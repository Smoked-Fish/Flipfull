/*
  global VideoPlayer, DeviceCapabilityManager, galleryErrorLargeSrc,
  Downsample
*/

/*
 * Media_frame.js:
 *
 * A MediaFrame displays a photo or a video. The gallery app uses
 * three side by side to support smooth panning from one item to the
 * next.  The Camera app uses one for image and video preview. The
 * Gallery app's open activity uses one of these to display the opened
 * item.
 *
 * MediaFrames have different behavior depending on whether they display
 * images or videos. Photo frames allow the user to zoom and pan on the photo.
 * Video frames allow the user to play and pause but don't allow zooming.
 *
 * When a frame is displaying a video, it handles mouse events.
 * When displaying a picture, however, it expects the client to handle events
 * and call the pan() and zoom() methods.
 *
 * The pan() method is a little unusual. It "uses" as much of the pan
 * event as it can, and returns a number indicating how much of the
 * horizontal motion it did not use. The gallery uses this returned
 * value for transitioning between frames.  If a frame displays a
 * photo that is not zoomed in at all, then it can't use any of the
 * pan, and returns the full amount which the gallery app turns into a
 * panning motion between frames.  But if the photo is zoomed in, then
 * the MediaFrame will just move the photo within itself, if it can, and
 * return 0.
 *
 * MediaFrame uses the #-moz-samplesize media fragment (via the downsample.js
 * module) to downsample large jpeg images while decoding them when necessary.
 * You can specify a maximum image decode size (in megapixels) when invoking
 * the constructor. The MediaFrame code also includes a runtime check for
 * the amount of RAM available on the device, and may limit the image decode
 * size on low-memory devices.
 */
function MediaFrame( // eslint-disable-line
  container,
  includeVideo,
  maxImageSize,
  autoHideProgressBar
) {
  this.clear();
  if (typeof container === 'string') {
    container = document.getElementById(container);
  }
  this.container = container;
  this.maximumImageSize = maxImageSize || 0;
  this.image = new Image();
  this.image.className = 'image-view';
  this.image.style.opacity = 0;
  this.image.onload = () => {
    this.image.style.opacity = 1;
  };
  this.image.style.transformOrigin = 'center center';
  this.image.style.backgroundImage = 'none';
  this.image.style.backgroundSize = 'contain';
  this.image.style.backgroundRepeat = 'no-repeat';
  this.container.appendChild(this.image);
  if (includeVideo) {
    this.video = new VideoPlayer(container, autoHideProgressBar);
    this.video.hide();
  }

  /*
   * Add a class to the container so we could find it later and use it as
   * a key in the instance weakmap.
   */
  container.classList.add('media-frame-container');
  MediaFrame.instancesToLocalize.set(container, this);
}

// WeakMap with the container nodes as keys and MediaFrame instances as values.
MediaFrame.instancesToLocalize = new WeakMap();

window.api.l10n.change(() => {
  // Retrieve MediaFrame instances by searching for container nodes.
  const containers = document.querySelectorAll('.media-frame-container');
  for (let container of containers) { // eslint-disable-line
    const instance = MediaFrame.instancesToLocalize.get(container);
    if (instance) {
      instance.localize();
    }
  }
});

DeviceCapabilityManager.get('hardware.memory').then(
  (mem) => {
    delete MediaFrame.pendingPromise;
    MediaFrame.maxImageDecodeSize = MediaFrame.computeMaxImageDecodeSize(mem);
  },
  () => {
    delete MediaFrame.pendingPromise;
    MediaFrame.maxImageDecodeSize = 0;
  }
);

MediaFrame.computeMaxImageDecodeSize = (mem) => {
  if (!mem) {
    return 0;
  } else if (mem < 256) {
    // This is a Tarako-class device ultra low-end device.
    return 2 * 1024 * 1024; // 2 megapixels
  } else if (mem < 512) {
    // This is a low-end 256mb device
    /*
     * Normally we can handle 3mp images on devices like this, but if
     * this device has a big screen and low memory (like a memory
     * throttled Flame) then it needs something smaller than 3mp.
     */
    const screensize =
      screen.width *
      window.devicePixelRatio *
      screen.height *
      window.devicePixelRatio;
    if (mem < 325 && screensize > 480 * 800) {
      return 2.5 * 1024 * 1024; // 2.5mp megapixels for throttled Flame
    }

    return 3 * 1024 * 1024; // 3 megapixels otherwise
  } else if (mem < 1024) {
    // A mid-range 512mb device
    return 5 * 1024 * 1024; // 5 megapixels
  }

  /*
   * A high-end device with 1 gigabyte or more of memory
   * Allow 8 megapixels of image decode size per gigabyte of memory
   */
  return mem / 1024 * 8 * 1024 * 1024;
};

// Determine whether we can use the preview image
MediaFrame.prototype.usePreview = function usePreview(preview, width, height) {
  // If no preview at all, we can't use it.
  if (!preview) {
    return false;
  }
  // If we don't know the preview size, we can't use it.
  if (!preview.width || !preview.height) {
    return false;
  }
  // If there isn't a preview offset or file, we can't use it
  if (!preview.start && !preview.filename) {
    return false;
  }
  // If the aspect ratio does not match, we can't use it
  if (Math.abs(width / height - preview.width / preview.height) > 0.01) {
    return false;
  }

  /*
   * If setMinimumPreviewSize has been called, then a preview is big
   * enough if it is at least that big.
   */
  if (this.minimumPreviewWidth && this.minimumPreviewHeight) {
    return (
      Math.max(preview.width, preview.height) >=
        Math.max(this.minimumPreviewWidth, this.minimumPreviewHeight) &&
      Math.min(preview.width, preview.height) >=
        Math.min(this.minimumPreviewWidth, this.minimumPreviewHeight)
    );
  }
  return true;
};

/*
 * If we've got a usable preview blob from EXIF or an external file,
 * this is what we do with it.
 */
MediaFrame.prototype.gotPreview = function gotPreview(
  previewblob,
  previewWidth,
  previewHeight
) {
  // Create a blob URL for the preview
  this.previewurl = URL.createObjectURL(previewblob);

  /*
   * In this case previewImageURL is the same as previewurl. In some other
   * cases, previewImageURL may have a media fragment appended, so we need
   * two distinct properties, however.
   */
  this.previewImageURL = this.previewurl;
  // Remember the preview size
  this.previewWidth = previewWidth;
  this.previewHeight = previewHeight;
  // Start off with the preview image displayed
  this.displayingPreview = true;
  this._displayImage(
    this.previewImageURL,
    this.previewWidth,
    this.previewHeight
  );
};

// If we don't have a preview image we can use this is what we do.
MediaFrame.prototype.noPreview = function noPreview(blob, width, height) {
  this.previewurl = null;

  /*
   * Figure out whether we can downsample the fullsize image for
   * use as a preview
   */
  const previewSampleSize = this.computePreviewSampleSize(blob, width, height);
  // If we can create a preview by downsampling...
  if (previewSampleSize === Downsample.NONE) {

    /*
     * If we can't (or don't need to) downsample the full image then note
     * that we don't have a preview and display the image at full size.
     */
    this.previewImageURL = null;
    this.displayingPreview = false;
    this._displayImage(
      this.fullImageURL,
      this.fullsizeWidth,
      this.fullsizeHeight
    );
  } else {

    /*
     * Combine the full image url with the downsample media fragment
     * to create a url for the downsampled preview.
     */
    this.previewImageURL = this.imageurl + previewSampleSize;
    // Compute the preview size based on the downsample amount.
    this.previewWidth = previewSampleSize.scale(width);
    this.previewHeight = previewSampleSize.scale(height);

    // Now start off with the downsampled image displayed
    this.displayingPreview = true;
    this._displayImage(
      this.previewImageURL,
      this.previewWidth,
      this.previewHeight
    );
  }
};

/*
 * If the blob is a JPEG then we can use #-moz-samplesize to downsample
 * it while decoding. If this is a particularly large image then to avoid
 * OOMs, we may not want to allow it to ever be decoded at full size
 */
MediaFrame.prototype.computeFullSampleSize = function computeFullSampleSize(
  blob,
  width,
  height
) {
  if (blob.type !== 'image/jpeg') {
    // We're not using #-moz-samplesize at all
    return Downsample.NONE;
  }

  /*
   * Determine the maximum size we will decode the image at, based on
   * device memory and the maximum size passed to the constructor.
   */
  let max = MediaFrame.maxImageDecodeSize || 0;
  if (this.maximumImageSize && (max === 0 || this.maximumImageSize < max)) {
    max = this.maximumImageSize;
  }
  if (!max || width * height <= max) {
    return Downsample.NONE;
  }
  return Downsample.areaAtLeast(max / (width * height));
};

MediaFrame.prototype.computePreviewSampleSize =
  function computePreviewSampleSize(blob, width, height) {
  // If the image is not a JPEG we can't use a samplesize
    if (blob.type !== 'image/jpeg') {
      return Downsample.NONE;
    }
  
    /*
     *
     * Determine how much we can scale the image down and still have it
     * big enough to fill the screen in at least one dimension.
     *
     * For example, suppose we have a 1600x1200 photo and a 320x480 screen
     *
     *  portraitScale = Math.min(.2, .4) = 0.2
     *  landscapeScale = Math.min(.3, .266) = 0.266
     *  scale = 0.266
     *
     */
    const screenWidth = window.innerWidth * window.devicePixelRatio;
    const screenHeight = window.innerHeight * window.devicePixelRatio;
  
    /*
     * To display the image in portrait orientation, this is how much we
     * have to scale it down to ensure that both dimensions fit
     */
    const portraitScale = Math.min(screenWidth / width, screenHeight / height);
  
    /*
     * To display the image in landscape, this is we need to scale it
     * this much
     */
    const landscapeScale = Math.min(screenHeight / width, screenWidth / height);
    // We need an image that is big enough in either orientation
    const scale = Math.max(portraitScale, landscapeScale);
    // Return the largest samplesize that still produces a big enough preview
    return Downsample.sizeNoMoreThan(scale);
};

MediaFrame.prototype.displayImage = function displayImage( // eslint-disable-line
  blob,
  width,
  height,
  preview,
  rotation,
  mirrored,
  largeSize
) {

  /*
   * If we are still querying the device memory, wait for that query to
   * complete and then try again.
   */
  if (MediaFrame.pendingPromise) {
    MediaFrame.pendingPromise.then(() => {
      this.displayImage(blob, width, height, preview, rotation, mirrored);
    });
    return;
  }
  this.clear(false, true); // Reset everything
  /*
   * Remember what we're displaying. This doesn't really need to be public
   * but the Gallery app uses it.
   */
  this.imageblob = blob;

  /*
   * Figure out if we are going to downsample the image before displaying it
   * We expose fullSampleSize as part of the public api only for testing.
   */
  this.fullSampleSize = this.computeFullSampleSize(blob, width, height);
  this.fullsizeWidth = this.fullSampleSize.scale(width);
  this.fullsizeHeight = this.fullSampleSize.scale(height);

  /*
   * Create a blob URL for the image and combine it with the media fragment.
   * imageurl is what we'll call revokeObjectURL on. fullImageURL may
   * have a media fragment appended, so we need to track both properties.
   */
  if (largeSize) {
    this.fullImageURL = galleryErrorLargeSrc;
  } else {
    this.imageurl = URL.createObjectURL(blob);
    this.fullImageURL = this.imageurl + this.fullSampleSize;
  }

  /*
   * Note: There is a default value for orientation/mirrored since some
   * images don't have EXIF data to retrieve this information.
   */
  this.rotation = rotation || 0;
  this.mirrored = mirrored || false;
  // Keep track of what kind of content we have
  this.displayingImage = true;

  /*
   * If a locale is present and ready, go ahead and localize now.
   * Otherwise, localization will be handled by the ready() callback above.
   */
  if (window.api.l10n.readyState === 'complete') {
    this.localize();
  }

  /*
   * To save memory, we want to avoid displaying the image at full size
   * whenever we can display a smaller preview of it. In general, we only
   * want to decode the full-size image if the user zooms in on it.
   * This code determines whether we have a usable preview image (or whether
   * we can downsample the full-size image) and if so, displays that image
   */
  if (this.usePreview(preview, width, height)) {
    if (preview.start) {
      this.gotPreview(
        blob.slice(preview.start, preview.end, 'image/jpeg'),
        preview.width,
        preview.height
      );
    } else {
      const storage = navigator.b2g.getDeviceStorage('pictures');
      const getReq = storage.get(preview.filename);
      getReq.onsuccess = () => {
        this.gotPreview(getReq.result, preview.width, preview.height);
      };
      getReq.onerror = () => {
        this.noPreview(blob, width, height);
      };
    }
  } else {
    this.noPreview(blob, width, height);
  }
};

/*
 * An internal method to set the url and size of the img element and to
 * reposition the image appropriately. We use this when first displaying an
 * image and when switching from the preview image to the full image and back.
 * The url argument is used as the img.src. The bg argument, if specified, is
 * a URL used for the CSS background-image property.  This is useful for
 * switching from a preview image to a full-size image (when the user zooms
 * in) without a flash while the full-size image is decoded.
 */
MediaFrame.prototype._displayImage = function _displayImage( // eslint-disable-line
  url,
  width,
  height,
  bg
) {

  /*
   * If a background was specfied, use it. If this is the preview image URL
   * and it is already decoded, it gives us something to display while the
   * full-size image is decoding.
   */
  if (bg) {
    this.image.style.backgroundImage = `url(${bg})`;
  } else {
    this.image.style.backgroundImage = 'none';
  }
  // Start loading and decoding the main image
  this.image.src = null;
  this.image.src = url;
  this.image.classList.add('displayframe');
  // Remember the width and height, but swap them for rotated images.
  if (this.rotation === 0 || this.rotation === 180) {
    this.itemWidth = width;
    this.itemHeight = height;
  } else {
    this.itemWidth = height;
    this.itemHeight = width;
  }
  // The image div has a new size, so we have to change its transform
  this.computeFit();
  this.setPosition();
};

/*
 * This function adds a label for accessibility to the image frame.
 * Videos are localized within the video player, so this is only for images.
 */
MediaFrame.prototype.localize = function localize() {
  if (!this.displayingImage) {
    return;
  }
  let portrait = this.fullsizeWidth < this.fullsizeHeight;
  if (this.rotation === 90 || this.rotation === 270) {
    // If rotated sideways, the width and height are swapped.
    portrait = !portrait;
  }
  const timestamp = this.imageblob.lastModifiedDate;
  const orientation = window.api.l10n.get(
    portrait ? 'orientationPortrait' : 'orientationLandscape'
  );
  let label = '';
  if (timestamp) {
    const localeEntry = window.api.l10n.get('imageDescription', {
      orientation
    });
    if (!this.dtf) {
      this.dtf = new window.api.l10n.DateTimeFormat();
    }
    label = this.dtf.localeFormat(new Date(timestamp), localeEntry);
  } else {
    label = window.api.l10n.get('imageDescriptionNoTimestamp', {
      orientation
    });
  }
  this.image.setAttribute('aria-label', label);
};

MediaFrame.prototype._switchToFullSizeImage =
  function _switchToFullSizeImage() {
    if (!this.displayingImage || !this.displayingPreview) {
      return;
    }
    this.displayingPreview = false;
    this._displayImage(
      this.fullImageURL,
      this.fullsizeWidth,
      this.fullsizeHeight,
      this.previewImageURL
    );
  };

MediaFrame.prototype._switchToPreviewImage = function _switchToPreviewImage() {

  /*
   * If we're not displaying an image or already displaying preview
   * or don't have a preview to display then there is nothing to do.
   */
  if (
    !this.displayingImage ||
    this.displayingPreview ||
    !this.previewImageURL
  ) {
    return;
  }
  this.displayingPreview = true;
  this._displayImage(
    this.previewImageURL,
    this.previewWidth,
    this.previewHeight
  );
};

MediaFrame.prototype.displayVideo = function displayVideo( // eslint-disable-line
  videoblob,
  posterblob,
  width,
  height,
  rotation
) {
  if (!this.video) {
    return;
  }
  this.clear(false); // Reset everything
  this.clear(true, false); // Reset everything
  // Keep track of what kind of content we have
  this.displayingVideo = true;
  // Remember the blobs
  this.videoblob = videoblob;
  this.posterblob = posterblob;
  // Get new URLs for the blobs
  this.videourl = URL.createObjectURL(videoblob);
  this.posterurl = URL.createObjectURL(posterblob);

  /*
   * Display them in the video element.
   * The VideoPlayer class takes care of positioning itself, so we
   * don't have to do anything here with computeFit() or setPosition()
   */
  this.video.load(
    this.videourl,
    this.posterurl,
    width,
    height,
    rotation || 0,
    videoblob.lastModifiedDate,
    false
  );
  // Show the player controls
  this.video.show();
};

// Reset the frame state, release any urls and and hide everything
MediaFrame.prototype.clear = function clear(
     resetImgSrc = true, resetVideoSrc = true) {
  // Reset the saved state
  this.displayingImage = false;
  this.displayingPreview = false;
  this.displayingVideo = false;
  this.itemWidth = null;
  this.itemHeight = null;
  this.imageblob = null;
  this.videoblob = null;
  this.posterblob = null;
  this.fullSampleSize = null;
  this.fullImageURL = null;
  this.previewImageURL = null;
  this.fullsizeWidth = null;
  this.fullsizeHeight = null;
  this.previewWidth = null;
  this.previewHeight = null;
  this.fit = null;
  if (this.imageurl) {
    URL.revokeObjectURL(this.imageurl);
  }
  this.imageurl = null;
  if (this.previewurl) {
    URL.revokeObjectURL(this.previewurl);
  }
  this.previewurl = null;
  // Hide the image and release anything it was displaying
  if (this.image && resetImgSrc) {
    this.image.style.opacity = 0;
    this.image.style.backgroundImage = 'none';
    this.image.src = '';
    this.image.removeAttribute('aria-label');
  }
  // Hide the video player
  if (this.video) {
    this.video.reset(resetVideoSrc);
    this.video.hide();
    if (this.videourl) {
      URL.revokeObjectURL(this.videourl);
    }
    this.videourl = null;
    if (this.posterurl) {
      URL.revokeObjectURL(this.posterurl);
    }
    this.posterurl = null;
  }
};

/*
 * Set the item's position based on this.fit
 * The VideoPlayer object fits itself to its container, and it
 * can't be zoomed or panned, so we only need to do this for images
 */
MediaFrame.prototype.setPosition = function setPosition(zoom) {
  if (!this.fit || !this.displayingImage) {
    return;
  }
  const dx = this.fit.left + (this.fit.width - this.itemWidth) / 2;
  const dy = this.fit.top + (this.fit.height - this.itemHeight) / 2;
  const sx = this.mirrored ? -this.fit.scale : this.fit.scale;
  const sy = this.fit.scale;
  let transform = `translate(${dx}px, ${dy}px) scale(${sx},${sy})`;
  if (this.previewurl && this.displayingPreview && this.rotation) {
    transform += ` rotate(${this.rotation}deg)`;
  }
  this.image.style.transform = transform;
  if (!zoom) {
    this.image.setAttribute('data-origin-scale', this.fit.scale);
    this.image.setAttribute('data-scale-delta', this.fit.scale / 5);
    this.image.setAttribute('data-zoom-in', 0);
    this.image.setAttribute('data-zoom-out', 0);
  }
};

MediaFrame.prototype.computeFit = function computeFit() {
  if (!this.displayingImage) {
    return;
  }
  this.viewportWidth = this.container.offsetWidth;
  this.viewportHeight = this.container.offsetHeight;

  const scalex = this.viewportWidth / this.itemWidth;
  const scaley = this.viewportHeight / this.itemHeight;
  const scale = Math.min(Math.min(scalex, scaley), 1);

  // Set the image size and position
  const width = Math.floor(this.itemWidth * scale);
  const height = Math.floor(this.itemHeight * scale);

  this.fit = {
    width,
    height,
    left: Math.floor((this.viewportWidth - width) / 2),
    top: Math.floor((this.viewportHeight - height) / 2),
    scale,
    baseScale: scale
  };
};

MediaFrame.prototype.reset = function reset() {

  /*
   * If we're not displaying the preview image, but we have one,
   * and it is the right size, then switch to it
   */
  if (this.displayingImage && !this.displayingPreview && this.previewImageURL) {
    this._switchToPreviewImage(); // Resets image size and position
    return;
  }

  // Otherwise, just resize and position the item we're already displaying
  this.computeFit();
  this.setPosition();
  // If frame is resized, the video's size also need to reset.
  if (this.displayingVideo) {
    this.video.setPlayerSize();
  }
};

/*
 * We call this from the resize handler when the user rotates the
 * screen or when going into or out of fullscreen mode. If the user
 * has not zoomed in, then we just fit the image to the new size (same
 * as reset).  But if the user has zoomed in (and we need to stay
 * zoomed for the new size) then we adjust the fit properties so that
 * the pixel that was at the center of the screen before remains at
 * the center now, or as close as possible
 */
MediaFrame.prototype.resize = function resize() {
  const oldWidth = this.viewportWidth;
  const oldHeight = this.viewportHeight;
  const newWidth = this.container.offsetWidth;
  const newHeight = this.container.offsetHeight;

  const oldfit = this.fit; // The current image fit

  /*
   * If this is triggered by a resize event before the frame has computed
   * its size, then there is nothing we can do yet.
   */
  if (!oldfit) {
    return;
  }

  /*
   * Compute the new fit.
   * This updates the the viewportWidth, viewportHeight and fit properties
   */
  this.computeFit();

  // This is how the image would fit at the new screen size
  const newfit = this.fit;

  /*
   * If no zooming has been done (or almost no zooming), then a resize is just
   * a reset. The same is true if the new fit base scale is greater than the
   * old scale.
   * The scale is calculated with division, the value may not be accurate
   * because of IEEE 754. We use abs difference to do the equality checking.
   */
  if (
    Math.abs(oldfit.scale - oldfit.baseScale) < 0.01 ||
    newfit.baseScale > oldfit.scale
  ) {
    this.reset();
    return;
  }

  /*
   * Otherwise, just adjust the old fit as needed and use that so we
   * retain the zoom factor.
   */
  oldfit.left += (newWidth - oldWidth) / 2;
  oldfit.top += (newHeight - oldHeight) / 2;
  oldfit.baseScale = newfit.baseScale;
  this.fit = oldfit;

  // Reposition this image without resetting the zoom
  this.setPosition();
};

/*
 * Zoom in by the specified factor, adjusting the pan amount so that
 * the image pixels at (fixedX, fixedY) remain at that position.
 * Assume that zoom gestures can't be done in the middle of swipes, so
 * if we're calling zoom, then the swipe property will be 0.
 * If time is specified and non-zero, then we set a CSS transition
 * to animate the zoom.
 */
MediaFrame.prototype.zoom = function zoom(scale, fixedX, fixedY, time) { // eslint-disable-line
  // Ignore zooms if we're not displaying an image
  if (!this.displayingImage) {
    return;
  }

  // If we were displaying the preview switch to the full-size image.
  if (this.displayingPreview) {
    this._switchToFullSizeImage();
  }

  // Never zoom in farther than the native resolution of the image
  if (this.fit.scale * scale > 1) {
    scale = 1 / this.fit.scale;
  // And never zoom out to make the image smaller than it would normally be
  } else if (this.fit.scale * scale < this.fit.baseScale) {
    scale = this.fit.baseScale / this.fit.scale;
  }

  this.fit.scale *= scale;

  // Change the size of the photo
  this.fit.width = Math.floor(this.itemWidth * this.fit.scale);
  this.fit.height = Math.floor(this.itemHeight * this.fit.scale);

  /*
   * FixedX and fixedY are in viewport coordinates.
   * These are the photo coordinates displayed at that point in the viewport
   */
  let photoX = fixedX - this.fit.left;
  let photoY = fixedY - this.fit.top;

  /*
   * After zooming, these are the new photo coordinates.
   * Note we just use the relative scale amount here, not this.fit.scale
   */
  photoX = Math.floor(photoX * scale);
  photoY = Math.floor(photoY * scale);

  // To keep that point still, here are the new left and top values we need
  this.fit.left = fixedX - photoX;
  this.fit.top = fixedY - photoY;

  /*
   * Now make sure we didn't pan too much: If the image fits on the
   * screen, fixed it. If the image is bigger than the screen, then
   * make sure we haven't gone past any edges
   */
  if (this.fit.width <= this.viewportWidth) {
    this.fit.left = (this.viewportWidth - this.fit.width) / 2;
  } else {
    // Don't let the left of the photo be past the left edge of the screen
    if (this.fit.left > 0) {
      this.fit.left = 0;
    }

    // Right of photo shouldn't be to the left of the right edge
    if (this.fit.left + this.fit.width < this.viewportWidth) {
      this.fit.left = this.viewportWidth - this.fit.width;
    }
  }

  if (this.fit.height <= this.viewportHeight) {
    this.fit.top = (this.viewportHeight - this.fit.height) / 2;
  } else {
    // Don't let the top of the photo be below the top of the screen
    if (this.fit.top > 0) {
      this.fit.top = 0;
    }

    // Bottom of photo shouldn't be above the bottom of screen
    if (this.fit.top + this.fit.height < this.viewportHeight) {
      this.fit.top = this.viewportHeight - this.fit.height;
    }
  }

  /*
   * If a time was specified, set up a transition so that the
   * call to setPosition() below is animated
   */
  if (time) {
    // If a time was specfied, animate the transformation
    const transition = `transform ${time}ms ease`;
    this.image.style.transition = transition;

    const self = this; // eslint-disable-line
    this.image.addEventListener('transitionend', function done() {
      self.image.removeEventListener('transitionend', done);
      self.image.style.transition = '';
    });
  }

  this.setPosition();
};

MediaFrame.prototype.zoomFrame = function zoomFrame( // eslint-disable-line
  scale,
  fixedX,
  fixedY,
  time
) {
  // Ignore zooms if we're not displaying an image
  if (!this.displayingImage) {
    return;
  }
  // If we were displaying the preview switch to the full-size image.
  if (this.displayingPreview) {
    this._switchToFullSizeImage();
  }
  this.fit.scale = scale;
  const overflowx = Math.abs(this.fit.width - this.viewportWidth);
  const overflowy = Math.abs(this.fit.height - this.viewportHeight);
  let ratiol = Math.abs(this.fit.left / overflowx);
  let ratiot = Math.abs(this.fit.top / overflowy);
  if (this.fit.left > 0 || this.fit.width <= this.viewportWidth) {
    ratiol = 0.5;
  }
  if (this.fit.top > 0 || this.fit.height <= this.viewportHeight) {
    ratiot = 0.5;
  }
  // Change the size of the photo
  this.fit.width = Math.floor(this.itemWidth * this.fit.scale);
  this.fit.height = Math.floor(this.itemHeight * this.fit.scale);

  /*
   * FixedX and fixedY are in viewport coordinates.
   * These are the photo coordinates displayed at that point in the viewport
   */
  let photoX = fixedX - this.fit.left;
  let photoY = fixedY - this.fit.top;

  /*
   * After zooming, these are the new photo coordinates.
   * Note we just use the relative scale amount here, not this.fit.scale
   */
  photoX = Math.floor(photoX * scale);
  photoY = Math.floor(photoY * scale);
  // To keep that point still, here are the new left and top values we need
  this.fit.left = fixedX - photoX;
  this.fit.top = fixedY - photoY;

  /*
   * Now make sure we didn't pan too much: If the image fits on the
   * screen, fixed it. If the image is bigger than the screen, then
   * make sure we haven't gone past any edges
   */
  if (this.fit.width <= this.viewportWidth) {
    this.fit.left = (this.viewportWidth - this.fit.width) / 2;
  } else {
    // Don't let the left of the photo be past the left edge of the screen
    if (this.fit.left > 0) {
      this.fit.left = 0;
    }
    // Right of photo shouldn't be to the left of the right edge
    if (Math.abs(this.fit.left) + this.fit.width < this.viewportWidth) {
      this.fit.left = this.viewportWidth - this.fit.width;
    } else {
      this.fit.left = (this.viewportWidth - this.fit.width) * ratiol;
    }
  }
  if (this.fit.height <= this.viewportHeight) {
    this.fit.top = (this.viewportHeight - this.fit.height) / 2;
  } else {
    // Don't let the top of the photo be below the top of the screen
    if (this.fit.top > 0) {
      this.fit.top = 0;
    }
    // Bottom of photo shouldn't be above the bottom of screen
    if (Math.abs(this.fit.top) + this.fit.height < this.viewportHeight) {
      this.fit.top = this.viewportHeight - this.fit.height;
    } else {
      this.fit.top = (this.viewportHeight - this.fit.height) * ratiot;
    }
  }

  /*
   * If a time was specified, set up a transition so that the
   * call to setPosition() below is animated
   */
  if (time) {
    // If a time was specfied, animate the transformation
    const transition = `transform ${time}ms ease`;
    this.image.style.transition = transition;
    const self = this; // eslint-disable-line
    this.image.addEventListener('transitionend', function done() {
      self.image.removeEventListener('transitionend', done);
      self.image.style.transition = null;
    });
  }

  this.setPosition(true);
};

/*
 * If the item being displayed is larger than the continer, pan it by
 * the specified amounts.  Return the "unused" dx amount for the gallery app
 * to use for sideways swiping
 */
MediaFrame.prototype.pan = function pan(dx, dy) {
  // We can only pan images, so return the entire dx amount
  if (!this.displayingImage) {
    return dx;
  }

  /*
   * Handle panning in the y direction first, since it is easier.
   * Don't pan in the y direction if we already fit on the screen
   */
  if (this.fit.height > this.viewportHeight) {
    this.fit.top += dy;

    // Don't let the top of the photo be below the top of the screen
    if (this.fit.top > 0) {
      this.fit.top = 0;
    }

    // Bottom of photo shouldn't be above the bottom of screen
    if (this.fit.top + this.fit.height < this.viewportHeight) {
      this.fit.top = this.viewportHeight - this.fit.height;
    }
  }

  /*
   * Now handle the X dimension. If we've already panned as far as we can
   * within the image (or if it isn't zoomed in) then return the "extra"
   * unused dx amount to the caller so that the caller can use them to
   * shift the frame left or right.
   */
  let extra = 0;

  if (this.fit.width <= this.viewportWidth) {
    // In this case, the photo isn't zoomed in, so it is all extra
    extra = dx;
  } else {
    this.fit.left += dx;

    /*
     * If this would take the left edge of the photo past the
     * left edge of the screen, then some of the motion is extra
     */
    if (this.fit.left > 0) {
      extra = this.fit.left;
      this.fit.left = 0;
    }

    /*
     * Or, if this would take the right edge of the photo past the
     * right edge of the screen, then we've got extra.
     */
    if (this.fit.left + this.fit.width < this.viewportWidth) {
      extra = this.fit.left + this.fit.width - this.viewportWidth;
      this.fit.left = this.viewportWidth - this.fit.width;
    }
  }

  this.setPosition(true);
  return extra;
};

MediaFrame.prototype.setMinimumPreviewSize = function setMinimumPreviewSize(
  w,
  h
) {
  this.minimumPreviewWidth = w;
  this.minimumPreviewHeight = h;
};

window.MediaFrame = MediaFrame;