import Utils from 'contact_utils';
import ContactStore, { TAG_INDEX } from 'contact_store';
import ContactDraftManager from 'contact_draft_manager';
import SimpleNavigationHelper from 'simple-navigation-helper';
import Service from 'service';

const FIELDS = ['name', 'tel', 'familyName', 'givenName', 'email'];
const MAX_TEL_LENGTH = 20;
const MAX_TEXT_LENGTH = 100;

class ContactEditor {
  name = 'ContactEditor';
  FOCUS_SELECTOR = '.navigable:not(.hidden)';
  SCROLL_SELECTOR = '.list-item';

  constructor({ container, params }) {
    this.container = container;
    this.params = params;
    const getData = ContactStore.getWrappedContact('new', this.params).then(
      (contact) => {
        this.contact = contact;
      },
    );
    this.loadExtraFiles().then(() => {
      Promise.all([getData, this.chooseMemory()]).then(() => {
        if (this.target) {
          this.render();
          this.componentDidMount();
          this.saveDraft();
        }
      });
    });
  }

  componentDidMount() {
    this.onFocus = this.onFocus.bind(this);
    this.onKeyDown = this.onKeyDown.bind(this);
    this.onInput = this.onInput.bind(this);
    this.element = document.querySelector('.contact-editor');
    this.element.addEventListener('focus', this.onFocus, true);
    this.element.addEventListener('keydown', this.onKeyDown, true);
    this.element.addEventListener('input', this.onInput);
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.container,
      this.SCROLL_SELECTOR,
    );
    this.updateSoftKeys();
    this.element.focus();
    if (ContactStore.source !== 'sim') {
      window.dispatchEvent(new CustomEvent('activityLoaded'));
    }
  }

  componentWillUnMount() {
    if (!this.element) {
      return;
    }
    this.element.removeEventListener('focus', this.onFocus);
    this.element.removeEventListener('keydown', this.onKeyDown);
    this.element.removeEventListener('input', this.onInput);
    this.navigator.destroy();
  }

  loadExtraFiles() {
    return new Promise((resolve) => {
      if (ContactStore.source !== 'phone') {
        let loadFiles = [
          'http://shared.localhost/js/helper/simslot/simslot.js',
          'http://shared.localhost/js/helper/simslot/simslot_manager.js'
        ];
        const simOnly = ContactStore.source === 'sim';

        if (simOnly) {
          const dialogFiles = [
            'http://shared.localhost/style/commons/confirm.css',
            'http://shared.localhost/js/utils/toaster/toaster.js',
            'http://shared.localhost/js/helper/dialog/confirm_dialog_helper.js'
          ];
          loadFiles = loadFiles.concat(dialogFiles);
        }
        window.LazyLoader.load(loadFiles).then(() => {
          require.ensure([], () => {
            if (simOnly) {
              require('./dialog-register');
            }
            resolve();
          });
        });
      } else {
        resolve();
      }
    });
  }

  chooseMemory() {
    return new Promise((resolve) => {
      Utils.chooseMemory().then((memory) => {
        if (!memory) {
          this.backOrClose();
        } else {
          this.target = memory;
        }
        resolve();
      });
    });
  }

  updateSoftKeys() {
    const savable = this.isChanged() && !this.isEmpty();
    const params = [{
      l10nId: 'cancel',
      priority: 1,
      method: () => {
        if (this.isChanged()) {
          this.showDiscardDialog();
        } else {
          this.backOrClose();
        }
      }
    }];
    if (savable) {
      params.push({
        l10nId: 'save',
        priority: 2,
        method: () => {
          this.save();
        }
      });
    }
    Service.request('showSoftkey', { params });
  }

  isTheSame(fieldA, fieldB) {
    return JSON.stringify(fieldA) === JSON.stringify(fieldB);
  }

  isEmpty() {
    let data = this.getInputData();
    for (let key in data) {
      if (data[key]) {
        return false;
      }
    }
    return true;
  }

  getInputData() {
    let config = {};
    const domList = this.element.querySelectorAll('input');
    for (let dom of domList) {
      let field = dom.dataset.field;
      let value = dom.value.trim();
      if ('' === value) {
        continue;
      }
      if ('givenName' === field || 'familyName' === field || 'name' === field) {
        config[field] = [value];
      } else {
        let type = dom.dataset.type;
        let data = {
          type: [type],
          value: value,
        };
        if (config[field]) {
          config[field].push(data);
        } else {
          config[field] = [data];
        }
      }
    }
    return config;
  }

  isChanged() {
    if (ContactDraftManager.hasCache) {
      return true;
    }
    let changed = false;
    let data = this.getInputData();
    FIELDS.some((field) => {
      let current = this.contact.contact[field];
      let next = data[field];
      if (!Array.isArray(current)) {
        current = [current];
      }
      if (!Array.isArray(next)) {
        next = [next];
      }
      if (
        (!current.length || (1 === current.length && !current[0])) &&
        (!next.length || (1 === next.length && !next[0]))
      ) {
        return false;
      }

      // XXX: This logic does not work for blob.
      if (!this.isTheSame(next, current)) {
        if (this.isSIMcontact() && ('name' === field || 'tel' === field)) {
          changed = true;
          return true;
        }
        if (!this.isSIMcontact() && 'name' !== field) {
          changed = true;
          return true;
        }
      }
      return false;
    });
    return changed;
  }

  backOrClose() {
    this.componentWillUnMount();
    let p = Promise.resolve();
    if (ContactDraftManager.hasCache && this.target) {
      const id = this.contact.id;
      const data = ContactStore.getContactSync(id);
      // remove data of draft from wrappedContactMap
      data && ContactStore.wrappedContactMap.get(id).update(data);
      p = ContactDraftManager.removeItem();
    }
    p.then(() => {
      Service.request('leaveActivity');
    });
  }

  showDiscardDialog() {
    const content = 'new' === this.contact.id
      ? 'confirm-discard-contact-data'
      : 'confirm-discard-contact-update-data';
    Service.request('showDialog', {
      header: 'confirm',
      content: content,
      type: 'custom',
      buttons: [
        {
          message: 'cancel',
        },
        {
          message: 'save',
        },
        {
          message: 'discard',
        },
      ],
      onSelect: (data) => {
        if (3 === data.priority) {
          this.contact.normalize();
          this.backOrClose();
        } else if (2 === data.priority) {
          this.save();
        }
      },
    });
  }

  onKeyDown(evt) {
    const dom = document.activeElement;
    console.log('onkeydown', evt);
    switch (evt.key) {
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        if ('INPUT' === dom.tagName && '' !== dom.value) {
          return;
        }
        // eslint-disable-next-line
      case 'EndCall':
        evt.preventDefault();
        evt.stopPropagation();
        if (this.isChanged()) {
          this.showDiscardDialog();
        } else {
          this.backOrClose();
        }
        break;  
      default:
        break;
    }
  }

  onFocus() {
    this._processingSave = false;
    this.updateSoftKeys();
    if (
      this.element.contains(document.activeElement) &&
      document.activeElement !== this.element
    ) {
      const prev = this.element.querySelector('.focus');
      if (prev) {
        const preLabel = prev.getElementsByTagName('label');
        const preInput = prev.getElementsByTagName('input')[0];
        if (preLabel && preLabel.length && preInput && !preInput.value) {
          preLabel[0].classList.remove('visibile');
          preLabel[0].classList.add('disvisibile');
        }
        prev.classList.remove('focus');
      }
      if ('INPUT' === document.activeElement.tagName) {
        document.activeElement.parentNode.parentNode.classList.add('focus');
        const currentLabel =
          document.getElementById(document.activeElement.id + '-label');
        currentLabel.classList.remove('disvisibile');
        Utils.setCursorToEnd(document.activeElement);
      }
    }
  }

  onInput() {
    this.updateSoftKeys();
    this.saveDraft();
  }

  saveDraft() {
    if (this.isEmpty()) {
      return ContactDraftManager.removeItem();
    }
    const data = this.getInputData();
    if (this.isSIMcontact()) {
      data.category =
        [TAG_INDEX.sim, this.target.toUpperCase(), TAG_INDEX.kaiContact];
    } else if (!data.category || 0 === data.category.length) {
      data.category = [TAG_INDEX.phone, TAG_INDEX.kaiContact];
    }
    data.id = 'new' !== this.contact.id ? this.contact.id : '';
    data.name = [`${data.givenName || ''} ${data.familyName || ''}`.trim()];
    ContactDraftManager.setItem(data);
  }

  save() {
    if (!ContactStore._cached) {
      ContactStore.on('loaded', () => {
        this.save();
      });
      return;
    }
    if (this._processingSave) {
      return;
    }
    this._processingSave = true;
    let config = this.getInputData();
    const bSIM = this.isSIMcontact();
    const _ = window.api.l10n.get;

    if (!bSIM) {
      if (Utils.inSurnameLang() ||
        Utils.isChinese(config.familyName) &&
        Utils.isChinese(config.givenName)
      ) {
        config.name = [
          `${config.familyName || ''}${config.givenName || ''}`.trim(),
        ];
      } else {
        config.name = [
          `${config.givenName || ''} ${config.familyName || ''}`.trim(),
        ];
      }
    }

    if (this.contact) {
      FIELDS.forEach((field) => {
        if (config[field]) {
          this.contact.contact[field] = config[field];
        } else {
          this.contact.contact[field] = null;
        }
      });
      config = this.contact.contact;
    }
    config.category = bSIM ?
      [TAG_INDEX.sim, this.target.toUpperCase(), TAG_INDEX.kaiContact] :
      [TAG_INDEX.phone, TAG_INDEX.kaiContact];

    ContactStore.createOrUpdate(config, false, 'manual').then(
      (result) => {
        let { message } = result;
        if (bSIM && config.name && result.data &&
          config.name[0].length > result.data.name[0].length) {
          message = [message, _('name-exceeds-limit')].join(' ');
        }
        if (!result.error) {
          message = [message, _('activity-new-contact-tap')].join(' ');
        }
        window.Toaster.showToast({ message });
        this.backOrClose();
      },
    );
  }

  isSIMcontact() {
    return this.target && this.target.startsWith('sim');
  }

  getInputType(field) {
    switch (field) {
      case 'email':
        return 'email';
      case 'tel':
      case 'postalCode':
        return 'tel';
      case 'bday':
        return 'date';
      default:
        return 'text';
    }
  }

  render() {
    let data = [];
    let dom = [];
    this.contact.dataMap.forEach((array) => {
      if (array.length && array[0].field === 'familyName') {
        let givenName = data.pop();
        if (Utils.inSurnameLang() ||
            Utils.isChinese(array[0].value) &&
            Utils.isChinese(givenName.value)) {
          data = data.concat(array);
          data.push(givenName);
        } else {
          data.push(givenName);
          data = data.concat(array);
        }
      } else {
        data = data.concat(array);
      }
    });
    data.forEach((content) => {
      const field = content.field;
      const index = content.index;
      const type = content.type;
      const containerKey = `${field}-${index}`;
      const value = content.value;
      const placeholder = Utils.getPlaceholderConfig(field, type);
      let extraConfig = '';
      for (let k in placeholder) {
        extraConfig += k + '="' + placeholder[k] + '" ';
      }
      const fieldContent = `
      <div
        class="list-item"
        tabIndex="-1"
        data-type="input"
        data-field=${field}
      >
        <div class="content">
          <label
            class="secondary ${('' === value ? 'disvisibile' : 'visibile')}"
            htmlFor=${`new-${containerKey}`}
            id=${`new-${containerKey}-label`}
            data-l10n-id=${type ? `${type}-${field}` : field}
          ></label>
          <input
            aria-label="new-contact-title"
            aria-describedby=${`new-${containerKey}-label`}
            type=${this.getInputType(field)}
            data-index=${index}
            data-field=${field}
            data-type=${type}
            id=${`new-${containerKey}`}
            ${extraConfig}
            class="navigable"
            name=${field}
            maxlength=${'tel' === field ? MAX_TEL_LENGTH : MAX_TEXT_LENGTH}
            value=${value || ''}
          ></input>
        </div>
      </div>`;
      switch (field) {
        case 'familyName':
        case 'givenName':
          if (this.isSIMcontact()) {
            break;
          }
          dom.push(fieldContent);
          break;
        case 'name':
          if (!this.isSIMcontact()) {
            break;
          }
          dom.push(fieldContent);
          break;
        case 'tel':
          dom.push(fieldContent);
          break;
        case 'email':
          if (value && !this.isSIMcontact()) {
            dom.push(fieldContent);
          }
          break;
        default:
          break;
      }
    });

    const container = `
    <div id="edit-view" tabIndex="-1">
      <div class="header h1" data-l10n-id="new-contact-title"></div>
      <div
        role="form"
        class="contact-editor"
        tabIndex="-1"
      >
        ${dom.join('')}
      </div>
    </div>`;
    this.container.insertAdjacentHTML('beforeend', container);
  }
}
export default ContactEditor;
