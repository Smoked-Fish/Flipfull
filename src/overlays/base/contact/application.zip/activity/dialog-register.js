import Service from 'service';

class Dialog {
  name = 'showDialog';

  constructor() {
    Service.register('showDialog', this);
    this.initDialog();
  }

  initDialog() {
    this.dialog = new window.ConfirmDialogHelper({});
  }

  showDialog(data) {
    const { header, content, type, onSelect, buttons } = data;
    const dialogConfig = {
      title: { id: header, args: {} },
      body: {
        id: content,
        args: {},
      },
    };
    NavigationMap.currentActivatedLength = 0;
    if ('alert' === type) {
      if ('add-contact-failed' === header) {
        dialogConfig.accept = {
          l10nId: 'ok',
          callback: () => {
            Service.request('leaveActivity');
          }
        };
      } else {
        dialogConfig.accept = {
          l10nId: 'save',
          callback: () => {
            onSelect();
          }
        };
      }
    } else if ('custom' === type) {
      Object.assign(dialogConfig, {
        cancel: {
          l10nId: buttons[0].message,
          callback: () => {
            onSelect({ priority: 1 });
          },
        },
        accept: {
          l10nId: buttons[1].message,
          priority: 2,
          callback: () => {
            onSelect({ priority: 2 });
          },
        },
        confirm: {
          l10nId: buttons[2].message,
          priority: 3,
          callback: () => {
            onSelect({ priority: 3 });
          },
        },
      });
    }
    this.dialog.config = dialogConfig;
    this.dialog.show(document.body);
  }
}
const dialog = new Dialog();
export default dialog;
