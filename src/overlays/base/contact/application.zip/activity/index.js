import Service from 'service';
import './serviceworker-emitter';
import 'system_message_handler';
import 'common-scss';
import './softkey-register';
import './index.scss';

const ROUTE_MAP = {
  '#new-activity': './contact-editor.js',
};
window.NavigationMap = {};
window.SettingsObserver = null;
window.AccountManager = null;

export default class App {
  constructor() {
    this.init();
  }

  init() {
    const hash = window.location.hash;
    const container = document.querySelector('.activity-content');
    window.addEventListener('activityLoaded', this);
    this.apiInit().then(() => {
      Service.request('SystemMessageHandler:ready').then(() => {
        const params = Service.query('activityParams');
        console.log('activty index params', params);
        if (hash && ROUTE_MAP[hash]) {
          require.ensure([], () => {
            const cEditor = require('./contact-editor.js');
            const Component = cEditor.default;
            new Component({ container, params });
          });
        }
      });
    });
  }

  apiInit() {
    const servicesArray = ['contactsService'];
    return new Promise(resolve => {
      /* Session init */
      return window.libSession.initService(servicesArray).then(() => {
        // DeviceCapabilityManager enable.
        resolve();
      });
    });
  }

  handleEvent(evt) {
    switch (evt.type) {
      case 'activityLoaded':
        window.removeEventListener('activityLoaded', this);
        this.loadExtraFiles();
        break;
      default:
        break;
    }
  }

  loadExtraFiles() {
    window.LazyLoader.load([
      'http://shared.localhost/style/commons/confirm.css',
      'http://shared.localhost/js/utils/toaster/toaster.js',
      'http://shared.localhost/js/helper/dialog/confirm_dialog_helper.js'
    ], () => {
      require.ensure([], () => {
        require('./dialog-register');
      });
    });
  }
}
window.app = new App();
