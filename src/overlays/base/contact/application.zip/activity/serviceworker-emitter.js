class ServiceWorkerEmitter {
  name = 'swEmitter';
  listeners = new Map();
  data = null;

  /**
   * Registers listener function to be executed once event occurs.
   * @param {string} eventName Name of the event to listen for.
   * @param {function} handler Handler to be executed once event occurs.
   */
  on(eventName, handler) {
    let handlers = this.listeners.get(eventName);

    if (!handlers) {
      handlers = new Set();
      this.listeners.set(eventName, handlers);
    }

    // Ignores handler if it has been already registered
    handlers.add(handler);
    if (this.data) {
      this.emit(eventName, this.data);
    }
  }

  /**
   * Removes registered listener for the specified event.
   * @param {string} eventName Name of the event to remove listener for.
   * @param {function} handler Handler to remove, so it won't be executed
   * next time event occurs.
   */
  off(eventName, handler) {
    const handlers = this.listeners.get(eventName);

    if (!handlers) {
      return;
    }

    handlers.delete(handler);

    if (!handlers.size) {
      this.listeners.delete(eventName);
    }
  }

  /**
   * Removes all registered listeners for the specified event.
   * @param {string} eventName Name of the event to remove all listeners for.
   */
  offAll(eventName) {
    if ('undefined' === typeof eventName) {
      this.listeners.clear();
      return;
    }

    const handlers = this.listeners.get(eventName);

    if (!handlers) {
      return;
    }

    handlers.clear();

    this.listeners.delete(eventName);
  }

  /**
   * Emits specified event so that all registered handlers will be called
   * with the specified parameters.
   * @param {string} eventName Name of the event to call handlers for.
   * @param {Object} parameters Optional parameters that will be passed to
   * every registered handler.
   */
  emit(eventName, ...parameters) {
    const handlers = this.listeners.get(eventName);

    if (!handlers) {
      return;
    }

    handlers.forEach(handler => {
      try {
        handler(...parameters);
      } catch (e) {
        console.error(e);
      }
    });
  }
}

const swEmitter = new ServiceWorkerEmitter();
window._SWObserver = swEmitter;
navigator.serviceWorker.addEventListener('message', ({ data }) => {
  window._SWObserver.data = data;
  window._SWObserver.emit('swMessage', data);
});

export default swEmitter;