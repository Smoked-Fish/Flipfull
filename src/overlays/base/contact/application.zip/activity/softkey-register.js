import Service from 'service';
import SimpleNavigationHelper from 'simple-navigation-helper';

class SoftKey {
  name = 'softkey';
  FOCUS_SELECTOR = '#mainmenu .menu-button';

  constructor() {
    window.addEventListener('menuEvent', this.menuChange.bind(this));
    Service.register('showSoftkey', this);
    Service.register('showOptionMenu', this);
  }

  initMenuNavigation() {
    this.navigator = new SimpleNavigationHelper(
      this.FOCUS_SELECTOR,
      this.menuContainer,
    );
  }

  menuChange(evt) {
    if (evt.detail.menuVisible) {
      this.menuContainer = evt.detail.softkeyPanel.menu.form;
      this.initMenuNavigation();
      this.menuContainer.addEventListener('keydown', this.onKeyDown);
    } else {
      if (this.menuContainer) {
        this.menuContainer.removeEventListener('keydown', this.onKeyDown);
      } 
    }
  }

  onKeyDown = (e) => {
    switch (e.key) {
      case 'EndCall':
      case 'Backspace':
        this.onCancel && this.onCancel();
        break;
      default:
        break;
    }
  };

  showOptionMenu({ options, onCancel }) {
    const params = [];
    options.map((data) => {
      params.push({
        l10nId: data.id,
        priority: 5,
        method: () => {
          data.callback();
        }
      });
    });
    this.onCancel = onCancel;
    this.showSoftkey({
      header: { l10nId: 'options' },
      params,
      showMenu: true
    });
  }

  showSoftkey({ params, header = '', showMenu = false }) {
    const skConfig = {
      header,
      items: params
    };
    if (!this.softkey) {
      this.softkey = new SoftkeyPanel(skConfig);
    } else {
      this.softkey.initSoftKeyPanel(skConfig);
    }
    this.softkey.show();
    if (showMenu) {
      window.dispatchEvent(new KeyboardEvent('keydown', {
        key: 'SoftRight'
      }));
    }
  }
}
const softKey = new SoftKey();
window.softKey = softKey;
export default softKey;
