const LAZY_LOAD_FILES = [
  `http://shared.localhost/js/utils/toaster/toaster.js`,
  'http://shared.localhost/js/utils/storage/async_storage.js',
  `http://shared.localhost/js/helper/sim_settings/sim_settings_helper.js`,
  `http://shared.localhost/js/helper/simslot/simslot.js`,
  `http://shared.localhost/js/helper/simslot/simslot_manager.js`,
  `http://shared.localhost/js/helper/softkey/softkey_register.js`,
  'http://shared.localhost/js/utils/common/app_origin.js',
  'account_manager_next.js',
  'dist/bundle.js',
];
const SESSION_FILES = [
  'http://shared.localhost/js/session/settings/settings_observer.js',
  'http://shared.localhost/js/session/account_manager/account_manager.js',
  'http://shared.localhost/js/session/apps_manager/apps_manager.js',
];
const PreloadApp = {
  itemSum: 0,
  PRELOAD_SIZE: 4,

  /**
   * This is template string of list item.
   * If the dom structure of list item is changed, we need to change here too.
   */
  template(c) {
    const reg = /<(?:[^"'>]|"[^"]*"|'[^']*')*>/g;
    const getSimIcon = contact => {
      let icon;
      const simNum = navigator.b2g.iccManager
        ? navigator.b2g.iccManager.iccIds.length
        : 0;
      if (1 >= simNum) {
        icon = `sim-card`;
      } else {
        icon = `sim-card-${contact.category.indexOf('SIM0') >= 0 ? '1' : '2'}`;
      }
      return `<i class="icon" data-icon="${icon}"></i>`;
    };

    const simicon =
      c.category && c.category.indexOf('SIM') >= 0 ? getSimIcon(c) : '';
    let icon = '';
    if (!this.isLowMemoryDevice) {
      if (c.photoBlob && c.photoBlob.length) {
        icon = `<span class="icon photo"><canvas /></span>`;
      } else {
        icon = '<i class="icon" data-icon="contacts" role="presentation"></i>';
      }
    }

    let name = '';
    if (c.name) {
      name = c.name;
    } else if (c.tel && c.tel[0]) {
      name = c.tel[0].value;
    } else if (c.email && c.email[0]) {
      name = c.email[0].value;
    }
    name = name.replace(reg, '');

    const favicon =
      c.category && c.category.includes('favorite')
        ? '<i class="icon" data-icon="favorite-on"></i>'
        : '';

    return `<div tabindex="-1" class="list-item" data-type="list">
      <div class="contact-list-item">
        ${icon}
        <div class="content">
          <div class="primary">
            <a data-l10n-id=${name ? "''" : 'no-name'}>${name}</a>
          </div>
        </div>
        ${simicon}
        ${favicon}
      </div>
    </div>`;
  },

  init() {
    const hash = window.location.hash;
    const activityReg = /^#\/?[^\s]+/;
    this.handleSWMessage();
    window.addEventListener('fullyloaded', this);
    window.cachedContacts = [];
    this.ssr = document.getElementById('ssr');
    this.content = document.querySelector('.content-placeholder');
    LazyLoader.load([`http://shared.localhost/js/utils/phone/operator_utils.js`]); //Porting from 11459618 xiaolei.yin add to GF5GTMO-3575 20240822
    if (activityReg.test(hash)) {
      let softKey = document.querySelector('.softkey-placeholder');
      softKey.innerHTML = `<button class="hidden"></button>`;
      let header = '';
      if (hash.endsWith('update') || hash.endsWith('pick')) {
        header = '<div class="header h1"><span data-l10n-id="select-a-contact"></span></div>';
      }
      this.content.innerHTML = `${header}
      <div class="body ${header ? 'contact-header' : ''}">
        <div class="loading-contacts primary">
          <div data-l10n-id="loading"></div>
        </div>
        <div class="header-progress"/>
      </div>`;

      LazyLoader.load(SESSION_FILES, () => {
        const servicesArray = [
          'accountsService',
          'appsService',
          'contactsService',
          'devicecapabilityService',
          'settingsService'
        ];
        window.libSession.initService(servicesArray).then(() => {
          SettingsObserver.init(); // SettingsObserver init
          LazyLoader.load(LAZY_LOAD_FILES, () => {
            console.time('loadreact');
          });
        });
      });
    } else {
      window.addEventListener('DOMContentLoaded', this);
    }
  },

  handleSWMessage() {
    class Emitter {
      listeners = new Map();
      data = null;

      /**
       * Registers listener function to be executed once event occurs.
       * @param {string} eventName Name of the event to listen for.
       * @param {function} handler Handler to be executed once event occurs.
       */
      on(eventName, handler) {
        let handlers = this.listeners.get(eventName);

        if (!handlers) {
          handlers = new Set();
          this.listeners.set(eventName, handlers);
        }

        // Ignores handler if it has been already registered
        handlers.add(handler);
        if (this.data) {
          this.emit(eventName, this.data);
        }
      }

      /**
       * Removes registered listener for the specified event.
       * @param {string} eventName Name of the event to remove listener for.
       * @param {function} handler Handler to remove, so it won't be executed
       * next time event occurs.
       */
      off(eventName, handler) {
        const handlers = this.listeners.get(eventName);

        if (!handlers) {
          return;
        }

        handlers.delete(handler);

        if (!handlers.size) {
          this.listeners.delete(eventName);
        }
      }

      /**
       * Removes all registered listeners for the specified event.
       * @param {string} eventName Name of the event to remove all listeners for.
       */
      offAll(eventName) {
        if ('undefined' === typeof eventName) {
          this.listeners.clear();
          return;
        }

        const handlers = this.listeners.get(eventName);

        if (!handlers) {
          return;
        }

        handlers.clear();

        this.listeners.delete(eventName);
      }

      /**
       * Emits specified event so that all registered handlers will be called
       * with the specified parameters.
       * @param {string} eventName Name of the event to call handlers for.
       * @param {Object} parameters Optional parameters that will be passed to
       * every registered handler.
       */
      emit(eventName, ...parameters) {
        const handlers = this.listeners.get(eventName);

        if (!handlers) {
          return;
        }

        handlers.forEach(handler => {
          try {
            handler(...parameters);
          } catch (e) {
            console.error(e);
          }
        });
      }
    }
    window._SWObserver = new Emitter();
    navigator.serviceWorker.addEventListener('message', ({ data }) => {
      window._SWObserver.data = data;
      window._SWObserver.emit('swMessage', data);
    });
  },

  apiInit() {
    const servicesArray = ['devicecapabilityService', 'contactsService'];
    return new Promise(resolve => {
      /* Session init */
      return window.libSession.initService(servicesArray).then(() => {
        // DeviceCapabilityManager enable.
        resolve();
      });
    });
  },

  handleEvent(evt) {
    switch (evt.type) {
      case 'DOMContentLoaded':
        window.removeEventListener('DOMContentLoaded', this);
        this.apiInit().then(() => {
          this.render();
        });
        this.bootPageKeydown = event => {
          switch (event.key) {
            case 'SoftLeft':
              this.lastPressKey = 'new';
              break;
            case 'SoftRight':
              this.lastPressKey = 'settings';
              break;
            default:
              break;
          }
        };
        window.addEventListener('keydown', this.bootPageKeydown);
        break;
      case 'fullyloaded':
        window.removeEventListener('fullyloaded', this);
        window.removeEventListener('keydown', this.bootPageKeydown);
        window.dispatchEvent(
          new CustomEvent('bootRoute', {
            detail: { action: this.lastPressKey },
          })
        );
        this.ssr.classList.add('hidden');
        break;
      default:
        break;
    }
  },

  drawPhoto(contact, canvas) {
    if (contact.photoBlob && contact.photoBlob.length) {
      const img = new Image();
      const target = 32;
      const url = URL.createObjectURL(
        new Blob([contact.photoBlob], { type: contact.photoType })
      );
      const _drawSquare = () => {
        const scalex = img.width / target;
        const scaley = img.height / target;
        const scale = Math.min(scalex, scaley);

        const l = target * scale;
        const x = (img.width - l) / 2;
        const y = (img.height - l) / 2;

        canvas.width = target;
        canvas.height = target;
        const context = canvas.getContext('2d', {
          willReadFrequently: true,
        });
        context.drawImage(img, x, y, l, l, 0, 0, target, target);
      };

      img.src = url;
      img.onload = () => {
        contact._photoImage = img;
        window.cachedContacts.push(contact);
        _drawSquare();
      };
      img.onerror = () => {
        img.src = '';
        URL.revokeObjectURL(url);
      };
    }
  },

  async render() {
    let iceDOM = '';
    // This is first launch.
    // We still need to look at the database to know if there is contact data or not.
    // Step 1: read local storage for ICE.
    // This may not be accurate, but we assume no other apps will change the ice list.
    let ice = window.localStorage.getItem('ice_contacts');
    if (ice) {
      ice = JSON.parse(ice);
      const hasIce = ice.some(c => {
        return !!c.id;
      });
      if (hasIce && window.localStorage.getItem('memory') !== 'sim') {
        this.itemSum += 1;
        iceDOM =
          '<div tabindex="-1" class="list-item"><i role="presentation" class="icon" data-icon="ice-contacts"></i><div class="content"><div class="primary"><a href="/icelist"><span data-l10n-id="ICEContactsGroup">ICE Contacts</span></a></div></div><i role="presentation" class="icon" data-icon="forward"></i></div>';
      }
    }
    // Step 2: read local storage for favorite
    // This may not be accurate,
    // but we assume no other apps will change the favorite state for contacts DB.
    let favoriteDOM = '';
    if (window.localStorage.getItem('hasFavorites')) {
      this.itemSum += 1;
      favoriteDOM =
        '<div tabindex="-1" class="list-item"><i role="presentation" class="icon icon-list" data-icon="favorite-on"></i><div class="content"><div class="primary"><a href="/favorite"><span data-l10n-id="favorite-contacts">Favorite contacts</span></a></div></div><i role="presentation" class="icon" data-icon="forward"></i></div>';
    }

    // Step 3: read local storage for group
    // This may not be accurate,
    // but we assume no other apps will change the group state for contacts DB.
    let groupDOM = '';
    if (window.localStorage.getItem('hasGroups')) {
      this.itemSum += 1;
      groupDOM =
        '<div tabindex="-1" class="list-item"><i role="presentation" class="icon icon-list" data-icon="group-contacts"></i><div class="content"><div class="primary"><a href="/group"><span data-l10n-id="group">Group</span></a></div></div><i role="presentation" class="icon" data-icon="forward"></i></div>';
    }

    // Step 4: read real contact data.
    const limit = this.PRELOAD_SIZE - this.itemSum;
    if (limit > 0) {
      console.time('loadcontact');
      let category =
        {
          phone: 'DEVICE',
          sim: 'SIM',
          kaiContact: 'KAICONTACT',
        }[window.localStorage.getItem('memory')] || 'DEVICE';
      //Porting from 11459618 xiaolei.yin add to GF5GTMO-3575 20240822 begin
      if (OperatorUtils.isVZWFamily()) {
        category = 'KAICONTACT';
      }
      //Porting from 11459618 xiaolei.yin add to GF5GTMO-3575 20240822 end

      const options = {
        sortBy:
          'familyName' === window.localStorage.getItem('sort')
            ? ContactsManager.SortOption.FAMILY_NAME
            : ContactsManager.SortOption.GIVEN_NAME,
        sortOrder: ContactsManager.Order.ASCENDING,
        sortLanguage: navigator.language,
        filterValue: category,
        filterOption: ContactsManager.FilterOption.CONTAINS,
        filterBy: [ContactsManager.FilterByOption.CATEGORY],
      };

      const rendPage = contacts => {
        if (contacts.length) {
          window.ssrHasContacts = true;
        }
        DeviceCapabilityManager.get('hardware.memory')
          .then(memOnDevice => {
            this.isLowMemoryDevice = memOnDevice <= 256;
            this.r(contacts, iceDOM, favoriteDOM, groupDOM);
          })
          .catch(err => {
            console.info('Error when detecting hardware.memory:', err);
            this.r(contacts, iceDOM, favoriteDOM, groupDOM);
          });
      };

      let accountsShow = window.localStorage.getItem('AccountsShow');
      if (accountsShow) {
        accountsShow = JSON.parse(accountsShow);
      }

      const request = await ContactsManager.find(options, limit);
      const contacts = [];
      const cursor = () => {
        request
          .next()
          .then(matches => {
            matches.some(match => {
              let bShow = true;
              if (accountsShow && match.category) {
                const index = match.category.indexOf('ACCOUNT');
                if (index > -1) {
                  bShow = accountsShow[match.category[index + 1]];
                }
              }
              if (bShow) {
                contacts.push(match);
              }
              if (contacts.length >= limit) {
                return true;
              }
            });
            if (contacts.length < limit) {
              cursor();
            } else {
              rendPage(contacts);
              request.release();
            }
          })
          .catch(() => {
            request.release();
            rendPage(contacts);
          });
      };
      cursor();
    } else {
      window.api.l10n.once(() => {
        this.r(null, iceDOM, favoriteDOM, groupDOM);
      });
    }
  },

  r(contacts, iceDOM, favoriteDOM, groupDOM) {
    let str = '';
    let searchstr = `<div class="search-container"><div data-index="0" data-type="input" tabindex="-1" class="list-item input-item focus"><div class="content"><input id="fake-search" x-inputmode="fake" placeholder="${window.api.l10n.get(
      'search'
    )}" class="navigable primary" type="text"></div></div></div>`;
    if (contacts) {
      for (let i = 0; i < contacts.length; i++) {
        str += this.template(contacts[i]);
      }
      if (!str) {
        document
          .getElementById('fake-settings-button')
          .classList.remove('hidden');
        document.getElementById('fake-new-button').classList.remove('hidden');
        str = groupDOM
          ? ''
          : '<div class="no-result primary" is="null"><div data-l10n-id="start-adding" is="null"></div></div>';
        searchstr = '';
      }
    }

    const content = this.content;
    content.innerHTML = `${searchstr}
      <div class="list-all">
        ${iceDOM}${favoriteDOM}${groupDOM}
        <div class="main-list">
          <div class="contact-list">
            <div class="list-items">
              ${str}
            </div>
          </div>
        </div>
      </div>
      `;
    const search = document.querySelector('.search-container input');
    if (search) {
      search.focus();
      search.addEventListener('input', () => {
        window._search_cache = search.value;
      });
    } else {
      this.noSearch = true;
    }
    console.timeEnd('loadcontact');

    // draw photo after canvas rendered
    //Porting from PR11031186 xiaolei.yin to GF5GTMO-3564 20240821 begin
    let skip = 0;
    !this.isLowMemoryDevice &&
      contacts &&
      contacts.forEach((c,index) => {
        if (c.photoBlob && c.photoBlob.length) {
          this.drawPhoto(c, document.querySelectorAll(`.photo canvas`)[index - skip]);
        } else {
          //skip while contact does not have custom icon but has default icon
          skip++;
        }
      });
    //Porting from PR11031186 xiaolei.yin to GF5GTMO-3564 20240821 end
    this.load();
  },

  load() {
    LazyLoader.load(SESSION_FILES, () => {
      const servicesArray = [
        'settingsService',
        'accountsService',
        'appsService',
      ];
      window.libSession.initService(servicesArray).then(() => {
        SettingsObserver.init(); // SettingsObserver init
      });
    });
    window.performance && window.performance.mark('visuallyLoaded');
    window.requestAnimationFrame(() => {
      const DELAY = !this.noSearch ? 500 : 0;
      setTimeout(() => {
        LazyLoader.load(LAZY_LOAD_FILES, () => {
          console.time('loadreact');
        });
      }, DELAY);
    });
  },
};

PreloadApp.init();
