import createHistory from 'history/createHashHistory';
import React from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import Service from 'service';
import BaseComponent from 'base-component';
import Router from './router';

export default class ReactWindowManager extends BaseComponent {
  name = 'ReactWindowManager';
  DEBUG = false;

  static defaultProps = {
    routes: [],
    pushCloseAnimation: 'center-to-left',
    popOpenAnimation: 'left-to-center'
  };

  static propTypes = {
    routes: PropTypes.array,
    popAnimation: PropTypes.string,
    backAnimation: PropTypes.string
  };

  constructor(props) {
    super(props);
    this.state = {
      panels: [],
      activeRef: '',
      action: ''
    };
    // Avoid chaos the state, we put the parent ref out of state.
    this.parentRefs = {};
    this.requestQueue = [];
  }
  componentWillUpdate(nextProps, nextState) {
    if (!this.state.activeRef ||
        nextState.activeRef === this.state.activeRef) {
      return;
    }
    let animation = null;
    for (let ref in this.refs) {
      let panel = this.refs[ref];
      if (ref === this.state.activeRef) {
        switch (nextState.action) {
          case 'PUSH':
            animation = panel.isTransitioning() ? '' : this.props.pushCloseAnimation;
            break;
          case 'REPLACE':
            animation = 'immediate';
            break;
          case 'POP':
            // do nothing
            break;
          case 'POPUP':
            // Don't close current panel
            return;
          case 'RECYCLE':
            return;
          default:
            break;
        }
        if (panel.close) {
          panel.on('closed', () => {
            this.recycleUnusedPanels();
          });
          panel.close(animation);
        } else {
          panel.hide && panel.hide();
        }
        break;
      }
    }
  }
  componentDidUpdate() {
    this.debug('did update: activeRef, action:', this.state.activeRef, this.state.action);
    let animation = '';
    for (let ref in this.refs) {
      let panel = this.refs[ref];
      if (ref === this.state.activeRef) {
        // Override animation per action.
        switch (this.state.action) {
          case 'POP':
            animation = panel.isTransitioning() ? '' : this.props.popOpenAnimation;
            break;
          case 'PUSH':
            break;
          case 'POPUP':
            animation = 'bottom-to-up';
            break;
          case 'REPLACE':
            animation = 'immediate';
            break;
          case 'RECYCLE':
            return;
          default:
            break;
        }
        if (1 === this.state.panels.length) {
          animation = 'immediate';
        }
        if (panel.open) {
          panel.open(animation);
        } else {
          panel.show && panel.show();
        }
        break;
      }
    }
  }
  updatePanels() {
    this.debug('updatePanels:');
    let location = this.history.location;
    let action = this.history.action;
    Router.resolve(this.props.routes, location).then((component) => {
      // Update parent ref
      if (action !== 'REPLACE') {
        if (this.state.activeRef && component.ref !== this.state.activeRef) {
          this.parentRefs[component.ref] = this.state.activeRef;
        }
      } else if (this.state.activeRef) {
        // current parent is next panel's parent
        let parentRef = this.parentRefs[this.state.activeRef];
        if (parentRef) {
          this.parentRefs[component.ref] = parentRef;
        }
      }
      // Seek for existing component
      for (let ref in this.refs) {
        if (component.ref === ref) {
          let id = -1;
          this.state.panels.some((panel, index) => {
            if (panel.ref === component.ref) {
              id = index;
              return true;
            } else {
              return false;
            }
          });
          this.state.panels[id] = component;
          let state = {
            panels: this.state.panels,
            activeRef: component.ref,
            action: action
          };
          this.setState(state);
          return;
        }
      }
      let state = {
        panels: this.state.panels.concat([component]),
        activeRef: component.ref,
        action: action
      };
      this.setState(state);
    }); // XXX: need catch
  }
  hasChildPanel(ref) {
    for (let child in this.parentRefs) {
      if (ref === this.parentRefs[child]) {
        return true;
      }
    }
    return false;
  }
  recycleUnusedPanels() {
    this.debug('recycleUnusedPanels: activeRef:', this.state.activeRef);
    let refsToRemove = [];
    for (let ref in this.refs) {
      let instance = this.refs[ref];
      this.debug('try to remove:', instance.name);
      if (!this.hasChildPanel(ref) && instance.isClosed()) {
        refsToRemove.push(ref);
        delete this.parentRefs[ref];
      }
    }
    let panels = this.state.panels.filter((panel) => {
      if (refsToRemove.indexOf(panel.ref) >= 0) {
        return false;
      } else {
        return true;
      }
    });
    this.setState({
      panels: panels,
      action: 'RECYCLE'
    });
  }
  componentDidMount() {
    this.debug('did mount');
    const history = createHistory();
    this.history = history;

    history.listen((location, action) => {
      switch (action) {
        case 'PUSH':
          this.updatePanels();
          break;
        case 'POP':
          if (this.state.panels.length <= 1) {
            return;
          }
          Router.resolve(this.props.routes, this.history.location).then((component) => {
            // Seek for existing component
            for (let ref in this.refs) {
              if (component.ref === ref) {
                this.setState({
                  activeRef: component.ref,
                  action: action
                });
                return;
              }
            }
          });
          break;
        case 'REPLACE':
          this.updatePanels();
          break;
        default:
          break;
      }
    });
    Service.register('popup', this);
    Service.register('focus', this);
    Service.register('back', this);
    Service.register('push', this);
    Service.register('replace', this);
    Service.registerState('isTransitioning', this);
    Service.registerState('canGoBack', this);
    this.router = Router;
    this.updatePanels();
  }

  isTransitioning() {
    const result = Object.values(this.refs).some((panel) => {
      this.debug('check isTransitioning:', panel.name);
      return panel.isTransitioning();
    });
    this.debug('isTransitioning:', result);
    return result;
  }

  popup(url, data) {
    this.debug('popup: url, data:', url, data);
    return new Promise((resolve) => {
      let location = { pathname: url, search: '', hash: '', state: undefined, key: undefined };
      // Popup will not affect history
      Router.resolve(this.props.routes, location).then((component) => {
        this.requestQueue.push(resolve);
        this.refs[this.state.activeRef].openPopup(React.cloneElement(component, data));
      }).catch((e) => console.error(e)); // XXX: need catch
    }).catch((e) => console.error(e));
  }
  canGoBack() {
    let ref = this.state.activeRef;
    let activePanel = this.refs[ref];
    if (!activePanel) {
      // XXX: Do window.close()
      return false;
    }
    let topMostPanel = activePanel.getTopMost();
    if (topMostPanel !== activePanel && !topMostPanel.isTransitioning()) {
      return true;
    }
    return this.history.length > 1;
  }
  back(...args) {
    this.debug('back:');
    let ref = this.state.activeRef;
    let activePanel = this.refs[ref];
    let request = null;
    if (this.requestQueue.length) {
      request = this.requestQueue.splice(this.requestQueue.length - 1, 1);
      request = request[0];
    }
    if (!activePanel) {
      // XXX: Do window.close()
    }
    let topMostPanel = activePanel.getTopMost();
    if (topMostPanel !== activePanel && !topMostPanel.isTransitioning()) {
      // Will not trigger history change
      topMostPanel.close('up-to-bottom');
      activePanel.focus();
    } else {
      // Trigger history change
      this.history.goBack();
    }
    if (request) {
      // Promise resolve only take 1st argument so we don't spread it.
      request(args);
    }
  }
  focus() {
    for (let ref in this.refs) {
      let panel = this.refs[ref];
      if (ref === this.state.activeRef) {
        let topMostPanel = panel.getTopMost();
        if (!topMostPanel.isTransitioning()) {
          panel = topMostPanel;
        }
        if (panel.focus) {
          panel.focus();
        } else {
          ReactDOM.findDOMNode(panel).focus();
        }
        break;
      }
    }
  }
  // Helper for history.push()
  push(url, data = {}) {
    this.debug('push: url, data:', url, data);
    return new Promise((resolve) => {
      this.requestQueue.push(resolve);
      this.history.push({
        pathname: url,
        search: JSON.stringify(data)
      });
    }).catch((e) => console.error(e));
  }
  replace(url, data) {
    this.history.replace(url, data);
  }
  render() {
    let panels = this.state.panels.map((panel) => {
      return React.cloneElement(panel, {
        ref: panel.ref, key: panel.ref, exitOnClose: panel.props ? panel.props.exitOnClose : false
      });
    });
    return (
      <div className="app-content">
        {panels}
      </div>
    );
  }
}
