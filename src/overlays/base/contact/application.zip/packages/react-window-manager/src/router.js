import toRegex from 'path-to-regexp';

function matchURI(path, uri) {
  const keys = [];
  const pattern = toRegex(path, keys); // TODO: Use caching
  const match = pattern.exec(uri);
  if (!match) return null;
  const params = Object.create(null);
  for (let i = 1; i < match.length; i++) {
    params[keys[i - 1].name] =
      match[i] !== undefined ? match[i] : undefined;
  }
  return params;
}

function resolve(routes, context) {
  console.info('[ReactWindowManager][Router] try to resolve: context:', context);
  return new Promise((resolvePromise, rejectPromise) => {
    for (let i = 0; i < routes.length; i++) {
      let route = routes[i];
      const uri = context.error ? '/error' : context.pathname;
      let params = matchURI(route.path, uri);
      if (!params) {
        continue;
      }
      const data = context.search ? JSON.parse(decodeURI(context.search).replace('?', '')) : {};
      Object.assign(params, data);
      console.info('[ReactWindowManager][Router] before resolving: params:', params);
      resolvePromise(route.action(params));
      return;
    }
    rejectPromise('not found');
  });
}
export default { resolve };
