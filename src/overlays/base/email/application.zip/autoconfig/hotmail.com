<clientConfig version="1.1">
  <emailProvider id="hotmail.com">
    <domain>hotmail.com</domain>
    <domain>hotmail.co.uk</domain>
    <domain>hotmail.co.jp</domain>
    <domain>hotmail.com.br</domain>
    <domain>hotmail.de</domain>
    <domain>hotmail.fr</domain>
    <domain>hotmail.it</domain>
    <domain>hotmail.es</domain>
    <domain>live.com</domain>
    <domain>live.co.uk</domain>
    <domain>live.co.jp</domain>
    <domain>live.de</domain>
    <domain>live.fr</domain>
    <domain>live.it</domain>
    <domain>live.jp</domain>
    <domain>msn.com</domain>
    <domain>outlook.com</domain>
    <displayName>Microsoft Live Hotmail</displayName>
    <displayShortName>Hotmail</displayShortName>
    <incomingServer type="imap">
      <hostname>imap-mail.outlook.com</hostname>
      <port>993</port>
      <socketType>SSL</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>xoauth2</authentication>
    </incomingServer>
    <outgoingServer type="smtp">
      <hostname>smtp-mail.outlook.com</hostname>
      <port>587</port>
      <socketType>STARTTLS</socketType>
      <username>%EMAILADDRESS%</username>
      <authentication>xoauth2</authentication>
    </outgoingServer>
    <oauth2Settings>
      <secretGroup>microsoft</secretGroup>
      <authEndpoint>https://login.microsoftonline.com/common/oauth2/v2.0/authorize</authEndpoint>
      <tokenEndpoint>https://login.microsoftonline.com/common/oauth2/v2.0/token</tokenEndpoint>
      <scope>offline_access https://outlook.office.com/IMAP.AccessAsUser.All https://outlook.office.com/SMTP.Send</scope>
    </oauth2Settings>
  </emailProvider>
</clientConfig>
