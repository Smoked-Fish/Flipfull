define('tmpl!cards/cmp/attachment_item.html', ['tmpl'], function (tmpl) {
    return tmpl.toDom('<li class="cmp-attachment-item cmp-attachment-focusable">\n  <span class="cmp-attachment-icon" role="presentation"></span>\n  <span class="cmp-attachment-fileinfo">\n    <span dir="auto" class="cmp-attachment-filename p-pri"></span>\n    <span class="cmp-attachment-filesize p-pri"></span>\n  </span>\n</li>');
});
define('tmpl!cards/cmp/peep_bubble.html', ['tmpl'], function (tmpl) {
    return tmpl.toDom('<div class="cmp-peep-bubble peep-bubble" dir="auto" role="button">\n  <span class="cmp-peep-name"></span>\n  <span class="cmp-peep-address collapsed"></span>\n</div>\n');
});
define('tmpl!cards/cmp/suggestion_item.html', ['tmpl'], function (tmpl) {
    return tmpl.toDom('<li class="suggestion-item" role="presentation">\r\n  <a class="suggestion" role="option" data-email="{{email}}" data-source="contacts" data-name="{{name}}">\r\n    <p class="name"><bdi class="ellipsis-dir-fix p-pri">{{name}}</bdi></p>\r\n    <p class="email">\r\n        <span class="description p-pri">{{type}}, </span>\r\n        <span class="email-detail p-pri">{{email}}</span>\r\n    </p>\r\n  </a>\r\n</li>\r\n');
});
define('mime_to_class', [], function () {
    return function mimeToClass(mimeType) {
        mimeType = mimeType || '';
        return 'mime-' + (mimeType.split('/')[0] || '');
    };
});
define('file_display', [
    'require',
    'l10n!'
], function (require) {
    var mozL10n = require('l10n!');
    const kbSize = 1024;
    return {
        fileSize: function (node, sizeInBytes) {
            var fileSize;
            var unitName;
            var fileInfo = {};
            if (sizeInBytes >= kbSize * kbSize) {
                fileSize = parseFloat(sizeInBytes / kbSize / kbSize).toFixed(1);
                fileInfo = { megabytes: fileSize };
                unitName = 'attachment-size-meb';
            } else if (sizeInBytes < kbSize) {
                fileInfo = { bytes: sizeInBytes };
                unitName = 'attachment-size-byte';
            } else {
                fileSize = parseFloat(sizeInBytes / kbSize).toFixed(1);
                fileInfo = { kilobytes: fileSize };
                unitName = 'attachment-size-kib';
            }
            mozL10n.setAttributes(node, unitName, fileInfo);
        }
    };
});
define('contacts', ['require'], function (require) {
    let filterFns = {
        contains: function (a, b) {
            a = a.toLowerCase();
            b = b.toLowerCase();
            return a.contains(b);
        },
        equality: function (a, b) {
            a = a.toLowerCase();
            b = b.toLowerCase();
            return a === b;
        }
    };
    function isMatch(contact, criteria, filterFn) {
        let found = {};
        outer:
            for (let i = 0, ilen = criteria.terms.length; i < ilen; i++) {
                let term = criteria.terms[i];
                for (let j = 0, jlen = criteria.fields.length; j < jlen; j++) {
                    let field = criteria.fields[j];
                    if (!contact[field]) {
                        continue;
                    }
                    for (let k = 0, klen = contact[field].length; k < klen; k++) {
                        let value = contact[field][k];
                        if (typeof value.value !== 'undefined') {
                            value = value.value;
                        }
                        if (found[term] = filterFn(value.trim(), term)) {
                            continue outer;
                        }
                    }
                }
            }
        return Object.keys(found).every(function (key) {
            return found[key];
        });
    }
    let Contacts = {
        rspaces: /\s+/,
        getCount: function () {
            return new Promise(resolver => {
                ContactsManager.getCount().then(result => {
                    resolver(result);
                });
            });
        },
        cursorNext: function (cursor, resultList, lower, terms, callback, insertNode) {
            cursor.next().then(result => {
                let contacts = result.slice();
                let fields = [
                    'email',
                    'givenName',
                    'familyName'
                ];
                let criteria = {
                    fields: fields,
                    terms: lower
                };
                let contact;
                if (terms.length > 1) {
                    while (contact = contacts.pop()) {
                        if (isMatch(contact, criteria, filterFns.contains)) {
                            resultList.push(contact);
                        }
                    }
                } else {
                    resultList = resultList.concat(contacts);
                }
                if (contacts && contacts.length) {
                    this.cursorNext(cursor, resultList, lower, terms, callback, insertNode);
                }
            }).catch(error => {
                console.log('error is:' + JSON.stringify(error));
                callback(resultList, { terms: terms }, insertNode);
                cursor.release();
            });
        },
        findContactByString: function (filterValue, insertNode, callback) {
            let props = [
                ContactsManager.FilterByOption.EMAIL,
                ContactsManager.FilterByOption.GIVEN_NAME,
                ContactsManager.FilterByOption.FAMILY_NAME
            ];
            return this.findBy({
                filterBy: props,
                filterOption: ContactsManager.FilterOption.CONTAINS,
                filterValue: filterValue
            }, insertNode, callback);
        },
        findBy: function (filter, insertNode, callback) {
            let lower = [];
            let filterValue = (filter.filterValue || '').trim();
            let terms, request;
            if (!ContactsManager || !filterValue.length) {
                setTimeout(() => {
                    callback(typeof filter.filterValue === 'undefined' ? null : [], {}, insertNode);
                });
                return;
            }
            terms = filterValue.split(this.rspaces);
            filter.filterValue = terms.length === 1 ? terms[0] : terms.reduce((initial, term) => {
                lower.push(term.toLowerCase());
                return term.length > initial.length ? term : initial;
            }, '');
            lower.splice(lower.indexOf(filter.filterValue.toLowerCase()), 1);
            lower.push.apply(lower, terms);
            request = ContactsManager.find(filter, 1);
            request.then(cursor => {
                let resultList = [];
                this.cursorNext(cursor, resultList, lower, terms, callback, insertNode);
            }, error => {
                callback([]);
            });
        },
        isContactData: function (data) {
            return new Promise(resolve => {
                let filter = {
                    filterBy: [
                        ContactsManager.FilterByOption.EMAIL,
                        ContactsManager.FilterByOption.TEL
                    ],
                    filterValue: data,
                    filterOption: ContactsManager.FilterOption.CONTAINS
                };
                let request = ContactsManager.find(filter, 1);
                request.then(cursor => {
                    cursor.next().then(result => {
                        if (result.length > 0) {
                            let contactId = result[0].id;
                            resolve(contactId);
                        } else {
                            resolve();
                        }
                        cursor.release();
                    }).catch(error => {
                        resolve();
                        cursor.release();
                    });
                }, error => {
                    console.log('find contact error!');
                });
            });
        }
    };
    return Contacts;
});
define('template!cards/compose.html', ['template'], function (template) {
    return {
        createdCallback: template.templateCreatedCallback,
        template: template.objToFn({
            'id': 'cards/compose.html',
            'deps': [],
            'text': '<section class="cmp-compose-header" role="region" data-statuscolor="default">\n  <header data-prop="headerNode">\n    <h1 id="compose-header" class="cmp-compose-header-label" data-prop="cmpTitle"></h1>\n  </header>\n</section>\n<div data-prop="scrollContainer" class="scrollregion-below-header"\n     role="heading" aria-labelledby="compose-header">\n  <div data-prop="addrBar" class="cmp-envelope-bar">\n    <div class="cmp-addr-bar">\n      <div data-event="keydown:onContainerKeydown"\n           class="cmp-envelope-line cmp-combo focusable"\n           role="textbox" data-prop="cmp_to">\n        <span class="cmp-to-label cmp-addr-label"\n              data-l10n-id="compose-to" aria-hidden="false"></span>\n        <div class="cmp-to-container cmp-addr-container">\n          <div class="cmp-bubble-container" data-prop="toContainer">\n              <input data-prop="toNode"\n                     data-event="keydown:onAddressKeydown,input:onAddressInput,focus:onAddressFocus"\n                     dir="auto" maxlength="255"\n                     class="cmp-to-text cmp-addr-text" type="text" />\n          </div>\n        </div>\n      </div>\n      <!-- XXX: spec calls for showing cc/bcc merged until selected,\n           but there is also the case where replying itself might need\n           to expand, so we are deferring that feature -->\n      <div data-event="keydown:onContainerKeydown"\n           class="cmp-envelope-line cmp-combo collapsed"\n           role="textbox" data-l10n-id="cc-group" data-prop="cmp_cc">\n        <span class="cmp-cc-label cmp-addr-label"\n               data-l10n-id="compose-cc" aria-hidden="true"></span>\n        <div class="cmp-cc-container cmp-addr-container">\n          <div class="cmp-bubble-container" data-prop="ccContainer">\n            <input data-prop="ccNode"\n                   data-event="keydown:onAddressKeydown,input:onAddressInput,focus:onAddressFocus"\n                   dir="auto" maxlength="255"\n                   class="cmp-cc-text cmp-addr-text" type="text" />\n          </div>\n        </div>\n      </div>\n      <div data-event="keydown:onContainerKeydown"\n           class="cmp-envelope-line cmp-combo collapsed"\n           role="textbox" data-l10n-id="bcc-group" data-prop="cmp_bcc">\n        <span class="cmp-bcc-label cmp-addr-label"\n               data-l10n-id="compose-bcc" aria-hidden="true"></span>\n        <div class="cmp-bcc-container cmp-addr-container">\n          <div class="cmp-bubble-container" data-prop="bccContainer">\n            <input data-prop="bccNode"\n                   data-event="keydown:onAddressKeydown,input:onAddressInput,focus:onAddressFocus"\n                   dir="auto" maxlength="255"\n                   class="cmp-bcc-text cmp-addr-text" type="text" />\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class="cmp-envelope-line cmp-subject focusable">\n      <span class="cmp-subject-label"\n            data-l10n-id="compose-subject" aria-hidden="true"></span>\n      <input data-prop="subjectNode"\n             data-event="keydown:onSubjectKeydown"\n             dir="auto" maxlength="255"\n             class="cmp-subject-text" type="text" data-l10n-id="subject" />\n    </div>\n    <div data-prop="errorMessage" class="cmp-error-message collapsed"></div>\n    <div data-prop="loadingAttachments" class="cmp-loading-attachments collapsed">\n      <span data-prop="loadingAttachmentsInfo"\n            class="cmp-loading-progress p-pri"\n            data-l10n-id="compose-attachment-loading"></span>\n      <progress></progress>\n    </div>\n    <div data-prop="attachmentTotal"\n         class="cmp-envelope-line cmp-attachment-total collapsed"\n         data-event="click:goAttachmentsList">\n      <span data-prop="attachmentLabel"\n            class="cmp-attachment-label cmp-addr-label p-sec"></span>\n      <span class="cmp-attachment-info">\n        <span data-prop="attachmentsName" class="cmp-attachment-name p-pri"></span>\n        <span data-prop="attachmentsSize" class="cmp-attachment-size p-pri"></span>\n      </span>\n    </div>\n    <div data-prop="attachmentsContainer" class="cmp-attachment-container collapsed">\n    </div>\n    <div> </div>\n  </div>\n  <li class="cmp-body-li focusable">\n    <div data-prop="textBodyNode" class="cmp-body-text p-pri"\n         contenteditable="true" role="textbox" aria-multiline="true"\n         x-inputmode="kai-editor"\n         data-l10n-id="compose-text" data-event="keydown:onBodyNodeKeydown"></div>\n  </li>\n  <div data-prop="htmlBodyContainer"\n       dir="auto"\n       class="cmp-body-html collapsed"\n       data-l10n-id="message-body-container">\n  </div>\n  <section id="suggestionsContainer" class="email-suggestion"\n           data-type="list" data-prop="suggestionsContainer">\n    <ul data-prop="suggestionsList" class="contact-list contact-suggestions-list"\n        role="listbox">\n    </ul>\n  </section>\n</div>\n'
        })
    };
});
define('cards/compose', [
    'require',
    'exports',
    'module',
    'tmpl!./cmp/attachment_item.html',
    'tmpl!./cmp/peep_bubble.html',
    'tmpl!./cmp/suggestion_item.html',
    'evt',
    'html_cache',
    'toaster',
    'model',
    'iframe_shims',
    'l10n!',
    'cards',
    'mime_to_class',
    'file_display',
    'contacts',
    './base',
    'template!./compose.html',
    './editor_mixins'
], function (require, exports, module) {
    let cmpAttachmentItemNode = require('tmpl!./cmp/attachment_item.html'), cmpPeepBubbleNode = require('tmpl!./cmp/peep_bubble.html'), suggestionItem = require('tmpl!./cmp/suggestion_item.html'), evt = require('evt'), htmlCache = require('html_cache'), toaster = require('toaster'), model = require('model'), iframeShims = require('iframe_shims'), mozL10n = require('l10n!'), cards = require('cards'), mimeToClass = require('mime_to_class'), fileDisplay = require('file_display'), Contacts = require('contacts'), dataIdCounter = 0;
    const MAX_ATTACHMENT_SIZE = 5 * 1024 * 1024;
    function focusInputAndPositionCursorFromContainerClick(event, input) {
        if (event.explicitOriginalTarget === input) {
            return;
        }
        event.stopPropagation();
        let bounds = input.getBoundingClientRect();
        let midX = bounds.left + bounds.width / 2;
        input.focus();
        let cursorPos = 0;
        if (event.clientX >= midX) {
            cursorPos = input.value.length;
        }
        input.setSelectionRange(cursorPos, cursorPos);
    }
    return [
        require('./base')(require('template!./compose.html')),
        require('./editor_mixins'),
        {
            createdCallback: function () {
                htmlCache.cloneAndSave(module.id, this);
                this.sending = false;
                this.doActive = true;
                this.needRefresh = false;
                this.suggestionList = false;
                this.suggestionListNavListener = false;
                this.focusTo = null;
                this.cmp_params = null;
                this._totalAttachmentsFinishing = 0;
                this._totalAttachmentsDone = 0;
                this._wantAttachment = false;
                this._onAttachmentDone = this._onAttachmentDone.bind(this);
                this._bindEditor(this.textBodyNode);
                let subjectContainer = this.querySelector('.cmp-subject');
                subjectContainer.addEventListener('click', evt => {
                    focusInputAndPositionCursorFromContainerClick(evt, subjectContainer.querySelector('input'));
                });
                this._selfClosed = false;
                let dataId = module.id + '-' + (dataIdCounter += 1);
                this._dataIdSaveDraft = dataId + '-saveDraft';
                this._dataIdSendEmail = dataId + '-sendEmail';
                this.addWhich = 'to';
                this.handBodyContainerKeydown = this.handBodyContainerKeydown.bind(this);
                this.needResetFocus = false;
                this.resetFocus = this.resetFocus.bind(this);
                window.addEventListener('gaia-confirm-close', this.resetFocus);
                this.draftEmailObj = { body: {} };
                cards.showActivityDraftToast();
                cards.saveActivityComposeDraft();
                this.activitySaveDraft = this.activitySaveDraft.bind(this);
                document.addEventListener('visibilitychange', this.activitySaveDraft);
            },
            onArgs: function (args) {
                this.composer = args.composer;
                this.composerData = args.composerData || {};
                this.type = args.type;
                this.activity = args.activity;
                this.forwardAttachments = args.forwardAttachments || null;
                this.unDownloadFilesSize = args.unDownloadFilesSize || 0;
                this.attachFilesSize = args.filesSize || 0;
                this.updateTitle(args);
                if (this.type && this.type === 'reply') {
                    this.toNode.classList.add('collapsed');
                    this.ccNode.classList.add('collapsed');
                    this.bccNode.classList.add('collapsed');
                }
            },
            updateTitle: function (args) {
                if (args.title) {
                    mozL10n.setAttributes(this.cmpTitle, args.title);
                } else {
                    mozL10n.setAttributes(this.cmpTitle, 'compose-header-short');
                }
            },
            handleMenu: function (evt) {
                let action = evt.detail.menuVisible;
                if (action === false) {
                    setTimeout(() => {
                        this.refresh();
                    });
                }
            },
            changeFocus: function (isSetFocus, classNameStr) {
                let parentNode = null;
                let inputNode = null;
                switch (this.addWhich) {
                case 'to':
                    parentNode = this.cmp_to;
                    inputNode = this.cmp_to.querySelector('.cmp-addr-text');
                    break;
                case 'cc':
                    parentNode = this.cmp_cc;
                    inputNode = this.cmp_cc.querySelector('.cmp-addr-text');
                    break;
                case 'bcc':
                    parentNode = this.cmp_bcc;
                    inputNode = this.cmp_bcc.querySelector('.cmp-addr-text');
                    break;
                }
                if (!parentNode || !inputNode) {
                    return;
                }
                if (isSetFocus) {
                    parentNode.classList.add(classNameStr);
                    inputNode.focus();
                } else {
                    parentNode.classList.remove(classNameStr);
                    inputNode.blur();
                }
            },
            handleKeydown: function (evt) {
                switch (evt.key) {
                case 'Backspace':
                    evt.preventDefault();
                    let addClassName = this.inEditMode ? 'edit-mode' : 'focus';
                    if (this.suggestionsList.children.length !== 0) {
                        let selected = this.suggestionsList.querySelector('.selected');
                        if (selected) {
                            this.changeFocus(true, addClassName);
                            return;
                        }
                    }
                    if (!option.menuVisible) {
                        if (NavigationMap.configDialogShown()) {
                            this.hideDialog();
                            NavigationMap.restoreFocus();
                        } else {
                            this.onBack();
                        }
                    }
                    break;
                }
            },
            handleEndkey: function (evt) {
                let callback = evt.detail.callback;
                if (option.menuVisible) {
                    option.hideMenu();
                }
                this.onBack(callback);
            },
            onCardVisible: function (navDirection) {
                let CARD_NAME = this.localName;
                let QUERY_CHILD = '.focusable';
                let CONTROL_ID = CARD_NAME + ' ' + QUERY_CHILD;
                let source = this.activity ? this.activity.source : null;
                this.menuHandler = this.handleMenu.bind(this);
                window.addEventListener('menuEvent', this.menuHandler);
                this.keydownHandler = this.handleKeydown.bind(this);
                window.addEventListener('keydown', this.keydownHandler);
                this.endkeyHandler = this.handleEndkey.bind(this);
                window.addEventListener('email-endkey', this.endkeyHandler);
                NavigationMap.cardContentHeight = this.scrollContainer.clientHeight;
                if (navDirection === 'forward') {
                    NavigationMap.navSetup(CARD_NAME, QUERY_CHILD);
                    NavigationMap.setCurrentControl(CONTROL_ID);
                    if (this.type && this.type === 'reply' || source && source.data && Object.keys(source.data).length) {
                        if (this.htmlBodyContainer.classList.contains('collapsed')) {
                            NavigationMap.setFocus('last');
                        } else {
                            let length = NavigationMap.getCurrentControl().elements.length;
                            NavigationMap.setFocus(length - 2);
                        }
                        this.textBodyNode.focus();
                    } else if (!NavigationMap.configDialogShown()) {
                        NavigationMap.setFocus('first');
                    } else {
                        this.needResetFocus = true;
                    }
                } else if (navDirection === 'back') {
                    NavigationMap.setCurrentControl(CONTROL_ID);
                    NavigationMap.setFocus('restore');
                }
                this.cmp_to.addEventListener('focus', () => {
                    this.toNode.focus();
                    if (this.toContainer.children.length > 1) {
                        NavigationMap.horizontal = '.cmp-to-container';
                        NavigationMap.navSetup(this.localName, '.focusable');
                    }
                    this.toNode.setSelectionRange(this.toNode.value.length, this.toNode.value.length);
                });
                this.cmp_cc.addEventListener('focus', () => {
                    this.ccNode.focus();
                    if (this.ccContainer.children.length > 1) {
                        NavigationMap.horizontal = '.cmp-cc-container';
                        NavigationMap.navSetup(this.localName, '.focusable');
                    }
                    this.ccNode.setSelectionRange(this.ccNode.value.length, this.ccNode.value.length);
                });
                this.cmp_bcc.addEventListener('focus', () => {
                    this.bccNode.focus();
                    if (this.bccContainer.children.length > 1) {
                        NavigationMap.horizontal = '.cmp-bcc-container';
                        NavigationMap.navSetup(this.localName, '.focusable');
                    }
                    this.bccNode.setSelectionRange(this.bccNode.value.length, this.bccNode.value.length);
                });
                let cmpBodyLi = document.querySelector('.cmp-body-li');
                cmpBodyLi.addEventListener('focus', () => {
                    this.textBodyNode.focus();
                });
                NavigationMap.checkStorage();
                document.execCommand('defaultParagraphSeparator', false, 'br');
            },
            onFocusChanged: function (queryChild, index, item) {
                console.log(this.localName + '.onFocusChanged, queryChild=' + queryChild + ', index=' + index);
                if (this.addATTActivity && this.addATTActivity.readyState === 'pending') {
                    this.addATTActivity = null;
                    return;
                }
                if (item && item.classList.contains('cmp-combo')) {
                    let inputItem = item.lastElementChild.lastElementChild.lastElementChild;
                    if (inputItem && inputItem.classList.contains('collapsed')) {
                        inputItem.classList.remove('collapsed');
                    }
                }
                this.updateSoftkey();
            },
            updateSoftkey: function () {
                let params = [];
                let focused = document.querySelector('.focus') || NavigationMap.getCurrentItem();
                if (focused.classList.contains('cmp-body-li')) {
                    params.push({
                        name: 'Enter',
                        l10nId: 'enter',
                        priority: 2
                    });
                } else if (focused.classList.contains('cmp-attachment-total')) {
                    params.push({
                        name: 'Select',
                        l10nId: 'select',
                        priority: 2
                    });
                }
                if (focused.classList.contains('cmp-combo')) {
                    focused.querySelector('.cmp-addr-text').focus();
                    params.push({
                        name: 'Add Contact',
                        l10nId: 'add-contact',
                        priority: 3,
                        method: () => {
                            this.onContactAdd();
                        }
                    });
                } else {
                    if (focused.classList.contains('cmp-subject')) {
                        focused.querySelector('input').focus();
                    }
                    params.push({
                        name: 'Add Attachment',
                        l10nId: 'add-attachment',
                        priority: 5,
                        method: () => {
                            this.onAttachmentAdd();
                        }
                    });
                    if (this.cmp_cc.classList.contains('collapsed')) {
                        params.push({
                            name: 'Add Cc',
                            l10nId: 'add-cc',
                            priority: 5,
                            method: () => {
                                this.onccAdd();
                            }
                        });
                    } else {
                        params.push({
                            name: 'Remove Cc',
                            l10nId: 'remove-cc',
                            priority: 5,
                            method: () => {
                                this.onccRemove();
                            }
                        });
                    }
                    if (this.cmp_bcc.classList.contains('collapsed')) {
                        params.push({
                            name: 'Add Bcc',
                            l10nId: 'add-bcc',
                            priority: 5,
                            method: () => {
                                this.onbccAdd();
                            }
                        });
                    } else {
                        params.push({
                            name: 'Remove Bcc',
                            l10nId: 'remove-bcc',
                            priority: 5,
                            method: () => {
                                this.onbccRemove();
                            }
                        });
                    }
                    params.push({
                        name: 'Save As Draft',
                        l10nId: 'save-as-draft',
                        priority: 5,
                        method: () => {
                            this._saveDraft('explicit', () => {
                                this.goBack();
                            });
                            toaster.toast({ text: mozL10n.get('composer-draft-saved') });
                        }
                    });
                    params.push({
                        name: 'Cancel',
                        l10nId: 'cancel',
                        priority: 5,
                        method: () => {
                            this.onBack();
                        }
                    });
                }
                this.cmp_params = params;
                this.setSoftkey();
            },
            setSoftkey: function () {
                let params = [];
                if (this.needSendKey) {
                    params.push({
                        name: 'Send',
                        l10nId: 'compose-send',
                        priority: 1,
                        method: () => {
                            this.onSend();
                        }
                    });
                }
                if (this.cmp_params) {
                    NavigationMap.setSoftKeyBar(params.concat(this.cmp_params));
                }
            },
            switchSKtoSuggetion: function () {
                let params = [];
                params.push({
                    name: 'Select',
                    l10nId: 'select',
                    priority: 2,
                    method: () => {
                        let node = this.suggestionsList.querySelector('.selected');
                        node.click();
                    }
                });
                NavigationMap.setSoftKeyBar(params);
            },
            skipEmitContentEvents: true,
            _focusEditorWithCursorAtEnd: function (event) {
                if (event) {
                    event.stopPropagation();
                }
                let insertAfter = this.textBodyNode.lastChild;
                let range = document.createRange();
                range.setStartAfter(insertAfter);
                range.setEndAfter(insertAfter);
                this.textBodyNode.focus();
                let selection = window.getSelection();
                selection.removeAllRanges();
                selection.addRange(range);
            },
            postInsert: function () {
                require(['iframe_shims'], () => {
                    if (this.composer) {
                        this._loadStateFromComposer();
                    } else {
                        let data = this.composerData;
                        model.latestOnce('folder', folder => {
                            this.composer = model.api.beginMessageComposition(data.message, folder, data.options, () => {
                                if (data.onComposer) {
                                    data.onComposer(this.composer, this);
                                }
                                this._loadStateFromComposer();
                            });
                        });
                    }
                });
            },
            _loadStateFromComposer: function () {
                let self = this;
                function expandAddresses(node, addresses) {
                    if (!addresses) {
                        return '';
                    }
                    addresses.forEach(aval => {
                        let name, address;
                        if (typeof aval === 'string') {
                            if (self.activity) {
                                Contacts.findContactByString(aval, null, contacts => {
                                    if (contacts.length) {
                                        name = contacts[0].name ? contacts[0].name : aval;
                                        address = aval;
                                    } else {
                                        name = address = aval;
                                    }
                                    self.insertBubble(node, name, address);
                                });
                            } else {
                                name = address = aval;
                                self.insertBubble(node, name, address);
                            }
                        } else {
                            name = aval.name;
                            address = aval.address;
                            self.insertBubble(node, name, address);
                        }
                    });
                }
                expandAddresses(this.toNode, this.composer.to);
                expandAddresses(this.ccNode, this.composer.cc);
                if (this.composer.cc && this.composer.cc.length > 0) {
                    this.cmp_cc.classList.remove('collapsed');
                    this.cmp_cc.classList.add('focusable');
                }
                expandAddresses(this.bccNode, this.composer.bcc);
                if (this.composer.bcc && this.composer.bcc.length > 0) {
                    this.cmp_bcc.classList.remove('collapsed');
                    this.cmp_bcc.classList.add('focusable');
                }
                this.validateAddresses();
                this.doActive = false;
                this.renderSendStatus();
                if (this.forwardAttachments) {
                    this.setForwardAttachments();
                } else {
                    this.renderAttachments();
                }
                this.subjectNode.value = this.composer.subject;
                this.origText = this.composer.body.text;
                this.populateEditor(this.composer.body.text);
                if (this.composer.body.html) {
                    this.htmlBodyContainer.classList.remove('collapsed');
                    this.htmlBodyContainer.classList.add('focusable');
                    let ishims = iframeShims.createAndInsertIframeForContent(this.composer.body.html, this.scrollContainer, this.htmlBodyContainer, null, 'noninteractive', null);
                    this.htmlBodyContainer.addEventListener('keydown', this.handBodyContainerKeydown);
                }
                if (!this._emittedContentEvents) {
                    evt.emit('metrics:contentDone');
                    this._emittedContentEvents = true;
                }
            },
            handBodyContainerKeydown: function (evt) {
                switch (evt.key) {
                case 'ArrowDown':
                    this.scrollByStep(this.scrollContainer, 'down');
                    evt.preventDefault();
                    evt.stopPropagation();
                    break;
                case 'ArrowUp':
                    if (this.textBodyNodeIsVisible()) {
                        return;
                    }
                    this.scrollByStep(this.scrollContainer, 'up');
                    evt.preventDefault();
                    evt.stopPropagation();
                    break;
                }
            },
            scrollByStep: function (el, dir) {
                let sHeight = el.scrollHeight;
                let cHeight = el.clientHeight;
                let moveHeight = sHeight - cHeight;
                let sTop = el.scrollTop;
                let stepHeight = document.documentElement.clientHeight / 8;
                if (dir === 'down') {
                    if (sTop < moveHeight) {
                        if (sTop + stepHeight >= moveHeight) {
                            el.scrollTop = moveHeight;
                        } else {
                            el.scrollTop = sTop + stepHeight;
                        }
                    }
                } else if (dir === 'up') {
                    if (sTop - stepHeight >= 0) {
                        el.scrollTop = sTop - stepHeight;
                    } else {
                        el.scrollTop = 0;
                    }
                }
            },
            textBodyNodeIsVisible: function () {
                let rects = this.textBodyNode.getClientRects();
                let top = rects[0].top;
                if (top > this.scrollContainer.offsetTop) {
                    return true;
                } else {
                    return false;
                }
            },
            renderSendStatus: function () {
                let sendStatus = this.composer.sendStatus || {};
                if (sendStatus.state === 'error') {
                    let badAddresses = sendStatus.badAddresses || [];
                    console.log('Editing a failed outbox message. Details:', JSON.stringify({
                        err: sendStatus.err,
                        badAddressCount: badAddresses.length,
                        sendFailures: sendStatus.sendFailures
                    }, null, ' '));
                    let l10nId;
                    if (badAddresses.length || sendStatus.err === 'bad-recipient') {
                        l10nId = 'send-failure-recipients';
                    } else {
                        l10nId = 'send-failure-unknown';
                    }
                    this.errorMessage.setAttribute('data-l10n-id', l10nId);
                    this.errorMessage.classList.remove('collapsed');
                } else {
                    this.errorMessage.classList.add('collapsed');
                }
            },
            isValidAddress: function (address) {
                let mailbox = model.api.parseMailbox(address);
                return mailbox && mailbox.address;
            },
            extractAddresses: function () {
                let allAddresses = [];
                let invalidAddresses = [];
                let frobAddressNode = node => {
                    let bubbles = node.parentNode.querySelectorAll('.cmp-peep-bubble');
                    let addrList = [];
                    for (let i = 0; i < bubbles.length; i++) {
                        let dataSet = bubbles[i].dataset;
                        addrList.push({
                            name: dataSet.name,
                            address: dataSet.address
                        });
                    }
                    if (node.value.trim().length !== 0) {
                        let mailbox = model.api.parseMailbox(node.value);
                        addrList.push({
                            name: mailbox.name,
                            address: mailbox.address
                        });
                    }
                    addrList.forEach(addr => {
                        allAddresses.push(addr);
                        if (!this.isValidAddress(addr.address)) {
                            invalidAddresses.push(addr);
                        }
                    });
                    return addrList;
                };
                return {
                    to: frobAddressNode(this.toNode),
                    cc: frobAddressNode(this.ccNode),
                    bcc: frobAddressNode(this.bccNode),
                    all: allAddresses,
                    invalid: invalidAddresses
                };
            },
            _saveStateToComposer: function (obj) {
                if (!obj) {
                    obj = this.composer;
                }
                let addrs = this.extractAddresses();
                obj.to = addrs.to;
                obj.cc = addrs.cc;
                obj.bcc = addrs.bcc;
                obj.subject = this.subjectNode.value;
                obj.body.text = this.fromEditor();
            },
            _closeCard: function () {
                this._selfClosed = true;
                cards.removeCardAndSuccessors(this, 'animate');
            },
            _saveNeeded: function () {
                let checkHeaderChange = () => {
                    let bubbles = this.querySelectorAll('.cmp-peep-bubble');
                    let subjectChange = this.subjectNode.value !== this.composer.subject;
                    if (!this.type || this.type !== 'reply') {
                        return bubbles.length > 0 || this.toNode.value || this.ccNode.value || this.bccNode.value || subjectChange;
                    } else {
                        let addrs = this.extractAddresses();
                        return this.isAddressChanged(addrs.to, this.composer.to) || this.isAddressChanged(addrs.cc, this.composer.cc) || this.isAddressChanged(addrs.bcc, this.composer.bcc) || subjectChange;
                    }
                };
                if (!this.composer) {
                    return false;
                }
                let hasNewContent = this.fromEditor() !== this.composer.body.text;
                return checkHeaderChange() || hasNewContent || this.composer.attachments.length || this.composer.hasDraft;
            },
            _saveDraft: function (reason, callback) {
                if (this.sending && reason === 'automatic') {
                    console.log('compose: skipping autosave because send in progress');
                    return;
                }
                this._saveStateToComposer();
                evt.emit('uiDataOperationStart', this._dataIdSaveDraft);
                this.composer.saveDraft(() => {
                    evt.emit('uiDataOperationStop', this._dataIdSaveDraft);
                    if (callback) {
                        callback();
                    }
                });
            },
            isAddressChanged: function (currentAddrs, originalAddrs) {
                if (!originalAddrs) {
                    return currentAddrs.length > 0;
                } else if (currentAddrs.length !== originalAddrs.length) {
                    return true;
                }
                let isObjectValueEqual = (a, b) => {
                    let aProps = Object.getOwnPropertyNames(a);
                    let bProps = Object.getOwnPropertyNames(b);
                    if (aProps.length !== bProps.length) {
                        return false;
                    }
                    for (let i = 0; i < aProps.length; i++) {
                        let propName = aProps[i];
                        if (a[propName] !== b[propName]) {
                            return false;
                        }
                    }
                    return true;
                };
                for (let i = 0; i < currentAddrs.length; i++) {
                    for (let j = 0; j < originalAddrs.length; j++) {
                        if (isObjectValueEqual(currentAddrs[i], originalAddrs[j])) {
                            break;
                        } else if (j === originalAddrs.length - 1) {
                            return true;
                        }
                    }
                }
                return false;
            },
            createBubbleNode: function (name, address) {
                let bubble = cmpPeepBubbleNode.cloneNode(true);
                bubble.classList.add('peep-bubble');
                bubble.classList.add('msg-peep-bubble');
                bubble.classList.add('focusable');
                bubble.setAttribute('data-address', address);
                bubble.querySelector('.cmp-peep-address').textContent = address;
                let nameNode = bubble.querySelector('.cmp-peep-name');
                if (navigator.largeTextEnabled) {
                    nameNode.classList.add('p-pri');
                }
                if (!name) {
                    nameNode.textContent = address.indexOf('@') !== -1 ? address.split('@')[0] : address;
                } else {
                    nameNode.textContent = name;
                    bubble.setAttribute('data-name', name);
                }
                return bubble;
            },
            insertBubble: function (node, name, address, callback) {
                let container = node.parentNode;
                let cmpLine = container.parentNode.parentNode;
                let bubble = this.createBubbleNode(name || address, address);
                let bInsert = true;
                for (let i = 0; i < container.children.length - 1; i++) {
                    let dataSet = container.children[i].dataset;
                    if (dataSet.address === address) {
                        bInsert = false;
                        break;
                    }
                }
                let setElementFocus = element => {
                    if (callback) {
                        callback(!this.inEditMode);
                    }
                    if (this.inEditMode) {
                        let input = container.querySelector('.cmp-addr-text');
                        input.classList.remove('cmp-edit-text');
                        if (element) {
                            let elements = Array.prototype.slice.call(NavigationMap.getCurrentControl().elements);
                            NavigationMap.setFocus(elements.indexOf(element));
                        } else {
                            let index = NavigationMap.getCurrentControl().index;
                            NavigationMap.setFocus(index);
                        }
                        this.inEditMode = false;
                        let editNode = document.querySelector('.edit-mode.cmp-envelope-line');
                        editNode && editNode.classList.remove('edit-mode');
                    }
                };
                if (bInsert) {
                    container.insertBefore(bubble, node);
                    if (!cmpLine.classList.contains('cmp-input-bubble')) {
                        cmpLine.classList.add('cmp-input-bubble');
                    }
                    this.validateAddresses();
                    NavigationMap.horizontal = '.' + container.parentNode.classList[0];
                    NavigationMap.navSetup(this.localName, '.focusable', null, seriesElement => {
                        setElementFocus(seriesElement);
                    });
                } else {
                    setElementFocus();
                }
                if (!this.isBubbleInView(this.toNode)) {
                    this.toNode.scrollIntoView(false);
                }
            },
            isBubbleInView: function (el) {
                let rect = el.getBoundingClientRect();
                return rect.top >= 0 && rect.bottom <= (window.innerHeight || document.documentElement.clientHeight);
            },
            deleteBubble: function (node) {
                if (!node) {
                    return;
                }
                let container = node.parentNode;
                let cmpLine = container.parentNode.parentNode;
                if (node.classList.contains('cmp-peep-bubble')) {
                    NavigationMap.horizontal = '.' + container.parentNode.classList[0];
                    container.removeChild(node);
                }
                if (container.children.length === 1) {
                    if (cmpLine.classList.contains('cmp-input-bubble')) {
                        cmpLine.classList.remove('cmp-input-bubble');
                    }
                }
                this.validateAddresses();
            },
            editBubble: function (node) {
                if (!node) {
                    return;
                }
                let container = node.parentNode;
                if (node.classList.contains('cmp-peep-bubble')) {
                    container.removeChild(node);
                    let input = container.querySelector('.cmp-addr-text');
                    input.classList.add('cmp-edit-text');
                    if (input.value.length > 0) {
                        input.value = input.value + ',';
                        this.onAddressInput({ target: input });
                    }
                    let address = node.dataset.address;
                    let selStart = input.value.length;
                    let selEnd = selStart + address.length;
                    input.value += address;
                    input.focus();
                    this.onAddressInput({ target: input });
                    this.inEditMode = true;
                    input.parentNode.parentNode.parentNode.classList.add('edit-mode');
                    input.setSelectionRange(selEnd, selEnd);
                }
                this.validateAddresses();
            },
            onAddressKeydown: function (evt) {
                let node = evt.target;
                if (evt.key === 'Backspace') {
                    let previousBubble = node.previousElementSibling;
                    if (node.value === '' && previousBubble && !this.inEditMode) {
                        this.deleteBubble(previousBubble);
                        if (NavigationMap.horizontal) {
                            NavigationMap.horizontal = null;
                        }
                        evt.preventDefault();
                        evt.stopPropagation();
                    }
                }
                if (this.inEditMode) {
                    if (evt.key === 'ArrowDown') {
                        if (this.suggestionsList.children.length) {
                            this.changeFocus(false, 'edit-mode');
                        }
                        return;
                    } else if (evt.key === 'ArrowUp') {
                        return;
                    }
                }
                if (evt.key === 'Enter') {
                    if (this.addedBubble) {
                        let index = NavigationMap.getCurrentControl().index;
                        NavigationMap.setFocus(index);
                        this.addedBubble = false;
                        return;
                    }
                    if (!this.isValidAddress(node.value)) {
                        let dialogConfig = {
                            title: {
                                id: 'compose-invalid-addresses-title',
                                args: {}
                            },
                            body: {
                                id: 'compose-invalid-addresses-description',
                                args: {}
                            },
                            accept: {
                                l10nId: 'confirm-dialog-ok',
                                priority: 2,
                                callback: () => {
                                    let index = NavigationMap.getCurrentControl().index;
                                    NavigationMap.setFocus(index);
                                    if (this.inEditMode) {
                                        node.classList.remove('cmp-edit-text');
                                        this.inEditMode = false;
                                        document.querySelector('.edit-mode.cmp-envelope-line').classList.remove('edit-mode');
                                    }
                                }
                            }
                        };
                        evt.preventDefault();
                        evt.stopPropagation();
                        NavigationMap.showConfigDialog(dialogConfig);
                    } else {
                        setTimeout(() => {
                            if (node.value) {
                                node.value = node.value + ',';
                                this.onAddressInput(evt);
                            }
                        });
                    }
                }
                if (evt.key === 'ArrowDown' || evt.key === 'ArrowUp' && !node.classList.contains('cmp-to-text')) {
                    if (node.classList.contains('cmp-addr-text')) {
                        if (node.value) {
                            if (this.isValidAddress(node.value) && !this.suggestionList) {
                                node.value = node.value + ',';
                                this.onAddressInput(evt);
                            }
                        }
                        if (node.value === '' && node.parentNode.children.length > 1) {
                            node.classList.add('collapsed');
                        }
                    }
                }
                if (evt.key === 'ArrowDown') {
                    if (this.suggestionList) {
                        let focused = document.querySelectorAll('.focus');
                        for (let i = 0; i < focused.length; i++) {
                            focused[i].classList.remove('focus');
                        }
                        document.activeElement.blur();
                    }
                }
            },
            onSubjectKeydown: function (evt) {
                if (evt.key === 'Enter') {
                    evt.preventDefault();
                    evt.stopPropagation();
                }
            },
            startNavOnSuggestionList: function (evt) {
                NavigationMap.navSetup(this.localName, '.focusable');
                this.navOnSuggestionListHandle = this.handleNavOnSuggestionList.bind(this);
                window.addEventListener('keydown', this.navOnSuggestionListHandle);
                this.suggestionListNavListener = true;
            },
            stopNavOnSuggestionList: function (evt) {
                let focused = document.querySelector('.focus');
                if (focused && focused.classList.contains('cmp-combo')) {
                    let container = focused.querySelector('.cmp-addr-container');
                    NavigationMap.horizontal = '.' + container.classList[0];
                    NavigationMap.navSetup(this.localName, '.focusable');
                }
                window.removeEventListener('keydown', this.navOnSuggestionListHandle);
                this.suggestionListNavListener = false;
            },
            handleNavOnSuggestionList: function (evt) {
                let selected = this.suggestionsList.querySelector('.selected');
                let index = NavigationMap.getCurrentControl().index;
                switch (evt.key) {
                case 'ArrowDown':
                    evt.preventDefault();
                    evt.stopPropagation();
                    if (selected) {
                        if (!selected.nextElementSibling && this.inEditMode) {
                            return;
                        }
                        selected.classList.remove('selected');
                        if (selected.nextElementSibling) {
                            selected.nextElementSibling.classList.add('selected');
                            let focus = this.suggestionsList.querySelector('.selected');
                            if (!this.isSuggestionVisible(focus)) {
                                focus.scrollIntoView(false);
                            }
                        } else if (!this.inEditMode) {
                            this.clearSuggestionList();
                            this.stopNavOnSuggestionList();
                            NavigationMap.setFocus(index + 1);
                            NavigationMap.scrollToElement(NavigationMap.getCurrentItem(), { key: 'ArrowDown' });
                        }
                    } else {
                        this.suggestionsList.children[0].classList.add('selected');
                        this.switchSKtoSuggetion();
                    }
                    break;
                case 'ArrowUp':
                    evt.preventDefault();
                    evt.stopPropagation();
                    if (selected) {
                        selected.classList.remove('selected');
                        if (selected.previousElementSibling) {
                            selected.previousElementSibling.classList.add('selected');
                            let focus = this.suggestionsList.querySelector('.selected');
                            if (!this.isSuggestionVisible(focus)) {
                                focus.scrollIntoView(false);
                            }
                        } else {
                            if (this.inEditMode) {
                                this.changeFocus(true, 'edit-mode');
                            } else {
                                NavigationMap.setFocus(index);
                            }
                            NavigationMap.scrollToElement(NavigationMap.getCurrentItem(), { key: 'ArrowUp' });
                            this.setSoftkey();
                        }
                    }
                    break;
                }
            },
            isSuggestionVisible: function (bestElementToFocus) {
                if (bestElementToFocus.offsetWidth === 0 || bestElementToFocus.offsetHeight === 0) {
                    return false;
                }
                let rects = bestElementToFocus.getClientRects();
                let softkeyHeight = document.getElementById('softkeyPanel').clientHeight;
                let topTarget;
                let inView = false;
                if (this.addWhich === 'to') {
                    topTarget = this.cmp_to.clientHeight + softkeyHeight;
                } else if (this.addWhich === 'cc') {
                    topTarget = this.cmp_cc.clientHeight + softkeyHeight;
                } else if (this.addWhich === 'bcc') {
                    topTarget = this.cmp_bcc.clientHeight + softkeyHeight;
                }
                let bottomTarget = topTarget + this.suggestionsContainer.clientHeight;
                for (let i = 0; i < rects.length; i++) {
                    let r = rects[i];
                    if (r.bottom > 0 && r.bottom <= bottomTarget && r.top >= topTarget) {
                        inView = true;
                    }
                    if (inView) {
                        return true;
                    }
                }
                return false;
            },
            onAddressFocus: function (evt) {
                this.searchContacts(evt);
                evt.target.setSelectionRange(9999, 9999);
            },
            onAddressInput: function (evt) {
                this.searchContacts(evt);
                if (evt.isComposing) {
                    return;
                }
                let node = evt.target;
                let makeBubble = false;
                switch (node.value.slice(-1)) {
                case ' ':
                case ',':
                case ';':
                    makeBubble = true;
                    break;
                }
                if (makeBubble) {
                    if (!this.isValidAddress(node.value)) {
                        let val = node.value;
                        let dialogConfig = {
                            title: {
                                id: 'compose-invalid-addresses-title',
                                args: {}
                            },
                            body: {
                                id: 'compose-invalid-addresses-description',
                                args: {}
                            },
                            accept: {
                                l10nId: 'confirm-dialog-ok',
                                priority: 2,
                                callback: () => {
                                    let index = NavigationMap.getCurrentControl().index;
                                    NavigationMap.setFocus(index);
                                    if (this.inEditMode) {
                                        node.classList.remove('cmp-edit-text');
                                        this.inEditMode = false;
                                        document.querySelector('.edit-mode.cmp-envelope-line').classList.remove('edit-mode');
                                    }
                                }
                            }
                        };
                        node.value = val.substr(0, val.length - 1);
                        evt.preventDefault();
                        evt.stopPropagation();
                        NavigationMap.showConfigDialog(dialogConfig);
                    } else {
                        let mailbox = model.api.parseMailbox(node.value);
                        this.insertBubble(node, mailbox.name, mailbox.address);
                        node.value = '';
                    }
                }
                if (!this.stringContainer) {
                    this.stringContainer = document.createElement('div');
                    this.appendChild(this.stringContainer);
                    let inputStyle = window.getComputedStyle(node);
                    this.stringContainer.style.fontSize = inputStyle.fontSize;
                }
                this.stringContainer.style.display = 'inline-block';
                this.stringContainer.style.visibility = 'hidden';
                this.stringContainer.textContent = node.value;
                node.style.width = this.stringContainer.clientWidth + 2 + 'px';
                this.validateAddresses();
            },
            onContainerKeydown: function (evt) {
                let target = evt.target;
                if (target.classList.contains('cmp-peep-bubble')) {
                    switch (evt.key) {
                    case 'Enter':
                        evt.preventDefault();
                        evt.stopPropagation();
                        this.editBubble(target);
                        break;
                    case 'Backspace':
                        evt.preventDefault();
                        evt.stopPropagation();
                        this.deleteBubble(target);
                        NavigationMap.navSetup(this.localName, '.focusable', null, seriesElement => {
                            let elements = Array.prototype.slice.call(NavigationMap.getCurrentControl().elements);
                            NavigationMap.setFocus(elements.indexOf(seriesElement));
                        });
                        break;
                    case 'ArrowUp':
                        if (target.style.getPropertyValue('--nav-up') < 0) {
                            break;
                        }
                    case 'ArrowDown':
                        let container = target.parentNode;
                        let input = container.querySelector('.cmp-addr-text');
                        input.classList.add('collapsed');
                        break;
                    }
                } else {
                    if (!this.inEditMode && target.value.length > 0 && (evt.key === 'ArrowLeft' || evt.key === 'ArrowRight')) {
                        evt.stopPropagation();
                    }
                }
            },
            activitySaveDraft: function () {
                if (this.activity && document.hidden && !cards._endKeyClicked) {
                    localStorage.setItem('emailComposeDraft', Date.now());
                    this._saveStateToComposer(this.draftEmailObj);
                    localStorage.setItem('emailComposeDraftContent', JSON.stringify(this.draftEmailObj));
                }
            },
            _warnAttachmentSizeExceeded: function (numAttachments) {
                let title = 'composer-attachment-large-title';
                let contentId;
                if (numAttachments > 1) {
                    contentId = 'compose-attchments-size-exceeded';
                } else {
                    contentId = 'compose-attchment-size-exceeded';
                }
                document.activeElement.blur();
                let dialogConfig = {
                    title: {
                        id: title,
                        args: {}
                    },
                    body: {
                        id: contentId,
                        args: {}
                    },
                    accept: {
                        l10nId: 'confirm-dialog-ok',
                        priority: 2,
                        callback: () => {
                            let index = NavigationMap.getCurrentControl().index;
                            NavigationMap.setFocus(index);
                        }
                    }
                };
                NavigationMap.showConfigDialog(dialogConfig);
            },
            _onAttachmentDone: function (err, composer, persistedNamer) {
                if (this.draftEmailObj) {
                    this.draftEmailObj.persistedNamer = persistedNamer;
                }
                this._totalAttachmentsDone += 1;
                if (this._totalAttachmentsDone < this._totalAttachmentsFinishing) {
                    return;
                }
                setTimeout(() => {
                    let wantAttachment = this._wantAttachment;
                    this._totalAttachmentsFinishing = 0;
                    this._totalAttachmentsDone = 0;
                    this._wantAttachment = false;
                    if (toaster.isShowing()) {
                        toaster.hide();
                    }
                    if (wantAttachment) {
                        this.onAttachmentAdd();
                    }
                }, 600);
            },
            addAttachmentsSubjectToSizeLimits: function (toAttach, replaceAttach) {
                let totalSize = this.calculateTotalAttachmentsSize();
                let attachedAny = false;
                let replaceSize = 0;
                while (toAttach.length) {
                    let attachment = toAttach.shift();
                    if (replaceAttach) {
                        replaceSize = replaceAttach.blob.size;
                    }
                    totalSize += attachment.blob.size;
                    if (totalSize >= MAX_ATTACHMENT_SIZE + replaceSize) {
                        this._warnAttachmentSizeExceeded(1 + this.composer.attachments.length);
                        break;
                    }
                    this._totalAttachmentsFinishing += 1;
                    if (replaceAttach) {
                        this.composer.replaceAttachment(replaceAttach, attachment, this._onAttachmentDone);
                    } else {
                        this.composer.addAttachment(attachment, this._onAttachmentDone);
                    }
                    attachedAny = true;
                }
                if (attachedAny) {
                    this.renderAttachments();
                }
            },
            setForwardAttachments: function () {
                let attachments = this.forwardAttachments;
                let index = 0;
                let attachmentsToAdd = [];
                let addError = false;
                let setAttachments = attachment => {
                    this.getAttachmentBlob(attachment).then(blob => {
                        if (blob) {
                            attachmentsToAdd.push({
                                name: attachments[index].filename,
                                blob: blob
                            });
                        }
                        index += 1;
                        loadAttachments();
                    }).catch(error => {
                        if ('NotFoundError' === error.message) {
                            attachment.resetDownloadState();
                            attachment.download(() => {
                                setAttachments(attachment);
                            }, null, false);
                        } else {
                            addError = true;
                            index += 1;
                            loadAttachments();
                        }
                    });
                };
                let loadAttachments = () => {
                    if (index < attachments.length) {
                        let attachment = attachments[index];
                        if (!attachment.isDownloaded || !attachment._file) {
                            if (navigator.connection.type === 'none') {
                                addError = true;
                                index += 1;
                                loadAttachments();
                                return;
                            }
                            attachment.download(() => {
                                setAttachments(attachment);
                            }, null, false);
                        } else {
                            setAttachments(attachment);
                        }
                    } else {
                        let someAttachmentsLoaded = attachmentsToAdd.length > 0;
                        this.loadingAttachments.classList.add('collapsed');
                        this.addAttachmentsSubjectToSizeLimits(attachmentsToAdd);
                        if (addError) {
                            this.showForwardAttention(attachments.length, someAttachmentsLoaded);
                        }
                        this.validateAddresses();
                    }
                };
                if (this.attachFilesSize > MAX_ATTACHMENT_SIZE) {
                    this._warnAttachmentSizeExceeded(attachments.length);
                    return;
                }
                let storage = navigator.b2g.getDeviceStorage('sdcard');
                storage.available().then(result => {
                    if (result === 'available') {
                        storage.freeSpace().then(result => {
                            if (result < this.unDownloadFilesSize) {
                                this.showForwardAttention(attachments.length);
                            } else {
                                if (attachments.length > 1) {
                                    this.loadingAttachmentsInfo.setAttribute('data-l10n-id', 'compose-attachments-loading');
                                }
                                this.loadingAttachments.classList.remove('collapsed');
                                loadAttachments();
                            }
                        });
                    }
                });
            },
            showForwardAttention: function (numAttachments, bPartLoaded = false) {
                let bodyId = numAttachments > 1 ? 'compose-forward-attachments-unable-load' : 'compose-forward-attachment-unable-load';
                let title = 'compose-forward-attachment-error-title';
                if (bPartLoaded) {
                    bodyId = 'compose-forward-attachment-load-error';
                    title = 'compose-forward-attachment-error-title2';
                }
                let dialogConfig = {
                    title: {
                        id: title,
                        args: {}
                    },
                    body: {
                        id: bodyId,
                        args: {}
                    },
                    accept: {
                        l10nId: 'confirm-dialog-ok',
                        priority: 2
                    }
                };
                NavigationMap.showConfigDialog(dialogConfig);
            },
            getAttachmentBlob: function (attachment) {
                return new Promise(function (resolve, reject) {
                    let storageType = attachment._file[0];
                    let filename = attachment._file[1];
                    let storage = navigator.b2g.getDeviceStorage(storageType);
                    let getReq = storage.get(filename);
                    getReq.then(blob => {
                        resolve(blob);
                    }, error => {
                        reject(error);
                    });
                });
            },
            renderAttachments: function () {
                if (this.composer.attachments && this.composer.attachments.length) {
                    this.attachmentsContainer.innerHTML = '';
                    this.attachmentsName.innerHTML = '';
                    let attTemplate = cmpAttachmentItemNode, filenameTemplate = attTemplate.getElementsByClassName('cmp-attachment-filename')[0], filesizeTemplate = attTemplate.getElementsByClassName('cmp-attachment-filesize')[0];
                    for (let i = 0; i < this.composer.attachments.length; i++) {
                        let attachment = this.composer.attachments[i];
                        filenameTemplate.textContent = attachment.name;
                        fileDisplay.fileSize(filesizeTemplate, attachment.blob.size);
                        let attachmentNode = attTemplate.cloneNode(true);
                        this.attachmentsContainer.appendChild(attachmentNode);
                        this.attachmentsName.textContent += attachment.name + ' ';
                        let mimeClass = mimeToClass(attachment.blob.type);
                        attachmentNode.classList.add(mimeClass);
                        let attachementIcon = attachmentNode.querySelector('.cmp-attachment-icon');
                        let attachementDataIcon = '';
                        switch (mimeClass) {
                        case 'mime-audio':
                            attachementDataIcon = 'file-audio';
                            break;
                        case 'mime-video':
                            attachementDataIcon = 'file-video';
                            break;
                        case 'mime-image':
                            attachementDataIcon = 'file-photo';
                            break;
                        case 'mime-zip':
                            attachementDataIcon = 'file-compress';
                            break;
                        default:
                            attachementDataIcon = 'file';
                            break;
                        }
                        attachementIcon.setAttribute('data-icon', attachementDataIcon);
                    }
                    this.updateAttachmentsSize();
                }
                new Promise(resolve => {
                    if (this.type !== 'reply') {
                        let index = NavigationMap.getCurrentControl().index;
                        NavigationMap.setFocus(index);
                    }
                    resolve();
                }).then(() => {
                    window.dispatchEvent(new CustomEvent('cmp-attachments-update', {
                        detail: { composer: this },
                        bubbles: true,
                        cancelable: false
                    }));
                });
            },
            calculateTotalAttachmentsSize: function () {
                let totalSize = 0;
                for (let i = 0; i < this.composer.attachments.length; i++) {
                    totalSize += this.composer.attachments[i].blob.size;
                }
                return totalSize;
            },
            updateAttachmentsSize: function () {
                mozL10n.setAttributes(this.attachmentLabel, 'compose-attachments', { n: this.composer.attachments.length });
                if (this.composer.attachments.length === 0) {
                    this.attachmentsSize.textContent = '';
                } else {
                    fileDisplay.fileSize(this.attachmentsSize, this.calculateTotalAttachmentsSize());
                }
                let needFocus = false;
                if (this.composer.attachments.length >= 1) {
                    this.attachmentTotal.classList.remove('collapsed');
                    this.attachmentTotal.classList.add('focusable');
                    needFocus = true;
                } else {
                    this.attachmentTotal.classList.add('collapsed');
                    this.attachmentTotal.classList.remove('focusable');
                }
                NavigationMap.navSetup(this.localName, '.focusable');
                if (needFocus) {
                    let elements = Array.prototype.slice.call(NavigationMap.getCurrentControl().elements);
                    NavigationMap.setFocus(elements.indexOf(this.attachmentTotal));
                }
            },
            onClickRemoveAttachment: function (attachIndex) {
                let node = this.attachmentsContainer.querySelector('[data-attachindex="' + attachIndex + '"]');
                node.parentNode.removeChild(node);
                let attachment = this.composer.attachments[attachIndex];
                this.composer.removeAttachment(attachment);
                toaster.toast({ text: mozL10n.get('cmp-remove-attach') });
                new Promise(resolve => {
                    if (this.composer.attachments && this.composer.attachments.length) {
                        let tempName = '';
                        for (let i = 0; i < this.composer.attachments.length; i++) {
                            let attachment = this.composer.attachments[i];
                            tempName += attachment.name + ' ';
                        }
                        this.attachmentsName.textContent = tempName;
                    }
                    this.updateAttachmentsSize();
                    resolve();
                }).then(() => {
                    window.dispatchEvent(new CustomEvent('cmp-attachments-update', {
                        detail: { composer: this },
                        bubbles: true,
                        cancelable: false
                    }));
                });
            },
            goBack: function () {
                this._closeCard();
                if (this.activity) {
                    const result = {
                        activityHandlerId: this.activity.activityHandlerId,
                        activityResult: 'cancelled',
                        isError: true
                    };
                    navigator.serviceWorker.controller.postMessage(result);
                    this.activity = null;
                    window.close();
                    clearInterval(window.keepSWStateInterval);
                    cards._backgroundUpdate = true;
                }
            },
            onBack: function (callback) {
                if (!this._saveNeeded()) {
                    console.log('compose: back: no save needed, exiting without prompt');
                    if (callback) {
                        callback();
                    } else {
                        this.goBack();
                    }
                    return;
                }
                if (!NavigationMap.configDialogShown()) {
                    let dialogConfig = {
                        title: {
                            id: 'confirm-dialog-title',
                            args: {}
                        },
                        body: {
                            id: 'compose-draft-save',
                            args: {}
                        },
                        cancel: {
                            l10nId: 'compose-draft-dialog-cancel',
                            priority: 1,
                            callback: () => {
                                NavigationMap.restoreFocus();
                                cards._endKeyClicked = false;
                            }
                        },
                        accept: {
                            l10nId: 'compose-draft-dialog-save',
                            priority: 2,
                            callback: () => {
                                this._saveDraft('explicit');
                                NavigationMap.restoreFocus();
                                if (callback) {
                                    toaster.toast({ text: mozL10n.get('composer-draft-saved') });
                                    callback();
                                } else {
                                    this.goBack();
                                    toaster.toast({ text: mozL10n.get('composer-draft-saved') });
                                }
                            }
                        },
                        confirm: {
                            l10nId: 'compose-discard-confirm',
                            priority: 3,
                            callback: () => {
                                if (localStorage.getItem('emailComposeDraft')) {
                                    localStorage.removeItem('emailComposeDraft');
                                    localStorage.removeItem('emailComposeDraftContent');
                                }
                                this.composer.abortCompositionDeleteDraft();
                                NavigationMap.restoreFocus();
                                if (callback) {
                                    callback();
                                } else {
                                    this.goBack();
                                }
                            }
                        }
                    };
                    NavigationMap.showConfigDialog(dialogConfig);
                }
            },
            validateAddresses: function () {
                let addrs = this.extractAddresses();
                if (addrs.all.length === 0 || !this.loadingAttachments.classList.contains('collapsed')) {
                    this.needSendKey = false;
                } else {
                    this.needSendKey = !(addrs.all.length === addrs.invalid.length);
                }
                if (!this.doActive) {
                    this.setSoftkey();
                }
                if (addrs.invalid.length === 0) {
                    this.errorMessage.classList.add('collapsed');
                    return true;
                } else {
                    return false;
                }
            },
            onSend: function () {
                if (!this.validateAddresses()) {
                    document.activeElement.blur();
                    let dialogConfig = {
                        title: {
                            id: 'compose-invalid-addresses-title',
                            args: {}
                        },
                        body: {
                            id: 'compose-invalid-addresses-description',
                            args: {}
                        },
                        accept: {
                            l10nId: 'confirm-dialog-ok',
                            priority: 2,
                            callback: () => {
                                let index = NavigationMap.getCurrentControl().index;
                                NavigationMap.setFocus(index);
                            }
                        }
                    };
                    NavigationMap.showConfigDialog(dialogConfig);
                } else {
                    this.reallySend();
                }
            },
            reallySend: function () {
                this._saveStateToComposer();
                let activity = this.activity;
                this.sending = true;
                console.log('compose: initiating send');
                evt.emit('uiDataOperationStart', this._dataIdSendEmail);
                this.composer.finishCompositionSendMessage(() => {
                    evt.emit('uiDataOperationStop', this._dataIdSendEmail);
                    if (!this.composer) {
                        return;
                    }
                    if (activity) {
                        const result = {
                            activityHandlerId: this.activity.activityHandlerId,
                            activityResult: 'complete',
                            isError: false
                        };
                        navigator.serviceWorker.controller.postMessage(result);
                        activity = null;
                        evt.once('closeWindowAfterSent', () => {
                            window.close();
                            clearInterval(window.keepSWStateInterval);
                        });
                        cards._backgroundUpdate = true;
                        if (localStorage.getItem('emailComposeDraft')) {
                            localStorage.removeItem('emailComposeDraft');
                            localStorage.removeItem('emailComposeDraftContent');
                        }
                    }
                    this._closeCard();
                });
            },
            onccAdd: function () {
                this.cmp_cc.classList.remove('collapsed');
                this.cmp_cc.classList.add('focusable');
                NavigationMap.navSetup(this.localName, '.focusable');
                this.needRefresh = true;
                this.focusTo = this.cmp_cc;
                this.cmp_cc.scrollIntoView(true);
            },
            onccRemove: function () {
                let ccList = this.cmp_cc.querySelectorAll('.cmp-peep-bubble');
                this.clearContacts(ccList);
                this.cmp_cc.classList.add('collapsed');
                this.cmp_cc.classList.remove('focusable');
                NavigationMap.navSetup(this.localName, '.focusable');
                this.needRefresh = true;
                toaster.toast({ text: mozL10n.get('compose-cc-remove') });
            },
            onbccAdd: function () {
                this.cmp_bcc.classList.remove('collapsed');
                this.cmp_bcc.classList.add('focusable');
                NavigationMap.navSetup(this.localName, '.focusable');
                this.needRefresh = true;
                this.focusTo = this.cmp_bcc;
                this.cmp_bcc.scrollIntoView(true);
            },
            onbccRemove: function () {
                let bccList = this.cmp_bcc.querySelectorAll('.cmp-peep-bubble');
                this.clearContacts(bccList);
                this.cmp_bcc.classList.add('collapsed');
                this.cmp_bcc.classList.remove('focusable');
                NavigationMap.navSetup(this.localName, '.focusable');
                this.needRefresh = true;
                toaster.toast({ text: mozL10n.get('compose-bcc-remove') });
            },
            refresh: function () {
                if (this.needRefresh) {
                    this.updateSoftkey();
                    this.needRefresh = false;
                }
                if (this.focusTo) {
                    let elements = NavigationMap.getCurrentControl().elements;
                    elements = Array.prototype.slice.call(elements);
                    NavigationMap.setFocus(elements.indexOf(this.focusTo));
                    this.focusTo = null;
                }
            },
            clearContacts: function (nodes) {
                let length = nodes.length;
                for (let i = 0; i < length; i++) {
                    this.deleteBubble(nodes[i]);
                }
            },
            goAttachmentsList: function () {
                if (this.addATTActivity && this.addATTActivity.readyState === 'pending') {
                    return;
                }
                console.log('go to attachments list');
                cards.pushCard('cmp-attachments', 'animate', { composer: this });
            },
            onContactAdd: function () {
                if (this._selfClosed) {
                    return;
                }
                let contactBtn = NavigationMap.getCurrentItem();
                try {
                    let activity = new WebActivity('pick', { type: 'webcontacts/email' });
                    activity.start().then(result => {
                        if (result && result.email) {
                            let emt = contactBtn.querySelector('.cmp-addr-text');
                            let name = result.name;
                            if (Array.isArray(name)) {
                                name = name[0];
                            }
                            this.insertBubble(emt, name, result.email);
                        }
                    }, error => {
                        console.log('Activities error');
                        setTimeout(() => {
                            NavigationMap.setFocus('restore');
                        }, 300);
                    });
                } catch (e) {
                    console.log('WebActivities unavailable? : ' + e);
                }
            },
            onAttachmentAdd: function (event) {
                if (event) {
                    event.stopPropagation();
                }
                if (this._totalAttachmentsFinishing > 0) {
                    this._wantAttachment = true;
                    toaster.toast({ text: mozL10n.get('compose-attachment-still-working') });
                    return;
                }
                try {
                    console.log('compose: attach: triggering web activity');
                    let activity = new WebActivity('pick', {
                        type: [
                            'image/*',
                            'video/*',
                            'audio/*',
                            'application/*',
                            'text/vcard'
                        ],
                        nocrop: true
                    });
                    activity.start().then(result => {
                        require(['attachment_name'], attachmentName => {
                            if (!result.blob) {
                                NavigationMap.setFocus('restore');
                                return;
                            }
                            let blob = result.blob, name = result.blob.name || result.name, count = this.composer.attachments.length + 1;
                            name = attachmentName.ensureName(blob, name, count);
                            let filename = name.substring(name.lastIndexOf('/') + 1);
                            this.addAttachmentsSubjectToSizeLimits([{
                                    name: filename,
                                    pathName: name,
                                    blob: blob
                                }]);
                        });
                    }, error => {
                        NavigationMap.setFocus('restore');
                    });
                    this.addATTActivity = activity;
                } catch (e) {
                    console.log('WebActivities unavailable? : ' + e);
                }
            },
            onAttachmentReplace: function () {
                let replacedIndex = document.querySelector('.hasfocused').getAttribute('data-attachIndex');
                if (!replacedIndex) {
                    console.log('Error index of attachment');
                    return;
                }
                let replaceAttach = this.composer.attachments[replacedIndex];
                if (this._totalAttachmentsFinishing > 0) {
                    this._wantAttachment = true;
                    toaster.toast({ text: mozL10n.get('compose-attachment-still-working') });
                    return;
                }
                try {
                    let activity = new WebActivity('pick', {
                        type: [
                            'image/*',
                            'video/*',
                            'audio/*',
                            'application/*',
                            'text/vcard'
                        ],
                        nocrop: true
                    });
                    activity.start().then(result => {
                        require(['attachment_name'], attachmentName => {
                            if (!result.blob) {
                                NavigationMap.setFocus('restore');
                                return;
                            }
                            let blob = result.blob, name = result.blob.name || result.name, count = this.composer.attachments.length + 1;
                            name = attachmentName.ensureName(blob, name, count);
                            console.log('compose: attach activity success:', name);
                            name = name.substring(name.lastIndexOf('/') + 1);
                            this.addAttachmentsSubjectToSizeLimits([{
                                    name: name,
                                    blob: blob
                                }], replaceAttach);
                        });
                    }, error => {
                        NavigationMap.setFocus('restore');
                    });
                    this.addATTActivity = activity;
                } catch (e) {
                    console.log('WebActivities unavailable? : ' + e);
                }
            },
            onHidden: function () {
                window.removeEventListener('keydown', this.keydownHandler);
                window.removeEventListener('email-endkey', this.endkeyHandler);
            },
            die: function () {
                if (this._savePromptMenu) {
                    document.body.removeChild(this._savePromptMenu);
                    this._savePromptMenu = null;
                }
                if (!this._selfClosed && this._saveNeeded()) {
                    console.log('compose: autosaving draft because not self-closed');
                    this._saveDraft('automatic');
                }
                if (this.composer) {
                    this.composer.die();
                    this.composer = null;
                }
                window.removeEventListener('menuEvent', this.menuHandler);
                window.removeEventListener('keydown', this.keydownHandler);
                window.removeEventListener('email-endkey', this.endkeyHandler);
                window.removeEventListener('gaia-confirm-close', this.resetFocus);
                this.htmlBodyContainer.removeEventListener('keydown', this.handBodyContainerKeydown);
                this.htmlBodyContainer.querySelectorAll('.cmp-body-html iframe').forEach(node => {
                    node.contentWindow.document.write('');
                    node.contentWindow.document.clear();
                    node.contentWindow.close();
                    node.parentNode.removeChild(node);
                });
                document.removeEventListener('visibilitychange', this.activitySaveDraft);
            },
            searchContacts: function (evt) {
                let target = evt.target;
                let typed = evt.target.value;
                if (typed) {
                    Contacts.findContactByString(typed, target, this.renderSuggestions.bind(this));
                } else {
                    this.clearSuggestionList();
                    this.stopNavOnSuggestionList();
                    this.setSoftkey();
                }
            },
            renderSuggestions: function (contacts, inputValue, insertNode) {
                this.addedBubble = false;
                if (contacts.length === 0) {
                    this.clearSuggestionList();
                    this.stopNavOnSuggestionList();
                    return;
                }
                if (document.activeElement !== insertNode) {
                    return;
                }
                let itemIndex = 0;
                let pHeight = insertNode.parentNode.parentNode.parentNode.clientHeight;
                let suggestionsListHeight = this.scrollContainer.clientHeight - pHeight;
                this.suggestionsList.innerHTML = '';
                let top;
                if (this.cmp_to.classList.contains('focus') || this.cmp_to.querySelector('.cmp-to-text').classList.contains('cmp-edit-text')) {
                    top = this.cmp_to.clientHeight;
                    this.addWhich = 'to';
                } else if (this.cmp_cc.classList.contains('focus') || this.cmp_cc.querySelector('.cmp-cc-text').classList.contains('cmp-edit-text')) {
                    top = this.cmp_to.clientHeight + this.cmp_cc.clientHeight;
                    this.addWhich = 'cc';
                } else if (this.cmp_bcc.classList.contains('focus') || this.cmp_bcc.querySelector('.cmp-bcc-text').classList.contains('cmp-edit-text')) {
                    top = this.cmp_to.clientHeight + this.cmp_cc.clientHeight + this.cmp_bcc.clientHeight;
                    this.addWhich = 'bcc';
                }
                this.suggestionsContainer.style.setProperty('top', top + 'px');
                this.suggestionsContainer.classList.add('show');
                this.suggestionList = true;
                contacts.forEach(contact => {
                    let name = contact.name;
                    let emails = contact.email;
                    if (!emails || emails.length === 0) {
                        return true;
                    }
                    emails.forEach(item => {
                        let ismatch = this.isMatch(inputValue.terms, name, item.value);
                        if (ismatch) {
                            itemIndex++;
                            let node = suggestionItem.cloneNode(true);
                            node.innerHTML = node.innerHTML.replace(new RegExp('{{name}}', 'gm'), name).replace(new RegExp('{{type}}', 'gm'), item.atype).replace(new RegExp('{{email}}', 'gm'), item.value);
                            this.highlightMatch(inputValue.terms, node);
                            this.suggestionsList.appendChild(node);
                            node.addEventListener('click', () => {
                                this.clearSuggestionList();
                                this.insertBubble(insertNode, name, item.value, needFocus => {
                                    this.addedBubble = true;
                                    insertNode.value = '';
                                    if (needFocus) {
                                        let index = NavigationMap.getCurrentControl().index;
                                        NavigationMap.setFocus(index);
                                    }
                                });
                            });
                        }
                    });
                });
                let liHeight = this.suggestionsList.querySelector('.suggestion-item').clientHeight;
                suggestionsListHeight = suggestionsListHeight < liHeight ? liHeight : suggestionsListHeight;
                this.suggestionsContainer.style.setProperty('max-height', suggestionsListHeight + 'px');
                if (this.suggestionsList.children.length === 0) {
                    this.clearSuggestionList();
                    this.stopNavOnSuggestionList();
                    return;
                }
                this.suggestionsContainer.scrollTop = 0;
                if (insertNode.classList.contains('cmp-cc-text')) {
                    this.cmp_cc.scrollIntoView(true);
                    top = this.cmp_cc.clientHeight;
                } else if (insertNode.classList.contains('cmp-bcc-text')) {
                    this.cmp_bcc.scrollIntoView(true);
                    top = this.cmp_bcc.clientHeight;
                }
                if (!this.suggestionListNavListener) {
                    this.startNavOnSuggestionList();
                }
                if (top + liHeight >= this.scrollContainer.clientHeight) {
                    this.suggestionsContainer.scrollIntoView(false);
                }
            },
            highlightMatch: function (text, node) {
                let name = node.querySelector('.ellipsis-dir-fix');
                let email = node.querySelector('.email-detail');
                let input = text.join(' ');
                let reg = new RegExp(input, 'mi');
                if (reg.test(name.innerHTML)) {
                    name.innerHTML = name.innerHTML.split(input).join('<span>' + input + '</span>');
                }
                if (reg.test(email.innerHTML)) {
                    email.innerHTML = email.innerHTML.split(input).join('<span>' + input + '</span>');
                }
            },
            clearSuggestionList: function (node) {
                if (node) {
                    let evt = new CustomEvent('backspace-long-press');
                    window.dispatchEvent(evt);
                }
                this.suggestionsContainer.classList.remove('show');
                this.suggestionsList.innerHTML = '';
                this.suggestionList = false;
                if (node && !this._selfClosed) {
                    this.searchContacts({ target: node });
                }
            },
            isMatch: function (inputValue, name, email) {
                let input = inputValue.join(' ');
                let reg = new RegExp(input, 'mi');
                return reg.test(name) || reg.test(email);
            },
            hideDialog: function () {
                CustomDialog.hide();
            },
            onBodyNodeKeydown: function (evt) {
                let range = window.getSelection().getRangeAt(0);
                let currentElement = range.startContainer;
                switch (evt.key) {
                case 'ArrowUp':
                    if ((currentElement === document.activeElement || currentElement === document.activeElement.firstChild) && range.startOffset === 0) {
                        break;
                    }
                    evt.stopPropagation();
                    break;
                case 'ArrowDown':
                    if (currentElement === document.activeElement && isLastLine(range) || isLastNode(range)) {
                        break;
                    }
                    evt.stopPropagation();
                    break;
                }
                function isLastLine(range) {
                    if (document.activeElement.lastChild.tagName === 'BR' && range.startOffset === document.activeElement.childNodes.length - 1) {
                        return true;
                    } else if (range.startOffset === document.activeElement.childNodes.length) {
                        return true;
                    }
                    return false;
                }
                function isLastNode(range) {
                    return range.startOffset === range.startContainer.length;
                }
            },
            resetFocus: function () {
                if (this.needResetFocus) {
                    NavigationMap.setFocus('first');
                    this.needResetFocus = false;
                }
            }
        }
    ];
});