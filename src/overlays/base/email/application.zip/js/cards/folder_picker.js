define([
    'require',
    'tmpl!./fld/folder_item.html',
    'tmpl!./fld/account_item.html',
    'folder_depth_classes',
    'cards',
    'model',
    'evt',
    'l10n!',
    'toaster',
    'transition_end',
    'css!style/folder_cards',
    './base',
    'template!./folder_picker.html'
], function (require) {
    let fldFolderItemNode = require('tmpl!./fld/folder_item.html'), fldAccountItemNode = require('tmpl!./fld/account_item.html'), FOLDER_DEPTH_CLASSES = require('folder_depth_classes'), cards = require('cards'), model = require('model'), evt = require('evt'), mozL10n = require('l10n!'), toaster = require('toaster'), transitionEnd = require('transition_end');
    require('css!style/folder_cards');
    return [
        require('./base')(require('template!./folder_picker.html')),
        {
            createdCallback: function () {
                if (this.mode === 'folder') {
                    this.pickerTitle.setAttribute('data-l10n-id', 'folders');
                    this.bindContainerHandler(this.foldersContainer, 'click', this.onClickFolder.bind(this));
                    this.updateAccount = this.updateAccount.bind(this);
                    model.latest('account', this.updateAccount);
                } else if (this.mode === 'account') {
                    this.pickerTitle.setAttribute('data-l10n-id', 'opt-account');
                    model.latest('account', account => {
                        this.curAccount = account;
                    });
                    this.bindContainerHandler(this.accountListContainer, 'click', this.onClickAccount.bind(this));
                    let accountCount = model.getAccountCount();
                    if (accountCount > 1) {
                        this.classList.remove('one-account');
                    }
                    this.acctsSlice = model.api.viewAccounts(false);
                    this.acctsSlice.onsplice = this.onAccountsSplice.bind(this);
                    this.acctsSlice.onchange = this.onAccountsChange.bind(this);
                }
                transitionEnd(this, this.onTransitionEnd.bind(this));
            },
            onArgs: function (args) {
                this.folderPickCard = args.previousCard;
            },
            extraClasses: [
                'anim-vertical',
                'anim-overlay',
                'one-account'
            ],
            onShowSettings: function (event) {
                cards.pushCard('settings_main', 'animate');
            },
            updateAccount: function (account) {
                let oldAccount = this.curAccount;
                this.mostRecentSyncTimestamp = 0;
                if (oldAccount !== account) {
                    this.foldersContainer.innerHTML = '';
                    model.latestOnce('folder', folder => {
                        this.curAccount = account;
                        if (!this.curFolder) {
                            this.curFolder = folder;
                        }
                        if (this.foldersSlice) {
                            this.foldersSlice.onsplice = null;
                            this.foldersSlice.onchange = null;
                        }
                        this.foldersSlice = model.foldersSlice;
                        if (account.enabled) {
                            this.foldersSlice.syncList(account.id);
                        }
                        this.onFoldersSplice(0, 0, this.foldersSlice.items, true, false);
                        this.foldersSlice.onsplice = this.onFoldersSplice.bind(this);
                    });
                }
            },
            onClickAccount: function (accountNode, event) {
                this.curAccount = accountNode.account;
                this._waitingAccountId = this.curAccount.id;
                this._closeCard();
            },
            onAccountsSplice: function (index, howMany, addedItems, requested, moreExpected) {
                let accountListContainer = this.accountListContainer;
                let postSliceCount = this.acctsSlice.items.length + addedItems.length - howMany;
                this.classList.toggle('one-account', postSliceCount <= 1);
                let account;
                if (howMany) {
                    for (let i = index + howMany - 1; i >= index; i--) {
                        account = this.acctsSlice.items[i];
                        if (account.element) {
                            accountListContainer.removeChild(account.element);
                        }
                    }
                }
                let insertBuddy = index >= accountListContainer.childElementCount ? null : accountListContainer.children[index];
                addedItems.forEach(account => {
                    if (account.syncEnable) {
                        let accountNode = account.element = fldAccountItemNode.cloneNode(true);
                        accountNode.account = account;
                        this.updateAccountDom(account, true);
                        accountListContainer.insertBefore(accountNode, insertBuddy);
                    }
                });
                this.setNavigationMap();
            },
            onAccountsChange: function (account) {
                this.updateAccountDom(account, false);
            },
            updateAccountDom: function (account, firstTime) {
                let accountNode = account.element;
                if (firstTime) {
                    accountNode.querySelector('.fld-account-name').textContent = account.name;
                    accountNode.querySelector('.fld-account-label').textContent = account.label;
                    if (this.curAccount && this.curAccount.id === account.id) {
                        accountNode.classList.add('fld-account-selected');
                        accountNode.querySelector('input').setAttribute('checked', true);
                    }
                }
            },
            onFoldersSplice: function (index, howMany, addedItems, requested, moreExpected) {
                let foldersContainer = this.foldersContainer;
                let folder;
                if (howMany) {
                    for (let i = index + howMany - 1; i >= index; i--) {
                        folder = this.foldersSlice.items[i];
                        foldersContainer.removeChild(folder.element);
                    }
                }
                let insertBuddy = index >= foldersContainer.childElementCount ? null : foldersContainer.children[index];
                addedItems.forEach(folder => {
                    let folderNode = folder.element = fldFolderItemNode.cloneNode(true);
                    folderNode.folder = folder;
                    if (folder.type === 'outbox') {
                        if (folder.unread > 0) {
                            folderNode.classList.remove('collapsed');
                        } else {
                            folderNode.classList.add('collapsed');
                        }
                    }
                    this.updateFolderDom(folder, true);
                    foldersContainer.insertBefore(folderNode, insertBuddy);
                });
                this.setNavigationMap();
            },
            updateFolderDom: function (folder, firstTime) {
                let folderNode = folder.element;
                if (firstTime) {
                    if (!folder.selectable) {
                        folderNode.classList.add('fld-folder-unselectable');
                    }
                    let depthIdx = Math.min(FOLDER_DEPTH_CLASSES.length - 1, folder.depth);
                    folderNode.classList.add(FOLDER_DEPTH_CLASSES[depthIdx]);
                    if (depthIdx > 0) {
                        folderNode.classList.add('fld-folder-depthnonzero');
                    }
                    folderNode.querySelector('.fld-folder-name').textContent = folder.name;
                    if (folder.unread > 0) {
                        folderNode.querySelector('.fld-folder-unread').textContent = '(' + folder.unread + ')';
                    }
                    folderNode.dataset.type = folder.type;
                }
                if (folder === this.curFolder) {
                    folderNode.classList.add('fld-folder-selected');
                } else {
                    folderNode.classList.remove('fld-folder-selected');
                }
            },
            onClickFolder: function (folderNode, event) {
                let folder = folderNode.folder;
                if (!folder.selectable) {
                    return;
                }
                let oldFolder = this.curFolder;
                this.curFolder = folder;
                this.updateFolderDom(oldFolder);
                this.updateFolderDom(folder);
                this._showFolder(folder);
                this._closeCard();
            },
            onTransitionEnd: function (event) {
                let switchDone = () => {
                    let text = mozL10n.get('toaster-switch-account');
                    if (this.curAccount.label) {
                        text = text + this.curAccount.label;
                    } else {
                        text = text + this.curAccount.name;
                    }
                    toaster.toast({ text: text });
                };
                if (!this.classList.contains('opened') && event.target.classList.contains('fld-content')) {
                    cards.removeCardAndSuccessors(this, 'animate');
                    if (this.folderPickCard && this.folderShown === true) {
                        this.folderPickCard.goBack();
                        this.folderPickCard = null;
                    }
                    this.folderShown = false;
                    if (this._waitingAccountId) {
                        model.changeAccountFromId(this._waitingAccountId, () => {
                            model.selectInbox(switchDone);
                        });
                        this._waitingAccountId = null;
                    }
                }
            },
            _closeCard: function () {
                evt.emit('folderPickerClosing');
                this.classList.remove('opened');
            },
            _showFolder: function (folder) {
                this.folderShown = true;
                model.changeFolder(folder);
            },
            onCardVisible: function (navDirection) {
                this.classList.add('opened');
                this.setNavigationMap(navDirection);
                this.keydownHandler = this.handleKeydown.bind(this);
                this.addEventListener('keydown', this.keydownHandler);
            },
            setNavigationMap: function (navDirection) {
                if (this.className.indexOf('card center') < 0) {
                    return;
                }
                const CARD_NAME = this.localName;
                const QUERY_CHILD = this.mode === 'folder' ? '.fld-folder-item:not(.collapsed)' : '.fld-account-item:not(.collapsed)';
                const CONTROL_ID = CARD_NAME + ' ' + QUERY_CHILD;
                let hasFocus = !!this.querySelector('.fld-content-container .focus');
                if (navDirection === 'forward' || !navDirection) {
                    this.initOption();
                    NavigationMap.navSetup(CARD_NAME, QUERY_CHILD);
                    NavigationMap.setCurrentControl(CONTROL_ID);
                    if (!hasFocus) {
                        NavigationMap.setFocus('first');
                    }
                } else if (navDirection === 'back') {
                    this.initOption();
                    NavigationMap.setCurrentControl(CONTROL_ID);
                    if (!hasFocus) {
                        NavigationMap.setFocus('restore');
                    }
                }
            },
            die: function () {
                if (this.acctsSlice) {
                    this.acctsSlice.die();
                }
                model.removeListener('account', this.updateAccount);
                this.removeListener('keydown', this.keydownHandler);
            },
            mode: 'folder',
            optCancel: null,
            optSave: null,
            initOption: function () {
                this.optCancel = {
                    name: 'Cancel',
                    l10nId: 'cancel',
                    priority: 1,
                    method: this._closeCard.bind(this)
                };
                this.optSave = {
                    name: 'Select',
                    l10nId: 'select',
                    priority: 2,
                    method: null
                };
                let options = [
                    this.optCancel,
                    this.optSave
                ];
                NavigationMap.setSoftKeyBar(options);
            },
            onSelectFocused: function () {
                let node = NavigationMap.getCurrentItem();
                if (node) {
                    node.click();
                }
            },
            onHidden: function () {
                this.removeListener('keydown', this.keydownHandler);
            },
            handleKeydown: function (evt) {
                switch (evt.key) {
                case 'Backspace':
                    evt.preventDefault();
                    if (window.backToShowFolder && this.localName !== 'cards-account-picker') {
                        this.foldersContainer.childNodes[0].click();
                    } else {
                        this._closeCard();
                    }
                    break;
                }
            }
        }
    ];
});