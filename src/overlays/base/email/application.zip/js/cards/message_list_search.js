define([
    'require',
    'exports',
    'module',
    './message_list'
], function (e, t) {
    return [
        e('./message_list'),
        { mode: 'search' }
    ];
});