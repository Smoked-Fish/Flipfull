define([
    'require',
    'exports',
    'module',
    'tmpl!./msg/view_attachment_item.html',
    'cards',
    'l10n!',
    'mime_to_class',
    'file_display',
    'http://shared.localhost/js/utils/common/mime_mapper.js',
    'toaster',
    'model',
    'device_storage',
    './base',
    'template!./message_reader_attachments.html'
], function (require, exports, module) {
    let attachmentItemNode = require('tmpl!./msg/view_attachment_item.html');
    let cards = require('cards');
    let mozL10n = require('l10n!');
    let mimeToClass = require('mime_to_class');
    let fileDisplay = require('file_display');
    let MimeMapper = require('http://shared.localhost/js/utils/common/mime_mapper.js');
    let toaster = require('toaster');
    let OCTET_STREAM_TYPE = 'application/octet-stream';
    let MAX_ATTCHMENT_SIZE = 5 * 1024 * 1024;
    let MAX_MAY_EMPTY_SIZE = 100;
    let model = require('model');
    let DeviceStorage = require('device_storage');
    return [
        require('./base')(require('template!./message_reader_attachments.html')),
        {
            onArgs: function (args) {
                this.attachments = args.composer;
                this.bView = false;
                this.bShare = false;
                if (this.attachments.length > 1) {
                    this.attachmentsHeader = mozL10n.get('msg-reader-display-attachments');
                } else {
                    this.attachmentsHeader = mozL10n.get('msg-reader-display-attachment');
                }
                this.currentFocusedAttachment = -1;
            },
            onBack: function () {
                cards.removeCardAndSuccessors(this, 'animate');
            },
            die: function () {
                this.attachmentViewShown = false;
                window.removeEventListener('keydown', this.attachmentsKeydownHander);
            },
            getAttachmentBlob: function (attachment, callback) {
                try {
                    let storageType = attachment._file[0];
                    let filename = attachment._file[1];
                    let storage = navigator.b2g.getDeviceStorage(storageType);
                    let getreq = storage.get(filename);
                    getreq.then(blob => {
                        callback(blob);
                    }, error => {
                        console.warn('Could not open attachment file: ', filename, error);
                        if ('NotFoundError' === error.message) {
                            this.notFoundFileDialog();
                        }
                    });
                } catch (ex) {
                    console.warn('Exception getting attachment from device storage:', attachment._file, '\n', ex, '\n', ex.stack);
                }
            },
            onViewAttachment: function (attachment) {
                console.log('trying to open', attachment._file, 'known type:', attachment.mimetype);
                if (!attachment._file && attachment.isDownloadable) {
                    console.log('download this file firstly');
                    this.downloadAttachment(attachment);
                    this.bView = true;
                    return;
                }
                if (attachment.isDownloaded) {
                    this.getAttachmentBlob(attachment, blob => {
                        try {
                            if (!blob) {
                                throw new Error('Blob does not exist');
                            }
                            let useType = attachment.mimetype;
                            if (!useType || useType === OCTET_STREAM_TYPE || useType === 'audio/vnd.dlna.adts') {
                                useType = blob.type;
                            }
                            let type = MimeMapper.guessTypeFromFileProperties(attachment.filename, OCTET_STREAM_TYPE);
                            if (type && type !== '' && useType !== type) {
                                useType = type;
                            }
                            if (!useType) {
                                useType = OCTET_STREAM_TYPE;
                            }
                            console.log('triggering open activity with MIME type:', useType);
                            let activity;
                            if (useType === 'text/x-vcard' || useType === 'text/vcard' || useType === 'text/directory') {
                                activity = new WebActivity('import', {
                                    type: useType,
                                    filename: attachment.filename,
                                    blob: blob
                                });
                            } else {
                                activity = new WebActivity('open', {
                                    type: useType,
                                    filename: attachment.filename,
                                    blob: blob,
                                    url: attachment.filename,
                                    allowSave: true
                                });
                            }
                            activity.start().then(() => {
                                console.log('"open" activity allegedly succeeded');
                            }, error => {
                                console.warn('Problem with "open" activity', error);
                                if (error === 'NO_PROVIDER') {
                                    let dialogConfig = {
                                        title: {
                                            id: 'message-attachment-did-not-open-label',
                                            args: {}
                                        },
                                        body: {
                                            id: 'message-attachment-did-not-open-body',
                                            args: {}
                                        },
                                        accept: {
                                            l10nId: 'confirm-dialog-ok',
                                            priority: 2
                                        }
                                    };
                                    NavigationMap.showConfigDialog(dialogConfig);
                                }
                            });
                        } catch (ex) {
                            console.warn('Problem creating "open" activity:', ex, '\n', ex.stack);
                        }
                    });
                }
            },
            doDownload: function (attachment) {
                let attachmentDownloading = this.currentItem.querySelector('.reader-view-attachment-downloading');
                attachment.isDownloading = true;
                this.setSoftKey();
                attachment.download(() => {
                    console.log('download attachment succuss callback');
                    attachment.isDownloading = false;
                    if (this.className !== 'card center') {
                        return;
                    }
                    if (!attachment._file) {
                        console.log('attachment _file is null');
                        if (attachment.sizeEstimateInBytes < MAX_MAY_EMPTY_SIZE) {
                            toaster.toast({ text: mozL10n.get('emptyDownloadFile') });
                        } else {
                            toaster.toast({ text: mozL10n.get('message-attachment-download-fail', { fileName: attachment.filename }) });
                        }
                    }
                    if (!attachmentDownloading.classList.contains('collapsed')) {
                        attachmentDownloading.classList.add('collapsed');
                    }
                    if (this.attachmentViewShown) {
                        this._refresh();
                        this.setSoftKey();
                        NavigationMap.setFocus('restore');
                        if (attachment === this.currentFocusedAttachment && attachment._file) {
                            if (this.bShare) {
                                this.shareAttachmentHelper(attachment);
                            } else if (this.bView) {
                                this.bView = false;
                                this.onViewAttachment(attachment);
                            }
                        }
                    }
                }, null, true);
                this.setSoftKey();
                attachmentDownloading.classList.remove('collapsed');
            },
            downloadAttachment: function (attachment) {
                let showToast = function (id) {
                    toaster.toast({ text: mozL10n.get(id) });
                };
                if (navigator.connection.type === 'none') {
                    this.noConnectionDialog();
                    return;
                }
                if (attachment.sizeEstimateInBytes > MAX_ATTCHMENT_SIZE) {
                    showToast('message-attachment-too-large');
                    return;
                }
                DeviceStorage.get().then(storage => {
                    if (!storage)
                        return;
                    storage.available().then(result => {
                        if (result !== 'available') {
                            console.error('Can not get available memory card to download!');
                        } else {
                            storage.freeSpace().then(result => {
                                console.log('free space:', result, attachment.sizeEstimateInBytes);
                                if (result > attachment.sizeEstimateInBytes) {
                                    this.doDownload(attachment);
                                } else {
                                    if (storage.storageName === 'sdcard') {
                                        showToast('storage-full');
                                    } else {
                                        showToast('storage-sdcard-full');
                                    }
                                }
                            });
                        }
                    });
                });
            },
            shareAttachmentHelper: function (attachment) {
                console.log('go to shareAttachmentHelper');
                this.bShare = false;
                this.getAttachmentBlob(attachment, blob => {
                    try {
                        if (!blob) {
                            throw new Error('Blob does not exist');
                        }
                        let useType = attachment.mimetype;
                        if (!useType || useType === OCTET_STREAM_TYPE) {
                            useType = blob.type;
                        }
                        if (!useType || useType === OCTET_STREAM_TYPE) {
                            useType = MimeMapper.guessTypeFromFileProperties(attachment.filename, OCTET_STREAM_TYPE);
                        }
                        if (!useType) {
                            useType = OCTET_STREAM_TYPE;
                        }
                        if (useType !== 'text/x-vcard' && useType !== 'text/vcard') {
                            useType = useType.split('/')[0] + '/*';
                        } else {
                            useType = 'text/vcard';
                        }
                        console.log('triggering share activity with MIME type:', useType);
                        let activity = new WebActivity('share', {
                            type: useType,
                            number: 1,
                            blobs: [blob],
                            filenames: [attachment.filename],
                            filepaths: [attachment.filename],
                            owner: 'email'
                        });
                        activity.start().then(() => {
                            console.log('"share" activity allegedly succeeded');
                        }, error => {
                            console.warn('Problem with "share" activity', error);
                        });
                    } catch (ex) {
                        console.warn('Problem creating "share" activity:', ex, '\n', ex.stack);
                    }
                });
            },
            shareAttachment: function (attachment) {
                console.log('go to shareAttachment, attachment is ' + attachment);
                if (attachment.isDownloaded && attachment._file) {
                    this.shareAttachmentHelper(attachment);
                } else if (!attachment.isDownloaded) {
                    console.log('not a downloaded attachment, downloading');
                    this.bShare = true;
                    this.downloadAttachment(attachment);
                    this.setSoftKey();
                }
            },
            noConnectionDialog: function () {
                let dialogConfig = {
                    title: {
                        id: 'confirmation-title',
                        args: {}
                    },
                    body: {
                        id: 'no-internet-connection',
                        args: {}
                    },
                    cancel: {
                        l10nId: 'opt-cancel',
                        priority: 1
                    },
                    confirm: {
                        l10nId: 'opt-settings',
                        priority: 3,
                        callback: () => {
                            let activity = new WebActivity('configure', {
                                target: 'device',
                                section: 'connectivity-settings'
                            });
                            activity.start().then(() => {
                                console.log('open activity success');
                            }, error => {
                                console.warn('Configure activity error:', error);
                            });
                        }
                    }
                };
                NavigationMap.showConfigDialog(dialogConfig);
            },
            notFoundFileDialog: function () {
                let dialogConfig = {
                    title: {
                        id: 'attachment-download',
                        args: {}
                    },
                    body: {
                        id: 'message-attachment-not-found',
                        args: {}
                    },
                    cancel: {
                        l10nId: 'opt-cancel',
                        priority: 1
                    },
                    confirm: {
                        l10nId: 'attachment-download',
                        priority: 3,
                        callback: () => {
                            this.currentItem.querySelector('.reader-view-attachment-downloaded-picture').classList.add('collapsed');
                            this.currentFocusedAttachment.resetDownloadState();
                            this.bView = true;
                            this.downloadAttachment(this.currentFocusedAttachment);
                        }
                    }
                };
                NavigationMap.showConfigDialog(dialogConfig);
            },
            onCardVisible: function (navDirection) {
                this.attachmentsKeydownHander = this.handleAttachmentsKeydown.bind(this);
                window.addEventListener('keydown', this.attachmentsKeydownHander);
                this.attachmentViewShown = true;
                this._refresh();
                this.setSoftKey();
                if (navDirection === 'forward') {
                    NavigationMap.setFocus('first');
                } else if (navDirection === 'back') {
                    NavigationMap.setFocus('restore');
                }
            },
            onHidden: function () {
                this.attachmentViewShown = false;
                window.removeEventListener('keydown', this.attachmentsKeydownHander);
            },
            navSetup: function () {
                let CARD_NAME = this.localName;
                let QUERY_CHILD = '.msg-reader-view-attachment-focusable';
                let CONTROL_ID = CARD_NAME + ' ' + QUERY_CHILD;
                NavigationMap.navSetup(CARD_NAME, QUERY_CHILD);
                NavigationMap.setCurrentControl(CONTROL_ID);
            },
            handleAttachmentsKeydown: function (evt) {
                switch (evt.key) {
                case 'Backspace':
                    if (option.menuVisible === false && !NavigationMap.configDialogShown()) {
                        evt.preventDefault();
                        this.onBack();
                    }
                    if (NavigationMap.configDialogShown()) {
                        evt.preventDefault();
                    }
                    break;
                }
            },
            _refresh: function () {
                console.log('go to messgae_reader_attachments --->_refresh');
                if (this.attachments && this.attachments.length) {
                    this.readerViewAttachmentsContainer.innerHTML = '';
                    let attachmentItemTemplate = attachmentItemNode;
                    let attachmentFileName = attachmentItemTemplate.querySelector('.reader-view-attachment-filename');
                    let attachmentFileSize = attachmentItemTemplate.querySelector('.reader-view-attachment-filesize');
                    for (let iAttach = 0; iAttach < this.attachments.length; iAttach++) {
                        let attachment = this.attachments[iAttach];
                        attachmentFileName.textContent = attachment.filename;
                        if (navigator.largeTextEnabled) {
                            attachmentFileName.classList.add('p-pri');
                            attachmentFileSize.classList.add('p-pri');
                        }
                        let extension = attachment.filename.split('.').pop();
                        let mimeClass = mimeToClass(attachment.mimetype || MimeMapper.guessTypeFromExtension(extension));
                        if (attachment.mimetype === 'application/zip') {
                            mimeClass = 'mime-zip';
                        } else if (attachment.mimetype === 'application/octet-stream' && extension) {
                            mimeClass = mimeToClass(MimeMapper.guessTypeFromExtension(extension));
                        }
                        fileDisplay.fileSize(attachmentFileSize, attachment.sizeEstimateInBytes);
                        let attachmentNode = attachmentItemTemplate.cloneNode(true);
                        attachmentNode.setAttribute('data-name', attachmentFileName.textContent);
                        attachmentNode.classList.add(mimeClass);
                        let attachementIcon = attachmentNode.querySelector('.reader-view-attachment-icon');
                        let attachementDataIcon = '';
                        switch (mimeClass) {
                        case 'mime-audio':
                            attachementDataIcon = 'file-audio';
                            break;
                        case 'mime-video':
                            attachementDataIcon = 'file-video';
                            break;
                        case 'mime-image':
                            attachementDataIcon = 'file-photo';
                            break;
                        case 'mime-zip':
                            attachementDataIcon = 'file-compress';
                            break;
                        case 'mime-text':
                            if (extension === 'vcf') {
                                attachementDataIcon = 'file-vcf';
                            } else {
                                attachementDataIcon = 'file';
                            }
                            break;
                        default:
                            attachementDataIcon = 'file';
                            break;
                        }
                        attachementIcon.setAttribute('data-icon', attachementDataIcon);
                        let downloadedImg = attachmentNode.querySelector('.reader-view-attachment-downloaded-picture');
                        let downloadingImg = attachmentNode.querySelector('.reader-view-attachment-downloading');
                        if (attachment.isDownloaded) {
                            downloadedImg.classList.remove('collapsed');
                            downloadingImg.classList.add('collapsed');
                        } else {
                            if (attachment.isDownloading) {
                                downloadingImg.classList.remove('collapsed');
                                downloadedImg.classList.add('collapsed');
                            } else {
                                downloadedImg.classList.add('collapsed');
                                downloadingImg.classList.add('collapsed');
                            }
                        }
                        this.readerViewAttachmentsContainer.appendChild(attachmentNode);
                    }
                }
                this.viewAttachmentsLabel.innerHTML = this.attachmentsHeader;
                this.navSetup();
            },
            setSoftKey: function () {
                let params = [];
                if (!this.currentFocusedAttachment.isDownloaded && !this.currentFocusedAttachment.isDownloading && this.currentFocusedAttachment.isDownloadable) {
                    params.push({
                        name: 'Download',
                        l10nId: 'attachment-download',
                        priority: 1,
                        method: () => {
                            if (!model.account.enabled) {
                                let attachmentDownloading = this.currentItem.querySelector('.reader-view-attachment-downloading');
                                if (attachmentDownloading.classList.contains('collapsed')) {
                                    attachmentDownloading.classList.remove('collapsed');
                                }
                                model.account.clearProblems(true, () => {
                                    this.downloadAttachment(this.currentFocusedAttachment);
                                });
                            } else {
                                this.downloadAttachment(this.currentFocusedAttachment);
                            }
                        }
                    });
                }
                if (!this.currentFocusedAttachment.isDownloading) {
                    params.push({
                        name: 'Select',
                        l10nId: 'select',
                        priority: 2,
                        method: () => {
                            this.onViewAttachment(this.currentFocusedAttachment);
                        }
                    });
                    if (this.currentFocusedAttachment.isDownloadable) {
                        params.push({
                            name: 'Share',
                            l10nId: 'attachment-share',
                            priority: 3,
                            method: () => {
                                this.shareAttachment(this.currentFocusedAttachment);
                            }
                        });
                    }
                }
                NavigationMap.setSoftKeyBar(params);
            },
            onFocusChanged: function (queryChild, index, item) {
                console.log(this.localName + '.onFocusChanged, queryChild=' + queryChild + ', index=' + index);
                if (this.attachments[index] !== this.currentFocusedAttachment) {
                    this.bShare = false;
                    this.bView = false;
                    this.currentFocusedAttachment = this.attachments[index];
                }
                this.currentItem = item;
                this.setSoftKey();
            }
        }
    ];
});