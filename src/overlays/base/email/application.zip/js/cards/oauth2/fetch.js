define(function (require) {
    let queryString = require('query_string');
    let services = require('services');
    let oauthSecrets = services.oauth2;
    let curOauthSecrets;
    let redeemingCode = false;
    const TIMEOUT_MS = 30 * 1000;
    const redirectUri = 'http://localhost/redirect/email/js/cards/oauth2/redirect.html';
    let deferred, p, oauthSettings, oauthWindow, winIntervalId, codeVerifier;
    const WINDOW_TIMER_INTERVAL = 300;
    const state = 'KaiOSMail628842';
    function clearOauthPageCache() {
        const url = new URL(oauthSettings.authEndpoint);
        AppsManager.clear(url.origin, 0);
    }
    function onBrowserComplete(evt) {
        window.removeEventListener('message', onBrowserComplete);
        let message = evt.data;
        let data = message.data;
        if (message.type === 'oauth2Complete') {
            if (!data.code) {
                reset('reject', new Error('no code returned'));
                return;
            }
            if (data.state !== state) {
                reset('reject', new Error('return state error'));
                return;
            }
            console.log('oauth redirect returned with code');
            redeemingCode = true;
            redeemCode(data.code).then(redeemed => {
                let expiresInMS = parseInt(redeemed.expires_in, 10) * 1000;
                let expireTimeMS = Date.now() + Math.max(0, expiresInMS - TIMEOUT_MS);
                let result = {
                    status: 'success',
                    tokens: {
                        accessToken: redeemed.access_token,
                        refreshToken: redeemed.refresh_token,
                        expireTimeMS: expireTimeMS
                    },
                    secrets: curOauthSecrets
                };
                reset('resolve', result);
            }, err => {
                reset('reject', err);
            });
        } else {
            reset('resolve', { status: 'cancel' });
        }
    }
    function redeemCode(code) {
        console.log('redeeming oauth code');
        return new Promise((xhrResolve, xhrReject) => {
            let xhr = new XMLHttpRequest({ mozSystem: true });
            xhr.open('POST', oauthSettings.tokenEndpoint, true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.timeout = TIMEOUT_MS;
            xhr.onload = function () {
                if (xhr.status < 200 || xhr.status >= 300) {
                    console.error('token redemption failed', xhr.status, xhr.responseText);
                    xhrReject('status' + xhr.status);
                } else {
                    try {
                        let data = JSON.parse(xhr.responseText);
                        console.log('oauth code redeemed. access_token? ' + !!data.access_token + ', refresh_token? ' + !!data.refresh_token);
                        xhrResolve(data);
                    } catch (ex) {
                        console.error('badly formed JSON response for token redemption:', xhr.responseText);
                        xhrReject(ex);
                    }
                }
            };
            xhr.onerror = err => {
                console.error('token redemption weird error:', err);
                xhrReject(err);
            };
            xhr.ontimeout = () => {
                console.error('token redemption timeout');
                xhrReject('timeout');
            };
            let redemptionArgs = {
                code: code,
                client_id: curOauthSecrets.clientId,
                redirect_uri: redirectUri,
                grant_type: 'authorization_code'
            };
            if (curOauthSecrets.codeVerifier) {
                redemptionArgs.code_verifier = curOauthSecrets.codeVerifier;
            }
            if (curOauthSecrets.clientSecret) {
                redemptionArgs.client_secret = curOauthSecrets.clientSecret;
            }
            xhr.send(queryString.fromObject(redemptionArgs));
        });
    }
    function dialogHeartbeat() {
        if ((!oauthWindow || oauthWindow.closed) && !redeemingCode) {
            reset('resolve', { status: 'cancel' });
        }
    }
    function reset(actionName, value) {
        console.log('oauth2 fetch reset with action: ' + actionName);
        let action = deferred[actionName];
        if (winIntervalId) {
            clearInterval(winIntervalId);
            winIntervalId = null;
        }
        if (oauthWindow && !oauthWindow.closed) {
            oauthWindow.close();
        }
        deferred = p = oauthWindow = null;
        redeemingCode = false;
        action(value);
    }
    function base64Encode(bytes) {
        const binString = Array.from(bytes, byte => String.fromCodePoint(byte)).join('');
        return btoa(binString).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
    }
    async function getChallenge() {
        if (!codeVerifier) {
            const iv = window.crypto.getRandomValues(new Uint8Array(32));
            codeVerifier = base64Encode(iv);
        }
        const msgUint8 = new TextEncoder().encode(codeVerifier);
        const hashBuffer = await window.crypto.subtle.digest('SHA-256', msgUint8);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = base64Encode(hashArray);
        return hashHex;
    }
    return async (o2Settings, extraQueryObject) => {
        if (deferred) {
            reset('reject', new Error('Multiple oauth calls, starting new one'));
        }
        p = new Promise((res, rej) => {
            deferred = {
                resolve: res,
                reject: rej
            };
        });
        oauthSettings = o2Settings;
        codeVerifier = o2Settings.codeVerifier || null;
        curOauthSecrets = undefined;
        if (o2Settings.clientId) {
            curOauthSecrets = {
                clientId: o2Settings.clientId,
                clientSecret: o2Settings.clientSecret
            };
        } else if (o2Settings.secretGroup) {
            curOauthSecrets = oauthSecrets[o2Settings.secretGroup];
        }
        if (!curOauthSecrets) {
            reset('reject', new Error('no secrets for group: ' + o2Settings.secretGroup));
            return p;
        }
        let authEndpointQuery = {
            client_id: curOauthSecrets.clientId,
            redirect_uri: redirectUri,
            response_type: 'code',
            response_mode: 'query',
            scope: o2Settings.scope,
            state: state,
            prompt: 'consent'
        };
        if (curOauthSecrets.usePKCE || codeVerifier) {
            const codeChallenge = await getChallenge();
            Object.assign(authEndpointQuery, {
                code_challenge: codeChallenge,
                code_challenge_method: 'S256'
            });
        }
        curOauthSecrets.codeVerifier = codeVerifier;
        let url = o2Settings.authEndpoint + '?' + queryString.fromObject(authEndpointQuery);
        if (extraQueryObject) {
            let extraArgs = queryString.fromObject(extraQueryObject);
            if (extraArgs) {
                url += '&' + extraArgs;
            }
        }
        window.addEventListener('message', onBrowserComplete);
        oauthWindow = window.open(url, '', 'dialog');
        winIntervalId = setInterval(dialogHeartbeat, WINDOW_TIMER_INTERVAL);
        return p;
    };
});