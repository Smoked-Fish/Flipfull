const Redirect = function Redirect() {
    const init = function init() {
        const url = window.location.href;
        const search = url.split('?')[1] || '';
        let result = {
            type: 'oauth2Complete',
            data: {}
        };
        if (search.length > 0) {
            const elements = search.split('&');
            elements.forEach(p => {
                const values = p.split('=');
                result.data[decodeURIComponent(values[0])] = decodeURIComponent(values[1]);
            });
            window.opener.postMessage(result, window.location.origin);
        }
        window.close();
    };
    return { 'init': init };
}();
Redirect.init();