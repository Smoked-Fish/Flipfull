define([
    'require',
    'cards',
    'l10n!',
    'evt',
    './base',
    'template!./setup_account_prefs.html',
    './editor_mixins',
    './account_prefs_mixins'
], function (require) {
    let cards = require('cards'), mozL10n = require('l10n!'), evt = require('evt'), trailingRegExp = /\s+$/;
    return [
        require('./base')(require('template!./setup_account_prefs.html')),
        require('./editor_mixins'),
        require('./account_prefs_mixins'),
        {
            onArgs: function (args) {
                this.account = args.account;
                this.autoSetup = args.autoSetup;
                this.identity = this.account.identities[0];
                this.signatureNodePref.innerHTML = '<br>';
                this.identity.modifyIdentity({
                    signatureEnabled: true,
                    signature: mozL10n.get('settings-default-signature-2')
                });
                navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name').then(operator => {
                    dump('email setup_account_prefs:: operator = ' + operator);
                    var sim_type;
                    navigator.b2g.engmodeManager.getPropertyValue('persist.gsm.sim.tmo.type').then(result => {
                        sim_type = result;
                        console.log('sim_type is> :', sim_type);
                        dump('settings  sim_type= is>\uFF1A' + sim_type);
                        navigator.b2g.engmodeManager.getPropertyValue('persist.gsm.sim.tmo.type.1').then(result1 => {
                            console.log('>sim_type is :', result1);
                            dump('>settings  sim_type= is\uFF1A' + result1);
                            if (sim_type == '' || sim_type == 'unknown') {
                                console.log('>sim_type is >:', sim_type == '');
                                dump('>settings  sim_type= is >\uFF1A' + (sim_type == ''));
                                sim_type = result1;
                            }
                            if (operator === 'TMO') {
                                let modelName;
                                dump('email setup_progress:: [CU Logic] detected operator = TMO, checking ro.tct.curef ...');
                                console.log('email setup_progress:: [CU Logic] detected operator = TMO, checking ro.tct.curef ...');
                                navigator.b2g.engmodeManager.getPropertyValue('ro.tct.curef').then(prop_cu => {
                                    dump('email setup_progress:: [CU Logic] raw ro.tct.curef = ' + prop_cu);
                                    console.log('email setup_progress:: [CU Logic] raw ro.tct.curef =', prop_cu);
                                    if (prop_cu && prop_cu.length >= 10) {
                                        let subStr = prop_cu.substring(8, 10);
                                        console.log('email setup_account_prefs:: cu substring[8,10] =', subStr);
                                        dump('email setup_account_prefs:: [CU Logic] substring[8,10] = ' + subStr);
                                        let modelName;
                                        if (subStr == '3U') {
                                            modelName = mozL10n.get('email-signature-cu');
                                            dump('email setup_account_prefs:: [CU Logic] raw modelName = ' + modelName);
                                            console.log('email setup_account_prefs:: [CU Logic] raw modelName =', modelName);
                                        } else if (sim_type == 'MPCS') {
                                            dump('email setup_account_prefs isMetroPCS');
                                            modelName = mozL10n.get('email-signature-gf5g-tmo-metropcs-model-name');
                                        } else if (sim_type == 'ASW') {
                                            dump('email setup_account_prefs isAssurance');
                                            modelName = mozL10n.get('email-signature-gf5g-tmo-assurance-model-name');
                                        } else {
                                            dump('email setup_account_prefs isTMO');
                                            modelName = mozL10n.get('email-signature-gf5g-tmo');
                                        }
                                        dump('email setup_account_prefs:: modelName ==>  ' + modelName);
                                        if (modelName !== undefined && modelName !== '') {
                                            var tmoSignature = mozL10n.get('email-signature', { board: modelName });
                                            this.identity.modifyIdentity({
                                                signatureEnabled: true,
                                                signature: tmoSignature
                                            });
                                        }
                                        if (this.autoSetup) {
                                            this.lastAccount = args.lastAccount;
                                        }
                                        this._bindPrefs('', '', 'tng-sound-onsend', 'tng-signature-enable', 'signature-box', 'pref-account-label');
                                        this._bindEditor(this.signatureNodePref);
                                    }
                                });
                            } else if (operator === 'VZW') {
                                let modelName;
                                modelName = mozL10n.get('email-signature-vzw');
                                dump('email setup_account_prefs:: modelName ==>  ' + modelName);
                                if (modelName !== undefined && modelName !== '') {
                                    var vzwSignature = mozL10n.get('email-signature', { board: modelName });
                                    this.identity.modifyIdentity({ signature: vzwSignature });
                                }
                                if (this.autoSetup) {
                                    this.lastAccount = args.lastAccount;
                                }
                                this._bindPrefs('', '', 'tng-sound-onsend', 'tng-signature-enable', 'signature-box', 'pref-account-label');
                                this._bindEditor(this.signatureNodePref);
                            } else if (operator === 'USCC') {
                                let modelName;
                                modelName = mozL10n.get('email-signature-uscc');
                                dump('email setup_account_prefs:: modelName ==>  ' + modelName);
                                if (modelName !== undefined && modelName !== '') {
                                    var usccSignature = mozL10n.get('email-signature', { board: modelName });
                                    this.identity.modifyIdentity({ signature: usccSignature });
                                }
                                if (this.autoSetup) {
                                    this.lastAccount = args.lastAccount;
                                }
                                this._bindPrefs('', '', 'tng-sound-onsend', 'tng-signature-enable', 'signature-box', 'pref-account-label');
                                this._bindEditor(this.signatureNodePref);
                            } else if (operator === 'TF') {
                                let modelName;
                                modelName = mozL10n.get('email-signature-tf');
                                dump('email setup_account_prefs:: modelName ==>  ' + modelName);
                                if (modelName !== undefined && modelName !== '') {
                                    var tfSignature = mozL10n.get('email-signature', { board: modelName });
                                    this.identity.modifyIdentity({ signature: tfSignature });
                                }
                                if (this.autoSetup) {
                                    this.lastAccount = args.lastAccount;
                                }
                                this._bindPrefs('', '', 'tng-sound-onsend', 'tng-signature-enable', 'signature-box', 'pref-account-label');
                                this._bindEditor(this.signatureNodePref);
                            } else if (operator === 'USOM') {
                                let modelName;
                                modelName = mozL10n.get('email-signature-usom');
                                dump('email setup_account_prefs:: modelName ==>  ' + modelName);
                                if (modelName !== undefined && modelName !== '') {
                                    var usomSignature = mozL10n.get('email-signature', { board: modelName });
                                    this.identity.modifyIdentity({ signature: usomSignature });
                                }
                                if (this.autoSetup) {
                                    this.lastAccount = args.lastAccount;
                                }
                                this._bindPrefs('', '', 'tng-sound-onsend', 'tng-signature-enable', 'signature-box', 'pref-account-label');
                                this._bindEditor(this.signatureNodePref);
                            } else if (operator === 'EE') {
                                let modelName;
                                modelName = mozL10n.get('email-signature-ee');
                                dump('email setup_account_prefs:: modelName ==>  ' + modelName);
                                if (modelName !== undefined && modelName !== '') {
                                    var eeSignature = mozL10n.get('email-signature', { board: modelName });
                                    this.identity.modifyIdentity({ signature: eeSignature });
                                }
                                if (this.autoSetup) {
                                    this.lastAccount = args.lastAccount;
                                }
                                this._bindPrefs('', '', 'tng-sound-onsend', 'tng-signature-enable', 'signature-box', 'pref-account-label');
                                this._bindEditor(this.signatureNodePref);
                            } else {
                                if (this.autoSetup) {
                                    this.lastAccount = args.lastAccount;
                                }
                                this._bindPrefs('', '', 'tng-sound-onsend', 'tng-signature-enable', 'signature-box', 'pref-account-label');
                                this._bindEditor(this.signatureNodePref);
                            }
                        });
                    });
                });
            },
            getTextFromEditor: function () {
                return this.fromEditor().replace(trailingRegExp, '');
            },
            onNext: function () {
                let signature = this.getTextFromEditor();
                let accountLabel = this.prefAccountLabelNode.value.trim();
                if (signature !== this.identity.signature) {
                    this.identity.modifyIdentity({ signature: signature });
                }
                if (accountLabel !== this.account.label) {
                    this.account.modifyAccount({ label: accountLabel });
                }
                if (this.autoSetup) {
                    evt.emit('autoAddDone');
                    cards.removeCardAndSuccessors(this, 'immediate', 1);
                } else {
                    cards.pushCard('setup_done', 'animate');
                }
            },
            updateFocusList: function () {
                NavigationMap.navSetup('cards-setup-account-prefs', 'cards-setup-account-prefs ul li:not(.hidden)');
            },
            handleKeyDown: function (e) {
                switch (e.key) {
                case 'Accept':
                case 'Enter':
                    let selectEl = document.querySelector('.scrollregion-below-header' + ' .focus select');
                    if (selectEl) {
                        selectEl.focus();
                    }
                    break;
                }
                if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
                    setTimeout(() => {
                        this.updateSK();
                    }, 0);
                }
            },
            onBodyNodeKeydown: function (evt) {
                let range = window.getSelection().getRangeAt(0);
                let currentElement = range.startContainer;
                switch (evt.key) {
                case 'ArrowUp':
                    if ((currentElement === document.activeElement || currentElement === document.activeElement.firstChild) && (range.startOffset === 0 || currentElement.textContent.length === 0)) {
                        break;
                    }
                    evt.stopPropagation();
                    break;
                case 'ArrowDown':
                    if (currentElement === document.activeElement && isLastLine(range) || isLastNode(range)) {
                        break;
                    }
                    evt.stopPropagation();
                    break;
                }
                function isLastLine(range) {
                    if (document.activeElement.lastChild.tagName === 'BR' && range.startOffset === document.activeElement.childNodes.length - 1) {
                        return true;
                    } else if (range.startOffset === document.activeElement.childNodes.length) {
                        return true;
                    }
                    return false;
                }
                function isLastNode(range) {
                    return range.startOffset === range.startContainer.length;
                }
            },
            onInfoInput: function () {
                this.updateSK();
            },
            updateSK: function () {
                let str = '';
                let strId = '';
                if (document.activeElement.classList.contains('signature-box')) {
                    str = 'Enter';
                    strId = 'enter';
                } else if (!document.activeElement.classList.contains('no-select')) {
                    str = 'Select';
                    strId = 'select';
                }
                let OptSelect = {
                    name: str,
                    l10nId: strId,
                    priority: 2
                };
                let optNext = {
                    name: 'Next',
                    l10nId: 'setup-info-next',
                    priority: 3,
                    method: () => {
                        this.onNext();
                    }
                };
                let params = [OptSelect];
                if (this.prefAccountLabelNode.value.trim().length) {
                    params.push(optNext);
                }
                NavigationMap.setSoftKeyBar(params);
            },
            onCardVisible: function (navDirection) {
                const CARD_NAME = this.localName;
                const QUERY_CHILD = CARD_NAME + ' ' + 'ul li:not(.hidden)';
                const CONTROL_ID = CARD_NAME + ' ' + QUERY_CHILD;
                let menuOptions = [{
                        name: 'Next',
                        l10nId: 'setup-info-next',
                        priority: 3,
                        method: () => {
                            this.onNext();
                        }
                    }];
                this.prefAccountLabelNode.parentNode.addEventListener('focus', () => {
                    this.prefAccountLabelNode.focus();
                    this.prefAccountLabelNode.setSelectionRange(9999, 9999);
                });
                console.log(this.localName + '.onCardVisible, navDirection=' + navDirection);
                if (navDirection === 'forward') {
                    NavigationMap.navSetup(CARD_NAME, QUERY_CHILD);
                    NavigationMap.setCurrentControl(CONTROL_ID);
                    NavigationMap.setFocus('first');
                    NavigationMap.setSoftKeyBar(menuOptions);
                } else if (navDirection === 'back') {
                    NavigationMap.setCurrentControl(CONTROL_ID);
                    NavigationMap.setFocus('restore');
                    NavigationMap.setSoftKeyBar(menuOptions);
                }
                this.keydownHandler = this.handleKeyDown.bind(this);
                window.addEventListener('keydown', this.keydownHandler);
                document.addEventListener('update-list', this.updateFocusList);
                this.updateSignatureBox();
                let signatureNode = document.querySelector('cards-setup-account-prefs .signature-box');
                let signatureNodeParentLi = document.querySelector('cards-setup-account-prefs ' + '.settings-account-signature');
                signatureNodeParentLi.addEventListener('focus', evt => {
                    signatureNode.focus();
                    if (evt.relatedTarget && !evt.relatedTarget.classList.contains('signature-box')) {
                        let selection = window.getSelection();
                        let range = document.createRange();
                        let lastChild = signatureNode.lastElementChild;
                        if (lastChild.nodeName === 'BR') {
                            range.setStartBefore(lastChild);
                        } else {
                            range.setStartAfter(lastChild);
                        }
                        selection.removeAllRanges();
                        selection.addRange(range);
                    }
                });
                document.execCommand('defaultParagraphSeparator', false, 'br');
            },
            onHidden: function () {
                window.removeEventListener('keydown', this.keydownHandler);
            },
            die: function () {
                window.removeEventListener('keydown', this.keydownHandler);
                document.removeEventListener('update-list', this.updateFocusList);
            }
        }
    ];
});