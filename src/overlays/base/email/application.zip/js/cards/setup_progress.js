define([
    'require',
    'api',
    'cards',
    'html_cache',
    'cards/oauth2/fetch',
    'evt',
    'l10n!',
    'accounts_sync',
    './base',
    'template!./setup_progress.html'
], function (require) {
    let MailAPI = require('api'), cards = require('cards'), htmlCache = require('html_cache'), oauthFetch = require('cards/oauth2/fetch'), evt = require('evt'), mozL10n = require('l10n!'), accountsSync = require('accounts_sync');
    return [
        require('./base')(require('template!./setup_progress.html')),
        {
            onArgs: function (args) {
                this.args = args;
                this.callingCard = args.callingCard;
                this.creationInProcess = true;
                this.pushedSecondaryCard = false;
                this.cardHasBeenShown = false;
                this.createOnBackground = false;
                this.createCanceled = false;
                this.activity = args.activity;
                this.autoSetup = args.autoSetup !== undefined ? args.autoSetup : false;
                this.globalAccount = false;
                if (this.autoSetup) {
                    this.setupProgressWait.setAttribute('data-l10n-id', 'setup-sync-progress-wait-msg');
                } else {
                    this.setupProgressWait.setAttribute('data-l10n-id', 'setup-progress-wait-msg');
                }
                if (document.hidden && this.autoSetup) {
                    this.onCardVisible();
                    this.createOnBackground = true;
                }
            },
            extraClasses: [
                'anim-fade',
                'anim-overlay'
            ],
            cancelCreation: function () {
                if (!this.creationInProcess) {
                    return;
                }
                this.creationInProcess = false;
                MailAPI._cancelCreation(this.args.emailAddress);
            },
            handleKeyDown: function (e) {
                if (this.className.indexOf('card center') > 0) {
                    switch (e.key) {
                    case 'Backspace':
                        e.preventDefault();
                        if (!this.autoSetup) {
                            this.onBack();
                        } else {
                            e.stopPropagation();
                        }
                        break;
                    }
                }
            },
            onCardVisible: function () {
                if (this.createOnBackground) {
                    return;
                }
                let menuOptions = [];
                if (!this.autoSetup) {
                    menuOptions.push({
                        name: 'Cancel',
                        l10nId: 'cancel',
                        priority: 1,
                        method: () => {
                            this.onBack();
                        }
                    });
                }
                NavigationMap.setSoftKeyBar(menuOptions);
                this.keydownHandler = this.handleKeyDown.bind(this);
                window.addEventListener('keydown', this.keydownHandler);
                if (this.cardHasBeenShown) {
                    if (this.pushedSecondaryCard) {
                        setTimeout(this.onBack.bind(this), 100);
                    }
                } else {
                    this.cardHasBeenShown = true;
                    if (this.autoSetup) {
                        if (!this.args.password) {
                            this.learnAbout();
                        } else {
                            this.tryCreate();
                        }
                    } else {
                        if (this.activity) {
                            let account = accountsSync.checkAccountExist(this.args.emailAddress);
                            if (account) {
                                accountsSync.getCredential(account, false).then(credential => {
                                    let nAccount = {
                                        name: account.accountId,
                                        username: credential.username,
                                        password: credential.password,
                                        type: account.authenticatorId,
                                        configInfo: credential.configInfo
                                    };
                                    const result = {
                                        activityHandlerId: this.activity.activityHandlerId,
                                        activityResult: 'complete',
                                        isError: false
                                    };
                                    navigator.serviceWorker.controller.postMessage(result);
                                    this.activity = null;
                                    evt.emit('userAddDone', {
                                        account: nAccount,
                                        activity: true
                                    });
                                });
                            } else {
                                this.tryCreate();
                            }
                        } else {
                            if (!this.args.password) {
                                this.learnAbout();
                            } else {
                                this.checkAndCreateAccount();
                            }
                        }
                    }
                }
            },
            onBack: function (e) {
                if (e) {
                    e.preventDefault();
                }
                this.cancelCreation();
                if (!this.createCanceled) {
                    cards.removeCardAndSuccessors(this, 'animate', 1);
                }
                this.createCanceled = true;
            },
            checkAndCreateAccount: function (learnAboutResult = '') {
                let accountType = this.args.configInfo ? this.args.configInfo.type : null;
                let data = {
                    address: this.args.emailAddress,
                    type: accountType
                };
                MailAPI.checkAndUpdateAccount(data, result => {
                    if (!result.bExist || result.bExist && result.type !== accountType) {
                        if (this.args.type === 'activesync') {
                            let account = accountsSync.checkAccountExist(this.args.emailAddress);
                            if (account) {
                                let data = {
                                    account: account,
                                    reEnable: true
                                };
                                evt.emit('accountSyncChanged', data);
                                cards.removeCardAndSuccessors(this, 'animate', 1);
                            }
                        } else {
                            this.learnAboutResult(learnAboutResult);
                        }
                    } else if (result.id) {
                        let data = {
                            id: result.id,
                            reEnable: true
                        };
                        evt.emit('accountSyncChanged', data);
                        cards.removeCardAndSuccessors(this, 'animate', 1);
                    } else {
                        this.onCreationError('user-account-exists');
                        return true;
                    }
                });
            },
            learnAbout: function () {
                MailAPI.learnAboutAccount({ emailAddress: this.args.emailAddress }, details => {
                    if (!this.creationInProcess) {
                        return;
                    }
                    this.args.configInfo = details.configInfo;
                    let result = details.result;
                    this.checkAndCreateAccount(result);
                });
            },
            learnAboutResult: function (result) {
                if (result === 'need-oauth2') {
                    if (this.autoSetup) {
                        this.args.configInfo.oauth2Tokens = this.args.oauth2Tokens;
                        this.tryCreate();
                    } else {
                        let group = this.args.configInfo.oauth2Settings.secretGroup;
                        if ('google' !== group) {
                            return this.localOauth2Create();
                        }
                        let extraInfo = {
                            loginHint: this.args.emailAddress,
                            hideUsedPage: true
                        };
                        let account = {
                            accountId: this.args.emailAddress,
                            authenticatorId: group
                        };
                        accountsSync.showLoginPage(group, extraInfo).then(result => {
                            this.globalAccount = true;
                            account.accountId = result.accountId;
                            account.authenticatorId = result.authenticatorId;
                            accountsSync.getCredential(account, false).then(credential => {
                                this.args.authenticatorId = group;
                                this.args.configInfo.oauth2Tokens = {
                                    accessToken: credential.access_token,
                                    expireTimeMS: credential.expire_timestamp
                                };
                                this.tryCreate();
                            }, () => {
                                this.onCreationError('unknown');
                            });
                        }, err => {
                            let errId;
                            switch (err) {
                            case 'no network':
                                errId = 'offline';
                                break;
                            case 'duplicate_account':
                                errId = 'user-account-exists';
                                break;
                            case 'login interrupted':
                                break;
                            default:
                                errId = 'unknown';
                                break;
                            }
                            if (errId) {
                                this.onCreationError(errId);
                            }
                            this.onBack();
                        });
                    }
                } else if (result === 'need-password') {
                    this.pushedSecondaryCard = true;
                    cards.pushCard('setup_account_password', 'animate', {
                        displayName: this.args.displayName,
                        emailAddress: this.args.emailAddress,
                        configInfo: this.args.configInfo
                    }, 'right');
                } else if (result === 'no-config-info') {
                    this._divertToManualConfig();
                } else {
                    this.tryCreate();
                }
            },
            _divertToManualConfig: function () {
                this.pushedSecondaryCard = true;
                cards.pushCard('setup_manual_config', 'animate', {
                    displayName: this.args.displayName,
                    emailAddress: this.args.emailAddress
                }, 'right');
            },
            localOauth2Create: function () {
                oauthFetch(this.args.configInfo.oauth2Settings, { login_hint: this.args.emailAddress }).then(response => {
                    if (response.status === 'cancel') {
                        this.onBack();
                    } else if (response.status === 'success') {
                        this.args.configInfo.oauth2Secrets = response.secrets;
                        this.args.configInfo.oauth2Tokens = response.tokens;
                        this.tryCreate();
                    } else {
                        console.error('Unknown oauthFetch status: ' + response.status);
                        this._divertToManualConfig();
                    }
                }, this.onCreationError.bind(this));
            },
            getDeviceImei: function () {
                let connection;
                if (navigator.b2g.mobileConnections) {
                    connection = navigator.b2g.mobileConnections[0];
                }
                return new Promise((resolve, reject) => {
                    let errorMsg;
                    if (!connection) {
                        errorMsg = 'No mobileConnections!';
                        reject(errorMsg);
                    }
                    let getDeviceId = connection.getDeviceIdentities();
                    if (getDeviceId) {
                        resolve(getDeviceId.imei);
                    } else {
                        errorMsg = 'Could not retrieve the IMEI code';
                        reject(errorMsg);
                    }
                });
            },
            getDeviceId: function (id) {
                let deviceId = id;
                return new Promise(resolve => {
                    if (deviceId) {
                        resolve(deviceId);
                    } else {
                        this.getDeviceImei().then(value => {
                            if (!deviceId) {
                                if (value) {
                                    deviceId = 'KaiOS' + value;
                                } else {
                                    deviceId = Math.random().toString(36).substr(2);
                                }
                                resolve(deviceId);
                            }
                        });
                    }
                });
            },
            tryCreate: function () {
                if (!this.creationInProcess) {
                    return;
                }
                let args = this.args;
                let id;
                if (this.args.configInfo && this.args.configInfo.incoming) {
                    id = this.args.configInfo.incoming.deviceId;
                }
                this.getDeviceId(id).then(deviceId => {
                    let options = {
                        displayName: args.displayName,
                        emailAddress: args.emailAddress,
                        password: args.password,
                        outgoingPassword: args.outgoingPassword,
                        deviceId: deviceId,
                        authenticatorId: args.authenticatorId
                    };
                    MailAPI.tryToCreateAccount(options, args.configInfo || null, (err, errDetails, account) => {
                        this.creationInProcess = false;
                        if (err) {
                            this.onCreationError(err, errDetails);
                        } else {
                            if (this.createCanceled) {
                                account.deleteAccount();
                            } else {
                                this.onCreationSuccess(account);
                            }
                        }
                    });
                });
            },
            onCreationError: function (err, errDetails) {
                if (this.autoSetup) {
                    evt.emit('autoAddDone');
                } else {
                    this.callingCard.showError(err, errDetails);
                }
                cards.removeCardAndSuccessors(this, 'animate', 1);
            },
            onCreationSuccess: function (account) {
                if (!this.activity) {
                    htmlCache.reset();
                }
                if (this.globalAccount) {
                    account.modifyAccount({ public: true });
                    if (!this.autoSetup) {
                        cards.pushCard('setup_account_usedInfo', 'animate', {
                            account: account,
                            activity: this.activity
                        });
                    } else {
                        if (document.hidden) {
                            this.identity = account.identities[0];
                            this.identity.modifyIdentity({
                                signatureEnabled: true,
                                signature: mozL10n.get('settings-default-signature-2')
                            });
                            navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name').then(operator => {
                                dump('email setup_progress:: operator = ' + operator);
                                console.log('error is operator:' + operator);
                                var sim_type;
                                navigator.b2g.engmodeManager.getPropertyValue('persist.gsm.sim.tmo.type').then(result => {
                                    sim_type = result;
                                    console.log('sim_type is :', sim_type);
                                    dump('settings  sim_type  is=' + sim_type);
                                    navigator.b2g.engmodeManager.getPropertyValue('persist.gsm.sim.tmo.type.1').then(result1 => {
                                        console.log('sim_type are :', result1);
                                        dump('settings  sim_type  are=' + result1);
                                        if (sim_type == '' || sim_type == 'unknown') {
                                            sim_type = result1;
                                        }
                                        if (operator === 'TMO') {
                                            let modelName;
                                            dump('email setup_progress:: [CU Logic] detected operator = TMO, checking ro.tct.curef ...');
                                            console.log('email setup_progress:: [CU Logic] detected operator = TMO, checking ro.tct.curef ...');
                                            navigator.b2g.engmodeManager.getPropertyValue('ro.tct.curef').then(prop_cu => {
                                                dump('email setup_progress:: [CU Logic] raw ro.tct.curef = ' + prop_cu);
                                                console.log('email setup_progress:: [CU Logic] raw ro.tct.curef =', prop_cu);
                                                if (prop_cu && prop_cu.length >= 10) {
                                                    let subStr = prop_cu.substring(8, 10);
                                                    console.log('email setup_progress:: cu substring[8,10] =', subStr);
                                                    dump('email setup_progress:: [CU Logic] substring[8,10] = ' + subStr);
                                                    let modelName;
                                                    if (subStr == '3U') {
                                                        modelName = mozL10n.get('email-signature-cu');
                                                        dump('email setup_progress:: [CU Logic] raw modelName = ' + modelName);
                                                        console.log('email setup_progress:: [CU Logic] raw modelName =', modelName);
                                                    } else if (sim_type == 'MPCS') {
                                                        dump('email setup_account_prefs isMetroPCS');
                                                        modelName = mozL10n.get('email-signature-gf5g-tmo-metropcs-model-name');
                                                    } else if (sim_type == 'ASW') {
                                                        dump('email setup_account_prefs isAssurance');
                                                        modelName = mozL10n.get('email-signature-gf5g-tmo-assurance-model-name');
                                                    } else {
                                                        dump('email setup_account_prefs isTMO');
                                                        modelName = mozL10n.get('email-signature-gf5g-tmo');
                                                    }
                                                    dump('email setup_account_prefs:: modelName ==>  ' + modelName);
                                                    dump('email setup_progress:: modelName ==>  ' + modelName);
                                                    if (modelName !== undefined && modelName !== '') {
                                                        var tmoSignature = mozL10n.get('email-signature', { board: modelName });
                                                        this.identity.modifyIdentity({
                                                            signatureEnabled: true,
                                                            signature: tmoSignature
                                                        });
                                                    }
                                                    evt.emit('autoAddDone');
                                                }
                                            });
                                        } else if (operator === 'VZW') {
                                            let modelName;
                                            modelName = mozL10n.get('email-signature-vzw');
                                            dump('email setup_progress:: modelName ==>  ' + modelName);
                                            if (modelName !== undefined && modelName !== '') {
                                                var vzwSignature = mozL10n.get('email-signature', { board: modelName });
                                                this.identity.modifyIdentity({
                                                    signatureEnabled: true,
                                                    signature: vzwSignature
                                                });
                                            }
                                            evt.emit('autoAddDone');
                                        } else if (operator === 'USCC') {
                                            let modelName;
                                            modelName = mozL10n.get('email-signature-uscc');
                                            dump('email setup_progress:: modelName ==>  ' + modelName);
                                            if (modelName !== undefined && modelName !== '') {
                                                var usccSignature = mozL10n.get('email-signature', { board: modelName });
                                                this.identity.modifyIdentity({ signature: usccSignature });
                                            }
                                            evt.emit('autoAddDone');
                                        } else if (operator === 'TF') {
                                            let modelName;
                                            modelName = mozL10n.get('email-signature-tf');
                                            dump('email setup_progress:: modelName ==>  ' + modelName);
                                            if (modelName !== undefined && modelName !== '') {
                                                var tfSignature = mozL10n.get('email-signature', { board: modelName });
                                                this.identity.modifyIdentity({ signature: tfSignature });
                                            }
                                            evt.emit('autoAddDone');
                                        } else if (operator === 'USOM') {
                                            let modelName;
                                            modelName = mozL10n.get('email-signature-usom');
                                            dump('email setup_progress:: modelName ==>  ' + modelName);
                                            if (modelName !== undefined && modelName !== '') {
                                                var usomSignature = mozL10n.get('email-signature', { board: modelName });
                                                this.identity.modifyIdentity({ signature: usomSignature });
                                            }
                                            evt.emit('autoAddDone');
                                        } else if (operator === 'EE') {
                                            let modelName;
                                            modelName = mozL10n.get('email-signature-ee');
                                            dump('email setup_progress:: modelName ==>  ' + modelName);
                                            if (modelName !== undefined && modelName !== '') {
                                                var eeSignature = mozL10n.get('email-signature', { board: modelName });
                                                this.identity.modifyIdentity({ signature: eeSignature });
                                            }
                                            evt.emit('autoAddDone');
                                        } else {
                                            evt.emit('autoAddDone');
                                        }
                                    });
                                });
                            });
                        } else if (!this.createOnBackground) {
                            cards.pushCard('setup_account_prefs', 'animate', {
                                account: account,
                                autoSetup: true
                            });
                        }
                        this.createOnBackground = false;
                    }
                } else {
                    cards.pushCard('setup_account_prefs', 'animate', { account: account });
                }
            },
            die: function () {
                if (!this.createOnBackground) {
                    this.cancelCreation();
                }
                window.removeEventListener('keydown', this.keydownHandler);
            }
        }
    ];
});