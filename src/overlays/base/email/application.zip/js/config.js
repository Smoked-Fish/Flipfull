var requirejs, require, define;
(function (global, Promise, undef) {
    if (!Promise) {
        throw new Error('No Promise implementation available');
    }
    var topReq, dataMain, src, subPath, bootstrapConfig = requirejs || require, hasOwn = Object.prototype.hasOwnProperty, contexts = {}, queue = [], currDirRegExp = /^\.\//, urlRegExp = /^\/|\:|\?|\.js$/, commentRegExp = /\/\*[\s\S]*?\*\/|([^:"'=]|^)\/\/.*$/mg, cjsRequireRegExp = /[^.]\s*require\s*\(\s*["']([^'"\s]+)["']\s*\)/g, jsSuffixRegExp = /\.js$/, slice = Array.prototype.slice;
    if (typeof requirejs === 'function') {
        return;
    }
    var asap = Promise.resolve(undefined);
    function commentReplace(match, singlePrefix) {
        return singlePrefix || '';
    }
    function hasProp(obj, prop) {
        return hasOwn.call(obj, prop);
    }
    function getOwn(obj, prop) {
        return obj && hasProp(obj, prop) && obj[prop];
    }
    function obj() {
        return Object.create(null);
    }
    function eachProp(obj, func) {
        var prop;
        for (prop in obj) {
            if (hasProp(obj, prop)) {
                if (func(obj[prop], prop)) {
                    break;
                }
            }
        }
    }
    function mixin(target, source, force, deepStringMixin) {
        if (source) {
            eachProp(source, function (value, prop) {
                if (force || !hasProp(target, prop)) {
                    if (deepStringMixin && typeof value === 'object' && value && !Array.isArray(value) && typeof value !== 'function' && !(value instanceof RegExp)) {
                        if (!target[prop]) {
                            target[prop] = {};
                        }
                        mixin(target[prop], value, force, deepStringMixin);
                    } else {
                        target[prop] = value;
                    }
                }
            });
        }
        return target;
    }
    function getGlobal(value) {
        if (!value) {
            return value;
        }
        var g = global;
        value.split('.').forEach(function (part) {
            g = g[part];
        });
        return g;
    }
    function newContext(contextName) {
        var req, main, makeMap, callDep, handlers, checkingLater, load, context, defined = obj(), waiting = obj(), config = {
                waitSeconds: 7,
                baseUrl: './',
                paths: {},
                bundles: {},
                pkgs: {},
                shim: {},
                config: {}
            }, mapCache = obj(), requireDeferreds = [], deferreds = obj(), calledDefine = obj(), calledPlugin = obj(), loadCount = 0, startTime = new Date().getTime(), errCount = 0, trackedErrors = obj(), urlFetched = obj(), bundlesMap = obj(), asyncResolve = Promise.resolve();
        function trimDots(ary) {
            var i, part, length = ary.length;
            for (i = 0; i < length; i++) {
                part = ary[i];
                if (part === '.') {
                    ary.splice(i, 1);
                    i -= 1;
                } else if (part === '..') {
                    if (i === 0 || i === 1 && ary[2] === '..' || ary[i - 1] === '..') {
                        continue;
                    } else if (i > 0) {
                        ary.splice(i - 1, 2);
                        i -= 2;
                    }
                }
            }
        }
        function normalize(name, baseName, applyMap) {
            var pkgMain, mapValue, nameParts, i, j, nameSegment, lastIndex, foundMap, foundI, foundStarMap, starI, baseParts = baseName && baseName.split('/'), normalizedBaseParts = baseParts, map = config.map, starMap = map && map['*'];
            if (name) {
                name = name.split('/');
                lastIndex = name.length - 1;
                if (config.nodeIdCompat && jsSuffixRegExp.test(name[lastIndex])) {
                    name[lastIndex] = name[lastIndex].replace(jsSuffixRegExp, '');
                }
                if (name[0].charAt(0) === '.' && baseParts) {
                    normalizedBaseParts = baseParts.slice(0, baseParts.length - 1);
                    name = normalizedBaseParts.concat(name);
                }
                trimDots(name);
                name = name.join('/');
            }
            if (applyMap && map && (baseParts || starMap)) {
                nameParts = name.split('/');
                outerLoop:
                    for (i = nameParts.length; i > 0; i -= 1) {
                        nameSegment = nameParts.slice(0, i).join('/');
                        if (baseParts) {
                            for (j = baseParts.length; j > 0; j -= 1) {
                                mapValue = getOwn(map, baseParts.slice(0, j).join('/'));
                                if (mapValue) {
                                    mapValue = getOwn(mapValue, nameSegment);
                                    if (mapValue) {
                                        foundMap = mapValue;
                                        foundI = i;
                                        break outerLoop;
                                    }
                                }
                            }
                        }
                        if (!foundStarMap && starMap && getOwn(starMap, nameSegment)) {
                            foundStarMap = getOwn(starMap, nameSegment);
                            starI = i;
                        }
                    }
                if (!foundMap && foundStarMap) {
                    foundMap = foundStarMap;
                    foundI = starI;
                }
                if (foundMap) {
                    nameParts.splice(0, foundI, foundMap);
                    name = nameParts.join('/');
                }
            }
            pkgMain = getOwn(config.pkgs, name);
            return pkgMain ? pkgMain : name;
        }
        function makeShimExports(value) {
            function fn() {
                var ret;
                if (value.init) {
                    ret = value.init.apply(global, arguments);
                }
                return ret || value.exports && getGlobal(value.exports);
            }
            return fn;
        }
        function takeQueue(anonId) {
            var i, id, args, shim;
            for (i = 0; i < queue.length; i += 1) {
                if (typeof queue[i][0] !== 'string') {
                    if (anonId) {
                        queue[i].unshift(anonId);
                        anonId = undef;
                    } else {
                        break;
                    }
                }
                args = queue.shift();
                id = args[0];
                i -= 1;
                if (!(id in defined) && !(id in waiting)) {
                    if (id in deferreds) {
                        main.apply(undef, args);
                    } else {
                        waiting[id] = args;
                    }
                }
            }
            if (anonId) {
                shim = getOwn(config.shim, anonId) || {};
                main(anonId, shim.deps || [], shim.exportsFn);
            }
        }
        function makeRequire(relName, topLevel) {
            var req = function (deps, callback, errback, alt) {
                var name, cfg;
                if (topLevel) {
                    takeQueue();
                }
                if (typeof deps === 'string') {
                    if (handlers[deps]) {
                        return handlers[deps](relName);
                    }
                    name = makeMap(deps, relName, true).id;
                    if (!(name in defined)) {
                        throw new Error('Not loaded: ' + name);
                    }
                    return defined[name];
                } else if (deps && !Array.isArray(deps)) {
                    cfg = deps;
                    deps = undef;
                    if (Array.isArray(callback)) {
                        deps = callback;
                        callback = errback;
                        errback = alt;
                    }
                    if (topLevel) {
                        return req.config(cfg)(deps, callback, errback);
                    }
                }
                callback = callback || function () {
                    return slice.call(arguments, 0);
                };
                return asyncResolve.then(function () {
                    takeQueue();
                    return main(undef, deps || [], callback, errback, relName);
                });
            };
            req.isBrowser = typeof document !== 'undefined' && typeof navigator !== 'undefined';
            req.nameToUrl = function (moduleName, ext, skipExt) {
                var paths, syms, i, parentModule, url, parentPath, bundleId, pkgMain = getOwn(config.pkgs, moduleName);
                if (pkgMain) {
                    moduleName = pkgMain;
                }
                bundleId = getOwn(bundlesMap, moduleName);
                if (bundleId) {
                    return req.nameToUrl(bundleId, ext, skipExt);
                }
                if (urlRegExp.test(moduleName)) {
                    url = moduleName + (ext || '');
                } else {
                    paths = config.paths;
                    syms = moduleName.split('/');
                    for (i = syms.length; i > 0; i -= 1) {
                        parentModule = syms.slice(0, i).join('/');
                        parentPath = getOwn(paths, parentModule);
                        if (parentPath) {
                            if (Array.isArray(parentPath)) {
                                parentPath = parentPath[0];
                            }
                            syms.splice(0, i, parentPath);
                            break;
                        }
                    }
                    url = syms.join('/');
                    url += ext || (/^data\:|^blob\:|\?/.test(url) || skipExt ? '' : '.js');
                    url = (url.charAt(0) === '/' || url.match(/^[\w\+\.\-]+:/) ? '' : config.baseUrl) + url;
                }
                return config.urlArgs && !/^blob\:/.test(url) ? url + config.urlArgs(moduleName, url) : url;
            };
            req.toUrl = function (moduleNamePlusExt) {
                var ext, index = moduleNamePlusExt.lastIndexOf('.'), segment = moduleNamePlusExt.split('/')[0], isRelative = segment === '.' || segment === '..';
                if (index !== -1 && (!isRelative || index > 1)) {
                    ext = moduleNamePlusExt.substring(index, moduleNamePlusExt.length);
                    moduleNamePlusExt = moduleNamePlusExt.substring(0, index);
                }
                return req.nameToUrl(normalize(moduleNamePlusExt, relName), ext, true);
            };
            req.defined = function (id) {
                return makeMap(id, relName, true).id in defined;
            };
            req.specified = function (id) {
                id = makeMap(id, relName, true).id;
                return id in defined || id in deferreds;
            };
            return req;
        }
        function resolve(name, d, value) {
            if (name) {
                defined[name] = value;
                if (requirejs.onResourceLoad) {
                    requirejs.onResourceLoad(context, d.map, d.deps);
                }
            }
            d.finished = true;
            d.resolve(value);
        }
        function reject(d, err) {
            d.finished = true;
            d.rejected = true;
            d.reject(err);
        }
        function makeNormalize(relName) {
            return function (name) {
                return normalize(name, relName, true);
            };
        }
        function defineModule(d) {
            d.factoryCalled = true;
            var ret, name = d.map.id;
            try {
                ret = context.execCb(name, d.factory, d.values, defined[name]);
            } catch (err) {
                return reject(d, err);
            }
            if (name) {
                if (ret === undef) {
                    if (d.cjsModule) {
                        ret = d.cjsModule.exports;
                    } else if (d.usingExports) {
                        ret = defined[name];
                    }
                }
            } else {
                requireDeferreds.splice(requireDeferreds.indexOf(d), 1);
            }
            resolve(name, d, ret);
        }
        function depFinished(val, i) {
            if (!this.rejected && !this.depDefined[i]) {
                this.depDefined[i] = true;
                this.depCount += 1;
                this.values[i] = val;
                if (!this.depending && this.depCount === this.depMax) {
                    defineModule(this);
                }
            }
        }
        function makeDefer(name, calculatedMap) {
            var d = {};
            d.promise = new Promise(function (resolve, reject) {
                d.resolve = resolve;
                d.reject = function (err) {
                    if (!name) {
                        requireDeferreds.splice(requireDeferreds.indexOf(d), 1);
                    }
                    reject(err);
                };
            });
            d.map = name ? calculatedMap || makeMap(name) : {};
            d.depCount = 0;
            d.depMax = 0;
            d.values = [];
            d.depDefined = [];
            d.depFinished = depFinished;
            if (d.map.pr) {
                d.deps = [makeMap(d.map.pr)];
            }
            return d;
        }
        function getDefer(name, calculatedMap) {
            var d;
            if (name) {
                d = name in deferreds && deferreds[name];
                if (!d) {
                    d = deferreds[name] = makeDefer(name, calculatedMap);
                }
            } else {
                d = makeDefer();
                requireDeferreds.push(d);
            }
            return d;
        }
        function makeErrback(d, name) {
            return function (err) {
                if (!d.rejected) {
                    if (!err.dynaId) {
                        err.dynaId = 'id' + (errCount += 1);
                        err.requireModules = [name];
                    }
                    reject(d, err);
                }
            };
        }
        function waitForDep(depMap, relName, d, i) {
            d.depMax += 1;
            callDep(depMap, relName).then(function (val) {
                d.depFinished(val, i);
            }, makeErrback(d, depMap.id)).catch(makeErrback(d, d.map.id));
        }
        function makeLoad(id) {
            var fromTextCalled;
            function load(value) {
                if (!fromTextCalled) {
                    resolve(id, getDefer(id), value);
                }
            }
            load.error = function (err) {
                reject(getDefer(id), err);
            };
            load.fromText = function (text, textAlt) {
                var d = getDefer(id), map = makeMap(makeMap(id).n), plainId = map.id, execError;
                fromTextCalled = true;
                d.factory = function (p, val) {
                    return val;
                };
                if (textAlt) {
                    text = textAlt;
                }
                if (hasProp(config.config, id)) {
                    config.config[plainId] = config.config[id];
                }
                try {
                    req.exec(text);
                } catch (e) {
                    execError = new Error('fromText eval for ' + plainId + ' failed: ' + e);
                    execError.requireType = 'fromtexteval';
                    reject(d, execError);
                }
                takeQueue(plainId);
                d.deps = [map];
                waitForDep(map, null, d, d.deps.length);
            };
            return load;
        }
        load = typeof importScripts === 'function' ? function (map) {
            var url = map.url;
            if (urlFetched[url]) {
                return;
            }
            urlFetched[url] = true;
            getDefer(map.id);
            importScripts(url);
            takeQueue(map.id);
        } : function (map) {
            var script, id = map.id, url = map.url;
            if (urlFetched[url]) {
                return;
            }
            urlFetched[url] = true;
            script = document.createElement('script');
            script.setAttribute('data-requiremodule', id);
            script.type = config.scriptType || 'text/javascript';
            script.charset = 'utf-8';
            script.async = true;
            loadCount += 1;
            script.addEventListener('load', function () {
                loadCount -= 1;
                takeQueue(id);
            }, false);
            script.addEventListener('error', function () {
                loadCount -= 1;
                var err, pathConfig = getOwn(config.paths, id);
                if (pathConfig && Array.isArray(pathConfig) && pathConfig.length > 1) {
                    script.parentNode.removeChild(script);
                    pathConfig.shift();
                    var d = getDefer(id);
                    d.map = makeMap(id);
                    d.map.url = req.nameToUrl(id);
                    load(d.map);
                } else {
                    err = new Error('Load failed: ' + id + ': ' + script.src);
                    err.requireModules = [id];
                    err.requireType = 'scripterror';
                    reject(getDefer(id), err);
                }
            }, false);
            script.src = url;
            if (document.documentMode === 10) {
                asap.then(function () {
                    document.head.appendChild(script);
                });
            } else {
                document.head.appendChild(script);
            }
        };
        function callPlugin(plugin, map, relName) {
            plugin.load(map.n, makeRequire(relName), makeLoad(map.id), config);
        }
        callDep = function (map, relName) {
            var args, bundleId, name = map.id, shim = config.shim[name];
            if (name in waiting) {
                args = waiting[name];
                delete waiting[name];
                main.apply(undef, args);
            } else if (!(name in deferreds)) {
                if (map.pr) {
                    if (bundleId = getOwn(bundlesMap, name)) {
                        map.url = req.nameToUrl(bundleId);
                        load(map);
                    } else {
                        return callDep(makeMap(map.pr)).then(function (plugin) {
                            var newMap = map.prn ? map : makeMap(name, relName, true), newId = newMap.id, shim = getOwn(config.shim, newId);
                            if (!(newId in calledPlugin)) {
                                calledPlugin[newId] = true;
                                if (shim && shim.deps) {
                                    req(shim.deps, function () {
                                        callPlugin(plugin, newMap, relName);
                                    });
                                } else {
                                    callPlugin(plugin, newMap, relName);
                                }
                            }
                            return getDefer(newId).promise;
                        });
                    }
                } else if (shim && shim.deps) {
                    req(shim.deps, function () {
                        load(map);
                    });
                } else {
                    load(map);
                }
            }
            return getDefer(name).promise;
        };
        function splitPrefix(name) {
            var prefix, index = name ? name.indexOf('!') : -1;
            if (index > -1) {
                prefix = name.substring(0, index);
                name = name.substring(index + 1, name.length);
            }
            return [
                prefix,
                name
            ];
        }
        makeMap = function (name, relName, applyMap) {
            if (typeof name !== 'string') {
                return name;
            }
            var plugin, url, parts, prefix, result, prefixNormalized, cacheKey = name + ' & ' + (relName || '') + ' & ' + !!applyMap;
            parts = splitPrefix(name);
            prefix = parts[0];
            name = parts[1];
            if (!prefix && cacheKey in mapCache) {
                return mapCache[cacheKey];
            }
            if (prefix) {
                prefix = normalize(prefix, relName, applyMap);
                plugin = prefix in defined && defined[prefix];
            }
            if (prefix) {
                if (plugin && plugin.normalize) {
                    name = plugin.normalize(name, makeNormalize(relName));
                    prefixNormalized = true;
                } else {
                    name = name.indexOf('!') === -1 ? normalize(name, relName, applyMap) : name;
                }
            } else {
                name = normalize(name, relName, applyMap);
                parts = splitPrefix(name);
                prefix = parts[0];
                name = parts[1];
                url = req.nameToUrl(name);
            }
            result = {
                id: prefix ? prefix + '!' + name : name,
                n: name,
                pr: prefix,
                url: url,
                prn: prefix && prefixNormalized
            };
            if (!prefix) {
                mapCache[cacheKey] = result;
            }
            return result;
        };
        handlers = {
            require: function (name) {
                return makeRequire(name);
            },
            exports: function (name) {
                var e = defined[name];
                if (typeof e !== 'undefined') {
                    return e;
                } else {
                    return defined[name] = {};
                }
            },
            module: function (name) {
                return {
                    id: name,
                    uri: '',
                    exports: handlers.exports(name),
                    config: function () {
                        return getOwn(config.config, name) || {};
                    }
                };
            }
        };
        function breakCycle(d, traced, processed) {
            var id = d.map.id;
            traced[id] = true;
            if (!d.finished && d.deps) {
                d.deps.forEach(function (depMap) {
                    var depId = depMap.id, dep = !hasProp(handlers, depId) && getDefer(depId, depMap);
                    if (dep && !dep.finished && !processed[depId]) {
                        if (hasProp(traced, depId)) {
                            d.deps.forEach(function (depMap, i) {
                                if (depMap.id === depId) {
                                    d.depFinished(defined[depId], i);
                                }
                            });
                        } else {
                            breakCycle(dep, traced, processed);
                        }
                    }
                });
            }
            processed[id] = true;
        }
        function check(d) {
            var err, mid, dfd, notFinished = [], waitInterval = config.waitSeconds * 1000, expired = waitInterval && startTime + waitInterval < new Date().getTime();
            if (loadCount === 0) {
                if (d) {
                    if (!d.finished) {
                        breakCycle(d, {}, {});
                    }
                } else if (requireDeferreds.length) {
                    requireDeferreds.forEach(function (d) {
                        breakCycle(d, {}, {});
                    });
                }
            }
            if (expired) {
                for (mid in deferreds) {
                    dfd = deferreds[mid];
                    if (!dfd.finished) {
                        notFinished.push(dfd.map.id);
                    }
                }
                err = new Error('Timeout for modules: ' + notFinished);
                err.requireModules = notFinished;
                err.requireType = 'timeout';
                notFinished.forEach(function (id) {
                    reject(getDefer(id), err);
                });
            } else if (loadCount || requireDeferreds.length) {
                if (!checkingLater) {
                    checkingLater = true;
                    setTimeout(function () {
                        checkingLater = false;
                        check();
                    }, 70);
                }
            }
        }
        function delayedError(e) {
            setTimeout(function () {
                if (!e.dynaId || !trackedErrors[e.dynaId]) {
                    trackedErrors[e.dynaId] = true;
                    req.onError(e);
                }
            });
            return e;
        }
        main = function (name, deps, factory, errback, relName) {
            if (name) {
                if (name in calledDefine) {
                    return;
                }
                calledDefine[name] = true;
            }
            var d = getDefer(name);
            if (deps && !Array.isArray(deps)) {
                factory = deps;
                deps = [];
            }
            deps = deps ? slice.call(deps, 0) : null;
            if (!errback) {
                if (hasProp(config, 'defaultErrback')) {
                    if (config.defaultErrback) {
                        errback = config.defaultErrback;
                    }
                } else {
                    errback = delayedError;
                }
            }
            if (errback) {
                d.promise.catch(errback);
            }
            relName = relName || name;
            if (typeof factory === 'function') {
                if (!deps.length && factory.length) {
                    factory.toString().replace(commentRegExp, commentReplace).replace(cjsRequireRegExp, function (match, dep) {
                        deps.push(dep);
                    });
                    deps = (factory.length === 1 ? ['require'] : [
                        'require',
                        'exports',
                        'module'
                    ]).concat(deps);
                }
                d.factory = factory;
                d.deps = deps;
                d.depending = true;
                deps.forEach(function (depName, i) {
                    var depMap;
                    deps[i] = depMap = makeMap(depName, relName, true);
                    depName = depMap.id;
                    if (depName === 'require') {
                        d.values[i] = handlers.require(name);
                    } else if (depName === 'exports') {
                        d.values[i] = handlers.exports(name);
                        d.usingExports = true;
                    } else if (depName === 'module') {
                        d.values[i] = d.cjsModule = handlers.module(name);
                    } else if (depName === undefined) {
                        d.values[i] = undefined;
                    } else {
                        waitForDep(depMap, relName, d, i);
                    }
                });
                d.depending = false;
                if (d.depCount === d.depMax) {
                    defineModule(d);
                }
            } else if (name) {
                resolve(name, d, factory);
            }
            startTime = new Date().getTime();
            if (!name) {
                check(d);
            }
            return d.promise;
        };
        req = makeRequire(null, true);
        req.config = function (cfg) {
            if (cfg.context && cfg.context !== contextName) {
                var existingContext = getOwn(contexts, cfg.context);
                if (existingContext) {
                    return existingContext.req.config(cfg);
                } else {
                    return newContext(cfg.context).config(cfg);
                }
            }
            mapCache = obj();
            if (cfg.baseUrl) {
                if (cfg.baseUrl.charAt(cfg.baseUrl.length - 1) !== '/') {
                    cfg.baseUrl += '/';
                }
            }
            if (typeof cfg.urlArgs === 'string') {
                var urlArgs = cfg.urlArgs;
                cfg.urlArgs = function (id, url) {
                    return (url.indexOf('?') === -1 ? '?' : '&') + urlArgs;
                };
            }
            var shim = config.shim, objs = {
                    paths: true,
                    bundles: true,
                    config: true,
                    map: true
                };
            eachProp(cfg, function (value, prop) {
                if (objs[prop]) {
                    if (!config[prop]) {
                        config[prop] = {};
                    }
                    mixin(config[prop], value, true, true);
                } else {
                    config[prop] = value;
                }
            });
            if (cfg.bundles) {
                eachProp(cfg.bundles, function (value, prop) {
                    value.forEach(function (v) {
                        if (v !== prop) {
                            bundlesMap[v] = prop;
                        }
                    });
                });
            }
            if (cfg.shim) {
                eachProp(cfg.shim, function (value, id) {
                    if (Array.isArray(value)) {
                        value = { deps: value };
                    }
                    if ((value.exports || value.init) && !value.exportsFn) {
                        value.exportsFn = makeShimExports(value);
                    }
                    shim[id] = value;
                });
                config.shim = shim;
            }
            if (cfg.packages) {
                cfg.packages.forEach(function (pkgObj) {
                    var location, name;
                    pkgObj = typeof pkgObj === 'string' ? { name: pkgObj } : pkgObj;
                    name = pkgObj.name;
                    location = pkgObj.location;
                    if (location) {
                        config.paths[name] = pkgObj.location;
                    }
                    config.pkgs[name] = pkgObj.name + '/' + (pkgObj.main || 'main').replace(currDirRegExp, '').replace(jsSuffixRegExp, '');
                });
            }
            if (cfg.deps || cfg.callback) {
                req(cfg.deps, cfg.callback);
            }
            return req;
        };
        req.onError = function (err) {
            throw err;
        };
        context = {
            id: contextName,
            defined: defined,
            waiting: waiting,
            config: config,
            deferreds: deferreds,
            req: req,
            execCb: function execCb(name, callback, args, exports) {
                return callback.apply(exports, args);
            }
        };
        contexts[contextName] = context;
        return req;
    }
    requirejs = topReq = newContext('_');
    if (typeof require !== 'function') {
        require = topReq;
    }
    topReq.exec = function (text) {
        return eval(text);
    };
    topReq.contexts = contexts;
    define = function () {
        queue.push(slice.call(arguments, 0));
    };
    define.amd = { jQuery: true };
    if (bootstrapConfig) {
        topReq.config(bootstrapConfig);
    }
    if (topReq.isBrowser && !contexts._.config.skipDataMain) {
        dataMain = document.querySelectorAll('script[data-main]')[0];
        dataMain = dataMain && dataMain.getAttribute('data-main');
        if (dataMain) {
            dataMain = dataMain.replace(jsSuffixRegExp, '');
            if ((!bootstrapConfig || !bootstrapConfig.baseUrl) && dataMain.indexOf('!') === -1) {
                src = dataMain.split('/');
                dataMain = src.pop();
                subPath = src.length ? src.join('/') + '/' : './';
                topReq.config({ baseUrl: subPath });
            }
            topReq([dataMain]);
        }
    }
}(this, typeof Promise !== 'undefined' ? Promise : undefined));
define('alameda', function () {
});
(function () {
    function consoleHelper() {
        let msg = arguments[0] + ':';
        for (let i = 1; i < arguments.length; i++) {
            msg += ' ' + arguments[i];
        }
        msg += '\x1B[0m\n';
        dump(msg);
    }
    if ('mozTCPSocket' in window.navigator) {
        window.console = {
            log: consoleHelper.bind(null, '\x1B[32mLOG'),
            error: consoleHelper.bind(null, '\x1B[31mERR'),
            info: consoleHelper.bind(null, '\x1B[36mINF'),
            warn: consoleHelper.bind(null, '\x1B[33mWAR')
        };
    }
    window.onerror = (msg, url, line) => {
        console.error('onerror reporting:', msg, '@', url, ':', line);
        return false;
    };
}());
define('console_hook', function () {
});
define('evt', [], function () {
    let evt, slice = Array.prototype.slice, props = [
            '_events',
            '_pendingEvents',
            'on',
            'once',
            'latest',
            'latestOnce',
            'removeListener',
            'emitWhenListener',
            'emit'
        ];
    function Emitter() {
        this._events = {};
        this._pendingEvents = {};
    }
    Emitter.prototype = {
        on: function (id, fn) {
            let listeners = this._events[id], pending = this._pendingEvents[id];
            if (!listeners) {
                listeners = this._events[id] = [];
            }
            listeners.push(fn);
            if (pending) {
                pending.forEach(args => {
                    fn.apply(null, args);
                });
                delete this._pendingEvents[id];
            }
            return this;
        },
        once: function (id, fn) {
            let self = this, fired = false;
            function one() {
                if (fired) {
                    return;
                }
                fired = true;
                fn.apply(null, arguments);
                setTimeout(() => {
                    self.removeListener(id, one);
                });
            }
            return this.on(id, one);
        },
        latest: function (id, fn) {
            if (this[id] && !this._pendingEvents[id]) {
                fn(this[id]);
            }
            this.on(id, fn);
        },
        latestOnce: function (id, fn) {
            if (this[id] && !this._pendingEvents[id]) {
                fn(this[id]);
            } else {
                this.once(id, fn);
            }
        },
        removeListener: function (id, fn) {
            let i, listeners = this._events[id];
            if (listeners) {
                i = listeners.indexOf(fn);
                if (i !== -1) {
                    listeners.splice(i, 1);
                }
                if (listeners.length === 0) {
                    delete this._events[id];
                }
            }
        },
        emitWhenListener: function (id) {
            let listeners = this._events[id];
            if (listeners) {
                this.emit.apply(this, arguments);
            } else {
                if (!this._pendingEvents[id]) {
                    this._pendingEvents[id] = [];
                }
                this._pendingEvents[id].push(slice.call(arguments, 1));
            }
        },
        emit: function (id) {
            let args = slice.call(arguments, 1);
            Promise.resolve().then(() => {
                let listeners = this._events[id];
                if (listeners) {
                    listeners.forEach(fn => {
                        try {
                            fn.apply(null, args);
                        } catch (e) {
                            setTimeout(() => {
                                throw e;
                            });
                        }
                    });
                }
            });
        }
    };
    evt = new Emitter();
    evt.Emitter = Emitter;
    evt.mix = function (obj) {
        let e = new Emitter();
        props.forEach(prop => {
            if (obj.hasOwnProperty(prop)) {
                throw new Error('Object already has a property "' + prop + '"');
            }
            obj[prop] = e[prop];
        });
        return obj;
    };
    return evt;
});
define('app_self', [
    'require',
    'exports',
    'module',
    'evt'
], function (require, exports, module) {
    let evt = require('evt');
    let appSelf = evt.mix({}), oldLatest = appSelf.latest, loaded = false;
    if (!AppsManager) {
        appSelf.self = {};
        loaded = true;
    }
    function loadSelf() {
        const manifestUrl = window.AppOrigin.getManifestURL('email');
        ;
        AppsManager.getApp(manifestUrl).then(app => {
            loaded = true;
            appSelf.self = app;
            appSelf.emit('self', appSelf.self);
        });
    }
    appSelf.latest = function (id) {
        if (!loaded) {
            loadSelf();
        }
        if (id !== 'self') {
            throw new Error(module.id + ' only supports "self" property');
        }
        return oldLatest.apply(this, arguments);
    };
    return appSelf;
});
define('l10n', {
    load: function (id, require, onload, config) {
        if (config.isBuild) {
            return onload();
        }
        require([
            'l10nbase',
            'l10ndate'
        ], () => {
            window.api.l10n.once(() => {
                let dir = window.api.l10n.language.direction, htmlNode = document.querySelector('html');
                if (htmlNode.getAttribute('dir') !== dir) {
                    console.log('email l10n updating html dir to ' + dir);
                    htmlNode.setAttribute('dir', dir);
                }
                onload(window.api.l10n);
            });
        });
    }
});
define('sync', [
    'require',
    'app_self',
    'evt',
    'l10n!',
    'http://shared.localhost/js/helper/notification/notification_helper.js'
], function (require) {
    let cronSyncStartTime, appSelf = require('app_self'), evt = require('evt'), mozL10n = require('l10n!');
    notificationHelper = require('http://shared.localhost/js/helper/notification/notification_helper.js');
    let notificationDataVersion = '1';
    return function syncInit(model, api) {
        let hasBeenVisible = !document.hidden, waitingOnCron = {};
        if (hasBeenVisible) {
            api.setInteractive();
        }
        document.addEventListener('visibilitychange', function onVisibilityChange() {
            if (!document.hidden) {
                hasBeenVisible = true;
                api.setInteractive();
            }
        }, false);
        function makeAccountKey(accountIds) {
            return 'id' + accountIds.join(' ');
        }
        let sendNotification;
        if (typeof Notification !== 'function') {
            console.log('email: notifications not available');
            sendNotification = function () {
            };
        } else {
            sendNotification = function (notificationId, title, body, iconUrl, data, behavior) {
                console.log('Notification sent for ' + notificationId);
                if (Notification.permission !== 'granted') {
                    console.log('email: notification skipped, permission: ' + Notification.permission);
                    return;
                }
                data = data || {};
                let notificationOptions = {
                    body: body,
                    icon: iconUrl,
                    tag: notificationId,
                    data: data,
                    mozbehavior: { noscreen: true }
                };
                if (behavior) {
                    Object.keys(behavior).forEach(key => {
                        notificationOptions.mozbehavior[key] = behavior[key];
                    });
                }
                let notification = new Notification(title, notificationOptions);
                notification.onclick = function () {
                    evt.emit('notification', {
                        clicked: true,
                        imageURL: iconUrl,
                        tag: notificationId,
                        data: data
                    });
                };
            };
        }
        api.oncronsyncstart = function (accountIds) {
            console.log('email oncronsyncstart: ' + accountIds);
            cronSyncStartTime = Date.now();
            let accountKey = makeAccountKey(accountIds);
            waitingOnCron[accountKey] = true;
        };
        function fetchNotificationsData(ntype) {
            if (typeof Notification !== 'function' || !Notification.get) {
                return Promise.resolve({});
            }
            return Notification.get().then(notifications => {
                let result = {};
                notifications.forEach(notification => {
                    let data = notification.data;
                    if (!data.v || data.v !== notificationDataVersion) {
                        notification.close();
                    } else if (data.ntype === ntype) {
                        data.notification = notification;
                        result[data.accountId] = data;
                    }
                });
                return result;
            }, err => {
                console.error('email notification.get call failed: ' + err);
                return {};
            });
        }
        function getSyncEnv(fn) {
            appSelf.latest('self', app => {
                model.latestOnce('account', currentAccount => {
                    fetchNotificationsData('sync').then(function (existingNotificationsData) {
                        fn(app, currentAccount, existingNotificationsData);
                    });
                });
            });
        }
        function topUniqueFromNames(latestInfos, oldFromNames) {
            let names = [], maxCount = 3;
            latestInfos.sort((a, b) => {
                return b.date - a.date;
            });
            latestInfos.some(info => {
                if (names.length > maxCount) {
                    return true;
                }
                if (names.indexOf(info.from) === -1) {
                    names.push(info.from);
                }
            });
            oldFromNames.some(name => {
                if (names.length > maxCount) {
                    return true;
                }
                if (names.indexOf(name) === -1) {
                    names.push(name);
                }
            });
            return names;
        }
        api.oncronsyncstop = function (accountsResults) {
            console.log('email oncronsyncstop: ' + accountsResults.accountIds);
            function finishSync() {
                evt.emit('cronSyncStop', accountsResults.accountIds);
                let accountKey = makeAccountKey(accountsResults.accountIds);
                waitingOnCron[accountKey] = false;
                let stillWaiting = Object.keys(waitingOnCron).some(key => {
                    return !!waitingOnCron[key];
                });
                if (!hasBeenVisible && !stillWaiting) {
                    console.log('sync completed in ' + (Date.now() - cronSyncStartTime) / 1000 + ' seconds, closing mail app');
                    window.close();
                }
            }
            if (!accountsResults.updates) {
                finishSync();
                return;
            }
            getSyncEnv(function (app, currentAccount, existingNotificationsData) {
                let iconUrl = notificationHelper.getIconURI(app);
                accountsResults.updates.forEach(result => {
                    if (currentAccount.id === result.id && !document.hidden) {
                        model.notifyInboxMessages(result);
                        return;
                    }
                    if (!model.getAccount(result.id).notifyOnNew || typeof Notification !== 'function') {
                        return;
                    }
                    let dataObject, subject, title, behavior, count = result.count, oldFromNames = [];
                    let existingData = existingNotificationsData[result.id];
                    if (existingData) {
                        if (existingData.count) {
                            count += parseInt(existingData.count, 10);
                        }
                        if (existingData.fromNames) {
                            oldFromNames = existingData.fromNames;
                        }
                    }
                    behavior = { soundFile: app.origin + '/sounds/new_mail.ogg' };
                    if (count > 1) {
                        let newFromNames = topUniqueFromNames(result.latestMessageInfos, oldFromNames);
                        dataObject = {
                            v: notificationDataVersion,
                            ntype: 'sync',
                            type: 'message_list',
                            accountId: result.id,
                            count: count,
                            fromNames: newFromNames
                        };
                        subject = mozL10n.get('new-emails-notify-one-account', { n: count });
                        title = newFromNames.join(mozL10n.get('senders-separation-sign'));
                    } else {
                        let info = result.latestMessageInfos[0];
                        dataObject = {
                            v: notificationDataVersion,
                            ntype: 'sync',
                            type: 'message_reader',
                            accountId: info.accountId,
                            messageSuid: info.messageSuid,
                            count: 1,
                            fromNames: [info.from]
                        };
                        subject = info.subject;
                        title = info.from;
                    }
                    sendNotification(result.id, title, subject, iconUrl, dataObject, behavior);
                });
                finishSync();
            });
        };
        let BACKGROUND_SEND_NOTIFICATION_ID = 'backgroundSendFailed';
        let sentAudio = null;
        api.onbackgroundsendstatus = function (data) {
            console.log('outbox: Message', data.suid, 'status =', JSON.stringify({
                state: data.state,
                err: data.err,
                sendFailures: data.sendFailures,
                emitNotifications: data.emitNotifications
            }));
            let descId;
            switch (data.state) {
            case 'pending':
                descId = 'background-send-pending';
                break;
            case 'sending':
                descId = 'background-send-sending';
                break;
            case 'success':
                descId = 'background-send-success';
                break;
            case 'error':
                if (data.badAddresses && data.badAddresses.length || data.err === 'bad-recipient') {
                    descId = 'background-send-error-recipients';
                } else {
                    descId = 'background-send-error';
                }
                break;
            case 'syncDone':
                break;
            default:
                console.error('No state description for background send state "' + data.state + '"');
                return;
            }
            if (descId) {
                data.localizedDescription = mozL10n.get(descId);
            }
            if (data.state === 'success') {
                model.latestOnce('acctsSlice', () => {
                    let account = model.getAccount(data.accountId);
                    if (!account) {
                        console.error('Invalid account ID', data.accountId, 'for a background send notification.');
                        return;
                    }
                    if (account.playSoundOnSend) {
                        if (!sentAudio) {
                            sentAudio = new Audio('/sounds/mail_sent.ogg');
                            sentAudio.mozAudioChannelType = 'notification';
                        }
                        sentAudio.play();
                    }
                });
            }
            if (data.emitNotifications) {
                model.notifyBackgroundSendStatus(data);
            }
        };
        evt.on('inboxShown', function (accountId) {
            fetchNotificationsData('sync').then(function (notificationsData) {
                if (notificationsData.hasOwnProperty(accountId)) {
                    notificationsData[accountId].notification.close();
                }
            });
        });
    };
});
define('model_init', [
    'require',
    'sync',
    'evt',
    'l10n!'
], function (require) {
    return function modelInit(model, api) {
        require('sync')(model, api);
        let evt = require('evt'), mozL10n = require('l10n!');
        api.onbadlogin = function (account, problem, whichSide) {
            evt.emitWhenListener('apiBadLogin', account, problem, whichSide);
        };
        api.onResetAccount = function (account) {
            model.resetAccount(account);
        };
        api.useLocalizedStrings({
            wrote: mozL10n.get('reply-quoting-wrote'),
            originalMessage: mozL10n.get('forward-original-message'),
            forwardHeaderLabels: {
                subject: mozL10n.get('forward-header-subject'),
                date: mozL10n.get('forward-header-date'),
                from: mozL10n.get('forward-header-from'),
                replyTo: mozL10n.get('forward-header-reply-to'),
                to: mozL10n.get('forward-header-to'),
                cc: mozL10n.get('forward-header-cc')
            },
            folderNames: {
                inbox: mozL10n.get('folder-inbox'),
                outbox: mozL10n.get('folder-outbox'),
                sent: mozL10n.get('folder-sent'),
                drafts: mozL10n.get('folder-drafts'),
                trash: mozL10n.get('folder-trash'),
                queue: mozL10n.get('folder-queue'),
                junk: mozL10n.get('folder-junk'),
                archives: mozL10n.get('folder-archives'),
                localdrafts: mozL10n.get('folder-localdrafts')
            }
        });
    };
});
define('model', [
    'require',
    'evt',
    'model_init'
], function (require) {
    let evt = require('evt'), modelInit = require('model_init');
    function dieOnFatalError(msg) {
        console.error('FATAL:', msg);
        throw new Error(msg);
    }
    function saveHasAccount(hasAccount, hasEnableAccount) {
        localStorage.setItem('data_has_account', hasAccount ? 'yes' : 'no');
        localStorage.setItem('data_has_enable_account', hasEnableAccount ? 'yes' : 'no');
        console.log('WRITING LOCAL STORAGE ITEM: ' + 'data_has_account', hasAccount ? 'yes' : 'no');
        console.log('WRITING LOCAL STORAGE ITEM: ' + 'data_has_enable_account', hasEnableAccount ? 'yes' : 'no');
    }
    let model = {
        firstRun: null,
        acctsSlice: null,
        account: null,
        foldersSlice: null,
        folder: null,
        _callEmit: function (id) {
            this.emit(id, this[id]);
        },
        inited: false,
        hasAccount: function () {
            return model.getAccountCount() > 0;
        },
        checkAccounts: function () {
            let hasEnable = false;
            if (this.hasAccount()) {
                for (let i = 0; i < model.acctsSlice.items.length; i++) {
                    if (model.acctsSlice.items[i].syncEnable) {
                        hasEnable = true;
                        break;
                    }
                }
                saveHasAccount(true, hasEnable);
            } else {
                saveHasAccount(false, hasEnable);
            }
            return hasEnable;
        },
        getAccount: function (id) {
            if (!model.acctsSlice || !model.acctsSlice.items) {
                throw new Error('No acctsSlice available');
            }
            let targetAccount;
            model.acctsSlice.items.some(account => {
                if (account.id === id) {
                    return !!(targetAccount = account);
                }
            });
            return targetAccount;
        },
        getEnableAccount: function (id, defaultAccount) {
            let index = 0;
            let account;
            for (index; index < model.acctsSlice.items.length; index++) {
                if (defaultAccount) {
                    if (model.acctsSlice.items[index].id !== id && model.acctsSlice.items[index].syncEnable) {
                        account = model.acctsSlice.items[index];
                        break;
                    }
                } else {
                    if (model.acctsSlice.items[index].isDefault && model.acctsSlice.items[index].id !== id && model.acctsSlice.items[index].syncEnable) {
                        account = model.acctsSlice.items[index];
                        break;
                    }
                }
            }
            return account;
        },
        getAccountCount: function () {
            let count = 0;
            if (model.acctsSlice && model.acctsSlice.items && model.acctsSlice.items.length) {
                count = model.acctsSlice.items.length;
            }
            return count;
        },
        init: function (showLatest, callback) {
            require(['api'], api => {
                if (!this.api) {
                    this.api = api;
                    modelInit(this, api);
                }
                this.die();
                let acctsSlice = api.viewAccounts(false);
                acctsSlice.oncomplete = () => {
                    model.acctsSlice = acctsSlice;
                    this.checkAccounts();
                    if (acctsSlice.items.length) {
                        let account = showLatest ? acctsSlice.items.slice(-1)[0] : acctsSlice.defaultAccount;
                        this.changeAccount(account, callback);
                    } else if (callback) {
                        callback();
                    }
                    this.inited = true;
                    this._callEmit('acctsSlice');
                    evt.emit('metrics:apiDone');
                };
                acctsSlice.onchange = () => {
                    model.acctsSlice = acctsSlice;
                    this.checkAccounts();
                };
            });
        },
        changeAccount: function (account, callback) {
            if (this.account && this.account.id === account.id) {
                if (callback) {
                    callback();
                }
                return;
            }
            this.resetAccount(account, callback);
        },
        resetAccount: function (account, callback) {
            this._dieFolders();
            this.account = account;
            this._callEmit('account');
            this.checkAccounts();
            let foldersSlice = this.api.viewFolders('account', account);
            foldersSlice.oncomplete = () => {
                this.foldersSlice = foldersSlice;
                this.foldersSlice.onchange = this.notifyFoldersSliceOnChange.bind(this);
                this.selectInbox(callback);
                this._callEmit('foldersSlice');
            };
        },
        changeAccountFromId: function (accountId, callback) {
            if (!this.acctsSlice || !this.acctsSlice.items.length) {
                throw new Error('No accounts available');
            }
            this.acctsSlice.items.some(account => {
                if (account.id === accountId) {
                    this.changeAccount(account, callback);
                    return true;
                }
            });
        },
        changeFolder: function (folder) {
            if (folder && (!this.folder || folder.id !== this.folder.id)) {
                this.folder = folder;
                this._callEmit('folder');
            }
        },
        selectInbox: function (callback) {
            this.selectFirstFolderWithType('inbox', callback);
        },
        selectFirstFolderWithType: function (folderType, callback) {
            if (!this.foldersSlice) {
                throw new Error('No foldersSlice available');
            }
            let folder = this.foldersSlice.getFirstFolderWithType(folderType);
            if (!folder) {
                dieOnFatalError('We have an account without a folderType ' + folderType + '!', this.foldersSlice.items);
            }
            if (this.folder && this.folder.id === folder.id) {
                if (callback) {
                    callback();
                }
            } else {
                if (callback) {
                    this.once('folder', callback);
                }
                this.changeFolder(folder);
            }
        },
        notifyInboxMessages: function (accountUpdate) {
            if (accountUpdate.id === this.account.id) {
                model.emit('newInboxMessages', accountUpdate.count);
            }
        },
        notifyFoldersSliceOnChange: function (folder) {
            model.emit('foldersSliceOnChange', folder);
        },
        notifyBackgroundSendStatus: function (data) {
            model.emit('backgroundSendStatus', data);
        },
        _dieFolders: function () {
            if (this.foldersSlice) {
                this.foldersSlice.die();
            }
            this.foldersSlice = null;
            this.folder = null;
        },
        die: function () {
            if (this.acctsSlice) {
                this.acctsSlice.die();
            }
            this.acctsSlice = null;
            this.account = null;
            this._dieFolders();
        }
    };
    return evt.mix(model);
});
define('attachment_name', [
    'require',
    'l10n!',
    'http://shared.localhost/js/utils/common/mime_mapper.js'
], function (require) {
    let mozL10n = require('l10n!'), mapper = require('http://shared.localhost/js/utils/common/mime_mapper.js');
    let attachmentName = {
        ensureName: function (blob, name, count) {
            if (!name) {
                count = count || 1;
                let suffix = mapper.guessExtensionFromType(blob.type);
                name = mozL10n.get('default-attachment-filename', { n: count }) + (suffix ? '.' + suffix : '');
            }
            return name;
        },
        ensureNameList: function (blobs, names) {
            for (let i = 0; i < blobs.length; i++) {
                names[i] = attachmentName.ensureName(blobs[i], names[i], i + 1);
            }
        }
    };
    return attachmentName;
});
define('query_uri', [], function () {
    'use strict';
    function decode(value) {
        try {
            return decodeURIComponent(value);
        } catch (err) {
            console.error('Skipping "' + value + '", decodeURIComponent error: ' + err);
            return '';
        }
    }
    function queryURI(uri) {
        function addressesToArray(addresses) {
            if (!addresses) {
                return [];
            }
            addresses = addresses.split(/[,;]/);
            return addresses.filter(addr => {
                return addr.trim() !== '';
            });
        }
        let mailtoReg = /^mailto:(.*)/i;
        let calltoReg = /^callto:(.*)/i;
        let obj = {};
        if (uri && uri.match(mailtoReg)) {
            uri = uri.match(mailtoReg)[1];
            let parts = uri.split('?');
            let subjectReg = /(?:^|&)subject=([^\&]*)/i, bodyReg = /(?:^|&)body=([^\&]*)/i, ccReg = /(?:^|&)cc=([^\&]*)/i, bccReg = /(?:^|&)bcc=([^\&]*)/i;
            obj.to = parts[0] ? addressesToArray(decode(parts[0])) : [];
            if (parts.length === 2) {
                let data = parts[1];
                if (data.match(subjectReg)) {
                    obj.subject = decode(data.match(subjectReg)[1]);
                }
                if (data.match(bodyReg)) {
                    obj.body = decode(data.match(bodyReg)[1]);
                }
                if (data.match(ccReg)) {
                    obj.cc = addressesToArray(decode(data.match(ccReg)[1]));
                }
                if (parts[1].match(bccReg)) {
                    obj.bcc = addressesToArray(decode(data.match(bccReg)[1]));
                }
            }
        } else if (uri && uri.match(calltoReg)) {
            uri = uri.match(calltoReg)[1];
            obj.number = uri;
        }
        return obj;
    }
    return queryURI;
});
define('activity_composer_data', [
    'require',
    'exports',
    'module',
    'attachment_name',
    'query_uri'
], function (require, exports, module) {
    let attachmentName = require('attachment_name'), queryUri = require('query_uri');
    return function activityComposeR(rawActivity) {
        let source = rawActivity.source;
        let data = source.data;
        let activityName = source.name;
        let dataType = data.type;
        let url = data.url || data.URI;
        let attachData;
        if (dataType === 'url' && activityName === 'share') {
            attachData = { body: url };
        } else {
            attachData = queryUri(url);
            attachData.attachmentBlobs = data.blobs || [];
            attachData.attachmentNames = data.filenames || [];
            attachmentName.ensureNameList(attachData.attachmentBlobs, attachData.attachmentNames);
        }
        return {
            onComposer: function (composer, composeCard) {
                let attachmentBlobs = attachData.attachmentBlobs;
                if (attachData.to) {
                    composer.to = attachData.to;
                }
                if (attachData.subject) {
                    composer.subject = attachData.subject;
                }
                if (attachData.body) {
                    composer.body = { text: attachData.body + composer.body.text };
                }
                if (attachData.cc) {
                    composer.cc = attachData.cc;
                }
                if (attachData.bcc) {
                    composer.bcc = attachData.bcc;
                }
                if (attachmentBlobs) {
                    let attachmentsToAdd = [];
                    for (let iBlob = 0; iBlob < attachmentBlobs.length; iBlob++) {
                        attachmentsToAdd.push({
                            name: attachData.attachmentNames[iBlob],
                            blob: attachmentBlobs[iBlob]
                        });
                    }
                    composeCard.addAttachmentsSubjectToSizeLimits(attachmentsToAdd);
                }
            }
        };
    };
});
define('cards_init', ['require'], function (require) {
    return function cardsInit(cards) {
        cards.pushDefaultCard = function (onPushed) {
            cards.pushCard('message_list', 'none', { onPushed: onPushed }, 'left');
        };
    };
});
define('html_cache', [
    'require',
    'exports',
    'module',
    'l10n!'
], function (require, exports) {
    let mozL10n = require('l10n!');
    exports.cloneAsInertNodeAvoidingCustomElementHorrors = function (node) {
        let templateNode = document.createElement('template');
        let cacheDoc = templateNode.content.ownerDocument;
        return cacheDoc.importNode(node, true);
    };
    exports.save = function htmlCacheSave(moduleId, html) {
        let id = exports.moduleIdToKey(moduleId);
        let lang = navigator.language;
        let langDir = document.querySelector('html').getAttribute('dir');
        let cachedSoftkeyHtml;
        if (!window.softkeyHTML) {
            let softkey = document.getElementById('softkeyPanel');
            if (softkey.innerText.length > 0) {
                let cachedSoftkeyNode = exports.cloneAsInertNodeAvoidingCustomElementHorrors(softkey);
                cachedSoftkeyNode.setAttribute('id', 'cachedSoftkeyPanel');
                cachedSoftkeyHtml = cachedSoftkeyNode.outerHTML;
            }
        } else {
            cachedSoftkeyHtml = window.softkeyHTML;
        }
        html = window.HTML_CACHE_VERSION + ',' + lang + (langDir ? ',' + langDir : '') + ',' + cachedSoftkeyHtml + ':' + html;
        try {
            localStorage.setItem('html_cache_' + id, html);
        } catch (e) {
            console.error('htmlCache.save error: ' + e);
        }
        console.log('htmlCache.save ' + id + ': ' + html.length + ', lang dir: ' + langDir);
    };
    exports.reset = function () {
        window.softkeyHTML = null;
        localStorage.clear();
    };
    exports.moduleIdToKey = function moduleIdToKey(moduleId) {
        return moduleId.replace(/^cards\//, '').replace(/-/g, '_');
    };
    exports.nodeToKey = function nodeToKey(node) {
        return node.nodeName.toLowerCase().replace(/^cards-/, '').replace(/-/g, '_');
    };
    exports.cloneAndSave = function cloneAndSave(moduleId, node) {
        let cachedNode = exports.cloneAsInertNodeAvoidingCustomElementHorrors(node);
        mozL10n.translateFragment(cachedNode);
        cachedNode.dataset.cached = 'cached';
        exports.delayedSaveFromNode(moduleId, cachedNode);
    };
    exports.saveFromNode = function saveFromNode(moduleId, node) {
        let cl = node.classList;
        cl.remove('before');
        cl.remove('after');
        cl.add('center');
        let html = node.outerHTML;
        exports.save(moduleId, html);
    };
    let delayedSaveId = 0;
    let delayedNode = '';
    exports.delayedSaveFromNode = function delayedSaveFromNode(moduleId, node) {
        delayedNode = node;
        if (!delayedSaveId) {
            delayedSaveId = setTimeout(() => {
                delayedSaveId = 0;
                exports.saveFromNode(moduleId, delayedNode);
                delayedNode = null;
            }, 100);
        }
    };
});
define('tmpl', ['l10n!'], function (mozL10n) {
    let tmpl = {
        pluginBuilder: './tmpl_builder',
        toDom: function (text) {
            let temp = document.createElement('div');
            temp.innerHTML = text;
            let node = temp.children[0];
            mozL10n.translateFragment(node);
            return node;
        },
        load: function (id, require, onload, config) {
            require(['text!' + id], function (text) {
                let node = tmpl.toDom(text);
                onload(node);
            });
        }
    };
    return tmpl;
});
define('tmpl!cards/toaster.html', ['tmpl'], function (tmpl) {
    return tmpl.toDom('<section role="status" class="toaster collapsed">\n  <p class="toaster-text"></p>\n  <div class="toaster-action-target collapsed"><button class="toaster-action"></button></div>\n</section>\n');
});
define('transition_end', [
    'require',
    'exports',
    'module'
], function (require, exports, module) {
    return function transitionEnd(node, fn, capturing) {
        function asyncFn(event) {
            Promise.resolve().then(function () {
                fn(event);
            }).catch(function (error) {
                console.error(error);
            });
        }
        node.addEventListener('transitionend', asyncFn, capturing);
        return asyncFn;
    };
});
define('toaster', [
    'require',
    'l10n!',
    'tmpl!./cards/toaster.html',
    'transition_end'
], function (require) {
    let mozL10n = require('l10n!');
    let toasterNode = require('tmpl!./cards/toaster.html');
    let transitionEnd = require('transition_end');
    let toaster = {
        defaultTimeout: 2000,
        _previousActionClass: undefined,
        init: function (parentEl) {
            this.el = toasterNode;
            parentEl.appendChild(this.el);
            this.text = this.el.querySelector('.toaster-text');
            this.actionButton = this.el.querySelector('.toaster-action');
            this.el.addEventListener('click', this.hide.bind(this));
            transitionEnd(this.el, this.hide.bind(this));
            this.el.querySelector('.toaster-action-target').addEventListener('click', this.onAction.bind(this));
            this.currentToast = null;
        },
        toastOperation: function (op) {
            if (!op || !op.affectedCount) {
                return;
            }
            let type = op.operation;
            let canUndo = op.undo && type !== 'move' && type !== 'delete';
            let text = mozL10n.get('toaster-message-' + type, { n: op.affectedCount });
            if (type === 'move' && op.target) {
                text += mozL10n.get('value-name', { name: op.target.name });
            }
            this.toast({
                text: text,
                actionLabel: mozL10n.get('toaster-undo'),
                actionClass: 'undo',
                action: canUndo && op.undo.bind(op)
            });
        },
        onAction: function () {
            let actionFunction = this.currentToast && this.currentToast.action;
            this.hide();
            if (actionFunction) {
                actionFunction();
            }
        },
        toast: function (opts) {
            opts = opts || {};
            Toaster.showToast({
                message: opts.text,
                latency: opts.timeout || this.defaultTimeout
            });
        },
        isShowing: function () {
            return !this.el.classList.contains('collapsed');
        },
        hide: function () {
            this.currentToast = null;
            this.el.classList.add('collapsed');
            this.el.classList.remove('fadeout');
            window.clearTimeout(this._fadeTimeout);
            this._fadeTimeout = null;
        }
    };
    return toaster;
});
define('input_areas', [
    'require',
    'exports',
    'module'
], function (require, exports) {
    let slice = Array.prototype.slice;
    return function hookupInputAreaResetButtons(e) {
        let selector = 'form p input + button[type="reset"],' + 'form p textarea + button[type="reset"]';
        let resetButtons = slice.call(e.querySelectorAll(selector));
        resetButtons.forEach(resetButton => {
            resetButton.addEventListener('mousedown', e => {
                e.preventDefault();
            });
            resetButton.addEventListener('click', e => {
                e.target.previousElementSibling.value = '';
                e.preventDefault();
            });
        });
    };
});
define('cards', [
    'require',
    'exports',
    'module',
    'cards_init',
    'html_cache',
    'l10n!',
    'evt',
    'toaster',
    'transition_end',
    'input_areas',
    'model'
], function (require, exports, module) {
    let cardsInit = require('cards_init'), htmlCache = require('html_cache'), mozL10n = require('l10n!'), evt = require('evt'), toaster = require('toaster'), transitionEnd = require('transition_end'), hookupInputAreaResetButtons = require('input_areas'), model = require('model');
    function addClass(domNode, name) {
        if (domNode) {
            domNode.classList.add(name);
        }
    }
    function removeClass(domNode, name) {
        if (domNode) {
            domNode.classList.remove(name);
        }
    }
    let cards = {
        _endKeyClicked: false,
        _backgroundUpdate: false,
        _cardDefs: {},
        _cardStack: [],
        activeCardIndex: -1,
        _pendingPush: null,
        _zIndex: 0,
        _rootNode: null,
        _containerNode: null,
        _cardsNode: null,
        _animatingDeadDomNodes: [],
        _transitionCount: 0,
        _startupEventsEmitted: false,
        _popupActive: null,
        _eatingEventsUntilNextCard: false,
        _supportBackground: true,
        init: function () {
            this._rootNode = document.body;
            this._containerNode = document.getElementById('cardContainer');
            this._cardsNode = document.getElementById('cards');
            this._statusColorMeta = document.querySelector('meta[name="theme-color"]');
            toaster.init(this._containerNode);
            this._containerNode.addEventListener('click', this._onMaybeIntercept.bind(this), true);
            transitionEnd(this._cardsNode, this._onTransitionEnd.bind(this), false);
            document.addEventListener('visibilitychange', () => {
                let card = this._cardStack[this.activeCardIndex];
                if (card && card.onCurrentCardDocumentVisibilityChange) {
                    card.onCurrentCardDocumentVisibilityChange(document.hidden);
                }
            });
            cardsInit(this);
            this._initKeydownEngine();
        },
        _onMaybeIntercept: function (event) {
            if (this._eatingEventsUntilNextCard && event.key !== 'MicrophoneToggle') {
                event.stopPropagation();
                event.preventDefault();
                return;
            }
            if (this._popupActive) {
                event.stopPropagation();
                event.preventDefault();
                this._popupActive.close();
                return;
            }
            let cardNode;
            let bContain = false;
            for (cardNode = event.target; cardNode; cardNode = cardNode.parentElement) {
                if (cardNode.classList.contains('card')) {
                    bContain = true;
                    break;
                }
            }
            if (!bContain) {
                let card = this._cardStack[this.activeCardIndex];
                if (event.key === 'Backspace' && card.localName === 'cards-settings-debug') {
                    event.stopPropagation();
                    event.preventDefault();
                    this.removeCardAndSuccessors(card, 'animate', 1);
                }
            }
        },
        pushCard: function (type, showMethod, args, placement) {
            let cardDef = this._cardDefs[type];
            args = args || {};
            if (window.option) {
                if (window.option.menuVisible) {
                    window.option.hideMenu();
                }
                window.option.hide();
            }
            if (!cardDef) {
                let cbArgs = Array.prototype.slice.call(arguments);
                this._pendingPush = [type];
                if (showMethod !== 'none') {
                    this.eatEventsUntilNextCard();
                }
                require(['element!cards/' + type], Ctor => {
                    this._cardDefs[type] = Ctor;
                    this.pushCard.apply(this, cbArgs);
                });
                return;
            }
            this._pendingPush = null;
            console.log('pushCard for type: ' + type);
            let domNode = args.cachedNode || new cardDef();
            if (args && domNode.onArgs) {
                domNode.onArgs(args);
            }
            let cardIndex, insertBuddy;
            if (!placement) {
                cardIndex = this._cardStack.length;
                insertBuddy = null;
                domNode.classList.add(cardIndex === 0 ? 'before' : 'after');
            } else if (placement === 'left') {
                cardIndex = this.activeCardIndex++;
                insertBuddy = this._cardsNode.children[cardIndex];
                domNode.classList.add('before');
            } else if (placement === 'right') {
                cardIndex = this.activeCardIndex + 1;
                if (cardIndex >= this._cardStack.length) {
                    insertBuddy = null;
                } else {
                    insertBuddy = this._cardsNode.children[cardIndex];
                }
                domNode.classList.add('after');
            }
            this._cardStack.splice(cardIndex, 0, domNode);
            if (!args.cachedNode) {
                this._cardsNode.insertBefore(domNode, insertBuddy);
            }
            hookupInputAreaResetButtons(domNode);
            if (!domNode.callHeaderFontSize) {
                window.dispatchEvent(new CustomEvent('lazyload', { detail: domNode }));
            }
            if ('postInsert' in domNode) {
                domNode.postInsert();
            }
            if (showMethod !== 'none') {
                if (!args.cachedNode) {
                    domNode.clientWidth;
                }
                this._showCard(cardIndex, showMethod, 'forward');
            }
            if (args.onPushed) {
                args.onPushed(domNode);
            }
        },
        pushOrTellCard: function (type, showMethod, args, placement) {
            let query = type;
            if (this.hasCard(query)) {
                this.tellCard(query, args);
                return false;
            } else {
                this.pushCard.apply(this, Array.prototype.slice.call(arguments));
                return true;
            }
        },
        setStatusColor: function (element) {
            let color;
            if (!element) {
                element = this._cardStack[this.activeCardIndex];
            }
            let statusElement = element.dataset.statuscolor ? element : element.querySelector('[data-statuscolor]');
            if (statusElement) {
                color = statusElement.dataset.statuscolor;
                if (color === 'default') {
                    color = null;
                } else if (color === 'background') {
                    color = getComputedStyle(statusElement).backgroundColor;
                }
            } else {
                color = getComputedStyle(element).backgroundColor;
            }
            if (color && color.indexOf('rgb') !== 0 && color.indexOf('#') !== 0) {
                color = null;
            }
            color = color || this._statusColorMeta.dataset.statuscolor;
            let existingColor = this._statusColorMeta.getAttribute('content');
            if (color !== existingColor) {
                this._statusColorMeta.setAttribute('content', color);
            }
        },
        _findCardUsingType: function (type) {
            for (let i = 0; i < this._cardStack.length; i++) {
                let domNode = this._cardStack[i];
                if (htmlCache.nodeToKey(domNode) === type) {
                    return i;
                }
            }
        },
        _findCard: function (query, skipFail) {
            let result;
            if (typeof query === 'string') {
                result = this._findCardUsingType(query, skipFail);
            } else if (typeof query === 'number') {
                result = query;
            } else {
                result = this._cardStack.indexOf(query);
            }
            if (result > -1) {
                return result;
            } else if (!skipFail) {
                throw new Error('Unable to find card with query:', query);
            } else {
                return undefined;
            }
        },
        hasCard: function (query) {
            if (this._pendingPush && this._pendingPush === query) {
                return true;
            }
            return this._findCard(query, true) > -1;
        },
        isVisible: function (domNode) {
            return !!(domNode && domNode.classList.contains('center'));
        },
        findCardObject: function (query) {
            return this._cardStack[this._findCard(query)];
        },
        getCurrentCard: function () {
            return this._cardStack[this.activeCardIndex];
        },
        getCurrentCardType: function () {
            let result = null, card = this._cardStack[this.activeCardIndex];
            if (this._pendingPush) {
                result = this._pendingPush;
            } else if (card) {
                result = htmlCache.nodeToKey(card);
            }
            return result;
        },
        folderSelector: function (callback, filter, curFolder) {
            require([
                'model',
                'value_selector'
            ], (model, ValueSelector) => {
                let optCancel = {
                    name: 'Cancel',
                    l10nId: 'opt-cancel',
                    priority: 1,
                    method: () => {
                        this.folderPrompt.hide();
                    }
                };
                let optSelect = {
                    name: 'Select',
                    l10nId: 'select',
                    priority: 2
                };
                function onFocusChanged() {
                    console.log('folderSelector onFocusChanged');
                    let actions = [
                        optCancel,
                        optSelect
                    ];
                    NavigationMap.setSoftKeyBar(actions);
                }
                if (!this.folderPrompt) {
                    this.folderPrompt = new ValueSelector('messages-folder-select', [], [optCancel]);
                }
                model.latestOnce('foldersSlice', foldersSlice => {
                    let folders = foldersSlice.items;
                    this.folderPrompt.List.length = 0;
                    folders.forEach(folder => {
                        let isMatch = !filter || filter(folder);
                        if (folder.neededForHierarchy || isMatch) {
                            let folderPrompt = this.folderPrompt;
                            folderPrompt.addToList(folder.name, folder.depth, isMatch, function (folder) {
                                return () => {
                                    folderPrompt.hide();
                                    callback(folder);
                                };
                            }(folder), folder === curFolder, folder);
                        }
                    });
                    this.folderPrompt.show(onFocusChanged);
                });
            });
        },
        moveToCard: function (query, showMethod) {
            this._showCard(this._findCard(query), showMethod || 'animate');
        },
        tellCard: function (query, what) {
            let cardIndex = this._findCard(query), domNode = this._cardStack[cardIndex];
            if (!('told' in domNode)) {
                console.warn('Tried to tell a card that\'s not listening!', query, what);
            } else {
                domNode.told(what);
            }
        },
        removeCardAndSuccessors: function (cardDomNode, showMethod, numCards, nextCardSpec, skipDefault) {
            if (!this._cardStack.length) {
                return;
            }
            if (showMethod === 'delay-animate') {
                this.eatEventsUntilNextCard();
                setTimeout(() => {
                    this.removeCardAndSuccessors(cardDomNode, 'animate', numCards, nextCardSpec, skipDefault);
                }, 100);
                return;
            }
            if (cardDomNode && this._cardStack.length === 1 && !skipDefault) {
                return cards.pushDefaultCard(() => {
                    this.removeCardAndSuccessors(cardDomNode, showMethod, numCards, nextCardSpec);
                });
            }
            if (window.option) {
                if (window.option.menuVisible) {
                    window.option.hideMenu();
                }
                window.option.hide();
            }
            let firstIndex, iCard, domNode;
            if (cardDomNode === undefined) {
                throw new Error('undefined is not a valid card spec!');
            } else if (cardDomNode === null) {
                firstIndex = 0;
                this._zIndex = 0;
            } else {
                for (iCard = this._cardStack.length - 1; iCard >= 0; iCard--) {
                    domNode = this._cardStack[iCard];
                    if (domNode === cardDomNode) {
                        firstIndex = iCard;
                        break;
                    }
                }
                if (firstIndex === undefined) {
                    throw new Error('No card represented by that DOM node');
                }
            }
            if (!numCards) {
                numCards = this._cardStack.length - firstIndex;
            }
            if (showMethod === 'none') {
                if (cardDomNode && cardDomNode.classList.contains('anim-overlay')) {
                    this._zIndex -= 10;
                }
            } else {
                let nextCardIndex = -1;
                if (nextCardSpec) {
                    nextCardIndex = this._findCard(nextCardSpec);
                } else if (this._cardStack.length) {
                    nextCardIndex = Math.min(firstIndex - 1, this._cardStack.length - 1);
                }
                if (nextCardIndex > -1) {
                    this._showCard(nextCardIndex, showMethod, 'back');
                }
            }
            if (firstIndex <= this.activeCardIndex) {
                this.activeCardIndex -= numCards;
                if (this.activeCardIndex < -1) {
                    this.activeCardIndex = -1;
                }
            }
            let deadDomNodes = this._cardStack.splice(firstIndex, numCards);
            for (iCard = 0; iCard < deadDomNodes.length; iCard++) {
                domNode = deadDomNodes[iCard];
                try {
                    domNode.die();
                } catch (ex) {
                    console.warn('Problem cleaning up card:', ex, '\n', ex.stack);
                }
                switch (showMethod) {
                case 'animate':
                case 'immediate':
                    this._animatingDeadDomNodes.push(domNode);
                    break;
                case 'none':
                    domNode.parentNode.removeChild(domNode);
                    break;
                }
            }
            this._setScreenReaderVisibility();
        },
        removeAllCards: function () {
            return this.removeCardAndSuccessors(null, 'none');
        },
        _showCard: function (cardIndex, showMethod, navDirection) {
            if (cardIndex === this.activeCardIndex) {
                return;
            }
            let activeElement = document.activeElement;
            if (activeElement && activeElement.blur) {
                activeElement.blur();
            }
            let focused = document.querySelectorAll('.focus');
            for (let i = 0; i < focused.length; i++) {
                focused[i].classList.remove('focus');
            }
            if (cardIndex > this._cardStack.length - 1) {
                cardIndex = this._cardStack.length - 1;
            }
            if (this.activeCardIndex > this._cardStack.length - 1) {
                this.activeCardIndex = -1;
            }
            if (this.activeCardIndex === -1) {
                this.activeCardIndex = cardIndex === 0 ? cardIndex : cardIndex - 1;
            }
            let domNode = cardIndex !== null ? this._cardStack[cardIndex] : null;
            let beginNode = this._cardStack[this.activeCardIndex];
            let endNode = this._cardStack[cardIndex];
            let isForward = navDirection === 'forward';
            if (this._cardStack.length === 1) {
                this._zIndex = 0;
            }
            if (isForward && endNode.classList.contains('anim-overlay')) {
                beginNode = null;
                this._zIndex += 10;
            }
            if (beginNode && beginNode.classList.contains('anim-overlay')) {
                if (isForward) {
                    if (showMethod !== 'immediate') {
                        if (beginNode.classList.contains('anim-vertical')) {
                            removeClass(beginNode, 'anim-vertical');
                            addClass(beginNode, 'disabled-anim-vertical');
                        } else if (beginNode.classList.contains('anim-fade')) {
                            removeClass(beginNode, 'anim-fade');
                            addClass(beginNode, 'disabled-anim-fade');
                        }
                    }
                } else {
                    endNode = null;
                    this._zIndex -= 10;
                }
            }
            if (endNode && isForward && this._zIndex) {
                endNode.style.zIndex = this._zIndex;
            }
            let cardsNode = this._cardsNode;
            if (showMethod === 'immediate') {
                addClass(beginNode, 'no-anim');
                addClass(endNode, 'no-anim');
                cardsNode.clientWidth;
                this._eatingEventsUntilNextCard = false;
            } else if (showMethod === 'none') {
            } else {
                this._transitionCount = beginNode && endNode ? 2 : 1;
                this._eatingEventsUntilNextCard = true;
            }
            if (this.activeCardIndex === cardIndex) {
                removeClass(beginNode, 'before');
                removeClass(beginNode, 'after');
                addClass(beginNode, 'center');
            } else if (this.activeCardIndex > cardIndex) {
                removeClass(beginNode, 'center');
                addClass(beginNode, 'after');
                removeClass(endNode, 'before');
                addClass(endNode, 'center');
            } else {
                removeClass(beginNode, 'center');
                addClass(beginNode, 'before');
                removeClass(endNode, 'after');
                addClass(endNode, 'center');
            }
            let prevCard = this._cardStack[this.activeCardIndex];
            if (isForward && prevCard && prevCard.onHidden) {
                prevCard.onHidden();
            }
            domNode.navDirection = navDirection;
            if (navigator.largeTextEnabled) {
                [
                    'span',
                    'input',
                    'label',
                    'select',
                    'a',
                    'h2'
                ].forEach(tag => {
                    let tags = domNode.getElementsByTagName(tag);
                    for (let i = 0; i < tags.length; i++) {
                        if (!tags[i].classList.contains('p-pri') && !tags[i].classList.contains('p-sec')) {
                            if (tags[i].parentNode.nodeName !== 'H2') {
                                tags[i].classList.add('p-pri');
                            } else {
                                tags[i].classList.add('p-sec');
                            }
                        }
                    }
                });
            }
            if (showMethod === 'immediate') {
                cardsNode.clientWidth;
                removeClass(beginNode, 'no-anim');
                removeClass(endNode, 'no-anim');
                this._onCardVisible(domNode);
            }
            toaster.hide();
            this.activeCardIndex = cardIndex;
            this._setScreenReaderVisibility();
        },
        _setScreenReaderVisibility: function () {
            this._cardStack.forEach((card, index) => {
                card.setAttribute('aria-hidden', index !== this.activeCardIndex);
            }, this);
        },
        _onTransitionEnd: function (event) {
            if (!event.target.classList.contains('card')) {
                return;
            }
            let activeCard = this._cardStack[this.activeCardIndex];
            if (!activeCard) {
                return;
            }
            if (this._transitionCount > 0) {
                this._transitionCount -= 1;
            }
            if (this._transitionCount === 0) {
                if (this._eatingEventsUntilNextCard) {
                    this._eatingEventsUntilNextCard = false;
                }
                if (this._animatingDeadDomNodes.length) {
                    setTimeout(() => {
                        this._animatingDeadDomNodes.forEach(domNode => {
                            if (domNode.parentNode) {
                                domNode.parentNode.removeChild(domNode);
                            }
                        });
                        this._animatingDeadDomNodes = [];
                    }, 100);
                }
                let endNode = activeCard;
                if (endNode.classList.contains('disabled-anim-vertical')) {
                    removeClass(endNode, 'disabled-anim-vertical');
                    addClass(endNode, 'anim-vertical');
                } else if (endNode.classList.contains('disabled-anim-fade')) {
                    removeClass(endNode, 'disabled-anim-fade');
                    addClass(endNode, 'anim-fade');
                }
                if (this._afterTransitionAction) {
                    let afterTransitionAction = this._afterTransitionAction;
                    this._afterTransitionAction = null;
                    afterTransitionAction();
                }
                this._onCardVisible(activeCard);
                let nextCards = activeCard.nextCards;
                if (nextCards) {
                    console.log('Preloading cards: ' + nextCards);
                    require(nextCards.map(id => {
                        return 'cards/' + id;
                    }));
                }
            }
        },
        _onCardVisible: function (domNode) {
            if (domNode.onCardVisible) {
                domNode.onCardVisible(domNode.navDirection);
            }
            if (window.option) {
                window.option.show();
            }
            this._emitStartupEvents(domNode.skipEmitContentEvents);
        },
        _emitStartupEvents: function (skipEmitContentEvents) {
            if (!this._startupEventsEmitted) {
                if (window.startupCacheEventsSent) {
                    window.performance.mark('contentInteractive');
                    window.dispatchEvent(new CustomEvent('moz-content-interactive'));
                } else {
                    window.performance.mark('navigationLoaded');
                    window.dispatchEvent(new CustomEvent('moz-chrome-dom-loaded'));
                }
                window.performance.mark('navigationInteractive');
                window.dispatchEvent(new CustomEvent('moz-chrome-interactive'));
                if (!skipEmitContentEvents) {
                    evt.emit('metrics:contentDone');
                }
                this._startupEventsEmitted = true;
            }
        },
        eatEventsUntilNextCard: function () {
            this._eatingEventsUntilNextCard = true;
        },
        stopEatingEvents: function () {
            this._eatingEventsUntilNextCard = false;
        },
        assertNoCards: function () {
            if (this._cardStack.length) {
                throw new Error('There are ' + this._cardStack.length + ' cards but' + ' there should be ZERO');
            }
        },
        _closeApp: function () {
            this._endKeyClicked = false;
            window.close();
        },
        _initKeydownEngine: function () {
            window.addEventListener('keydown', evt => {
                let card = this._cardStack[this.activeCardIndex];
                if (evt.key === 'EndCall' && card.localName === 'cards-compose') {
                    if (!!this._cardStack[this.activeCardIndex].endkeyHandler) {
                        evt.preventDefault();
                        if (this._endKeyClicked) {
                            this._closeApp();
                        } else {
                            this._endKeyClicked = true;
                            window.dispatchEvent(new CustomEvent('email-endkey', {
                                detail: { callback: this._closeApp },
                                bubbles: true,
                                cancelable: false
                            }));
                        }
                    } else {
                    }
                } else {
                    this._onMaybeIntercept(evt);
                }
            });
        },
        showActivityDraftToast: function () {
            const timestamp = localStorage.getItem('emailComposeDraft');
            const HAS_DRAFT_TOAST_MS = 24 * 60 * 60 * 1000;
            if (timestamp) {
                if (Date.now() - timestamp < HAS_DRAFT_TOAST_MS) {
                    toaster.toast({ text: mozL10n.get('save-draft-toast') });
                }
                localStorage.removeItem('emailComposeDraft');
            }
        },
        saveActivityComposeDraft: function () {
            let draftComposer = JSON.parse(localStorage.getItem('emailComposeDraftContent'));
            if (draftComposer) {
                let composer = null;
                if (draftComposer.persistedNamer) {
                    composer = model.api.resumeMessageComposition(draftComposer.persistedNamer, () => {
                        composer.to = draftComposer.to;
                        composer.cc = draftComposer.cc;
                        composer.bcc = draftComposer.bcc;
                        composer.subject = draftComposer.subject;
                        composer.body.text = draftComposer.body.text;
                        composer.saveDraft(() => {
                            draftComposer = null;
                            composer = null;
                            localStorage.removeItem('emailComposeDraftContent');
                        });
                    });
                } else {
                    model.latestOnce('folder', folder => {
                        composer = model.api.beginMessageComposition(null, folder, null, () => {
                            composer.to = draftComposer.to;
                            composer.cc = draftComposer.cc;
                            composer.bcc = draftComposer.bcc;
                            composer.subject = draftComposer.subject;
                            composer.body.text = draftComposer.body.text;
                            composer.saveDraft(() => {
                                draftComposer = null;
                                composer = null;
                                localStorage.removeItem('emailComposeDraftContent');
                            });
                        });
                    });
                }
            }
        }
    };
    return cards;
});
define('array', ['require'], function (require) {
    let array = {
        indexOfGeneric: function (array, callback, thisObject) {
            let result = -1;
            array.some((value, index) => {
                if (callback.call(thisObject, value)) {
                    result = index;
                    return true;
                }
            });
            return result;
        }
    };
    return array;
});
define('header_cursor', [
    'require',
    'array',
    'evt',
    'model'
], function (require) {
    let array = require('array'), evt = require('evt'), model = require('model');
    function makeListener(type, obj) {
        return function () {
            let args = Array.prototype.slice.call(arguments);
            this.emit.apply(this, ['messages_' + type].concat(args));
        }.bind(obj);
    }
    function compareNoCase(str1, str2) {
        if (!str1) {
            str1 = '';
        }
        if (!str2) {
            str2 = '';
        }
        return str1.toLocaleUpperCase().localeCompare(str2.toLocaleUpperCase());
    }
    let sortFunc = {
        'date': function byDate(a, b) {
            return b.date - a.date;
        },
        'from': function byFrom(a, b) {
            return compareNoCase(a.author.address, b.author.address);
        },
        'to': function byTo(a, b) {
            return compareNoCase(a.to[0].address, b.to[0].address);
        },
        'subject': function bySubject(a, b) {
            return compareNoCase(a.subject, b.subject);
        }
    };
    function HeaderCursor() {
        evt.Emitter.call(this);
        this.searchMode = 'nonsearch';
    }
    HeaderCursor.prototype = evt.mix({
        currentMessage: null,
        messagesSlice: null,
        expectingMessageSuid: null,
        sliceEvents: [
            'splice',
            'change',
            'status',
            'remove',
            'complete'
        ],
        _inited: false,
        sortSymbol: false,
        folderSortType: 'date',
        init: function () {
            this._inited = true;
            this.on('messages_splice', this.onMessagesSplice.bind(this));
            this.on('messages_remove', this.onMessagesSpliceRemove.bind(this));
            this.on('messages_complete', () => {
                if (this.messagesSlice) {
                    this.messagesSlice.oncomplete = makeListener('complete', this);
                }
            });
            this.onLatestFolder = this.onLatestFolder.bind(this);
            model.latest('folder', this.onLatestFolder);
        },
        advance: function (direction) {
            let index = this.indexOfMessageById(this.currentMessage.header.id);
            switch (direction) {
            case 'previous':
                index -= 1;
                break;
            case 'next':
                index += 1;
                break;
            }
            let messages = this.messagesSlice.items;
            if (index < 0 || index >= messages.length) {
                return;
            }
            this.setCurrentMessageByIndex(index);
        },
        setCurrentMessageBySuid: function (messageSuid) {
            this.expectingMessageSuid = messageSuid;
            this.checkExpectingMessageSuid();
        },
        checkExpectingMessageSuid: function (eventIfNotFound) {
            let messageSuid = this.expectingMessageSuid;
            if (!messageSuid || !model.folder || model.folder.type !== 'inbox') {
                return;
            }
            let index = this.indexOfMessageById(messageSuid);
            if (index > -1) {
                this.expectingMessageSuid = null;
                return this.setCurrentMessageByIndex(index);
            }
            if (eventIfNotFound) {
                console.error('header_cursor could not find messageSuid ' + messageSuid + ', emitting messageSuidNotFound');
                this.emit('messageSuidNotFound', messageSuid);
            }
        },
        setCurrentMessage: function (header) {
            if (!header) {
                return;
            }
            this.setCurrentMessageByIndex(this.indexOfMessageById(header.id));
        },
        setCurrentMessageByIndex: function (index) {
            let messages = this.messagesSlice.items;
            if (index === -1 || index > messages.length - 1) {
                return;
            }
            let header = messages[index];
            if ('header' in header) {
                header = header.header;
            }
            let currentMessage = new CurrentMessage(header, {
                hasPrevious: index !== 0,
                hasNext: index !== messages.length - 1
            });
            this.emit('currentMessage', currentMessage, index);
            this.currentMessage = currentMessage;
        },
        indexOfMessageById: function (id) {
            let messages = this.messagesSlice && this.messagesSlice.items || [];
            return array.indexOfGeneric(messages, message => {
                let other = 'header' in message ? message.header.id : message.id;
                return other === id;
            });
        },
        onLatestFolder: function (folder) {
            if (!model.foldersSlice) {
                return;
            }
            this.folderSortType = 'date';
            this.freshMessagesSlice();
        },
        startSearch: function (phrase, whatToSearch) {
            this.searchMode = 'search';
            this.bindToSlice(model.api.searchFolderMessages(model.folder, phrase, whatToSearch));
        },
        endSearch: function () {
            this.die();
            this.searchMode = 'nonsearch';
            this.freshMessagesSlice();
        },
        freshMessagesSlice: function () {
            this.bindToSlice(model.api.viewFolderMessages(model.folder));
        },
        bindToSlice: function (messagesSlice) {
            this.die();
            this.messagesSlice = messagesSlice;
            this.sliceEvents.forEach(type => {
                messagesSlice['on' + type] = makeListener(type, this);
            });
        },
        onMessagesSplice: function (index, howMany, addedItems, requested, moreExpected) {
            if (!this.messagesSlice) {
                return;
            }
            if (this.sortType || addedItems.length || howMany) {
                if (this.messagesSlice.items) {
                    if (this.messagesSlice.items.length === this.messagesSlice.headerCount) {
                        this.sortType = this.sortType || this.folderSortType;
                        this.messagesSlice.items.sort(sortFunc[this.sortType]);
                        this.sortType = null;
                        if (this.sortSymbol) {
                            this.emit('messageSorted');
                            this.sortSymbol = false;
                        }
                    }
                }
            }
            if (this.messagesSlice.atTop && this.expectingMessageSuid && this.messagesSlice.items && this.messagesSlice.items.length) {
                this.checkExpectingMessageSuid(true);
            }
        },
        onMessagesSpliceRemove: function (removedHeader, removedFromIndex) {
            if (this.currentMessage !== removedHeader) {
                return this.setCurrentMessage(this.currentMessage);
            }
            let messages = this.messagesSlice.items;
            if (messages.length === 0) {
                return this.currentMessage = null;
            }
            let index = Math.min(removedFromIndex, messages.length - 1);
            let message = this.messagesSlice.items[index];
            this.setCurrentMessage(message);
        },
        die: function () {
            if (this.messagesSlice) {
                this.messagesSlice.die();
                this.messagesSlice = null;
            }
            this.currentMessage = null;
        },
        sortBy: function (type) {
            let fillSize;
            this.sortSymbol = true;
            if (this.messagesSlice) {
                fillSize = this.messagesSlice.headerCount;
            }
            this.sortType = type;
            this.folderSortType = type;
            this.bindToSlice(model.api.sortFolderMessages(model.folder, fillSize));
        }
    });
    let oldOn = HeaderCursor.prototype.on;
    HeaderCursor.prototype.on = function () {
        if (!this._inited) {
            this.init();
            HeaderCursor.prototype.on = oldOn;
        }
        return oldOn.apply(this, arguments);
    };
    function CurrentMessage(header, siblings) {
        this.header = header;
        this.siblings = siblings;
    }
    CurrentMessage.prototype = {
        header: null,
        siblings: null
    };
    return {
        CurrentMessage: CurrentMessage,
        cursor: new HeaderCursor()
    };
});
define('ext/ext/equal', ['require'], function (require) {
    var COMPARE_DEPTH = 6;
    function boundedCmpObjs(a, b, depthLeft) {
        var aAttrCount = 0, bAttrCount = 0, key, nextDepth = depthLeft - 1;
        if ('toJSON' in a)
            a = a.toJSON();
        if ('toJSON' in b)
            b = b.toJSON();
        for (key in a) {
            aAttrCount++;
            if (!(key in b))
                return false;
            if (depthLeft) {
                if (!equal(a[key], b[key], nextDepth))
                    return false;
            } else {
                if (a[key] !== b[key])
                    return false;
            }
        }
        for (key in b) {
            bAttrCount++;
        }
        if (aAttrCount !== bAttrCount)
            return false;
        return true;
    }
    function equal(a, b, depthLeft) {
        if (depthLeft === undefined) {
            depthLeft = COMPARE_DEPTH;
        }
        var ta = typeof a, tb = typeof b;
        if (ta !== 'object' || tb !== ta || a == null || b == null)
            return a === b;
        if (a === b)
            return true;
        if (Array.isArray(a)) {
            if (!Array.isArray(b))
                return false;
            if (a.length !== b.length)
                return false;
            for (var iArr = 0; iArr < a.length; iArr++) {
                if (!equal(a[iArr], b[iArr], depthLeft - 1))
                    return false;
            }
            return true;
        }
        return boundedCmpObjs(a, b, depthLeft);
    }
    return equal;
});
;
define('ext/logic', [
    'require',
    'evt',
    './ext/equal'
], function (require) {
    var evt = require('evt');
    var equal = require('./ext/equal');
    function logic() {
        return logic.event.apply(logic, arguments);
    }
    evt.mix(logic);
    logic.scope = function (namespace, defaultDetails) {
        return new Scope(namespace, defaultDetails);
    };
    var objectToScope = new WeakMap();
    function toScope(scope) {
        if (!(scope instanceof Scope)) {
            scope = objectToScope.get(scope);
            if (!scope) {
                throw new Error('Invalid scope ' + scope + ' passed to logic.event(); ' + 'did you remember to call logic.defineScope()? ' + new Error().stack);
            }
        }
        return scope;
    }
    logic.defineScope = function (obj, namespace, defaultDetails) {
        if (!namespace && obj && obj.constructor && obj.constructor.name) {
            namespace = obj.constructor.name;
        }
        var scope = new Scope(namespace, defaultDetails);
        objectToScope.set(obj, scope);
        return scope;
    };
    logic.subscope = function (scope, defaultDetails) {
        scope = toScope(scope);
        return new Scope(scope.namespace, into(shallowClone(scope.defaultDetails), shallowClone(defaultDetails)));
    };
    logic.event = function (scope, type, details) {
        scope = toScope(scope);
        var isDefaultPrevented = false;
        var preprocessEvent = {
            scope: scope,
            namespace: scope.namespace,
            type: type,
            details: details,
            preventDefault: function () {
                isDefaultPrevented = true;
            }
        };
        logic.emit('preprocessEvent', preprocessEvent);
        if (isDefaultPrevented) {
            return { id: 0 };
        }
        type = preprocessEvent.type;
        details = preprocessEvent.details;
        if (typeof type !== 'string') {
            throw new Error('Invalid "type" passed to logic.event(); ' + 'expected a string, got "' + type + '"');
        }
        if (scope.defaultDetails) {
            if (isPlainObject(details)) {
                details = into(shallowClone(scope.defaultDetails), shallowClone(details));
            } else {
                details = shallowClone(scope.defaultDetails);
            }
        } else {
            details = shallowClone(details);
        }
        var event = new LogicEvent(scope, type, details);
        logic.emit('censorEvent', event);
        logic.emit('event', event);
        if (logic.realtimeLogEverything) {
            dump('logic: ' + event.toString() + '\n');
        }
        return event;
    };
    logic.underTest = false;
    logic._currentTestRejectFunction = null;
    logic.fail = function (ex) {
        if (logic.underTest) {
            if (logic._currentTestRejectFunction) {
                logic._currentTestRejectFunction(ex);
            } else {
                throw ex;
            }
        } else {
            console.error('Logic fail:', ex);
        }
    };
    var nextId = 1;
    logic.uniqueId = function () {
        return nextId++;
    };
    logic.isCensored = false;
    logic.realtimeLogEverything = false;
    var interceptions = {};
    logic.interceptable = function (type, fn) {
        if (interceptions[type]) {
            return interceptions[type]();
        } else {
            return fn();
        }
    };
    logic.interceptOnce = function (type, replacementFn) {
        var prevFn = interceptions[type];
        interceptions[type] = function () {
            interceptions[type] = prevFn;
            return replacementFn();
        };
    };
    logic.match = function (ns, type, detailPredicate) {
        return new LogicMatcher(LogicMatcher.normalizeMatchArgs(ns, type, detailPredicate));
    };
    function MismatchError(matcher, event) {
        this.matcher = matcher;
        this.event = event;
    }
    MismatchError.prototype = Object.create(Error.prototype, {
        constructor: { value: MismatchError },
        toString: {
            value: function () {
                if (this.matcher.not) {
                    return 'MismatchError: expected ' + this.event + ' to not occur (failIfMatched ' + this.matcher + ').';
                } else {
                    return 'MismatchError: expected ' + this.event + ' to match ' + JSON.stringify(this.matcher.detailPredicate) + '.';
                }
            }
        }
    });
    function LogicMatcher(opts) {
        this.matchedLogs = opts.prevMatcher ? opts.prevMatcher.matchedLogs : [];
        this.capturedLogs = [];
        this.ns = opts.ns;
        this.type = opts.type;
        this.detailPredicate = opts.detailPredicate;
        this.failOnMismatchedDetails = true;
        this.not = opts.not;
        this.timeoutMS = 2000;
        this.resolved = false;
        this.anotherMatcherNeedsMyLogs = false;
        if (opts.prevMatcher) {
            opts.prevMatcher.anotherMatcherNeedsMyLogs = true;
        }
        logic.defineScope(this, 'LogicMatcher');
        var hasPrevPromise = !!opts.prevPromise;
        var normalizedPrevPromise = opts.prevPromise || Promise.resolve();
        if (this.not) {
            this.promise = normalizedPrevPromise.then(() => {
                this.capturedLogs.some(event => {
                    if ((!this.ns || event.namespace === this.ns) && event.matches(this.type, this.detailPredicate)) {
                        throw new MismatchError(this, event);
                    }
                });
            });
        } else if (this.type) {
            this.promise = new Promise((resolve, reject) => {
                var subscribeToNextMatch = () => {
                    var timeoutId = setTimeout(() => {
                        logic(this, 'failedMatch', {
                            ns: this.ns,
                            type: this.type,
                            detailPredicate: this.detailPredicate,
                            capturedLogs: this.capturedLogs
                        });
                        reject(new Error('LogicMatcherTimeout: ' + this));
                    }, this.timeoutMS);
                    var resolveThisMatcher = event => {
                        this.resolved = true;
                        this.capturedLogs = [];
                        if (!this.anotherMatcherNeedsMyLogs) {
                            this.removeMatchListener();
                        }
                    };
                    var matchFn = event => {
                        this.capturedLogs.push(event);
                        if (this.resolved) {
                            return;
                        }
                        if (this.ns && event.namespace !== this.ns || event.type !== this.type) {
                            return false;
                        }
                        if (event.matches(this.type, this.detailPredicate)) {
                            resolveThisMatcher(event);
                            this.matchedLogs.push(event);
                            clearTimeout(timeoutId);
                            logic(this, 'match', {
                                ns: this.ns,
                                type: this.type,
                                event: event
                            });
                            resolve(event);
                            return true;
                        } else {
                            if (this.failOnMismatchedDetails) {
                                resolveThisMatcher(event);
                                reject(new MismatchError(this, event));
                                return true;
                            } else {
                            }
                        }
                        return false;
                    };
                    this.removeMatchListener = () => {
                        logic.removeListener('event', matchFn);
                    };
                    logic.on('event', matchFn);
                    if (opts.prevMatcher) {
                        var prevLogs = opts.prevMatcher.capturedLogs;
                        var matchIndex = prevLogs.findIndex(matchFn);
                        if (matchIndex !== -1) {
                            this.capturedLogs = prevLogs.slice(matchIndex + 1);
                        }
                        opts.prevMatcher.removeMatchListener();
                    }
                };
                if (hasPrevPromise) {
                    normalizedPrevPromise.then(subscribeToNextMatch, e => reject(e));
                } else {
                    try {
                        subscribeToNextMatch();
                    } catch (e) {
                        reject(e);
                    }
                }
            });
        } else {
            this.promise = normalizedPrevPromise;
        }
    }
    LogicMatcher.normalizeMatchArgs = function (ns, type, details) {
        if (typeof type === 'object') {
            details = type;
            type = ns;
            ns = null;
        }
        return {
            ns: ns,
            type: type,
            detailPredicate: details
        };
    };
    LogicMatcher.prototype = {
        match(ns, type, details) {
            var args = LogicMatcher.normalizeMatchArgs(ns, type, details);
            args.prevMatcher = this;
            args.prevPromise = this.promise;
            return new LogicMatcher(args);
        },
        failIfMatched(ns, type, details) {
            var args = LogicMatcher.normalizeMatchArgs(ns, type, details);
            args.not = true;
            args.prevMatcher = this;
            args.prevPromise = this.promise;
            return new LogicMatcher(args);
        },
        then(fn, catchFn) {
            return new LogicMatcher({
                prevPromise: this.promise.then(() => {
                    var ret = fn(this.matchedLogs.slice());
                    if (ret instanceof Promise) {
                        ret = new LogicMatcher({ prevPromise: ret });
                    }
                    return ret;
                }, catchFn)
            });
        },
        toString() {
            return '<LogicMatcher ' + (this.ns ? this.ns + '/' : '') + this.type + ' ' + new ObjectSimplifier().simplify(this.detailPredicate) + '>';
        }
    };
    function Scope(namespace, defaultDetails) {
        this.namespace = namespace;
        if (defaultDetails && !isPlainObject(defaultDetails)) {
            throw new Error('Invalid defaultDetails; expected a plain-old object: ' + defaultDetails);
        }
        this.defaultDetails = defaultDetails;
    }
    function ObjectSimplifier(opts) {
        opts = opts || {};
        this.maxDepth = opts.maxDepth || 10;
        this.maxStringLength = opts.maxStringLength || 1000;
        this.maxArrayLength = opts.maxArrayLength || 1000;
        this.maxObjectLength = opts.maxObjectLength || 10;
    }
    ObjectSimplifier.prototype = {
        simplify: function (x) {
            return this._simplify(x, 0, new WeakSet());
        },
        _simplify: function (x, depth, cacheSet) {
            if (cacheSet.has(x)) {
                return '(cycle)';
            }
            if (typeof x === 'number') {
                return x;
            } else if (typeof x === 'string') {
                return x.slice(0, this.maxStringLength);
            } else if (x && x.BYTES_PER_ELEMENT) {
                return x.slice(0, this.maxArrayLength);
            } else if (Array.isArray(x)) {
                if (depth < this.maxDepth) {
                    return x.slice(0, this.maxArrayLength).map(element => this._simplify(element, depth + 1, cacheSet));
                } else {
                    return '[Array length=' + x.length + ']';
                }
            } else if (x && typeof x === 'object') {
                cacheSet.add(x);
                if (!isPlainObject(x)) {
                    if (x.toJSON) {
                        return this._simplify(x.toJSON(), depth, cacheSet);
                    } else if (x.toString) {
                        return this._simplify(x.toString(), depth, cacheSet);
                    } else {
                        return '(?)';
                    }
                } else {
                    if (depth < this.maxDepth) {
                        var retObj = {};
                        var idx = 0;
                        for (var key in x) {
                            if (idx > this.maxObjectLength) {
                                break;
                            }
                            retObj[key] = this._simplify(x[key], depth + 1, cacheSet);
                            idx++;
                        }
                        return retObj;
                    } else if (x.toString) {
                        return this._simplify(x.toString(), depth, cacheSet);
                    } else {
                        return '(object?)';
                    }
                }
            } else if (typeof x === 'function') {
                return '(function)';
            } else {
                return x;
            }
        }
    };
    function LogicEvent(scope, type, details) {
        if (!(scope instanceof Scope)) {
            throw new Error('Invalid "scope" passed to LogicEvent(); ' + 'did you remember to call logic.defineScope()?');
        }
        this.scope = scope;
        this.type = type;
        this.details = details;
        this.time = Date.now();
        this.id = logic.uniqueId();
        this.jsonRepresentation = {
            namespace: this.scope.namespace,
            type: this.type,
            details: new ObjectSimplifier().simplify(this.details),
            time: this.time,
            id: this.id
        };
    }
    LogicEvent.fromJSON = function (data) {
        var event = new LogicEvent(new Scope(data.namespace), data.type, data.details);
        event.time = data.time;
        event.id = data.id;
        return event;
    };
    LogicEvent.prototype = {
        get namespace() {
            return this.scope.namespace;
        },
        toJSON: function () {
            return this.jsonRepresentation;
        },
        toString: function () {
            return '<LogicEvent ' + this.namespace + '/' + this.type + ' ' + JSON.stringify(this.jsonRepresentation.details) + '>';
        },
        matches: function (type, detailPredicate) {
            if (this.type !== type) {
                return false;
            }
            if (typeof detailPredicate === 'function') {
                return !!detailPredicate(this.details);
            } else if (isPlainObject(detailPredicate)) {
                for (var key in detailPredicate) {
                    var expected = detailPredicate && detailPredicate[key];
                    var actual = this.details && this.details[key];
                    if (actual === undefined) {
                        actual = null;
                    }
                    if (expected === undefined) {
                        continue;
                    } else if (!this.details || !equal(expected, actual)) {
                        return false;
                    }
                }
                return true;
            } else if (detailPredicate != null) {
                return equal(this.details, detailPredicate);
            } else {
                return true;
            }
        }
    };
    function isPlainObject(obj) {
        if (!obj || typeof obj !== 'object') {
            return false;
        }
        if (obj.toString && obj.toString() !== '[object Object]') {
            return false;
        }
        for (var k in obj) {
            if (typeof k === 'function') {
                return false;
            }
        }
        return true;
    }
    logic.isPlainObject = isPlainObject;
    var promiseToStartEventMap = new WeakMap();
    var promiseToResultEventMap = new WeakMap();
    logic.startAsync = function (scope, type, details) {
        var resolve, reject;
        var promise = logic.async(scope, type, details, (_resolve, _reject) => {
            resolve = _resolve;
            reject = _reject;
        });
        return {
            resolve: resolve,
            reject: reject
        };
    };
    logic.async = function (scope, type, details, fn) {
        if (!fn && typeof details === 'function') {
            fn = details;
            details = null;
        }
        scope = logic.subscope(scope, details);
        var startEvent;
        var promise = new Promise((resolve, reject) => {
            startEvent = logic(scope, 'begin ' + type, {
                asyncStatus: 0,
                asyncName: type
            });
            fn(result => {
                promiseToResultEventMap.set(promise, logic(scope, type, {
                    asyncStatus: 1,
                    sourceEventIds: [startEvent.id],
                    result: result
                }));
                resolve(result);
            }, error => {
                promiseToResultEventMap.set(promise, logic(scope, type, {
                    asyncStatus: 2,
                    sourceEventIds: [startEvent.id],
                    error: error
                }));
                reject(error);
            });
        });
        promiseToStartEventMap.set(promise, startEvent);
        return promise;
    };
    logic.await = function (scope, type, details, promise) {
        if (!promise && details.then) {
            promise = details;
            details = null;
        }
        scope = logic.subscope(scope, details).subscope(scope);
        var startEvent = promiseToStartEventMap.get(promise);
        var awaitEvent = logic.event(scope, 'await ' + type, {
            awaitStatus: 0,
            sourceEventIds: startEvent ? [startEvent.id] : null,
            awaitName: type
        });
        return promise.then(result => {
            var resultEvent = promiseToResultEventMap.get(promise);
            logic(scope, type, {
                awaitStatus: 1,
                result: result,
                sourceEventIds: resultEvent ? [
                    resultEvent.id,
                    awaitEvent.id
                ] : [awaitEvent.id]
            });
            return result;
        }, error => {
            var resultEvent = promiseToResultEventMap.get(promise);
            logic(scope, type, {
                awaitStatus: 2,
                error: error,
                sourceEventIds: resultEvent ? [
                    resultEvent.id,
                    awaitEvent.id
                ] : [awaitEvent.id]
            });
            throw error;
        });
    };
    function shallowClone(x) {
        if (isPlainObject(x)) {
            var ret = {};
            for (var key in x) {
                ret[key] = x[key];
            }
            return ret;
        } else {
            return x;
        }
    }
    function into(target, source) {
        if (!target) {
            target = {};
        }
        for (var key in source) {
            target[key] = source[key];
        }
        return target;
    }
    return logic;
});
(function (root, factory) {
    'use strict';
    if (typeof define === 'function' && define.amd) {
        define('ext/ext/addressparser', factory);
    } else if (typeof exports === 'object') {
        module.exports = factory();
    } else {
        root.addressparser = factory();
    }
}(this, function () {
    'use strict';
    var addressparser = {};
    addressparser.parse = function (str) {
        var tokenizer = new addressparser.Tokenizer(str), tokens = tokenizer.tokenize();
        var addresses = [], address = [], parsedAddresses = [];
        tokens.forEach(function (token) {
            if (token.type === 'operator' && (token.value === ',' || token.value === ';')) {
                if (address.length) {
                    addresses.push(address);
                }
                address = [];
            } else {
                address.push(token);
            }
        });
        if (address.length) {
            addresses.push(address);
        }
        addresses.forEach(function (address) {
            address = addressparser._handleAddress(address);
            if (address.length) {
                parsedAddresses = parsedAddresses.concat(address);
            }
        });
        return parsedAddresses;
    };
    addressparser._handleAddress = function (tokens) {
        var token, isGroup = false, state = 'text', address, addresses = [], data = {
                address: [],
                comment: [],
                group: [],
                text: []
            }, i, len;
        for (i = 0, len = tokens.length; i < len; i++) {
            token = tokens[i];
            if (token.type === 'operator') {
                switch (token.value) {
                case '<':
                    state = 'address';
                    break;
                case '(':
                    state = 'comment';
                    break;
                case ':':
                    state = 'group';
                    isGroup = true;
                    break;
                default:
                    state = 'text';
                }
            } else {
                if (token.value) {
                    data[state].push(token.value);
                }
            }
        }
        if (!data.text.length && data.comment.length) {
            data.text = data.comment;
            data.comment = [];
        }
        if (isGroup) {
            data.text = data.text.join(' ');
            addresses.push({
                name: data.text || address && address.name,
                group: data.group.length ? addressparser.parse(data.group.join(',')) : []
            });
        } else {
            if (!data.address.length && data.text.length) {
                for (i = data.text.length - 1; i >= 0; i--) {
                    if (data.text[i].match(/^[^@\s]+@[^@\s]+$/)) {
                        data.address = data.text.splice(i, 1);
                        break;
                    }
                }
                var _regexHandler = function (address) {
                    if (!data.address.length) {
                        data.address = [address.trim()];
                        return ' ';
                    } else {
                        return address;
                    }
                };
                if (!data.address.length) {
                    for (i = data.text.length - 1; i >= 0; i--) {
                        data.text[i] = data.text[i].replace(/\s*\b[^@\s]+@[^@\s]+\b\s*/, _regexHandler).trim();
                        if (data.address.length) {
                            break;
                        }
                    }
                }
            }
            if (!data.text.length && data.comment.length) {
                data.text = data.comment;
                data.comment = [];
            }
            if (data.address.length > 1) {
                data.text = data.text.concat(data.address.splice(1));
            }
            data.text = data.text.join(' ');
            data.address = data.address.join(' ');
            if (!data.address && isGroup) {
                return [];
            } else {
                address = {
                    address: data.address || data.text || '',
                    name: data.text || data.address || ''
                };
                if (address.address === address.name) {
                    if ((address.address || '').match(/^[^@\s]+@[^@\s]+$/)) {
                        address.name = '';
                    } else {
                        address.address = '';
                    }
                }
                addresses.push(address);
            }
        }
        return addresses;
    };
    addressparser.Tokenizer = function (str) {
        this.str = (str || '').toString();
        this.operatorCurrent = '';
        this.operatorExpecting = '';
        this.node = null;
        this.escaped = false;
        this.list = [];
    };
    addressparser.Tokenizer.prototype.operators = {
        '"': '"',
        '(': ')',
        '<': '>',
        ',': '',
        ':': ';',
        ';': ''
    };
    addressparser.Tokenizer.prototype.tokenize = function () {
        var chr, list = [];
        for (var i = 0, len = this.str.length; i < len; i++) {
            chr = this.str.charAt(i);
            this.checkChar(chr);
        }
        this.list.forEach(function (node) {
            node.value = (node.value || '').toString().trim();
            if (node.value) {
                list.push(node);
            }
        });
        return list;
    };
    addressparser.Tokenizer.prototype.checkChar = function (chr) {
        if ((chr in this.operators || chr === '\\') && this.escaped) {
            this.escaped = false;
        } else if (this.operatorExpecting && chr === this.operatorExpecting) {
            this.node = {
                type: 'operator',
                value: chr
            };
            this.list.push(this.node);
            this.node = null;
            this.operatorExpecting = '';
            this.escaped = false;
            return;
        } else if (!this.operatorExpecting && chr in this.operators) {
            this.node = {
                type: 'operator',
                value: chr
            };
            this.list.push(this.node);
            this.node = null;
            this.operatorExpecting = this.operators[chr];
            this.escaped = false;
            return;
        }
        if (!this.escaped && chr === '\\') {
            this.escaped = true;
            return;
        }
        if (!this.node) {
            this.node = {
                type: 'text',
                value: ''
            };
            this.list.push(this.node);
        }
        if (this.escaped && chr !== '\\') {
            this.node.value += '\\';
        }
        this.node.value += chr;
        this.escaped = false;
    };
    return addressparser;
}));
define('ext/mailapi', [
    'exports',
    './logic',
    './ext/addressparser'
], function (exports, logic, addressparser) {
    function objCopy(obj) {
        var copy = {};
        Object.keys(obj).forEach(function (key) {
            copy[key] = obj[key];
        });
        return copy;
    }
    function reportError() {
        var msg = null;
        for (var i = 0; i < arguments.length; i++) {
            if (msg)
                msg += ' ' + arguments[i];
            else
                msg = '' + arguments[i];
        }
        logic.fail(new Error(msg));
    }
    var unexpectedBridgeDataError = reportError, internalError = reportError, reportClientCodeError = reportError;
    var HEADER_CACHE_LIMIT = 8;
    function MailAccount(api, wireRep, acctsSlice) {
        this._api = api;
        this.id = wireRep.id;
        this._wireRep = wireRep;
        this.acctsSlice = acctsSlice;
        this.type = wireRep.type;
        this.name = wireRep.name;
        this.authenticatorId = wireRep.authenticatorId;
        this.label = wireRep.label ? wireRep.label : wireRep.name.split('@')[1].split('.')[0];
        this.syncRange = wireRep.syncRange;
        this.syncInterval = wireRep.syncInterval;
        this.notifyOnNew = wireRep.notifyOnNew;
        this.playSoundOnSend = wireRep.playSoundOnSend;
        this.syncEnable = wireRep.syncEnable;
        this.public = wireRep.public;
        this.enabled = wireRep.enabled;
        this.problems = wireRep.problems;
        this.identities = [];
        for (var iIdent = 0; iIdent < wireRep.identities.length; iIdent++) {
            this.identities.push(new MailSenderIdentity(this._api, wireRep.identities[iIdent]));
        }
        this.username = wireRep.credentials.username;
        this.password = wireRep.credentials.password;
        this.servers = wireRep.servers;
        this.authMechanism = wireRep.credentials.oauth2 ? 'oauth2' : 'password';
        this.element = null;
        this.data = null;
    }
    MailAccount.prototype = {
        toString: function () {
            return '[MailAccount: ' + this.type + ' ' + this.id + ']';
        },
        toJSON: function () {
            return {
                type: 'MailAccount',
                accountType: this.type,
                id: this.id
            };
        },
        __update: function (wireRep) {
            this.enabled = wireRep.enabled;
            this.problems = wireRep.problems;
            this.syncRange = wireRep.syncRange;
            this.syncInterval = wireRep.syncInterval;
            this.notifyOnNew = wireRep.notifyOnNew;
            this.playSoundOnSend = wireRep.playSoundOnSend;
            this.label = wireRep.label;
            this._wireRep.defaultPriority = wireRep.defaultPriority;
            this.syncEnable = wireRep.syncEnable;
            this.public = wireRep.public;
            for (var i = 0; i < wireRep.identities.length; i++) {
                if (this.identities[i]) {
                    this.identities[i].__update(wireRep.identities[i]);
                } else {
                    this.identities.push(new MailSenderIdentity(this._api, wireRep.identities[i]));
                }
            }
        },
        __die: function () {
        },
        clearProblems: function (forceIgnore, callback) {
            this._api._clearAccountProblems(this, forceIgnore, callback);
        },
        modifyAccount: function (mods, callback) {
            this._api._modifyAccount(this, mods, callback);
        },
        deleteAccount: function () {
            this._api._deleteAccount(this);
        },
        get isDefault() {
            if (!this.acctsSlice)
                throw new Error('No account slice available');
            return this.acctsSlice.defaultAccount === this;
        }
    };
    function MailSenderIdentity(api, wireRep) {
        this._api = api;
        this.id = wireRep.id;
        this.name = wireRep.name;
        this.address = wireRep.address;
        this.replyTo = wireRep.replyTo;
        this.signature = wireRep.signature;
        this.signatureEnabled = wireRep.signatureEnabled;
    }
    MailSenderIdentity.prototype = {
        toString: function () {
            return '[MailSenderIdentity: ' + this.type + ' ' + this.id + ']';
        },
        toJSON: function () {
            return { type: 'MailSenderIdentity' };
        },
        __update: function (wireRep) {
            this.id = wireRep.id;
            this.name = wireRep.name;
            this.address = wireRep.address;
            this.replyTo = wireRep.replyTo;
            this.signature = wireRep.signature;
            this.signatureEnabled = wireRep.signatureEnabled;
        },
        modifyIdentity: function (mods, callback) {
            if (typeof mods.signature !== 'undefined') {
                this.signature = mods.signature;
            }
            if (typeof mods.signatureEnabled !== 'undefined') {
                this.signatureEnabled = mods.signatureEnabled;
            }
            this._api._modifyIdentity(this, mods, callback);
        },
        __die: function () {
        }
    };
    exports._MailFolder = MailFolder;
    function MailFolder(api, wireRep) {
        this._api = api;
        this.__update(wireRep);
        this.onchange = null;
        this.onremove = null;
        this.element = null;
        this.data = null;
    }
    MailFolder.prototype = {
        toString: function () {
            return '[MailFolder: ' + this.path + ']';
        },
        toJSON: function () {
            return {
                type: this.type,
                path: this.path
            };
        },
        __update: function (wireRep) {
            this._wireRep = wireRep;
            this.unread = wireRep.unreadCount;
            this.lastSyncedAt = wireRep.lastSyncedAt ? new Date(wireRep.lastSyncedAt) : null;
            this.path = wireRep.path;
            this.id = wireRep.id;
            this.name = wireRep.name;
            this.path = wireRep.path;
            this.depth = wireRep.depth;
            this.type = wireRep.type;
            this.name = this._api.l10n_folder_name(this.name, this.type);
            this.selectable = wireRep.type !== 'account' && wireRep.type !== 'nomail';
            this.neededForHierarchy = !this.selectable;
            switch (this.type) {
            case 'localdrafts':
            case 'outbox':
            case 'account':
            case 'nomail':
                this.isValidMoveTarget = false;
                break;
            default:
                this.isValidMoveTarget = true;
            }
        },
        __die: function () {
        }
    };
    function filterOutBuiltinFlags(flags) {
        var outFlags = [];
        for (var i = flags.length - 1; i >= 0; i--) {
            if (flags[i][0] !== '\\')
                outFlags.push(flags[i]);
        }
        return outFlags;
    }
    function serializeMessageName(x) {
        return {
            date: x.date.valueOf(),
            suid: x.id,
            guid: x.guid
        };
    }
    var ContactCache = exports.ContactCache = {
        _contactCache: Object.create(null),
        _cacheHitEntries: 0,
        _cacheEmptyEntries: 0,
        MAX_CACHE_HITS: 256,
        MAX_CACHE_EMPTY: 1024,
        _livePeepsById: Object.create(null),
        _livePeepsByEmail: Object.create(null),
        pendingLookupCount: 0,
        callbacks: [],
        init: function () {
            var contactsAPI = ContactsManager;
            if (!contactsAPI)
                return;
            this._onContactChange = this._onContactChange.bind(this);
            ContactsManager.addEventListener(ContactsManager.EventMap.CONTACT_CHANGE, this._onContactChange);
        },
        _resetCache: function () {
            this._contactCache = Object.create(null);
            this._cacheHitEntries = 0;
            this._cacheEmptyEntries = 0;
        },
        shutdown: function () {
            var contactsAPI = ContactsManager;
            if (!contactsAPI)
                return;
            contactsAPI.oncontactchange = null;
        },
        _onContactChange: function (event) {
            var contactsAPI = ContactsManager;
            var livePeepsById = this._livePeepsById, livePeepsByEmail = this._livePeepsByEmail;
            if (this._cacheHitEntries || this._cacheEmptyEntries)
                this._resetCache();
            if (event.reason === ContactsManager.ChangeReason.REMOVE) {
                function cleanOutPeeps(livePeeps) {
                    for (var iPeep = 0; iPeep < livePeeps.length; iPeep++) {
                        var peep = livePeeps[iPeep];
                        peep.contactId = null;
                        peep.contactName = '';
                        if (peep.onchange) {
                            try {
                                peep.onchange(peep);
                            } catch (ex) {
                                reportClientCodeError('peep.onchange error', ex, '\n', ex.stack);
                            }
                        }
                    }
                }
                livePeeps = livePeepsById[event.contacts[0].id];
                if (livePeeps) {
                    cleanOutPeeps(livePeeps);
                    delete livePeepsById[event.contactID];
                }
            } else {
                var contact = event.contacts[0], livePeeps, iPeep, peep;
                if (event.reason === ContactsManager.ChangeReason.UPDATE) {
                    livePeeps = livePeepsById[contact.id];
                    if (livePeeps) {
                        var contactEmails = contact.email ? contact.email.map(function (e) {
                            return e.value;
                        }) : [];
                        for (iPeep = 0; iPeep < livePeeps.length; iPeep++) {
                            peep = livePeeps[iPeep];
                            if (contactEmails.indexOf(peep.address) === -1) {
                                livePeeps.splice(iPeep--, 1);
                                peep.contactId = null;
                                peep.contactName = '';
                                if (peep.onchange) {
                                    try {
                                        peep.onchange(peep);
                                        window.dispatchEvent(new CustomEvent('contact-updated', {
                                            detail: {
                                                peep: peep,
                                                photo: contact.photoBlob ? contact.photoBlob : null
                                            },
                                            bubbles: true,
                                            cancelable: false
                                        }));
                                    } catch (ex) {
                                        reportClientCodeError('peep.onchange error', ex, '\n', ex.stack);
                                    }
                                }
                            }
                        }
                        if (livePeeps.length === 0)
                            delete livePeepsById[contact.id];
                    }
                }
                if (!contact.email)
                    return;
                for (var iEmail = 0; iEmail < contact.email.length; iEmail++) {
                    var email = contact.email[iEmail].value;
                    livePeeps = livePeepsByEmail[email];
                    if (!livePeeps)
                        continue;
                    for (iPeep = 0; iPeep < livePeeps.length; iPeep++) {
                        peep = livePeeps[iPeep];
                        if (!peep.contactId) {
                            peep.contactId = contact.id;
                            var idLivePeeps = livePeepsById[peep.contactId];
                            if (idLivePeeps === undefined)
                                idLivePeeps = livePeepsById[peep.contactId] = [];
                            idLivePeeps.push(peep);
                        } else if (peep.contactId !== contact.id) {
                            continue;
                        }
                        peep._thumbnailBlob = contact.photoBlob && contact.photoBlob.length ? contact.photoBlob : null;
                        if (contact.name && contact.name.length)
                            peep.contactName = contact.name;
                        if (peep.onchange) {
                            try {
                                peep.onchange(peep);
                                window.dispatchEvent(new CustomEvent('contact-updated', {
                                    detail: {
                                        peep: peep,
                                        photo: contact.photoBlob ? contact.photoBlob : null
                                    },
                                    bubbles: true,
                                    cancelable: false
                                }));
                            } catch (ex) {
                                reportClientCodeError('peep.onchange error', ex, '\n', ex.stack);
                            }
                        }
                    }
                }
            }
        },
        resolvePeeps: function (addressPairs) {
            if (addressPairs == null)
                return null;
            var resolved = [];
            for (var i = 0; i < addressPairs.length; i++) {
                resolved.push(this.resolvePeep(addressPairs[i]));
            }
            return resolved;
        },
        resolvePeep: function (addressPair) {
            if (!addressPair) {
                console.error('NO ADDRESS PAIR?', new Error().stack);
                return;
            }
            var emailAddress = addressPair.address;
            var entry = this._contactCache[emailAddress], contact, peep;
            var contactsAPI = ContactsManager;
            if (entry === null || !contactsAPI) {
                peep = new MailPeep(addressPair.name || '', emailAddress, null, null);
                if (!contactsAPI)
                    return peep;
            } else if (entry !== undefined) {
                var name = addressPair.name || '';
                if (entry.name && entry.name.length)
                    name = entry.name;
                peep = new MailPeep(name, emailAddress, entry.id, entry.photoBlob && entry.photoBlob.length ? entry.photoBlob : null);
            } else {
                peep = new MailPeep(addressPair.name || '', emailAddress, null, null);
                this._contactCache[emailAddress] = null;
                this.pendingLookupCount++;
                var filterValue = emailAddress ? emailAddress.toLowerCase() : '';
                var req = contactsAPI.find({
                    filterBy: [ContactsManager.FilterByOption.EMAIL],
                    filterOption: ContactsManager.FilterOption.EQUALS,
                    filterValue: filterValue
                }, 1);
                var self = this, handleResult = function (result) {
                        if (result && result.length) {
                            var contact = result[0];
                            ContactCache._contactCache[emailAddress] = contact;
                            if (++ContactCache._cacheHitEntries > ContactCache.MAX_CACHE_HITS)
                                self._resetCache();
                            var peepsToFixup = self._livePeepsByEmail[emailAddress];
                            if (!peepsToFixup)
                                return;
                            for (var i = 0; i < peepsToFixup.length; i++) {
                                var peep = peepsToFixup[i];
                                if (!peep.contactId) {
                                    peep.contactId = contact.id;
                                    var livePeeps = self._livePeepsById[peep.contactId];
                                    if (livePeeps === undefined)
                                        livePeeps = self._livePeepsById[peep.contactId] = [];
                                    livePeeps.push(peep);
                                }
                                if (contact.name && contact.name.length)
                                    peep.contactName = contact.name;
                                if (contact.photoBlob && contact.photoBlob.length)
                                    peep._thumbnailBlob = contact.photoBlob;
                                if (!self.callbacks.length) {
                                    if (peep.onchange) {
                                        try {
                                            peep.onchange(peep);
                                        } catch (ex) {
                                            reportClientCodeError('peep.onchange error', ex, '\n', ex.stack);
                                        }
                                    }
                                }
                            }
                        } else {
                            ContactCache._contactCache[emailAddress] = null;
                            if (++ContactCache._cacheEmptyEntries > ContactCache.MAX_CACHE_EMPTY)
                                self._resetCache();
                        }
                        if (--self.pendingLookupCount === 0) {
                            for (i = 0; i < ContactCache.callbacks.length; i++) {
                                ContactCache.callbacks[i]();
                            }
                            ContactCache.callbacks.splice(0, ContactCache.callbacks.length);
                        }
                    };
                req.then(cursor => {
                    cursor.next().then(result => {
                        handleResult(result);
                        cursor.release();
                    }).catch(err => {
                        handleResult();
                        cursor.release();
                    });
                }, error => {
                    console.log('find contact error:' + JSON.stringify(error));
                });
            }
            var livePeeps;
            livePeeps = this._livePeepsByEmail[emailAddress];
            if (livePeeps === undefined)
                livePeeps = this._livePeepsByEmail[emailAddress] = [];
            livePeeps.push(peep);
            if (peep.contactId) {
                livePeeps = this._livePeepsById[peep.contactId];
                if (livePeeps === undefined)
                    livePeeps = this._livePeepsById[peep.contactId] = [];
                livePeeps.push(peep);
            }
            return peep;
        },
        forgetPeepInstances: function () {
            var livePeepsById = this._livePeepsById, livePeepsByEmail = this._livePeepsByEmail;
            for (var iArg = 0; iArg < arguments.length; iArg++) {
                var peeps = arguments[iArg];
                if (!peeps)
                    continue;
                for (var iPeep = 0; iPeep < peeps.length; iPeep++) {
                    var peep = peeps[iPeep], livePeeps, idx;
                    if (peep.contactId) {
                        livePeeps = livePeepsById[peep.contactId];
                        if (livePeeps) {
                            idx = livePeeps.indexOf(peep);
                            if (idx !== -1) {
                                livePeeps.splice(idx, 1);
                                if (livePeeps.length === 0)
                                    delete livePeepsById[peep.contactId];
                            }
                        }
                    }
                    livePeeps = livePeepsByEmail[peep.address];
                    if (livePeeps) {
                        idx = livePeeps.indexOf(peep);
                        if (idx !== -1) {
                            livePeeps.splice(idx, 1);
                            if (livePeeps.length === 0)
                                delete livePeepsByEmail[peep.address];
                        }
                    }
                }
            }
        }
    };
    function revokeImageSrc() {
        var useWin = this.ownerDocument.defaultView || window;
        useWin.URL.revokeObjectURL(this.src);
    }
    function showBlobInImg(imgNode, blob) {
        var useWin = imgNode.ownerDocument.defaultView || window;
        imgNode.src = useWin.URL.createObjectURL(blob);
    }
    function MailPeep(name, address, contactId, thumbnailBlob) {
        this.name = name;
        this.address = address;
        this.contactId = contactId;
        this._thumbnailBlob = thumbnailBlob;
        this.element = null;
        this.data = null;
        this.type = null;
        this.onchange = null;
    }
    MailPeep.prototype = {
        get isContact() {
            return this.contactId !== null;
        },
        toString: function () {
            return '[MailPeep: ' + this.address + ']';
        },
        toJSON: function () {
            return {
                name: this.name,
                address: this.address,
                contactId: this.contactId
            };
        },
        toWireRep: function () {
            return {
                name: this.name,
                address: this.address
            };
        },
        get hasPicture() {
            return this._thumbnailBlob !== null;
        },
        displayPictureInImageTag: function (imgNode) {
            if (this._thumbnailBlob)
                showBlobInImg(imgNode, this._thumbnailBlob);
        }
    };
    function MailHeader(slice, wireRep) {
        this._slice = slice;
        this._wireRep = wireRep;
        this.id = wireRep.suid;
        this.guid = wireRep.guid;
        this.author = ContactCache.resolvePeep(wireRep.author);
        this.to = ContactCache.resolvePeeps(wireRep.to);
        this.cc = ContactCache.resolvePeeps(wireRep.cc);
        this.bcc = ContactCache.resolvePeeps(wireRep.bcc);
        this.replyTo = wireRep.replyTo;
        this.date = new Date(wireRep.date);
        this.__update(wireRep);
        this.hasAttachments = wireRep.hasAttachments;
        this.subject = wireRep.subject;
        this.snippet = wireRep.snippet;
        this.onchange = null;
        this.onremove = null;
        this.element = null;
        this.data = null;
    }
    MailHeader.prototype = {
        toString: function () {
            return '[MailHeader: ' + this.id + ']';
        },
        toJSON: function () {
            return {
                type: 'MailHeader',
                id: this.id
            };
        },
        makeCopy: function () {
            return new MailHeader(this._slice, this._wireRep);
        },
        __update: function (wireRep) {
            this._wireRep = wireRep;
            if (wireRep.snippet !== null) {
                this.snippet = wireRep.snippet;
            }
            this.isRead = wireRep.flags.indexOf('\\Seen') !== -1;
            this.isStarred = wireRep.flags.indexOf('\\Flagged') !== -1;
            this.isRepliedTo = wireRep.flags.indexOf('\\Answered') !== -1;
            this.isForwarded = wireRep.flags.indexOf('$Forwarded') !== -1;
            this.isJunk = wireRep.flags.indexOf('$Junk') !== -1;
            this.tags = filterOutBuiltinFlags(wireRep.flags);
            this.sendStatus = wireRep.sendStatus || {};
        },
        __die: function () {
            ContactCache.forgetPeepInstances([this.author], this.to, this.cc, this.bcc);
        },
        deleteMessage: function () {
            return this._slice._api.deleteMessages([this]);
        },
        moveMessage: function (targetFolder) {
            return this._slice._api.moveMessages([this], targetFolder);
        },
        setRead: function (beRead) {
            return this._slice._api.markMessagesRead([this], beRead);
        },
        setStarred: function (beStarred) {
            return this._slice._api.markMessagesStarred([this], beStarred);
        },
        modifyTags: function (addTags, removeTags) {
            return this._slice._api.modifyMessageTags([this], addTags, removeTags);
        },
        getBody: function (options, callback) {
            if (typeof options === 'function') {
                callback = options;
                options = null;
            }
            this._slice._api._getBodyForMessage(this, options, callback);
        },
        get bytesToDownloadForBodyDisplay() {
            return this._wireRep.bytesToDownloadForBodyDisplay || 0;
        },
        editAsDraft: function (callback) {
            var composer = this._slice._api.resumeMessageComposition(this, callback);
            composer.hasDraft = true;
            return composer;
        },
        replyToMessage: function (replyMode, callback) {
            return this._slice._api.beginMessageComposition(this, null, {
                replyTo: this,
                replyMode: replyMode
            }, callback);
        },
        forwardMessage: function (forwardMode, callback) {
            return this._slice._api.beginMessageComposition(this, null, {
                forwardOf: this,
                forwardMode: forwardMode
            }, callback);
        }
    };
    function MailMatchedHeader(slice, wireRep) {
        this.header = new MailHeader(slice, wireRep.header);
        this.matches = wireRep.matches;
        this.element = null;
        this.data = null;
    }
    MailMatchedHeader.prototype = {
        toString: function () {
            return '[MailMatchedHeader: ' + this.header.id + ']';
        },
        toJSON: function () {
            return {
                type: 'MailMatchedHeader',
                id: this.header.id
            };
        },
        __update: function (wireRep) {
            this.matches = wireRep.matches;
            this.header.__update(wireRep.header);
        },
        __die: function () {
            this.header.__die();
        }
    };
    function MailBody(api, suid, wireRep, handle) {
        this._api = api;
        this.id = suid;
        this._date = wireRep.date;
        this._handle = handle;
        this.attachments = null;
        if (wireRep.attachments) {
            this.attachments = [];
            for (var iAtt = 0; iAtt < wireRep.attachments.length; iAtt++) {
                this.attachments.push(new MailAttachment(this, wireRep.attachments[iAtt]));
            }
        }
        this._relatedParts = wireRep.relatedParts;
        this.bodyReps = wireRep.bodyReps;
        this._references = wireRep.references;
        this.onchange = null;
        this.ondead = null;
    }
    MailBody.prototype = {
        toString: function () {
            return '[MailBody: ' + this.id + ']';
        },
        toJSON: function () {
            return {
                type: 'MailBody',
                id: this.id
            };
        },
        __update: function (wireRep, detail) {
            this._relatedParts = wireRep.relatedParts;
            this.bodyReps = wireRep.bodyReps;
            if (detail && detail.changeDetails && detail.changeDetails.detachedAttachments) {
                var indices = detail.changeDetails.detachedAttachments;
                for (var iSplice = 0; iSplice < indices.length; iSplice++) {
                    this.attachments.splice(indices[iSplice], 1);
                }
            }
            if (wireRep.attachments) {
                var i, attachment;
                for (i = 0; i < this.attachments.length; i++) {
                    attachment = this.attachments[i];
                    attachment.__update(wireRep.attachments[i]);
                }
                for (i = this.attachments.length; i < wireRep.attachments.length; i++) {
                    this.attachments.push(new MailAttachment(this, wireRep.attachments[i]));
                }
            }
        },
        get embeddedImageCount() {
            if (!this._relatedParts)
                return 0;
            return this._relatedParts.length;
        },
        get allEmbeddedImagesSize() {
            var imagesSize = 0;
            var imagesCount = this._relatedParts.length;
            for (var i = 0; i < imagesCount; i++) {
                imagesSize += this._relatedParts[i].sizeEstimate;
            }
            console.log('allEmbeddedImagesSize: all the embedded image count is ', imagesCount);
            console.log('allEmbeddedImagesSize: all the embedded image size is ', imagesSize);
            return imagesSize;
        },
        get bodyRepsDownloaded() {
            var i = 0;
            var len = this.bodyReps.length;
            for (; i < len; i++) {
                if (!this.bodyReps[i].isDownloaded) {
                    return false;
                }
            }
            return true;
        },
        get embeddedImagesDownloaded() {
            for (var i = 0; i < this._relatedParts.length; i++) {
                var relatedPart = this._relatedParts[i];
                if (!relatedPart.file)
                    return false;
            }
            return true;
        },
        downloadEmbeddedImages: function (callWhenDone, callOnProgress) {
            var relPartIndices = [];
            for (var i = 0; i < this._relatedParts.length; i++) {
                var relatedPart = this._relatedParts[i];
                if (relatedPart.file)
                    continue;
                relPartIndices.push(i);
            }
            if (!relPartIndices.length) {
                if (callWhenDone)
                    callWhenDone();
                return;
            }
            this._api._downloadAttachments(this, relPartIndices, [], [], callWhenDone, callOnProgress);
        },
        showEmbeddedImages: function (htmlNode, loadCallback) {
            var i, cidToBlob = {};
            for (i = 0; i < this._relatedParts.length; i++) {
                var relPart = this._relatedParts[i];
                if (relPart.file && !Array.isArray(relPart.file))
                    cidToBlob[relPart.contentId] = relPart.file;
            }
            var nodes = htmlNode.querySelectorAll('.moz-embedded-image');
            for (i = 0; i < nodes.length; i++) {
                var node = nodes[i], cid = node.getAttribute('cid-src');
                if (!cidToBlob.hasOwnProperty(cid))
                    continue;
                showBlobInImg(node, cidToBlob[cid]);
                if (loadCallback)
                    node.addEventListener('load', loadCallback, false);
                node.removeAttribute('cid-src');
                node.classList.remove('moz-embedded-image');
            }
        },
        checkForExternalImages: function (htmlNode) {
            var someNode = htmlNode.querySelector('.moz-external-image');
            return someNode !== null;
        },
        showExternalImages: function (htmlNode, loadCallback) {
            var nodes = htmlNode.querySelectorAll('.moz-external-image');
            for (var i = 0; i < nodes.length; i++) {
                var node = nodes[i];
                if (loadCallback) {
                    node.addEventListener('load', loadCallback, false);
                }
                node.setAttribute('src', node.getAttribute('ext-src'));
                node.removeAttribute('ext-src');
                node.classList.remove('moz-external-image');
            }
        },
        die: function () {
            this.onchange = null;
            this._api.__bridgeSend({
                type: 'killBody',
                id: this.id,
                handle: this._handle
            });
        }
    };
    function MailAttachment(_body, wireRep) {
        this._body = _body;
        this.partId = wireRep.part;
        this.filename = wireRep.name;
        this.mimetype = wireRep.type;
        this.sizeEstimateInBytes = wireRep.sizeEstimate;
        this._file = wireRep.file;
        this.element = null;
        this.data = null;
    }
    MailAttachment.prototype = {
        toString: function () {
            return '[MailAttachment: "' + this.filename + '"]';
        },
        toJSON: function () {
            return {
                type: 'MailAttachment',
                filename: this.filename
            };
        },
        __update: function (wireRep) {
            this.mimetype = wireRep.type;
            this.sizeEstimateInBytes = wireRep.sizeEstimate;
            this._file = wireRep.file;
        },
        get isDownloaded() {
            return !!this._file;
        },
        get isDownloadable() {
            return this.mimetype !== 'application/x-gelam-no-download';
        },
        resetDownloadState: function () {
            this._file = null;
        },
        download: function (callWhenDone, callOnProgress, registerWithDownloadManager) {
            if (this.isDownloaded) {
                callWhenDone();
                return;
            }
            this._body._api._downloadAttachments(this._body, [], [this._body.attachments.indexOf(this)], [registerWithDownloadManager || false], callWhenDone, callOnProgress);
        }
    };
    function UndoableOperation(_api, operation, affectedCount, _tempHandle, _longtermIds) {
        this._api = _api;
        this.operation = operation;
        this.affectedCount = affectedCount;
        this._tempHandle = _tempHandle;
        this._longtermIds = null;
        this._undoRequested = false;
    }
    UndoableOperation.prototype = {
        toString: function () {
            return '[UndoableOperation]';
        },
        toJSON: function () {
            return {
                type: 'UndoableOperation',
                handle: this._tempHandle,
                longtermIds: this._longtermIds
            };
        },
        undo: function () {
            if (!this._longtermIds) {
                this._undoRequested = true;
                return;
            }
            this._api.__undo(this);
        }
    };
    function BridgedViewSlice(api, ns, handle) {
        this._api = api;
        this._ns = ns;
        this._handle = handle;
        this.items = [];
        this.status = 'new';
        this.syncProgress = 0;
        this.atTop = false;
        this.atBottom = false;
        this.userCanGrowUpwards = false;
        this.userCanGrowDownwards = false;
        this.pendingRequestCount = 0;
        this._growing = 0;
        this.onadd = null;
        this.onchange = null;
        this.onsplice = null;
        this.onremove = null;
        this.onstatus = null;
        this.oncomplete = null;
        this.ondead = null;
    }
    BridgedViewSlice.prototype = {
        toString: function () {
            return '[BridgedViewSlice: ' + this._ns + ' ' + this._handle + ']';
        },
        toJSON: function () {
            return {
                type: 'BridgedViewSlice',
                namespace: this._ns,
                handle: this._handle
            };
        },
        requestShrinkage: function (firstUsedIndex, lastUsedIndex) {
            this.pendingRequestCount++;
            if (lastUsedIndex >= this.items.length)
                lastUsedIndex = this.items.length - 1;
            this._api.__bridgeSend({
                type: 'shrinkSlice',
                handle: this._handle,
                firstIndex: firstUsedIndex,
                firstSuid: this.items[firstUsedIndex].id,
                lastIndex: lastUsedIndex,
                lastSuid: this.items[lastUsedIndex].id
            });
        },
        requestGrowth: function (dirMagnitude, userRequestsGrowth) {
            if (this._growing) {
                reportError('Already growing in ' + this._growing + ' dir.');
                return;
            }
            this._growing = dirMagnitude;
            this.pendingRequestCount++;
            this._api.__bridgeSend({
                type: 'growSlice',
                dirMagnitude: dirMagnitude,
                userRequestsGrowth: userRequestsGrowth,
                handle: this._handle
            });
        },
        die: function () {
            this.onadd = null;
            this.onchange = null;
            this.onsplice = null;
            this.onremove = null;
            this.onstatus = null;
            this.oncomplete = null;
            this._api.__bridgeSend({
                type: 'killSlice',
                handle: this._handle
            });
            for (var i = 0; i < this.items.length; i++) {
                var item = this.items[i];
                item.__die();
            }
        }
    };
    function AccountsViewSlice(api, handle) {
        BridgedViewSlice.call(this, api, 'accounts', handle);
    }
    AccountsViewSlice.prototype = Object.create(BridgedViewSlice.prototype);
    AccountsViewSlice.prototype.getAccountById = function (id) {
        for (var i = 0; i < this.items.length; i++) {
            if (this.items[i]._wireRep.id === id) {
                return this.items[i];
            }
        }
        return null;
    };
    Object.defineProperty(AccountsViewSlice.prototype, 'defaultAccount', {
        get: function () {
            var defaultAccount = this.items[0];
            for (var i = 1; i < this.items.length; i++) {
                if ((this.items[i]._wireRep.defaultPriority || 0) > (defaultAccount._wireRep.defaultPriority || 0))
                    defaultAccount = this.items[i];
            }
            return defaultAccount;
        }
    });
    function FoldersViewSlice(api, handle) {
        BridgedViewSlice.call(this, api, 'folders', handle);
    }
    FoldersViewSlice.prototype = Object.create(BridgedViewSlice.prototype);
    FoldersViewSlice.prototype.syncList = function (accountId) {
        this._api.__bridgeSend({
            type: 'foldersListRefresh',
            accountId: accountId,
            handle: this._handle
        });
    };
    FoldersViewSlice.prototype.getFirstFolderWithType = function (type, items) {
        if (!items)
            items = this.items;
        for (var i = 0; i < items.length; i++) {
            var folder = items[i];
            if (folder.type === type)
                return folder;
        }
        return null;
    };
    FoldersViewSlice.prototype.getFirstFolderWithName = function (name, items) {
        if (!items)
            items = this.items;
        for (var i = 0; i < items.length; i++) {
            var folder = items[i];
            if (folder.name === name)
                return folder;
        }
        return null;
    };
    FoldersViewSlice.prototype.getFirstFolderWithPath = function (path, items) {
        if (!items)
            items = this.items;
        for (var i = 0; i < items.length; i++) {
            var folder = items[i];
            if (folder.path === path)
                return folder;
        }
        return null;
    };
    function HeadersViewSlice(api, handle, ns) {
        BridgedViewSlice.call(this, api, ns || 'headers', handle);
        this._bodiesRequestId = 1;
        this._bodiesRequest = {};
    }
    HeadersViewSlice.prototype = Object.create(BridgedViewSlice.prototype);
    HeadersViewSlice.prototype.refresh = function () {
        this._api.__bridgeSend({
            type: 'refreshHeaders',
            handle: this._handle
        });
    };
    HeadersViewSlice.prototype._notifyRequestBodiesComplete = function (reqId) {
        var callback = this._bodiesRequest[reqId];
        if (reqId && callback) {
            callback(true);
            delete this._bodiesRequest[reqId];
        }
    };
    HeadersViewSlice.prototype.maybeRequestBodies = function (idxStart, idxEnd, options, callback) {
        if (typeof options === 'function') {
            callback = options;
            options = null;
        }
        var messages = [];
        idxEnd = Math.min(idxEnd, this.items.length - 1);
        for (; idxStart <= idxEnd; idxStart++) {
            var item = this.items[idxStart];
            if (this._ns === 'matchedHeaders') {
                item = item.header;
            }
            if (item && item.snippet === null) {
                messages.push({
                    suid: item.id,
                    date: item.date.valueOf()
                });
            }
        }
        if (!messages.length)
            return callback && window.setZeroTimeout(callback, false);
        var reqId = this._bodiesRequestId++;
        this._bodiesRequest[reqId] = callback;
        this._api.__bridgeSend({
            type: 'requestBodies',
            handle: this._handle,
            requestId: reqId,
            messages: messages,
            options: options
        });
    };
    HeadersViewSlice.prototype.indexOfItemById = function (id) {
        var result = -1;
        for (var i = 0; i < this.items.length; i++) {
            if (this.items[i].id === id) {
                result = i;
                break;
            }
        }
        return result;
    };
    function MessageComposition(api, handle) {
        this._api = api;
        this._handle = handle;
        this.senderIdentity = null;
        this.to = null;
        this.cc = null;
        this.bcc = null;
        this.subject = null;
        this.body = null;
        this._references = null;
        this.attachments = null;
        this.hasDraft = false;
        this.sendType = null;
    }
    MessageComposition.prototype = {
        toString: function () {
            return '[MessageComposition: ' + this._handle + ']';
        },
        toJSON: function () {
            return {
                type: 'MessageComposition',
                handle: this._handle
            };
        },
        die: function () {
            if (this._handle) {
                this._api._composeDone(this._handle, 'die', null, null);
                this._handle = null;
            }
        },
        addAttachment: function (attachmentDef, callback) {
            if (!this.hasDraft)
                this.saveDraft();
            this._api._composeAttach(this._handle, attachmentDef, callback);
            var placeholderAttachment = {
                name: attachmentDef.name,
                pathName: attachmentDef.pathName,
                blob: attachmentDef.blob
            };
            this.attachments.push(placeholderAttachment);
            return placeholderAttachment;
        },
        removeAttachment: function (attachmentDef, callback) {
            var idx = this.attachments.indexOf(attachmentDef);
            if (idx !== -1) {
                this.attachments.splice(idx, 1);
                this._api._composeDetach(this._handle, idx, callback);
            }
        },
        replaceAttachment: function (attachmentDef, targetAttchmentDef, callback) {
            var idx = this.attachments.indexOf(attachmentDef);
            if (idx !== -1) {
                this.attachments.splice(idx, 1);
                this._api._composeDetach(this._handle, idx, callback);
                if (!this.hasDraft) {
                    this.saveDraft();
                }
                this._api._composeAttach(this._handle, targetAttchmentDef, callback);
                var placeholderAttachment = {
                    name: targetAttchmentDef.name,
                    pathName: targetAttchmentDef.pathName,
                    blob: targetAttchmentDef.blob
                };
                this.attachments.splice(idx, 0, placeholderAttachment);
            }
        },
        _buildWireRep: function () {
            return {
                senderId: this.senderIdentity.id,
                to: this.to,
                cc: this.cc,
                bcc: this.bcc,
                subject: this.subject,
                body: this.body,
                referencesStr: this._references,
                attachments: this.attachments,
                sendType: this.sendType
            };
        },
        finishCompositionSendMessage: function (callback) {
            this._api._composeDone(this._handle, 'send', this._buildWireRep(), callback);
        },
        saveDraft: function (callback) {
            this.hasDraft = true;
            this._api._composeDone(this._handle, 'save', this._buildWireRep(), callback);
        },
        abortCompositionDeleteDraft: function (callback) {
            this._api._composeDone(this._handle, 'delete', null, callback);
        }
    };
    var LEGAL_CONFIG_KEYS = [];
    var RE_URL = /(^|[\s(,;])((?:https?:\/\/|www\d{0,3}[.][a-z0-9.\-]{2,249}|[a-z0-9.\-]{2,250}[.][a-z]{2,4}\/)[-\w.!~*'();,/?:@&=+$#%]*)/im;
    var RE_UNEAT_LAST_URL_CHARS = /(?:[),;.!?]|[.!?]\)|\)[.!?])$/;
    var RE_HTTP = /^https?:/i;
    var RE_MAIL = /(^|[\s(,;，"<>])([^(,;，"<>@\s]+@[a-z0-9.\-]{2,250}[.][a-z0-9\-]{2,32})/im;
    var RE_MAILTO = /^mailto:/i;
    var RE_PHONE = /(?:\+\d{1,4}[ \t.()-]{0,3}|\()?(?:\d{1,4}[ \t.()-]{0,3})?(?:\d[\d \t.()-]{0,12}\d)\b/i;
    var safeStart = /[\s,:;\(>\u0080-\uFFFF]/;
    const MINIMUM_DIGITS_IN_PHONE_NUMBER = 5;
    var RE_DATE = /((^((1[8-9]\d{2})|([2-9]\d{3}))([-\/\._])(10|12|0?[13578])([-\/\._])(3[01]|[12][0-9]|0?[1-9])$)|(^((1[8-9]\d{2})|([2-9]\d{3}))([-\/\._])(11|0?[469])([-\/\._])(30|[12][0-9]|0?[1-9])$)|(^((1[8-9]\d{2})|([2-9]\d{3}))([-\/\._])(0?2)([-\/\._])(2[0-8]|1[0-9]|0?[1-9])$)|(^([2468][048]00)([-\/\._])(0?2)([-\/\._])(29)$)|(^([3579][26]00)([-\/\._])(0?2)([-\/\._])(29)$)|(^([1][89][0][48])([-\/\._])(0?2)([-\/\._])(29)$)|(^([2-9][0-9][0][48])([-\/\._])(0?2)([-\/\._])(29)$)|(^([1][89][2468][048])([-\/\._])(0?2)([-\/\._])(29)$)|(^([2-9][0-9][2468][048])([-\/\._])(0?2)([-\/\._])(29)$)|(^([1][89][13579][26])([-\/\._])(0?2)([-\/\._])(29)$)|(^([2-9][0-9][13579][26])([-\/\._])(0?2)([-\/\._])(29)$))/i;
    var RE_IP = /((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)/i;
    var MailUtils = {
        linkifyPlain: function (body, doc) {
            var nodes = [];
            var match = true, contentStart;
            while (true) {
                var url = RE_URL.exec(body);
                var email = RE_MAIL.exec(body);
                var phone = RE_PHONE.exec(body);
                if (url && (!email || url.index < email.index) && (!phone || url.index < phone.index)) {
                    contentStart = url.index + url[1].length;
                    if (contentStart > 0)
                        nodes.push(doc.createTextNode(body.substring(0, contentStart)));
                    var useUrl = url[2];
                    var uneat = RE_UNEAT_LAST_URL_CHARS.exec(useUrl);
                    if (uneat) {
                        useUrl = useUrl.substring(0, uneat.index);
                    }
                    var link = doc.createElement('a');
                    link.className = 'moz-external-link';
                    if (RE_HTTP.test(url[2]))
                        link.setAttribute('ext-href', useUrl);
                    else
                        link.setAttribute('ext-href', 'http://' + useUrl);
                    var text = doc.createTextNode(useUrl);
                    link.appendChild(text);
                    nodes.push(link);
                    body = body.substring(url.index + url[1].length + useUrl.length);
                } else if (email && (!phone || email.index < phone.index)) {
                    contentStart = email.index + email[1].length;
                    if (contentStart > 0)
                        nodes.push(doc.createTextNode(body.substring(0, contentStart)));
                    link = doc.createElement('a');
                    link.className = 'moz-external-link';
                    if (RE_MAILTO.test(email[2]))
                        link.setAttribute('ext-href', email[2]);
                    else
                        link.setAttribute('ext-href', 'mailto:' + email[2]);
                    text = doc.createTextNode(email[2]);
                    link.appendChild(text);
                    nodes.push(link);
                    body = body.substring(email.index + email[0].length);
                } else if (phone) {
                    contentStart = phone.index;
                    var createTextNode = text => {
                        if (text) {
                            var pos = contentStart + text.length;
                            var nodeText = body.substring(0, pos);
                            nodes.push(doc.createTextNode(nodeText));
                            body = body.substring(pos);
                        }
                    };
                    if (phone[0].length > MINIMUM_DIGITS_IN_PHONE_NUMBER) {
                        let bDateOrIp = false;
                        let bDecimal = false;
                        let num = phone[0].split(' ');
                        for (let i in num) {
                            if (RE_DATE.test(num[i]) || RE_IP.test(num[i])) {
                                bDateOrIp = true;
                                break;
                            }
                        }
                        if (!bDateOrIp) {
                            num = phone[0].split('.');
                            if (num.length > 1) {
                                for (let i in num) {
                                    if (num[i].length > 3) {
                                        bDecimal = false;
                                        break;
                                    } else if (i === num.length - 1) {
                                        bDecimal = true;
                                    }
                                }
                            }
                        }
                        if (RE_DATE.test(phone[0]) || RE_IP.test(phone[0]) || bDateOrIp || bDecimal) {
                            createTextNode(phone[0]);
                            continue;
                        }
                        var rest = body.slice(contentStart + phone[0].length);
                        if (rest.length && !safeStart.test(rest.charAt(0)) || contentStart > 0 && !safeStart.test(body.charAt(contentStart - 1))) {
                            createTextNode(phone[0]);
                            continue;
                        }
                        if (contentStart > 0) {
                            nodes.push(doc.createTextNode(body.substring(0, contentStart)));
                        }
                        link = doc.createElement('a');
                        link.className = 'moz-external-link';
                        link.setAttribute('ext-href', 'callto:' + phone[0]);
                        text = doc.createTextNode(phone[0]);
                        link.appendChild(text);
                        nodes.push(link);
                        body = body.substring(phone.index + phone[0].length);
                    } else {
                        createTextNode(phone[0]);
                    }
                } else {
                    break;
                }
            }
            if (body.length > 0)
                nodes.push(doc.createTextNode(body));
            return nodes;
        },
        linkifyHTML: function (doc) {
            function linkElem(elem) {
                var children = elem.childNodes;
                for (var i = 0; i < children.length; i++) {
                    var sub = children[i];
                    if (sub.nodeName === '#text') {
                        var nodes = MailUtils.linkifyPlain(sub.nodeValue, doc);
                        elem.replaceChild(nodes[nodes.length - 1], sub);
                        for (var iNode = nodes.length - 2; iNode >= 0; --iNode) {
                            elem.insertBefore(nodes[iNode], nodes[iNode + 1]);
                        }
                    } else if (sub.nodeName !== 'A' || sub.nodeName === 'A' && !sub.attributes['ext-href']) {
                        linkElem(sub);
                    }
                }
            }
            linkElem(doc.body);
        }
    };
    function MailAPI() {
        this._nextHandle = 1;
        this._slices = {};
        this._pendingRequests = {};
        this._liveBodies = {};
        this._spliceFireFuncs = [];
        this._storedSends = [];
        this._processingMessage = null;
        this._deferredMessages = [];
        this.config = {};
        this.onbadlogin = null;
        this.onResetAccount = null;
        ContactCache.init();
    }
    exports.MailAPI = MailAPI;
    MailAPI.prototype = {
        toString: function () {
            return '[MailAPI]';
        },
        toJSON: function () {
            return { type: 'MailAPI' };
        },
        utils: MailUtils,
        __bridgeSend: function (msg) {
            this._storedSends.push(msg);
        },
        __bridgeReceive: function ma___bridgeReceive(msg) {
            if (this._processingMessage && msg.type !== 'pong') {
                this._deferredMessages.push(msg);
            } else {
                this._processMessage(msg);
            }
        },
        _processMessage: function ma__processMessage(msg) {
            var methodName = '_recv_' + msg.type;
            if (!(methodName in this)) {
                unexpectedBridgeDataError('Unsupported message type:', msg.type);
                return;
            }
            try {
                var done = this[methodName](msg);
                if (!done) {
                    this._processingMessage = msg;
                }
            } catch (ex) {
                internalError('Problem handling message type:', msg.type, ex, '\n', ex.stack);
                return;
            }
        },
        _doneProcessingMessage: function (msg) {
            if (this._processingMessage && this._processingMessage !== msg)
                throw new Error('Mismatched message completion!');
            this._processingMessage = null;
            while (this._processingMessage === null && this._deferredMessages.length) {
                this._processMessage(this._deferredMessages.shift());
            }
        },
        _recv_badLogin: function ma__recv_badLogin(msg) {
            if (this.onbadlogin)
                this.onbadlogin(new MailAccount(this, msg.account, null), msg.problem, msg.whichSide);
            return true;
        },
        _recv_accountReset: function (msg) {
            if (this.onResetAccount) {
                this.onResetAccount(new MailAccount(this, msg.account, null));
            }
            return true;
        },
        _fireAllSplices: function () {
            for (var i = 0; i < this._spliceFireFuncs.length; i++) {
                var fireSpliceData = this._spliceFireFuncs[i];
                fireSpliceData();
            }
            this._spliceFireFuncs.length = 0;
        },
        _recv_batchSlice: function receiveBatchSlice(msg) {
            var slice = this._slices[msg.handle];
            if (!slice) {
                unexpectedBridgeDataError('Received message about nonexistent slice:', msg.handle);
                return true;
            }
            var updateStatus = this._updateSliceStatus(msg, slice);
            for (var i = 0; i < msg.sliceUpdates.length; i++) {
                var update = msg.sliceUpdates[i];
                if (update.type === 'update') {
                    this._spliceFireFuncs.push(this._processSliceUpdate.bind(this, msg, update.updates, slice));
                } else {
                    this._transformAndEnqueueSingleSplice(msg, update, slice);
                }
            }
            if (ContactCache.pendingLookupCount) {
                ContactCache.callbacks.push(function contactsResolved() {
                    this._fireAllSplices();
                    this._fireStatusNotifications(updateStatus, slice);
                    this._doneProcessingMessage(msg);
                }.bind(this));
                return false;
            }
            this._fireAllSplices();
            this._fireStatusNotifications(updateStatus, slice);
            return true;
        },
        _fireStatusNotifications: function (updateStatus, slice) {
            if (updateStatus && slice.onstatus) {
                slice.onstatus(slice.status);
            }
        },
        _updateSliceStatus: function (msg, slice) {
            slice.atTop = msg.atTop;
            slice.atBottom = msg.atBottom;
            slice.userCanGrowUpwards = msg.userCanGrowUpwards;
            slice.userCanGrowDownwards = msg.userCanGrowDownwards;
            var generatedStatusChange = msg.status && (slice.status !== msg.status || slice.syncProgress !== msg.progress);
            if (msg.status) {
                slice.status = msg.status;
                slice.syncProgress = msg.syncProgress;
            }
            return generatedStatusChange;
        },
        _processSliceUpdate: function (msg, splice, slice) {
            try {
                for (var i = 0; i < splice.length; i += 2) {
                    var idx = splice[i], wireRep = splice[i + 1];
                    var itemObj = slice.items[idx];
                    if (wireRep.suid !== itemObj.id) {
                        if (slice.indexOfItemById) {
                            var index = slice.indexOfItemById(wireRep.suid);
                            idx = index !== -1 ? index : idx;
                        }
                        itemObj = slice.items[idx];
                    }
                    itemObj.__update(wireRep);
                    if (slice.onchange) {
                        slice.onchange(itemObj, idx);
                    }
                    if (itemObj.onchange) {
                        itemObj.onchange(itemObj, idx);
                    }
                }
            } catch (ex) {
                reportClientCodeError('onchange notification error', ex, '\n', ex.stack);
            }
        },
        _transformAndEnqueueSingleSplice: function (msg, splice, slice) {
            var transformedItems = this._transform_sliceSplice(splice, slice);
            var fake = false;
            this._spliceFireFuncs.push(function singleSpliceUpdate() {
                this._fireSplice(splice, slice, transformedItems, fake);
            }.bind(this));
        },
        _fireSplice: function (splice, slice, transformedItems, fake) {
            var i, stopIndex, items, tempMsg;
            if (splice.headerCount !== undefined) {
                slice.headerCount = splice.headerCount;
            }
            if (slice.onsplice) {
                try {
                    slice.onsplice(splice.index, splice.howMany, transformedItems, splice.requested, splice.moreExpected, fake);
                } catch (ex) {
                    reportClientCodeError('onsplice notification error', ex, '\n', ex.stack);
                }
            }
            if (splice.howMany) {
                try {
                    slice.items.sort((a, b) => {
                        return b.date - a.date;
                    });
                    stopIndex = splice.index + splice.howMany;
                    for (i = splice.index; i < stopIndex; i++) {
                        var item = slice.items[i];
                        if (slice.onremove)
                            slice.onremove(item, i);
                        if (item.onremove)
                            item.onremove(item, i);
                        item.__die();
                    }
                } catch (ex) {
                    reportClientCodeError('onremove notification error', ex, '\n', ex.stack);
                }
            }
            slice.items.splice.apply(slice.items, [
                splice.index,
                splice.howMany
            ].concat(transformedItems));
            if (slice.onadd) {
                try {
                    stopIndex = splice.index + transformedItems.length;
                    for (i = splice.index; i < stopIndex; i++) {
                        slice.onadd(slice.items[i], i);
                    }
                } catch (ex) {
                    reportClientCodeError('onadd notification error', ex, '\n', ex.stack);
                }
            }
            if (splice.requested && !splice.moreExpected) {
                slice._growing = 0;
                if (slice.pendingRequestCount)
                    slice.pendingRequestCount--;
                if (slice.oncomplete) {
                    var completeFunc = slice.oncomplete;
                    slice.oncomplete = null;
                    try {
                        completeFunc(splice.newEmailCount);
                    } catch (ex) {
                        reportClientCodeError('oncomplete notification error', ex, '\n', ex.stack);
                    }
                }
            }
        },
        _transform_sliceSplice: function ma__transform_sliceSplice(splice, slice) {
            var addItems = splice.addItems, transformedItems = [], i;
            switch (slice._ns) {
            case 'accounts':
                for (i = 0; i < addItems.length; i++) {
                    transformedItems.push(new MailAccount(this, addItems[i], slice));
                }
                break;
            case 'identities':
                for (i = 0; i < addItems.length; i++) {
                    transformedItems.push(new MailSenderIdentity(this, addItems[i]));
                }
                break;
            case 'folders':
                for (i = 0; i < addItems.length; i++) {
                    transformedItems.push(new MailFolder(this, addItems[i]));
                }
                break;
            case 'headers':
                for (i = 0; i < addItems.length; i++) {
                    transformedItems.push(new MailHeader(slice, addItems[i]));
                }
                break;
            case 'matchedHeaders':
                for (i = 0; i < addItems.length; i++) {
                    transformedItems.push(new MailMatchedHeader(slice, addItems[i]));
                }
                break;
            default:
                console.error('Slice notification for unknown type:', slice._ns);
                break;
            }
            return transformedItems;
        },
        _recv_sliceDead: function (msg) {
            var slice = this._slices[msg.handle];
            delete this._slices[msg.handle];
            if (slice.ondead)
                slice.ondead(slice);
            slice.ondead = null;
            return true;
        },
        _getBodyForMessage: function (header, options, callback) {
            var downloadBodyReps = false, withBodyReps = false;
            if (options && options.downloadBodyReps) {
                downloadBodyReps = options.downloadBodyReps;
            }
            if (options && options.withBodyReps) {
                withBodyReps = options.withBodyReps;
            }
            var handle = this._nextHandle++;
            this._pendingRequests[handle] = {
                type: 'getBody',
                suid: header.id,
                callback: callback
            };
            this.__bridgeSend({
                type: 'getBody',
                handle: handle,
                suid: header.id,
                date: header.date.valueOf(),
                downloadBodyReps: downloadBodyReps,
                withBodyReps: withBodyReps
            });
        },
        _recv_gotBody: function (msg) {
            var req = this._pendingRequests[msg.handle];
            if (!req) {
                unexpectedBridgeDataError('Bad handle for got body:', msg.handle);
                return true;
            }
            delete this._pendingRequests[msg.handle];
            var body = msg.bodyInfo ? new MailBody(this, req.suid, msg.bodyInfo, msg.handle) : null;
            if (body) {
                this._liveBodies[msg.handle] = body;
            }
            req.callback.call(null, body, req.suid);
            return true;
        },
        _recv_requestBodiesComplete: function (msg) {
            var slice = this._slices[msg.handle];
            if (slice)
                slice._notifyRequestBodiesComplete(msg.requestId);
            return true;
        },
        _recv_bodyModified: function (msg) {
            var body = this._liveBodies[msg.handle];
            if (!body) {
                unexpectedBridgeDataError('body modified for dead handle', msg.handle);
                return true;
            }
            var wireRep = msg.bodyInfo;
            body.__update(wireRep, msg.detail);
            if (body.onchange) {
                body.onchange(msg.detail, body);
            }
            return true;
        },
        _recv_bodyDead: function (msg) {
            var body = this._liveBodies[msg.handle];
            if (body && body.ondead) {
                body.ondead();
            }
            delete this._liveBodies[msg.handle];
            return true;
        },
        _downloadAttachments: function (body, relPartIndices, attachmentIndices, registerAttachments, callWhenDone, callOnProgress) {
            var handle = this._nextHandle++;
            this._pendingRequests[handle] = {
                type: 'downloadAttachments',
                body: body,
                relParts: relPartIndices.length > 0,
                attachments: attachmentIndices.length > 0,
                callback: callWhenDone,
                progress: callOnProgress
            };
            this.__bridgeSend({
                type: 'downloadAttachments',
                handle: handle,
                suid: body.id,
                date: body._date,
                relPartIndices: relPartIndices,
                attachmentIndices: attachmentIndices,
                registerAttachments: registerAttachments
            });
        },
        _recv_downloadedAttachments: function (msg) {
            var req = this._pendingRequests[msg.handle];
            if (!req) {
                unexpectedBridgeDataError('Bad handle for got body:', msg.handle);
                return true;
            }
            delete this._pendingRequests[msg.handle];
            if (req.callback)
                req.callback.call(null, req.body);
            return true;
        },
        learnAboutAccount: function (details, callback) {
            var handle = this._nextHandle++;
            this._pendingRequests[handle] = {
                type: 'learnAboutAccount',
                details: details,
                callback: callback
            };
            this.__bridgeSend({
                type: 'learnAboutAccount',
                handle: handle,
                details: details
            });
        },
        _recv_learnAboutAccountResults: function (msg) {
            var req = this._pendingRequests[msg.handle];
            if (!req) {
                unexpectedBridgeDataError('Bad handle:', msg.handle);
                return true;
            }
            delete this._pendingRequests[msg.handle];
            req.callback.call(null, msg.data);
            return true;
        },
        checkAndUpdateAccount: function (emailData, callback) {
            let handle = this._nextHandle++;
            this._pendingRequests[handle] = {
                type: 'checkAndUpdateAccount',
                data: emailData,
                callback: callback
            };
            this.__bridgeSend({
                type: 'checkAndUpdateAccount',
                handle: handle,
                data: emailData
            });
        },
        _recv_checkAndUpdateAccountResult: function (msg) {
            let req = this._pendingRequests[msg.handle];
            if (!req) {
                unexpectedBridgeDataError('Bad handle:', msg.handle);
                return true;
            }
            delete this._pendingRequests[msg.handle];
            req.callback.call(null, msg.data);
            return true;
        },
        removeDeletedAccounts: function (emailIds, bRemove, callback) {
            let handle = this._nextHandle++;
            if (bRemove === undefined) {
                bRemove = false;
            }
            this._pendingRequests[handle] = {
                type: 'removeDeletedAccounts',
                emailIds: emailIds,
                remove: bRemove,
                callback: callback
            };
            this.__bridgeSend({
                type: 'removeDeletedAccounts',
                handle: handle,
                emailIds: emailIds,
                remove: bRemove
            });
        },
        _recv_removeDeletedAccountsResult: function (msg) {
            let req = this._pendingRequests[msg.handle];
            if (!req) {
                unexpectedBridgeDataError('Bad handle:', msg.handle);
                return true;
            }
            delete this._pendingRequests[msg.handle];
            req.callback.call(null, msg.data);
            return true;
        },
        tryToCreateAccount: function ma_tryToCreateAccount(details, domainInfo, callback) {
            var handle = this._nextHandle++;
            this._pendingRequests[handle] = {
                type: 'tryToCreateAccount',
                details: details,
                domainInfo: domainInfo,
                callback: callback
            };
            this.__bridgeSend({
                type: 'tryToCreateAccount',
                handle: handle,
                details: details,
                domainInfo: domainInfo
            });
        },
        _recv_tryToCreateAccountResults: function ma__recv_tryToCreateAccountResults(msg) {
            var req = this._pendingRequests[msg.handle];
            if (!req) {
                unexpectedBridgeDataError('Bad handle for create account:', msg.handle);
                return true;
            }
            delete this._pendingRequests[msg.handle];
            var account;
            if (msg.account) {
                account = new MailAccount(this, msg.account, null);
            }
            req.callback.call(null, msg.error, msg.errorDetails, account);
            return true;
        },
        _cancelCreation: function ma_cancelCreation(emailAddress) {
            var handle = this._nextHandle++;
            this._pendingRequests[handle] = {
                type: 'cancelCreateAccount',
                details: emailAddress
            };
            this.__bridgeSend({
                type: 'cancelCreateAccount',
                details: emailAddress,
                handle: handle
            });
        },
        _clearAccountProblems: function ma__clearAccountProblems(account, forceIgnore, callback) {
            var handle = this._nextHandle++;
            this._pendingRequests[handle] = {
                type: 'clearAccountProblems',
                callback: callback
            };
            this.__bridgeSend({
                type: 'clearAccountProblems',
                accountId: account.id,
                bIgnore: forceIgnore || false,
                handle: handle
            });
        },
        _recv_clearAccountProblems: function ma__recv_clearAccountProblems(msg) {
            var req = this._pendingRequests[msg.handle];
            delete this._pendingRequests[msg.handle];
            req.callback && req.callback();
            return true;
        },
        _modifyAccount: function ma__modifyAccount(account, mods, callback) {
            var handle = this._nextHandle++;
            this._pendingRequests[handle] = {
                type: 'modifyAccount',
                callback: callback
            };
            this.__bridgeSend({
                type: 'modifyAccount',
                accountId: account.id,
                mods: mods,
                handle: handle
            });
        },
        _recv_modifyAccount: function (msg) {
            var req = this._pendingRequests[msg.handle];
            delete this._pendingRequests[msg.handle];
            req.callback && req.callback();
            return true;
        },
        _deleteAccount: function ma__deleteAccount(account) {
            this.__bridgeSend({
                type: 'deleteAccount',
                accountId: account.id
            });
        },
        _modifyIdentity: function ma__modifyIdentity(identity, mods, callback) {
            var handle = this._nextHandle++;
            this._pendingRequests[handle] = {
                type: 'modifyIdentity',
                callback: callback
            };
            this.__bridgeSend({
                type: 'modifyIdentity',
                identityId: identity.id,
                mods: mods,
                handle: handle
            });
        },
        _recv_modifyIdentity: function (msg) {
            var req = this._pendingRequests[msg.handle];
            delete this._pendingRequests[msg.handle];
            req.callback && req.callback();
            return true;
        },
        viewAccounts: function ma_viewAccounts(realAccountsOnly) {
            var handle = this._nextHandle++, slice = new AccountsViewSlice(this, handle);
            this._slices[handle] = slice;
            this.__bridgeSend({
                type: 'viewAccounts',
                handle: handle
            });
            return slice;
        },
        viewSenderIdentities: function ma_viewSenderIdentities() {
            var handle = this._nextHandle++, slice = new BridgedViewSlice(this, 'identities', handle);
            this._slices[handle] = slice;
            this.__bridgeSend({
                type: 'viewSenderIdentities',
                handle: handle
            });
            return slice;
        },
        viewFolders: function ma_viewFolders(mode, argument) {
            var handle = this._nextHandle++, slice = new FoldersViewSlice(this, handle);
            this._slices[handle] = slice;
            this.__bridgeSend({
                type: 'viewFolders',
                mode: mode,
                handle: handle,
                argument: argument ? argument.id : null
            });
            return slice;
        },
        viewFolderMessages: function ma_viewFolderMessages(folder) {
            var handle = this._nextHandle++, slice = new HeadersViewSlice(this, handle);
            slice.folderId = folder.id;
            slice.pendingRequestCount++;
            this._slices[handle] = slice;
            this.__bridgeSend({
                type: 'viewFolderMessages',
                folderId: folder.id,
                handle: handle
            });
            return slice;
        },
        sortFolderMessages: function (folder, fillSize) {
            var handle = this._nextHandle++, slice = new HeadersViewSlice(this, handle);
            slice.pendingRequestCount++;
            this._slices[handle] = slice;
            this.__bridgeSend({
                type: 'sortFolderMessages',
                folderId: folder.id,
                handle: handle,
                fillSize: fillSize
            });
            return slice;
        },
        searchFolderMessages: function ma_searchFolderMessages(folder, text, whatToSearch) {
            var handle = this._nextHandle++, slice = new HeadersViewSlice(this, handle, 'matchedHeaders');
            slice.pendingRequestCount++;
            this._slices[handle] = slice;
            this.__bridgeSend({
                type: 'searchFolderMessages',
                folderId: folder.id,
                handle: handle,
                phrase: text,
                whatToSearch: whatToSearch
            });
            return slice;
        },
        deleteMessages: function ma_deleteMessages(messages) {
            var handle = this._nextHandle++;
            var undoableOp = new UndoableOperation(this, 'delete', messages.length, handle), msgSuids = messages.map(serializeMessageName);
            this._pendingRequests[handle] = {
                type: 'mutation',
                handle: handle,
                undoableOp: undoableOp
            };
            this.__bridgeSend({
                type: 'deleteMessages',
                handle: handle,
                messages: msgSuids
            });
            return undoableOp;
        },
        moveMessages: function ma_moveMessages(messages, targetFolder, callback) {
            var handle = this._nextHandle++;
            var undoableOp = new UndoableOperation(this, 'move', messages.length, handle), msgSuids = messages.map(serializeMessageName);
            this._pendingRequests[handle] = {
                type: 'mutation',
                handle: handle,
                undoableOp: undoableOp,
                callback: callback
            };
            this.__bridgeSend({
                type: 'moveMessages',
                handle: handle,
                messages: msgSuids,
                targetFolder: targetFolder.id
            });
            undoableOp.target = targetFolder;
            return undoableOp;
        },
        markMessagesRead: function ma_markMessagesRead(messages, beRead) {
            return this.modifyMessageTags(messages, beRead ? ['\\Seen'] : null, beRead ? null : ['\\Seen'], beRead ? 'read' : 'unread');
        },
        markMessagesStarred: function ma_markMessagesStarred(messages, beStarred) {
            return this.modifyMessageTags(messages, beStarred ? ['\\Flagged'] : null, beStarred ? null : ['\\Flagged'], beStarred ? 'star' : 'unstar');
        },
        markMessagesReply: function ma_markMessagesReply(messages, beReply) {
            return this.modifyMessageTags(messages, beReply ? ['\\Answered'] : null, beReply ? null : ['\\Answered'], null);
        },
        markMessagesForward: function ma_markMessagesForward(messages, beForward) {
            return this.modifyMessageTags(messages, beForward ? ['$Forwarded'] : null, beForward ? null : ['$Forwarded'], null);
        },
        modifyMessageTags: function ma_modifyMessageTags(messages, addTags, removeTags, _opcode) {
            var handle = this._nextHandle++;
            if (!_opcode) {
                if (addTags && addTags.length)
                    _opcode = 'addtag';
                else if (removeTags && removeTags.length)
                    _opcode = 'removetag';
            }
            var undoableOp = new UndoableOperation(this, _opcode, messages.length, handle), msgSuids = messages.map(serializeMessageName);
            this._pendingRequests[handle] = {
                type: 'mutation',
                handle: handle,
                undoableOp: undoableOp
            };
            this.__bridgeSend({
                type: 'modifyMessageTags',
                handle: handle,
                opcode: _opcode,
                addTags: addTags,
                removeTags: removeTags,
                messages: msgSuids
            });
            return undoableOp;
        },
        sendOutboxMessages: function (account, callback) {
            var handle = this._nextHandle++;
            this._pendingRequests[handle] = {
                type: 'sendOutboxMessages',
                callback: callback
            };
            this.__bridgeSend({
                type: 'sendOutboxMessages',
                accountId: account.id,
                handle: handle
            });
        },
        _recv_sendOutboxMessages: function (msg) {
            var req = this._pendingRequests[msg.handle];
            delete this._pendingRequests[msg.handle];
            req.callback && req.callback();
            return true;
        },
        setOutboxSyncEnabled: function (account, enabled, callback) {
            var handle = this._nextHandle++;
            this._pendingRequests[handle] = {
                type: 'setOutboxSyncEnabled',
                callback: callback
            };
            this.__bridgeSend({
                type: 'setOutboxSyncEnabled',
                accountId: account.id,
                outboxSyncEnabled: enabled,
                handle: handle
            });
        },
        _recv_setOutboxSyncEnabled: function (msg) {
            var req = this._pendingRequests[msg.handle];
            delete this._pendingRequests[msg.handle];
            req.callback && req.callback();
            return true;
        },
        parseMailbox: function (email) {
            try {
                var mailbox = addressparser.parse(email);
                return mailbox.length >= 1 ? mailbox[0] : null;
            } catch (ex) {
                reportClientCodeError('parse mailbox error', ex, '\n', ex.stack);
                return null;
            }
        },
        _recv_mutationConfirmed: function (msg) {
            var req = this._pendingRequests[msg.handle];
            if (!req) {
                unexpectedBridgeDataError('Bad handle for mutation:', msg.handle);
                return true;
            }
            req.undoableOp._tempHandle = null;
            req.undoableOp._longtermIds = msg.longtermIds;
            if (req.undoableOp._undoRequested)
                req.undoableOp.undo();
            if (req.callback) {
                req.callback(msg.result);
            }
            delete this._pendingRequests[msg.handle];
            return true;
        },
        __undo: function undo(undoableOp) {
            this.__bridgeSend({
                type: 'undo',
                longtermIds: undoableOp._longtermIds
            });
        },
        resolveEmailAddressToPeep: function (emailAddress, callback) {
            var peep = ContactCache.resolvePeep({
                name: null,
                address: emailAddress
            });
            if (ContactCache.pendingLookupCount)
                ContactCache.callbacks.push(callback.bind(null, peep));
            else
                callback(peep);
        },
        beginMessageComposition: function (message, folder, options, callback) {
            if (!callback)
                throw new Error('A callback must be provided; you are using the API ' + 'wrong if you do not.');
            if (!options)
                options = {};
            var handle = this._nextHandle++, composer = new MessageComposition(this, handle);
            this._pendingRequests[handle] = {
                type: 'compose',
                composer: composer,
                callback: callback
            };
            var msg = {
                type: 'beginCompose',
                handle: handle,
                mode: null,
                submode: null,
                refSuid: null,
                refDate: null,
                refGuid: null,
                refAuthor: null,
                refSubject: null
            };
            if (options.hasOwnProperty('replyTo') && options.replyTo) {
                msg.mode = 'reply';
                msg.submode = options.replyMode;
                msg.refSuid = options.replyTo.id;
                msg.refDate = options.replyTo.date.valueOf();
                msg.refGuid = options.replyTo.guid;
                msg.refAuthor = options.replyTo.author.toWireRep();
                msg.refSubject = options.replyTo.subject;
            } else if (options.hasOwnProperty('forwardOf') && options.forwardOf) {
                msg.mode = 'forward';
                msg.submode = options.forwardMode;
                msg.refSuid = options.forwardOf.id;
                msg.refDate = options.forwardOf.date.valueOf();
                msg.refGuid = options.forwardOf.guid;
                msg.refAuthor = options.forwardOf.author.toWireRep();
                msg.refSubject = options.forwardOf.subject;
            } else {
                msg.mode = 'new';
                if (message) {
                    msg.submode = 'message';
                    msg.refSuid = message.id;
                } else if (folder) {
                    msg.submode = 'folder';
                    msg.refSuid = folder.id;
                }
            }
            this.__bridgeSend(msg);
            return composer;
        },
        resumeMessageComposition: function (message, callback) {
            if (!callback)
                throw new Error('A callback must be provided; you are using the API ' + 'wrong if you do not.');
            var handle = this._nextHandle++, composer = new MessageComposition(this, handle);
            this._pendingRequests[handle] = {
                type: 'compose',
                composer: composer,
                callback: callback
            };
            this.__bridgeSend({
                type: 'resumeCompose',
                handle: handle,
                messageNamer: message.suid ? message : serializeMessageName(message)
            });
            return composer;
        },
        _recv_composeBegun: function (msg) {
            var req = this._pendingRequests[msg.handle];
            if (!req) {
                unexpectedBridgeDataError('Bad handle for compose begun:', msg.handle);
                return true;
            }
            console.warn('msg.sendType is:' + msg.sendType);
            req.composer.senderIdentity = new MailSenderIdentity(this, msg.identity);
            req.composer.subject = msg.subject;
            req.composer.body = msg.body;
            req.composer.to = msg.to;
            req.composer.cc = msg.cc;
            req.composer.bcc = msg.bcc;
            req.composer._references = msg.referencesStr;
            req.composer.attachments = msg.attachments;
            req.composer.sendStatus = msg.sendStatus;
            req.composer.sendType = msg.sendType;
            if (req.callback) {
                var callback = req.callback;
                req.callback = null;
                callback.call(null, req.composer);
            }
            return true;
        },
        _composeAttach: function (draftHandle, attachmentDef, callback) {
            if (!draftHandle) {
                return;
            }
            var draftReq = this._pendingRequests[draftHandle];
            if (!draftReq) {
                return;
            }
            var callbackHandle = this._nextHandle++;
            this._pendingRequests[callbackHandle] = {
                type: 'attachBlobToDraft',
                callback: callback
            };
            this.__bridgeSend({
                type: 'attachBlobToDraft',
                handle: callbackHandle,
                draftHandle: draftHandle,
                attachmentDef: attachmentDef
            });
        },
        _recv_attachedBlobToDraft: function (msg) {
            var callbackReq = this._pendingRequests[msg.handle];
            var draftReq = this._pendingRequests[msg.draftHandle];
            if (!callbackReq) {
                return true;
            }
            delete this._pendingRequests[msg.handle];
            if (callbackReq.callback && draftReq && draftReq.composer) {
                callbackReq.callback(msg.err, draftReq.composer, msg.persistedNamer);
            }
            return true;
        },
        _composeDetach: function (draftHandle, attachmentIndex, callback) {
            if (!draftHandle) {
                return;
            }
            var draftReq = this._pendingRequests[draftHandle];
            if (!draftReq) {
                return;
            }
            var callbackHandle = this._nextHandle++;
            this._pendingRequests[callbackHandle] = {
                type: 'detachAttachmentFromDraft',
                callback: callback
            };
            this.__bridgeSend({
                type: 'detachAttachmentFromDraft',
                handle: callbackHandle,
                draftHandle: draftHandle,
                attachmentIndex: attachmentIndex
            });
        },
        _recv_detachedAttachmentFromDraft: function (msg) {
            var callbackReq = this._pendingRequests[msg.handle];
            var draftReq = this._pendingRequests[msg.draftHandle];
            if (!callbackReq) {
                return true;
            }
            delete this._pendingRequests[msg.handle];
            if (callbackReq.callback && draftReq && draftReq.composer) {
                callbackReq.callback(msg.err, draftReq.composer);
            }
            return true;
        },
        _composeDone: function (handle, command, state, callback) {
            if (!handle)
                return;
            var req = this._pendingRequests[handle];
            if (!req) {
                if (command === 'die') {
                    this.__bridgeSend({
                        type: 'doneCompose',
                        handle: handle,
                        command: command,
                        state: state
                    });
                }
                return;
            }
            req.type = command;
            if (callback)
                req.callback = callback;
            this.__bridgeSend({
                type: 'doneCompose',
                handle: handle,
                command: command,
                state: state
            });
        },
        _recv_doneCompose: function (msg) {
            var req = this._pendingRequests[msg.handle];
            if (!req) {
                unexpectedBridgeDataError('Bad handle for doneCompose:', msg.handle);
                return true;
            }
            req.active = null;
            if (req.type === 'die' || !msg.err && req.type !== 'save')
                delete this._pendingRequests[msg.handle];
            if (req.callback) {
                req.callback.call(null, {
                    sentDate: msg.sentDate,
                    messageId: msg.messageId,
                    sendStatus: msg.sendStatus
                });
                req.callback = null;
            }
            return true;
        },
        setInteractive: function () {
            this.__bridgeSend({ type: 'setInteractive' });
        },
        _recv_cronSyncStart: function ma__recv_cronSyncStart(msg) {
            if (this.oncronsyncstart)
                this.oncronsyncstart(msg.accountIds);
            return true;
        },
        _recv_cronSyncStop: function ma__recv_cronSyncStop(msg) {
            if (this.oncronsyncstop)
                this.oncronsyncstop(msg.accountsResults);
            return true;
        },
        _recv_backgroundSendStatus: function (msg) {
            if (this.onbackgroundsendstatus) {
                this.onbackgroundsendstatus(msg.data);
            }
            return true;
        },
        useLocalizedStrings: function (strings) {
            this.__bridgeSend({
                type: 'localizedStrings',
                strings: strings
            });
            if (strings.folderNames)
                this.l10n_folder_names = strings.folderNames;
        },
        l10n_folder_names: {},
        l10n_folder_name: function (name, type) {
            if (this.l10n_folder_names.hasOwnProperty(type)) {
                var lowerName = name.toLowerCase();
                if (type === lowerName || type === 'drafts' || type === 'junk' || type === 'queue')
                    return this.l10n_folder_names[type];
            }
            return name;
        },
        modifyConfig: function (mods) {
            for (var key in mods) {
                if (LEGAL_CONFIG_KEYS.indexOf(key) === -1)
                    throw new Error(key + ' is not a legal config key!');
            }
            this.__bridgeSend({
                type: 'modifyConfig',
                mods: mods
            });
        },
        _recv_config: function (msg) {
            this.config = msg.config;
            return true;
        },
        ping: function (callback) {
            var handle = this._nextHandle++;
            this._pendingRequests[handle] = {
                type: 'ping',
                callback: callback
            };
            window.setZeroTimeout(function () {
                this.__bridgeSend({
                    type: 'ping',
                    handle: handle
                });
            }.bind(this));
        },
        _recv_pong: function (msg) {
            var req = this._pendingRequests[msg.handle];
            delete this._pendingRequests[msg.handle];
            req.callback();
            return true;
        },
        debugSupport: function (command, argument) {
            if (command === 'setLogging')
                this.config.debugLogging = argument;
            this.__bridgeSend({
                type: 'debugSupport',
                cmd: command,
                arg: argument
            });
        }
    };
});
;
define('ext/worker-support/main-router', [], function () {
    'use strict';
    var listeners = {};
    var modules = [];
    var worker = null;
    function register(module) {
        var action, name = module.name;
        modules.push(module);
        if (module.process) {
            action = function (msg) {
                module.process(msg.uid, msg.cmd, msg.args);
            };
        } else if (module.dispatch) {
            action = function (msg) {
                if (module.dispatch[msg.cmd]) {
                    module.dispatch[msg.cmd].apply(module.dispatch, msg.args);
                }
            };
        }
        listeners[name] = action;
        module.sendMessage = function (uid, cmd, args, transferArgs) {
            worker.postMessage({
                type: name,
                uid: uid,
                cmd: cmd,
                args: args
            }, transferArgs);
        };
    }
    function unregister(module) {
        delete listeners['on' + module.name];
    }
    function shutdown() {
        modules.forEach(function (module) {
            if (module.shutdown)
                module.shutdown();
        });
    }
    function useWorker(_worker) {
        worker = _worker;
        worker.onmessage = function dispatchToListener(evt) {
            var data = evt.data;
            var listener = listeners[data.type];
            if (listener)
                listener(data);
        };
    }
    return {
        register: register,
        unregister: unregister,
        useWorker: useWorker,
        shutdown: shutdown
    };
});
;
define('ext/worker-support/updateCredentials-main', [], function () {
    'use strict';
    function updateAccountCredentials(uid, cmd, accountId) {
        let postResponse = function (credentials) {
            self.sendMessage(uid, cmd, [credentials]);
        };
        let data = { action: 'getAccounts' };
        accountManagerUtils.launchActivity(data).then(accounts => {
            for (let account of accounts) {
                if (accountId === account.accountId) {
                    let config = { refreshCredential: true };
                    let data = {
                        action: 'getCredential',
                        account: {
                            authenticatorId: account.authenticatorId,
                            accountId: account.accountId
                        }
                    };
                    accountManagerUtils.launchActivity(data).then(credential => {
                        postResponse(credential);
                    }, error => {
                        console.log('getCredential rejected: ' + error);
                        postResponse(null);
                    });
                    break;
                }
            }
        });
    }
    let self = {
        name: 'updateCredentials',
        sendMessage: null,
        process: function (uid, cmd, args) {
            updateAccountCredentials(uid, cmd, args[0]);
        }
    };
    return self;
});
define('ext/worker-support/configparser-main', [], function () {
    'use strict';
    function debug(str) {
    }
    function nsResolver(prefix) {
        var baseUrl = 'http://schemas.microsoft.com/exchange/autodiscover/';
        var ns = {
            rq: baseUrl + 'mobilesync/requestschema/2006',
            ad: baseUrl + 'responseschema/2006',
            ms: baseUrl + 'mobilesync/responseschema/2006'
        };
        return ns[prefix] || null;
    }
    function parseAccountCommon(uid, cmd, text) {
        var doc = new DOMParser().parseFromString(text, 'text/xml');
        var getNode = function (xpath, rel) {
            return doc.evaluate(xpath, rel || doc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
        };
        var dictifyChildNodes = function (node) {
            if (!node) {
                return null;
            }
            var dict = {};
            for (var kid = node.firstElementChild; kid; kid = kid.nextElementSibling) {
                dict[kid.tagName] = kid.textContent;
            }
            return dict;
        };
        var provider = getNode('/clientConfig/emailProvider');
        var incoming = getNode('incomingServer[@type="imap"] | ' + 'incomingServer[@type="activesync"] | ' + 'incomingServer[@type="pop3"]', provider);
        var outgoing = getNode('outgoingServer[@type="smtp"]', provider);
        var oauth2Settings = dictifyChildNodes(getNode('oauth2Settings', provider));
        var config = null;
        var status = null;
        if (incoming) {
            config = {
                type: null,
                incoming: {},
                outgoing: {},
                oauth2Settings: oauth2Settings
            };
            for (var iter in incoming.children) {
                var child = incoming.children[iter];
                config.incoming[child.tagName] = child.textContent;
            }
            if (incoming.getAttribute('type') === 'activesync') {
                config.type = 'activesync';
            } else if (outgoing) {
                var isImap = incoming.getAttribute('type') === 'imap';
                config.type = isImap ? 'imap+smtp' : 'pop3+smtp';
                for (var iter in outgoing.children) {
                    var child = outgoing.children[iter];
                    config.outgoing[child.tagName] = child.textContent;
                }
                var ALLOWED_SOCKET_TYPES = [
                    'SSL',
                    'STARTTLS'
                ];
                if (ALLOWED_SOCKET_TYPES.indexOf(config.incoming.socketType) === -1 || ALLOWED_SOCKET_TYPES.indexOf(config.outgoing.socketType) === -1) {
                    config = null;
                    status = 'unsafe';
                }
            } else {
                config = null;
                status = 'no-outgoing';
            }
        } else {
            status = 'no-incoming';
        }
        self.sendMessage(uid, cmd, [
            config,
            status
        ]);
    }
    function parseActiveSyncAccount(uid, cmd, text, aNoRedirect) {
        var doc = new DOMParser().parseFromString(text, 'text/xml');
        var getNode = function (xpath, rel) {
            return doc.evaluate(xpath, rel, nsResolver, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
        };
        var getNodes = function (xpath, rel) {
            return doc.evaluate(xpath, rel, nsResolver, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
        };
        var getString = function (xpath, rel) {
            return doc.evaluate(xpath, rel, nsResolver, XPathResult.STRING_TYPE, null).stringValue;
        };
        var postResponse = function (error, config, redirectedEmail) {
            self.sendMessage(uid, cmd, [
                config,
                error,
                redirectedEmail
            ]);
        };
        var error = null;
        if (doc.documentElement.tagName === 'parsererror') {
            error = 'Error parsing autodiscover response';
            return postResponse(error);
        }
        var responseNode = getNode('/ad:Autodiscover/ms:Response', doc) || getNode('/ms:Autodiscover/ms:Response', doc);
        if (!responseNode) {
            error = 'Missing Autodiscover Response node';
            return postResponse(error);
        }
        var error = getNode('ms:Error', responseNode) || getNode('ms:Action/ms:Error', responseNode);
        if (error) {
            error = getString('ms:Message/text()', error);
            return postResponse(error);
        }
        var redirect = getNode('ms:Action/ms:Redirect', responseNode);
        if (redirect) {
            if (aNoRedirect) {
                error = 'Multiple redirects occurred during autodiscovery';
                return postResponse(error);
            }
            var redirectedEmail = getString('text()', redirect);
            return postResponse(null, null, redirectedEmail);
        }
        var user = getNode('ms:User', responseNode);
        var config = {
            culture: getString('ms:Culture/text()', responseNode),
            user: {
                name: getString('ms:DisplayName/text()', user),
                email: getString('ms:EMailAddress/text()', user)
            },
            servers: []
        };
        var servers = getNodes('ms:Action/ms:Settings/ms:Server', responseNode);
        var server;
        while (server = servers.iterateNext()) {
            config.servers.push({
                type: getString('ms:Type/text()', server),
                url: getString('ms:Url/text()', server),
                name: getString('ms:Name/text()', server),
                serverData: getString('ms:ServerData/text()', server)
            });
        }
        for (var iter in config.servers) {
            var server = config.servers[iter];
            if (server.type === 'MobileSync') {
                config.mobileSyncServer = server;
                break;
            }
        }
        if (!config.mobileSyncServer) {
            error = 'No MobileSync server found';
            return postResponse(error, config);
        }
        postResponse(null, config);
    }
    ;
    var self = {
        name: 'configparser',
        sendMessage: null,
        process: function (uid, cmd, args) {
            debug('process ' + cmd);
            switch (cmd) {
            case 'accountcommon':
                parseAccountCommon(uid, cmd, args[0]);
                break;
            case 'accountactivesync':
                parseActiveSyncAccount(uid, cmd, args[0], args[1]);
                break;
            }
        }
    };
    return self;
});
define('ext/worker-support/cronsync-main', [
    'require',
    'evt'
], function (require) {
    'use strict';
    var evt = require('evt');
    function debug(str) {
        console.log('cronsync-main: ' + str);
    }
    function makeData(accountIds, interval, date) {
        return {
            type: 'sync',
            accountIds: accountIds,
            interval: interval,
            timestamp: date.getTime()
        };
    }
    function makeAccountKey(accountIds) {
        return 'id' + accountIds.join(' ');
    }
    var prefixLength = 'interval'.length;
    function toInterval(intervalKey) {
        return parseInt(intervalKey.substring(prefixLength), 10);
    }
    function hasSameValues(ary1, ary2) {
        if (ary1.length !== ary2.length) {
            return false;
        }
        var hasMismatch = ary1.some(function (item, i) {
            return item !== ary2[i];
        });
        return !hasMismatch;
    }
    function getPublicAccounts() {
        const emailSyncKey = 'emailSyncEnable';
        return new Promise(function (resolve, reject) {
            let data = { action: 'getAccounts' };
            accountManagerUtils.launchActivity(data).then(accounts => {
                let data = {
                    accounts: accounts,
                    syncSwitch: null
                };
                SettingsObserver.getValue(emailSyncKey).then(result => {
                    if (result) {
                        data.syncSwitch = result;
                    }
                    resolve(data);
                });
            }, reason => {
                reject(reason);
            });
        });
    }
    var dispatcher = {
        _routeReady: false,
        _routeQueue: [],
        _sendMessage: function (type, args) {
            if (this._routeReady) {
                routeRegistration.sendMessage(null, type, args);
            } else {
                this._routeQueue.push([
                    type,
                    args
                ]);
            }
        },
        hello: function () {
            this._routeReady = true;
            if (this._routeQueue.length) {
                var queue = this._routeQueue;
                this._routeQueue = [];
                queue.forEach(function (args) {
                    this._sendMessage(args[0], args[1]);
                }.bind(this));
            }
        },
        clearAll: function () {
            var mozAlarms = navigator.b2g.alarmManager;
            if (!mozAlarms) {
                return;
            }
            var r = mozAlarms.getAll();
            r.then(alarms => {
                if (!alarms) {
                    return;
                }
                alarms.forEach(function (alarm) {
                    if (alarm.data && alarm.data.type === 'sync') {
                        mozAlarms.remove(alarm.id);
                    }
                });
            }, error => {
                console.error('cronsync-main clearAll mozAlarms.getAll: error: ' + error);
            });
        },
        ensureSync: function (syncData) {
            var mozAlarms = navigator.b2g.alarmManager;
            if (!mozAlarms) {
                console.warn('no alarmManager support!');
                return;
            }
            debug('ensureSync called');
            var request = mozAlarms.getAll();
            request.then(alarms => {
                debug('success!');
                if (!alarms) {
                    alarms = [];
                }
                var expiredAlarmIds = [], okAlarmIntervals = {}, uniqueAlarms = {};
                alarms.forEach(function (alarm) {
                    if (!alarm.data || !alarm.data.type || alarm.data.type !== 'sync') {
                        return;
                    }
                    var intervalKey = 'interval' + alarm.data.interval, wantedAccountIds = syncData[intervalKey];
                    if (!wantedAccountIds || !hasSameValues(wantedAccountIds, alarm.data.accountIds)) {
                        debug('account array mismatch, canceling existing alarm');
                        expiredAlarmIds.push(alarm.id);
                    } else {
                        var interval = toInterval(intervalKey), now = Date.now(), alarmTime = alarm.data.timestamp, accountKey = makeAccountKey(wantedAccountIds);
                        if (interval && !uniqueAlarms.hasOwnProperty(accountKey) && alarmTime > now && alarmTime < now + interval) {
                            debug('existing alarm is OK: ' + accountKey);
                            uniqueAlarms[accountKey] = true;
                            okAlarmIntervals[intervalKey] = true;
                        } else {
                            debug('existing alarm is out of interval range, canceling');
                            expiredAlarmIds.push(alarm.id);
                        }
                    }
                });
                expiredAlarmIds.forEach(function (alarmId) {
                    mozAlarms.remove(alarmId);
                });
                var alarmMax = 0, alarmCount = 0, self = this;
                function done() {
                    alarmCount += 1;
                    if (alarmCount < alarmMax) {
                        return;
                    }
                    debug('ensureSync completed');
                    self._sendMessage('syncEnsured');
                }
                Object.keys(syncData).forEach(function (intervalKey) {
                    if (okAlarmIntervals.hasOwnProperty(intervalKey)) {
                        return;
                    }
                    var interval = toInterval(intervalKey), accountIds = syncData[intervalKey], date = new Date(Date.now() + interval);
                    if (!interval) {
                        return;
                    }
                    alarmMax += 1;
                    var options = {
                        'date': date,
                        'data': makeData(accountIds, interval, date),
                        'ignoreTimezone': true
                    };
                    var alarmRequest = mozAlarms.add(options);
                    alarmRequest.then(() => {
                        debug('success: mozAlarms.add for ' + 'IDs: ' + accountIds + ' at ' + interval + 'ms');
                        done();
                    }, error => {
                        console.error('cronsync-main mozAlarms.add for IDs: ' + accountIds + ' failed: ' + error);
                    });
                });
                if (!alarmMax) {
                    done();
                }
            }, error => {
                console.error('cronsync-main ensureSync mozAlarms.getAll: error: ' + error);
            });
        }
    };
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.addEventListener('message', event => {
            var type = event.data.type;
            var datas = event.data.data;
            if (type !== 'alarm') {
                return;
            }
            console.log('mozSetMessageHandler: received an alarm');
            if (window.hasOwnProperty('appDispatchedMessage')) {
                window.appDispatchedMessage = true;
            }
            var data = datas.data;
            if (!data || data.type !== 'sync') {
                return;
            }
            if (navigator.b2g.requestWakeLock) {
                var locks = [navigator.b2g.requestWakeLock('cpu')];
                debug('wake locks acquired: ' + locks + ' for account IDs: ' + data.accountIds);
                evt.emitWhenListener('cronSyncWakeLocks', makeAccountKey(data.accountIds), locks);
            }
            debug('alarm dispatch started at ' + new Date());
            getPublicAccounts().then(accountsData => {
                dispatcher._sendMessage('alarm', [
                    data.accountIds,
                    accountsData,
                    data.interval
                ]);
            });
        });
    }
    var routeRegistration = {
        name: 'cronsync',
        sendMessage: null,
        dispatch: dispatcher
    };
    return routeRegistration;
});
define('ext/worker-support/deviceInfo-main', [], function () {
    'use strict';
    let connection;
    if (navigator.b2g.mobileConnections) {
        connection = navigator.b2g.mobileConnections[0];
    }
    function debug(str) {
        console.log('DeviceInfo: ' + str + '\n');
    }
    function getDeviceInfoError(str) {
        return 'Get device info:' + str + ' error!';
    }
    function getIMEI() {
        return new Promise(function (resolve, reject) {
            if (!connection) {
                reject('No mobileConnections!');
            }
            resolve(connection.getDeviceIdentities().imei);
        });
    }
    function getPhoneNumber() {
        let msisdn = null;
        if (connection) {
            let iccId = connection.iccId;
            if (iccId) {
                let iccInfo = navigator.b2g.iccManager.getIccById(iccId);
                msisdn = iccInfo.msisdn || iccInfo.mdn;
            }
        }
        return msisdn;
    }
    function getOperatorName() {
        let operatorName = null;
        if (connection && connection.data && connection.data.network) {
            operatorName = connection.data.network.longName;
        }
        return operatorName;
    }
    function getSettings(key) {
        return new Promise(function (resolve, reject) {
            if (!SettingsObserver) {
                reject('No SettingsObserver!!!');
            }
            let request = SettingsObserver.getValue(key);
            request.then(result => {
                let value = result[key];
                resolve(value);
            }, error => {
                console.error('Could not get settings value : ' + key);
                resolve();
            });
        });
    }
    function getDeviceInfo(uid, cmd) {
        let deviceInfo = {
            deviceType: 'KaiOS',
            imei: '000000000000000',
            phoneNumber: '',
            deviceName: 'KaiDevice',
            modelName: 'KaiOS',
            OSName: 'KaiOS',
            OSLanguage: 'en-US',
            operatorName: ''
        };
        let postResponse = function (error, deviceInfo) {
            self.sendMessage(uid, cmd, [
                deviceInfo,
                error
            ]);
        };
        let deviceNameKey = 'deviceinfo.product_device';
        let modelNamekey = 'deviceinfo.product_model';
        let languageKey = 'language.current';
        getSettings(deviceNameKey).then(value => {
            if (value) {
                deviceInfo.deviceName = value;
            }
            getSettings(modelNamekey).then(value => {
                if (value) {
                    deviceInfo.modelName = value;
                }
                getSettings(languageKey).then(value => {
                    if (value) {
                        deviceInfo.OSLanguage = value;
                    }
                    getIMEI().then(value => {
                        if (value) {
                            deviceInfo.imei = value;
                        } else {
                            return postResponse(getDeviceInfoError('IMEI'));
                        }
                        let number = getPhoneNumber();
                        let operatorName = getOperatorName();
                        if (number) {
                            deviceInfo.phoneNumber = number;
                        }
                        if (operatorName) {
                            deviceInfo.operatorName = operatorName;
                        }
                        debug(JSON.stringify(deviceInfo));
                        postResponse(null, deviceInfo);
                    });
                });
            });
        });
    }
    function factoryReset() {
        debug('factory reset!!!');
        if (!PowerManager) {
            console.error('Cannot get PowerManager');
            return;
        }
        if (!PowerManager.setFactoryReset) {
            console.error('Cannot invoke PowerManager.setFactoryReset');
            return;
        }
        PowerManager.setFactoryReset();
    }
    let self = {
        name: 'deviceInfo',
        sendMessage: null,
        process: function (uid, cmd) {
            switch (cmd) {
            case 'get':
                getDeviceInfo(uid, cmd);
                break;
            case 'reset':
                factoryReset();
                break;
            }
        }
    };
    return self;
});
define('device_storage', ['require'], function (require) {
    function getDefaultWriteStorage() {
        return new Promise(res => {
            if (SettingsObserver) {
                SettingsObserver.getValue('device.storage.writable.name').then(result => {
                    res(result);
                }, () => {
                    res('sdcard');
                });
            } else {
                res('sdcard');
            }
        });
    }
    const DeviceStorage = {
        get: (storage = 'sdcard') => {
            const storages = navigator.b2g.getDeviceStorages(storage);
            return new Promise(res => {
                let deviceStorage = null;
                if (storages && storages[0]) {
                    deviceStorage = storages[0];
                    if (storages.length > 1) {
                        getDefaultWriteStorage().then(value => {
                            if ('sdcard1' === value) {
                                deviceStorage = storages[1];
                            }
                            res(deviceStorage);
                        });
                    } else {
                        res(deviceStorage);
                    }
                } else {
                    res(deviceStorage);
                }
            });
        }
    };
    return DeviceStorage;
});
define('ext/worker-support/devicestorage-main', [
    'require',
    'exports',
    'module',
    'device_storage'
], function (require, exports, module) {
    'use strict';
    let DeviceStorage = require('device_storage');
    function debug(str) {
        dump('DeviceStorage: ' + str + '\n');
    }
    function save(uid, cmd, storage, blob, filename, registerDownload) {
        DeviceStorage.get(storage).then(deviceStorage => {
            if (!deviceStorage) {
                self.sendMessage(uid, cmd, [
                    false,
                    'no-device-storage',
                    null,
                    false
                ]);
                return;
            }
            if (filename.indexOf('\r\n') > 0) {
                filename = filename.replace('\r\n', '');
            }
            filename = filename.replace(/[\s#&?<>\$]/g, '');
            filename = 'downloads/' + filename;
            var req = deviceStorage.addNamed(blob, filename);
            req.onerror = function () {
                self.sendMessage(uid, cmd, [
                    false,
                    req.error.name,
                    null,
                    false
                ]);
            };
            req.onsuccess = function (e) {
                var prefix = '';
                if (typeof window.IS_GELAM_TEST !== 'undefined') {
                    prefix = 'TEST_PREFIX/';
                }
                var savedPath = prefix + e.target.result;
                var registering = false;
                var url = window.AppOrigin.getOrigin('email');
                if (registerDownload) {
                    var downloadManager = navigator.b2g.downloadManager;
                    console.warn('have downloadManager?', !!downloadManager, 'have adoptDownload?', downloadManager && !!downloadManager.adoptDownload);
                    if (downloadManager && downloadManager.adoptDownload) {
                        try {
                            var fullPath = e.target.result;
                            var firstSlash = fullPath.indexOf('/', 2);
                            var storageName = fullPath.substring(1, firstSlash);
                            var storagePath = fullPath.substring(firstSlash + 1);
                            console.log('adopting download', deviceStorage.storageName, e.target.result);
                            registering = true;
                            downloadManager.adoptDownload({
                                totalBytes: blob.size,
                                url: url,
                                storageName: storageName,
                                storagePath: storagePath,
                                contentType: blob.type,
                                startTime: new Date(Date.now())
                            }).then(function () {
                                console.log('registered download with download manager');
                                self.sendMessage(uid, cmd, [
                                    true,
                                    null,
                                    savedPath,
                                    true
                                ]);
                            }, function () {
                                console.warn('failed to register download with download manager');
                                self.sendMessage(uid, cmd, [
                                    true,
                                    null,
                                    savedPath,
                                    false
                                ]);
                            });
                        } catch (ex) {
                            console.error('Problem adopting download!:', ex, '\n', ex.stack);
                        }
                    } else {
                        console.log('download manager not available, not registering.');
                    }
                } else {
                    console.log('do not want to register download');
                }
                if (!registering) {
                    self.sendMessage(uid, cmd, [
                        true,
                        null,
                        savedPath,
                        false
                    ]);
                }
            };
        });
    }
    var self = {
        name: 'devicestorage',
        sendMessage: null,
        process: function (uid, cmd, args) {
            debug('process ' + cmd);
            switch (cmd) {
            case 'save':
                save(uid, cmd, args[0], args[1], args[2], args[3]);
                break;
            }
        }
    };
    return self;
});
define('ext/worker-support/maildb-main', [], function () {
    'use strict';
    function debug(str) {
        dump('MailDB: ' + str + '\n');
    }
    var db = null;
    function open(uid, cmd, args) {
        db = self._debugDB = new MailDB(args[0], function () {
            self.sendMessage(uid, cmd, Array.prototype.slice.call(arguments));
        });
    }
    function others(uid, cmd, args) {
        if (!Array.isArray(args))
            args = [];
        args.push(function () {
            self.sendMessage(uid, cmd, Array.prototype.slice.call(arguments));
        });
        if (!db._db)
            console.warn('trying to call', cmd, 'on apparently dead db. skipping.');
        else
            db[cmd].apply(db, args);
    }
    var self = {
        name: 'maildb',
        sendMessage: null,
        process: function (uid, cmd, args) {
            switch (cmd) {
            case 'open':
                open(uid, cmd, args);
                break;
            default:
                others(uid, cmd, args);
                break;
            }
        },
        _debugDB: null
    };
    var IndexedDB;
    if ('indexedDB' in window && window.indexedDB) {
        IndexedDB = window.indexedDB;
    } else if ('mozIndexedDB' in window && window.mozIndexedDB) {
        IndexedDB = window.mozIndexedDB;
    } else if ('webkitIndexedDB' in window && window.webkitIndexedDB) {
        IndexedDB = window.webkitIndexedDB;
    } else {
        console.error('No IndexedDB!');
        throw new Error('I need IndexedDB; load me in a content page universe!');
    }
    var CUR_VERSION = 22;
    var FRIENDLY_LAZY_DB_UPGRADE_VERSION = 5;
    var TBL_CONFIG = 'config', CONFIG_KEY_ROOT = 'config', CONFIG_KEYPREFIX_ACCOUNT_DEF = 'accountDef:';
    var TBL_FOLDER_INFO = 'folderInfo';
    var TBL_HEADER_BLOCKS = 'headerBlocks';
    var TBL_BODY_BLOCKS = 'bodyBlocks';
    let count = 3;
    function MailDB(testOptions, successCb, errorCb, upgradeCb) {
        this._db = null;
        this._lazyConfigCarryover = null;
        let self = this;
        this._fatalError = function (event) {
            function explainSource(source) {
                if (!source)
                    return 'unknown source';
                if (source instanceof IDBObjectStore)
                    return 'object store "' + source.name + '"';
                if (source instanceof IDBIndex)
                    return 'index "' + source.name + '" on object store "' + source.objectStore.name + '"';
                if (source instanceof IDBCursor)
                    return 'cursor on ' + explainSource(source.source);
                return 'unexpected source';
            }
            var explainedSource, target = event.target;
            if (target instanceof IDBTransaction) {
                explainedSource = 'transaction (' + target.mode + ')';
            } else if (target instanceof IDBRequest) {
                explainedSource = 'request as part of ' + (target.transaction ? target.transaction.mode : 'NO') + ' transaction on ' + explainSource(target.source);
            } else {
                explainedSource = target.toString();
            }
            console.error('indexedDB error:', target.error.name, 'from', explainedSource);
            if ('QuotaExceededError' === target.error.name) {
                if (!localStorage.getItem('data_has_account')) {
                    window.close();
                }
            }
        };
        this.openDB = function () {
            return new Promise(resolve => {
                var dbVersion = CUR_VERSION;
                if (testOptions && testOptions.dbDelta)
                    dbVersion += testOptions.dbDelta;
                if (testOptions && testOptions.dbVersion)
                    dbVersion = testOptions.dbVersion;
                var openRequest = IndexedDB.open('b2g-email', dbVersion);
                openRequest.onsuccess = function (event) {
                    self._db = openRequest.result;
                    if (self._db.objectStoreNames.contains(TBL_CONFIG)) {
                        successCb();
                        resolve();
                    } else {
                        if (count--) {
                            self._db.close();
                            self._db = null;
                            IndexedDB.deleteDatabase('b2g-email');
                            MailDB.call(self, testOptions, successCb, errorCb, upgradeCb);
                        }
                    }
                };
                openRequest.onupgradeneeded = function (event) {
                    console.log('MailDB in onupgradeneeded');
                    var db = openRequest.result;
                    if (event.oldVersion < FRIENDLY_LAZY_DB_UPGRADE_VERSION || testOptions && testOptions.nukeDb) {
                        self._nukeDB(db);
                    } else {
                        var trans = openRequest.transaction;
                        self.getConfig(function (configObj, accountInfos) {
                            if (configObj)
                                self._lazyConfigCarryover = {
                                    oldVersion: event.oldVersion,
                                    config: configObj,
                                    accountInfos: accountInfos
                                };
                            self._nukeDB(db);
                        }, trans);
                    }
                    resolve();
                };
                openRequest.onerror = this._fatalError;
            });
        };
        this.openDB();
    }
    MailDB.prototype = {
        _nukeDB: function (db) {
            var existingNames = db.objectStoreNames;
            for (var i = 0; i < existingNames.length; i++) {
                db.deleteObjectStore(existingNames[i]);
            }
            db.createObjectStore(TBL_CONFIG);
            db.createObjectStore(TBL_FOLDER_INFO);
            db.createObjectStore(TBL_HEADER_BLOCKS);
            db.createObjectStore(TBL_BODY_BLOCKS);
        },
        close: function () {
            if (this._db) {
                this._db.close();
                this._db = null;
            }
        },
        getConfig: function (callback, trans) {
            var transaction = trans || this._db.transaction([
                TBL_CONFIG,
                TBL_FOLDER_INFO
            ], 'readonly');
            var configStore = transaction.objectStore(TBL_CONFIG), folderInfoStore = transaction.objectStore(TBL_FOLDER_INFO);
            var configReq = configStore.mozGetAll(), folderInfoReq = folderInfoStore.mozGetAll();
            configReq.onerror = this._fatalError;
            folderInfoReq.onerror = this._fatalError;
            var self = this;
            folderInfoReq.onsuccess = function (event) {
                var configObj = null, accounts = [], i, obj;
                if (self._lazyConfigCarryover) {
                    var lazyCarryover = self._lazyConfigCarryover;
                    self._lazyConfigCarryover = null;
                    callback(configObj, accounts, lazyCarryover);
                    return;
                }
                for (i = 0; i < configReq.result.length; i++) {
                    obj = configReq.result[i];
                    if (obj.id === 'config')
                        configObj = obj;
                    else
                        accounts.push({
                            def: obj,
                            folderInfo: null
                        });
                }
                for (i = 0; i < folderInfoReq.result.length; i++) {
                    accounts[i].folderInfo = folderInfoReq.result[i];
                }
                try {
                    callback(configObj, accounts);
                } catch (ex) {
                    console.error('Problem in configCallback', ex, '\n', ex.stack);
                }
            };
        },
        saveConfig: function (config) {
            var req = this._db.transaction(TBL_CONFIG, 'readwrite').objectStore(TBL_CONFIG).put(config, 'config');
            req.onerror = this._fatalError;
        },
        saveAccountDef: function (config, accountDef, folderInfo, callback) {
            var trans = this._db.transaction([
                TBL_CONFIG,
                TBL_FOLDER_INFO
            ], 'readwrite');
            var configStore = trans.objectStore(TBL_CONFIG);
            configStore.put(config, 'config');
            configStore.put(accountDef, CONFIG_KEYPREFIX_ACCOUNT_DEF + accountDef.id);
            if (folderInfo) {
                trans.objectStore(TBL_FOLDER_INFO).put(folderInfo, accountDef.id);
            }
            trans.onerror = this._fatalError;
            if (callback) {
                trans.oncomplete = function () {
                    callback();
                };
            }
        },
        loadHeaderBlock: function (folderId, blockId, callback) {
            var req = this._db.transaction(TBL_HEADER_BLOCKS, 'readonly').objectStore(TBL_HEADER_BLOCKS).get(folderId + ':' + blockId);
            req.onerror = this._fatalError;
            req.onsuccess = function () {
                callback(req.result);
            };
        },
        loadBodyBlock: function (folderId, blockId, callback) {
            var req = this._db.transaction(TBL_BODY_BLOCKS, 'readonly').objectStore(TBL_BODY_BLOCKS).get(folderId + ':' + blockId);
            req.onerror = this._fatalError;
            req.onsuccess = function () {
                callback(req.result);
            };
        },
        saveAccountFolderStates: function (accountId, folderInfo, perFolderStuff, deletedFolderIds, callback) {
            var trans = this._db.transaction([
                TBL_FOLDER_INFO,
                TBL_HEADER_BLOCKS,
                TBL_BODY_BLOCKS
            ], 'readwrite');
            trans.onerror = this._fatalError;
            trans.objectStore(TBL_FOLDER_INFO).put(folderInfo, accountId);
            var headerStore = trans.objectStore(TBL_HEADER_BLOCKS), bodyStore = trans.objectStore(TBL_BODY_BLOCKS), i;
            var operationQueue = [];
            function addToQueue() {
                var args = Array.prototype.slice.call(arguments);
                var store = args.shift();
                var type = args.shift();
                operationQueue.push({
                    store: store,
                    type: type,
                    args: args
                });
            }
            function workQueue() {
                var pendingRequest = operationQueue.shift();
                if (!pendingRequest)
                    return;
                var store = pendingRequest.store;
                var type = pendingRequest.type;
                var request = store[type].apply(store, pendingRequest.args);
                request.onsuccess = request.onerror = workQueue;
            }
            for (i = 0; i < perFolderStuff.length; i++) {
                var pfs = perFolderStuff[i], block;
                for (var headerBlockId in pfs.headerBlocks) {
                    block = pfs.headerBlocks[headerBlockId];
                    if (block)
                        addToQueue(headerStore, 'put', block, pfs.id + ':' + headerBlockId);
                    else
                        addToQueue(headerStore, 'delete', pfs.id + ':' + headerBlockId);
                }
                for (var bodyBlockId in pfs.bodyBlocks) {
                    block = pfs.bodyBlocks[bodyBlockId];
                    if (block)
                        addToQueue(bodyStore, 'put', block, pfs.id + ':' + bodyBlockId);
                    else
                        addToQueue(bodyStore, 'delete', pfs.id + ':' + bodyBlockId);
                }
            }
            if (deletedFolderIds) {
                for (i = 0; i < deletedFolderIds.length; i++) {
                    var folderId = deletedFolderIds[i], range = IDBKeyRange.bound(folderId + ':', folderId + ':\uFFF0', false, false);
                    addToQueue(headerStore, 'delete', range);
                    addToQueue(bodyStore, 'delete', range);
                }
            }
            if (callback) {
                trans.addEventListener('complete', function () {
                    callback();
                });
            }
            trans.addEventListener('error', err => {
                if (err.target.error.name !== 'QuotaExceededError') {
                    return;
                }
                this._db.close();
                this.openDB().then(() => {
                    console.log('indexedDB reopened');
                    setTimeout(() => {
                        this.saveAccountFolderStates(accountId, folderInfo, perFolderStuff, deletedFolderIds, callback);
                    }, 3000);
                });
                return;
            });
            workQueue();
            return trans;
        },
        deleteAccount: function (accountId) {
            var trans = this._db.transaction([
                TBL_CONFIG,
                TBL_FOLDER_INFO,
                TBL_HEADER_BLOCKS,
                TBL_BODY_BLOCKS
            ], 'readwrite');
            trans.onerror = this._fatalError;
            trans.objectStore(TBL_CONFIG).delete('accountDef:' + accountId);
            trans.objectStore(TBL_FOLDER_INFO).delete(accountId);
            var range = IDBKeyRange.bound(accountId + '/', accountId + '/\uFFF0', false, false);
            trans.objectStore(TBL_HEADER_BLOCKS).delete(range);
            trans.objectStore(TBL_BODY_BLOCKS).delete(range);
        }
    };
    return self;
});
define('ext/async_blob_fetcher', ['exports'], function (exports) {
    function asyncFetchBlobAsUint8Array(blob, callback) {
        var blobUrl = URL.createObjectURL(blob);
        var xhr = new XMLHttpRequest();
        xhr.open('GET', blobUrl, true);
        xhr.responseType = 'arraybuffer';
        xhr.onload = function () {
            if (xhr.status !== 0 && (xhr.status < 200 || xhr.status >= 300)) {
                callback(xhr.status);
                return;
            }
            callback(null, new Uint8Array(xhr.response));
        };
        xhr.onerror = function () {
            callback('error');
        };
        try {
            xhr.send();
        } catch (ex) {
            console.error('XHR send() failure on blob');
            callback('error');
        }
        URL.revokeObjectURL(blobUrl);
    }
    return { asyncFetchBlobAsUint8Array: asyncFetchBlobAsUint8Array };
});
;
define('ext/worker-support/net-main', [
    'require',
    '../async_blob_fetcher'
], function (require) {
    'use strict';
    var asyncFetchBlobAsUint8Array = require('../async_blob_fetcher').asyncFetchBlobAsUint8Array;
    var sockInfoByUID = {};
    function open(uid, host, port, options) {
        var socket = navigator.mozTCPSocket;
        var sock = socket.open(host, port, options);
        var sockInfo = sockInfoByUID[uid] = {
            uid: uid,
            sock: sock,
            activeBlob: null,
            blobOffset: 0,
            queuedData: null,
            backlog: []
        };
        sock.onopen = function (evt) {
            self.sendMessage(uid, 'onopen');
        };
        sock.onerror = function (evt) {
            var err = evt.data || evt;
            var wrappedErr;
            if (err && typeof err === 'object') {
                wrappedErr = {
                    name: err.name,
                    type: err.type,
                    message: err.message
                };
            } else {
                wrappedErr = err;
            }
            self.sendMessage(uid, 'onerror', wrappedErr);
        };
        sock.ondata = function (evt) {
            var buf = evt.data;
            self.sendMessage(uid, 'ondata', buf, [buf]);
        };
        sock.ondrain = function (evt) {
            if (sockInfo.activeBlob && sockInfo.queuedData) {
                console.log('net-main(' + sockInfo.uid + '): Socket drained, sending.');
                sock.send(sockInfo.queuedData.buffer, 0, sockInfo.queuedData.byteLength);
                sockInfo.queuedData = null;
                fetchNextBlobChunk(sockInfo);
            } else {
                self.sendMessage(uid, 'ondrain');
            }
        };
        sock.onclose = function (evt) {
            self.sendMessage(uid, 'onclose');
            delete sockInfoByUID[uid];
        };
    }
    function beginBlobSend(sockInfo, blob) {
        console.log('net-main(' + sockInfo.uid + '): Blob send of', blob.size, 'bytes');
        sockInfo.activeBlob = blob;
        sockInfo.blobOffset = 0;
        sockInfo.queuedData = null;
        fetchNextBlobChunk(sockInfo);
    }
    function fetchNextBlobChunk(sockInfo) {
        if (sockInfo.blobOffset >= sockInfo.activeBlob.size) {
            console.log('net-main(' + sockInfo.uid + '): Blob send completed.', 'backlog length:', sockInfo.backlog.length);
            sockInfo.activeBlob = null;
            var backlog = sockInfo.backlog;
            while (backlog.length) {
                var sendArgs = backlog.shift();
                var data = sendArgs[0];
                if (data instanceof Blob) {
                    beginBlobSend(sockInfo, data);
                    return;
                }
                sockInfo.sock.send(data, sendArgs[1], sendArgs[2]);
            }
            return;
        }
        var nextOffset = Math.min(sockInfo.blobOffset + self.BLOB_BLOCK_READ_SIZE, sockInfo.activeBlob.size);
        console.log('net-main(' + sockInfo.uid + '): Fetching bytes', sockInfo.blobOffset, 'through', nextOffset, 'of', sockInfo.activeBlob.size);
        var blobSlice = sockInfo.activeBlob.slice(sockInfo.blobOffset, nextOffset);
        sockInfo.blobOffset = nextOffset;
        function gotChunk(err, binaryDataU8) {
            console.log('net-main(' + sockInfo.uid + '): Retrieved chunk');
            if (err) {
                sockInfo.sock.close();
                return;
            }
            if (sockInfo.sock.bufferedAmount === 0) {
                console.log('net-main(' + sockInfo.uid + '): Sending chunk immediately.');
                sockInfo.sock.send(binaryDataU8.buffer, 0, binaryDataU8.byteLength);
                fetchNextBlobChunk(sockInfo);
                return;
            }
            sockInfo.queuedData = binaryDataU8;
        }
        ;
        asyncFetchBlobAsUint8Array(blobSlice, gotChunk);
    }
    function close(uid) {
        var sockInfo = sockInfoByUID[uid];
        if (!sockInfo)
            return;
        var sock = sockInfo.sock;
        sock.close();
        sock.onopen = null;
        sock.onerror = null;
        sock.ondata = null;
        sock.ondrain = null;
        sock.onclose = null;
        self.sendMessage(uid, 'onclose');
        delete sockInfoByUID[uid];
    }
    function write(uid, data, offset, length) {
        var sockInfo = sockInfoByUID[uid];
        if (!sockInfo) {
            return;
        }
        if (sockInfo.activeBlob) {
            sockInfo.backlog.push([
                data,
                offset,
                length
            ]);
            return;
        }
        self.sendMessage(uid, 'onprogress', []);
        if (data instanceof Blob) {
            beginBlobSend(sockInfo, data);
        } else {
            sockInfo.sock.send(data, offset, length);
        }
    }
    function upgradeToSecure(uid) {
        var sockInfo = sockInfoByUID[uid];
        if (!sockInfo)
            return;
        sockInfo.sock.upgradeToSecure();
    }
    var self = {
        name: 'netsocket',
        sendMessage: null,
        BLOB_BLOCK_READ_SIZE: 96 * 1024,
        process: function (uid, cmd, args) {
            switch (cmd) {
            case 'open':
                open(uid, args[0], args[1], args[2]);
                break;
            case 'close':
                close(uid);
                break;
            case 'write':
                write(uid, args[0], args[1], args[2]);
                break;
            case 'upgradeToSecure':
                upgradeToSecure(uid);
                break;
            default:
                console.error('Unhandled net-main command:', cmd);
                break;
            }
        }
    };
    return self;
});
define('ext/worker-support/wakelocks-main', [], function () {
    'use strict';
    function debug(str) {
        dump('WakeLocks: ' + str + '\n');
    }
    var nextId = 1;
    var locks = {};
    function requestWakeLock(type) {
        var lock = navigator.b2g.requestWakeLock(type);
        var id = nextId++;
        locks[id] = lock;
        return id;
    }
    var self = {
        name: 'wakelocks',
        sendMessage: null,
        process: function (uid, cmd, args) {
            debug('process ' + cmd + ' ' + JSON.stringify(args));
            switch (cmd) {
            case 'requestWakeLock':
                var type = args[0];
                self.sendMessage(uid, cmd, [requestWakeLock(type)]);
                break;
            case 'unlock':
                var id = args[0];
                var lock = locks[id];
                if (lock) {
                    lock.unlock();
                    delete locks[id];
                }
                self.sendMessage(uid, cmd, []);
            }
        }
    };
    return self;
});
define('ext/worker-support/contactapi-main', [], function () {
    'use strict';
    const ContactAPI = {
        _uid: null,
        _cmd: null,
        postResponse: function (result, error = null) {
            self.sendMessage(this._uid, this._cmd, [
                result,
                error
            ]);
        },
        getContactName: function (items) {
            if (!items || !items.length) {
                this.postResponse(null, 'empty');
                return;
            }
            items.forEach(item => {
                item.author = self.ContactCache.resolvePeep(item.author);
            });
            this.postResponse(items);
        }
    };
    var self = {
        name: 'contactapi',
        sendMessage: null,
        ContactCache: null,
        process: function (uid, cmd, args) {
            ContactAPI._uid = uid;
            ContactAPI._cmd = cmd;
            ContactAPI[cmd](args[0]);
        }
    };
    return self;
});
window.setZeroTimeout = function (fn) {
    setTimeout(function () {
        fn();
    }, 0);
};
define('ext/main-frame-setup', [
    './mailapi',
    './worker-support/main-router',
    './worker-support/updateCredentials-main',
    './worker-support/configparser-main',
    './worker-support/cronsync-main',
    './worker-support/deviceInfo-main',
    './worker-support/devicestorage-main',
    './worker-support/maildb-main',
    './worker-support/net-main',
    './worker-support/wakelocks-main',
    './worker-support/contactapi-main',
    'require'
], function ($mailapi, $router, $updateCredentials, $configparser, $cronsync, $deviceinfo, $devicestorage, $maildb, $net, $wakelocks, $contactapi, require) {
    var control = {
        name: 'control',
        sendMessage: null,
        process: function (uid, cmd, args) {
            var online = navigator.connection.type !== 'none';
            control.sendMessage(uid, 'hello', [online]);
            window.navigator.connection.addEventListener('typechange', function (evt) {
                var type = evt.target.type;
                if (type !== 'none') {
                    control.sendMessage(uid, 'online', [true]);
                } else {
                    control.sendMessage(uid, 'offline', [false]);
                }
            });
            $router.unregister(control);
        }
    };
    var MailAPI = new $mailapi.MailAPI();
    var ContactCache = $mailapi.ContactCache;
    $contactapi.ContactCache = ContactCache;
    var bridge = {
        name: 'bridge',
        sendMessage: null,
        process: function (uid, cmd, args) {
            var msg = args;
            if (msg.type === 'hello') {
                delete MailAPI._fake;
                MailAPI.__bridgeSend = function (msg) {
                    worker.postMessage({
                        uid: uid,
                        type: 'bridge',
                        msg: msg
                    });
                };
                MailAPI.config = msg.config;
                MailAPI._storedSends.forEach(function (msg) {
                    MailAPI.__bridgeSend(msg);
                });
                MailAPI._storedSends = [];
            } else {
                MailAPI.__bridgeReceive(msg);
            }
        }
    };
    var worker = new Worker(require.toUrl('./worker-bootstrap.js'));
    $router.useWorker(worker);
    $router.register(control);
    $router.register(bridge);
    $router.register($updateCredentials);
    $router.register($configparser);
    $router.register($cronsync);
    $router.register($devicestorage);
    $router.register($deviceinfo);
    $router.register($maildb);
    $router.register($net);
    $router.register($wakelocks);
    $router.register($contactapi);
    return MailAPI;
});
;
define('accounts_sync', [
    'require',
    'api',
    'evt',
    'model',
    'cards'
], function (require) {
    let MailAPI = require('api'), evt = require('evt'), model = require('model'), cards = require('cards');
    const emailSyncKey = 'emailSyncEnable';
    const DELAY_LOAD_TIME = 2000;
    let accountSync = {
        doSync: false,
        bAdded: false,
        index: 0,
        accounts: [],
        accountIds: [],
        accountsList: [],
        syncSwitch: [],
        autoAddedListener: false,
        userAddedListener: false,
        addChangedHandler: false,
        getCredential: function (account, refreshCredential) {
            console.log('Get account credential of ' + account.accountId);
            return new Promise(function (resolve, reject) {
                let action = refreshCredential ? 'refreshCredential' : 'getCredential';
                let data = {
                    action: action,
                    account: {
                        authenticatorId: account.authenticatorId,
                        accountId: account.accountId
                    }
                };
                if (!account.accountId) {
                    return;
                }
                accountManagerUtils.launchActivity(data).then(credential => {
                    resolve(credential);
                }, error => {
                    console.log('getCredential rejected: ' + error);
                    reject(error);
                });
            });
        },
        updateAccount: function (refresh = false, action = 'none') {
            let account = this.accounts[this.index];
            let mailAddress = account.accountId;
            let authenticatorId = account.authenticatorId;
            let enable = true;
            let syncKey = `${ authenticatorId }:${ mailAddress }`;
            if (this.syncSwitch[syncKey] !== undefined) {
                enable = this.syncSwitch[syncKey];
            }
            this.accountIds.push(mailAddress);
            this.getCredential(account, refresh).then(credential => {
                let oauth2Tokens;
                let password;
                let config = {};
                let mailData = {
                    address: mailAddress,
                    syncEnable: enable,
                    autoSetup: true
                };
                if (credential.access_token) {
                    if (Date.now() < credential.expire_timestamp) {
                        oauth2Tokens = {
                            accessToken: credential.access_token,
                            expireTimeMS: credential.expire_timestamp
                        };
                        mailData.oauth2Tokens = oauth2Tokens;
                    } else {
                        this.updateAccount(true);
                        return;
                    }
                } else if (authenticatorId === 'activesync') {
                    password = credential.password;
                    config = {
                        type: 'activesync',
                        incoming: {
                            username: credential.username,
                            server: credential.configInfo.server,
                            deviceId: credential.configInfo.deviceId,
                            policyKey: credential.configInfo.policyKey
                        }
                    };
                    mailData.password = password;
                    mailData.type = 'activesync';
                }
                console.log('Check and update account: ' + mailAddress);
                MailAPI.checkAndUpdateAccount(mailData, result => {
                    if (!result.bExist && action !== 'onrefreshed') {
                        if (enable && navigator.connection.type !== 'none') {
                            cards.pushCard('setup_progress', 'animate', {
                                displayName: '',
                                emailAddress: mailAddress,
                                password: password,
                                configInfo: config,
                                oauth2Tokens: oauth2Tokens,
                                authenticatorId: authenticatorId,
                                autoSetup: true,
                                callingCard: cards.getCurrentCard()
                            }, 'right');
                        } else {
                            this.continueAdd();
                        }
                        this.onAutoAdded();
                    } else {
                        if (result.bUpdate) {
                            evt.emit('accountSyncChanged', { id: result.id });
                        }
                        this.continueAdd();
                    }
                });
            }, () => {
                this.continueAdd();
            });
        },
        continueAdd: function () {
            let accountsNumber = this.accounts.length;
            if (this.index < accountsNumber) {
                if (this.index < accountsNumber - 1) {
                    this.index += 1;
                    this.updateAccount();
                } else {
                    if (this.bAdded) {
                        let cacheSoftkeyNode = document.getElementById('cachedSoftkeyPanel');
                        if (cacheSoftkeyNode) {
                            document.body.removeChild(cacheSoftkeyNode);
                        }
                        evt.emit('resetApp');
                    }
                    this.syncAccountsDone();
                }
            }
        },
        syncAccountsDone: function () {
            console.log('Sync accouns done');
            this.doSync = false;
            this.checkDeletedAccounts();
            this.onAccountsChange();
        },
        getAllAccounts: function () {
            return new Promise(function (resolve, reject) {
                let data = { action: 'getAccounts' };
                accountManagerUtils.launchActivity(data).then(result => {
                    for (let i = 0; i < result.length; i++) {
                        if (result[i].authenticatorId === 'kaiaccount') {
                            result.splice(i, 1);
                            break;
                        }
                    }
                    resolve(result);
                }, reason => {
                    reject(reason);
                });
            });
        },
        showLoginPage: function (authenticatorId, aExtraInfo) {
            return new Promise(function (resolve, reject) {
                let data = {
                    action: 'showLoginPage',
                    authenticatorId: authenticatorId,
                    extraInfo: aExtraInfo
                };
                accountManagerUtils.launchActivity(data).then(result => {
                    console.log('showLoginPage resolved: ' + JSON.stringify(result));
                    resolve(result);
                }, reason => {
                    console.log('showLoginPage rejected: ' + reason);
                    reject(reason);
                });
            });
        },
        checkDeletedAccounts: function (bRemove = false, noExecute = false) {
            MailAPI.removeDeletedAccounts(this.accountIds, bRemove, result => {
                if (result && !noExecute) {
                    evt.emit('resetApp');
                }
            });
        },
        sendAccountInfo: function (configData) {
            let account = configData.account;
            let accountId = account.name;
            let username = account.username;
            let accountType = account.type;
            let password = account.password;
            if (accountType === 'activesync') {
                let accountData = {
                    accountId: accountId,
                    username: username,
                    password: password,
                    configInfo: account.servers ? account.servers[0].connInfo : account.configInfo
                };
                console.log('Send activesync setup info to system');
                let bActive = configData.activity;
                const manifestUrl = window.AppOrigin.getManifestURL('email');
                AppsManager.getApp(manifestUrl).then(app => {
                    app.connect('emailcomms').then(ports => {
                        ports.forEach(port => {
                            if (bActive) {
                                port.postMessage(accountData);
                            }
                            port.onmessage = function (event) {
                                if (event.data === 'requireData') {
                                    port.postMessage(accountData);
                                }
                            };
                        });
                        if (!bActive) {
                            let authenticator = { authenticatorId: accountType };
                            let extraInfo = { hideSetupPage: true };
                            this.showLoginPage(authenticator, extraInfo);
                        }
                    }, reason => {
                        console.log('Email emailcomms is rejected ' + reason);
                    });
                });
            }
        },
        changePassword: function (accountId, authenticatorId, password) {
            if (authenticatorId) {
                console.log('Change password of account: ' + accountId);
                let data = {
                    action: 'refreshCredential',
                    account: {
                        accountId: accountId,
                        authenticatorId: authenticatorId
                    },
                    credential: { password: password }
                };
                accountManagerUtils.launchActivity(data).then(result => {
                    console.log('Account:' + accountId + '\'s password changed');
                }, reason => {
                    console.log('Account:' + accountId + ' change password failed');
                    reject(reason);
                });
            }
        },
        removeAccount: function (accountId, authenticatorId) {
            if (authenticatorId) {
                let account = {
                    accountId: accountId,
                    authenticatorId: authenticatorId
                };
                let data = {
                    action: 'revokeCredential',
                    account: account
                };
                accountManagerUtils.launchActivity(data).then(() => {
                    console.log('Account logout: ' + accountId);
                    this.updateAccountsList(accountId);
                }, reason => {
                    console.log('showLoginPage rejected: ' + reason);
                    console.log('Account logout failed: ' + reason);
                });
            }
        },
        onLoginPageAccountChange: function (data) {
            const {state, accountId, authenticatorId} = data;
            console.log('Accounts changed action:' + state);
            let account = {
                accountId: accountId,
                authenticatorId: authenticatorId
            };
            if (state === 0) {
                this.accountsList.push(account);
            } else if (state === 1) {
                this.updateAccountsList(accountId);
            }
            if (!document.hidden && authenticatorId === 'google') {
                return;
            }
            this.clearData();
            if (state === 2 || state === 0) {
                this.accountsList.forEach(val => {
                    this.accountIds.push(val.accountId);
                });
                this.accounts.push(account);
                const action = state === 0 ? 'onlogin' : state === 1 ? 'onlogout' : 'onrefreshed';
                this.updateAccount(false, action);
            } else if (state === 1) {
                this.accountIds.push(accountId);
                this.checkDeletedAccounts(true);
            }
        },
        onAccountsChange: function () {
            if (this.addChangedHandler) {
                return;
            }
            console.log('Add accounts change handler');
            this.addChangedHandler = true;
            this.onLoginPageAccountChange = this.onLoginPageAccountChange.bind(this);
            AccountManager.observe('activesync', this.onLoginPageAccountChange);
            AccountManager.observe('google', this.onLoginPageAccountChange);
            SettingsObserver.observe(emailSyncKey, null, values => {
                console.log('Email sync switch changed!');
                if (values) {
                    if (Object.keys(values).length === Object.keys(this.syncSwitch).length) {
                        console.log('Update accounts because sync value change!');
                        this.checkChangedAccount(values);
                    } else {
                        this.syncSwitch = values;
                    }
                }
            }, true);
        },
        clearData: function () {
            this.accountIds = [];
            this.accounts = [];
            this.index = 0;
            this.bAdded = false;
        },
        checkAccountExist: function (accountId) {
            let account = null;
            for (let i = 0; i < this.accountsList.length; i++) {
                if (this.accountsList[i].accountId.toLowerCase() === accountId.toLowerCase()) {
                    console.log('Account : ' + accountId + ' already exist in account manager DB');
                    account = this.accountsList[i];
                    break;
                }
            }
            return account;
        },
        updateAccountsList: function (accountId) {
            for (let i = 0; i < this.accountsList.length; i++) {
                if (this.accountsList[i].accountId === accountId) {
                    this.accountsList.splice(i, 1);
                    break;
                }
            }
        },
        checkChangedAccount: function (values) {
            let accountId = '';
            this.clearData();
            for (let i in values) {
                if (values.hasOwnProperty(i)) {
                    if (this.syncSwitch[i] === undefined || values[i] !== this.syncSwitch[i]) {
                        this.syncSwitch[i] = values[i];
                        accountId = i.split(':')[1];
                    }
                    this.accountIds.push(i.split(':')[1]);
                }
            }
            this.syncSwitch = values;
            this.accounts = this.accountsList.filter(val => val.accountId === accountId);
            this.updateAccount();
        },
        updateAccounts: function (bActivity = false) {
            this.getAllAccounts().then(result => {
                console.log('Account length: ' + result.length);
                this.clearData();
                this.accountsList = result;
                if (!bActivity) {
                    if (result.length > 0) {
                        this.accounts = result;
                        this.updateAccount();
                    } else {
                        this.syncAccountsDone();
                    }
                } else {
                    this.onUserAdded();
                    this.onAccountsChange();
                    if (this.accountsList.length) {
                        this.accountsList.forEach(val => {
                            this.accountIds.push(val.accountId);
                        });
                    }
                    this.checkDeletedAccounts(false, true);
                }
            });
        },
        updateSyncInfo: function (accountId, authenticatorId) {
            console.log('Update sync switch info');
            return new Promise(function (resolve, reject) {
                SettingsObserver.getValue(emailSyncKey).then(result => {
                    if (result) {
                        let syncInfo = result;
                        let syncKey = `${ authenticatorId }:${ accountId }`;
                        syncInfo[syncKey] = true;
                        return SettingsObserver.setValue([{
                                name: emailSyncKey,
                                value: syncInfo
                            }]);
                    }
                });
            });
        },
        onAutoAdded: function () {
            if (!this.autoAddedListener) {
                evt.on('autoAddDone', () => {
                    this.bAdded = true;
                    this.continueAdd();
                });
                this.autoAddedListener = true;
            }
        },
        onUserAdded: function () {
            if (!this.userAddedListener) {
                evt.on('userAddDone', configData => {
                    this.sendAccountInfo(configData);
                });
                this.userAddedListener = true;
            }
        },
        syncAccounts: function () {
            console.log('Start sync account using accountManager');
            this.doSync = true;
            SettingsObserver.getValue(emailSyncKey).then(result => {
                if (result) {
                    this.syncSwitch = result;
                }
                setTimeout(() => {
                    this.updateAccounts();
                }, DELAY_LOAD_TIME);
            });
            this.onUserAdded();
        }
    };
    return accountSync;
});
define('metrics', [
    'require',
    'evt'
], function (require) {
    let evt = require('evt'), apiDone = false, contentDone = false;
    function checkAppLoaded() {
        if (apiDone && contentDone) {
            window.performance.mark('fullyLoaded');
            window.dispatchEvent(new CustomEvent('moz-app-loaded'));
        }
    }
    evt.once('metrics:apiDone', function onApiDone() {
        apiDone = true;
        checkAppLoaded();
    });
    evt.once('metrics:contentDone', function () {
        contentDone = true;
        if (!window.startupCacheEventsSent) {
            window.performance.mark('visuallyLoaded');
            window.dispatchEvent(new CustomEvent('moz-app-visually-complete'));
            window.performance.mark('contentInteractive');
            window.dispatchEvent(new CustomEvent('moz-content-interactive'));
        }
        checkAppLoaded();
    });
});
define('wake_locks', [
    'require',
    'evt'
], function (require) {
    'use strict';
    let lockTimeouts = {}, evt = require('evt'), allLocks = {}, dataOps = {}, dataOpsTimeoutId = 0, maxLockInterval = 45000, dataOpsTimeout = 5000;
    function close() {
        dataOps = {};
        dataOpsTimeoutId = 0;
        if (document.hidden) {
            console.log('email: cronsync wake locks expired, force closing app');
            window.close();
        } else {
            console.log('email: cronsync wake locks expired, but app visible, ' + 'not force closing');
            Object.keys(allLocks).forEach(function (accountKey) {
                clearLocks(accountKey);
            });
        }
    }
    function closeIfNoDataOps() {
        let dataOpsKeys = Object.keys(dataOps);
        if (!dataOpsKeys.length) {
            return close();
        }
        console.log('email: cronsync wake lock force shutdown waiting on email ' + 'data operations: ' + dataOpsKeys.join(', '));
        dataOpsTimeoutId = setTimeout(close, dataOpsTimeout);
    }
    evt.on('uiDataOperationStart', dataId => {
        dataOps[dataId] = true;
    });
    evt.on('uiDataOperationStop', dataId => {
        delete dataOps[dataId];
        if (dataOpsTimeoutId && !Object.keys(dataOps).length) {
            clearTimeout(dataOpsTimeoutId);
            close();
        }
    });
    function clearLocks(accountKey) {
        console.log('email: clearing wake locks for "' + accountKey + '"');
        let lockTimeoutId = lockTimeouts[accountKey];
        if (lockTimeoutId) {
            clearTimeout(lockTimeoutId);
        }
        lockTimeouts[accountKey] = 0;
        let locks = allLocks[accountKey];
        allLocks[accountKey] = null;
        if (locks) {
            locks.forEach(lock => {
                lock.unlock();
            });
        }
    }
    function makeAccountKey(accountIds) {
        return 'id' + accountIds.join(' ');
    }
    function onCronStop(accountIds) {
        clearLocks(makeAccountKey(accountIds));
    }
    evt.on('cronSyncWakeLocks', (accountKey, locks) => {
        if (lockTimeouts[accountKey]) {
            clearLocks(accountKey);
        }
        allLocks[accountKey] = locks;
        lockTimeouts[accountKey] = setTimeout(closeIfNoDataOps, maxLockInterval);
    });
    evt.on('cronSyncStop', onCronStop);
});
define('account_manager_utils', ['require'], function (require) {
    const ASYMMETRIC_ALGORITHM_NAME = 'RSA-OAEP';
    const SYMMETRIC_ALGORITHM_NAME = 'AES-GCM';
    let mActivity;
    let theKeyPair = {};
    let exportedPublicKey;
    return {
        init: function () {
            if (!exportedPublicKey) {
                this.generateKey(exportedKey => {
                    exportedPublicKey = exportedKey;
                });
            }
        },
        launchActivity: function (data) {
            console.log('data.action is ' + data.action);
            if (!data.publicKey) {
                data.publicKey = exportedPublicKey;
            }
            return new Promise((resolve, reject) => {
                mActivity = new WebActivity('account-manager', data);
                mActivity.start().then(successResponse => {
                    resolve(this.unwrapKey(successResponse));
                }, error => {
                    console.log('WebActivity error: ', error);
                    reject(error);
                });
            });
        },
        generateKey: function (callback) {
            const start = +new Date();
            return window.crypto.subtle.generateKey({
                name: ASYMMETRIC_ALGORITHM_NAME,
                modulusLength: 1024,
                publicExponent: new Uint8Array([
                    1,
                    0,
                    1
                ]),
                hash: 'SHA-256'
            }, true, [
                'wrapKey',
                'unwrapKey'
            ]).then(keyPair => {
                console.log(`${ ASYMMETRIC_ALGORITHM_NAME } keyPair....: `, +new Date() - start);
                theKeyPair = keyPair;
                this.exportKey(callback);
            }).catch(err => {
                console.error('generateKey: ', err);
            });
        },
        exportKey: function (callback) {
            window.crypto.subtle.exportKey('jwk', theKeyPair.publicKey).then(exportedKey => {
                console.log('exportKey exportedKey: ', exportedKey);
                exportedPublicKey = exportedKey;
                callback(exportedKey);
            }).catch(err => {
                console.error('exportKey: ', err);
            });
        },
        unwrapKey: function (encryptedText) {
            const {encrypted, symmetricKey, iv} = encryptedText;
            return window.crypto.subtle.unwrapKey('raw', symmetricKey, theKeyPair.privateKey, {
                name: ASYMMETRIC_ALGORITHM_NAME,
                hash: { name: 'SHA-256' }
            }, {
                name: SYMMETRIC_ALGORITHM_NAME,
                length: 256
            }, false, ['decrypt']).then(key => {
                return this.decryptResponse(key, encrypted, iv);
            }).catch(err => {
                console.error('unwrapKey: ', err);
            });
        },
        decryptResponse: function (symmetricKey, encrypted, iv) {
            return new Promise(resolve => {
                const dec = new TextDecoder();
                window.crypto.subtle.decrypt({
                    name: SYMMETRIC_ALGORITHM_NAME,
                    iv
                }, symmetricKey, encrypted).then(decryptedText => {
                    const accountInfo = JSON.parse(dec.decode(decryptedText));
                    resolve(accountInfo);
                }).catch(err => {
                    console.error('decryptResponse: ', err);
                });
            });
        }
    };
});
define('mail_app', [
    'require',
    'exports',
    'module',
    'l10n!',
    'activity_composer_data',
    'cards',
    'evt',
    'model',
    'header_cursor',
    'html_cache',
    'toaster',
    'accounts_sync',
    'http://shared.localhost/js/utils/font/font_size_utils.js',
    'http://shared.localhost/js/helper/date_time/date_time_helper.js',
    'metrics',
    'wake_locks',
    'account_manager_utils'
], function (require, exports, module) {
    let mozL10n = require('l10n!'), activityComposerData = require('activity_composer_data'), cards = require('cards'), evt = require('evt'), model = require('model'), headerCursor = require('header_cursor').cursor, htmlCache = require('html_cache'), toaster = require('toaster'), accountsSync = require('accounts_sync'), waitingRawActivity, activityCallback;
    require('http://shared.localhost/js/utils/font/font_size_utils.js');
    require('http://shared.localhost/js/helper/date_time/date_time_helper.js');
    require('metrics');
    require('wake_locks');
    window.accountManagerUtils = require('account_manager_utils');
    accountManagerUtils.init();
    let started = false;
    let addActivity = false;
    function pushStartCard(id, addedArgs) {
        let args = {};
        if (addedArgs) {
            Object.keys(addedArgs).forEach(key => {
                args[key] = addedArgs[key];
            });
        }
        if (!started) {
            let cachedNode = cards._cardsNode.children[0];
            if (cachedNode && id === htmlCache.nodeToKey(cachedNode)) {
                mozL10n.translateFragment(cachedNode);
                args.cachedNode = cachedNode;
            }
            document.body.classList.add('content-visible');
        }
        cards.pushCard(id, 'immediate', args);
        started = true;
    }
    let Language = navigator.language, emailLocation = window.location;
    SettingsObserver.observe('language.current', 'en-US', value => {
        if (value && value !== Language) {
            emailLocation.reload();
        }
    }, true);
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            if (!accountsSync.doSync && !addActivity) {
                accountsSync.syncAccounts();
            }
            if (!started && startupData && startupData.entry === 'alarm') {
                pushStartCard('message_list');
            }
            NavigationMap.checkStorage();
        } else {
            addActivity = false;
            if (!accountsSync.addChangedHandler) {
                accountsSync.onAccountsChange();
            }
        }
    }, false);
    function isCurrentCardMessageList() {
        let cardType = cards.getCurrentCardType();
        return cardType && cardType === 'message_list';
    }
    evt.on('addAccount', () => {
        cards.removeAllCards();
        pushStartCard('setup_account_info', { allowBack: true });
    });
    function resetApp(pageName) {
        activityCallback = waitingRawActivity = undefined;
        cards.removeAllCards();
        model.init(false, () => {
            let noAccount = !model.checkAccounts();
            if (noAccount) {
                htmlCache.reset();
                model.checkAccounts();
            }
            let cardId = noAccount ? 'welcome_page' : pageName ? pageName : 'message_list';
            pushStartCard(cardId);
        });
    }
    evt.on('accountDeleted', account => {
        accountsSync.removeAccount(account.name, account.authenticatorId);
        resetApp('settings_main');
    });
    evt.on('resetApp', resetApp);
    evt.on('setupAccountCanceled', fromCard => {
        if (waitingRawActivity) {
            const result = {
                activityHandlerId: waitingRawActivity.activityHandlerId,
                activityResult: 'cancelled',
                isError: true
            };
            navigator.serviceWorker.controller.postMessage(result);
            window.close();
            clearInterval(window.keepSWStateInterval);
        }
        if (!model.foldersSlice) {
            evt.emit('resetApp');
        } else {
            cards.removeCardAndSuccessors(fromCard, 'delay-animate', 1);
        }
    });
    function showReEnableDialog(data) {
        let dialogConfig = {
            title: {
                id: 'confirmation-title',
                args: {}
            },
            body: {
                id: 'account-reEnable',
                args: {}
            },
            cancel: {
                l10nId: 'cancel',
                priority: 1
            },
            confirm: {
                l10nId: 'sync',
                priority: 3,
                callback: () => {
                    if (data.id) {
                        cards.removeAllCards();
                        let account = model.getAccount(data.id);
                        accountsSync.updateSyncInfo(account.name, account.authenticatorId);
                        model.changeAccount(account, () => {
                            pushStartCard('message_list');
                        });
                    } else if (data.account) {
                        accountsSync.updateSyncInfo(data.account.accountId, data.account.authenticatorId);
                    }
                }
            }
        };
        NavigationMap.showConfigDialog(dialogConfig);
    }
    evt.on('accountSyncChanged', data => {
        if (data.reEnable) {
            showReEnableDialog(data);
        } else {
            if (model.checkAccounts()) {
                let account = model.getAccount(data.id);
                let bDefault = account.isDefault;
                if (model.account.id === data.id) {
                    if (!account.syncEnable) {
                        let newAccount = model.getEnableAccount(data.id, bDefault);
                        if (bDefault) {
                            newAccount.modifyAccount({ setAsDefault: true });
                        }
                        cards.removeAllCards();
                        model.changeAccount(newAccount, () => {
                            pushStartCard('message_list');
                        });
                    } else {
                        if (!bDefault) {
                            account.modifyAccount({ setAsDefault: true });
                        }
                        cards.removeAllCards();
                        model.changeAccount(account, () => {
                            pushStartCard('message_list');
                        });
                    }
                } else {
                    if (!model.account.syncEnable && account.syncEnable) {
                        if (!bDefault) {
                            account.modifyAccount({ setAsDefault: true });
                        }
                        cards.removeAllCards();
                        model.changeAccount(account, () => {
                            pushStartCard('message_list');
                        });
                    } else {
                        if (bDefault) {
                            model.account.modifyAccount({ setAsDefault: true });
                        }
                    }
                }
            } else {
                let card = cards.getCurrentCard();
                if (card.localName !== 'cards-welcome-page') {
                    cards.removeAllCards();
                    pushStartCard('welcome_page');
                }
            }
        }
    });
    evt.on('showLatestAccount', () => {
        cards.removeAllCards();
        if (!model.checkAccounts()) {
            pushStartCard('welcome_page');
            return;
        }
        model.latestOnce('acctsSlice', acctsSlice => {
            let account = acctsSlice.items[acctsSlice.items.length - 1];
            model.changeAccount(account, () => {
                pushStartCard('message_list', {
                    onPushed: function () {
                        if (activityCallback) {
                            let activityCb = activityCallback;
                            activityCallback = null;
                            activityCb();
                            return true;
                        }
                        return false;
                    }
                });
            });
        });
    });
    let checkPassword = function (account, whichSide) {
        let checkedAccount = {
            accountId: account.username,
            authenticatorId: account.authenticatorId
        };
        let data = {
            action: 'refreshCredential',
            account: {
                accountId: account.username,
                authenticatorId: account.authenticatorId
            },
            credential: { password: account.password }
        };
        accountManagerUtils.launchActivity(data).then(() => {
            console.log('Account:' + account.username + '\'s password changed');
        }, error => {
            console.log('Account:' + account.username + ' change password failed');
            cards.pushCard('setup_fix_password', 'animate', {
                account: account,
                whichSide: whichSide,
                restoreCard: cards.activeCardIndex
            }, 'right');
        });
    };
    let waitAndCheck = function (callback) {
        let i = 0;
        let timer = setInterval(() => {
            i++;
            if (!accountsSync.doSync) {
                clearInterval(timer);
                callback();
            } else if (i === 5) {
                clearInterval(timer);
            }
        }, 1000);
    };
    evt.on('apiBadLogin', (account, problem, whichSide) => {
        switch (problem) {
        case 'bad-user-or-pass':
            if (account.type === 'activesync') {
                if (accountsSync.doSync) {
                    waitAndCheck(() => {
                        checkPassword(account, whichSide);
                    });
                } else {
                    checkPassword(account, whichSide);
                }
            } else {
                cards.pushCard('setup_fix_password', 'animate', {
                    account: account,
                    whichSide: whichSide,
                    restoreCard: cards.activeCardIndex
                }, 'right');
            }
            break;
        case 'imap-disabled':
        case 'pop3-disabled':
            cards.pushCard('setup_fix_gmail', 'animate', {
                account: account,
                restoreCard: cards.activeCardIndex
            }, 'right');
            break;
        case 'needs-app-pass':
            cards.pushCard('setup_fix_gmail_twofactor', 'animate', {
                account: account,
                restoreCard: cards.activeCardIndex
            }, 'right');
            break;
        case 'needs-oauth-reauth':
            cards.pushCard('setup_fix_oauth2', 'animate', {
                account: account,
                restoreCard: cards.activeCardIndex
            }, 'right');
            break;
        }
    });
    cards.init();
    if (!model.inited) {
        model.init();
    }
    let startupData = globalOnAppMessage({
        activity: function (rawActivity) {
            if (!isCurrentCardMessageList() && rawActivity.source.data.owner !== 'email') {
                cards.removeAllCards();
            }
            function activityCompose() {
                let cardArgs = {
                    activity: rawActivity,
                    composerData: activityComposerData(rawActivity)
                };
                pushStartCard('compose', cardArgs);
            }
            if (rawActivity.source.name === 'setup') {
                pushStartCard('setup_manual_config', {
                    displayName: '',
                    emailAddress: '',
                    activity: rawActivity
                });
                addActivity = true;
                accountsSync.updateAccounts(true);
            } else if (globalOnAppMessage.hasAccount()) {
                activityCompose();
            } else {
                activityCallback = activityCompose;
                waitingRawActivity = rawActivity;
                pushStartCard('setup_account_info', {
                    allowBack: true,
                    launchedFromActivity: true
                });
            }
        },
        notification: function (data) {
            data = data || {};
            let type = data.type || '';
            let folderType = data.folderType || 'inbox';
            model.latestOnce('foldersSlice', () => {
                function onCorrectFolder() {
                    if (!isCurrentCardMessageList()) {
                        cards.removeAllCards();
                    }
                    if (type === 'message_list') {
                        cards.removeAllCards();
                        pushStartCard('message_list', {});
                    } else if (type === 'message_reader') {
                        headerCursor.setCurrentMessageBySuid(data.messageSuid);
                        window.performance.mark('mail-load-start');
                        pushStartCard(type, { messageSuid: data.messageSuid });
                    } else {
                        console.error('unhandled notification type: ' + type);
                    }
                }
                let acctsSlice = model.acctsSlice, accountId = data.accountId;
                if (model.account.id === accountId) {
                    return model.selectFirstFolderWithType(folderType, onCorrectFolder);
                } else {
                    let newAccount;
                    acctsSlice.items.some(account => {
                        if (account.id === accountId) {
                            newAccount = account;
                            return true;
                        }
                    });
                    if (newAccount) {
                        model.changeAccount(newAccount, () => {
                            model.selectFirstFolderWithType(folderType, onCorrectFolder);
                        });
                    }
                }
            });
        }
    });
    console.log('startupData: ' + JSON.stringify(startupData, null, '  '));
    if (startupData.entry === 'default' || startupData.entry === 'alarm' && !document.hidden) {
        pushStartCard(startupData.view);
        if (navigator.connection.type === 'none') {
            toaster.toast({ text: mozL10n.get('no-internet-connection') });
        }
        accountsSync.syncAccounts();
        NavigationMap.checkStorage();
    }
});
if (typeof TestUrlResolver === 'undefined') {
    requirejs.config({
        waitSeconds: 0,
        baseUrl: 'js',
        paths: {
            l10nbase: 'http://shared.localhost/js/utils/l10n/l10n',
            l10ndate: 'http://shared.localhost/js/utils/l10n/l10n_date',
            style: '../style',
            shared: '../shared'
        },
        map: { '*': { 'api': 'ext/main-frame-setup' } },
        shim: {
            l10ndate: ['l10nbase'],
            'http://shared.localhost/js/utils/common/mime_mapper.js': { exports: 'MimeMapper' },
            'http://shared.localhost/js/helper/notification/notification_helper.js': { exports: 'NotificationHelper' },
            'http://shared.localhost/js/helper/accessibility/accessibility_helper.js': { exports: 'AccessibilityHelper' }
        },
        config: {
            template: {
                tagToId: function (tag) {
                    return tag.replace(/^cards-/, 'cards/').replace(/-/g, '_');
                }
            }
        },
        definePrim: 'prim'
    });
}
if (navigator.b2g.audioChannelManager) {
    navigator.b2g.audioChannelManager.volumeControlChannel = 'notification';
}
if (window.startupOnModelLoaded) {
    requirejs([
        'console_hook',
        'model'
    ], (hook, model) => {
        model.init();
        window.startupOnModelLoaded(model, () => {
            require(['mail_app']);
        });
    });
} else {
    requirejs([
        'console_hook',
        'mail_app'
    ]);
}
;
define('config', function () {
});
define('text', {
    load: function (name, req, onload, config) {
        let url = req.toUrl(name), xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.onreadystatechange = evt => {
            let status, err;
            if (xhr.readyState === 4) {
                status = xhr.status;
                if (status > 399 && status < 600) {
                    err = new Error(url + ' HTTP status: ' + status);
                    err.xhr = xhr;
                    onload.error(err);
                } else {
                    onload(xhr.responseText);
                }
            }
        };
        xhr.responseType = 'text';
        xhr.send(null);
    }
});
define('folder_depth_classes', [], function () {
    return [
        'fld-folder-depth0',
        'fld-folder-depth1',
        'fld-folder-depth2',
        'fld-folder-depth3',
        'fld-folder-depth4',
        'fld-folder-depth5',
        'fld-folder-depthmax'
    ];
});
define('tmpl!cards/value_selector.html', ['tmpl'], function (tmpl) {
    return tmpl.toDom('<form class="email-value-selector collapsed" role="dialog" data-type="value-selector">\n  <section class="scrollable">\n    <h1></h1>\n    <ol class="valueSelector_single" role="listbox">\n    </ol>\n  </section>\n</form>\n');
});
define('tmpl!cards/vsl/item.html', ['tmpl'], function (tmpl) {
    return tmpl.toDom('<li role="option"><label role="presentation"> <span class="p-pri"></span></label></li>');
});
define('value_selector', [
    'require',
    'l10n!',
    'cards',
    'folder_depth_classes',
    'tmpl!cards/value_selector.html',
    'tmpl!cards/vsl/item.html'
], function (require) {
    'use strict';
    let mozL10n = require('l10n!'), cards = require('cards'), FOLDER_DEPTH_CLASSES = require('folder_depth_classes'), formNode = require('tmpl!cards/value_selector.html'), itemTemplateNode = require('tmpl!cards/vsl/item.html');
    function noop() {
    }
    function ValueSelector(titleId, list, actions) {
        let init, show, hide, render, setTitle, emptyList, addToList, data, getFocusedItem, getSelectedItem;
        let backup = {};
        function handleKeydown(evt) {
            switch (evt.key) {
            case 'ArrowLeft':
            case 'ArrowRight':
                evt.preventDefault();
                evt.stopPropagation();
                break;
            case 'Backspace':
                evt.preventDefault();
                hide();
                evt.stopPropagation();
                break;
            }
        }
        init = function () {
            data = {
                title: 'No Title',
                list: [{
                        label: 'Dummy element',
                        callback: function () {
                            alert('Define an action here!');
                        }
                    }]
            };
            document.body.appendChild(formNode);
            emptyList();
            if (typeof titleId === 'string') {
                setTitle(mozL10n.get(titleId));
            }
            if (Array.isArray(list)) {
                data.list = list;
            }
        };
        show = function (onFocusChanged) {
            let delayTime = 0;
            if (actions) {
                if (window.option) {
                    backup.actions = window.option.actions;
                    delayTime = 200;
                }
                NavigationMap.setSoftKeyBar(actions);
            }
            if (typeof onFocusChanged === 'function') {
                formNode.onFocusChanged = onFocusChanged;
            } else {
                formNode.onFocusChanged = undefined;
            }
            render();
            formNode.classList.remove('collapsed');
            formNode.classList.toggle('move-to-folder', titleId === 'messages-folder-select');
            formNode.classList.toggle('sort-by', titleId === 'sort-by-title');
            const QUERY_PARENT = '.email-value-selector';
            const QUERY_CHILD = '[role="option"]';
            const CONTROL_ID = QUERY_PARENT + ' ' + QUERY_CHILD;
            NavigationMap.navSetup(QUERY_PARENT, QUERY_CHILD);
            backup.controlID = NavigationMap.setCurrentControl(CONTROL_ID);
            setTimeout(() => {
                NavigationMap.setFocus('first');
            }, delayTime);
            formNode.addEventListener('keydown', handleKeydown);
        };
        hide = function () {
            formNode.classList.add('collapsed');
            NavigationMap.setCurrentControl(backup.controlID);
            if (backup.controlID === 'cards-message-list .msg-header-item:not([data-index="-1"])') {
                let messageId = NavigationMap.currentMessageId;
                NavigationMap.setMessageListFocus(messageId, false);
            } else {
                NavigationMap.setFocus('restore');
            }
            if (backup.actions) {
                NavigationMap.setSoftKeyBar(backup.actions);
            }
            formNode.removeEventListener('keydown', handleKeydown);
        };
        render = function () {
            let title = formNode.querySelector('h1'), list = formNode.querySelector('ol');
            title.textContent = data.title;
            list.innerHTML = '';
            data.list.forEach(listItem => {
                let node = itemTemplateNode.cloneNode(true);
                node.querySelector('span').textContent = listItem.label;
                let depthIdx = listItem.depth;
                depthIdx = Math.min(FOLDER_DEPTH_CLASSES.length - 1, depthIdx);
                node.classList.add(FOLDER_DEPTH_CLASSES[depthIdx]);
                node.classList.add('list-item');
                let callback = listItem.selectable ? listItem.callback : noop;
                node.addEventListener('click', callback, false);
                if (listItem.selected) {
                    node.setAttribute('aria-selected', true);
                }
                node.data = listItem;
                list.appendChild(node);
            });
        };
        setTitle = function (str) {
            data.title = str;
        };
        emptyList = function () {
            data.list = [];
        };
        addToList = function (label, depth, selectable, callback, selected, source) {
            data.list.push({
                label: label,
                depth: depth,
                selectable: selectable,
                callback: callback,
                selected: selected,
                source: source
            });
        };
        getFocusedItem = function () {
            let node = formNode.querySelector('.focus');
            return node.data;
        };
        getSelectedItem = function () {
            let items = [];
            data.list.forEach(item => {
                if (item.selected) {
                    items.push(item);
                }
            });
            return items;
        };
        init();
        return {
            init: init,
            show: show,
            hide: hide,
            setTitle: setTitle,
            addToList: addToList,
            List: list,
            getFocusedItem: getFocusedItem,
            getSelectedItem: getSelectedItem
        };
    }
    return ValueSelector;
});
define('iframe_shims', [], function () {
    let DEFAULT_STYLE_TAG = '<style type="text/css">\n' + 'blockquote {' + 'margin: 0; ' + '-moz-border-start: 0.2rem solid gray;' + 'padding: 0; -moz-padding-start: 0.5rem; ' + '}\n' + 'html, body { max-width: 120rem; word-wrap: break-word;' + ' overflow: hidden; padding: 0; margin: 0; }\n' + 'pre { white-space: pre-wrap; word-wrap: break-word; }\n' + '.moz-external-link { color: #00aac5; cursor: pointer; }\n' + '.focus { border: 0.2rem solid var(--highlight-color, #ff4f1a); }\n' + '</style>';
    let iframeShimsOpts = {
        zoomDelayMS: 200,
        initialScale: null,
        resizeLimit: 4,
        initialResizePollIntervalMS: 200,
        noResizePollIntervalMS: 250,
        didResizePollIntervalMS: 300,
        pictureDelayPollIntervalMS: 200
    };
    let iframe = null;
    function createAndInsertIframeForContent(htmlStr, scrollContainer, parentNode, beforeNode, interactiveMode, clickHandler, callback) {
        let scrollPad = 0;
        const aPercent = 0.98;
        let viewportWidth = parentNode.offsetWidth - scrollPad;
        let viewport = document.createElement('div');
        viewport.setAttribute('style', 'padding: 0; border-width: 0; margin: 0; ' + 'overflow: hidden;');
        viewport.style.width = viewportWidth + 'px';
        if (!iframe || parentNode.classList.contains('cmp-body-html')) {
            iframe = document.createElement('iframe');
            iframe.setAttribute('sandbox', 'allow-same-origin');
            iframe.setAttribute('style', 'padding: 0; border-width: 0; margin: 0; ' + 'overflow: hidden; ' + 'transform-origin: top ' + (document.documentElement.dir === 'rtl' ? 'right' : 'left') + '; ' + 'pointer-events: none;');
        }
        if (iframeShimsOpts.tapTransform) {
            iframe.style.transform = 'scale(1)';
        }
        iframe.style.width = viewportWidth + 'px';
        viewport.appendChild(iframe);
        parentNode.insertBefore(viewport, beforeNode);
        iframe.contentDocument.open();
        iframe.contentDocument.write('<!doctype html><html><head>');
        iframe.contentDocument.write(DEFAULT_STYLE_TAG);
        iframe.contentDocument.write('</head><body>');
        iframe.contentDocument.write(htmlStr);
        iframe.contentDocument.write('</body>');
        iframe.contentDocument.close();
        let iframeBody = iframe.contentDocument.body;
        let scrollWidth = iframeBody.scrollWidth;
        let scrollHeight = iframeBody.scrollHeight;
        let baseScale = Math.min(1, viewportWidth / scrollWidth), lastRequestedScale = iframeShimsOpts.initialScale || baseScale, scale = lastRequestedScale, lastDoubleTapScale = scale, scaleMode = 0;
        viewport.style.width = Math.ceil(scrollWidth * scale) + 'px';
        viewport.style.height = Math.ceil(scrollHeight * scale) + 'px';
        iframe.style.width = scrollWidth + 'px';
        let resizeFrame = function (why) {
            if (why === 'initial' || why === 'poll') {
                scrollWidth = iframeBody.scrollWidth;
                scrollHeight = iframeBody.scrollHeight;
                let oldBaseScale = baseScale;
                baseScale = Math.min(1, viewportWidth / scrollWidth);
                if (scale === oldBaseScale) {
                    scale = baseScale;
                }
                iframe.style.width = scrollWidth + 'px';
                console.log('iframe_shims: recalculating height / width because', why, 'sw', scrollWidth, 'sh', scrollHeight, 'bs', baseScale);
            }
            iframe.style.transform = 'scale(' + scale * aPercent + ')';
            iframe.style.height = scrollHeight * Math.max(1, scale) + scrollPad + 'px';
            viewport.style.width = Math.ceil(scrollWidth * scale) + 'px';
            viewport.style.height = Math.ceil(scrollHeight * scale) + scrollPad + 'px';
        };
        resizeFrame('initial');
        let activeZoom = false, lastCenterX, lastCenterY;
        let zoomFrame = function (newScale, centerX, centerY) {
            if (newScale === scale) {
                return;
            }
            lastRequestedScale = newScale;
            lastCenterX = centerX;
            lastCenterY = centerY;
            if (activeZoom) {
                return;
            }
            activeZoom = true;
            let iframeScrolledTop = scrollContainer.scrollTop - extraHeight, iframeScrolledLeft = scrollContainer.scrollLeft;
            let ix = centerX + iframeScrolledLeft, iy = centerY + iframeScrolledTop;
            let scaleDelta = newScale / scale;
            let vertScrollDelta = Math.ceil(iy * scaleDelta), horizScrollDelta = Math.ceil(ix * scaleDelta);
            scale = newScale;
            resizeFrame('zoom');
            scrollContainer.scrollTop = vertScrollDelta + extraHeight - centerY;
            scrollContainer.scrollLeft = horizScrollDelta - centerX;
            window.setTimeout(clearActiveZoom, iframeShimsOpts.zoomDelayMS);
        };
        let clearActiveZoom = function () {
            activeZoom = false;
            if (scale !== lastRequestedScale) {
                window.requestAnimationFrame(function () {
                    console.log('delayed zoomFrame timeout, probably causing a mem-spike');
                    zoomFrame(lastRequestedScale, lastCenterX, lastCenterY);
                });
            }
        };
        let resizePollerTimeout = null;
        let resizePollCount = 0;
        let pollResize = function () {
            let opts = iframeShimsOpts;
            let desiredScrollWidth = iframeBody.scrollWidth;
            let desiredScrollHeight = iframeBody.scrollHeight;
            let resized = false;
            if (desiredScrollWidth > scrollWidth || desiredScrollHeight > scrollHeight) {
                resizeFrame('poll');
                resized = true;
            }
            if (++resizePollCount < opts.resizeLimit) {
                resizePollerTimeout = window.setTimeout(pollResize, resized ? opts.didResizePollIntervalMS : opts.noResizePollIntervalMS);
            } else {
                resizePollerTimeout = null;
                if (callback) {
                    callback(scale * aPercent);
                }
            }
        };
        resizePollerTimeout = window.setTimeout(pollResize, iframeShimsOpts.initialResizePollIntervalMS);
        let iframeShims = {
            scale: scale,
            iframe: iframe,
            resizeHandler: function () {
                resizePollCount = 0;
                if (resizePollerTimeout) {
                    window.clearTimeout(resizePollerTimeout);
                }
                resizePollerTimeout = window.setTimeout(pollResize, iframeShimsOpts.pictureDelayPollIntervalMS);
            }
        };
        if (interactiveMode !== 'interactive') {
            return iframeShims;
        }
        let title = document.getElementsByClassName('msg-reader-header')[0];
        let header = document.getElementsByClassName('msg-envelope-bar')[0];
        let extraHeight = title.clientHeight + header.clientHeight;
        return iframeShims;
    }
    function bindSanitizedClickHandler(target, clickHandler, topNode, iframe) {
        let eventType, node;
        let root, title, header, attachmentsContainer, msgBodyContainer, titleHeight, headerHeight, attachmentsHeight, msgBodyMarginTop, msgBodyMarginLeft, attachmentsMarginTop, iframeDoc, inputStyle, loadBar, loadBarHeight;
        if (iframe) {
            root = document.getElementsByClassName('scrollregion-horizontal-too')[0];
            title = document.getElementsByClassName('msg-reader-header')[0];
            header = document.getElementsByClassName('msg-envelope-bar')[0];
            attachmentsContainer = document.getElementsByClassName('msg-attachments-container')[0];
            loadBar = document.getElementsByClassName('msg-reader-load-infobar')[0];
            msgBodyContainer = document.getElementsByClassName('msg-body-container')[0];
            inputStyle = window.getComputedStyle(msgBodyContainer);
            msgBodyMarginTop = parseInt(inputStyle.marginTop);
            msgBodyMarginLeft = parseInt(inputStyle.marginLeft);
            titleHeight = title.clientHeight;
            headerHeight = header.clientHeight;
            eventType = 'tap';
            iframeDoc = iframe.contentDocument;
        } else {
            eventType = 'click';
        }
        target.addEventListener(eventType, function clicked(event) {
            if (iframe) {
                loadBarHeight = loadBar.clientHeight;
                attachmentsHeight = attachmentsContainer.clientHeight;
                inputStyle = window.getComputedStyle(attachmentsContainer);
                attachmentsMarginTop = attachmentsHeight ? parseInt(inputStyle.marginTop) : 0;
                let dx, dy;
                let transform = iframe.style.transform || 'scale(1)';
                let scale = transform.match(/(\d|\.)+/g)[0];
                if (document.dir === 'rtl') {
                    dx = event.detail.clientX - msgBodyMarginLeft + root.scrollWidth + root.scrollLeft - root.clientWidth;
                } else {
                    dx = event.detail.clientX + root.scrollLeft - msgBodyMarginLeft;
                }
                dy = event.detail.clientY + root.scrollTop - titleHeight - headerHeight - loadBarHeight - attachmentsHeight - attachmentsMarginTop - msgBodyMarginTop;
                node = iframeDoc.elementFromPoint(dx / scale, dy / scale);
            } else {
                node = event.originalTarget;
            }
            while (node !== topNode) {
                if (node.nodeName === 'A') {
                    if (node.hasAttribute('ext-href')) {
                        if (clickHandler) {
                            clickHandler(event, node, node.getAttribute('ext-href'), node.textContent);
                        }
                        event.preventDefault();
                        event.stopPropagation();
                        return;
                    }
                }
                node = node.parentNode;
            }
        });
    }
    return {
        createAndInsertIframeForContent: createAndInsertIframeForContent,
        bindSanitizedClickHandler: bindSanitizedClickHandler,
        iframeShimsOpts: iframeShimsOpts
    };
});
define('cards/editor_mixins', ['require'], function (require) {
    return {
        _bindEditor: function (textNode) {
            this._editorNode = textNode;
        },
        populateEditor: function (value) {
            let lines = value.split('\n');
            let frag = document.createDocumentFragment();
            for (let i = 0, len = lines.length; i < len; i++) {
                if (i) {
                    frag.appendChild(document.createElement('br'));
                }
                if (lines[i]) {
                    frag.appendChild(document.createTextNode(lines[i]));
                }
            }
            if (!frag.childNodes.length) {
                frag.appendChild(document.createTextNode(''));
            }
            this._editorNode.appendChild(frag);
        },
        fromEditor: function (value) {
            let content = '';
            let len = this._editorNode.childNodes.length;
            for (let i = 0; i < len; i++) {
                let node = this._editorNode.childNodes[i];
                if (node.nodeName === 'BR' && node.getAttribute('type') !== '_moz') {
                    content += '\n';
                } else {
                    content += node.textContent;
                }
            }
            return content;
        }
    };
});
define('tmpl!cards/msg/header_item.html', ['tmpl'], function (tmpl) {
    return tmpl.toDom('<a class="msg-header-item" role="option" tabindex="0">\n  <label class="pack-checkbox negative" aria-hidden="true">\n    <input type="checkbox"><span></span>\n  </label>\n  <div class="msg-header-details-section">\n    <span dir="auto" class="msg-header-author p-pri"></span>\n    <span dir="auto" class="msg-header-subject p-sec"></span>\n    <span dir="auto" class="msg-header-date p-thi"></span>\n    <span dir="auto" class="msg-header-snippet p-thi"></span>\n  </div>\n  <div class="msg-header-syncing-section"></div>\n  <div class="msg-header-flags-section">\n    <div class="msg-header-unread-section"\n       data-l10n-id="message-header-unread"></div>\n    <div class="msg-header-reply-section"\n       data-l10n-id="message-header-reply"></div>\n    <div class="msg-header-forward-section"\n       data-l10n-id="message-header-forward"></div>\n  </div>\n  <div class="msg-header-icons-section">\n    <span class="msg-header-attachments"\n          data-l10n-id="message-header-attachments"></span>\n    <span class="msg-header-star" data-l10n-id="message-header-starred"></span>\n  </div><div class="msg-header-avatar-section" aria-hidden="true">\n  </div></a>\n');
});
define('date', [
    'require',
    'l10n!'
], function (require) {
    let mozL10n = require('l10n!');
    let _ = mozL10n.get;
    let date = {
        showDateTime: function (time) {
            let dateFormat = new Date(time);
            let options = {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit',
                hour12: window.api.hour12
            };
            return dateFormat.toLocaleString(navigator.language, options);
        },
        prettyDate: function (time, useCompactFormat, syncTime) {
            let maxDiff = 86400;
            switch (time.constructor) {
            case String:
                time = parseInt(time);
                break;
            case Date:
                time = time.getTime();
                break;
            }
            let start;
            if (syncTime) {
                start = Date.now();
                maxDiff *= 7;
            } else {
                start = new Date(new Date().toLocaleDateString()).getTime();
            }
            let secDiff = (start - time) / 1000;
            if (isNaN(secDiff)) {
                return _('incorrectDate');
            }
            if (Math.abs(secDiff) > 60) {
                secDiff = secDiff > 0 ? Math.ceil(secDiff) : Math.floor(secDiff);
            }
            if (syncTime) {
                return this.dateL10nFormat(time, secDiff, maxDiff, useCompactFormat);
            }
            let options;
            if (Math.abs(secDiff) > maxDiff) {
                options = {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit'
                };
            } else if (secDiff > 0) {
                return _('days-ago-long', { value: 1 });
            } else {
                options = {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: window.api.hour12
                };
            }
            let dateFormat = new Date(time);
            return dateFormat.toLocaleString(navigator.language, options);
        },
        dateL10nFormat: function (time, secDiff, maxDiff, useCompactFormat) {
            let dateFormat = new mozL10n.DateTimeFormat();
            if (secDiff > maxDiff) {
                return dateFormat.localeFormat(new Date(time), '%x');
            }
            let f = useCompactFormat ? '-short' : '-long';
            let parts = dateFormat.relativeParts(secDiff);
            let affix = secDiff >= 0 ? '-ago' : '-until';
            for (let i in parts) {
                return _(i + affix + f, { value: parts[i] });
            }
        },
        setPrettyNodeDate: function (node, timestamp) {
            if (timestamp) {
                node.dataset.time = timestamp.valueOf();
                node.dataset.compactFormat = true;
                node.dataset.l10nFormat = true;
                node.textContent = date.prettyDate(timestamp, true, true);
            } else {
                node.textContent = '';
                node.removeAttribute('data-time');
            }
        }
    };
    return date;
});
define('vscroll', [
    'require',
    'exports',
    'module',
    'evt'
], function (require, exports, module) {
    let evt = require('evt'), slice = Array.prototype.slice, useTransform = false;
    function setTop(node, value) {
        if (useTransform) {
            node.style.transform = 'translateY(' + value + 'px)';
        } else {
            node.style.top = value + 'px';
        }
    }
    function VScroll(container, scrollingContainer, template, defaultData) {
        evt.Emitter.call(this);
        this.container = container;
        this.scrollingContainer = scrollingContainer;
        this.template = template;
        this.defaultData = defaultData;
        this._inited = false;
        this._initing = false;
        this._capturedScreenMetrics = false;
        this.firstRenderedIndex = 0;
        this._limited = false;
        this.nodes = [];
        this.nodesDataIndices = {};
        this.nodesIndex = -1;
        this.scrollTop = 0;
        this.visibleOffset = 0;
        this.oldListSize = 0;
        this._lastEventTime = 0;
        this.listNodeCount = 0;
        this.onEvent = this.onEvent.bind(this);
        this.onChange = this.onChange.bind(this);
        this._scrollTimeoutPoll = this._scrollTimeoutPoll.bind(this);
    }
    VScroll.nodeClassName = 'vscroll-node';
    VScroll.trimMessagesForCache = function (container, itemLimit) {
        let nodes = slice.call(container.querySelectorAll('.' + VScroll.nodeClassName));
        nodes.forEach(node => {
            let index = parseInt(node.dataset.index, 10);
            delete node.dataset.index;
            if (index > itemLimit - 1) {
                container.removeChild(node);
            }
        });
    };
    VScroll.prototype = {
        eventRateLimitMillis: 0,
        itemsPerScreen: undefined,
        prerenderScreens: 3,
        prefetchScreens: 2,
        retainExtraRenderedScreens: 3,
        recalculatePaddingScreens: 1.5,
        lastScrollTopSetTime: 0,
        prerenderItemCount: undefined,
        prefetchItemCount: undefined,
        recalculatePaddingItemCount: undefined,
        itemDefaultDataClass: 'default-data',
        prepareData: function (highAbsoluteIndex) {
        },
        bindData: function (model, node) {
        },
        setListNodeCount: function (count) {
            this.listNodeCount = count;
        },
        setData: function (list) {
            this.list = list;
            if (this._inited) {
                if (!this.waitingForRecalculate) {
                    this._recalculate(0);
                }
                this.emit('dataChanged');
            } else {
                this._init();
                this.renderCurrentPosition();
            }
        },
        updateDataBind: function (index, dataList, removedCount) {
            if (!this._inited) {
                return;
            }
            if (this.oldListSize !== this.list.size() || removedCount) {
                if (!this.waitingForRecalculate) {
                    this.waitingForRecalculate = true;
                    this.once('scrollStopped', () => {
                        this._recalculate(index);
                    });
                }
                return;
            }
            for (let i = 0; i < dataList.length; i++) {
                let absoluteIndex = index + i;
                let node = this._getNodeFromDataIndex(absoluteIndex);
                if (node) {
                    this.bindData(dataList[i], node);
                }
            }
        },
        onEvent: function () {
            this._lastEventTime = Date.now();
            if (!this.eventRateLimitMillis) {
                this.onChange();
                return;
            }
            if (this._limited) {
                return;
            }
            this._limited = true;
            setTimeout(this.onChange, this.eventRateLimitMillis);
        },
        onChange: function () {
            this._limited = false;
            if (!this._inited) {
                return;
            }
            if (this.lastScrollTopSetTime) {
                if (this.lastScrollTopSetTime + 1000 < Date.now()) {
                    this.lastScrollTopSetTime = 0;
                }
            }
            let startIndex, endIndex, scrollTop = this.scrollingContainer.scrollTop, scrollingDown = scrollTop >= this.scrollTop;
            this.scrollTop = scrollTop;
            let visibleRange = this.getVisibleIndexRange();
            if (scrollingDown) {
                startIndex = visibleRange[0];
                endIndex = visibleRange[1] + this.prerenderItemCount;
                this.prepareData(endIndex + this.prefetchItemCount);
            } else {
                startIndex = visibleRange[0] - this.prerenderItemCount;
                endIndex = visibleRange[1];
            }
            this._render(startIndex, endIndex);
            this._startScrollStopPolling();
        },
        nowVisible: function () {
            if (!this._inited && this.list) {
                this._init();
                this.onChange();
            }
        },
        renderCurrentPosition: function () {
            if (!this._inited) {
                return;
            }
            this.scrollTop = this.scrollingContainer.scrollTop;
            let visibleRange = this.getVisibleIndexRange();
            let startIndex = visibleRange[0] - this.recalculatePaddingItemCount;
            let endIndex = visibleRange[1] + this.recalculatePaddingItemCount;
            this._render(startIndex, endIndex);
            this.prepareData(endIndex);
        },
        indexAtScrollPosition: function (position) {
            let top = position - this.visibleOffset;
            if (top < 0) {
                top = 0;
            }
            return this.itemHeight ? Math.floor(top / this.itemHeight) : 0;
        },
        getVisibleIndexRange: function () {
            if (this.itemHeight === undefined) {
                return undefined;
            }
            let top = this.scrollTop;
            return [
                this.indexAtScrollPosition(top),
                this.indexAtScrollPosition(top + this.innerHeight)
            ];
        },
        jumpToIndex: function (index) {
            this._setContainerScrollTop(index * this.itemHeight + this.visibleOffset);
        },
        clearDisplay: function () {
            this.container.innerHTML = '';
            this.container.style.height = '0px';
            this.oldListSize = 0;
        },
        destroy: function () {
            this.scrollingContainer.removeEventListener('scroll', this.onEvent);
            if (this._scrollTimeoutPoll) {
                clearTimeout(this._scrollTimeoutPoll);
                this._scrollTimeoutPoll = 0;
            }
        },
        _setContainerScrollTop: function (value) {
            this.scrollingContainer.scrollTop = value;
            this.lastScrollTopSetTime = Date.now();
        },
        _render: function (startIndex, endIndex) {
            let i, listSize = this.list.size();
            if (startIndex < 0) {
                startIndex = 0;
            }
            if (endIndex >= listSize) {
                endIndex = listSize - 1;
            }
            this.firstRenderedIndex = startIndex;
            if (!this._inited) {
                this._init();
            }
            for (i = startIndex; i <= endIndex; i++) {
                if (this._getNodeFromDataIndex(i)) {
                    continue;
                }
                let node = this._nextAvailableNode(startIndex, endIndex), data = this.list(i);
                if (!data) {
                    data = this.defaultData;
                }
                if (node.parentNode) {
                    node.parentNode.removeChild(node);
                }
                setTop(node, i * this.itemHeight);
                this._setNodeDataIndex(this.nodesIndex, i);
                this.bindData(data, node);
                this.container.appendChild(node);
            }
        },
        _setNodeDataIndex: function (nodesIndex, dataIndex) {
            let oldDataIndex = this.nodes[nodesIndex].vScrollDataIndex;
            if (oldDataIndex > -1) {
                this.nodesDataIndices[oldDataIndex] = -1;
            }
            let node = this.nodes[nodesIndex];
            node.vScrollDataIndex = dataIndex;
            node.dataset.index = dataIndex;
            this.nodesDataIndices[dataIndex] = nodesIndex;
        },
        _getNodeFromDataIndex: function (dataIndex) {
            let index = this.nodesDataIndices[dataIndex];
            if (index === undefined) {
                index = -1;
            }
            return index === -1 ? null : this.nodes[index];
        },
        captureScreenMetrics: function () {
            if (this._capturedScreenMetrics) {
                return;
            }
            this.innerHeight = this.scrollingContainer.getBoundingClientRect().height;
            if (this.innerHeight > 0) {
                this._capturedScreenMetrics = true;
            }
        },
        _init: function () {
            if (this._inited || this._initing) {
                return;
            }
            this._initing = true;
            this.container.innerHTML = '';
            let node = this.template.cloneNode(true);
            this.container.appendChild(node);
            this.itemHeight = node.clientHeight;
            this.container.removeChild(node);
            this.captureScreenMetrics();
            if (!this.itemHeight || !this.innerHeight) {
                this._initing = false;
                return;
            }
            this.scrollingContainer.addEventListener('scroll', this.onEvent);
            this.itemsPerScreen = Math.ceil(this.innerHeight / this.itemHeight);
            this.prerenderItemCount = Math.ceil(this.itemsPerScreen * this.prerenderScreens);
            this.prefetchItemCount = Math.ceil(this.itemsPerScreen * this.prefetchScreens);
            this.recalculatePaddingItemCount = Math.ceil(this.itemsPerScreen * this.recalculatePaddingScreens);
            this.nodeCount = this.itemsPerScreen + this.prerenderItemCount + Math.ceil(this.retainExtraRenderedScreens * this.itemsPerScreen);
            if (this.listNodeCount > this.nodeCount) {
                this.nodeCount = this.listNodeCount;
            }
            for (let i = 0; i < this.nodeCount; i++) {
                node = this.template.cloneNode(true);
                node.classList.add(VScroll.nodeClassName);
                setTop(node, -1 * this.itemHeight);
                this.nodes.push(node);
                this._setNodeDataIndex(i, -1);
            }
            this._calculateTotalHeight();
            this._inited = true;
            this._initing = false;
            this.emit('inited');
        },
        _nextAvailableNode: function (beginIndex, endIndex) {
            let i, node, vScrollDataIndex, count = 0;
            for (i = this.nodesIndex + 1; count < this.nodes.length; count++, i++) {
                if (i > this.nodes.length - 1) {
                    i = 0;
                }
                node = this.nodes[i];
                vScrollDataIndex = node.vScrollDataIndex;
                if (vScrollDataIndex < beginIndex || vScrollDataIndex > endIndex) {
                    this.nodesIndex = i;
                    break;
                }
            }
            return node;
        },
        _recalculate: function (refIndex) {
            if (!this._inited) {
                return;
            }
            let node, index = this.indexAtScrollPosition(this.scrollTop), remainder = this.scrollTop % this.itemHeight, sizeDiff = this.list.size() - this.oldListSize;
            if (refIndex && refIndex < index && sizeDiff > 0 && this.oldListSize !== 0 && index !== 0) {
                index += sizeDiff;
            }
            console.log('VSCROLL scrollTop: ' + this.scrollTop + ', RECALCULATE: ' + index + ', ' + remainder);
            this._calculateTotalHeight();
            for (let i = 0; i < this.nodeCount; i++) {
                node = this.nodes[i];
                setTop(node, -1 * this.itemHeight);
                this._setNodeDataIndex(i, -1);
            }
            this.waitingForRecalculate = false;
            this._setContainerScrollTop(this.itemHeight * index + remainder);
            this.renderCurrentPosition();
            this.emit('recalculated', index === 0, refIndex);
        },
        _calculateTotalHeight: function () {
            let newListSize = this.list.size();
            if (this.oldListSize !== newListSize || parseInt(this.container.style.height, 10) === 0) {
                let softkeyHeight = document.getElementById('softkeyPanel').clientHeight;
                this.totalHeight = this.itemHeight * newListSize;
                this.container.style.height = this.totalHeight + softkeyHeight + 'px';
                this.oldListSize = newListSize;
            }
        },
        _scrollTimeoutPoll: function () {
            this._scrollStopTimeout = 0;
            if (Date.now() > this._lastEventTime + 30) {
                this.emit('scrollStopped');
            } else {
                this._scrollStopTimeout = setTimeout(this._scrollTimeoutPoll, 30);
            }
        },
        _startScrollStopPolling: function () {
            if (!this._scrollStopTimeout) {
                this._scrollStopTimeout = setTimeout(this._scrollTimeoutPoll, 30);
            }
        }
    };
    evt.mix(VScroll.prototype);
    let originalOn = VScroll.prototype.on;
    VScroll.prototype.on = function (id, fn) {
        if (id === 'scrollStopped') {
            this._startScrollStopPolling();
        }
        return originalOn.apply(this, slice.call(arguments));
    };
    return VScroll;
});
define('message_display', [
    'require',
    'l10n!'
], function (require) {
    let mozL10n = require('l10n!');
    return {
        subject: function (subjectNode, message) {
            let subject = message.subject && message.subject.trim();
            if (subject) {
                subjectNode.textContent = subject;
                subjectNode.classList.remove('msg-no-subject');
                subjectNode.removeAttribute('data-l10n-id');
            } else {
                mozL10n.setAttributes(subjectNode, 'message-no-subject');
                subjectNode.classList.add('msg-no-subject');
            }
        }
    };
});
define('cards/mixins/data-prop', [], function () {
    return {
        templateInsertedCallback: function () {
            let nodes = this.querySelectorAll('[data-prop]'), length = nodes.length;
            for (let i = 0; i < length; i++) {
                this[nodes[i].dataset.prop] = nodes[i];
            }
        }
    };
});
define('cards/mixins/data-event', [], function () {
    let slice = Array.prototype.slice;
    return {
        templateInsertedCallback: function () {
            slice.call(this.querySelectorAll('[data-event]')).forEach(node => {
                node.dataset.event.split(',').forEach(pair => {
                    let evtName, method, parts = pair.split(':');
                    if (!parts[1]) {
                        parts[1] = parts[0];
                    }
                    evtName = parts[0].trim();
                    method = parts[1].trim();
                    if (typeof this[method] !== 'function') {
                        throw new Error('"' + method + '" is not a function, ' + 'cannot bind with data-event');
                    }
                    node.addEventListener(evtName, evt => {
                        return this[method](evt);
                    }, false);
                });
            });
        }
    };
});
define('cards/base', [
    'require',
    'l10n!',
    'date',
    'evt',
    './mixins/data-prop',
    './mixins/data-event'
], function (require) {
    let mozL10n = require('l10n!'), date = require('date'), Emitter = require('evt').Emitter;
    (function () {
        let updatePrettyDate = function updatePrettyDate() {
            let labels = document.querySelectorAll('[data-time]');
            let i = labels.length;
            while (i--) {
                labels[i].textContent = date.prettyDate(labels[i].dataset.time, 'compactFormat' in labels[i].dataset, 'l10nFormat' in labels[i].dataset);
            }
        };
        let timer = setInterval(updatePrettyDate, 60 * 1000);
        function updatePrettyDateOnEvent() {
            clearTimeout(timer);
            updatePrettyDate();
            timer = setInterval(updatePrettyDate, 60 * 1000);
        }
        mozL10n.change(updatePrettyDateOnEvent);
        document.addEventListener('visibilitychange', () => {
            if (document && !document.hidden) {
                updatePrettyDateOnEvent();
            }
        });
    }());
    return function cardBase(templateMixins) {
        return [
            templateMixins ? templateMixins : {},
            require('./mixins/data-prop'),
            require('./mixins/data-event'),
            Emitter.prototype,
            {
                createdCallback: function () {
                    Emitter.call(this);
                    if (this.extraClasses) {
                        this.classList.add.apply(this.classList, this.extraClasses);
                    }
                    this.classList.add('card');
                },
                batchAddClass: function (searchClass, classToAdd) {
                    let nodes = this.getElementsByClassName(searchClass);
                    for (let i = 0; i < nodes.length; i++) {
                        nodes[i].classList.add(classToAdd);
                    }
                },
                bindContainerHandler: function (containerNode, eventName, func) {
                    containerNode.addEventListener(eventName, event => {
                        let node = event.target;
                        if (node === containerNode) {
                            return;
                        }
                        while (node && node.parentNode !== containerNode) {
                            node = node.parentNode;
                        }
                        func(node, event);
                    }, false);
                }
            }
        ];
    };
});
define('element', [], function () {
    'use strict';
    var slice = Array.prototype.slice, callbackSuffix = 'Callback', callbackSuffixLength = callbackSuffix.length, charRegExp = /[^a-z]/g;
    function makePropName(attrName) {
        var parts = attrName.split('-');
        for (var i = 1; i < parts.length; i++) {
            parts[i] = parts[i].charAt(0).toUpperCase() + parts[i].substring(1);
        }
        return parts.join('');
    }
    function setPropFromAttr(instance, attrName, attrValue) {
        var proto = Object.getPrototypeOf(instance), propName = makePropName(attrName), descriptor = Object.getOwnPropertyDescriptor(proto, propName);
        if (descriptor && descriptor.set) {
            instance[propName] = attrValue;
        }
    }
    function makePropFn(prop) {
        return function () {
            var i, ret, args = slice.call(arguments), fns = this._element.props[prop];
            for (i = 0; i < fns.length; i++) {
                ret = fns[i].apply(this, args);
            }
            return ret;
        };
    }
    function mixFnProp(proto, prop, value, operation) {
        if (proto.hasOwnProperty(prop)) {
            var existing = proto._element.props[prop];
            if (!existing) {
                existing = proto._element.props[prop] = [proto[prop]];
                proto[prop] = makePropFn(prop);
            }
            operation = operation || 'push';
            existing[operation](value);
        } else {
            proto[prop] = value;
        }
    }
    function mix(proto, mixin) {
        if (Array.isArray(mixin)) {
            mixin.forEach(function (mixin) {
                mix(proto, mixin);
            });
            return;
        }
        Object.keys(mixin).forEach(function (key) {
            var suffixIndex, descriptor = Object.getOwnPropertyDescriptor(mixin, key);
            suffixIndex = key.indexOf(callbackSuffix);
            if (suffixIndex > 0 && suffixIndex === key.length - callbackSuffixLength) {
                mixFnProp(proto, key, descriptor.value);
            } else {
                Object.defineProperty(proto, key, descriptor);
            }
        });
    }
    var element = {
        load: function (id, req, onload, config) {
            req([id], function (mod) {
                if (config.isBuild || !mod || typeof mod === 'function') {
                    return onload();
                }
                var proto = Object.create(HTMLElement.prototype);
                Object.defineProperty(proto, '_element', {
                    enumerable: false,
                    configurable: false,
                    writable: false,
                    value: {}
                });
                proto._element.props = {};
                mix(proto, mod);
                mixFnProp(proto, 'createdCallback', function attrCreated() {
                    var i, item, attrs = this.attributes;
                    for (i = 0; i < attrs.length; i++) {
                        item = attrs.item(i);
                        setPropFromAttr(this, item.nodeName, item.value);
                    }
                }, 'unshift');
                mixFnProp(proto, 'attributeChangedCallback', function attrChanged(name, oldValue, newValue) {
                    setPropFromAttr(this, name, newValue);
                }, 'unshift');
                id = id.toLowerCase().replace(charRegExp, '-');
                onload(document.registerElement(id, { prototype: proto }));
            });
        }
    };
    return element;
});
define('template', [
    'require',
    'exports',
    'module',
    'element'
], function (require, exports, module) {
    let template, fetchText, templateDiv, isReady = false, readyQueue = [], tagRegExp = /<(\w+-[\w-]+)(\s|>)/g, commentRegExp = /<!--*.?-->/g, attrIdRegExp = /\s(hrefid|srcid)="([^"]+)"/g, buildProtocol = 'build:', moduleConfig = module.config(), depPrefix = 'element!', buildMap = {}, tagToId = function (tag) {
            return tag;
        };
    require('element');
    if (moduleConfig.hasOwnProperty('depPrefix')) {
        depPrefix = moduleConfig.depPrefix;
    }
    if (moduleConfig.hasOwnProperty('tagToId')) {
        tagToId = moduleConfig.tagToId;
    }
    if (typeof document !== 'undefined') {
        templateDiv = document.createElement('div');
    }
    function onReady() {
        isReady = true;
        let bodyTemplate = document.querySelector('template#body');
        if (bodyTemplate) {
            bodyTemplate.parentNode.removeChild(bodyTemplate);
            document.body.innerHTML = bodyTemplate.innerHTML;
        }
        readyQueue.forEach(fn => {
            fn();
        });
        readyQueue = [];
    }
    function makeFullId(id, refId) {
        if (id.indexOf('.') === 0 && refId) {
            let parts = refId.split('/');
            parts.pop();
            refId = parts.join('/');
            id = (refId ? refId + '/' : '') + id;
        }
        return id;
    }
    function templateCreatedCallback() {
        if (this.dataset.cached === 'cached' || this.template) {
            if (this.dataset.cached !== 'cached' && this.template) {
                this.innerHTML = '';
                this.appendChild(this.template());
            }
            if (this.templateInsertedCallback) {
                this.templateInsertedCallback();
            }
        }
    }
    if (typeof XMLHttpRequest !== 'undefined') {
        fetchText = function (url, onload, onerror) {
            let xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.onreadystatechange = function () {
                let status, err;
                if (xhr.readyState === 4) {
                    status = xhr.status;
                    if (status > 399 && status < 600) {
                        err = new Error(url + ' HTTP status: ' + status);
                        err.xhr = xhr;
                        onerror(err);
                    } else {
                        onload(xhr.responseText);
                    }
                }
            };
            xhr.responseType = 'text';
            xhr.send(null);
        };
    } else {
        fetchText = function (url, onload) {
            onload(requirejs._readFile(url));
        };
    }
    template = {
        fetchText: fetchText,
        ready: function (fn) {
            if (isReady) {
                setTimeout(fn);
            } else {
                readyQueue.push(fn);
            }
        },
        makeFullId: makeFullId,
        makeTemplateFn: function (text) {
            return function () {
                let e, frag = document.createDocumentFragment();
                templateDiv.innerHTML = text;
                while (e = templateDiv.firstChild) {
                    frag.appendChild(e);
                }
                return frag;
            };
        },
        idsToUrls: function (text, refId) {
            text = text.replace(attrIdRegExp, function (match, type, id) {
                id = makeFullId(id, refId);
                let attr = type === 'hrefid' ? 'href' : 'src';
                return ' ' + attr + '="' + require.toUrl(id) + '"';
            });
            return text;
        },
        depsFromText: function (text) {
            let match, noCommentText, deps = [];
            noCommentText = text.replace(commentRegExp, '');
            tagRegExp.lastIndex = 0;
            while (match = tagRegExp.exec(noCommentText)) {
                deps.push(depPrefix + tagToId(match[1]));
            }
            return deps;
        },
        textToTemplate: function (text, id, skipTranslateIds) {
            let obj, deps = template.depsFromText(text);
            obj = {
                id: id,
                deps: deps,
                text: text
            };
            if (!skipTranslateIds) {
                obj.text = template.idsToUrls(text, id);
                obj.fn = template.makeTemplateFn(obj.text);
            }
            return obj;
        },
        objToFn: function (obj) {
            let text = template.idsToUrls(obj.text, obj.id);
            return template.makeTemplateFn(text);
        },
        templateCreatedCallback: templateCreatedCallback,
        load: function (id, req, onload, config) {
            let isBuild = config.isBuild;
            if (id.indexOf(buildProtocol) === 0 && isBuild) {
                id = id.substring(buildProtocol.length);
                let idList = id.split(','), count = 0, buildIdDone = function () {
                        count += 1;
                        if (count === idList.length) {
                            onload();
                        }
                    };
                buildIdDone.__requireJsBuild = true;
                id.split(',').forEach(moduleId => {
                    let path = req.toUrl(moduleId);
                    require(template.depsFromText(requirejs._readFile(path)), buildIdDone);
                });
            } else {
                fetchText(req.toUrl(id), text => {
                    let templateObj = template.textToTemplate(text, id, isBuild);
                    req(templateObj.deps, () => {
                        if (isBuild) {
                            buildMap[id] = templateObj;
                        }
                        onload({
                            createdCallback: templateCreatedCallback,
                            template: templateObj.fn
                        });
                    });
                }, onload.error);
            }
        },
        write: function (pluginName, id, write) {
            if (buildMap.hasOwnProperty(id)) {
                let obj = buildMap[id], depString = JSON.stringify(obj.deps);
                depString = depString.replace(/^\s*\[/, '').replace(/\]\s*$/, '').trim();
                if (depString) {
                    depString = ', ' + depString;
                }
                write.asModule(pluginName + '!' + id, 'define([\'' + module.id + '\'' + depString + '], function(template) { return {\n' + 'createdCallback: template.templateCreatedCallback,\n' + 'template: template.objToFn(' + JSON.stringify(buildMap[id]) + ')}; });\n');
            }
        }
    };
    if (typeof document !== 'undefined') {
        let onDom, onDomDone = false;
        onDom = function () {
            if (onDomDone) {
                return;
            }
            onDomDone = true;
            let converted = template.textToTemplate(document.body.innerHTML);
            require(converted.deps, onReady);
        };
        if (document.readyState === 'interactive' || document.readyState === 'complete') {
            onDom();
        } else {
            window.addEventListener('DOMContentLoaded', onDom);
        }
    }
    return template;
});
define('template!cards/message_list.html', ['template'], function (template) {
    return {
        createdCallback: template.templateCreatedCallback,
        template: template.objToFn({
            'id': 'cards/message_list.html',
            'deps': [],
            'text': '<!-- Non-search header -->\n<section data-prop="normalHeader"\n         class="msg-list-header msg-nonsearch-only"\n         data-statuscolor="default"\n         role="region">\n  <header>\n    <h1 id="folder-header" data-prop="folderLabel"\n        class="msg-list-header-folder-label header-label">\n      <div class="msg-list-header-folder-info">\n        <span data-prop="folderNameNode"\n            dir="auto"\n            class="msg-list-header-folder-name"></span>\n        <span data-prop="folderUnread"\n            class="msg-list-header-folder-unread collapsed"></span>\n      </div>\n    </h1>\n    <h2 class="msg-list-header-sync-label" data-prop="headerSyncLabel">\n      <div class="msg-last-synced-header">\n        <span data-prop="lastSyncedLabel"\n              class="msg-last-synced-label p-sec"\n              data-l10n-id="folder-last-synced-label"></span>\n        <span data-prop="lastSyncedAtNode"\n              class="msg-last-synced-value p-sec"></span>\n      </div>\n      <span class="msg-synchronizing-label" data-l10n-id="synchronizing">Synchronizing...</span>\n      <span class="msg-outbox-unsent-label collapsed" data-prop="msgUnsentLabel"></span>\n      <span class="msg-never-sync-label collapsed"\n            data-prop="msgNeverSync"\n            data-l10n-id="never-sync">Never sync</span>\n    </h2>\n  </header>\n</section>\n<!-- Multi-edit state header -->\n<section data-prop="editHeader"\n         class="msg-listedit-header collapsed" role="region">\n  <header>\n    <h1 class="msg-listedit-header-label">\n      <div class="msg-listedit-header-info">\n        <span class="msg-list-edit-header-name"\n              data-prop="editHeaderNode"></span>\n      </div>\n    </h1>\n    <h2 data-prop="headerNode" class="msg-listedit-selected-label"></h2>\n  </header>\n</section>\n<!-- Search header -->\n<section role="region" data-prop="searchHeader"\n         class="msg-search-header msg-search-only">\n  <header>\n    <h1 class="cmp-compose-header-label search-title"\n        data-prop="searchTitle"\n        data-l10n-id="message-search-header">\n    </h1>\n  </header>\n  <ul class="filter-container">\n    <li data-prop="filterType" class="filter-selector focusable" role="option"></li>\n  </ul>\n  <li class="search-input-li focusable" data-prop="searchInputLi">\n    <input data-prop="searchInput" data-event="input:onSearchTextChange"\n           type="text" required="required" class="msg-search-text"\n           autocorrect="off"\n           inputmode="verbatim"\n           x-inputmode="verbatim"\n           maxlength="100"\n           dir="auto"\n           data-l10n-id="message-search-input" />\n  </li>\n  <header>\n    <h2 class="cmp-compose-header-label search-result collapsed"\n        data-prop="searchResult"></h2>\n  </header>\n  <!-- Search filter switcher -->\n  <header class="msg-search-controls-bar collapsed">\n    <ul role="tablist" class="bb-tablist filter" data-type="filter">\n      <li role="presentation" class="msg-search-from msg-search-filter"\n          data-filter="author" data-filter-name="search-author">\n        <a data-l10n-id="message-search-from" role="tab"\n          aria-selected="false"></a></li>\n      <li role="presentation" class="msg-search-to msg-search-filter"\n          data-filter="recipients" data-filter-name="search-to">\n        <a data-l10n-id="message-search-to" role="tab"\n          aria-selected="false"></a></li>\n      <li role="presentation" class="msg-search-subject msg-search-filter"\n           data-filter="subject" data-filter-name="search-subject">\n        <a data-l10n-id="message-search-subject" role="tab"\n          aria-selected="false"></a>\n      </li>\n      <li role="presentation" class="msg-search-body msg-search-filter"\n           data-filter="body" data-filter-name="search-body">\n        <a data-l10n-id="message-search-body" role="tab"\n          aria-selected="false"></a></li>\n      <li role="presentation" class="msg-search-body msg-search-filter"\n          data-filter="all" data-filter-name="search-all">\n        <a data-l10n-id="message-search-all" role="tab"\n          aria-selected="true"></a></li>\n    </ul>\n  </header>\n</section>\n<!-- Scroll region -->\n<div data-prop="scrollContainer" class="msg-list-scrollouter">\n  <!-- exists so we can force a minimum height -->\n  <div class="msg-list-scrollinner">\n    <!-- The search textbox hides under the lip of the messages.\n         As soon as any typing happens in it, we push the search\n         controls card. -->\n    <form role="search" data-prop="searchBar"\n          class="msg-search-tease-bar msg-nonsearch-only">\n      <p>\n        <input data-event="focus:onSearchButton"\n               class="msg-search-text-tease" type="text"\n               dir="auto"\n               maxlength="100"\n               data-l10n-id="message-search-input" />\n      </p>\n    </form>\n    <div data-prop="messagesContainer" class="msg-messages-container"\n         role="listbox" aria-multiselectable="true">\n    </div>\n    <!-- maintain vertical space for the syncing/sync more div\'s\n         regardless of their displayed status so we don\'t scroll them\n         out of the way -->\n    <div data-prop="syncContainer" class="msg-messages-sync-container">\n      <p data-prop="syncingNode" class="msg-messages-syncing collapsed"\n         role="progressbar" data-l10n-id="messages-syncing-progressbar">\n        <span data-l10n-id="messages-syncing"></span>\n      </p>\n      <p data-prop="syncMoreNode" data-index="0"\n         data-event="click:onGetMoreMessages"\n         class="msg-header-item msg-messages-sync-more"\n         role="button">\n        <span data-l10n-id="messages-load-more"></span>\n      </p>\n    </div>\n\n    <div data-nav-id="jumpToHead" style="display: none"></div>\n    <div data-nav-id="jumpToTail" style="display: none"></div>\n  </div>\n</div>\n<!-- New email notification bar -->\n<div class="message-list-topbar"></div>\n<!-- Conveys background send, plus undo-able recent actions -->\n<div class="msg-activity-infobar hidden">\n</div>\n\n<div data-prop="messageEmptyContainer"\n     class="msg-list-empty-container collapsed">\n  <p data-prop="messageEmptyText"\n     class="msg-list-empty-message-text"\n     data-l10n-id="messages-folder-empty" tabindex="-1"></p>\n</div>\n'
        })
    };
});
define('cards/message_list', [
    'require',
    'exports',
    'module',
    'tmpl!./msg/header_item.html',
    'cards',
    'date',
    'evt',
    'toaster',
    'model',
    'header_cursor',
    'html_cache',
    'l10n!',
    'vscroll',
    'http://shared.localhost/js/helper/accessibility/accessibility_helper.js',
    'message_display',
    './base',
    'template!./message_list.html'
], function (require, exports, module) {
    let msgHeaderItemNode = require('tmpl!./msg/header_item.html'), cards = require('cards'), date = require('date'), evt = require('evt'), toaster = require('toaster'), model = require('model'), headerCursor = require('header_cursor').cursor, htmlCache = require('html_cache'), mozL10n = require('l10n!'), VScroll = require('vscroll'), accessibilityHelper = require('http://shared.localhost/js/helper/accessibility/accessibility_helper.js'), messageDisplay = require('message_display');
    let MATCHED_TEXT_CLASS = 'highlight';
    function appendMatchItemTo(matchItem, node) {
        let text = matchItem.text;
        let idx = 0;
        for (let iRun = 0; iRun <= matchItem.matchRuns.length; iRun++) {
            let run;
            if (iRun === matchItem.matchRuns.length) {
                run = {
                    start: text.length,
                    length: 0
                };
            } else {
                run = matchItem.matchRuns[iRun];
            }
            if (run.start > idx) {
                let tnode = document.createTextNode(text.substring(idx, run.start));
                node.appendChild(tnode);
            }
            if (!run.length) {
                continue;
            }
            let hspan = document.createElement('span');
            hspan.classList.add(MATCHED_TEXT_CLASS);
            hspan.textContent = text.substr(run.start, run.length);
            node.appendChild(hspan);
            idx = run.start + run.length;
        }
    }
    let defaultVScrollData = {
        'isPlaceholderData': true,
        'id': 'INVALID',
        'author': {
            'name': '\u2583\u2583\u2583\u2583\u2583\u2583\u2583\u2583',
            'address': '',
            'contactId': null
        },
        'to': [{
                'name': ' ',
                'address': ' ',
                'contactId': null
            }],
        'cc': null,
        'bcc': null,
        'date': '0',
        'hasAttachments': false,
        'snippet': '\u2583\u2583\u2583\u2583\u2583\u2583\u2583\u2583' + '\u2583\u2583\u2583\u2583\u2583\u2583\u2583\u2583' + '\u2583\u2583\u2583\u2583\u2583\u2583\u2583\u2583',
        'isRead': true,
        'isStarred': false,
        'sendStatus': {},
        'subject': '\u2583\u2583\u2583\u2583\u2583\u2583\u2583\u2583' + '\u2583\u2583\u2583\u2583\u2583\u2583\u2583\u2583' + '\u2583\u2583\u2583\u2583\u2583\u2583\u2583\u2583'
    };
    let defaultSearchVScrollData = {
        header: defaultVScrollData,
        matches: []
    };
    let MINIMUM_ITEMS_FOR_SCROLL_CALC = 10;
    let MAXIMUM_MS_BETWEEN_SNIPPET_REQUEST = 6000;
    let MAXIMUM_BYTES_PER_MESSAGE_DURING_SCROLL = 4 * 1024;
    let searchIndex = 4;
    const QUERY_CHILD = '.msg-header-item:not([data-index="-1"])';
    return [
        require('./base')(require('template!./message_list.html')),
        {
            createdCallback: function () {
                let mode = this.mode;
                if (mode === 'nonsearch') {
                    this.batchAddClass('msg-search-only', 'collapsed');
                } else {
                    this.batchAddClass('msg-nonsearch-only', 'collapsed');
                    this.dataset.statuscolor = 'background';
                }
                this.bindContainerHandler(this.messagesContainer, 'click', this.onClickMessage.bind(this));
                this.setRefreshState(true);
                if (mode === 'search') {
                    this.bindContainerHandler(this.querySelector('.filter'), 'click', this.onSearchFilterClick.bind(this));
                    this.searchFilterTabs = this.querySelectorAll('.filter [role="tab"]');
                }
                this.editMode = false;
                this.selectedMessages = null;
                this.isFirstTimeVisible = true;
                this.curFolder = null;
                this.isIncomingFolder = true;
                this._emittedContentEvents = false;
                this.usingCachedNode = this.dataset.cached === 'cached';
                this.composeSendType = null;
                this.setReadBoth = false;
                this.setFlagBoth = false;
                this.setAllAsStarred = false;
                this.setAllAsRead = false;
                this.action = null;
                let listFunc = index => {
                    return headerCursor.messagesSlice.items[index];
                };
                listFunc.size = () => {
                    let slice = headerCursor.messagesSlice;
                    return Math.max(slice.headerCount || 0, slice.items.length);
                };
                this.listFunc = listFunc;
                this.waitingOnChunk = true;
                this.desiredHighAbsoluteIndex = 0;
                this._needVScrollData = false;
                this.vScroll = new VScroll(this.messagesContainer, this.scrollContainer, msgHeaderItemNode, this.mode === 'nonsearch' ? defaultVScrollData : defaultSearchVScrollData);
                if (this.mode === 'nonsearch') {
                    this.vScroll.bindData = (model, node) => {
                        if (this.mode === headerCursor.searchMode) {
                            model.element = node;
                            node.message = model;
                            this.updateMessageDom(true, model);
                        }
                    };
                } else {
                    this.vScroll.bindData = (model, node) => {
                        if (this.mode === headerCursor.searchMode) {
                            model.element = node;
                            node.message = model.header;
                            this.updateMatchedMessageDom(true, model);
                        }
                    };
                }
                this.vScroll.prepareData = highAbsoluteIndex => {
                    let items = headerCursor.messagesSlice && headerCursor.messagesSlice.items, headerCount = headerCursor.messagesSlice.headerCount;
                    if (!items || !headerCount) {
                        return;
                    }
                    if (highAbsoluteIndex > headerCount - 1) {
                        highAbsoluteIndex = headerCount - 1;
                    }
                    if (highAbsoluteIndex < items.length) {
                        return;
                    }
                    this.loadNextChunk(highAbsoluteIndex);
                };
                this._hideSearchBoxByScrolling = this._hideSearchBoxByScrolling.bind(this);
                this._onVScrollStopped = this._onVScrollStopped.bind(this);
                this.vScroll.on('inited', this._hideSearchBoxByScrolling);
                this.vScroll.on('dataChanged', this._hideSearchBoxByScrolling);
                this.vScroll.on('scrollStopped', this._onVScrollStopped);
                this.vScroll.on('recalculated', calledFromTop => {
                    if (calledFromTop) {
                        this._hideSearchBoxByScrolling();
                    }
                });
                this._folderChanged = this._folderChanged.bind(this);
                this.onNewMail = this.onNewMail.bind(this);
                this.onFoldersSliceChange = this.onFoldersSliceChange.bind(this);
                this.messages_splice = this.messages_splice.bind(this);
                this.messages_change = this.messages_change.bind(this);
                this.messages_status = this.messages_status.bind(this);
                this.messages_complete = this.messages_complete.bind(this);
                this.onBackgroundSendStatus = this.onBackgroundSendStatus.bind(this);
                model.latest('folder', this._folderChanged);
                model.on('newInboxMessages', this.onNewMail);
                model.on('backgroundSendStatus', this.onBackgroundSendStatus);
                model.on('foldersSliceOnChange', this.onFoldersSliceChange);
                this.sliceEvents.forEach(type => {
                    let name = 'messages_' + type;
                    headerCursor.on(name, this[name]);
                });
                this.onCurrentMessage = this.onCurrentMessage.bind(this);
                headerCursor.on('currentMessage', this.onCurrentMessage);
                this.onMessageSorted = this.onMessageSorted.bind(this);
                headerCursor.on('messageSorted', this.onMessageSorted);
                if (this.curFolder && this.mode === 'nonsearch') {
                    let items = headerCursor.messagesSlice && headerCursor.messagesSlice.items;
                    if (items && items.length) {
                        this.messages_splice(0, 0, items);
                        this.messages_complete(0);
                    }
                }
                this.isShowEmpty = false;
                this.shouldSetListFocus = false;
                this.transitionendFn = this.transitionendFn.bind(this);
                window.addEventListener('transitionend', this.transitionendFn);
                cards.showActivityDraftToast();
                cards.saveActivityComposeDraft();
            },
            transitionendFn: function (event) {
                if (event.target.id === 'option-menu') {
                    if (!window.option.menuVisible && this.shouldSetListFocus) {
                        this.setMessageListFocus(false, true);
                    }
                }
            },
            mode: 'nonsearch',
            _distanceBetweenMessages: 0,
            sliceEvents: [
                'splice',
                'change',
                'status',
                'complete'
            ],
            skipEmitContentEvents: true,
            postInsert: function () {
                this._hideSearchBoxByScrolling();
                this.vScroll.visibleOffset = this.searchBar.getBoundingClientRect().height;
                this.vScroll.captureScreenMetrics();
            },
            onSearchButton: function () {
                if (!this.curFolder) {
                    return;
                }
                cards.pushCard('message_list_search', 'animate', { folder: this.curFolder });
            },
            setEditMode: function (editMode) {
                if (!this.curFolder) {
                    return;
                }
                if (this.curFolder.type === 'outbox') {
                    if (editMode && this.outboxSyncInProgress) {
                        return;
                    }
                    if (!model.account.enabled) {
                        model.account.clearProblems();
                    }
                    NavigationMap.needDelayToFocus = true;
                    if (!editMode) {
                        this._setEditMode(editMode);
                        model.api.setOutboxSyncEnabled(model.account, !editMode, () => {
                        });
                    } else {
                        model.api.setOutboxSyncEnabled(model.account, !editMode, () => {
                            this._setEditMode(editMode);
                        });
                    }
                } else {
                    this._setEditMode(editMode);
                }
            },
            _setEditMode: function (editMode) {
                let i;
                this.editMode = editMode;
                if (this.mode !== 'search') {
                    this.updateScrollContainer();
                }
                if (editMode) {
                    if (this.mode === 'nonsearch') {
                        this.searchHeader.classList.add('collapsed');
                        this.editHeader.classList.remove('collapsed');
                    }
                    this.normalHeader.classList.add('collapsed');
                    this.messagesContainer.classList.add('show-edit');
                    this.selectedMessages = [];
                    this.selectedMessagesUpdated();
                } else {
                    if (this.mode === 'nonsearch') {
                        this.normalHeader.classList.remove('collapsed');
                    } else {
                        mozL10n.setAttributes(this.searchTitle, 'message-search-header');
                        this.searchHeader.classList.remove('collapsed');
                    }
                    this.editHeader.classList.add('collapsed');
                    this.messagesContainer.classList.remove('show-edit');
                    let item = NavigationMap.getCurrentItem();
                    if (item && item.message) {
                        this.selectedMessages = [item.message];
                    }
                    this.selectedMessagesUpdated();
                }
                let msgNodes = this.messagesContainer.querySelectorAll('.msg-header-item');
                for (i = 0; i < msgNodes.length; i++) {
                    this.setMessageChecked(msgNodes[i], false);
                }
            },
            setEditModeStart: function () {
                this.setEditMode(true);
            },
            setEditModeDone: function () {
                this.setEditMode(false);
            },
            selectedMessagesUpdated: function () {
                this.headerNode.classList.add('collapsed');
                if (this.editMode) {
                    if (this.mode === 'search') {
                        mozL10n.setAttributes(this.searchTitle, 'message-multiedit-search-header', { n: this.selectedMessages.length });
                    } else {
                        mozL10n.setAttributes(this.editHeaderNode, 'message-multiedit-header', { n: this.selectedMessages.length });
                    }
                }
                let hasMessages = !!this.selectedMessages.length;
                let numStarred = 0, numRead = 0;
                for (let i = 0; i < this.selectedMessages.length; i++) {
                    let msg = this.selectedMessages[i];
                    if (msg.isStarred) {
                        numStarred++;
                    }
                    if (msg.isRead) {
                        numRead++;
                    }
                }
                this.setAsStarred = !(numStarred && numStarred === this.selectedMessages.length);
                this.setAsRead = hasMessages && numRead === 0;
                this.optMarkRead.l10nId = this.setAsRead ? 'opt-mark-read' : 'opt-mark-unread';
                this.optAddFlag.l10nId = this.setAsStarred ? 'opt-add-flag' : 'opt-remove-flag';
                this.setFlagBoth = numStarred > 0 && numStarred < this.selectedMessages.length;
                if (!this.setFlagBoth) {
                    this.setAllAsStarred = numStarred === 0;
                }
                this.setReadBoth = numRead > 0 && numRead < this.selectedMessages.length;
                if (!this.setReadBoth) {
                    this.setAllAsRead = numRead === 0;
                }
                if (this.editMode) {
                    let focused = document.querySelector('.focus');
                    if (focused && focused.message) {
                        let checkBox = focused.children[0].children[0];
                        if (checkBox && checkBox.checked) {
                            this.optionCsk = this.optionDeselect;
                        } else {
                            this.optionCsk = this.optionSelect;
                        }
                    }
                }
                this.setSoftkeyBar();
            },
            _hideSearchBoxByScrolling: function () {
                let searchBar = this.searchBar, scrollContainer = this.scrollContainer;
                if (searchBar.classList.contains('collapsed')) {
                    searchBar.classList.remove('collapsed');
                    scrollContainer.scrollTop += searchBar.offsetHeight;
                }
                if (scrollContainer.scrollTop === 0) {
                    scrollContainer.scrollTop = searchBar.offsetHeight;
                }
            },
            onShowFolders: function () {
                window.backToShowFolder = false;
                cards.pushCard('folder_picker', 'animate');
            },
            onCompose: function () {
                cards.pushCard('compose', 'animate');
            },
            updateScrollContainer: function () {
                setTimeout(() => {
                    let headerHeight;
                    let focused = document.querySelector('.focus');
                    if (this.editMode) {
                        headerHeight = this.headerNode.clientHeight;
                    } else {
                        headerHeight = this.headerSyncLabel.clientHeight;
                    }
                    this.scrollContainer.style.height = 'calc(100% - var(--statusbar-softkeybar-height)' + ' - var(--header-height) - ' + headerHeight + 'px' + ')';
                    this.vScroll.updateDataBind(0, [], 0);
                    NavigationMap.cardContentHeight = this.scrollContainer.clientHeight;
                    if (focused && !NavigationMap.isVisible(focused)) {
                        focused.scrollIntoView(false);
                    }
                });
            },
            updateLastSynced: function (value) {
                if (this.mode === 'search') {
                    return;
                }
                if (this.folder.type !== 'localdrafts') {
                    this.msgNeverSync.classList.add('collapsed');
                    let outboxFolder = model.foldersSlice.getFirstFolderWithType('outbox');
                    let num = outboxFolder.unread;
                    if (this.folder.type === 'inbox' && num > 0) {
                        this.msgUnsentLabel.classList.remove('collapsed');
                        mozL10n.setAttributes(this.msgUnsentLabel, 'outbox-unsent-label', { n: num });
                    } else {
                        this.msgUnsentLabel.classList.add('collapsed');
                    }
                } else {
                    this.msgUnsentLabel.classList.add('collapsed');
                    this.msgNeverSync.classList.remove('collapsed');
                    value = null;
                }
                const lastSyncedHeader = this.headerSyncLabel.querySelector('.msg-last-synced-header');
                if (lastSyncedHeader) {
                    lastSyncedHeader.classList.remove('collapsed');
                }
                let method = value ? 'remove' : 'add';
                this.lastSyncedLabel.classList[method]('collapsed');
                date.setPrettyNodeDate(this.lastSyncedAtNode, value);
                this.updateScrollContainer();
            },
            updateUnread: function (num) {
                let content = '';
                if (num > 0) {
                    content = num > 999 ? mozL10n.get('messages-folder-unread-max') : num;
                }
                this.folderUnread.textContent = '(' + content + ')';
                this.folderUnread.classList.toggle('collapsed', !content);
                this.folderNameNode.style.setProperty('margin-right', content ? 'unset' : 'auto');
                this.callHeaderFontSize();
            },
            onFoldersSliceChange: function (folder) {
                if (folder === this.curFolder) {
                    this.updateUnread(folder.unread);
                    this.updateLastSynced(folder.lastSyncedAt);
                } else if (folder.type === 'outbox' && this.curFolder.type === 'inbox') {
                    this.updateUnread(this.curFolder.unread);
                    this.updateLastSynced(this.curFolder.lastSyncedAt);
                }
            },
            callHeaderFontSize: function (node) {
                requestAnimationFrame(() => {
                    FontSizeUtils._reformatHeaderText(this.folderLabel);
                });
            },
            showFolder: function (folder, forceNewSlice) {
                if (folder === this.curFolder && !forceNewSlice) {
                    return false;
                }
                if (!this.usingCachedNode) {
                    this.vScroll.clearDisplay();
                }
                this._needVScrollData = true;
                this.curFolder = folder;
                switch (folder.type) {
                case 'drafts':
                case 'localdrafts':
                case 'outbox':
                case 'sent':
                    this.isIncomingFolder = false;
                    break;
                default:
                    this.isIncomingFolder = true;
                    break;
                }
                this.folderNameNode.textContent = folder.name;
                this.updateUnread(folder.unread);
                this.messagesContainer.setAttribute('aria-label', folder.name);
                this.hideEmptyLayout();
                this.updateLastSynced(folder.lastSyncedAt);
                if (forceNewSlice) {
                    this._snippetRequestPending = false;
                    headerCursor.freshMessagesSlice();
                }
                this.onFolderShown();
                return true;
            },
            showSearch: function (phrase, filter) {
                console.log('sf: showSearch. phrase:', phrase, phrase.length);
                this.curFolder = model.folder;
                this.vScroll.clearDisplay();
                this.vScroll.setListNodeCount(headerCursor.messagesSlice.headerCount);
                this.curFilter = filter;
                if (!phrase.length) {
                    if (this.editMode) {
                        this.setEditMode(false);
                    }
                }
                this.syncMoreNode.classList.add('collapsed');
                this._snippetRequestPending = false;
                this.waitingOnChunk = true;
                headerCursor.startSearch(phrase, {
                    author: filter === 'all' || filter === 'author',
                    recipients: filter === 'all' || filter === 'recipients',
                    subject: filter === 'all' || filter === 'subject',
                    body: filter === 'all' || filter === 'body'
                });
                return true;
            },
            onSearchFilterClick: function (filterNode, event) {
                accessibilityHelper.setAriaSelected(filterNode.firstElementChild, this.searchFilterTabs);
                this.showSearch(this.searchInput.value, filterNode.dataset.filter);
            },
            onSearchTextChange: function (event) {
                console.log('sf: typed, now:', this.searchInput.value);
                if (event.isComposing) {
                    return;
                }
                this.showSearch(this.searchInput.value, this.curFilter);
            },
            onSearchSubmit: function (event) {
                event.preventDefault();
                this.searchInput.blur();
            },
            onCancelSearch: function (event) {
                try {
                    headerCursor.endSearch();
                } catch (ex) {
                    console.error('problem killing slice:', ex, '\n', ex.stack);
                }
                cards.removeCardAndSuccessors(this, 'animate');
            },
            onGetMoreMessages: function () {
                if (!headerCursor.messagesSlice) {
                    return;
                }
                this.vScroll.once('recalculated', (calledFromTop, refIndex) => {
                    this.messagesContainer.querySelector('[data-index="' + refIndex + '"]').focus();
                });
                headerCursor.messagesSlice.requestGrowth(1, true);
            },
            setRefreshState: function (syncing) {
                if (syncing) {
                    this.normalHeader.classList.add('synchronizing');
                } else {
                    this.normalHeader.classList.remove('synchronizing');
                }
            },
            messages_status: function (newStatus) {
                if (headerCursor.searchMode !== this.mode) {
                    return;
                }
                if (this.curFolder.type === 'outbox') {
                    return;
                }
                if (newStatus === 'synchronizing' || newStatus === 'syncblocked') {
                    this.hideEmptyLayout();
                    this.setRefreshState(true);
                } else if (newStatus === 'syncfailed' || newStatus === 'synced') {
                    if (newStatus === 'syncfailed') {
                        let errorInfo;
                        if (navigator.connection.type !== 'none') {
                            errorInfo = mozL10n.get('toaster-sync-failed');
                        } else {
                            errorInfo = mozL10n.get('no-internet-connection');
                        }
                        toaster.toast({ text: errorInfo });
                        if (!model.account.enabled) {
                            model.account.clearProblems();
                        }
                    }
                    this.setRefreshState(false);
                    this._manuallyTriggeredSync = false;
                }
            },
            isEmpty: function () {
                return headerCursor.messagesSlice.items.length === 0;
            },
            showEmptyLayout: function () {
                if (!this.syncMoreNode.classList.contains('collapsed')) {
                    this.syncMoreNode.classList.add('collapsed');
                }
                if (!this.usingCachedNode) {
                    this.usingCachedNode = true;
                }
                this._clearCachedMessages();
                mozL10n.setAttributes(this.messageEmptyText, this.mode === 'search' ? 'messages-search-empty' : 'messages-folder-empty');
                if (this.mode !== 'search' || this.searchInput.value) {
                    this.messageEmptyContainer.classList.remove('collapsed');
                    if (this.mode === 'nonsearch') {
                        this.messageEmptyText.focus();
                    }
                }
                this._hideSearchBoxByScrolling();
                this.isShowEmpty = true;
                this.setSoftkeyBar();
            },
            hideEmptyLayout: function () {
                this.isShowEmpty = false;
                this.messageEmptyContainer.classList.add('collapsed');
                this.setSoftkeyBar();
            },
            toggleSearchCount: function (num) {
                const count = num ? num : 0;
                if (count) {
                    this.searchResult.classList.remove('collapsed');
                } else {
                    this.searchResult.classList.add('collapsed');
                }
                mozL10n.setAttributes(this.searchResult, 'search-result', { num: count });
            },
            messages_complete: function (newEmailCount) {
                if (headerCursor.searchMode !== this.mode) {
                    return;
                }
                console.log('message_list complete:', headerCursor.messagesSlice.items.length, 'items of', headerCursor.messagesSlice.headerCount, 'alleged known headers. canGrow:', headerCursor.messagesSlice.userCanGrowDownwards);
                if (headerCursor.messagesSlice.userCanGrowDownwards && headerCursor.messagesSlice.headerCount) {
                    this.syncMoreNode.classList.remove('collapsed');
                    if (!this.syncContainer.contains(this.syncMoreNode)) {
                        this.syncContainer.appendChild(this.syncMoreNode);
                    }
                } else {
                    this.syncMoreNode.classList.add('collapsed');
                    if (this.syncContainer.contains(this.syncMoreNode)) {
                        this.syncContainer.removeChild(this.syncMoreNode);
                    }
                }
                if (headerCursor.messagesSlice.items.length === 0) {
                    this.showEmptyLayout();
                }
                if (this.mode === 'search' && !this.vScroll.list) {
                    this.vScroll.setData(this.listFunc);
                }
                if (this.mode === 'search') {
                    this.searchMessages = headerCursor.messagesSlice.headerCount;
                    this.toggleSearchCount(this.searchMessages);
                    if (this.editMode && this.selectedMessages.length > 0) {
                        let items = headerCursor.messagesSlice.items;
                        let temp = [];
                        for (let i = 0; i < items.length; i++) {
                            let id = items[i].header.id;
                            for (let j = 0; j < this.selectedMessages.length; j++) {
                                if (this.selectedMessages[j].id === id) {
                                    temp.push(this.selectedMessages[j]);
                                }
                            }
                        }
                        this.selectedMessages = temp;
                        this.selectedMessagesUpdated();
                    }
                }
                this.onNewMail(newEmailCount);
                this.waitingOnChunk = false;
                if (this.desiredHighAbsoluteIndex) {
                    this.loadNextChunk(this.desiredHighAbsoluteIndex);
                    this.desiredHighAbsoluteIndex = 0;
                }
                this.vScroll.updateDataBind(0, [], 0);
                if (!this._emittedContentEvents) {
                    evt.emit('metrics:contentDone');
                    this._emittedContentEvents = true;
                }
                NavigationMap.messageListMailCount = headerCursor.messagesSlice.headerCount;
                this.setSoftkeyBar();
                this.setRefreshState(false);
                this._cacheDom();
            },
            onNewMail: function (newEmailCount) {
                let inboxFolder = model.foldersSlice.getFirstFolderWithType('inbox');
                if (inboxFolder && inboxFolder.id === this.curFolder.id && newEmailCount && newEmailCount > 0) {
                    if (!cards.isVisible(this)) {
                        this._whenVisible = this.onNewMail.bind(this, newEmailCount);
                        return;
                    }
                    this.curFolder.reSort = true;
                    if (this._manuallyTriggeredSync) {
                        this.vScroll.jumpToIndex(0);
                        this.action = 'new';
                    } else {
                        let newMessages = mozL10n.get('new-messages', { n: newEmailCount });
                        toaster.toast({ text: newMessages });
                    }
                } else {
                    if (this.mode === 'nonsearch' && this.className === 'card center') {
                        if (!window.option.menuVisible) {
                            this.setMessageListFocus(false, true);
                        } else {
                            this.shouldSetListFocus = true;
                        }
                    }
                }
            },
            onBackgroundSendStatus: function (data) {
                if (this.curFolder.type === 'outbox') {
                    if (data.state === 'sending') {
                        this.toggleOutboxSyncingDisplay(true);
                    } else if (data.state === 'syncDone') {
                        this.toggleOutboxSyncingDisplay(false);
                    }
                } else {
                    if (data.state === 'sending' && data.sendType) {
                        this.composeSendType = data.sendType;
                    } else if (data.state === 'success') {
                        switch (this.composeSendType) {
                        case 'reply':
                            model.api.markMessagesReply(this.selectedMessages, true);
                            break;
                        case 'forward':
                            model.api.markMessagesForward(this.selectedMessages, true);
                            break;
                        default:
                            break;
                        }
                    }
                }
                if (data.emitNotifications && data.sendType || data.state === 'success') {
                    toaster.toast({ text: data.localizedDescription });
                } else if (data.state === 'error') {
                    let errMsg = data.localizedDescription;
                    setTimeout(() => {
                        if (navigator.connection.type === 'none') {
                            errMsg = mozL10n.get('background-send-pending');
                        }
                        toaster.toast({ text: errMsg });
                    }, 200);
                }
                if (data.state === 'success' || data.state === 'error') {
                    evt.emit('closeWindowAfterSent');
                }
            },
            _onVScrollStopped: function () {
                if (!headerCursor.messagesSlice || headerCursor.messagesSlice.pendingRequestCount) {
                    this.doScrollAction();
                    return;
                }
                if (cards.isVisible(this) && !this._hasSnippetRequest()) {
                    this._requestSnippets();
                }
                this.doScrollAction();
            },
            _hasSnippetRequest: function () {
                let max = MAXIMUM_MS_BETWEEN_SNIPPET_REQUEST;
                let now = Date.now();
                let beforeTimeout = this._lastSnippetRequest + max > now;
                return this._snippetRequestPending && beforeTimeout;
            },
            _pendingSnippetRequest: function () {
                this._snippetRequestPending = true;
                this._lastSnippetRequest = Date.now();
            },
            _clearSnippetRequest: function () {
                this._snippetRequestPending = false;
            },
            _requestSnippets: function () {
                let items = headerCursor.messagesSlice.items;
                let len = items.length;
                if (!len) {
                    return;
                }
                let clearSnippets = this._clearSnippetRequest.bind(this);
                let options = { maximumBytesToFetch: MAXIMUM_BYTES_PER_MESSAGE_DURING_SCROLL };
                if (len < MINIMUM_ITEMS_FOR_SCROLL_CALC) {
                    this._pendingSnippetRequest();
                    headerCursor.messagesSlice.maybeRequestBodies(0, MINIMUM_ITEMS_FOR_SCROLL_CALC - 1, options, clearSnippets);
                    return;
                }
                let visibleIndices = this.vScroll.getVisibleIndexRange();
                if (visibleIndices) {
                    this._pendingSnippetRequest();
                    headerCursor.messagesSlice.maybeRequestBodies(visibleIndices[0], visibleIndices[1], options, clearSnippets);
                }
            },
            _cacheListLimit: 7,
            _cacheDomTimeoutId: 0,
            _isCacheableCardState: function () {
                return this.cacheableFolderId === this.curFolder.id && this.mode === 'nonsearch' && !this.editMode;
            },
            _cacheDom: function () {
                this._cacheDomTimeoutId = 0;
                if (!this._isCacheableCardState()) {
                    return;
                }
                let cacheNode = htmlCache.cloneAsInertNodeAvoidingCustomElementHorrors(this);
                cacheNode.dataset.cached = 'cached';
                let removableCacheNode = cacheNode.querySelector('.msg-search-tease-bar');
                if (removableCacheNode) {
                    removableCacheNode.classList.add('collapsed');
                }
                let tempNode = cacheNode.querySelector('.msg-last-synced-header');
                if (tempNode) {
                    tempNode.classList.add('collapsed');
                }
                tempNode = cacheNode.querySelector('.msg-list-header');
                if (tempNode) {
                    tempNode.classList.add('synchronizing');
                }
                VScroll.trimMessagesForCache(cacheNode.querySelector('.msg-messages-container'), this._cacheListLimit);
                if (!cacheNode.querySelector('.msg-messages-sync-more')) {
                    let syncContainer = cacheNode.querySelector('.msg-messages-sync-container');
                    if (syncContainer) {
                        syncContainer.appendChild(this.syncMoreNode.cloneNode(true));
                    }
                }
                htmlCache.saveFromNode(module.id, cacheNode);
            },
            _considerCacheDom: function (index) {
                if (!this._cacheDomTimeoutId && this._isCacheableCardState() && this.vScroll.firstRenderedIndex === 0 && (index || index === 0) && index < this._cacheListLimit && this.className === 'card center') {
                    this._cacheDomTimeoutId = setTimeout(this._cacheDom.bind(this), 600);
                }
            },
            _clearCachedMessages: function () {
                if (this.usingCachedNode) {
                    this.messagesContainer.innerHTML = '';
                    this.usingCachedNode = false;
                }
            },
            loadNextChunk: function (desiredHighAbsoluteIndex) {
                if (this.vScroll.waitingForRecalculate) {
                    return;
                }
                if (this.waitingOnChunk) {
                    this.desiredHighAbsoluteIndex = desiredHighAbsoluteIndex;
                    return;
                }
                if (desiredHighAbsoluteIndex >= headerCursor.messagesSlice.headerCount) {
                    desiredHighAbsoluteIndex = headerCursor.messagesSlice.headerCount - 1;
                }
                let items = headerCursor.messagesSlice.items;
                let curHighAbsoluteIndex = items.length - 1;
                let amount = desiredHighAbsoluteIndex - curHighAbsoluteIndex;
                if (amount > 0) {
                    console.log('message_list loadNextChunk growing', amount, amount === 1 ? '(will get boosted to 15!) to' : 'to', desiredHighAbsoluteIndex + 1, 'items out of', headerCursor.messagesSlice.headerCount, 'alleged known');
                    headerCursor.messagesSlice.requestGrowth(amount, false);
                    this.waitingOnChunk = true;
                }
            },
            messages_splice: function (index, howMany, addedItems, requested, moreExpected, fake) {
                if (headerCursor.searchMode !== this.mode || index === 0 && howMany === 0 && !addedItems.length) {
                    return;
                }
                this._clearCachedMessages();
                if (this._needVScrollData) {
                    let count = headerCursor.messagesSlice.headerCount;
                    this.vScroll.setListNodeCount(count);
                    this.vScroll.setData(this.listFunc);
                    this._needVScrollData = false;
                }
                this.vScroll.updateDataBind(index, addedItems, howMany);
                if (addedItems.length > 0) {
                    this.hideEmptyLayout();
                }
                if (this.mode === 'search') {
                    if (this.searchResultNeedUpdate) {
                        this.searchMessages = headerCursor.messagesSlice.headerCount;
                        this.toggleSearchCount(this.searchMessages);
                        this.searchResultNeedUpdate = false;
                    }
                }
                if (!headerCursor.messagesSlice.headerCount) {
                    this.vScroll.once('scrollStopped', () => {
                        if (!headerCursor.messagesSlice.headerCount) {
                            this.showEmptyLayout();
                        }
                    });
                } else {
                    NavigationMap.messageListMailCount = headerCursor.messagesSlice.headerCount;
                }
                if (howMany > 0 && addedItems.length === 0) {
                    this.setMessageListFocus(true, false);
                }
                if (addedItems.length || howMany) {
                    this._considerCacheDom(index);
                }
            },
            messages_change: function (message, index) {
                if (headerCursor.searchMode !== this.mode) {
                    return;
                }
                if (this.mode === 'nonsearch') {
                    this.onMessagesChange(message, index);
                } else {
                    this.updateMatchedMessageDom(false, message);
                }
                if (message) {
                    this.selectedMessagesUpdated();
                }
            },
            onMessagesChange: function (message, index) {
                this.updateMessageDom(false, message);
                this._considerCacheDom(index);
                if (this.curFolder.type === 'outbox') {
                    let status = message.sendStatus && message.sendStatus.state;
                    if (status !== 'sending') {
                        this.toggleOutboxSyncingDisplay(false);
                    }
                }
            },
            _updatePeepDom: function (peep) {
                if (peep.element) {
                    peep.element.textContent = peep.contactName || peep.name || peep.address;
                }
                if (peep.photoNode) {
                    let url = 'url(style/images/icons/contacts_icon.png)';
                    if (peep._thumbnailBlob) {
                        url = 'url(' + URL.createObjectURL(new Blob([peep.photoBlob])) + '), ' + url;
                    }
                    peep.photoNode.style.backgroundImage = url;
                    URL.revokeObjectURL(url);
                }
            },
            updateMessageDom: function (firstTime, message) {
                let msgNode = message.element;
                if (!msgNode) {
                    return;
                }
                let classAction = message.isPlaceholderData ? 'add' : 'remove';
                msgNode.classList[classAction](this.vScroll.itemDefaultDataClass);
                msgNode.dataset.id = message.id;
                let dateNode = msgNode.querySelector('.msg-header-date');
                let subjectNode = msgNode.querySelector('.msg-header-subject');
                let snippetNode = msgNode.querySelector('.msg-header-snippet');
                let avatarNode = msgNode.querySelector('.msg-header-avatar-section');
                if (firstTime) {
                    let listPerson;
                    if (this.isIncomingFolder) {
                        listPerson = message.author;
                    } else if (message.to && message.to.length) {
                        listPerson = message.to[0];
                    } else if (message.cc && message.cc.length) {
                        listPerson = message.cc[0];
                    } else if (message.bcc && message.bcc.length) {
                        listPerson = message.bcc[0];
                    }
                    if (listPerson) {
                        listPerson.element = msgNode.querySelector('.msg-header-author');
                        listPerson.photoNode = avatarNode;
                        listPerson.onchange = this._updatePeepDom;
                        listPerson.onchange(listPerson);
                    } else {
                        msgNode.querySelector('.msg-header-author').textContent = '';
                    }
                    if (message.date) {
                        let dateTime = message.date.valueOf();
                        dateNode.dataset.time = dateTime;
                        dateNode.textContent = dateTime ? date.prettyDate(message.date) : '';
                    }
                    messageDisplay.subject(msgNode.querySelector('.msg-header-subject'), message);
                    let attachmentsNode = msgNode.querySelector('.msg-header-attachments');
                    attachmentsNode.classList.toggle('msg-header-attachments-yes', message.hasAttachments);
                    snippetNode.classList.toggle('icon-short', message.hasAttachments);
                }
                snippetNode.textContent = message.snippet;
                msgNode.classList.toggle('unread', !message.isRead);
                msgNode.classList.toggle('reply', message.isRepliedTo);
                msgNode.classList.toggle('forward', message.isForwarded);
                let starNode = msgNode.querySelector('.msg-header-star');
                starNode.classList.toggle('msg-header-star-starred', message.isStarred);
                subjectNode.classList.toggle('icon-short', message.isStarred);
                let syncNode = msgNode.querySelector('.msg-header-syncing-section');
                let sendState = message.sendStatus && message.sendStatus.state;
                syncNode.classList.toggle('msg-header-syncing-section-syncing', sendState === 'sending');
                syncNode.classList.toggle('msg-header-syncing-section-error', sendState === 'error');
                if (sendState) {
                    mozL10n.setAttributes(syncNode, 'message-header-state-' + sendState);
                } else {
                    syncNode.removeAttribute('data-l10n-id');
                }
                this.setSelectState(msgNode, message);
            },
            updateMatchedMessageDom: function (firstTime, matchedHeader) {
                let msgNode = matchedHeader.element, matches = matchedHeader.matches, message = matchedHeader.header;
                if (!msgNode) {
                    return;
                }
                let classAction = message.isPlaceholderData ? 'add' : 'remove';
                msgNode.classList[classAction](this.vScroll.itemDefaultDataClass);
                msgNode.dataset.id = matchedHeader.id;
                let dateNode = msgNode.querySelector('.msg-header-date');
                let subjectNode = msgNode.querySelector('.msg-header-subject');
                let avatarNode = msgNode.querySelector('.msg-header-avatar-section');
                if (firstTime) {
                    let authorNode = msgNode.querySelector('.msg-header-author');
                    if (matches.author) {
                        authorNode.textContent = '';
                        appendMatchItemTo(matches.author, authorNode);
                        message.author.element = null;
                    } else {
                        message.author.element = authorNode;
                    }
                    message.author.photoNode = avatarNode;
                    message.author.onchange = this._updatePeepDom;
                    message.author.onchange(message.author);
                    if (message.date) {
                        dateNode.dataset.time = message.date.valueOf();
                        dateNode.textContent = date.prettyDate(message.date);
                    }
                    if (matches.subject) {
                        subjectNode.textContent = '';
                        appendMatchItemTo(matches.subject[0], subjectNode);
                    } else {
                        messageDisplay.subject(subjectNode, message);
                    }
                    let snippetNode = msgNode.querySelector('.msg-header-snippet');
                    if (matches.body) {
                        snippetNode.textContent = '';
                        appendMatchItemTo(matches.body[0], snippetNode);
                    } else {
                        snippetNode.textContent = message.snippet;
                    }
                    let attachmentsNode = msgNode.querySelector('.msg-header-attachments');
                    attachmentsNode.classList.toggle('msg-header-attachments-yes', message.hasAttachments);
                    snippetNode.classList.toggle('icon-short', message.hasAttachments);
                }
                msgNode.classList.toggle('unread', !message.isRead);
                msgNode.classList.toggle('reply', message.isRepliedTo);
                msgNode.classList.toggle('forward', message.isForwarded);
                let starNode = msgNode.querySelector('.msg-header-star');
                starNode.classList.toggle('msg-header-star-starred', message.isStarred);
                subjectNode.classList.toggle('icon-short', message.isStarred);
                this.setSelectState(msgNode, message);
            },
            setSelectState: function (msgNode, message) {
                if (this.editMode) {
                    let bCheck = false;
                    if (this.selectedMessages.length > 0) {
                        for (let i = 0; i < this.selectedMessages.length; i++) {
                            if (this.selectedMessages[i].id === message.id) {
                                bCheck = true;
                                break;
                            }
                        }
                    }
                    this.setMessageChecked(msgNode, bCheck);
                } else {
                    msgNode.removeAttribute('aria-selected');
                }
            },
            setMessageChecked: function (msgNode, checked) {
                let checkbox = msgNode.querySelector('input[type=checkbox]');
                checkbox.checked = checked;
                msgNode.setAttribute('aria-selected', checked);
            },
            onFolderShown: function () {
                if (this.mode === 'search') {
                    return;
                }
                let account = model.account, foldersSlice = model.foldersSlice;
                if (!document.hidden && account && foldersSlice && this.curFolder) {
                    let inboxFolder = foldersSlice.getFirstFolderWithType('inbox');
                    if (inboxFolder === this.curFolder) {
                        evt.emit('inboxShown', account.id);
                    }
                }
            },
            onCurrentCardDocumentVisibilityChange: function (evt) {
                this.onFolderShown();
                if (cards._backgroundUpdate && !evt) {
                    this.onCardVisible('forward');
                    cards._backgroundUpdate = false;
                }
            },
            sortElements: function (elements) {
                let arrayElements = Array.prototype.slice.call(elements);
                let syncmore;
                let syncmoreindex;
                arrayElements.forEach(item => {
                    if (item.classList.contains('msg-messages-sync-more')) {
                        syncmore = item;
                    }
                });
                if (syncmore) {
                    syncmoreindex = arrayElements.indexOf(syncmore);
                    let headPart = arrayElements.slice(0, syncmoreindex);
                    let tailPart = arrayElements.slice(syncmoreindex + 1);
                    arrayElements = headPart.concat(tailPart);
                }
                arrayElements.sort((a, b) => {
                    return a.dataset.index - b.dataset.index;
                });
                if (syncmore) {
                    arrayElements.push(syncmore);
                }
                return arrayElements;
            },
            onCardVisible: function (navDirection) {
                if (this._whenVisible) {
                    let fn = this._whenVisible;
                    this._whenVisible = null;
                    fn();
                }
                let cacheSoftkeyNode = document.getElementById('cachedSoftkeyPanel');
                if (cacheSoftkeyNode) {
                    document.body.removeChild(cacheSoftkeyNode);
                }
                NavigationMap.searchMode = false;
                if (this.mode === 'search') {
                    if (this.isFirstTimeVisible) {
                        mozL10n.setAttributes(this.filterType, 'message-search-all');
                    }
                    NavigationMap.searchMode = true;
                    if (!this.keydownForSearchHander) {
                        this.keydownForSearchHander = this.handleKeydownForSearch.bind(this);
                        window.addEventListener('keydown', this.keydownForSearchHander);
                    }
                    this.searchInputLi.addEventListener('focus', () => {
                        this.searchInput.focus();
                        let inputLength = this.searchInput.value.length;
                        this.searchInput.setSelectionRange(inputLength, inputLength);
                    });
                } else if (this.mode === 'nonsearch') {
                    if (!this.keydownHandler) {
                        this.keydownHandler = this.handleKeydown.bind(this);
                        window.addEventListener('keydown', this.keydownHandler);
                    }
                }
                NavigationMap.cardContentHeight = this.scrollContainer.clientHeight;
                this.isFirstTimeVisible = false;
                this.vScroll.nowVisible();
                let CARD_NAME = this.localName;
                let CONTROL_ID;
                if (this.mode === 'search') {
                    CONTROL_ID = CARD_NAME + ' .focusable, ' + CARD_NAME + ' ' + QUERY_CHILD;
                } else {
                    CONTROL_ID = CARD_NAME + ' ' + QUERY_CHILD;
                }
                if (navDirection === 'forward') {
                    this.initOption();
                    NavigationMap.setCurrentControl(CONTROL_ID);
                    NavigationMap.navSetup(CARD_NAME, QUERY_CHILD, this.sortElements);
                    let focusIndex = this.mode === 'search' ? 1 : 'first';
                    NavigationMap.setFocus(focusIndex);
                    NavigationMap.observeChild(CARD_NAME, QUERY_CHILD, this.sortElements);
                } else if (navDirection === 'back') {
                    NavigationMap.setCurrentControl(CONTROL_ID);
                    let curControl = NavigationMap.getCurrentControl();
                    if (!curControl || curControl.container.className !== 'card center' || !NavigationMap.currentMessageId) {
                        this.initOption();
                        NavigationMap.navSetup(CARD_NAME, QUERY_CHILD, this.sortElements);
                        NavigationMap.observeChild(CARD_NAME, QUERY_CHILD, this.sortElements);
                    }
                    if (this.mode === 'search' && this.curFolder.type === 'localdrafts' && this.searchInput.value) {
                        this.showSearch(this.searchInput.value, this.curFilter);
                    }
                    this.setMessageListFocus(false, false);
                }
                if (this.isShowEmpty) {
                    setTimeout(() => {
                        this.messageEmptyText.focus();
                    }, 3000);
                }
                if (this.mode === 'nonsearch') {
                    this.scrollContainer.setAttribute('role', 'heading');
                    this.scrollContainer.setAttribute('aria-labelledby', 'folder-header');
                }
                if (!cards._cardDefs['message_reader']) {
                    require(['element!cards/message_reader'], Ctor => {
                        cards._cardDefs['message_reader'] = Ctor;
                    });
                }
            },
            setMessageListFocus: function (bDelete, bSync) {
                let currentId;
                if (this.mode === 'search') {
                    currentId = NavigationMap.currentSearchId;
                } else {
                    currentId = NavigationMap.currentMessageId;
                }
                if (currentId !== 'INVALID') {
                    console.log('Message list: set focus list id : ' + currentId);
                    if (bSync && currentId === 'load-more') {
                        currentId = null;
                    }
                    NavigationMap.setMessageListFocus(currentId, bDelete);
                } else {
                    let focused = document.querySelector('.focus');
                    if (focused && focused.message) {
                        currentId = focused.message.id;
                        NavigationMap.setMessageListFocus(currentId, bDelete);
                    }
                }
            },
            onClickMessage: function (messageNode, event) {
                if (this.curFolder && this.curFolder.type === 'outbox' && this.outboxSyncInProgress) {
                    return;
                }
                let header = messageNode.message;
                if (header && header.isPlaceholderData) {
                    return;
                }
                if (this.editMode) {
                    let idx = this.selectedMessages.indexOf(header);
                    if (idx !== -1) {
                        this.selectedMessages.splice(idx, 1);
                    } else {
                        this.selectedMessages.push(header);
                    }
                    this.setMessageChecked(messageNode, idx === -1);
                    this.selectedMessagesUpdated();
                    return;
                }
                if (this.curFolder && this.curFolder.type === 'localdrafts') {
                    let composer = header.editAsDraft(() => {
                        cards.pushCard('compose', 'animate', { composer: composer });
                    });
                    return;
                }
                if (this.curFolder && this.curFolder.type === 'outbox') {
                    if (header.sendStatus.state === 'sending') {
                        return;
                    }
                    let draftsFolder = model.foldersSlice.getFirstFolderWithType('localdrafts');
                    console.log('outbox: Moving message to localdrafts.');
                    model.api.moveMessages([header], draftsFolder, moveMap => {
                        header.id = moveMap[header.id];
                        console.log('outbox: Editing message in localdrafts.');
                        let composer = header.editAsDraft(() => {
                            cards.pushCard('compose', 'animate', { composer: composer });
                        });
                    });
                    return;
                }
                let pushMessageCard = () => {
                    cards.pushCard('message_reader', 'animate', {
                        header: header,
                        messageSuid: messageNode.dataset.id,
                        curFolder: this.curFolder
                    });
                };
                if (header) {
                    headerCursor.setCurrentMessage(header);
                } else if (messageNode.dataset.id) {
                    headerCursor.setCurrentMessageBySuid(messageNode.dataset.id);
                } else {
                    return;
                }
                window.performance.mark('mail-load-start');
                pushMessageCard();
            },
            onCurrentMessage: function (currentMessage, index) {
                if (!currentMessage || headerCursor.searchMode !== this.mode) {
                    return;
                }
                let visibleIndices = this.vScroll.getVisibleIndexRange();
                if (visibleIndices && (index < visibleIndices[0] || index > visibleIndices[1])) {
                    this.vScroll.jumpToIndex(index);
                }
            },
            onHoldMessage: function (messageNode, event) {
                if (this.curFolder) {
                    this.setEditMode(true);
                }
            },
            toggleOutboxSyncingDisplay: function (syncing) {
                if (syncing === this._outboxSyncing) {
                    return;
                }
                this._outboxSyncing = syncing;
                let items = this.messagesContainer.getElementsByClassName('msg-header-syncing-section');
                if (syncing) {
                    for (let i = 0; i < items.length; i++) {
                        items[i].classList.add('msg-header-syncing-section-syncing');
                        items[i].classList.remove('msg-header-syncing-section-error');
                    }
                } else {
                    for (let i = 0; i < items.length; i++) {
                        items[i].classList.remove('msg-header-syncing-section-syncing');
                    }
                }
                this.setRefreshState(syncing);
            },
            onRefresh: function () {
                if (!headerCursor.messagesSlice) {
                    return;
                }
                if (this.curFolder.type === 'outbox') {
                    this.toggleOutboxSyncingDisplay(true);
                } else {
                    switch (headerCursor.messagesSlice.status) {
                    case 'new':
                    case 'synchronizing':
                        break;
                    case 'synced':
                        this._manuallyTriggeredSync = true;
                        headerCursor.messagesSlice.refresh();
                        break;
                    case 'syncfailed':
                        if (headerCursor.messagesSlice.items.length) {
                            headerCursor.messagesSlice.refresh();
                        } else {
                            this.showFolder(this.curFolder, true);
                        }
                        break;
                    }
                }
                model.api.sendOutboxMessages(model.account);
                this.setSoftkeyBar();
            },
            onStarMessages: function (arg) {
                let setValue = arg === undefined ? this.setAsStarred : arg;
                let op = model.api.markMessagesStarred(this.selectedMessages, setValue);
                this.setEditMode(false);
                toaster.toastOperation(op);
            },
            onMarkMessagesRead: function (arg) {
                let setValue = arg === undefined ? this.setAsRead : arg;
                let op = model.api.markMessagesRead(this.selectedMessages, setValue);
                this.setEditMode(false);
                toaster.toastOperation(op);
            },
            onDeleteMessages: function () {
                if (this.selectedMessages.length === 0) {
                    return;
                }
                let dialogConfig = {
                    title: {
                        id: 'confirm-dialog-title',
                        args: {}
                    },
                    body: {
                        id: 'message-multiedit-delete-confirm',
                        args: { n: this.selectedMessages.length }
                    },
                    cancel: {
                        l10nId: 'message-delete-cancel',
                        priority: 1
                    },
                    confirm: {
                        l10nId: 'message-edit-menu-delete',
                        priority: 3,
                        callback: () => {
                            let op = model.api.deleteMessages(this.selectedMessages);
                            this.updateSearchResult();
                            toaster.toastOperation(op);
                            this.setEditMode(false);
                            if (!this.editMode && this.mode === 'search') {
                                this.searchResultNeedUpdate = true;
                            }
                        }
                    }
                };
                NavigationMap.showConfigDialog(dialogConfig);
            },
            updateSearchResult: function () {
                this.searchMessages = this.searchMessages - this.selectedMessages.length;
                this.toggleSearchCount(this.searchMessages);
            },
            showLargeMessageWarning: function (size, cb) {
                let dialogConfig = {
                    title: {
                        id: 'confirm-dialog-title',
                        args: {}
                    },
                    body: { id: 'message-large-message-confirm' },
                    cancel: {
                        l10nId: 'msg-large-message-cancel',
                        priority: 1,
                        callback: () => {
                            cb(true);
                        }
                    },
                    confirm: {
                        l10nId: 'msg-large-message-ok',
                        priority: 3,
                        callback: () => {
                            cb(true);
                        }
                    }
                };
                NavigationMap.showConfigDialog(dialogConfig);
            },
            onMoveMessages: function () {
                cards.folderSelector(folder => {
                    let op = model.api.moveMessages(this.selectedMessages, folder);
                    this.updateSearchResult();
                    toaster.toastOperation(op);
                    this.setEditMode(false);
                }, folder => {
                    return folder.isValidMoveTarget;
                }, this.curFolder);
            },
            _folderChanged: function (folder) {
                if (!model.foldersSlice) {
                    return;
                }
                if (this.curFolder) {
                    this.curFolder.sortType = 'date';
                }
                let inboxFolder = model.foldersSlice.getFirstFolderWithType('inbox');
                this.cacheableFolderId = model.account === model.acctsSlice.defaultAccount ? inboxFolder.id : null;
                this.folder = folder;
                if (this.mode === 'nonsearch') {
                    NavigationMap.currentMessageId = null;
                    if (this.showFolder(folder)) {
                        this._hideSearchBoxByScrolling();
                    }
                } else {
                    this.showSearch('', 'all');
                }
            },
            onJumptoHead: function () {
                this.vScroll.jumpToIndex(0);
                this.action = 'top';
            },
            onJumptoTail: function () {
                let mailCount = headerCursor.messagesSlice.headerCount;
                this.vScroll.jumpToIndex(mailCount - 1);
                this.action = 'bottom';
            },
            doScrollAction: function () {
                let action = this.action;
                if (!action) {
                    return;
                }
                let elements = NavigationMap.getCurrentControl().elements;
                switch (action) {
                case 'top':
                    let firstIndex;
                    for (let i = 0; i < elements.length; i++) {
                        if (!elements[i].classList.contains('msg-messages-sync-more') && elements[i].dataset.index === '0') {
                            firstIndex = i;
                        }
                    }
                    NavigationMap.setFocus(firstIndex);
                    break;
                case 'bottom':
                    let lastIndex;
                    let mailCount = headerCursor.messagesSlice.headerCount;
                    for (let i = 0; i < elements.length; i++) {
                        if (elements[i].classList.contains('msg-messages-sync-more')) {
                            lastIndex = elements.length - 1;
                        } else if (elements[i].dataset.index === (mailCount - 1).toString()) {
                            lastIndex = i;
                        }
                    }
                    if (lastIndex) {
                        NavigationMap.setFocus(lastIndex);
                    }
                    break;
                case 'new':
                    let messageId = headerCursor.messagesSlice.items[0].id;
                    if (messageId) {
                        NavigationMap.setMessageListFocus(messageId, false);
                    }
                    break;
                }
                this.action = null;
            },
            onEmptyTrash: function () {
                function loadAllMessagesAndDelete() {
                    let length = headerCursor.messagesSlice.items.length;
                    let headerCount = headerCursor.messagesSlice.headerCount;
                    if (length < headerCount) {
                        headerCursor.messagesSlice.requestGrowth(1, true);
                        headerCursor.messagesSlice.oncomplete = function () {
                            loadAllMessagesAndDelete();
                        };
                    } else {
                        let op = model.api.deleteMessages(headerCursor.messagesSlice.items);
                        if (op) {
                            toaster.toast({ text: mozL10n.get('trash-emptied') });
                        }
                    }
                }
                let dialogConfig = {
                    title: {
                        id: 'confirm-dialog-title',
                        args: {}
                    },
                    body: {
                        id: 'empty-trash-confirm',
                        args: {}
                    },
                    cancel: {
                        l10nId: 'cancel',
                        priority: 1
                    },
                    confirm: {
                        l10nId: 'empty',
                        priority: 3,
                        callback: () => {
                            loadAllMessagesAndDelete();
                        }
                    }
                };
                NavigationMap.showConfigDialog(dialogConfig);
            },
            die: function () {
                this.sliceEvents.forEach(type => {
                    let name = 'messages_' + type;
                    headerCursor.removeListener(name, this[name]);
                });
                model.removeListener('folder', this._folderChanged);
                model.removeListener('newInboxMessages', this.onNewMail);
                model.removeListener('foldersSliceOnChange', this.onFoldersSliceChange);
                model.removeListener('backgroundSendStatus', this.onBackgroundSendStatus);
                headerCursor.removeListener('currentMessage', this.onCurrentMessage);
                headerCursor.removeListener('messageSorted', this.onMessageSorted);
                this.vScroll.destroy();
                window.removeEventListener('keydown', this.keydownHandler);
                window.removeEventListener('keydown', this.keydownForSearchHander);
                window.removeEventListener('transitionend', this.transitionendFn);
                this.keydownHandler = null;
                this.keydownForSearchHander = null;
            },
            searchFilter: [
                'search-author',
                'search-to',
                'search-subject',
                'search-body',
                'search-all'
            ],
            initOption: function () {
                let optCompose = {
                    name: 'Compose',
                    l10nId: 'opt-compose',
                    priority: 1,
                    method: this.onCompose.bind(this)
                };
                let optSelect = {
                    name: 'Select',
                    l10nId: 'select',
                    priority: 2
                };
                let optDeSelect = {
                    name: 'Deselect',
                    l10nId: 'deselect',
                    priority: 2
                };
                let optMarkRead = {
                    name: 'Mark as Read',
                    l10nId: 'opt-mark-read',
                    priority: 5,
                    method: this.onMarkMessagesRead.bind(this)
                };
                let optAddFlag = {
                    name: 'Add Flag',
                    l10nId: 'opt-add-flag',
                    priority: 5,
                    method: this.onStarMessages.bind(this)
                };
                let optMove = {
                    name: 'Move to Folder',
                    l10nId: 'opt-move-message',
                    priority: 5,
                    method: this.onMoveMessages.bind(this)
                };
                let optDelete = {
                    name: 'Delete',
                    l10nId: 'opt-delete-message',
                    priority: 5,
                    method: this.onDeleteMessages.bind(this)
                };
                let optMultiSelect = {
                    name: 'Select Multiple',
                    l10nId: 'opt-multi-select',
                    priority: 5,
                    method: this.setEditModeStart.bind(this)
                };
                let optSearch = {
                    name: 'Search',
                    l10nId: 'opt-search',
                    priority: 5,
                    method: this.onSearchButton.bind(this)
                };
                let optShowFolders = {
                    name: 'View Folders',
                    l10nId: 'opt-folders',
                    priority: 5,
                    method: this.onShowFolders.bind(this)
                };
                let optSort = {
                    name: 'Sort',
                    l10nId: 'opt-sort',
                    priority: 5,
                    method: this.onSortMessages.bind(this)
                };
                let optSynchronize = {
                    name: 'Synchronize',
                    l10nId: 'opt-sync',
                    priority: 5,
                    method: this.onRefresh.bind(this)
                };
                let optSwitchAccount = {
                    name: 'Switch Account',
                    l10nId: 'opt-account',
                    priority: 5,
                    method: this.onSwitchAccount.bind(this)
                };
                let optSettings = {
                    name: 'Settings',
                    l10nId: 'opt-settings',
                    priority: 5,
                    method: this.onShowSettings.bind(this)
                };
                let optEmptyTrash = {
                    name: 'Empty Trash',
                    l10nId: 'opt-empty-trash',
                    priority: 5,
                    method: this.onEmptyTrash.bind(this)
                };
                let optEdit = {
                    id: 'edit',
                    name: 'Edit',
                    l10nId: 'opt-edit',
                    priority: 5
                };
                let optSubMove = {
                    fid: 'edit',
                    name: 'Move to Folder',
                    l10nId: 'opt-move-message',
                    priority: 5,
                    method: this.onMoveMessages.bind(this)
                };
                let optSubMultiSelect = {
                    fid: 'edit',
                    name: 'Select Multiple',
                    l10nId: 'opt-multi-select',
                    priority: 5,
                    method: this.setEditModeStart.bind(this)
                };
                let optCancelEdit = {
                    name: 'Cancel',
                    l10nId: 'opt-cancel',
                    priority: 1,
                    method: this.setEditModeDone.bind(this)
                };
                let optCancelSearch = {
                    name: 'Cancel',
                    l10nId: 'opt-cancel',
                    priority: 1,
                    method: this.onCancelSearch.bind(this)
                };
                this.optionSelectRead = {
                    name: 'Mark as Read',
                    l10nId: 'opt-mark-read',
                    priority: 5,
                    method: () => {
                        this.onMarkMessagesRead(true);
                    }
                };
                this.optionSelectUnread = {
                    name: 'Mark as Unread',
                    l10nId: 'opt-mark-unread',
                    priority: 5,
                    method: () => {
                        this.onMarkMessagesRead(false);
                    }
                };
                this.optionSelectStar = {
                    name: 'Add Flag',
                    l10nId: 'opt-add-flag',
                    priority: 5,
                    method: () => {
                        this.onStarMessages(true);
                    }
                };
                this.optionSelectUnstar = {
                    name: 'Remove Flag',
                    l10nId: 'opt-remove-flag',
                    priority: 5,
                    method: () => {
                        this.onStarMessages(false);
                    }
                };
                this.optionSelectCancel = optCancelEdit;
                this.optionSelect = optSelect;
                this.optionDeselect = optDeSelect;
                this.optionCsk = optSelect;
                this.optionSelectMove = optMove;
                this.optionSelectDelete = optDelete;
                this.optionMain = [
                    optCompose,
                    optSelect,
                    optDelete,
                    optMarkRead,
                    optAddFlag,
                    optEdit,
                    optSubMove,
                    optSubMultiSelect,
                    optSearch,
                    optShowFolders,
                    optSort,
                    optSynchronize,
                    optSwitchAccount,
                    optSettings
                ];
                this.optionNoSyncEmpty = [
                    optCompose,
                    optShowFolders,
                    optSwitchAccount,
                    optSettings
                ];
                this.optionEmpty = [
                    optCompose,
                    optShowFolders,
                    optSynchronize,
                    optSwitchAccount,
                    optSettings
                ];
                this.loadMore = [
                    optCompose,
                    optSelect,
                    optShowFolders,
                    optSynchronize,
                    optSwitchAccount,
                    optSettings
                ];
                this.optionSearch = [
                    optCancelSearch,
                    optSelect,
                    optMarkRead,
                    optAddFlag,
                    optMove,
                    optDelete,
                    optMultiSelect,
                    optSettings
                ];
                this.optionSearchSingle = [
                    optCancelSearch,
                    optSelect,
                    optMarkRead,
                    optAddFlag,
                    optMove,
                    optDelete,
                    optSettings
                ];
                this.optionOutbox = [
                    optCompose,
                    optSelect,
                    optDelete,
                    optEdit,
                    optSubMultiSelect,
                    optSearch,
                    optShowFolders,
                    optSort,
                    optSynchronize,
                    optSwitchAccount,
                    optSettings
                ];
                this.optionOutboxSyncing = [
                    optCompose,
                    optSelect,
                    optSearch,
                    optShowFolders,
                    optSort,
                    optSwitchAccount,
                    optSettings
                ];
                this.optionOutboxSelect = [
                    optCancelEdit,
                    optSelect,
                    optDelete
                ];
                this.optionOutboxSearch = [
                    optCancelSearch,
                    optSelect,
                    optDelete,
                    optMultiSelect,
                    optSettings
                ];
                this.optionOutboxSearchSingle = [
                    optCancelSearch,
                    optSelect,
                    optDelete,
                    optSettings
                ];
                this.optionLocalDrafts = [
                    optCompose,
                    optSelect,
                    optDelete,
                    optMarkRead,
                    optAddFlag,
                    optEdit,
                    optSubMultiSelect,
                    optSearch,
                    optShowFolders,
                    optSort,
                    optSwitchAccount,
                    optSettings
                ];
                this.optionLocalDraftsSelect = [
                    optCancelEdit,
                    optSelect,
                    optMarkRead,
                    optAddFlag,
                    optDelete
                ];
                this.optionLocalDraftsSearch = [
                    optCancelSearch,
                    optSelect,
                    optMarkRead,
                    optAddFlag,
                    optDelete,
                    optMultiSelect,
                    optSettings
                ];
                this.optionLocalDraftsSearchSingle = [
                    optCancelSearch,
                    optSelect,
                    optMarkRead,
                    optAddFlag,
                    optDelete,
                    optSettings
                ];
                this.optionTrash = [
                    optCompose,
                    optSelect,
                    optEmptyTrash,
                    optDelete,
                    optMarkRead,
                    optAddFlag,
                    optEdit,
                    optSubMove,
                    optSubMultiSelect,
                    optSearch,
                    optShowFolders,
                    optSort,
                    optSynchronize,
                    optSwitchAccount,
                    optSettings
                ];
                this.optMarkRead = optMarkRead;
                this.optAddFlag = optAddFlag;
                this.optEditDone = [
                    optCancelEdit,
                    this.optionCsk
                ];
                this.optCancelSearch = optCancelSearch;
            },
            setSoftkeyBar: function () {
                let currentCard = cards.getCurrentCardType();
                if (!cards.isVisible(this) || !this.selectedMessages || currentCard !== 'message_list' && currentCard !== 'message_list_search') {
                    return;
                }
                let options = [];
                if (this.editMode) {
                    if (this.selectedMessages.length > 0) {
                        switch (model.folder.type) {
                        case 'localdrafts':
                            this.optionLocalDraftsSelect[1] = this.optionCsk;
                            options = this.optionLocalDraftsSelect;
                            break;
                        case 'outbox':
                            this.optionOutboxSelect[1] = this.optionCsk;
                            options = this.optionOutboxSelect;
                            break;
                        default:
                            options.push(this.optionSelectCancel, this.optionCsk);
                            this.setReadBoth ? options.push(this.optionSelectRead, this.optionSelectUnread) : this.setAllAsRead ? options.push(this.optionSelectRead) : options.push(this.optionSelectUnread);
                            this.setFlagBoth ? options.push(this.optionSelectStar, this.optionSelectUnstar) : this.setAllAsStarred ? options.push(this.optionSelectStar) : options.push(this.optionSelectUnstar);
                            options.push(this.optionSelectMove, this.optionSelectDelete);
                            break;
                        }
                    } else {
                        options = this.optEditDone;
                    }
                } else {
                    if (this.mode === 'search') {
                        if (this.selectedMessages.length > 0) {
                            switch (model.folder.type) {
                            case 'localdrafts':
                                if (this.searchMessages === 1) {
                                    options = this.optionLocalDraftsSearchSingle;
                                } else {
                                    options = this.optionLocalDraftsSearch;
                                }
                                break;
                            case 'outbox':
                                if (this.searchMessages === 1) {
                                    options = this.optionOutboxSearchSingle;
                                } else {
                                    options = this.optionOutboxSearch;
                                }
                                break;
                            default:
                                if (this.searchMessages === 1) {
                                    options = this.optionSearchSingle;
                                } else {
                                    options = this.optionSearch;
                                }
                                break;
                            }
                        } else {
                            options = [this.optCancelSearch];
                        }
                    } else if (this.mode === 'nonsearch') {
                        if (typeof window.option !== 'undefined') {
                            if (window.option.menuVisible) {
                                return;
                            }
                        }
                        let itemLength = 0;
                        if (headerCursor.hasOwnProperty('messagesSlice')) {
                            itemLength = headerCursor.messagesSlice.items.length;
                        }
                        if (itemLength > 0 && this.selectedMessages.length > 0) {
                            switch (model.folder.type) {
                            case 'localdrafts':
                                options = this.optionLocalDrafts;
                                break;
                            case 'outbox':
                                if (this._outboxSyncing) {
                                    options = this.optionOutboxSyncing;
                                } else {
                                    options = this.optionOutbox;
                                }
                                break;
                            case 'trash':
                                options = this.optionTrash;
                                break;
                            default:
                                options = this.optionMain;
                                break;
                            }
                        } else {
                            if (model.folder && (model.folder.type === 'localdrafts' || model.folder.type === 'outbox')) {
                                options = this.optionNoSyncEmpty;
                            } else {
                                if (NavigationMap.currentMessageId === 'load-more' && !this.isShowEmpty) {
                                    options = this.loadMore;
                                } else {
                                    options = this.optionEmpty;
                                }
                            }
                        }
                    }
                }
                NavigationMap.setSoftKeyBar(options);
            },
            onFocusChanged: function (queryChild, index, item) {
                console.log(this.localName + '.onFocusChanged, queryChild=' + queryChild + '', index = '' + index);
                if (this.className !== 'card center') {
                    return;
                }
                if (index === 'jumpToHead') {
                    this.onJumptoHead();
                } else if (index === 'jumpToTail') {
                    this.onJumptoTail();
                }
                if (!this.editMode) {
                    if (item && item.message && !item.message.isPlaceholderData) {
                        this.selectedMessages = [item.message];
                    } else {
                        this.selectedMessages = [];
                    }
                }
                this.selectedMessagesUpdated();
            },
            onHidden: function () {
                console.log(this.localName + '.onHidden');
                window.removeEventListener('keydown', this.keydownHandler);
                window.removeEventListener('keydown', this.keydownForSearchHander);
                this.keydownHandler = null;
                this.keydownForSearchHander = null;
            },
            onShowSettings: function () {
                cards.pushCard('settings_main', 'animate');
            },
            onSwitchAccount: function () {
                console.log(this.localName + '.onSwitchAccount');
                cards.pushCard('account_picker', 'animate');
            },
            onSortMessages: function () {
                console.log(this.localName + '.onSortMessages');
                require([
                    'model',
                    'value_selector'
                ], (model, ValueSelector) => {
                    let optCancel = {
                        name: 'Cancel',
                        l10nId: 'opt-cancel',
                        priority: 1,
                        method: () => {
                            this.sortSelector.hide();
                        }
                    };
                    let optSelect = {
                        name: 'Select',
                        l10nId: 'select',
                        priority: 2
                    };
                    let options = [
                        optCancel,
                        optSelect
                    ];
                    if (!this.sortSelector) {
                        this.sortSelector = new ValueSelector('sort-by-title', [], options);
                    } else {
                        this.sortSelector.List.length = 0;
                    }
                    const sortType = [
                        {
                            id: 'date',
                            label: 'sort-by-date'
                        },
                        {
                            id: 'from',
                            label: 'sort-by-from'
                        },
                        {
                            id: 'to',
                            label: 'sort-by-to'
                        },
                        {
                            id: 'subject',
                            label: 'sort-by-subject'
                        }
                    ].forEach(type => {
                        this.sortSelector.addToList(mozL10n.get(type.label), 0, true, () => {
                            let item = this.sortSelector.getFocusedItem();
                            this.sortSelector.hide();
                            if (item && item.source) {
                                if (this.curFolder.sortType !== item.source.id || this.curFolder.reSort) {
                                    this.curFolder.reSort = false;
                                    this.curFolder.sortType = item.source.id;
                                    headerCursor.sortBy(item.source.id);
                                    item.selected = true;
                                }
                                let sortName = mozL10n.get('value-name', { name: mozL10n.get(item.source.label) });
                                let sortMeg = mozL10n.get('toaster-sorted-by') + sortName;
                                toaster.toast({ text: sortMeg });
                            }
                        }, type.id === (this.curFolder.sortType || 'date'), type);
                    });
                    this.sortSelector.show();
                });
            },
            onMessageSorted: function () {
                this.vScroll.setData(this.listFunc);
            },
            handleKeydown: function (evt) {
                switch (evt.key) {
                case 'Backspace':
                    if (NavigationMap.configDialogShown()) {
                        evt.preventDefault();
                        CustomDialog.hide();
                    } else {
                        if (window.option.menuVisible === false && this.editMode) {
                            evt.preventDefault();
                            this.setEditModeDone();
                        } else {
                            if (window.option.menuVisible === false) {
                                let bInbox = false;
                                let foldersSlice = model.foldersSlice;
                                let inboxFolder;
                                if (foldersSlice && this.curFolder) {
                                    inboxFolder = foldersSlice.getFirstFolderWithType('inbox');
                                    if (inboxFolder === this.curFolder) {
                                        bInbox = true;
                                    }
                                }
                                if (!bInbox && this.curFolder) {
                                    window.backToShowFolder = true;
                                    evt.preventDefault();
                                    cards.pushCard('folder_picker', 'animate');
                                }
                            }
                        }
                    }
                    break;
                }
            },
            handleKeydownForSearch: function (evt) {
                let changeFilter = false;
                let activeElement = document.activeElement;
                let filterFocus = activeElement.classList.contains('filter-selector');
                switch (evt.key) {
                case 'ArrowLeft':
                    if (filterFocus) {
                        searchIndex = searchIndex === 0 ? 4 : --searchIndex;
                        changeFilter = true;
                    }
                    break;
                case 'ArrowRight':
                    if (filterFocus) {
                        searchIndex = searchIndex === 4 ? 0 : ++searchIndex;
                        changeFilter = true;
                    }
                    break;
                case 'Backspace':
                    evt.preventDefault();
                    let confirm = document.getElementById('confirm-dialog-container');
                    if (confirm.innerHTML.length > 0) {
                        CustomDialog.hide();
                        option.show();
                    } else {
                        if (this.editMode) {
                            this.setEditModeDone();
                        } else {
                            if (window.option.menuVisible === false) {
                                this.onCancelSearch();
                            }
                        }
                    }
                    break;
                }
                if (changeFilter) {
                    let filter = this.searchFilter[searchIndex];
                    let item = this.searchHeader.querySelector('[data-filter-name="' + filter + '"]');
                    let l10Id = item.firstElementChild.getAttribute('data-l10n-id');
                    mozL10n.setAttributes(this.filterType, l10Id);
                    item.click();
                }
            }
        }
    ];
});