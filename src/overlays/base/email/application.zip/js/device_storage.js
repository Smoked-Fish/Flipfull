define(['require'], function (require) {
    function getDefaultWriteStorage() {
        return new Promise(res => {
            if (SettingsObserver) {
                SettingsObserver.getValue('device.storage.writable.name').then(result => {
                    res(result);
                }, () => {
                    res('sdcard');
                });
            } else {
                res('sdcard');
            }
        });
    }
    const DeviceStorage = {
        get: (storage = 'sdcard') => {
            const storages = navigator.b2g.getDeviceStorages(storage);
            return new Promise(res => {
                let deviceStorage = null;
                if (storages && storages[0]) {
                    deviceStorage = storages[0];
                    if (storages.length > 1) {
                        getDefaultWriteStorage().then(value => {
                            if ('sdcard1' === value) {
                                deviceStorage = storages[1];
                            }
                            res(deviceStorage);
                        });
                    } else {
                        res(deviceStorage);
                    }
                } else {
                    res(deviceStorage);
                }
            });
        }
    };
    return DeviceStorage;
});