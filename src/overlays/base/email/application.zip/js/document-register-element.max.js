(function (e, t) {
    'use strict';
    function qt() {
        var e = Tt.splice(0, Tt.length);
        Nt = 0;
        while (e.length)
            e.shift().call(null, e.shift());
    }
    function Rt(e, t) {
        for (var n = 0, r = e.length; n < r; n++)
            en(e[n], t);
    }
    function Ut(e) {
        for (var t = 0, n = e.length, r; t < n; t++)
            r = e[t], Ft(r, O[Wt(r)]);
    }
    function zt(e) {
        return function (t) {
            ft(t) && (en(t, e), M.length && Rt(t.querySelectorAll(M), e));
        };
    }
    function Wt(e) {
        var t = vt.call(e, 'is'), n = e.nodeName.toUpperCase(), r = D.call(A, t ? C + t.toUpperCase() : N + n);
        return t && -1 < r && !Xt(n, t) ? -1 : r;
    }
    function Xt(e, t) {
        return -1 < M.indexOf(e + '[is="' + t + '"]');
    }
    function Vt(e) {
        var t = e.currentTarget, n = e.attrChange, r = e.attrName, i = e.target, s = e[b] || 2, o = e[E] || 3;
        Mt && (!i || i === t) && t[p] && r !== 'style' && (e.prevValue !== e.newValue || e.newValue === '' && (n === s || n === o)) && t[p](r, n === s ? null : e.prevValue, n === o ? null : e.newValue);
    }
    function $t(e) {
        var t = zt(e);
        return function (e) {
            Tt.push(t, e.target), Nt && clearTimeout(Nt), Nt = setTimeout(qt, 1);
        };
    }
    function Jt(e) {
        Ot && (Ot = !1, e.currentTarget.removeEventListener(x, Jt)), M.length && Rt((e.target || n).querySelectorAll(M), e.detail === c ? c : f), ut && Yt();
    }
    function Kt(e, t) {
        var n = this;
        yt.call(n, e, t), _t.call(n, { target: n });
    }
    function Qt(e, t, n) {
        var r = t.apply(e, n), i = Wt(r);
        return -1 < i && Ft(r, O[i]), n.pop() && M.length && Ut(r.querySelectorAll(M)), r;
    }
    function Gt(e, t) {
        rt(e, t), Ht ? Ht.observe(e, St) : (At && (e.setAttribute = Kt, e[u] = Pt(e), e[a](T, _t)), e[a](S, Vt)), e[g] && Mt && (e.created = !0, e[g](), e.created = !1);
    }
    function Yt() {
        for (var e, t = 0, n = lt.length; t < n; t++)
            e = lt[t], _.contains(e) || (n--, lt.splice(t--, 1), en(e, c));
    }
    function Zt(e) {
        throw new Error('A ' + e + ' type is already registered');
    }
    function en(e, t) {
        var n, r = Wt(e), i;
        -1 < r && !pt.call(e, 'TEMPLATE') && (jt(e, O[r]), r = 0, t === f && !e[f] ? (e[c] = !1, e[f] = !0, i = 'connected', r = 1, ut && D.call(lt, e) < 0 && lt.push(e)) : t === c && !e[c] && (e[f] = !1, e[c] = !0, i = 'disconnected', r = 1), r && (n = e[t + l] || e[i + l]) && n.call(e));
    }
    function tn() {
    }
    function nn(e, t, r) {
        var i = r && r[h] || '', o = t.prototype, u = nt(o), a = t.observedAttributes || F, f = { prototype: u };
        at(u, g, {
            value: function () {
                if (G)
                    G = !1;
                else if (!this[X]) {
                    this[X] = !0, new t(this), o[g] && o[g].call(this);
                    var e = Y[et.get(t)];
                    (!$ || e.create.length > 1) && on(this);
                }
            }
        }), at(u, p, {
            value: function (e) {
                -1 < D.call(a, e) && o[p] && o[p].apply(this, arguments);
            }
        }), o[v] && at(u, d, { value: o[v] }), o[m] && at(u, y, { value: o[m] }), i && (f[h] = i), e = e.toUpperCase(), Y[e] = {
            constructor: t,
            create: i ? [
                i,
                tt(e)
            ] : [e]
        }, et.set(t, e), n[s](e.toLowerCase(), f), un(e), Z[e].r();
    }
    function rn(e) {
        var t = Y[e.toUpperCase()];
        return t && t.constructor;
    }
    function sn(e) {
        return typeof e == 'string' ? e : e && e.is || '';
    }
    function on(e) {
        var t = e[p], n = t ? e.attributes : F, r = n.length, i;
        while (r--)
            i = n[r], t.call(e, i.name || i.nodeName, null, i.value || i.nodeValue);
    }
    function un(e) {
        return e = e.toUpperCase(), e in Z || (Z[e] = {}, Z[e].p = new Q(function (t) {
            Z[e].r = t;
        })), Z[e].p;
    }
    function an() {
        V && delete e.customElements, j(e, 'customElements', {
            configurable: !0,
            value: new tn()
        }), j(e, 'CustomElementRegistry', {
            configurable: !0,
            value: tn
        });
        for (var t = function (t) {
                    var r = e[t];
                    if (r) {
                        e[t] = function (t) {
                            var i, s;
                            return t || (t = this), t[X] || (G = !0, i = Y[et.get(t.constructor)], s = $ && i.create.length === 1, t = s ? Reflect.construct(r, F, i.constructor) : n.createElement.apply(n, i.create), t[X] = !0, G = !1, s || on(t)), t;
                        }, e[t].prototype = r.prototype;
                        try {
                            r.prototype.constructor = e[t];
                        } catch (i) {
                            W = !0, j(r, X, { value: e[t] });
                        }
                    }
                }, r = i.get(/^HTML[A-Z]*[a-z]/), o = r.length; o--; t(r[o]));
        n.createElement = function (e, t) {
            var n = sn(t);
            return n ? Et.call(this, e, tt(n)) : Et.call(this, e);
        }, Ct || (Lt = !0, n[s](''));
    }
    var n = e.document, r = e.Object, i = function (e) {
            var t = /^[A-Z]+[a-z]/, n = function (e) {
                    var t = [], n;
                    for (n in s)
                        e.test(n) && t.push(n);
                    return t;
                }, i = function (e, t) {
                    t = t.toLowerCase(), t in s || (s[e] = (s[e] || []).concat(t), s[t] = s[t.toUpperCase()] = e);
                }, s = (r.create || r)(null), o = {}, u, a, f, l;
            for (a in e)
                for (l in e[a]) {
                    f = e[a][l], s[l] = f;
                    for (u = 0; u < f.length; u++)
                        s[f[u].toLowerCase()] = s[f[u].toUpperCase()] = l;
                }
            return o.get = function (r) {
                return typeof r == 'string' ? s[r] || (t.test(r) ? [] : '') : n(r);
            }, o.set = function (n, r) {
                return t.test(n) ? i(n, r) : i(r, n), o;
            }, o;
        }({
            collections: {
                HTMLAllCollection: ['all'],
                HTMLCollection: ['forms'],
                HTMLFormControlsCollection: ['elements'],
                HTMLOptionsCollection: ['options']
            },
            elements: {
                Element: ['element'],
                HTMLAnchorElement: ['a'],
                HTMLAppletElement: ['applet'],
                HTMLAreaElement: ['area'],
                HTMLAttachmentElement: ['attachment'],
                HTMLAudioElement: ['audio'],
                HTMLBRElement: ['br'],
                HTMLBaseElement: ['base'],
                HTMLBodyElement: ['body'],
                HTMLButtonElement: ['button'],
                HTMLCanvasElement: ['canvas'],
                HTMLContentElement: ['content'],
                HTMLDListElement: ['dl'],
                HTMLDataElement: ['data'],
                HTMLDataListElement: ['datalist'],
                HTMLDetailsElement: ['details'],
                HTMLDialogElement: ['dialog'],
                HTMLDirectoryElement: ['dir'],
                HTMLDivElement: ['div'],
                HTMLDocument: ['document'],
                HTMLElement: [
                    'element',
                    'abbr',
                    'address',
                    'article',
                    'aside',
                    'b',
                    'bdi',
                    'bdo',
                    'cite',
                    'code',
                    'command',
                    'dd',
                    'dfn',
                    'dt',
                    'em',
                    'figcaption',
                    'figure',
                    'footer',
                    'header',
                    'i',
                    'kbd',
                    'mark',
                    'nav',
                    'noscript',
                    'rp',
                    'rt',
                    'ruby',
                    's',
                    'samp',
                    'section',
                    'small',
                    'strong',
                    'sub',
                    'summary',
                    'sup',
                    'u',
                    'var',
                    'wbr'
                ],
                HTMLEmbedElement: ['embed'],
                HTMLFieldSetElement: ['fieldset'],
                HTMLFontElement: ['font'],
                HTMLFormElement: ['form'],
                HTMLFrameElement: ['frame'],
                HTMLFrameSetElement: ['frameset'],
                HTMLHRElement: ['hr'],
                HTMLHeadElement: ['head'],
                HTMLHeadingElement: [
                    'h1',
                    'h2',
                    'h3',
                    'h4',
                    'h5',
                    'h6'
                ],
                HTMLHtmlElement: ['html'],
                HTMLIFrameElement: ['iframe'],
                HTMLImageElement: ['img'],
                HTMLInputElement: ['input'],
                HTMLKeygenElement: ['keygen'],
                HTMLLIElement: ['li'],
                HTMLLabelElement: ['label'],
                HTMLLegendElement: ['legend'],
                HTMLLinkElement: ['link'],
                HTMLMapElement: ['map'],
                HTMLMarqueeElement: ['marquee'],
                HTMLMediaElement: ['media'],
                HTMLMenuElement: ['menu'],
                HTMLMenuItemElement: ['menuitem'],
                HTMLMetaElement: ['meta'],
                HTMLMeterElement: ['meter'],
                HTMLModElement: [
                    'del',
                    'ins'
                ],
                HTMLOListElement: ['ol'],
                HTMLObjectElement: ['object'],
                HTMLOptGroupElement: ['optgroup'],
                HTMLOptionElement: ['option'],
                HTMLOutputElement: ['output'],
                HTMLParagraphElement: ['p'],
                HTMLParamElement: ['param'],
                HTMLPictureElement: ['picture'],
                HTMLPreElement: ['pre'],
                HTMLProgressElement: ['progress'],
                HTMLQuoteElement: [
                    'blockquote',
                    'q',
                    'quote'
                ],
                HTMLScriptElement: ['script'],
                HTMLSelectElement: ['select'],
                HTMLShadowElement: ['shadow'],
                HTMLSlotElement: ['slot'],
                HTMLSourceElement: ['source'],
                HTMLSpanElement: ['span'],
                HTMLStyleElement: ['style'],
                HTMLTableCaptionElement: ['caption'],
                HTMLTableCellElement: [
                    'td',
                    'th'
                ],
                HTMLTableColElement: [
                    'col',
                    'colgroup'
                ],
                HTMLTableElement: ['table'],
                HTMLTableRowElement: ['tr'],
                HTMLTableSectionElement: [
                    'thead',
                    'tbody',
                    'tfoot'
                ],
                HTMLTemplateElement: ['template'],
                HTMLTextAreaElement: ['textarea'],
                HTMLTimeElement: ['time'],
                HTMLTitleElement: ['title'],
                HTMLTrackElement: ['track'],
                HTMLUListElement: ['ul'],
                HTMLUnknownElement: [
                    'unknown',
                    'vhgroupv',
                    'vkeygen'
                ],
                HTMLVideoElement: ['video']
            },
            nodes: {
                Attr: ['node'],
                Audio: ['audio'],
                CDATASection: ['node'],
                CharacterData: ['node'],
                Comment: ['#comment'],
                Document: ['#document'],
                DocumentFragment: ['#document-fragment'],
                DocumentType: ['node'],
                HTMLDocument: ['#document'],
                Image: ['img'],
                Option: ['option'],
                ProcessingInstruction: ['node'],
                ShadowRoot: ['#shadow-root'],
                Text: ['#text'],
                XMLDocument: ['xml']
            }
        });
    typeof t != 'object' && (t = { type: t || 'auto' });
    var s = 'registerElement', o = e.Math.random() * 100000 >> 0, u = '__' + s + o, a = 'addEventListener', f = 'attached', l = 'Callback', c = 'detached', h = 'extends', p = 'attributeChanged' + l, d = f + l, v = 'connected' + l, m = 'disconnected' + l, g = 'created' + l, y = c + l, b = 'ADDITION', w = 'MODIFICATION', E = 'REMOVAL', S = 'DOMAttrModified', x = 'DOMContentLoaded', T = 'DOMSubtreeModified', N = '<', C = '=', k = /^[A-Z][._A-Z0-9]*-[-._A-Z0-9]*$/, L = [
            'ANNOTATION-XML',
            'COLOR-PROFILE',
            'FONT-FACE',
            'FONT-FACE-SRC',
            'FONT-FACE-URI',
            'FONT-FACE-FORMAT',
            'FONT-FACE-NAME',
            'MISSING-GLYPH'
        ], A = [], O = [], M = '', _ = n.documentElement, D = A.indexOf || function (e) {
            for (var t = this.length; t-- && this[t] !== e;);
            return t;
        }, P = r.prototype, H = P.hasOwnProperty, B = P.isPrototypeOf, j = r.defineProperty, F = [], I = r.getOwnPropertyDescriptor, q = r.getOwnPropertyNames, R = r.getPrototypeOf, U = r.setPrototypeOf, z = !!r.__proto__, W = !1, X = '__dreCEv1', V = e.customElements, $ = !/^force/.test(t.type) && !!(V && V.define && V.get && V.whenDefined), J = r.create || r, K = e.Map || function () {
            var t = [], n = [], r;
            return {
                get: function (e) {
                    return n[D.call(t, e)];
                },
                set: function (e, i) {
                    r = D.call(t, e), r < 0 ? n[t.push(e) - 1] = i : n[r] = i;
                }
            };
        }, Q = e.Promise || function (e) {
            function i(e) {
                n = !0;
                while (t.length)
                    t.shift()(e);
            }
            var t = [], n = !1, r = {
                    'catch': function () {
                        return r;
                    },
                    then: function (e) {
                        return t.push(e), n && setTimeout(i, 1), r;
                    }
                };
            return e(i), r;
        }, G = !1, Y = J(null), Z = J(null), et = new K(), tt = function (e) {
            return e.toLowerCase();
        }, nt = r.create || function cn(e) {
            return e ? (cn.prototype = e, new cn()) : this;
        }, rt = U || (z ? function (e, t) {
            return e.__proto__ = t, e;
        } : q && I ? function () {
            function e(e, t) {
                for (var n, r = q(t), i = 0, s = r.length; i < s; i++)
                    n = r[i], H.call(e, n) || j(e, n, I(t, n));
            }
            return function (t, n) {
                do
                    e(t, n);
                while ((n = R(n)) && !B.call(n, t));
                return t;
            };
        }() : function (e, t) {
            for (var n in t)
                e[n] = t[n];
            return e;
        }), it = e.MutationObserver || e.WebKitMutationObserver, st = e.HTMLAnchorElement, ot = (e.HTMLElement || e.Element || e.Node).prototype, ut = !B.call(ot, _), at = ut ? function (e, t, n) {
            return e[t] = n.value, e;
        } : j, ft = ut ? function (e) {
            return e.nodeType === 1;
        } : function (e) {
            return B.call(ot, e);
        }, lt = ut && [], ct = ot.attachShadow, ht = ot.cloneNode, pt = ot.closest || function (e) {
            var t = this;
            while (t && t.nodeName !== e)
                t = t.parentNode;
            return t;
        }, dt = ot.dispatchEvent, vt = ot.getAttribute, mt = ot.hasAttribute, gt = ot.removeAttribute, yt = ot.setAttribute, bt = n.createElement, wt = n.importNode, Et = bt, St = it && {
            attributes: !0,
            characterData: !0,
            attributeOldValue: !0
        }, xt = it || function (e) {
            At = !1, _.removeEventListener(S, xt);
        }, Tt, Nt = 0, Ct = s in n && !/^force-all/.test(t.type), kt = !0, Lt = !1, At = !0, Ot = !0, Mt = !0, _t, Dt, Pt, Ht, Bt, jt, Ft, It;
    it && (It = n.createElement('div'), It.innerHTML = '<div><div></div></div>', new it(function (e, t) {
        if (e[0] && e[0].type == 'childList' && !e[0].removedNodes[0].childNodes.length) {
            It = I(ot, 'innerHTML');
            var n = It && It.set;
            n && j(ot, 'innerHTML', {
                set: function (e) {
                    while (this.lastChild)
                        this.removeChild(this.lastChild);
                    n.call(this, e);
                }
            });
        }
        t.disconnect(), It = null;
    }).observe(It, {
        childList: !0,
        subtree: !0
    }), It.innerHTML = ''), Ct || (U || z ? (jt = function (e, t) {
        B.call(t, e) || Gt(e, t);
    }, Ft = Gt) : (jt = function (e, t) {
        e[u] || (e[u] = r(!0), Gt(e, t));
    }, Ft = jt), ut ? (At = !1, function () {
        var e = I(ot, a), t = e.value, n = function (e) {
                var t = new CustomEvent(S, { bubbles: !0 });
                t.attrName = e, t.prevValue = vt.call(this, e), t.newValue = null, t[E] = t.attrChange = 2, gt.call(this, e), dt.call(this, t);
            }, r = function (e, t) {
                var n = mt.call(this, e), r = n && vt.call(this, e), i = new CustomEvent(S, { bubbles: !0 });
                yt.call(this, e, t), i.attrName = e, i.prevValue = n ? r : null, i.newValue = t, n ? i[w] = i.attrChange = 1 : i[b] = i.attrChange = 0, dt.call(this, i);
            }, i = function (e) {
                var t = e.currentTarget, n = t[u], r = e.propertyName, i;
                n.hasOwnProperty(r) && (n = n[r], i = new CustomEvent(S, { bubbles: !0 }), i.attrName = n.name, i.prevValue = n.value || null, i.newValue = n.value = t[r] || null, i.prevValue == null ? i[b] = i.attrChange = 0 : i[w] = i.attrChange = 1, dt.call(t, i));
            };
        e.value = function (e, s, o) {
            e === S && this[p] && this.setAttribute !== r && (this[u] = {
                className: {
                    name: 'class',
                    value: this.className
                }
            }, this.setAttribute = r, this.removeAttribute = n, t.call(this, 'propertychange', i)), t.call(this, e, s, o);
        }, j(ot, a, e);
    }()) : it || (_[a](S, xt), _.setAttribute(u, 1), _.removeAttribute(u), At && (_t = function (e) {
        var t = this, n, r, i;
        if (t === e.target) {
            n = t[u], t[u] = r = Pt(t);
            for (i in r) {
                if (!(i in n))
                    return Dt(0, t, i, n[i], r[i], b);
                if (r[i] !== n[i])
                    return Dt(1, t, i, n[i], r[i], w);
            }
            for (i in n)
                if (!(i in r))
                    return Dt(2, t, i, n[i], r[i], E);
        }
    }, Dt = function (e, t, n, r, i, s) {
        var o = {
            attrChange: e,
            currentTarget: t,
            attrName: n,
            prevValue: r,
            newValue: i
        };
        o[s] = e, Vt(o);
    }, Pt = function (e) {
        for (var t, n, r = {}, i = e.attributes, s = 0, o = i.length; s < o; s++)
            t = i[s], n = t.name, n !== 'setAttribute' && (r[n] = t.value);
        return r;
    })), n[s] = function (t, r) {
        l = t.toUpperCase(), kt && (kt = !1, it ? (Ht = function (e, t) {
            function n(e, t) {
                for (var n = 0, r = e.length; n < r; t(e[n++]));
            }
            return new it(function (r) {
                for (var i, s, o, u = 0, a = r.length; u < a; u++)
                    i = r[u], i.type === 'childList' ? (n(i.addedNodes, e), n(i.removedNodes, t)) : (s = i.target, Mt && s[p] && i.attributeName !== 'style' && (o = vt.call(s, i.attributeName), o !== i.oldValue && s[p](i.attributeName, i.oldValue, o)));
            });
        }(zt(f), zt(c)), Bt = function (e) {
            return Ht.observe(e, {
                childList: !0,
                subtree: !0
            }), e;
        }, Bt(n), ct && (ot.attachShadow = function () {
            return Bt(ct.apply(this, arguments));
        })) : (Tt = [], n[a]('DOMNodeInserted', $t(f)), n[a]('DOMNodeRemoved', $t(c))), n[a](x, Jt), n[a]('readystatechange', Jt), n.importNode = function (e, t) {
            switch (e.nodeType) {
            case 1:
                return Qt(n, wt, [
                    e,
                    !!t
                ]);
            case 11:
                for (var r = n.createDocumentFragment(), i = e.childNodes, s = i.length, o = 0; o < s; o++)
                    r.appendChild(n.importNode(i[o], !!t));
                return r;
            default:
                return ht.call(e, !!t);
            }
        }, ot.cloneNode = function (e) {
            return Qt(this, ht, [!!e]);
        });
        if (Lt)
            return Lt = !1;
        -2 < D.call(A, C + l) + D.call(A, N + l) && Zt(t);
        if (!k.test(l) || -1 < D.call(L, l))
            throw new Error('The type ' + t + ' is invalid');
        var i = function () {
                return o ? n.createElement(u, l) : n.createElement(u);
            }, s = r || P, o = H.call(s, h), u = o ? r[h].toUpperCase() : l, l, d;
        return o && -1 < D.call(A, N + u) && Zt(u), d = A.push((o ? C : N) + l) - 1, M = M.concat(M.length ? ',' : '', o ? u + '[is="' + t.toLowerCase() + '"]' : u), i.prototype = O[d] = H.call(s, 'prototype') ? s.prototype : nt(ot), M.length && Rt(n.querySelectorAll(M), f), i;
    }, n.createElement = Et = function (e, t) {
        var r = sn(t), i = r ? bt.call(n, e, tt(r)) : bt.call(n, e), s = '' + e, o = D.call(A, (r ? C : N) + (r || s).toUpperCase()), u = -1 < o;
        return r && (i.setAttribute('is', r = r.toLowerCase()), u && (u = Xt(s.toUpperCase(), r))), Mt = !n.createElement.innerHTMLHelper, u && Ft(i, O[o]), i;
    }), addEventListener('beforeunload', function () {
        delete n.createElement, delete n.importNode, delete n[s];
    }, !1), tn.prototype = {
        constructor: tn,
        define: $ ? function (e, t, n) {
            if (n)
                nn(e, t, n);
            else {
                var r = e.toUpperCase();
                Y[r] = {
                    constructor: t,
                    create: [r]
                }, et.set(t, r), V.define(e, t);
            }
        } : nn,
        get: $ ? function (e) {
            return V.get(e) || rn(e);
        } : rn,
        whenDefined: $ ? function (e) {
            return Q.race([
                V.whenDefined(e),
                un(e)
            ]);
        } : un
    };
    if (!V || /^force/.test(t.type))
        an();
    else if (!t.noBuiltIn)
        try {
            (function (t, r, i) {
                var s = new RegExp('^<a\\s+is=(\'|")' + i + '\\1></a>$');
                r[h] = 'a', t.prototype = nt(st.prototype), t.prototype.constructor = t, e.customElements.define(i, t, r);
                if (!s.test(n.createElement('a', { is: i }).outerHTML) || !s.test(new t().outerHTML))
                    throw r;
            }(function hn() {
                return Reflect.construct(st, [], hn);
            }, {}, 'document-register-element-a' + o));
        } catch (fn) {
            an();
        }
    if (!t.noBuiltIn)
        try {
            if (bt.call(n, 'a', 'a').outerHTML.indexOf('is') < 0)
                throw {};
        } catch (ln) {
            tt = function (e) {
                return { is: e.toLowerCase() };
            };
        }
}(window));