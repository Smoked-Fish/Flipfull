define('activesync/folder', [
    'logic',
    '../date',
    '../syncbase',
    '../allback',
    '../db/mail_rep',
    'activesync/codepages/AirSync',
    'activesync/codepages/AirSyncBase',
    'activesync/codepages/ItemEstimate',
    'activesync/codepages/Email',
    'activesync/codepages/ItemOperations',
    'safe-base64',
    'mimetypes',
    'module',
    'require',
    'exports'
], function (logic, $date, $sync, allback, mailRep, $AirSync, $AirSyncBase, $ItemEstimate, $Email, $ItemOperations, safeBase64, mimetypes, $module, require, exports) {
    'use strict';
    var DESIRED_TEXT_SNIPPET_BYTES = 5120;
    var DESIRED_MESSAGE_COUNT = 50;
    var FILTER_TYPE, SYNC_RANGE_TO_FILTER_TYPE, FILTER_TYPE_TO_STRING;
    function initFilterTypes() {
        FILTER_TYPE = $AirSync.Enums.FilterType;
        SYNC_RANGE_TO_FILTER_TYPE = {
            'auto': null,
            '1d': FILTER_TYPE.OneDayBack,
            '3d': FILTER_TYPE.ThreeDaysBack,
            '1w': FILTER_TYPE.OneWeekBack,
            '2w': FILTER_TYPE.TwoWeeksBack,
            '1m': FILTER_TYPE.OneMonthBack,
            'all': FILTER_TYPE.NoFilter
        };
        FILTER_TYPE_TO_STRING = {
            0: 'all messages',
            1: 'one day',
            2: 'three days',
            3: 'one week',
            4: 'two weeks',
            5: 'one month'
        };
    }
    var $wbxml, parseAddresses, $mailchew;
    function lazyConnection(cbIndex, fn, failString) {
        return function lazyRun() {
            var args = Array.prototype.slice.call(arguments), errback = args[cbIndex], self = this;
            require([
                'wbxml',
                'addressparser',
                '../mailchew'
            ], function (wbxml, addressparser, mailchew) {
                if (!$wbxml) {
                    $wbxml = wbxml;
                    parseAddresses = addressparser.parse.bind(addressparser);
                    $mailchew = mailchew;
                    initFilterTypes();
                }
                self._account.withConnection(errback, function () {
                    fn.apply(self, args);
                }, failString);
            });
        };
    }
    function ActiveSyncFolderConn(account, storage) {
        this._account = account;
        this._storage = storage;
        logic.defineScope(this, 'ActiveSyncFolderConn', {
            folderId: storage.folderId,
            accountId: account.id
        });
        this.folderMeta = storage.folderMeta;
        if (!this.syncKey)
            this.syncKey = '0';
    }
    ActiveSyncFolderConn.prototype = {
        get syncKey() {
            return this.folderMeta.syncKey;
        },
        set syncKey(value) {
            return this.folderMeta.syncKey = value;
        },
        get serverId() {
            return this.folderMeta.serverId;
        },
        get filterType() {
            var syncRange = this._account.accountDef.syncRange;
            if (SYNC_RANGE_TO_FILTER_TYPE.hasOwnProperty(syncRange)) {
                var accountFilterType = SYNC_RANGE_TO_FILTER_TYPE[syncRange];
                if (accountFilterType)
                    return accountFilterType;
                else
                    return this.folderMeta.filterType;
            } else {
                console.warn('Got an invalid syncRange (' + syncRange + ') using three days back instead');
                return $AirSync.Enums.FilterType.ThreeDaysBack;
            }
        },
        _getSyncKey: lazyConnection(1, function asfc__getSyncKey(filterType, callback) {
            var folderConn = this;
            var account = this._account;
            var as = $AirSync.Tags;
            var w = new $wbxml.Writer('1.3', 1, 'UTF-8');
            w.stag(as.Sync).stag(as.Collections).stag(as.Collection);
            if (account.conn.currentVersion.lt('12.1'))
                w.tag(as.Class, 'Email');
            w.tag(as.SyncKey, '0').tag(as.CollectionId, this.serverId).stag(as.Options).tag(as.FilterType, filterType).etag().etag().etag().etag();
            account.conn.postCommand(w, function (aError, aResponse) {
                if (aError) {
                    console.error(aError);
                    account._reportErrorIfNecessary(aError);
                    callback('unknown');
                    return;
                }
                folderConn.syncKey = '0';
                var e = new $wbxml.EventParser();
                e.addEventListener([
                    as.Sync,
                    as.Collections,
                    as.Collection,
                    as.SyncKey
                ], function (node) {
                    folderConn.syncKey = node.children[0].textContent;
                });
                e.onerror = function () {
                };
                e.run(aResponse);
                if (folderConn.syncKey === '0') {
                    console.error('Unable to get sync key for folder');
                    callback('unknown');
                } else {
                    callback();
                }
            });
        }),
        _getItemEstimate: lazyConnection(1, function asfc__getItemEstimate(filterType, callback) {
            var ie = $ItemEstimate.Tags;
            var as = $AirSync.Tags;
            var account = this._account;
            var w = new $wbxml.Writer('1.3', 1, 'UTF-8');
            w.stag(ie.GetItemEstimate).stag(ie.Collections).stag(ie.Collection);
            if (this._account.conn.currentVersion.gte('14.0')) {
                w.tag(as.SyncKey, this.syncKey).tag(ie.CollectionId, this.serverId).stag(as.Options).tag(as.FilterType, filterType).etag();
            } else if (this._account.conn.currentVersion.gte('12.0')) {
                w.tag(ie.CollectionId, this.serverId).tag(as.FilterType, filterType).tag(as.SyncKey, this.syncKey);
            } else {
                w.tag(ie.Class, 'Email').tag(as.SyncKey, this.syncKey).tag(ie.CollectionId, this.serverId).tag(as.FilterType, filterType);
            }
            w.etag(ie.Collection).etag(ie.Collections).etag(ie.GetItemEstimate);
            account.conn.postCommand(w, function (aError, aResponse) {
                if (aError) {
                    console.error(aError);
                    account._reportErrorIfNecessary(aError);
                    callback('unknown');
                    return;
                }
                var e = new $wbxml.EventParser();
                var base = [
                    ie.GetItemEstimate,
                    ie.Response
                ];
                var status, estimate;
                e.addEventListener(base.concat(ie.Status), function (node) {
                    status = node.children[0].textContent;
                });
                e.addEventListener(base.concat(ie.Collection, ie.Estimate), function (node) {
                    estimate = parseInt(node.children[0].textContent, 10);
                });
                try {
                    e.run(aResponse);
                } catch (ex) {
                    console.error('Error parsing GetItemEstimate response', ex, '\n', ex.stack);
                    callback('unknown');
                    return;
                }
                if (status !== $ItemEstimate.Enums.Status.Success) {
                    console.error('Error getting item estimate:', status);
                    callback('unknown');
                } else {
                    callback(null, estimate);
                }
            });
        }),
        _inferFilterType: lazyConnection(0, function asfc__inferFilterType(callback) {
            var folderConn = this;
            var Type = $AirSync.Enums.FilterType;
            var getEstimate = function (filterType, onSuccess) {
                folderConn._getSyncKey(filterType, function (error) {
                    if (error) {
                        callback('unknown');
                        return;
                    }
                    folderConn._getItemEstimate(filterType, function (error, estimate) {
                        if (error) {
                            callback(null, Type.ThreeDaysBack);
                            return;
                        }
                        onSuccess(estimate);
                    });
                });
            };
            getEstimate(Type.TwoWeeksBack, function (estimate) {
                var messagesPerDay = estimate / 14;
                var filterType;
                if (estimate < 0)
                    filterType = Type.ThreeDaysBack;
                else if (messagesPerDay >= DESIRED_MESSAGE_COUNT)
                    filterType = Type.OneDayBack;
                else if (messagesPerDay * 3 >= DESIRED_MESSAGE_COUNT)
                    filterType = Type.ThreeDaysBack;
                else if (messagesPerDay * 7 >= DESIRED_MESSAGE_COUNT)
                    filterType = Type.OneWeekBack;
                else if (messagesPerDay * 14 >= DESIRED_MESSAGE_COUNT)
                    filterType = Type.TwoWeeksBack;
                else if (messagesPerDay * 30 >= DESIRED_MESSAGE_COUNT)
                    filterType = Type.OneMonthBack;
                else {
                    getEstimate(Type.NoFilter, function (estimate) {
                        var filterType;
                        if (estimate > DESIRED_MESSAGE_COUNT) {
                            filterType = Type.OneMonthBack;
                            folderConn.syncKey = '0';
                        } else {
                            filterType = Type.NoFilter;
                        }
                        logic(folderConn, 'inferFilterType', { filterType: filterType });
                        callback(null, filterType);
                    });
                    return;
                }
                if (filterType !== Type.TwoWeeksBack) {
                    folderConn.syncKey = '0';
                }
                logic(folderConn, 'inferFilterType', { filterType: filterType });
                callback(null, filterType);
            });
        }),
        _enumerateFolderChanges: lazyConnection(0, function asfc__enumerateFolderChanges(callback, progress) {
            var folderConn = this, storage = this._storage;
            if (!this.filterType) {
                this._inferFilterType(function (error, filterType) {
                    if (error) {
                        callback('unknown');
                        return;
                    }
                    console.log('We want a filter of', FILTER_TYPE_TO_STRING[filterType]);
                    folderConn.folderMeta.filterType = filterType;
                    folderConn._enumerateFolderChanges(callback, progress);
                });
                return;
            }
            if (this.syncKey === '0') {
                this._getSyncKey(this.filterType, function (error) {
                    if (error) {
                        callback('aborted');
                        return;
                    }
                    folderConn._enumerateFolderChanges(callback, progress);
                });
                return;
            }
            var as = $AirSync.Tags;
            var asEnum = $AirSync.Enums;
            var asb = $AirSyncBase.Tags;
            var asbEnum = $AirSyncBase.Enums;
            var w;
            logic(this, 'exchange version: ', { version: this._account.conn.currentVersion });
            if (this._account._syncsInProgress++ === 0 && this._account._lastSyncKey === this.syncKey && this._account._lastSyncFilterType === this.filterType && this._account._lastSyncResponseWasEmpty) {
                w = as.Sync;
            } else {
                w = new $wbxml.Writer('1.3', 1, 'UTF-8');
                w.stag(as.Sync).stag(as.Collections).stag(as.Collection);
                if (this._account.conn.currentVersion.lte('12.1'))
                    w.tag(as.Class, 'Email');
                w.tag(as.SyncKey, this.syncKey).tag(as.CollectionId, this.serverId).tag(as.GetChanges).stag(as.Options).tag(as.FilterType, this.filterType);
                if (this._account.conn.currentVersion.lt('12.0')) {
                    w.tag(as.MIMESupport, asEnum.MIMESupport.Never).tag(as.Truncation, asEnum.MIMETruncation.TruncateAll);
                } else {
                    w.tag(as.MIMESupport, asEnum.MIMESupport.Always).tag(as.MIMETruncation, asEnum.MIMETruncation.NoTruncate);
                }
                w.etag().etag().etag().etag();
            }
            this._account.conn.postCommand(w, function (aError, aResponse) {
                var added = [];
                var changed = [];
                var deleted = [];
                var status;
                var moreAvailable = false;
                folderConn._account._syncsInProgress--;
                if (aError) {
                    console.error('Error syncing folder:', aError);
                    folderConn._account._reportErrorIfNecessary(aError);
                    callback('aborted');
                    return;
                }
                folderConn._account._lastSyncKey = folderConn.syncKey;
                folderConn._account._lastSyncFilterType = folderConn.filterType;
                if (!aResponse) {
                    console.log('Sync completed with empty response');
                    folderConn._account._lastSyncResponseWasEmpty = true;
                    callback(null, added, changed, deleted);
                    return;
                }
                folderConn._account._lastSyncResponseWasEmpty = false;
                var e = new $wbxml.EventParser();
                var base = [
                    as.Sync,
                    as.Collections,
                    as.Collection
                ];
                e.addEventListener(base.concat(as.SyncKey), function (node) {
                    folderConn.syncKey = node.children[0].textContent;
                });
                e.addEventListener(base.concat(as.Status), function (node) {
                    status = node.children[0].textContent;
                });
                e.addEventListener(base.concat(as.MoreAvailable), function (node) {
                    moreAvailable = true;
                });
                e.addEventListener(base.concat(as.Commands, [[
                        as.Add,
                        as.Change
                    ]]), function (node) {
                    var id, guid, msg;
                    for (var iter of node.children) {
                        var child = iter;
                        switch (child.tag) {
                        case as.ServerId:
                            guid = child.children[0].textContent;
                            break;
                        case as.ApplicationData:
                            try {
                                msg = folderConn._parseMessage(child, node.tag === as.Add, storage);
                            } catch (ex) {
                                console.error('Failed to parse a message:', ex, '\n', ex.stack);
                                return;
                            }
                            break;
                        }
                    }
                    msg.header.srvid = guid;
                    var collection = node.tag === as.Add ? added : changed;
                    collection.push(msg);
                });
                e.addEventListener(base.concat(as.Commands, [[
                        as.Delete,
                        as.SoftDelete
                    ]]), function (node) {
                    var guid;
                    for (var iter of node.children) {
                        var child = iter;
                        switch (child.tag) {
                        case as.ServerId:
                            guid = child.children[0].textContent;
                            break;
                        }
                    }
                    deleted.push(guid);
                });
                try {
                    e.run(aResponse);
                } catch (ex) {
                    console.error('Error parsing Sync response:', ex, '\n', ex.stack);
                    callback('unknown');
                    return;
                }
                if (status === asEnum.Status.Success) {
                    console.log('Sync completed: added ' + added.length + ', changed ' + changed.length + ', deleted ' + deleted.length);
                    callback(null, added, changed, deleted, moreAvailable);
                    if (moreAvailable)
                        folderConn._enumerateFolderChanges(callback, progress);
                } else if (status === asEnum.Status.InvalidSyncKey) {
                    console.warn('ActiveSync had a bad sync key');
                    callback('badkey');
                } else {
                    if (!status) {
                        callback('checkAccount');
                    } else {
                        console.error('Something went wrong during ActiveSync syncing ' + 'and we got a status of ' + status);
                        callback('unknown');
                    }
                }
            }, null, null, function progressData(bytesSoFar, totalBytes) {
                if (!totalBytes)
                    totalBytes = Math.max(1000000, bytesSoFar);
                progress(0.1 + 0.7 * bytesSoFar / totalBytes);
            });
        }, 'aborted'),
        _parseMessage: function asfc__parseMessage(node, isAdded, storage) {
            var em = $Email.Tags;
            var asb = $AirSyncBase.Tags;
            var asbEnum = $AirSyncBase.Enums;
            var header, body, flagHeader;
            if (isAdded) {
                var newId = storage._issueNewHeaderId();
                header = {
                    id: newId,
                    srvid: null,
                    suid: storage.folderId + '/' + newId,
                    guid: '',
                    author: null,
                    to: null,
                    cc: null,
                    bcc: null,
                    replyTo: null,
                    date: null,
                    flags: [],
                    hasAttachments: false,
                    subject: null,
                    snippet: null
                };
                body = {
                    date: null,
                    size: 0,
                    attachments: [],
                    relatedParts: [],
                    references: null,
                    bodyReps: null
                };
                flagHeader = function (flag, state) {
                    if (state)
                        header.flags.push(flag);
                };
            } else {
                header = {
                    flags: [],
                    mergeInto: function (o) {
                        for (var iter of this.flags) {
                            var flagstate = iter;
                            if (flagstate[1]) {
                                o.flags.push(flagstate[0]);
                            } else {
                                var index = o.flags.indexOf(flagstate[0]);
                                if (index !== -1)
                                    o.flags.splice(index, 1);
                            }
                        }
                        var skip = [
                            'mergeInto',
                            'suid',
                            'srvid',
                            'guid',
                            'id',
                            'flags'
                        ];
                        for (var iter in this) {
                            var key = iter, value = this[iter];
                            if (skip.indexOf(key) !== -1)
                                continue;
                            o[key] = value;
                        }
                    }
                };
                body = {
                    mergeInto: function (o) {
                        for (var iter of this) {
                            var key = iter, value = this[iter];
                            if (key === 'mergeInto')
                                continue;
                            o[key] = value;
                        }
                    }
                };
                flagHeader = function (flag, state) {
                    header.flags.push([
                        flag,
                        state
                    ]);
                };
            }
            var bodyType, bodySize;
            for (var iter of node.children) {
                var child = iter;
                var childText = child.children.length ? child.children[0].textContent : null;
                switch (child.tag) {
                case em.Subject:
                    header.subject = childText;
                    break;
                case em.From:
                    header.author = parseAddresses(childText)[0] || null;
                    break;
                case em.To:
                    header.to = parseAddresses(childText);
                    break;
                case em.Cc:
                    header.cc = parseAddresses(childText);
                    break;
                case em.ReplyTo:
                    header.replyTo = parseAddresses(childText);
                    break;
                case em.DateReceived:
                    body.date = header.date = new Date(childText).valueOf();
                    break;
                case em.Read:
                    flagHeader('\\Seen', childText === '1');
                    break;
                case em.Flag:
                    for (var iter2 of child.children) {
                        var grandchild = iter2;
                        if (grandchild.tag === em.Status)
                            flagHeader('\\Flagged', grandchild.children[0].textContent !== '0');
                    }
                    break;
                case asb.Body:
                    for (var iter2 of child.children) {
                        var grandchild = iter2;
                        switch (grandchild.tag) {
                        case asb.Type:
                            var type = grandchild.children[0].textContent;
                            if (type === asbEnum.Type.HTML)
                                bodyType = 'html';
                            else {
                                if (type !== asbEnum.Type.PlainText) {
                                    console.warn('A message had a strange body type:', type);
                                    bodyType = 'html';
                                } else {
                                    bodyType = 'plain';
                                }
                            }
                            break;
                        case asb.EstimatedDataSize:
                            bodySize = grandchild.children[0].textContent;
                            break;
                        case asb.Data:
                            bodySize = grandchild.children[0].textContent.length;
                            break;
                        }
                    }
                    break;
                case em.MIMEData:
                    bodyType = 'html';
                    bodySize = childText.length;
                    break;
                case em.BodySize:
                    bodyType = 'plain';
                    bodySize = childText;
                    break;
                case asb.Attachments:
                case em.Attachments:
                    for (var iter2 of child.children) {
                        var attachmentNode = iter2;
                        if (attachmentNode.tag !== asb.Attachment && attachmentNode.tag !== em.Attachment)
                            continue;
                        var attachment = {
                            name: null,
                            contentId: null,
                            type: null,
                            part: null,
                            encoding: null,
                            sizeEstimate: null,
                            file: null
                        };
                        var isInline = false;
                        for (var iter3 of attachmentNode.children) {
                            var attachData = iter3;
                            var dot, ext;
                            var attachDataText = attachData.children.length ? attachData.children[0].textContent : null;
                            switch (attachData.tag) {
                            case asb.DisplayName:
                            case em.DisplayName:
                                attachment.name = attachDataText;
                                dot = attachment.name.lastIndexOf('.');
                                ext = dot > 0 ? attachment.name.substring(dot + 1).toLowerCase() : '';
                                attachment.type = mimetypes.detectMimeType(ext);
                                break;
                            case asb.FileReference:
                            case em.AttName:
                            case em.Att0Id:
                                attachment.part = attachDataText;
                                break;
                            case asb.EstimatedDataSize:
                            case em.AttSize:
                                attachment.sizeEstimate = parseInt(attachDataText, 10);
                                break;
                            case asb.ContentId:
                                attachment.contentId = attachDataText;
                                break;
                            case asb.IsInline:
                                isInline = attachDataText === '1';
                                break;
                            }
                        }
                        if (isInline)
                            body.relatedParts.push(mailRep.makeAttachmentPart(attachment));
                        else
                            body.attachments.push(mailRep.makeAttachmentPart(attachment));
                    }
                    header.hasAttachments = body.attachments.length > 0;
                    break;
                }
            }
            if (isAdded) {
                body.bodyReps = [mailRep.makeBodyPart({
                        type: bodyType,
                        sizeEstimate: bodySize,
                        amountDownloaded: 0,
                        isDownloaded: false
                    })];
                return {
                    header: mailRep.makeHeaderInfo(header),
                    body: mailRep.makeBodyInfo(body)
                };
            } else {
                return {
                    header: header,
                    body: body
                };
            }
        },
        downloadBodies: function (headers, options, callback) {
            if (this._account.conn.currentVersion.lt('12.0'))
                return this._syncBodies(headers, callback);
            var downloadsNeeded = 0, folderConn = this;
            var latch = allback.latch();
            for (var i = 0; i < headers.length; i++) {
                var header = headers[i];
                if (!header || header.snippet !== null) {
                    continue;
                }
                downloadsNeeded++;
                this.downloadBodyReps(header, options, latch.defer(header.suid));
            }
            latch.then(function (results) {
                callback(allback.extractErrFromCallbackArgs(results), downloadsNeeded);
            });
        },
        downloadBodyReps: lazyConnection(1, function (header, options, callback) {
            var folderConn = this;
            var account = this._account;
            if (account.conn.currentVersion.lt('12.0'))
                return this._syncBodies([header], callback);
            if (typeof options === 'function') {
                callback = options;
                options = null;
            }
            options = options || {};
            var io = $ItemOperations.Tags;
            var ioEnum = $ItemOperations.Enums;
            var as = $AirSync.Tags;
            var asEnum = $AirSync.Enums;
            var asb = $AirSyncBase.Tags;
            var Type = $AirSyncBase.Enums.Type;
            var gotBody = function gotBody(bodyInfo) {
                if (!bodyInfo)
                    return callback('unknown');
                var bodyRep = bodyInfo.bodyReps[0];
                var bodyType = bodyRep.type === 'html' ? Type.HTML : Type.PlainText;
                var truncationSize;
                if (options.maximumBytesToFetch < bodyRep.sizeEstimate) {
                    bodyType = Type.PlainText;
                    truncationSize = DESIRED_TEXT_SNIPPET_BYTES;
                }
                var w = new $wbxml.Writer('1.3', 1, 'UTF-8');
                w.stag(io.ItemOperations).stag(io.Fetch).tag(io.Store, 'Mailbox').tag(as.CollectionId, folderConn.serverId).tag(as.ServerId, header.srvid).stag(io.Options).stag(io.Schema).tag(asb.Body).etag().stag(asb.BodyPreference).tag(asb.Type, bodyType);
                if (truncationSize)
                    w.tag(asb.TruncationSize, truncationSize);
                w.etag().etag().etag().etag();
                account.conn.postCommand(w, function (aError, aResponse) {
                    if (aError) {
                        console.error(aError);
                        account._reportErrorIfNecessary(aError);
                        callback('unknown');
                        return;
                    }
                    var status, bodyContent, parseError, e = new $wbxml.EventParser();
                    e.addEventListener([
                        io.ItemOperations,
                        io.Status
                    ], function (node) {
                        status = node.children[0].textContent;
                    });
                    e.addEventListener([
                        io.ItemOperations,
                        io.Response,
                        io.Fetch,
                        io.Properties,
                        asb.Body,
                        asb.Data
                    ], function (node) {
                        bodyContent = node.children[0].textContent;
                    });
                    try {
                        e.run(aResponse);
                    } catch (ex) {
                        return callback('unknown');
                    }
                    if (status !== ioEnum.Status.Success)
                        return callback('unknown');
                    folderConn._updateBody(header, bodyInfo, bodyContent, !!truncationSize, callback);
                });
            };
            this._storage.getMessageBody(header.suid, header.date, gotBody);
        }),
        _syncBodies: function (headers, callback) {
            var as = $AirSync.Tags;
            var asEnum = $AirSync.Enums;
            var em = $Email.Tags;
            var folderConn = this;
            var account = this._account;
            var w = new $wbxml.Writer('1.3', 1, 'UTF-8');
            w.stag(as.Sync).stag(as.Collections).stag(as.Collection).tag(as.Class, 'Email').tag(as.SyncKey, this.syncKey).tag(as.CollectionId, this.serverId).stag(as.Options).tag(as.MIMESupport, asEnum.MIMESupport.Never).etag().stag(as.Commands);
            for (var i = 0; i < headers.length; i++) {
                w.stag(as.Fetch).tag(as.ServerId, headers[i].srvid).etag();
            }
            w.etag().etag().etag().etag();
            account.conn.postCommand(w, function (aError, aResponse) {
                if (aError) {
                    console.error(aError);
                    account._reportErrorIfNecessary(aError);
                    callback('unknown');
                    return;
                }
                var latch = allback.latch();
                var iHeader = 0;
                var e = new $wbxml.EventParser();
                var base = [
                    as.Sync,
                    as.Collections,
                    as.Collection
                ];
                e.addEventListener(base.concat(as.SyncKey), function (node) {
                    folderConn.syncKey = node.children[0].textContent;
                });
                e.addEventListener(base.concat(as.Status), function (node) {
                    var status = node.children[0].textContent;
                    if (status !== asEnum.Status.Success) {
                        latch.defer('status')('unknown');
                    }
                });
                e.addEventListener(base.concat(as.Responses, as.Fetch, as.ApplicationData, em.Body), function (node) {
                    var header = headers[iHeader++];
                    var bodyContent = node.children[0].textContent;
                    var latchCallback = latch.defer(header.suid);
                    folderConn._storage.getMessageBody(header.suid, header.date, function (body) {
                        folderConn._updateBody(header, body, bodyContent, false, latchCallback);
                    });
                });
                e.run(aResponse);
                latch.then(function (results) {
                    callback(allback.extractErrFromCallbackArgs(results));
                });
            });
        },
        _activeSyncHeaderIsSeen: function (header) {
            for (var i = 0; i < header.flags.length; i++) {
                if (header.flags[i][0] === '\\Seen' && header.flags[i][1]) {
                    return true;
                }
            }
            return false;
        },
        _updateBody: function (header, bodyInfo, bodyContent, snippetOnly, callback) {
            var bodyRep = bodyInfo.bodyReps[0];
            if (!bodyContent) {
                bodyContent = '';
            }
            bodyContent = bodyContent.replace(/\r/g, '');
            var type = snippetOnly ? 'plain' : bodyRep.type;
            var data = $mailchew.processMessageContent(bodyContent, type, !snippetOnly, true);
            header.snippet = data.snippet;
            bodyRep.isDownloaded = !snippetOnly;
            bodyRep.amountDownloaded = bodyContent.length;
            if (!snippetOnly)
                bodyRep.content = data.content;
            var event = { changeDetails: { bodyReps: [0] } };
            var latch = allback.latch();
            this._storage.updateMessageHeader(header.date, header.id, false, header, bodyInfo, latch.defer('header'));
            this._storage.updateMessageBody(header, bodyInfo, {}, event, latch.defer('body'));
            latch.then(callback.bind(null, null, bodyInfo, false));
        },
        sync: lazyConnection(1, function asfc_sync(accuracyStamp, doneCallback, progressCallback) {
            var folderConn = this, addedMessages = 0, changedMessages = 0, deletedMessages = 0;
            logic(this, 'sync_begin');
            var self = this;
            this._enumerateFolderChanges(function (error, added, changed, deleted, moreAvailable) {
                var storage = folderConn._storage;
                if (error === 'badkey') {
                    folderConn.syncKey = '0';
                    folderConn._account._recreateFolder(storage.folderId, function (s) {
                        folderConn._storage = null;
                        logic(folderConn, 'sync_end', {
                            full: null,
                            changed: null,
                            deleted: null
                        });
                    });
                    return;
                } else if (error === 'checkAccount') {
                    folderConn._account.syncFolderList(error => {
                        doneCallback(error);
                    });
                    return;
                } else if (error) {
                    logic(folderConn, 'sync_end', {
                        full: null,
                        changed: null,
                        deleted: null
                    });
                    doneCallback(error);
                    return;
                }
                var latch = allback.latch();
                for (var iter of added) {
                    var message = iter;
                    if (storage.hasMessageWithServerId(message.header.srvid))
                        continue;
                    storage.addMessageHeader(message.header, message.body, latch.defer());
                    storage.addMessageBody(message.header, message.body, latch.defer());
                    addedMessages++;
                }
                for (var iter of changed) {
                    var message = iter;
                    if (!storage.hasMessageWithServerId(message.header.srvid))
                        continue;
                    storage.updateMessageHeaderByServerId(message.header.srvid, true, function (message, oldHeader) {
                        if (!self._activeSyncHeaderIsSeen(oldHeader) && self._activeSyncHeaderIsSeen(message.header)) {
                            storage.folderMeta.unreadCount--;
                        } else if (self._activeSyncHeaderIsSeen(oldHeader) && !self._activeSyncHeaderIsSeen(message.header)) {
                            storage.folderMeta.unreadCount++;
                        }
                        message.header.mergeInto(oldHeader);
                        return true;
                    }.bind(null, message), null, latch.defer());
                    changedMessages++;
                }
                for (var iter of deleted) {
                    var messageGuid = iter;
                    if (!storage.hasMessageWithServerId(messageGuid))
                        continue;
                    storage.deleteMessageByServerId(messageGuid, latch.defer());
                    deletedMessages++;
                }
                if (!moreAvailable) {
                    var messagesSeen = addedMessages + changedMessages + deletedMessages;
                    latch.then(function () {
                        logic(folderConn, 'sync_end', {
                            full: addedMessages,
                            changed: changedMessages,
                            deleted: deletedMessages
                        });
                        storage.markSyncRange($sync.OLDEST_SYNC_DATE, accuracyStamp, 'XXX', accuracyStamp);
                        doneCallback(null, null, messagesSeen);
                    });
                }
            }, progressCallback);
        }),
        performMutation: lazyConnection(1, function (invokeWithWriter, callWhenDone) {
            var folderConn = this;
            var as = $AirSync.Tags;
            var account = this._account;
            var w = new $wbxml.Writer('1.3', 1, 'UTF-8');
            w.stag(as.Sync).stag(as.Collections).stag(as.Collection);
            if (account.conn.currentVersion.lt('12.1'))
                w.tag(as.Class, 'Email');
            w.tag(as.SyncKey, this.syncKey).tag(as.CollectionId, this.serverId).tag(as.DeletesAsMoves, this.folderMeta.type === 'trash' ? '0' : '1').tag(as.GetChanges, '0').stag(as.Commands);
            try {
                invokeWithWriter(w);
            } catch (ex) {
                console.error('Exception in performMutation callee:', ex, '\n', ex.stack);
                callWhenDone('unknown');
                return;
            }
            w.etag(as.Commands).etag(as.Collection).etag(as.Collections).etag(as.Sync);
            account.conn.postCommand(w, function (aError, aResponse) {
                if (aError) {
                    console.error('postCommand error:', aError);
                    account._reportErrorIfNecessary(aError);
                    callWhenDone('unknown');
                    return;
                }
                var e = new $wbxml.EventParser();
                var syncKey, status;
                var base = [
                    as.Sync,
                    as.Collections,
                    as.Collection
                ];
                e.addEventListener(base.concat(as.SyncKey), function (node) {
                    syncKey = node.children[0].textContent;
                });
                e.addEventListener(base.concat(as.Status), function (node) {
                    status = node.children[0].textContent;
                });
                try {
                    e.run(aResponse);
                } catch (ex) {
                    console.error('Error parsing Sync response:', ex, '\n', ex.stack);
                    callWhenDone('unknown');
                    return;
                }
                if (status === $AirSync.Enums.Status.Success) {
                    folderConn.syncKey = syncKey;
                    if (callWhenDone)
                        callWhenDone(null);
                } else {
                    console.error('Something went wrong during ActiveSync syncing and we ' + 'got a status of ' + status);
                    callWhenDone('status:' + status);
                }
            });
        }),
        downloadMessageAttachments: lazyConnection(2, function (uid, partInfos, callback, progress) {
            var folderConn = this;
            var io = $ItemOperations.Tags;
            var ioStatus = $ItemOperations.Enums.Status;
            var asb = $AirSyncBase.Tags;
            var w = new $wbxml.Writer('1.3', 1, 'UTF-8');
            w.stag(io.ItemOperations);
            for (var iter of partInfos) {
                var part = iter;
                w.stag(io.Fetch).tag(io.Store, 'Mailbox').tag(asb.FileReference, part.part).etag();
            }
            w.etag();
            this._account.conn.postCommand(w, function (aError, aResult) {
                if (aError) {
                    console.error('postCommand error:', aError);
                    folderConn._account._reportErrorIfNecessary(aError);
                    callback('unknown');
                    return;
                }
                var globalStatus;
                var attachments = {};
                var e = new $wbxml.EventParser();
                e.addEventListener([
                    io.ItemOperations,
                    io.Status
                ], function (node) {
                    globalStatus = node.children[0].textContent;
                });
                e.addEventListener([
                    io.ItemOperations,
                    io.Response,
                    io.Fetch
                ], function (node) {
                    var part = null, attachment = {};
                    for (var iter of node.children) {
                        var child = iter;
                        switch (child.tag) {
                        case io.Status:
                            attachment.status = child.children[0].textContent;
                            break;
                        case asb.FileReference:
                            part = child.children[0].textContent;
                            break;
                        case io.Properties:
                            var contentType = null, data = null;
                            for (var iter2 of child.children) {
                                var grandchild = iter2;
                                var textContent = grandchild.children[0].textContent;
                                switch (grandchild.tag) {
                                case asb.ContentType:
                                    contentType = textContent;
                                    break;
                                case io.Data:
                                    data = safeBase64.decode(textContent);
                                    break;
                                }
                            }
                            if (contentType && data)
                                attachment.data = new Blob([data], { type: contentType });
                            break;
                        }
                        if (part)
                            attachments[part] = attachment;
                    }
                });
                e.run(aResult);
                var error = globalStatus !== ioStatus.Success ? 'unknown' : null;
                var bodies = [];
                for (var iter of partInfos) {
                    var part = iter;
                    if (attachments.hasOwnProperty(part.part) && attachments[part.part].status === ioStatus.Success) {
                        bodies.push(attachments[part.part].data);
                    } else {
                        error = 'unknown';
                        bodies.push(null);
                    }
                }
                callback(error, bodies);
            });
        })
    };
    function ActiveSyncFolderSyncer(account, folderStorage) {
        this._account = account;
        this.folderStorage = folderStorage;
        logic.defineScope(this, 'ActiveSyncFolderSyncer', {
            accountId: account.id,
            folderId: folderStorage.folderId
        });
        this.folderConn = new ActiveSyncFolderConn(account, folderStorage);
    }
    exports.ActiveSyncFolderSyncer = ActiveSyncFolderSyncer;
    ActiveSyncFolderSyncer.prototype = {
        get syncable() {
            return this.folderConn.serverId !== null;
        },
        get canGrowSync() {
            return false;
        },
        initialSync: function (slice, initialDays, syncCallback, doneCallback, progressCallback) {
            syncCallback('sync', true);
            this.folderConn.sync($date.NOW(), this.onSyncCompleted.bind(this, doneCallback, true), progressCallback);
        },
        refreshSync: function (slice, dir, startTS, endTS, origStartTS, doneCallback, progressCallback) {
            this.folderConn.sync($date.NOW(), this.onSyncCompleted.bind(this, doneCallback, false), progressCallback);
        },
        growSync: function (slice, growthDirection, anchorTS, syncStepDays, doneCallback, progressCallback) {
            return false;
        },
        onSyncCompleted: function ifs_onSyncCompleted(doneCallback, initialSync, err, bisectInfo, messagesSeen) {
            var storage = this.folderStorage;
            console.log('Sync Completed!', messagesSeen, 'messages synced');
            if (!err)
                storage.markSyncedToDawnOfTime();
            this._account.__checkpointSyncCompleted(function () {
                if (err) {
                    doneCallback(err);
                } else if (initialSync) {
                    storage._curSyncSlice.ignoreHeaders = false;
                    storage._curSyncSlice.waitingOnData = 'db';
                    storage.getMessagesInImapDateRange(0, null, $sync.INITIAL_FILL_SIZE, $sync.INITIAL_FILL_SIZE, storage.onFetchDBHeaders.bind(storage, storage._curSyncSlice, false, doneCallback, null));
                } else {
                    doneCallback(err);
                }
            });
        },
        allConsumersDead: function () {
        },
        shutdown: function () {
            this.folderConn.shutdown();
        }
    };
});
;
define('activesync/jobs', [
    'logic',
    'mix',
    '../jobmixins',
    '../drafts/jobs',
    'activesync/codepages/AirSync',
    'activesync/codepages/Email',
    'activesync/codepages/Move',
    'module',
    'require',
    'exports'
], function (logic, mix, $jobmixins, draftsJobs, $AirSync, $Email, $Move, $module, require, exports) {
    'use strict';
    var $wbxml;
    function lazyConnection(cbIndex, fn, failString) {
        return function lazyRun() {
            var args = Array.prototype.slice.call(arguments), errback = args[cbIndex], self = this;
            require(['wbxml'], function (wbxml) {
                if (!$wbxml) {
                    $wbxml = wbxml;
                }
                self.account.withConnection(errback, function () {
                    fn.apply(self, args);
                }, failString);
            });
        };
    }
    function ActiveSyncJobDriver(account, state) {
        this.account = account;
        this.resilientServerIds = true;
        this._heldMutexReleasers = [];
        logic.defineScope(this, 'ActiveSyncJobDriver', { accountId: this.account.id });
        this._state = state;
        if (!state.hasOwnProperty('suidToServerId')) {
            state.suidToServerId = {};
            state.moveMap = {};
        }
        this._stateDelta = {
            serverIdMap: null,
            moveMap: null
        };
    }
    exports.ActiveSyncJobDriver = ActiveSyncJobDriver;
    ActiveSyncJobDriver.prototype = {
        postJobCleanup: $jobmixins.postJobCleanup,
        allJobsDone: $jobmixins.allJobsDone,
        _accessFolderForMutation: function (folderId, needConn, callback, deathback, label) {
            var storage = this.account.getFolderStorageForFolderId(folderId), self = this;
            storage.runMutexed(label, function (releaseMutex) {
                self._heldMutexReleasers.push(releaseMutex);
                var syncer = storage.folderSyncer;
                if (needConn) {
                    self.account.withConnection(callback, function () {
                        try {
                            callback(syncer.folderConn, storage);
                        } catch (ex) {
                            logic(self, 'callbackErr', { ex: ex });
                        }
                    });
                } else {
                    try {
                        callback(syncer.folderConn, storage);
                    } catch (ex) {
                        logic(self, 'callbackErr', { ex: ex });
                    }
                }
            });
        },
        _partitionAndAccessFoldersSequentially: $jobmixins._partitionAndAccessFoldersSequentially,
        local_do_modtags: $jobmixins.local_do_modtags,
        do_modtags: lazyConnection(1, function (op, jobDoneCallback, undo) {
            var addTags = undo ? op.removeTags : op.addTags, removeTags = undo ? op.addTags : op.removeTags;
            function getMark(tag) {
                if (addTags && addTags.indexOf(tag) !== -1)
                    return true;
                if (removeTags && removeTags.indexOf(tag) !== -1)
                    return false;
                return undefined;
            }
            var markRead = getMark('\\Seen');
            var markFlagged = getMark('\\Flagged');
            var as = $AirSync.Tags;
            var em = $Email.Tags;
            var aggrErr = null;
            this._partitionAndAccessFoldersSequentially(op.messages, true, function perFolder(folderConn, storage, serverIds, namers, callWhenDone) {
                var modsToGo = 0;
                function tagsModded(err) {
                    if (err) {
                        console.error('failure modifying tags', err);
                        aggrErr = 'unknown';
                        return;
                    }
                    op.progress += undo ? -serverIds.length : serverIds.length;
                    if (--modsToGo === 0)
                        callWhenDone();
                }
                serverIds = serverIds.filter(function (srvid) {
                    return !!srvid;
                });
                if (!serverIds.length) {
                    callWhenDone();
                    return;
                }
                folderConn.performMutation(function withWriter(w) {
                    for (var i = 0; i < serverIds.length; i++) {
                        w.stag(as.Change).tag(as.ServerId, serverIds[i]).stag(as.ApplicationData);
                        if (markRead !== undefined)
                            w.tag(em.Read, markRead ? '1' : '0');
                        if (markFlagged !== undefined)
                            w.stag(em.Flag).tag(em.Status, markFlagged ? '2' : '0').etag();
                        w.etag(as.ApplicationData).etag(as.Change);
                    }
                }, function mutationPerformed(err) {
                    if (err)
                        aggrErr = err;
                    callWhenDone();
                });
            }, function allDone() {
                jobDoneCallback(aggrErr);
            }, function deadConn() {
                aggrErr = 'aborted-retry';
            }, undo, 'modtags');
        }),
        check_modtags: function (op, callback) {
            callback(null, 'idempotent');
        },
        local_undo_modtags: $jobmixins.local_undo_modtags,
        undo_modtags: function (op, callback) {
            this.do_modtags(op, callback, true);
        },
        local_do_move: $jobmixins.local_do_move,
        do_move: lazyConnection(1, function (op, jobDoneCallback) {
            var aggrErr = null, account = this.account, targetFolderStorage = this.account.getFolderStorageForFolderId(op.targetFolder);
            var mo = $Move.Tags;
            this._partitionAndAccessFoldersSequentially(op.messages, true, function perFolder(folderConn, storage, serverIds, namers, callWhenDone) {
                serverIds = serverIds.filter(function (srvid) {
                    return !!srvid;
                });
                if (!serverIds.length) {
                    callWhenDone();
                    return;
                }
                serverIds = serverIds.filter(function (srvid) {
                    return !!srvid;
                });
                if (!serverIds.length) {
                    callWhenDone();
                    return;
                }
                var w = new $wbxml.Writer('1.3', 1, 'UTF-8');
                w.stag(mo.MoveItems);
                for (var i = 0; i < serverIds.length; i++) {
                    w.stag(mo.Move).tag(mo.SrcMsgId, serverIds[i]).tag(mo.SrcFldId, storage.folderMeta.serverId).tag(mo.DstFldId, targetFolderStorage.folderMeta.serverId).etag(mo.Move);
                }
                w.etag(mo.MoveItems);
                account.conn.postCommand(w, function (err, response) {
                    let e = new $wbxml.EventParser();
                    if (err) {
                        aggrErr = err;
                        console.error('failure moving messages:', err);
                    }
                    const st = $Move.Enums.Status;
                    e.addEventListener([
                        mo.MoveItems,
                        mo.Response,
                        mo.Status
                    ], node => {
                        const status = node.children[0].textContent;
                        if (status != st.Success) {
                            console.error('failure moving messages' + status);
                        }
                    });
                    let count = 0;
                    e.addEventListener([
                        mo.MoveItems,
                        mo.Response,
                        mo.DstMsgId
                    ], node => {
                        const value = node.children[0].textContent;
                        (function (count) {
                            const moveSuid = op.messages[count].moveSuid;
                            const date = namers[count].date;
                            targetFolderStorage.getMessageHeader(moveSuid, date, header => {
                                let _header = header;
                                targetFolderStorage.deleteMessageHeaderUsingHeader(_header, () => {
                                    _header.srvid = value;
                                    targetFolderStorage.addMessageHeader(_header, null, () => {
                                        console.log(' addMessageHeader callback');
                                    });
                                });
                            });
                        }(count));
                        count++;
                    });
                    try {
                        e.run(response);
                    } catch (ex) {
                        console.error('ex is:' + ex);
                    }
                    callWhenDone();
                });
            }, function allDone() {
                jobDoneCallback(aggrErr, null, true);
            }, function deadConn() {
                aggrErr = 'aborted-retry';
            }, false, 'move');
        }),
        check_move: function (op, jobDoneCallback) {
        },
        local_undo_move: $jobmixins.local_undo_move,
        undo_move: function (op, jobDoneCallback) {
        },
        local_do_delete: $jobmixins.local_do_delete,
        do_delete: lazyConnection(1, function (op, jobDoneCallback) {
            var aggrErr = null;
            var as = $AirSync.Tags;
            var em = $Email.Tags;
            this._partitionAndAccessFoldersSequentially(op.messages, true, function perFolder(folderConn, storage, serverIds, namers, callWhenDone) {
                serverIds = serverIds.filter(function (srvid) {
                    return !!srvid;
                });
                if (!serverIds.length) {
                    callWhenDone();
                    return;
                }
                folderConn.performMutation(function withWriter(w) {
                    for (var i = 0; i < serverIds.length; i++) {
                        w.stag(as.Delete).tag(as.ServerId, serverIds[i]).etag(as.Delete);
                    }
                }, function mutationPerformed(err) {
                    if (err) {
                        aggrErr = err;
                        console.error('failure deleting messages:', err);
                    }
                    callWhenDone();
                });
            }, function allDone() {
                jobDoneCallback(aggrErr, null, true);
            }, function deadConn() {
                aggrErr = 'aborted-retry';
            }, false, 'delete');
        }),
        check_delete: function (op, callback) {
            callback(null, 'idempotent');
        },
        local_undo_delete: $jobmixins.local_undo_delete,
        undo_delete: function (op, callback) {
            callback('moot');
        },
        local_do_syncFolderList: function (op, doneCallback) {
            doneCallback(null);
        },
        do_syncFolderList: lazyConnection(1, function (op, doneCallback) {
            var account = this.account, self = this;
            var inboxFolder = account.getFirstFolderWithType('inbox'), inboxStorage;
            if (inboxFolder && inboxFolder.serverId === null)
                inboxStorage = account.getFolderStorageForFolderId(inboxFolder.id);
            account.syncFolderList(function (err) {
                if (!err)
                    account.meta.lastFolderSyncAt = Date.now();
                doneCallback(err ? 'aborted-retry' : null, null, !err);
                if (inboxStorage && inboxStorage.hasActiveSlices) {
                    if (!err) {
                        console.log('Refreshing fake inbox');
                        inboxStorage.resetAndRefreshActiveSlices();
                    }
                }
            });
        }, 'aborted-retry'),
        check_syncFolderList: function (op, doneCallback) {
            doneCallback(null, 'coherent-notyet');
        },
        local_undo_syncFolderList: function (op, doneCallback) {
            doneCallback('moot');
        },
        undo_syncFolderList: function (op, doneCallback) {
            doneCallback('moot');
        },
        local_do_downloadBodies: $jobmixins.local_do_downloadBodies,
        do_downloadBodies: $jobmixins.do_downloadBodies,
        check_downloadBodies: $jobmixins.check_downloadBodies,
        local_do_downloadBodyReps: $jobmixins.local_do_downloadBodyReps,
        do_downloadBodyReps: $jobmixins.do_downloadBodyReps,
        check_downloadBodyReps: $jobmixins.check_downloadBodyReps,
        local_do_download: $jobmixins.local_do_download,
        do_download: $jobmixins.do_download,
        check_download: $jobmixins.check_download,
        local_undo_download: $jobmixins.local_undo_download,
        undo_download: $jobmixins.undo_download,
        local_do_sendOutboxMessages: $jobmixins.local_do_sendOutboxMessages,
        do_sendOutboxMessages: $jobmixins.do_sendOutboxMessages,
        check_sendOutboxMessages: $jobmixins.check_sendOutboxMessages,
        local_undo_sendOutboxMessages: $jobmixins.local_undo_sendOutboxMessages,
        undo_sendOutboxMessages: $jobmixins.undo_sendOutboxMessages,
        local_do_setOutboxSyncEnabled: $jobmixins.local_do_setOutboxSyncEnabled,
        local_do_upgradeDB: $jobmixins.local_do_upgradeDB,
        local_do_purgeExcessMessages: function (op, doneCallback) {
            doneCallback(null);
        },
        do_purgeExcessMessages: function (op, doneCallback) {
            doneCallback(null);
        },
        check_purgeExcessMessages: function (op, doneCallback) {
            return 'idempotent';
        },
        local_undo_purgeExcessMessages: function (op, doneCallback) {
            doneCallback(null);
        },
        undo_purgeExcessMessages: function (op, doneCallback) {
            doneCallback(null);
        }
    };
    mix(ActiveSyncJobDriver.prototype, draftsJobs.draftsMixins);
});
;
define('activesync/account', [
    'logic',
    '../a64',
    '../accountmixins',
    '../mailslice',
    '../searchfilter',
    'activesync/codepages/FolderHierarchy',
    './folder',
    './jobs',
    '../util',
    '../db/folder_info_rep',
    'module',
    'require',
    'exports'
], function (logic, $a64, $acctmixins, $mailslice, $searchfilter, $FolderHierarchy, $asfolder, $asjobs, $util, $folder_info, $module, require, exports) {
    'use strict';
    var $wbxml, $asproto, ASCP;
    var bsearchForInsert = $util.bsearchForInsert;
    var $FolderTypes = $FolderHierarchy.Enums.Type;
    var DEFAULT_TIMEOUT_MS = exports.DEFAULT_TIMEOUT_MS = 30 * 1000;
    exports.makeUniqueDeviceId = function () {
        return Math.random().toString(36).substr(2);
    };
    function lazyConnection(cbIndex, fn, failString) {
        return function lazyRun() {
            var args = Array.prototype.slice.call(arguments), errback = args[cbIndex], self = this;
            this.withConnection(errback, function () {
                fn.apply(self, args);
            }, failString);
        };
    }
    function ActiveSyncAccount(universe, accountDef, folderInfos, dbConn, receiveProtoConn) {
        this.universe = universe;
        this.id = accountDef.id;
        this.accountDef = accountDef;
        this._db = dbConn;
        logic.defineScope(this, 'Account', {
            accountId: this.id,
            accountType: 'activesync'
        });
        if (receiveProtoConn) {
            this.conn = receiveProtoConn;
            this._attachLoggerToConnection(this.conn);
        } else {
            this.conn = null;
        }
        this.enabled = true;
        this.problems = [];
        this._alive = true;
        this.authenticatorId = accountDef.authenticatorId;
        this.syncEnable = accountDef.syncEnable;
        this.public = accountDef.public;
        this.credentials = accountDef.credentials;
        this.identities = accountDef.identities;
        this.folders = [];
        this._folderStorages = {};
        this._folderInfos = folderInfos;
        this._serverIdToFolderId = {};
        this._deadFolderIds = null;
        this._syncsInProgress = 0;
        this._lastSyncKey = null;
        this._lastSyncResponseWasEmpty = false;
        this.meta = folderInfos.$meta;
        this.mutations = folderInfos.$mutations;
        this.doReset = false;
        this.resetAccount = false;
        for (var folderId in folderInfos) {
            if (folderId[0] === '$')
                continue;
            var folderInfo = folderInfos[folderId];
            this._folderStorages[folderId] = new $mailslice.FolderStorage(this, folderId, folderInfo, this._db, $asfolder.ActiveSyncFolderSyncer);
            this._serverIdToFolderId[folderInfo.$meta.serverId] = folderId;
            this.folders.push(folderInfo.$meta);
        }
        this.folders.sort(function (a, b) {
            return a.path.localeCompare(b.path);
        });
        this._jobDriver = new $asjobs.ActiveSyncJobDriver(this, this._folderInfos.$mutationState);
        this.ensureEssentialOfflineFolders();
        $acctmixins.accountConstructorMixin.call(this, this, this);
    }
    exports.Account = exports.ActiveSyncAccount = ActiveSyncAccount;
    ActiveSyncAccount.prototype = {
        type: 'activesync',
        supportsServerFolders: true,
        toString: function asa_toString() {
            return '[ActiveSyncAccount: ' + this.id + ']';
        },
        withConnection: function (errback, callback, failString) {
            if (!$wbxml) {
                require([
                    'wbxml',
                    'activesync/protocol',
                    'activesync/codepages'
                ], function (_wbxml, _asproto, _ASCP) {
                    $wbxml = _wbxml;
                    $asproto = _asproto;
                    ASCP = _ASCP;
                    this.withConnection(errback, callback, failString);
                }.bind(this));
                return;
            }
            if (!this.conn) {
                var accountDef = this.accountDef;
                this.conn = new $asproto.Connection(accountDef.connInfo.deviceId, accountDef.connInfo.policyKey);
                this._attachLoggerToConnection(this.conn);
                this.conn.open(accountDef.connInfo.server, accountDef.credentials.username, accountDef.credentials.password);
                this.conn.timeout = DEFAULT_TIMEOUT_MS;
            }
            if (!this.conn.connected) {
                this.conn.connect(function (error) {
                    if (error) {
                        this._reportErrorIfNecessary(error);
                        if (this._isBadUserOrPassError(error) && !failString) {
                            failString = 'bad-user-or-pass';
                        }
                        errback(failString || 'unknown');
                        return;
                    }
                    var policyKey = this.conn.policyKey;
                    if (this.accountDef.connInfo.policyKey !== policyKey) {
                        this.accountDef.connInfo.policyKey = policyKey;
                        this.universe.saveAccountDef(this.accountDef);
                    }
                    callback();
                }.bind(this));
            } else {
                callback();
            }
        },
        _isBadUserOrPassError: function (error) {
            return error && error instanceof $asproto.HttpError && error.status === 401;
        },
        _reportErrorIfNecessary: function (error) {
            if (!error) {
                return;
            }
            if (this._isBadUserOrPassError(error)) {
                this.universe.__reportAccountProblem(this, 'bad-user-or-pass', 'incoming');
            }
        },
        _attachLoggerToConnection: function (conn) {
            logic.defineScope(conn, 'ActiveSyncConnection', { connectionId: logic.uniqueId() });
            if (!logic.isCensored) {
                conn.onmessage = this._onmessage_dangerous.bind(this, conn);
            } else {
                conn.onmessage = this._onmessage_safe.bind(this, conn);
            }
        },
        _onmessage_safe: function onmessage(conn, type, special, xhr, params, extraHeaders, sentData, response) {
            if (type === 'options') {
                logic(conn, 'options', {
                    special: special,
                    status: xhr.status,
                    response: response
                });
            } else {
                logic(conn, 'command', {
                    type: type,
                    special: special,
                    status: xhr.status
                });
            }
        },
        _onmessage_dangerous: function onmessage(conn, type, special, xhr, params, extraHeaders, sentData, response) {
            if (type === 'options') {
                logic(conn, 'options', {
                    special: special,
                    status: xhr.status,
                    response: response
                });
            } else {
                var sentXML, receivedXML;
                if (sentData) {
                    try {
                        var sentReader = new $wbxml.Reader(new Uint8Array(sentData), ASCP);
                        sentXML = sentReader.dump();
                    } catch (ex) {
                        sentXML = 'parse problem';
                    }
                }
                if (response) {
                    try {
                        receivedXML = response.dump();
                        response.rewind();
                    } catch (ex) {
                        receivedXML = 'parse problem';
                    }
                }
                logic(conn, 'command', {
                    type: type,
                    special: special,
                    status: xhr.status,
                    params: params,
                    extraHeaders: extraHeaders,
                    sentXML: sentXML,
                    receivedXML: receivedXML
                });
            }
        },
        toBridgeWire: function asa_toBridgeWire() {
            return {
                id: this.accountDef.id,
                name: this.accountDef.name,
                authenticatorId: this.accountDef.authenticatorId,
                label: this.accountDef.label,
                path: this.accountDef.name,
                type: this.accountDef.type,
                defaultPriority: this.accountDef.defaultPriority,
                enabled: this.enabled,
                problems: this.problems,
                syncRange: this.accountDef.syncRange,
                syncInterval: this.accountDef.syncInterval,
                notifyOnNew: this.accountDef.notifyOnNew,
                playSoundOnSend: this.accountDef.playSoundOnSend,
                syncEnable: this.accountDef.syncEnable,
                public: this.accountDef.public,
                identities: this.identities,
                credentials: {
                    username: this.accountDef.credentials.username,
                    password: this.accountDef.credentials.password
                },
                servers: [{
                        type: this.accountDef.type,
                        connInfo: this.accountDef.connInfo
                    }]
            };
        },
        toBridgeFolder: function asa_toBridgeFolder() {
            return {
                id: this.accountDef.id,
                name: this.accountDef.name,
                path: this.accountDef.name,
                type: 'account'
            };
        },
        get numActiveConns() {
            return 0;
        },
        checkAccount: function (callback) {
            if (this.conn !== null) {
                if (this.conn.connected) {
                    this.conn.disconnect();
                }
                this.conn = null;
            }
            this.withConnection(function (err) {
                callback(err);
            }, function () {
                callback();
            });
        },
        __checkpointSyncCompleted: function (callback, betterReason) {
            this.saveAccountState(null, callback, betterReason || 'checkpointSync');
        },
        shutdown: function asa_shutdown(callback) {
            if (callback)
                callback();
        },
        accountDeleted: function asa_accountDeleted() {
            this._alive = false;
            this.shutdown();
        },
        sliceFolderMessages: function asa_sliceFolderMessages(folderId, bridgeHandle) {
            var storage = this._folderStorages[folderId], slice = new $mailslice.MailSlice(bridgeHandle, storage);
            storage.sliceOpenMostRecent(slice);
        },
        sortFolderMessages: function (folderId, bridgeHandle, fillSize) {
            var storage = this._folderStorages[folderId], slice = new $mailslice.MailSlice(bridgeHandle, storage, fillSize);
            storage.sliceOpenMostRecent(slice);
        },
        searchFolderMessages: function (folderId, bridgeHandle, phrase, whatToSearch) {
            var storage = this._folderStorages[folderId], slice = new $searchfilter.SearchSlice(bridgeHandle, storage, phrase, whatToSearch);
            storage.sliceOpenSearch(slice);
            return slice;
        },
        syncFolderList: lazyConnection(0, function asa_syncFolderList(callback) {
            var account = this;
            var fh = ASCP.FolderHierarchy.Tags;
            var w = new $wbxml.Writer('1.3', 1, 'UTF-8');
            w.stag(fh.FolderSync).tag(fh.SyncKey, this.meta.syncKey).etag();
            this.conn.postCommand(w, function (aError, aResponse) {
                var needGetPolicy = false;
                if (aError) {
                    if (aError.status === 449) {
                        needGetPolicy = true;
                    } else {
                        account._reportErrorIfNecessary(aError);
                        callback(aError);
                        return;
                    }
                }
                var e = new $wbxml.EventParser();
                var deferredAddedFolders = [];
                var ace = ASCP.Common.Enums;
                var afe = ASCP.FolderHierarchy.Enums;
                e.addEventListener([
                    fh.FolderSync,
                    fh.Status
                ], function (node) {
                    var status = node.children[0].textContent;
                    if (status !== afe.Status.Success) {
                        if (status === ace.Status.PolicyRefresh || status === ace.Status.InvalidPolicyKey || needGetPolicy) {
                            console.log('Policy need refresh!!!');
                            var self = account;
                            account.conn.getPolicyKey(false, function (aError) {
                                if (aError) {
                                    callback(aError);
                                    return;
                                }
                                self.conn.getPolicyKey(true, function (error) {
                                    if (error) {
                                        callback(error);
                                        return;
                                    }
                                    self.accountDef.connInfo.policyKey = self.conn.policyKey;
                                    self.universe.saveAccountDef(self.accountDef);
                                });
                            });
                        } else if (status === ace.Status.RemoteWipeRequested) {
                            account.conn.deviceWipe(function (aError) {
                                if (aError) {
                                    callback(aError);
                                }
                            });
                        } else {
                            if (status === afe.Status.InvalidSyncKey) {
                                account.resetAccount = true;
                                account._clearAllFolders();
                                account.meta.syncKey = '0';
                            }
                            aError = 'Sync folder list error, folder error status: ' + status;
                            account._reportErrorIfNecessary(aError);
                            callback(aError);
                        }
                    }
                });
                e.addEventListener([
                    fh.FolderSync,
                    fh.SyncKey
                ], function (node) {
                    account.meta.syncKey = node.children[0].textContent;
                });
                e.addEventListener([
                    fh.FolderSync,
                    fh.Changes,
                    [
                        fh.Add,
                        fh.Delete,
                        fh.Update
                    ]
                ], function (node) {
                    var folder = {};
                    for (var iter of node.children) {
                        var child = iter;
                        folder[child.localTagName] = child.children[0].textContent;
                    }
                    if (account.resetAccount && !account.doReset) {
                        account.doReset = true;
                    }
                    if (node.tag === fh.Add) {
                        if (!account._addedFolder(folder.ServerId, folder.ParentId, folder.DisplayName, folder.Type)) {
                            deferredAddedFolders.push(folder);
                        }
                    } else {
                        account._updateFolder(folder, node.tag === fh.Delete);
                    }
                });
                try {
                    e.run(aResponse);
                } catch (ex) {
                    console.error('Error parsing FolderSync response:', ex, '\n', ex.stack);
                    callback('unknown');
                    return;
                }
                while (deferredAddedFolders.length) {
                    var moreDeferredAddedFolders = [];
                    for (var iter of deferredAddedFolders) {
                        var folder = iter;
                        if (!account._addedFolder(folder.ServerId, folder.ParentId, folder.DisplayName, folder.Type))
                            moreDeferredAddedFolders.push(folder);
                    }
                    if (moreDeferredAddedFolders.length === deferredAddedFolders.length)
                        throw new Error('got some orphaned folders');
                    deferredAddedFolders = moreDeferredAddedFolders;
                }
                account.ensureEssentialOnlineFolders();
                account.normalizeFolderHierarchy();
                if (account.doReset) {
                    account.resetAccount = false;
                    account.doReset = false;
                    account.universe.__notifyResetAccount(account);
                }
                console.log('Synced folder list');
                callback && callback(null);
            });
        }),
        _folderTypes: {
            1: 'normal',
            2: 'inbox',
            3: 'drafts',
            4: 'trash',
            5: 'sent',
            6: 'normal',
            12: 'normal'
        },
        _junkFolderNames: [
            'bulk mail',
            'correo no deseado',
            'courrier indésirable',
            'istenmeyen',
            'istenmeyen e-posta',
            'junk',
            'levélszemét',
            'nevyžiadaná pošta',
            'nevyžádaná pošta',
            'no deseado',
            'posta indesiderata',
            'pourriel',
            'roskaposti',
            'skräppost',
            'spam',
            'spamowanie',
            'søppelpost',
            'thư rác',
            'спам',
            'דואר זבל',
            'الرسائل العشوائية',
            'هرزنامه',
            'สแปม',
            '垃圾郵件',
            '垃圾邮件',
            '垃圾電郵'
        ],
        _addedFolder: function asa__addedFolder(serverId, parentServerId, displayName, typeNum, forceType, suppressNotification) {
            if (!forceType && !(typeNum in this._folderTypes))
                return true;
            var path = displayName;
            var parentFolderId = null;
            var depth = 0;
            if (parentServerId !== '0') {
                parentFolderId = this._serverIdToFolderId[parentServerId];
                if (parentFolderId === undefined)
                    return null;
                var parent = this._folderInfos[parentFolderId];
                path = parent.$meta.path + '/' + path;
                depth = parent.$meta.depth + 1;
            }
            var useFolderType = this._folderTypes[typeNum];
            if (depth < 2) {
                var normalizedName = displayName.toLowerCase();
                if (this._junkFolderNames.indexOf(normalizedName) !== -1) {
                    useFolderType = 'junk';
                }
            }
            if (forceType) {
                useFolderType = forceType;
            }
            if (typeNum === $FolderTypes.DefaultInbox) {
                var existingInboxMeta = this.getFirstFolderWithType('inbox');
                if (existingInboxMeta) {
                    delete this._serverIdToFolderId[existingInboxMeta.serverId];
                    this._serverIdToFolderId[serverId] = existingInboxMeta.id;
                    existingInboxMeta.serverId = serverId;
                    existingInboxMeta.name = displayName;
                    existingInboxMeta.path = path;
                    existingInboxMeta.depth = depth;
                    return existingInboxMeta;
                }
            }
            var folderId = this.id + '/' + $a64.encodeInt(this.meta.nextFolderNum++);
            var folderInfo = this._folderInfos[folderId] = {
                $meta: $folder_info.makeFolderMeta({
                    id: folderId,
                    serverId: serverId,
                    name: displayName,
                    type: useFolderType,
                    path: path,
                    parentId: parentFolderId,
                    depth: depth,
                    lastSyncedAt: 0,
                    syncKey: '0',
                    version: $mailslice.FOLDER_DB_VERSION
                }),
                $impl: {
                    nextId: 0,
                    nextHeaderBlock: 0,
                    nextBodyBlock: 0
                },
                accuracy: [],
                headerBlocks: [],
                bodyBlocks: [],
                serverIdHeaderBlockMapping: {}
            };
            console.log('Added folder ' + displayName + ' (' + folderId + ')');
            this._folderStorages[folderId] = new $mailslice.FolderStorage(this, folderId, folderInfo, this._db, $asfolder.ActiveSyncFolderSyncer);
            this._serverIdToFolderId[serverId] = folderId;
            var folderMeta = folderInfo.$meta;
            var idx = bsearchForInsert(this.folders, folderMeta, function (a, b) {
                return a.path.localeCompare(b.path);
            });
            this.folders.splice(idx, 0, folderMeta);
            if (!suppressNotification)
                this.universe.__notifyAddedFolder(this, folderMeta);
            return folderMeta;
        },
        _updateFolder: function (folder, bDelete) {
            let folderId = this._serverIdToFolderId[folder.ServerId];
            let folderMeta = this._folderInfos[folderId].$meta;
            let depFolders = [];
            let folders = [];
            let getSubFolders = subFolder => {
                let tempFolders = [];
                let tempFolder = null;
                for (let i = 0; i < depFolders.length; i++) {
                    if (depFolders[i].depth > subFolder.depth) {
                        if (depFolders[i].parentId !== subFolder.id) {
                            tempFolders.push(depFolders[i]);
                        } else {
                            tempFolder = depFolders[i];
                            folders.push(tempFolder);
                        }
                    }
                    if (i === depFolders.length - 1 && tempFolder) {
                        depFolders = tempFolders;
                        getSubFolders(tempFolder);
                    }
                }
            };
            for (let folderId in this._folderInfos) {
                if (this._folderInfos.hasOwnProperty(folderId)) {
                    if (folderId[0] === '$') {
                        continue;
                    }
                    let folderInfo = this._folderInfos[folderId];
                    if (folderInfo.$meta.depth > folderMeta.depth) {
                        if (folderInfo.$meta.parentId !== folderMeta.id) {
                            depFolders.push(folderInfo.$meta);
                        } else {
                            folders.push(folderMeta);
                            folders.push(folderInfo.$meta);
                        }
                    }
                }
            }
            if (folders.length > 0) {
                getSubFolders(folders[1]);
            } else {
                folders.push(folderMeta);
            }
            for (let i = folders.length - 1; i >= 0; i--) {
                this._deletedFolder(folders[i].serverId);
            }
            if (!bDelete) {
                this._addedFolder(folder.ServerId, folder.ParentId, folder.DisplayName, folder.Type);
                let parentServerId;
                for (let i = 1; i < folders.length; i++) {
                    let serverId = folders[i].serverId;
                    let parentId;
                    let displayName = folders[i].name;
                    let type = folders[i].type;
                    if (i === 1) {
                        parentId = folder.ServerId;
                    } else {
                        parentId = parentServerId;
                    }
                    parentServerId = serverId;
                    this._addedFolder(serverId, parentId, displayName, type, type);
                }
            }
        },
        _deletedFolder: function asa__deletedFolder(serverId, suppressNotification) {
            if (!serverId || !this._serverIdToFolderId[serverId]) {
                return;
            }
            var folderId = this._serverIdToFolderId[serverId], folderInfo = this._folderInfos[folderId], folderMeta = folderInfo.$meta;
            console.log('Deleted folder ' + folderMeta.name + ' (' + folderId + ')');
            delete this._serverIdToFolderId[serverId];
            delete this._folderInfos[folderId];
            delete this._folderStorages[folderId];
            var idx = this.folders.indexOf(folderMeta);
            this.folders.splice(idx, 1);
            if (this._deadFolderIds === null)
                this._deadFolderIds = [];
            this._deadFolderIds.push(folderId);
            if (!suppressNotification)
                this.universe.__notifyRemovedFolder(this, folderMeta);
        },
        _clearAllFolders: function asa__clearAllFolders() {
            let folders = [];
            let pushInFolders = folderInfo => {
                if (folders.length === 0) {
                    folders.push(folderInfo);
                } else {
                    for (let i = folders.length - 1; i >= 0; i--) {
                        if (folderInfo.$meta.depth >= folders[i].$meta.depth) {
                            folders.splice(i + 1, 0, folderInfo);
                            break;
                        }
                    }
                }
            };
            for (let folderId in this._folderInfos) {
                if (this._folderInfos.hasOwnProperty(folderId)) {
                    if (folderId[0] === '$') {
                        continue;
                    }
                    pushInFolders(this._folderInfos[folderId]);
                }
            }
            for (let i = folders.length - 1; i >= 0; i--) {
                this._deletedFolder(folders[i].$meta.serverId);
            }
        },
        _recreateFolder: function asa__recreateFolder(folderId, callback) {
            logic(this, 'recreateFolder', { folderId: folderId });
            var folderInfo = this._folderInfos[folderId];
            folderInfo.$impl = {
                nextId: 0,
                nextHeaderBlock: 0,
                nextBodyBlock: 0
            };
            folderInfo.accuracy = [];
            folderInfo.headerBlocks = [];
            folderInfo.bodyBlocks = [];
            folderInfo.serverIdHeaderBlockMapping = {};
            if (this._deadFolderIds === null)
                this._deadFolderIds = [];
            this._deadFolderIds.push(folderId);
            var self = this;
            this.saveAccountState(null, function () {
                var newStorage = new $mailslice.FolderStorage(self, folderId, folderInfo, self._db, $asfolder.ActiveSyncFolderSyncer);
                for (var iter of self._folderStorages[folderId]._slices) {
                    var slice = iter;
                    slice._storage = newStorage;
                    slice.reset();
                    newStorage.sliceOpenMostRecent(slice);
                }
                self._folderStorages[folderId]._slices = [];
                self._folderStorages[folderId] = newStorage;
                callback(newStorage);
            }, 'recreateFolder');
        },
        createFolder: lazyConnection(3, function asa_createFolder(parentFolderId, folderName, containOnlyOtherFolders, callback) {
            var account = this;
            var parentFolderServerId = parentFolderId ? this._folderInfos[parentFolderId] : '0';
            var fh = ASCP.FolderHierarchy.Tags;
            var fhStatus = ASCP.FolderHierarchy.Enums.Status;
            var folderType = ASCP.FolderHierarchy.Enums.Type.Mail;
            var w = new $wbxml.Writer('1.3', 1, 'UTF-8');
            w.stag(fh.FolderCreate).tag(fh.SyncKey, this.meta.syncKey).tag(fh.ParentId, parentFolderServerId).tag(fh.DisplayName, folderName).tag(fh.Type, folderType).etag();
            this.conn.postCommand(w, function (aError, aResponse) {
                account._reportErrorIfNecessary(aError);
                var e = new $wbxml.EventParser();
                var status, serverId;
                e.addEventListener([
                    fh.FolderCreate,
                    fh.Status
                ], function (node) {
                    status = node.children[0].textContent;
                    if (status === fhStatus.Success) {
                        let folderMeta = account._addedFolder(serverId, parentFolderServerId, folderName, folderType);
                        callback(null, folderMeta);
                    } else if (status === fhStatus.FolderExists) {
                        callback('already-exists');
                    } else {
                        callback('unknown');
                    }
                });
                e.addEventListener([
                    fh.FolderCreate,
                    fh.SyncKey
                ], function (node) {
                    account.meta.syncKey = node.children[0].textContent;
                });
                e.addEventListener([
                    fh.FolderCreate,
                    fh.ServerId
                ], function (node) {
                    serverId = node.children[0].textContent;
                });
                try {
                    e.run(aResponse);
                } catch (ex) {
                    console.error('Error parsing FolderCreate response:', ex, '\n', ex.stack);
                    callback('unknown');
                }
            });
        }),
        deleteFolder: lazyConnection(1, function asa_deleteFolder(folderId, callback) {
            var account = this;
            var folderMeta = this._folderInfos[folderId].$meta;
            var fh = ASCP.FolderHierarchy.Tags;
            var fhStatus = ASCP.FolderHierarchy.Enums.Status;
            var folderType = ASCP.FolderHierarchy.Enums.Type.Mail;
            var w = new $wbxml.Writer('1.3', 1, 'UTF-8');
            w.stag(fh.FolderDelete).tag(fh.SyncKey, this.meta.syncKey).tag(fh.ServerId, folderMeta.serverId).etag();
            this.conn.postCommand(w, function (aError, aResponse) {
                account._reportErrorIfNecessary(aError);
                var e = new $wbxml.EventParser();
                var status;
                e.addEventListener([
                    fh.FolderDelete,
                    fh.Status
                ], function (node) {
                    status = node.children[0].textContent;
                });
                e.addEventListener([
                    fh.FolderDelete,
                    fh.SyncKey
                ], function (node) {
                    account.meta.syncKey = node.children[0].textContent;
                });
                try {
                    e.run(aResponse);
                } catch (ex) {
                    console.error('Error parsing FolderDelete response:', ex, '\n', ex.stack);
                    callback('unknown');
                    return;
                }
                if (status === fhStatus.Success) {
                    account._deletedFolder(folderMeta.serverId);
                    callback(null, folderMeta);
                } else {
                    callback('unknown');
                }
            });
        }),
        sendMessage: lazyConnection(1, function asa_sendMessage(composer, callback) {
            var account = this;
            composer.withMessageBlob({ includeBcc: true }, function (mimeBlob) {
                if (this.conn.currentVersion.gte('14.0')) {
                    var cm = ASCP.ComposeMail.Tags;
                    var w = new $wbxml.Writer('1.3', 1, 'UTF-8', null, 'blob');
                    w.stag(cm.SendMail).tag(cm.ClientId, Date.now().toString() + '@mozgaia').tag(cm.SaveInSentItems).stag(cm.Mime).opaque(mimeBlob).etag().etag();
                    this.conn.postCommand(w, function (aError, aResponse) {
                        if (aError) {
                            account._reportErrorIfNecessary(aError);
                            console.error(aError);
                            callback('unknown');
                            return;
                        }
                        if (aResponse === null) {
                            console.log('Sent message successfully!');
                            callback(null);
                        } else {
                            console.error('Error sending message. XML dump follows:\n' + aResponse.dump());
                            callback('unknown');
                        }
                    }, null, null, function () {
                        composer.renewSmartWakeLock('ActiveSync XHR Progress');
                    });
                } else {
                    this.conn.postData('SendMail', 'message/rfc822', mimeBlob, function (aError, aResponse) {
                        if (aError) {
                            account._reportErrorIfNecessary(aError);
                            console.error(aError);
                            callback('unknown');
                            return;
                        }
                        console.log('Sent message successfully!');
                        callback(null);
                    }, { SaveInSent: 'T' }, null, function () {
                        composer.renewSmartWakeLock('ActiveSync XHR Progress');
                    });
                }
            }.bind(this));
        }),
        getFolderStorageForFolderId: function asa_getFolderStorageForFolderId(folderId) {
            return this._folderStorages[folderId];
        },
        getFolderStorageForServerId: function asa_getFolderStorageForServerId(serverId) {
            return this._folderStorages[this._serverIdToFolderId[serverId]];
        },
        getFolderMetaForFolderId: function (folderId) {
            if (this._folderInfos.hasOwnProperty(folderId))
                return this._folderInfos[folderId].$meta;
            return null;
        },
        ensureEssentialOfflineFolders: function () {
            [
                {
                    type: 'inbox',
                    displayName: 'Inbox',
                    typeNum: $FolderTypes.DefaultInbox
                },
                {
                    type: 'outbox',
                    displayName: 'outbox',
                    typeNum: $FolderTypes.Unknown
                },
                {
                    type: 'localdrafts',
                    displayName: 'localdrafts',
                    typeNum: $FolderTypes.Unknown
                }
            ].forEach(function (data) {
                if (!this.getFirstFolderWithType(data.type)) {
                    this._addedFolder(null, '0', data.displayName, data.typeNum, data.type, true);
                }
            }, this);
        },
        ensureEssentialOnlineFolders: function (callback) {
            callback && callback();
        },
        normalizeFolderHierarchy: $acctmixins.normalizeFolderHierarchy,
        scheduleMessagePurge: function (folderId, callback) {
            if (callback)
                callback();
        },
        upgradeFolderStoragesIfNeeded: $acctmixins.upgradeFolderStoragesIfNeeded,
        runOp: $acctmixins.runOp,
        getFirstFolderWithType: $acctmixins.getFirstFolderWithType,
        getFolderByPath: $acctmixins.getFolderByPath,
        saveAccountState: $acctmixins.saveAccountState,
        runAfterSaves: $acctmixins.runAfterSaves,
        allOperationsCompleted: function () {
        }
    };
});
;
define('ext/md5', [
    'require',
    'exports',
    'module'
], function (require, exports, module) {
    module.exports = function md5(data) {
        return hex_md5(data);
    };
    var hexcase = 0;
    var b64pad = '';
    function hex_md5(s) {
        return rstr2hex(rstr_md5(str2rstr_utf8(s)));
    }
    function b64_md5(s) {
        return rstr2b64(rstr_md5(str2rstr_utf8(s)));
    }
    function any_md5(s, e) {
        return rstr2any(rstr_md5(str2rstr_utf8(s)), e);
    }
    function hex_hmac_md5(k, d) {
        return rstr2hex(rstr_hmac_md5(str2rstr_utf8(k), str2rstr_utf8(d)));
    }
    function b64_hmac_md5(k, d) {
        return rstr2b64(rstr_hmac_md5(str2rstr_utf8(k), str2rstr_utf8(d)));
    }
    function any_hmac_md5(k, d, e) {
        return rstr2any(rstr_hmac_md5(str2rstr_utf8(k), str2rstr_utf8(d)), e);
    }
    function md5_vm_test() {
        return hex_md5('abc').toLowerCase() == '900150983cd24fb0d6963f7d28e17f72';
    }
    function rstr_md5(s) {
        return binl2rstr(binl_md5(rstr2binl(s), s.length * 8));
    }
    function rstr_hmac_md5(key, data) {
        var bkey = rstr2binl(key);
        if (bkey.length > 16)
            bkey = binl_md5(bkey, key.length * 8);
        var ipad = Array(16), opad = Array(16);
        for (var i = 0; i < 16; i++) {
            ipad[i] = bkey[i] ^ 909522486;
            opad[i] = bkey[i] ^ 1549556828;
        }
        var hash = binl_md5(ipad.concat(rstr2binl(data)), 512 + data.length * 8);
        return binl2rstr(binl_md5(opad.concat(hash), 512 + 128));
    }
    function rstr2hex(input) {
        try {
            hexcase;
        } catch (e) {
            hexcase = 0;
        }
        var hex_tab = hexcase ? '0123456789ABCDEF' : '0123456789abcdef';
        var output = '';
        var x;
        for (var i = 0; i < input.length; i++) {
            x = input.charCodeAt(i);
            output += hex_tab.charAt(x >>> 4 & 15) + hex_tab.charAt(x & 15);
        }
        return output;
    }
    function rstr2b64(input) {
        try {
            b64pad;
        } catch (e) {
            b64pad = '';
        }
        var tab = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        var output = '';
        var len = input.length;
        for (var i = 0; i < len; i += 3) {
            var triplet = input.charCodeAt(i) << 16 | (i + 1 < len ? input.charCodeAt(i + 1) << 8 : 0) | (i + 2 < len ? input.charCodeAt(i + 2) : 0);
            for (var j = 0; j < 4; j++) {
                if (i * 8 + j * 6 > input.length * 8)
                    output += b64pad;
                else
                    output += tab.charAt(triplet >>> 6 * (3 - j) & 63);
            }
        }
        return output;
    }
    function rstr2any(input, encoding) {
        var divisor = encoding.length;
        var i, j, q, x, quotient;
        var dividend = Array(Math.ceil(input.length / 2));
        for (i = 0; i < dividend.length; i++) {
            dividend[i] = input.charCodeAt(i * 2) << 8 | input.charCodeAt(i * 2 + 1);
        }
        var full_length = Math.ceil(input.length * 8 / (Math.log(encoding.length) / Math.log(2)));
        var remainders = Array(full_length);
        for (j = 0; j < full_length; j++) {
            quotient = Array();
            x = 0;
            for (i = 0; i < dividend.length; i++) {
                x = (x << 16) + dividend[i];
                q = Math.floor(x / divisor);
                x -= q * divisor;
                if (quotient.length > 0 || q > 0)
                    quotient[quotient.length] = q;
            }
            remainders[j] = x;
            dividend = quotient;
        }
        var output = '';
        for (i = remainders.length - 1; i >= 0; i--)
            output += encoding.charAt(remainders[i]);
        return output;
    }
    function str2rstr_utf8(input) {
        var output = '';
        var i = -1;
        var x, y;
        while (++i < input.length) {
            x = input.charCodeAt(i);
            y = i + 1 < input.length ? input.charCodeAt(i + 1) : 0;
            if (55296 <= x && x <= 56319 && 56320 <= y && y <= 57343) {
                x = 65536 + ((x & 1023) << 10) + (y & 1023);
                i++;
            }
            if (x <= 127)
                output += String.fromCharCode(x);
            else if (x <= 2047)
                output += String.fromCharCode(192 | x >>> 6 & 31, 128 | x & 63);
            else if (x <= 65535)
                output += String.fromCharCode(224 | x >>> 12 & 15, 128 | x >>> 6 & 63, 128 | x & 63);
            else if (x <= 2097151)
                output += String.fromCharCode(240 | x >>> 18 & 7, 128 | x >>> 12 & 63, 128 | x >>> 6 & 63, 128 | x & 63);
        }
        return output;
    }
    function str2rstr_utf16le(input) {
        var output = '';
        for (var i = 0; i < input.length; i++)
            output += String.fromCharCode(input.charCodeAt(i) & 255, input.charCodeAt(i) >>> 8 & 255);
        return output;
    }
    function str2rstr_utf16be(input) {
        var output = '';
        for (var i = 0; i < input.length; i++)
            output += String.fromCharCode(input.charCodeAt(i) >>> 8 & 255, input.charCodeAt(i) & 255);
        return output;
    }
    function rstr2binl(input) {
        var output = Array(input.length >> 2);
        for (var i = 0; i < output.length; i++)
            output[i] = 0;
        for (var i = 0; i < input.length * 8; i += 8)
            output[i >> 5] |= (input.charCodeAt(i / 8) & 255) << i % 32;
        return output;
    }
    function binl2rstr(input) {
        var output = '';
        for (var i = 0; i < input.length * 32; i += 8)
            output += String.fromCharCode(input[i >> 5] >>> i % 32 & 255);
        return output;
    }
    function binl_md5(x, len) {
        x[len >> 5] |= 128 << len % 32;
        x[(len + 64 >>> 9 << 4) + 14] = len;
        var a = 1732584193;
        var b = -271733879;
        var c = -1732584194;
        var d = 271733878;
        for (var i = 0; i < x.length; i += 16) {
            var olda = a;
            var oldb = b;
            var oldc = c;
            var oldd = d;
            a = md5_ff(a, b, c, d, x[i + 0], 7, -680876936);
            d = md5_ff(d, a, b, c, x[i + 1], 12, -389564586);
            c = md5_ff(c, d, a, b, x[i + 2], 17, 606105819);
            b = md5_ff(b, c, d, a, x[i + 3], 22, -1044525330);
            a = md5_ff(a, b, c, d, x[i + 4], 7, -176418897);
            d = md5_ff(d, a, b, c, x[i + 5], 12, 1200080426);
            c = md5_ff(c, d, a, b, x[i + 6], 17, -1473231341);
            b = md5_ff(b, c, d, a, x[i + 7], 22, -45705983);
            a = md5_ff(a, b, c, d, x[i + 8], 7, 1770035416);
            d = md5_ff(d, a, b, c, x[i + 9], 12, -1958414417);
            c = md5_ff(c, d, a, b, x[i + 10], 17, -42063);
            b = md5_ff(b, c, d, a, x[i + 11], 22, -1990404162);
            a = md5_ff(a, b, c, d, x[i + 12], 7, 1804603682);
            d = md5_ff(d, a, b, c, x[i + 13], 12, -40341101);
            c = md5_ff(c, d, a, b, x[i + 14], 17, -1502002290);
            b = md5_ff(b, c, d, a, x[i + 15], 22, 1236535329);
            a = md5_gg(a, b, c, d, x[i + 1], 5, -165796510);
            d = md5_gg(d, a, b, c, x[i + 6], 9, -1069501632);
            c = md5_gg(c, d, a, b, x[i + 11], 14, 643717713);
            b = md5_gg(b, c, d, a, x[i + 0], 20, -373897302);
            a = md5_gg(a, b, c, d, x[i + 5], 5, -701558691);
            d = md5_gg(d, a, b, c, x[i + 10], 9, 38016083);
            c = md5_gg(c, d, a, b, x[i + 15], 14, -660478335);
            b = md5_gg(b, c, d, a, x[i + 4], 20, -405537848);
            a = md5_gg(a, b, c, d, x[i + 9], 5, 568446438);
            d = md5_gg(d, a, b, c, x[i + 14], 9, -1019803690);
            c = md5_gg(c, d, a, b, x[i + 3], 14, -187363961);
            b = md5_gg(b, c, d, a, x[i + 8], 20, 1163531501);
            a = md5_gg(a, b, c, d, x[i + 13], 5, -1444681467);
            d = md5_gg(d, a, b, c, x[i + 2], 9, -51403784);
            c = md5_gg(c, d, a, b, x[i + 7], 14, 1735328473);
            b = md5_gg(b, c, d, a, x[i + 12], 20, -1926607734);
            a = md5_hh(a, b, c, d, x[i + 5], 4, -378558);
            d = md5_hh(d, a, b, c, x[i + 8], 11, -2022574463);
            c = md5_hh(c, d, a, b, x[i + 11], 16, 1839030562);
            b = md5_hh(b, c, d, a, x[i + 14], 23, -35309556);
            a = md5_hh(a, b, c, d, x[i + 1], 4, -1530992060);
            d = md5_hh(d, a, b, c, x[i + 4], 11, 1272893353);
            c = md5_hh(c, d, a, b, x[i + 7], 16, -155497632);
            b = md5_hh(b, c, d, a, x[i + 10], 23, -1094730640);
            a = md5_hh(a, b, c, d, x[i + 13], 4, 681279174);
            d = md5_hh(d, a, b, c, x[i + 0], 11, -358537222);
            c = md5_hh(c, d, a, b, x[i + 3], 16, -722521979);
            b = md5_hh(b, c, d, a, x[i + 6], 23, 76029189);
            a = md5_hh(a, b, c, d, x[i + 9], 4, -640364487);
            d = md5_hh(d, a, b, c, x[i + 12], 11, -421815835);
            c = md5_hh(c, d, a, b, x[i + 15], 16, 530742520);
            b = md5_hh(b, c, d, a, x[i + 2], 23, -995338651);
            a = md5_ii(a, b, c, d, x[i + 0], 6, -198630844);
            d = md5_ii(d, a, b, c, x[i + 7], 10, 1126891415);
            c = md5_ii(c, d, a, b, x[i + 14], 15, -1416354905);
            b = md5_ii(b, c, d, a, x[i + 5], 21, -57434055);
            a = md5_ii(a, b, c, d, x[i + 12], 6, 1700485571);
            d = md5_ii(d, a, b, c, x[i + 3], 10, -1894986606);
            c = md5_ii(c, d, a, b, x[i + 10], 15, -1051523);
            b = md5_ii(b, c, d, a, x[i + 1], 21, -2054922799);
            a = md5_ii(a, b, c, d, x[i + 8], 6, 1873313359);
            d = md5_ii(d, a, b, c, x[i + 15], 10, -30611744);
            c = md5_ii(c, d, a, b, x[i + 6], 15, -1560198380);
            b = md5_ii(b, c, d, a, x[i + 13], 21, 1309151649);
            a = md5_ii(a, b, c, d, x[i + 4], 6, -145523070);
            d = md5_ii(d, a, b, c, x[i + 11], 10, -1120210379);
            c = md5_ii(c, d, a, b, x[i + 2], 15, 718787259);
            b = md5_ii(b, c, d, a, x[i + 9], 21, -343485551);
            a = safe_add(a, olda);
            b = safe_add(b, oldb);
            c = safe_add(c, oldc);
            d = safe_add(d, oldd);
        }
        return Array(a, b, c, d);
    }
    function md5_cmn(q, a, b, x, s, t) {
        return safe_add(bit_rol(safe_add(safe_add(a, q), safe_add(x, t)), s), b);
    }
    function md5_ff(a, b, c, d, x, s, t) {
        return md5_cmn(b & c | ~b & d, a, b, x, s, t);
    }
    function md5_gg(a, b, c, d, x, s, t) {
        return md5_cmn(b & d | c & ~d, a, b, x, s, t);
    }
    function md5_hh(a, b, c, d, x, s, t) {
        return md5_cmn(b ^ c ^ d, a, b, x, s, t);
    }
    function md5_ii(a, b, c, d, x, s, t) {
        return md5_cmn(c ^ (b | ~d), a, b, x, s, t);
    }
    function safe_add(x, y) {
        var lsw = (x & 65535) + (y & 65535);
        var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
        return msw << 16 | lsw & 65535;
    }
    function bit_rol(num, cnt) {
        return num << cnt | num >>> 32 - cnt;
    }
});
define('activesync/configurator', [
    'logic',
    '../accountcommon',
    '../a64',
    './account',
    '../date',
    '../ext/md5',
    'tcp-socket',
    'require',
    'exports'
], function (logic, $accountcommon, $a64, $asacct, $date, $md5, tcpSocket, require, exports) {
    function checkServerCertificate(url, callback) {
        var match = /^https:\/\/([^:/]+)(?::(\d+))?/.exec(url);
        if (!match) {
            callback(null);
            return;
        }
        var port = match[2] ? parseInt(match[2], 10) : 443, host = match[1];
        console.log('checking', host, port, 'for security problem');
        var sock = tcpSocket.open(host, port);
        function reportAndClose(err) {
            if (sock) {
                var wasSock = sock;
                sock = null;
                try {
                    wasSock.close();
                } catch (ex) {
                }
                callback(err);
            }
        }
        sock.onopen = function () {
            sock.send(new TextEncoder('utf-8').encode('GET /images/logo.png HTTP/1.1\n\n'));
        };
        sock.onerror = function (evt) {
            var err = evt.data || evt;
            var reportErr = null;
            if (err && typeof err === 'object' && err.name === 'NetworkError')
                reportErr = 'bad-security';
            reportAndClose(reportErr);
        };
        sock.ondata = function (data) {
            reportAndClose(null);
        };
    }
    var scope = logic.scope('ActivesyncConfigurator');
    exports.account = $asacct;
    exports.configurator = {
        timeout: 30 * 1000,
        _getFullDetailsFromAutodiscover: function ($asproto, userDetails, autoDiscoverEndpoint, callback) {
            logic(scope, 'autodiscover:begin', { server: '' });
            var autoDiscoverResult = function (error, config) {
                if (error) {
                    var failureType = 'no-config-info', failureDetails = {};
                    if (error instanceof $asproto.HttpError) {
                        if (error.status === 401)
                            failureType = 'bad-user-or-pass';
                        else if (error.status === 403)
                            failureType = 'not-authorized';
                        else
                            failureDetails.status = error.status;
                    } else if (error instanceof $asproto.AutodiscoverDomainError) {
                        logic(scope, 'autodiscover.error', { message: error.message });
                    }
                    logic(scope, 'autodiscover:end', { err: failureType });
                    callback(failureType, null, failureDetails);
                    return;
                }
                logic(scope, 'autodiscover:end', { server: config.mobileSyncServer.url });
                var autoconfig = {
                    type: 'activesync',
                    displayName: config.user.name,
                    incoming: {
                        server: config.mobileSyncServer.url,
                        username: config.user.email
                    }
                };
                callback(null, autoconfig, null);
            };
            if (autoDiscoverEndpoint.length > 1) {
                $asproto.autodiscover(userDetails.emailAddress, userDetails.password, self.timeout, autoDiscoverResult, false);
            } else {
                $asproto.raw_autodiscover(autoDiscoverEndpoint, userDetails.emailAddress, userDetails.password, self.timeout, false, autoDiscoverResult);
            }
        },
        tryToCreateAccount: function (universe, userDetails, domainInfo, callback) {
            require(['activesync/protocol'], function ($asproto) {
                if (domainInfo.incoming.autodiscoverEndpoint) {
                    this._getFullDetailsFromAutodiscover($asproto, userDetails, domainInfo.incoming.autodiscoverEndpoint, function (err, fullConfigInfo, errDetails) {
                        if (err) {
                            callback(err, fullConfigInfo, errDetails);
                            return;
                        }
                        this._createAccountUsingFullInfo(universe, userDetails, fullConfigInfo, callback, $asproto);
                    }.bind(this));
                    return;
                }
                this._createAccountUsingFullInfo(universe, userDetails, domainInfo, callback, $asproto);
            }.bind(this));
        },
        _createAccountUsingFullInfo: function (universe, userDetails, domainInfo, callback, $asproto) {
            logic(scope, 'create:begin', { server: domainInfo.incoming.server });
            var credentials = {
                username: domainInfo.incoming.username,
                password: userDetails.password
            };
            var deviceId = domainInfo.incoming.deviceId || $md5(userDetails.deviceId);
            var policyKey = domainInfo.incoming.policyKey;
            var self = this;
            var conn = new $asproto.Connection(deviceId, policyKey, userDetails.emailAddress);
            conn.open(domainInfo.incoming.server, credentials.username, credentials.password);
            conn.timeout = $asacct.DEFAULT_TIMEOUT_MS;
            conn.connect(function (error, options) {
                if (error) {
                    var failureType, failureDetails = { server: domainInfo.incoming.server };
                    if (error instanceof $asproto.HttpError) {
                        if (error.status === 401) {
                            failureType = 'bad-user-or-pass';
                        } else if (error.status === 403) {
                            failureType = 'not-authorized';
                        } else {
                            failureType = 'server-problem';
                            failureDetails.status = error.status;
                        }
                    } else {
                        checkServerCertificate(domainInfo.incoming.server, function (securityError) {
                            var failureType;
                            if (securityError)
                                failureType = 'bad-security';
                            else
                                failureType = 'unresponsive-server';
                            callback(failureType, null, failureDetails);
                        });
                        return;
                    }
                    logic(scope, 'create:end', {
                        server: domainInfo.incoming.server,
                        err: failureType
                    });
                    callback(failureType, null, failureDetails);
                    return;
                }
                var accountId = $a64.encodeInt(universe.config.nextAccountNum++);
                var accountDef = {
                    id: accountId,
                    name: userDetails.accountName || userDetails.emailAddress,
                    authenticatorId: userDetails.authenticatorId || 'activesync',
                    label: userDetails.label || userDetails.emailAddress.split('@')[1].split('.')[0],
                    defaultPriority: $date.NOW(),
                    type: 'activesync',
                    syncRange: 'auto',
                    syncInterval: userDetails.syncInterval || 0,
                    notifyOnNew: userDetails.hasOwnProperty('notifyOnNew') ? userDetails.notifyOnNew : true,
                    playSoundOnSend: userDetails.hasOwnProperty('playSoundOnSend') ? userDetails.playSoundOnSend : true,
                    syncEnable: true,
                    public: false,
                    credentials: credentials,
                    connInfo: {
                        server: domainInfo.incoming.server,
                        deviceId: deviceId,
                        policyKey: conn.policyKey
                    },
                    identities: [{
                            id: accountId + '/' + $a64.encodeInt(universe.config.nextIdentityNum++),
                            name: userDetails.displayName || domainInfo.displayName,
                            address: userDetails.emailAddress,
                            replyTo: null,
                            signature: null
                        }]
                };
                logic(scope, 'create:end', {
                    server: domainInfo.incoming.server,
                    id: accountId
                });
                self._loadAccount(universe, accountDef, conn, function (account) {
                    callback(null, account, null);
                });
            });
        },
        recreateAccount: function cfg_as_ra(universe, oldVersion, oldAccountInfo, callback) {
            var oldAccountDef = oldAccountInfo.def;
            var credentials = {
                username: oldAccountDef.credentials.username,
                password: oldAccountDef.credentials.password
            };
            var accountId = $a64.encodeInt(universe.config.nextAccountNum++);
            var accountDef = {
                id: accountId,
                name: oldAccountDef.name,
                authenticatorId: oldAccountDef.authenticatorId,
                label: oldAccountDef.label,
                type: 'activesync',
                syncRange: oldAccountDef.syncRange,
                syncInterval: oldAccountDef.syncInterval || 0,
                notifyOnNew: oldAccountDef.hasOwnProperty('notifyOnNew') ? oldAccountDef.notifyOnNew : true,
                playSoundOnSend: oldAccountDef.hasOwnProperty('playSoundOnSend') ? oldAccountDef.playSoundOnSend : true,
                syncEnable: oldAccountDef.hasOwnProperty('syncEnable') ? oldAccountDef.syncEnable : true,
                public: oldAccountDef.hasOwnProperty('public') ? oldAccountDef.public : false,
                credentials: credentials,
                connInfo: {
                    server: oldAccountDef.connInfo.server,
                    deviceId: oldAccountDef.connInfo.deviceId,
                    policyKey: oldAccountDef.connInfo.policyKey
                },
                identities: $accountcommon.recreateIdentities(universe, accountId, oldAccountDef.identities)
            };
            this._loadAccount(universe, accountDef, null, function (account) {
                callback(null, account, null);
            });
        },
        _loadAccount: function cfg_as__loadAccount(universe, accountDef, protoConn, callback) {
            var canceledAddress = universe.getNeedCancelAccount();
            if (canceledAddress && canceledAddress === accountDef.name) {
                console.log('Cancel setup this account(account name: ' + accountDef.name + ')!!!');
                universe.resetNeedCancelAccount();
                return;
            }
            var folderInfo = {
                $meta: {
                    nextFolderNum: 0,
                    nextMutationNum: 0,
                    lastFolderSyncAt: 0,
                    syncKey: '0'
                },
                $mutations: [],
                $mutationState: {}
            };
            universe.saveAccountDef(accountDef, folderInfo);
            universe._loadAccount(accountDef, folderInfo, protoConn, callback);
        }
    };
});
;