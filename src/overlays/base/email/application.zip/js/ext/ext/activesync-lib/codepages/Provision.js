(function (root, factory) {
    if (typeof exports === 'object')
        module.exports = factory();
    else if (typeof define === 'function' && define.amd)
        define([], factory);
    else
        root.ASCPProvision = factory();
}(this, function () {
    'use strict';
    return {
        Tags: {
            Provision: 3589,
            Policies: 3590,
            Policy: 3591,
            PolicyType: 3592,
            PolicyKey: 3593,
            Data: 3594,
            Status: 3595,
            RemoteWipe: 3596,
            EASProvisionDoc: 3597,
            DevicePasswordEnabled: 3598,
            AlphanumericDevicePasswordRequired: 3599,
            DeviceEncryptionEnabled: 3600,
            RequireStorageCardEncryption: 3600,
            PasswordRecoveryEnabled: 3601,
            AttachmentsEnabled: 3603,
            MinDevicePasswordLength: 3604,
            MaxInactivityTimeDeviceLock: 3605,
            MaxDevicePasswordFailedAttempts: 3606,
            MaxAttachmentSize: 3607,
            AllowSimpleDevicePassword: 3608,
            DevicePasswordExpiration: 3609,
            DevicePasswordHistory: 3610,
            AllowStorageCard: 3611,
            AllowCamera: 3612,
            RequireDeviceEncryption: 3613,
            AllowUnsignedApplications: 3614,
            AllowUnsignedInstallationPackages: 3615,
            MinDevicePasswordComplexCharacters: 3616,
            AllowWiFi: 3617,
            AllowTextMessaging: 3618,
            AllowPOPIMAPEmail: 3619,
            AllowBluetooth: 3620,
            AllowIrDA: 3621,
            RequireManualSyncWhenRoaming: 3622,
            AllowDesktopSync: 3623,
            MaxCalendarAgeFilter: 3624,
            AllowHTMLEmail: 3625,
            MaxEmailAgeFilter: 3626,
            MaxEmailBodyTruncationSize: 3627,
            MaxEmailHTMLBodyTruncationSize: 3628,
            RequireSignedSMIMEMessages: 3629,
            RequireEncryptedSMIMEMessages: 3630,
            RequireSignedSMIMEAlgorithm: 3631,
            RequireEncryptionSMIMEAlgorithm: 3632,
            AllowSMIMEEncryptionAlgorithmNegotiation: 3633,
            AllowSMIMESoftCerts: 3634,
            AllowBrowser: 3635,
            AllowConsumerEmail: 3636,
            AllowRemoteDesktop: 3637,
            AllowInternetSharing: 3638,
            UnapprovedInROMApplicationList: 3639,
            ApplicationName: 3640,
            ApprovedApplicationList: 3641,
            Hash: 3642
        }
    };
}));