(function (root, factory) {
    if (typeof exports === 'object')
        module.exports = factory(require('wbxml'), require('activesync/codepages'));
    else if (typeof define === 'function' && define.amd)
        define([
            'wbxml',
            'activesync/codepages'
        ], factory);
    else
        root.ActiveSyncProtocol = factory(WBXML, ActiveSyncCodepages);
}(this, function (WBXML, ASCP) {
    'use strict';
    var exports = {};
    var USER_AGENT = 'KaiOS ActiveSync Client';
    function nullCallback() {
    }
    function makeError(name, parent, extraArgs) {
        function CustomError() {
            var self = this instanceof CustomError ? this : Object.create(CustomError.prototype);
            var tmp = Error();
            var offset = 1;
            self.stack = tmp.stack.substring(tmp.stack.indexOf('\n') + 1);
            self.message = arguments[0] || tmp.message;
            if (extraArgs) {
                offset += extraArgs.length;
                for (var i = 0; i < extraArgs.length; i++)
                    self[extraArgs[i]] = arguments[i + 1];
            }
            var m = /@(.+):(.+)/.exec(self.stack);
            self.fileName = arguments[offset] || m && m[1] || '';
            self.lineNumber = arguments[offset + 1] || m && m[2] || 0;
            return self;
        }
        CustomError.prototype = Object.create((parent || Error).prototype);
        CustomError.prototype.name = name;
        CustomError.prototype.constructor = CustomError;
        return CustomError;
    }
    var AutodiscoverError = makeError('ActiveSync.AutodiscoverError');
    exports.AutodiscoverError = AutodiscoverError;
    var AutodiscoverDomainError = makeError('ActiveSync.AutodiscoverDomainError', AutodiscoverError);
    exports.AutodiscoverDomainError = AutodiscoverDomainError;
    var HttpError = makeError('ActiveSync.HttpError', null, ['status']);
    exports.HttpError = HttpError;
    function nsResolver(prefix) {
        var baseUrl = 'http://schemas.microsoft.com/exchange/autodiscover/';
        var ns = {
            rq: baseUrl + 'mobilesync/requestschema/2006',
            ad: baseUrl + 'responseschema/2006',
            ms: baseUrl + 'mobilesync/responseschema/2006'
        };
        return ns[prefix] || null;
    }
    function Version(str) {
        var details = str.split('.').map(function (x) {
            return parseInt(x);
        });
        this.major = details[0], this.minor = details[1];
    }
    exports.Version = Version;
    Version.prototype = {
        eq: function (other) {
            if (!(other instanceof Version))
                other = new Version(other);
            return this.major === other.major && this.minor === other.minor;
        },
        ne: function (other) {
            return !this.eq(other);
        },
        gt: function (other) {
            if (!(other instanceof Version))
                other = new Version(other);
            return this.major > other.major || this.major === other.major && this.minor > other.minor;
        },
        gte: function (other) {
            if (!(other instanceof Version))
                other = new Version(other);
            return this.major >= other.major || this.major === other.major && this.minor >= other.minor;
        },
        lt: function (other) {
            return !this.gte(other);
        },
        lte: function (other) {
            return !this.gt(other);
        },
        toString: function () {
            return this.major + '.' + this.minor;
        }
    };
    function setAuthHeader(xhr, username, password) {
        var authorization = 'Basic ' + btoa(username + ':' + password);
        xhr.setRequestHeader('Authorization', authorization);
    }
    function autodiscover(aEmailAddress, aPassword, aTimeout, aCallback, aNoRedirect) {
        if (!aCallback)
            aCallback = nullCallback;
        var domain = aEmailAddress.substring(aEmailAddress.indexOf('@') + 1);
        do_autodiscover('autodiscover.' + domain, aEmailAddress, aPassword, aTimeout, aNoRedirect, function (aError, aConfig) {
            if (aError instanceof AutodiscoverDomainError || aError instanceof HttpError)
                do_autodiscover(domain, aEmailAddress, aPassword, aTimeout, aNoRedirect, aCallback);
            else
                aCallback(aError, aConfig);
        });
    }
    exports.autodiscover = autodiscover;
    function do_autodiscover(aHost, aEmailAddress, aPassword, aTimeout, aNoRedirect, aCallback) {
        var url = 'https://' + aHost + '/autodiscover/autodiscover.xml';
        return raw_autodiscover(url, aEmailAddress, aPassword, aTimeout, aNoRedirect, aCallback);
    }
    function raw_autodiscover(aUrl, aEmailAddress, aPassword, aTimeout, aNoRedirect, aCallback) {
        var xhr = new XMLHttpRequest({
            mozSystem: true,
            mozAnon: true
        });
        xhr.open('POST', aUrl, true);
        setAuthHeader(xhr, aEmailAddress, aPassword);
        xhr.setRequestHeader('Content-Type', 'text/xml');
        xhr.setRequestHeader('User-Agent', USER_AGENT);
        xhr.timeout = aTimeout;
        xhr.upload.onprogress = xhr.upload.onload = function () {
            xhr.timeout = 0;
        };
        xhr.onload = function () {
            if (xhr.status < 200 || xhr.status >= 300)
                return aCallback(new HttpError(xhr.statusText, xhr.status));
            var uid = Math.random();
            self.postMessage({
                uid: uid,
                type: 'configparser',
                cmd: 'accountactivesync',
                args: [
                    xhr.responseText,
                    aNoRedirect
                ]
            });
            self.addEventListener('message', function onworkerresponse(evt) {
                var data = evt.data;
                if (data.type !== 'configparser' || data.cmd !== 'accountactivesync' || data.uid !== uid) {
                    return;
                }
                self.removeEventListener(evt.type, onworkerresponse);
                var args = data.args;
                var config = args[0], error = args[1], redirectedEmail = args[2];
                if (error) {
                    aCallback(new AutodiscoverDomainError(error), config);
                } else if (redirectedEmail) {
                    autodiscover(redirectedEmail, aPassword, aTimeout, aCallback, true);
                } else {
                    aCallback(null, config);
                }
            });
        };
        xhr.ontimeout = xhr.onerror = function () {
            aCallback(new HttpError('Error getting Autodiscover URL', null));
        };
        var postdata = '<?xml version="1.0" encoding="utf-8"?>\n' + '<Autodiscover xmlns="' + nsResolver('rq') + '">\n' + '  <Request>\n' + '    <EMailAddress>' + aEmailAddress + '</EMailAddress>\n' + '    <AcceptableResponseSchema>' + nsResolver('ms') + '</AcceptableResponseSchema>\n' + '  </Request>\n' + '</Autodiscover>';
        xhr.send(postdata);
    }
    exports.raw_autodiscover = raw_autodiscover;
    function Connection(aDeviceId, aPolicyKey, aEmailAddress, aDeviceType) {
        this._deviceId = aDeviceId || 'v140Device';
        this._deviceType = aDeviceType || 'KaiOS';
        this.timeout = 0;
        this._connected = false;
        this._waitingForConnection = false;
        this._connectionError = null;
        this._connectionCallbacks = [];
        this.baseUrl = null;
        this._username = null;
        this._password = null;
        this._emailaddress = aEmailAddress || '';
        this.versions = [];
        this.supportedCommands = [];
        this.currentVersion = null;
        this.policyKey = aPolicyKey || 0;
        this.onmessage = null;
    }
    exports.Connection = Connection;
    Connection.prototype = {
        _notifyConnected: function (aError) {
            if (aError)
                this.disconnect();
            for (var iter of this._connectionCallbacks) {
                var callback = iter;
                callback.apply(callback, arguments);
            }
            this._connectionCallbacks = [];
        },
        get connected() {
            return this._connected;
        },
        open: function (aURL, aUsername, aPassword) {
            var servicePath = '/Microsoft-Server-ActiveSync';
            this.baseUrl = aURL;
            if (!this.baseUrl.endsWith(servicePath))
                this.baseUrl += servicePath;
            this._username = aUsername;
            this._password = aPassword;
        },
        connect: function (aCallback) {
            if (this.connected) {
                if (aCallback)
                    aCallback(null);
                return;
            }
            if (aCallback)
                this._connectionCallbacks.push(aCallback);
            if (this._waitingForConnection)
                return;
            this._waitingForConnection = true;
            this._connectionError = null;
            this.getOptions((aError, aOptions) => {
                this._waitingForConnection = false;
                this._connectionError = aError;
                if (aError) {
                    console.error('Error connecting to ActiveSync:', aError);
                    return this._notifyConnected(aError, aOptions);
                }
                this._connected = true;
                this.versions = aOptions.versions;
                this.supportedCommands = aOptions.commands;
                this.currentVersion = new Version(aOptions.versions.slice(-1)[0]);
                this.enforcement((aError, aResponse) => {
                    let errorStr = 'Error get Security Policy for ActiveSync: ';
                    let doGetPolicy = false;
                    if (aError) {
                        console.error(errorStr, aError);
                        if (aError.status === 449) {
                            doGetPolicy = true;
                        } else {
                            return this._notifyConnected(aError, aOptions);
                        }
                    }
                    let e = new WBXML.EventParser();
                    let fh = ASCP.FolderHierarchy.Tags;
                    let ace = ASCP.Common.Enums;
                    let afe = ASCP.FolderHierarchy.Enums;
                    e.addEventListener([
                        fh.FolderSync,
                        fh.Status
                    ], node => {
                        let status = node.children[0].textContent;
                        if (status === afe.Status.Success) {
                            return this._notifyConnected(null, aOptions);
                        } else if (status === ace.Status.DeviceNotProvisioned || status === ace.Status.PolicyRefresh || status === ace.Status.InvalidPolicyKey || doGetPolicy) {
                            this.getPolicyKey(false, aError => {
                                if (aError) {
                                    console.error(errorStr, aError);
                                    return this._notifyConnected(aError, aOptions);
                                }
                                this.getPolicyKey(true, error => {
                                    if (error) {
                                        console.error(errorStr, error);
                                        return this._notifyConnected(error, aOptions);
                                    }
                                    return this._notifyConnected(null, aOptions);
                                });
                            });
                        } else if (status === ace.Status.RemoteWipeRequested) {
                            this.deviceWipe(aError => {
                                if (aError) {
                                    console.error(errorStr, aError);
                                    return this._notifyConnected(aError, aOptions);
                                } else {
                                    return this._notifyConnected(null, aOptions);
                                }
                            });
                        } else {
                            aError = 'enforcement error, status: ' + status;
                            console.error(errorStr, aError);
                            return this._notifyConnected(aError, aOptions);
                        }
                    });
                    try {
                        if (!aResponse) {
                            console.log('response error');
                            return this._notifyConnected('response error', aOptions);
                        } else {
                            e.run(aResponse);
                        }
                    } catch (ex) {
                        console.error(errorStr, ex);
                    }
                });
            });
        },
        disconnect: function () {
            if (this._waitingForConnection)
                throw new Error('Can\'t disconnect while waiting for server response');
            this._connected = false;
            this.versions = [];
            this.supportedCommands = [];
            this.currentVersion = null;
        },
        getDeviceInfo: function (aCallback) {
            var uid = Math.random();
            self.postMessage({
                uid: uid,
                type: 'deviceInfo',
                cmd: 'get'
            });
            self.addEventListener('message', function onworkerresponse(evt) {
                var data = evt.data;
                if (data.type != 'deviceInfo' || data.cmd != 'get' || data.uid != uid) {
                    return;
                }
                self.removeEventListener(evt.type, onworkerresponse);
                var args = data.args;
                var data = args[0], error = args[1];
                if (error) {
                    aCallback(null, error);
                } else {
                    aCallback(data);
                }
            });
        },
        provision: function (doFinal, aCallback) {
            var pv = ASCP.Provision.Tags;
            var st = ASCP.Settings.Tags;
            var w = new WBXML.Writer('1.3', 1, 'UTF-8');
            w.stag(pv.Provision);
            var bSetDeviceInfo = !doFinal && this.currentVersion.gte('12.0');
            if (bSetDeviceInfo) {
                this.getDeviceInfo(function (deviceInfo, error) {
                    if (error) {
                        aCallback(error);
                    }
                    w.stag(st.DeviceInformation).stag(st.Set).tag(st.FriendlyName, deviceInfo.deviceName).tag(st.Model, deviceInfo.modelName).tag(st.IMEI, deviceInfo.imei).tag(st.OS, deviceInfo.OSName).tag(st.OSLanguage, deviceInfo.OSLanguage);
                    if (deviceInfo.phoneNumber.length > 0) {
                        w.tag(st.PhoneNumber, deviceInfo.phoneNumber);
                    }
                    if (this.currentVersion.gte('14.0')) {
                        w.tag(st.MobileOperator, deviceInfo.operatorName);
                    }
                    w.etag().etag();
                    w.stag(pv.Policies).stag(pv.Policy).tag(pv.PolicyType, 'MS-EAS-Provisioning-WBXML');
                    w.etag().etag().etag();
                    this.postCommand(w, aCallback);
                }.bind(this));
            } else {
                w.stag(pv.Policies).stag(pv.Policy).tag(pv.PolicyType, 'MS-EAS-Provisioning-WBXML');
                if (doFinal) {
                    w.tag(pv.PolicyKey, this.policyKey).tag(pv.Status, 1);
                }
                w.etag().etag().etag();
                this.postCommand(w, aCallback);
            }
        },
        enforcement: function (aCallback) {
            var fh = ASCP.FolderHierarchy.Tags;
            var w = new WBXML.Writer('1.3', 1, 'UTF-8');
            w.stag(fh.FolderSync).tag(fh.SyncKey, '0').etag();
            this.postCommand(w, aCallback);
        },
        getPolicyKey: function (bFinal, aCallback) {
            this.provision(bFinal, function (aError, aResponse) {
                if (aError) {
                    aCallback(aError);
                }
                var e = new WBXML.EventParser();
                var pv = ASCP.Provision.Tags;
                var base = [
                    pv.Provision,
                    pv.Policies,
                    pv.Policy
                ];
                e.addEventListener(base.concat(pv.PolicyKey), function (node) {
                    this.policyKey = node.children[0].textContent;
                    aCallback(null);
                }.bind(this));
                if (!bFinal) {
                    e.addEventListener(base.concat([
                        pv.Data,
                        pv.EASProvisionDoc
                    ]), function (node) {
                        this.securitySettings(pv, node);
                    }.bind(this));
                }
                try {
                    e.run(aResponse);
                } catch (ex) {
                    aCallback(ex);
                }
            }.bind(this));
        },
        securitySettings: function (pv, node) {
            for (var iter of node.children) {
                var child = iter;
                var childText = child.children.length ? child.children[0].textContent : null;
                switch (child.tag) {
                case pv.DevicePasswordEnabled:
                    break;
                case pv.AlphanumericDevicePasswordRequired:
                    break;
                case pv.PasswordRecoveryEnabled:
                    break;
                case pv.RequireStorageCardEncryption:
                    break;
                case pv.AttachmentsEnabled:
                    break;
                case pv.MinDevicePasswordLength:
                    break;
                case pv.MaxInactivityTimeDeviceLock:
                    break;
                case pv.MaxAttachmentSize:
                    break;
                case pv.MaxDevicePasswordFailedAttempts:
                    break;
                case pv.AllowSimpleDevicePassword:
                    break;
                case pv.DevicePasswordExpiration:
                    break;
                case pv.DevicePasswordHistory:
                    break;
                }
            }
        },
        wipeCommand: function (pv, bWipe, callback) {
            var w = new WBXML.Writer('1.3', 1, 'UTF-8');
            w.stag(pv.Provision);
            if (bWipe) {
                w.stag(pv.RemoteWipe).tag(pv.Status, 1).etag();
            }
            w.etag();
            this.postCommand(w, function (aError, aResponse) {
                var e = new WBXML.EventParser();
                if (aError) {
                    callback(aError);
                }
                e.addEventListener([
                    pv.Provision,
                    pv.Status
                ], function (node) {
                    var status = node.children[0].textContent;
                    if (status === '1') {
                        callback(null);
                    } else {
                        var error = 'Remote wipe error, error status: ' + status;
                        console.error(error);
                        callback(error);
                    }
                });
                try {
                    e.run(aResponse);
                } catch (ex) {
                    callback(ex);
                }
            });
        },
        deviceWipe: function (callback) {
            var pv = ASCP.Provision.Tags;
            this.wipeCommand(pv, false, function (aError) {
                if (aError) {
                    callback(aError);
                    return;
                }
                this.wipeCommand(pv, true, function (aError) {
                    if (aError) {
                        callback(aError);
                        return;
                    } else {
                        callback(null);
                        var uid = Math.random();
                        self.postMessage({
                            uid: uid,
                            type: 'deviceInfo',
                            cmd: 'reset'
                        });
                    }
                });
            }.bind(this));
        },
        getOptions: function (aCallback) {
            if (!aCallback)
                aCallback = nullCallback;
            var conn = this;
            var xhr = new XMLHttpRequest({
                mozSystem: true,
                mozAnon: true
            });
            xhr.open('OPTIONS', this.baseUrl, true);
            setAuthHeader(xhr, this._username, this._password);
            xhr.setRequestHeader('User-Agent', USER_AGENT);
            xhr.timeout = this.timeout;
            xhr.upload.onprogress = xhr.upload.onload = function () {
                xhr.timeout = 0;
            };
            xhr.onload = function () {
                if (xhr.status < 200 || xhr.status >= 300) {
                    console.error('ActiveSync options request failed with response ' + xhr.status);
                    if (conn.onmessage)
                        conn.onmessage('options', 'error', xhr, null, null, null, null);
                    aCallback(new HttpError(xhr.statusText, xhr.status));
                    return;
                }
                var result = {
                    versions: xhr.getResponseHeader('MS-ASProtocolVersions').split(/\s*,\s*/),
                    commands: xhr.getResponseHeader('MS-ASProtocolCommands').split(/\s*,\s*/)
                };
                if (conn.onmessage)
                    conn.onmessage('options', 'ok', xhr, null, null, null, result);
                aCallback(null, result);
            };
            xhr.ontimeout = xhr.onerror = function () {
                var error = new Error('Error getting OPTIONS URL');
                console.error(error);
                if (conn.onmessage)
                    conn.onmessage('options', 'timeout', xhr, null, null, null, null);
                aCallback(error);
            };
            xhr.responseType = 'text';
            xhr.send();
        },
        supportsCommand: function (aCommand) {
            if (!this.connected)
                throw new Error('Connection required to get command');
            if (typeof aCommand === 'number')
                aCommand = ASCP.__tagnames__[aCommand];
            return this.supportedCommands.indexOf(aCommand) !== -1;
        },
        doCommand: function () {
            console.warn('doCommand is deprecated. Use postCommand instead.');
            this.postCommand.apply(this, arguments);
        },
        postCommand: function (aCommand, aCallback, aExtraParams, aExtraHeaders, aProgressCallback) {
            var contentType = 'application/vnd.ms-sync.wbxml';
            if (typeof aCommand === 'string' || typeof aCommand === 'number') {
                this.postData(aCommand, contentType, null, aCallback, aExtraParams, aExtraHeaders);
            } else {
                var commandName = ASCP.__tagnames__[aCommand.rootTag];
                this.postData(commandName, contentType, aCommand.dataType === 'blob' ? aCommand.blob : aCommand.buffer, aCallback, aExtraParams, aExtraHeaders, aProgressCallback);
            }
        },
        postData: function (aCommand, aContentType, aData, aCallback, aExtraParams, aExtraHeaders, aProgressCallback) {
            if (typeof aCommand === 'number')
                aCommand = ASCP.__tagnames__[aCommand];
            if (!this.supportsCommand(aCommand)) {
                var error = new Error('This server doesn\'t support the command ' + aCommand);
                console.error(error);
                aCallback(error);
                return;
            }
            var params = [
                [
                    'Cmd',
                    aCommand
                ],
                [
                    'User',
                    this._username
                ],
                [
                    'DeviceId',
                    this._deviceId
                ],
                [
                    'DeviceType',
                    this._deviceType
                ]
            ];
            if (aExtraParams) {
                for (var iter of params) {
                    var param = iter;
                    if (param[0] in aExtraParams)
                        throw new TypeError('reserved URL parameter found');
                }
                for (var kv of aExtraParams)
                    params.push(kv);
            }
            var paramsStr = params.map(function (i) {
                return encodeURIComponent(i[0]) + '=' + encodeURIComponent(i[1]);
            }).join('&');
            var xhr = new XMLHttpRequest({
                mozSystem: true,
                mozAnon: true
            });
            xhr.open('POST', this.baseUrl + '?' + paramsStr, true);
            setAuthHeader(xhr, this._username, this._password);
            xhr.setRequestHeader('MS-ASProtocolVersion', this.currentVersion);
            xhr.setRequestHeader('Content-Type', aContentType);
            xhr.setRequestHeader('User-Agent', USER_AGENT);
            if (!this.noUsePolicy) {
                xhr.setRequestHeader('X-MS-PolicyKey', this.policyKey);
            }
            if (aExtraHeaders) {
                for (var iter of aExtraHeaders) {
                    var key = iter, value = aExtraHeaders[iter];
                    xhr.setRequestHeader(key, value);
                }
            }
            xhr.timeout = this.timeout;
            xhr.upload.onprogress = xhr.upload.onload = function () {
                xhr.timeout = 0;
            };
            xhr.onprogress = function (event) {
                if (aProgressCallback)
                    aProgressCallback(event.loaded, event.total);
            };
            var conn = this;
            var parentArgs = arguments;
            xhr.onload = function () {
                if (xhr.status === 451) {
                    conn.baseUrl = xhr.getResponseHeader('X-MS-Location');
                    if (conn.onmessage)
                        conn.onmessage(aCommand, 'redirect', xhr, params, aExtraHeaders, aData, null);
                    conn.postData.apply(conn, parentArgs);
                    return;
                }
                if (xhr.status < 200 || xhr.status >= 300) {
                    console.error('ActiveSync command ' + aCommand + ' failed with ' + 'response ' + xhr.status);
                    if (conn.onmessage)
                        conn.onmessage(aCommand, 'error', xhr, params, aExtraHeaders, aData, null);
                    aCallback(new HttpError(xhr.statusText, xhr.status));
                    return;
                }
                var response = null;
                if (xhr.response.byteLength > 0)
                    response = new WBXML.Reader(new Uint8Array(xhr.response), ASCP);
                if (conn.onmessage)
                    conn.onmessage(aCommand, 'ok', xhr, params, aExtraHeaders, aData, response);
                aCallback(null, response);
            };
            xhr.ontimeout = xhr.onerror = function (evt) {
                var error = new Error('Command URL ' + evt.type + ' for command ' + aCommand + ' at baseUrl ' + this.baseUrl);
                console.error(error);
                if (conn.onmessage)
                    conn.onmessage(aCommand, evt.type, xhr, params, aExtraHeaders, aData, null);
                aCallback(error);
            }.bind(this);
            xhr.responseType = 'arraybuffer';
            xhr.send(aData);
        }
    };
    return exports;
}));