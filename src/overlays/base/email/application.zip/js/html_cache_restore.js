let _xstart = performance.timing.fetchStart - performance.timing.navigationStart;
window.plog = function (msg) {
    console.log(msg + ' ' + (performance.now() - _xstart));
};
(function () {
    function dispatch(name) {
        if (!window.mozPerfHasListener) {
            return;
        }
        let now = window.performance.now();
        let epoch = Date.now();
        setTimeout(() => {
            let detail = {
                name: name,
                timestamp: now,
                epoch: epoch
            };
            let event = new CustomEvent('x-moz-perf', { detail: detail });
            window.dispatchEvent(event);
        });
    }
    [
        'moz-chrome-dom-loaded',
        'moz-chrome-interactive',
        'moz-app-visually-complete',
        'moz-content-interactive',
        'moz-app-loaded'
    ].forEach(eventName => {
        window.addEventListener(eventName, () => {
            dispatch(eventName);
        }, false);
    });
    window.PerformanceTestingHelper = { dispatch: dispatch };
}());
const jsFileLazyload = [
    `http://shared.localhost/js/utils/toaster/toaster.js`,
    `http://shared.localhost/js/helper/softkey/softkey_panel.js`,
    `http://shared.localhost/js/helper/softkey/softkey_panel_helper.js`,
    `http://shared.localhost/js/utils/common/app_origin.js`,
    `http://shared.localhost/js/utils/navigation/navigation_handler.js`,
    'js/document-register-element.max.js'
];
function lazyLoadJsFile() {
    return new Promise(resolve => {
        LazyLoader.load(jsFileLazyload, () => {
            resolve();
        });
    });
}
window.startupCacheEventsSent = false;
window.HTML_CACHE_VERSION = '04b0754ae6dc6196a59735cc221a38c1316710e6';
window.startupOnModelLoaded = null;
window.appDispatchedMessage = false;
(function () {
    let pendingUiMessageType = null;
    let startingUp = true;
    let startupData = {};
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.addEventListener('message', event => {
            let {type, data} = event.data;
            window.keepSWStateInterval = setInterval(() => {
                if (navigator.serviceWorker.controller) {
                    navigator.serviceWorker.controller.postMessage({ isDummy: true });
                } else {
                    console.log('navigator.serviceWorker.controller is null');
                }
            }, 300000);
            startupData.entry = type;
            if (type === 'activity') {
                onActivityRequest(data);
            } else if (type === 'notification') {
                onNotification(data);
            }
        });
    }
    function localOnModelLoaded(model, callback) {
        model.latestOnce('acctsSlice', acctsSlice => {
            console.log('localOnModelLoaded called, hasAccount: ' + localStorage.getItem('data_has_enable_account'));
            setDefaultView();
            hydrateHtml(startupData.view);
            window.startupOnModelLoaded = null;
            callback();
        });
    }
    if (!localStorage.getItem('data_has_enable_account')) {
        console.log('data_has_enable_account unknown, asking for model load first');
        window.startupOnModelLoaded = localOnModelLoaded;
    }
    function hasAccount() {
        return localStorage.getItem('data_has_enable_account') === 'yes';
    }
    function setDefaultView() {
        if (hasAccount()) {
            if (!startupData.view) {
                startupData.view = 'message_list';
            }
        } else {
            startupData.view = 'welcome_page';
        }
    }
    if (!window.startupOnModelLoaded) {
        setDefaultView();
    }
    const activityReg = /^#\/?[^\s]+/;
    startupData.entry = activityReg.test(location.hash) ? 'activity' : 'default';
    let lastEntryTime = 0;
    function isUiMessageTypeAllowedEntry(type) {
        if (pendingUiMessageType && pendingUiMessageType !== type) {
            console.log('Ignoring message of type: ' + type);
            return false;
        }
        let entryTime = Date.now();
        if (pendingUiMessageType) {
            pendingUiMessageType = null;
        } else {
            if (entryTime > lastEntryTime && entryTime < lastEntryTime + 1000) {
                console.log('email entry gate blocked fast repeated action: ' + type);
                return false;
            }
        }
        lastEntryTime = entryTime;
        return true;
    }
    function retrieve(id) {
        let value = localStorage.getItem('html_cache_' + id) || '';
        let index, version, lang, langDir, cachedSoftkey;
        index = value.indexOf(':');
        if (index === -1) {
            value = '';
        } else {
            version = value.substring(0, index);
            value = value.substring(index + 1);
            let versionParts = version.split(',');
            version = versionParts[0];
            lang = versionParts[1];
            langDir = versionParts[2];
            cachedSoftkey = versionParts[3];
        }
        if (version !== window.HTML_CACHE_VERSION) {
            console.log('Skipping html cache for ' + id + ', out of date. Expected ' + window.HTML_CACHE_VERSION + ' but found ' + version);
            value = '';
        }
        return {
            lang: lang,
            langDir: langDir,
            cachedSoftkey: cachedSoftkey,
            contents: value
        };
    }
    let evt;
    let handlers = {};
    let handlerQueues = {
        notification: [],
        activity: []
    };
    window.globalOnAppMessage = function (listener) {
        Object.keys(listener).forEach(key => {
            let fn = handlers[key] = listener[key];
            let queue = handlerQueues[key];
            if (queue.length) {
                handlerQueues[key] = [];
                queue.forEach(argsArray => {
                    fn.apply(undefined, argsArray);
                });
            }
        });
        if (!evt) {
            require(['evt'], ev => {
                evt = ev;
                evt.on('notification', onNotification);
            });
        }
        return startupData;
    };
    window.globalOnAppMessage.hasAccount = hasAccount;
    function dispatch(type, args) {
        window.appDispatchedMessage = true;
        if (handlers[type]) {
            return handlers[type].apply(undefined, args);
        } else {
            handlerQueues[type].push(args);
        }
        finishStartup();
    }
    function onActivityRequest(req) {
        console.log('mozSetMessageHandler: received an activity');
        if (!isUiMessageTypeAllowedEntry('activity')) {
            const result = {
                activityHandlerId: req.activityHandlerId,
                activityResult: 'cancelled',
                isError: true
            };
            navigator.serviceWorker.controller.postMessage(result);
            window.close();
            clearInterval(window.keepSWStateInterval);
        }
        if (startingUp) {
            startupData.view = 'compose';
            hydrateHtml(startupData.view);
        }
        dispatch('activity', [req]);
    }
    function onNotification(msg) {
        console.log('mozSetMessageHandler: received a notification');
        if (!msg.clicked) {
            if (startupData.entry === 'notification' && !window.appDispatchedMessage) {
                console.log('App only started for notification close, closing app.');
                window.close();
            }
            return;
        }
        if (!isUiMessageTypeAllowedEntry('notification')) {
            return;
        }
        if (typeof Notification !== 'undefined' && Notification.get) {
            Notification.get().then(notifications => {
                if (notifications) {
                    notifications.some(notification => {
                        if (notification.tag === msg.tag && notification.close) {
                            notification.close();
                            return true;
                        }
                    });
                }
            });
        }
        let view = msg.data && msg.data.type;
        if (startingUp && view) {
            startupData.view = view;
            hydrateHtml(view);
        }
        setTimeout(() => {
            if (document.hidden && AppsManager) {
                console.log('document was hidden, showing app via mozApps.getSelf');
                const manifestUrl = window.AppOrigin.getManifestURL('email');
                ;
                AppsManager.getApp(manifestUrl).then(app => {
                    app.launch();
                });
            }
        }, 300);
        dispatch('notification', [msg.data]);
    }
    let selfNode = document.querySelector('[data-loadsrc]');
    function hydrateHtml(id) {
        let parsedResults = retrieve(id);
        if (parsedResults.lang !== navigator.language) {
            return;
        }
        if (parsedResults.langDir) {
            document.querySelector('html').setAttribute('dir', parsedResults.langDir);
        }
        let contents = parsedResults.contents;
        let cardsNode = document.getElementById(selfNode.dataset.targetid);
        cardsNode.innerHTML = contents;
        window.startupCacheEventsSent = !!contents;
        let softkeyHTML = parsedResults.cachedSoftkey;
        if (softkeyHTML && id !== 'compose') {
            window.softkeyHTML = softkeyHTML;
            let softkeyNODE = new DOMParser().parseFromString(softkeyHTML, 'text/html').activeElement.childNodes[0];
            if (id === 'message_list' && softkeyNODE.length > 1) {
                softkeyNODE[1].setAttribute('disabled', true);
            }
            document.body.appendChild(softkeyNODE);
        }
        if (contents) {
            console.log('Using HTML cache for ' + id);
        }
        if (window.startupCacheEventsSent) {
            window.performance.mark('navigationLoaded');
            window.dispatchEvent(new CustomEvent('moz-chrome-dom-loaded'));
            window.performance.mark('visuallyLoaded');
            window.dispatchEvent(new CustomEvent('moz-app-visually-complete'));
        }
    }
    function finishStartup() {
        if (!startingUp) {
            return;
        }
        initSession().then(() => {
            startingUp = false;
            lazyLoadJsFile().then(() => {
                const scriptNode = document.createElement('script');
                const loader = selfNode.dataset.loader;
                const loadSrc = selfNode.dataset.loadsrc;
                if (loader) {
                    scriptNode.setAttribute('data-main', loadSrc);
                    scriptNode.src = loader;
                } else {
                    scriptNode.src = loadSrc;
                }
                document.head.appendChild(scriptNode);
            });
        });
    }
    const SYSTEM_MESSAGE_TYPES = [
        'activity',
        'alarm',
        'notification'
    ];
    if (window.startupOnModelLoaded) {
        finishStartup();
    } else if (startupData.entry === 'default' || startupData.entry === 'alarm') {
        hydrateHtml(startupData.view);
        finishStartup();
    }
}());