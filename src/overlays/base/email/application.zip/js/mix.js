define([], function () {
    return function (t, n, r) {
        return Object.keys(n).forEach(function (e) {
            if (!t.hasOwnProperty(e) || r)
                t[e] = n[e];
        }), t;
    };
});