define([], function () {
    let queryString = {
        toObject: function toObject(value) {
            if (!value) {
                return null;
            }
            let result = {};
            value.split('&').forEach(keyValue => {
                let pair = keyValue.split('=');
                result[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1]);
            });
            return result;
        },
        fromObject: function fromObject(object) {
            let result = '';
            Object.keys(object).forEach(key => {
                result += (result ? '&' : '') + encodeURIComponent(key) + '=' + encodeURIComponent(object[key]);
            });
            return result;
        }
    };
    return queryString;
});