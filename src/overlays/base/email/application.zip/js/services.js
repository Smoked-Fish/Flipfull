define({
    oauth2: {
        google: {
            clientId: '1076439968824-h2hhq8rkbknsqrksvo7hjqmr44aikffs.apps.googleusercontent.com',
            clientSecret: 'F7H7mQ-w6oakrZkAK49LBxEt'
        },
        microsoft: {
            clientId: 'a2f9a01a-732b-49df-8302-39457378d990',
            usePKCE: true
        }
    }
});