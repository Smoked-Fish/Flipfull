const servicesArray = [
    'settingsService',
    'powerService',
    'appsService',
    'contactsService',
    'accountsService'
];
const lazyFiles = [
    `http://shared.localhost/js/session/task_scheduler.js`,
    `http://shared.localhost/js/session/lib_session.js`,
    `http://shared.localhost/js/session/settings/settings_observer.js`,
    `http://shared.localhost/js/session/apps_manager/apps_manager.js`,
    `http://shared.localhost/js/session/power_manager/power_manager.js`,
    `http://shared.localhost/js/session/account_manager/account_manager.js`,
    `http://shared.localhost/js/session/contacts_manager/contacts_manager.js`
];
const TIMEOUT = 1000;
let bInit = false;
let reloadTimer;
function initSession() {
    const doInit = resolve => {
        window.libSession.initService(servicesArray).then(() => {
            SettingsObserver.init();
            window.clearTimeout(reloadTimer);
            bInit = true;
            resolve();
        });
        reloadTimer = setTimeout(() => {
            if (!bInit) {
                window.location.reload();
            }
        }, TIMEOUT);
    };
    return new Promise(resolve => {
        LazyLoader.load(lazyFiles, () => {
            doInit(resolve);
        });
    });
}