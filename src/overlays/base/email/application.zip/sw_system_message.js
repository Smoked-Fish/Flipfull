const SYSTEM_MESSAGE_TYPES = [
    'activity',
    'alarm',
    'notification'
];
let resolveIdleTimeExtension = null;
self.addEventListener('install', event => {
    event.waitUntil(self.skipWaiting());
});
self.addEventListener('activate', event => {
    event.waitUntil(self.clients.claim());
});
self.onsystemmessage = evt => {
    console.log(' onsystemmessage: ' + evt.name);
    if (SYSTEM_MESSAGE_TYPES.includes(evt.name)) {
        let data = '';
        if (evt.name === 'activity') {
            const handler = evt.data.webActivityRequestHandler();
            addWebActivityRequestHandler(handler).then(activityHandlerId => {
                data = {
                    source: handler.source,
                    activityHandlerId
                };
                evt.waitUntil(clients.openWindow('/index.html#new', { disposition: 'inline' }).then(client => {
                    client.postMessage({
                        category: 'systemmessage',
                        data: data,
                        type: evt.name
                    });
                }));
            });
        } else {
            data = evt.data.json();
            evt.waitUntil(clients.matchAll({
                includeUncontrolled: true,
                type: 'window'
            }).then(clientList => {
                clientList.forEach(client => {
                    client.postMessage({
                        category: 'systemmessage',
                        type: evt.name,
                        data: data
                    });
                });
            }));
        }
        const idleTimeExtension = new Promise(resolve => {
            resolveIdleTimeExtension = resolve;
        });
        evt.waitUntil(idleTimeExtension);
    }
};
self.addEventListener('message', event => {
    console.log('service worker receive message: ', event.data);
    const {data} = event;
    if (data.isDummy) {
        return;
    }
    if (data.activityHandlerId) {
        const handler = handlerMap[data.activityHandlerId];
        if (data.isError) {
            handler.postError(data.activityResult);
        } else {
            handler.postResult(data.activityResult);
        }
        removeWebActivityRequestHandler(data.activityHandlerId);
        if (resolveIdleTimeExtension) {
            resolveIdleTimeExtension();
            resolveIdleTimeExtension = null;
        }
    }
});
let handlerMap = {};
const addWebActivityRequestHandler = async handler => {
    const activityHandlerId = `${ +new Date() }`;
    handlerMap[activityHandlerId] = handler;
    console.log('addWebActivityRequestHandler: ', handlerMap);
    return activityHandlerId;
};
const removeWebActivityRequestHandler = async activityHandlerId => {
    delete handlerMap[activityHandlerId];
    console.log('removeWebActivityRequestHandler: ', handlerMap);
};