/* global SettingsObserver */

const FTU_PAGES = ['changeMode', 'changeLang', 'showSymbols', 'addSpace'];
const FTU_IMG_KEYS = ['{{ # }}', '{{ # }}', '{{ * }}', '{{ 0 }}'];
const FTU_TIME_STAMP_KEY = 'ime-ftu-time-stamp';
const LONGPRESS_INTERVAL = 1000;

class FTU {
  constructor() {
    this.panel = document.getElementById('ftu');
    this.dialog = document.getElementById('ftu-dialog');
    this.page = document.getElementById('ftu-page');
    this.image = document.getElementById('ftu-image');
    this.content = document.getElementById('ftu-content');
    this.orderNum = document.getElementById('ftu-order-number');
    this.voiceInput = document.getElementById('ftu-vi');
    this.softKeys = document.getElementById('soft-keys');
    this.currentPageNum = 0;
    this.shown = false;
    this.inSinglePage = false;
    this.pageStates = [];
    this.ftuDone = false;
  }

  show(noDialog, page) {
    if (!this.shown) {
      this.shown = true;
      this.panel.classList.add('show');
    }
    if (noDialog) {
      if (page) {
        this.showSinglePage(page);
      } else {
        this.showPage();
      }
      this.doAction('ftuPageShown');
    } else {
      this.showDialog();
    }
    this.softKeys.classList.remove('browser');
    this.softKeys.style.opacity = '1';
    this.panel.setAttribute('dir', document.dir);
  }

  showDialog() {
    SettingsObserver.getValue(FTU_TIME_STAMP_KEY).then((value) => {
      this.canDelay = !value;
      this.dialog.innerHTML = `
        <div data-l10n-id="ftu-dialog-title"></div>
        <div id="ftu-dialog-image"></div>`;  
      this.dialog.classList.add('show');
      this.updateSoftKeys();
      this.doAction('ftuDialogShown');
    });
  }

  showPage() {
    if (this.shown) {
      this.doAction('ftuDialogHid');
      this.dialog.classList.remove('show');
      this.softKeys.classList.remove('ftu-dialog');
    }
    this.softKeys.classList.add('ftu-page');
    this.page.classList.add('show');
    this.orderNum.innerHTML = '';
    this.pageStates = [];
    for (let i = 0; i < FTU_PAGES.length; i++) {
      let p = document.createElement('div');
      p.classList.add('ftu-indicator');
      this.orderNum.appendChild(p);
      this.pageStates.push(false);
    }
    this.currentPageNum = 1;
    this.updatePage();
  }

  showSinglePage(page) {
    const index = FTU_PAGES.indexOf(page);
    if (index > -1) {
      this.inSinglePage = true;
      this.currentPageNum = index + 1;
      this.page.classList.add('show');
      this.orderNum.innerHTML = '';
      for (let i = 0; i < FTU_PAGES.length; i++) {
        this.pageStates.push(i !== index);
      }
      this.updatePage();
    } else {
      this.hide();
    }
  }

  showVI() {
    if (this.shown) {
      return;
    }
    this.voiceInput.innerHTML = '';
    this.panel.classList.add('showVI');

    const viContent = document.createElement('div');
    const cText = window.api.l10n.get('ime-voice-input');
    const imgData = { dataIcon: 'mic' };
    let viText = document.createElement('div');

    viContent.classList.add('vi-content');
    viText.innerHTML =
      this.replaceTextWithImg(cText, '{{ microphone }}', imgData);
    viContent.appendChild(viText);
    this.voiceInput.appendChild(viContent);
    this.intersectionObserver(this.panel, () => {
      this.voiceInput.classList.add('show');
    });
  }

  hideVI() {
    if (this.voiceInput.classList.contains('show')) {
      this.voiceInput.classList.remove('show');
      this.voiceInput.ontransitionend = () => {
        if (!this.voiceInput.classList.contains('show')) {
          this.voiceInput.innerHTML = '';
          this.panel.classList.remove('showVI');
        }
      };
    }
  }

  intersectionObserver(element, callback) {
    const intersectionObserver = new IntersectionObserver((entries) => {
      if (entries[0].intersectionRatio <= 0) {
        return;
      }
      intersectionObserver.disconnect();
      callback();
    });
    intersectionObserver.observe(element);
  }

  isActive() {
    return this.shown;
  }

  isFinished() {
    return this.ftuDone;
  }

  handleKeydown(key) {
    if (key === '#') {
      const action = 'changeLang';
      this.longpressTimer = window.setTimeout(() => {
        if (this.currentPageNum - 1 === FTU_PAGES.indexOf(action) &&
            !this.pageStates[this.currentPageNum - 1]) {
          this.doAction(action, true);
        }
      }, LONGPRESS_INTERVAL);
    }
  }

  isIgnoreKey(key, showDialog) {
    return (showDialog && key !== 'SoftLeft' && key !== 'Enter') ||
      (this.inSinglePage && key !== 'Enter' && key !== '*' && key !== '#');
  }

  handleKeyup(key) {
    const showDialog = this.dialog.classList.contains('show');
    if (this.isIgnoreKey(key, showDialog)) {
      return;
    }
    switch (key) {
      case 'SoftLeft':
        if (showDialog) {
          if (this.canDelay) {
            SettingsObserver.setValue([{
              name: FTU_TIME_STAMP_KEY,
              value: Date.now()
            }]).then(() => {
              this.hide();
              this.doAction('ftuDone');
            });
          } else {
            this.done();
          }
        } else if (this.currentPageNum > 1) {
          this.previous();
        } else {
          this.skip();
        }
        break;
      case 'Backspace':
        if (this.currentPageNum > 1) {
          this.previous();
        }
        break;
      case 'Enter':
        if (showDialog) {
          this.showPage();
          this.doAction('ftuPageShown');
        } else if (this.inSinglePage) {
          this.hide();
          this.doAction('ftuDone');
        }
        break;  
      case 'SoftRight':
        if (this.currentPageNum < FTU_PAGES.length) {
          this.next();
        } else {
          this.done();
        }
        break;
      case '*': {
        const action = 'showSymbols';
        const index = this.currentPageNum - 1;
        if (index === FTU_PAGES.indexOf(action) && !this.pageStates[index]) {
          this.resetSoftKeys();
          this.doAction(action, true);
        }
        break;
      }
      case '#':
        if (this.longpressTimer) {
          window.clearTimeout(this.longpressTimer);
          this.longpressTimer = null;
        }
        if (this.currentPageNum === 1 && !this.pageStates[0]) {
          this.doAction('changeMode', true);
        }
        break;
      case '0': {
        const index = this.currentPageNum - 1;
        if (index === FTU_PAGES.indexOf('addSpace') &&
            !this.pageStates[index]) {
          this.pageStates[index] = true;
          this.updatePage();
        }
        break;
      }
      default:
        break;
    }
  }

  doAction(action, updatePage = false) {
    window.dispatchEvent(new CustomEvent('keypad-action', {
      detail: { action }
    }));
    if (updatePage) {
      if (!this.inSinglePage) {
        this.pageStates[this.currentPageNum - 1] = true;
      }
      this.updatePage(action !== 'showSymbols');
    }
  }

  skip() {
    this.done();
  }

  previous() {
    this.currentPageNum--;
    this.updatePage();
  }

  next() {
    this.currentPageNum++;
    this.updatePage();
  }

  hide() {
    this.shown = false;
    this.inSinglePage = false;
    this.dialog.classList.remove('show');
    this.page.classList.remove('show');
    this.panel.classList.remove('show');
    this.hideVI();
    this.resetSoftKeys();
    this.softKeys.style.opacity = '0';
  }

  async done() {
    if (!this.ftuDone) {
      await SettingsObserver.setValue([{
        name: 'ime-ftu',
        value: false
      }]);
      this.ftuDone = true;
    }
    this.hide();
    this.doAction('ftuDone');
  }

  replaceTextWithImg(sourceText, placeholder, imgData) {
    let img = '';
    if (imgData.id) {
      img = `<span id="${imgData.id}" class="text-img"></span>`;
    } else if (imgData.dataIcon) {
      img = `<span data-icon="${imgData.dataIcon}"></span>`;
    }
    return sourceText.split(placeholder).join(img);
  }

  updateGuideImg(index) {
    if (index === FTU_PAGES.indexOf('addSpace') &&
        this.pageStates[index]) {
      this.image.className += '-done';
    }
  }

  updatePage(usk = true) {
    this.image.className = 'image-' + this.currentPageNum;
    const text = window.api.l10n.get('ftu-content-' + this.currentPageNum);
    const cIndex = this.currentPageNum - 1;
    const imgData = {
      id: 'text-img-' + this.currentPageNum
    };
    this.updateGuideImg(cIndex);
    this.content.innerHTML = `<div>
      ${this.replaceTextWithImg(text, FTU_IMG_KEYS[cIndex], imgData)}
    </div>`;

    Array.from(this.orderNum.children).forEach((p, index) => {
      const currentInd = index === cIndex;
      if (this.pageStates[index]) {
        p.textContent = '';
        p.dataset.icon = 'tick';
        p.classList.toggle('done', true);
      } else {
        p.textContent = currentInd ? this.currentPageNum : '';
      }
      p.classList.toggle('current', currentInd);
    });
    if (usk) {
      this.updateSoftKeys();
    }
  }

  updateSoftKeys() {
    const showDialog = this.dialog.classList.contains('show');
    if (showDialog) {
      this.softKeys.classList.add('ftu-dialog');
      this.softKeys.children[0].dataset.l10nId =
        this.canDelay ? 'ftu-later' : 'ftu-no';
      this.softKeys.children[1].dataset.l10nId = 'ftu-start';
      this.softKeys.children[2].dataset.l10nId = '';
      this.softKeys.children[2].textContent = '';
      this.softKeys.children[2].removeAttribute('data-icon');
      return;
    }
    if (this.inSinglePage) {
      this.softKeys.classList.add('ftu-page');
      this.softKeys.children[0].textContent = '';
      this.softKeys.children[0].dataset.l10nId = '';
      this.softKeys.children[1].textContent = '';
      this.softKeys.children[1].dataset.l10nId = 'ok';
      this.softKeys.children[2].textContent = '';
      this.softKeys.children[2].dataset.l10nId = '';
      this.softKeys.children[2].removeAttribute('data-icon');
      return;
    }
    if (this.currentPageNum === 1) {
      this.softKeys.children[0].removeAttribute('data-icon');
      this.softKeys.children[0].dataset.l10nId = 'ftu-skip';
    } else {
      this.softKeys.children[0].textContent = '';
      this.softKeys.children[0].dataset.l10nId = '';
      this.softKeys.children[0].dataset.icon = 'back';
    }
    this.softKeys.children[1].textContent = '';
    this.softKeys.children[1].dataset.l10nId = '';
    const isEndPage = this.currentPageNum === FTU_PAGES.length;
    if (isEndPage) {
      this.softKeys.children[2].removeAttribute('data-icon');
      this.softKeys.children[2].dataset.l10nId = 'ftu-done';
    } else {
      this.softKeys.children[2].textContent = '';
      this.softKeys.children[2].dataset.l10nId = '';
      this.softKeys.children[2].dataset.icon = 'forward';
    }
    this.softKeys.children[2].classList.toggle('end-page', isEndPage);
    let doneState = true;
    for (let i = 0; i < this.currentPageNum; i++) {
      if (!this.pageStates[i]) {
        doneState = false;
        break;
      }
    }
    this.softKeys.children[2].classList.toggle('all-done', doneState);
  }

  resetSoftKeys() {
    this.softKeys.classList.remove('ftu-page');
    this.softKeys.classList.remove('ftu-dialog');
    this.softKeys.children[0].removeAttribute('data-icon');
    this.softKeys.children[2].textContent = '';
    this.softKeys.children[2].dataset.l10nId = '';
    this.softKeys.children[2].removeAttribute('data-icon');
    this.softKeys.children[2].classList.remove('all-done');
  }
}

export default FTU;
