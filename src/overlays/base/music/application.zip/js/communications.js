let previousPlay;
function MusicComm() {
    this.enabled = false;
    this.isSCOEnabled = false;
    this._statusBeforeSCO = null;
    this.mozinterruptbegin = false;
}
MusicComm.prototype.commands = {
    play: function (event) {
        this.commands.playpause.call(this, event);
    },
    playpause: function (event) {
        this._getPlayerReady(() => {
            if (!PlayerView.view.classList.contains('hidden')) {
                if (IceCastModulePlayerView.playStatus === STATIONSTATUS_PLAYING) {
                    IceCastModulePlayerView.pauseAudio();
                }
                this.playpausemusic(event);
                return;
            }
            if (IceCastModulePlayerView.view && !IceCastModulePlayerView.view.classList.contains('hidden')) {
                if (PlayerView.playStatus === PLAYSTATUS_PLAYING) {
                    PlayerView.pause();
                }
                IceCastModulePlayerView.playAudio();
                return;
            }
            if (previousPlay === 'music') {
                this.playpausemusic(event);
            }
            if (previousPlay === 'radio') {
                if (IceCastModulePlayerView.playStatus === STATIONSTATUS_PLAYING) {
                    previousPlay = 'radio';
                    IceCastModulePlayerView.pauseAudio();
                } else if (IceCastModulePlayerView.playStatus === STATIONSTATUS_PAUSED) {
                    IceCastModulePlayerView.playAudio();
                }
            }
        });
    },
    pause: function (event) {
        this.isSCOEnabled = event.detail.isSCOConnected;
        if (this.isSCOEnabled) {
            this._statusBeforeSCO = PlayerView.playStatus;
        }
        if (typeof PlayerView !== 'undefined' && (PlayerView.playStatus === INTERRUPT_BEGIN || PlayerView.playStatus === PLAYSTATUS_PLAYING)) {
            previousPlay = 'music';
        } else if (IceCastModulePlayerView.playStatus === STATIONSTATUS_INTERRUPT || IceCastModulePlayerView.playStatus === STATIONSTATUS_PLAYING) {
            previousPlay = 'radio';
            IceCastModulePlayerView.pauseAudio();
        }
        if (this._isPlayerActivated()) {
            PlayerView.pause();
        }
    },
    stop: function () {
        if (!this._isPlayerActivated()) {
            return;
        }
        PlayerView.stop();
    },
    next: function () {
        if (!this._isPlayerActivated()) {
            return;
        }
        if (PlayerView.playStatus === PLAYSTATUS_STOPPED) {
            PlayerView.dataSource = PlayerView.dataSourceBeforeStop;
        }
        PlayerView.next();
    },
    previous: function () {
        if (!this._isPlayerActivated()) {
            return;
        }
        if (PlayerView.playStatus === PLAYSTATUS_STOPPED) {
            PlayerView.dataSource = PlayerView.dataSourceBeforeStop;
        }
        PlayerView.previous();
    },
    seekpress: function (event) {
        if (!this._isPlayerActivated()) {
            return;
        }
        if (this.cancelRelease) {
            window.clearTimeout(this.cancelRelease);
        }
        if (!PlayerView.isTouching) {
            PlayerView.startFastSeeking(event.detail.direction);
        }
    },
    seekrelease: function () {
        if (!this._isPlayerActivated()) {
            return;
        }
        this.cancelRelease = window.setTimeout(() => {
            PlayerView.stopFastSeeking();
        }, 200);
    },
    updatemetadata: function () {
        this._getPlayerReady(() => {
            PlayerView.updateRemoteMetadata();
        });
    },
    updateplaystatus: function () {
        this._getPlayerReady(() => {
            PlayerView.updateRemotePlayStatus();
        });
    }
};
MusicComm.prototype.init = function () {
    this.mrc = new MediaRemoteControls();
    for (let command in this.commands) {
        this.mrc.addCommandListener(command, this.commands[command].bind(this));
    }
    this.mrc.start(this.updateSCOStatus.bind(this));
    this.enabled = true;
    this.cancelRelease = null;
};
MusicComm.prototype._getPlayerReady = function (callback) {
    if (typeof PlayerView === 'undefined') {
        LazyLoader.load('js/ui/views/player_view.js', () => {
            PlayerView.init();
            callback();
        });
    } else {
        callback();
    }
};
MusicComm.prototype.playpausemusic = function (event) {
    let isResumedBySCO = this.isSCOEnabled;
    this.isSCOEnabled = event.detail.isSCOConnected;
    if (isResumedBySCO) {
        if (this._statusBeforeSCO === PLAYSTATUS_PLAYING || this._statusBeforeSCO === INTERRUPT_BEGIN) {
            PlayerView.play();
        } else {
            PlayerView.pause();
            previousPlay = 'music';
        }
    } else if (PlayerView.playStatus === PLAYSTATUS_STOPPED) {
        PlayerView.dataSource = PlayerView.dataSourceBeforeStop;
        PlayerView.play(PlayerView.indexBeforeStop, true);
    } else if (PlayerView.playStatus === PLAYSTATUS_PLAYING) {
        PlayerView.pause();
        previousPlay = 'music';
    } else {
        PlayerView.play();
    }
};
MusicComm.prototype._isPlayerActivated = function () {
    return typeof PlayerView !== 'undefined' && this.mozinterruptbegin === false;
};
MusicComm.prototype.notifyMetadataChanged = function (metadata) {
    if (this.enabled) {
        this.mrc.notifyMetadataChanged(metadata);
    }
};
MusicComm.prototype.notifyStatusChanged = function (info) {
    if (this.enabled) {
        this.mrc.notifyStatusChanged(info);
    }
};
MusicComm.prototype.updateSCOStatus = function () {
    if (this.enabled) {
        this.mrc.getSCOStatus(status => {
            this.isSCOEnabled = status;
        });
    }
};
MusicComm.prototype.isA2dpConnected = function (cb) {
    if (this.enabled) {
        this.mrc.hasConnectedDevicesByA2dp().then(cb);
    }
};
let MusicComms = new MusicComm();