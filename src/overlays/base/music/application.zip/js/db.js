var musicdb;
var firstScanDone = false;
var reparsingMetadata = false;
let promiseUpdate;
function initDB() {
    musicdb = new MediaDB('music', metadataParserWrapper, {
        indexes: [
            'metadata.album',
            'metadata.artist',
            'metadata.title',
            'metadata.rated',
            'metadata.played',
            'date'
        ],
        batchSize: 1,
        autoscan: false,
        updateRecord: updateRecord,
        reparsedRecord: reparsedRecord,
        version: 3,
        excludeFilter: /\/sdcard\d?\/(?!(audio|callrecording|FM Radio)\/).*/i
    });
    musicdb.onopenMediaDBFail = function () {
        window.close();
    };
    function metadataParserWrapper(file, onsuccess, onerror) {
        AudioMetadata.parse(file).then(onsuccess, onerror);
    }
    function updateRecord(record, oldVersion, newVersion) {
        if (oldVersion === 2) {
            record.needsReparse = true;
            reparsingMetadata = true;
        }
        return record.metadata;
    }
    function reparsedRecord(oldMetadata, newMetadata) {
        newMetadata.rated = oldMetadata.rated;
        newMetadata.played = oldMetadata.played;
        return newMetadata;
    }
    musicdb.onupgrading = function () {
        App.showOverlay('upgrade');
    };
    musicdb.onunavailable = function (event) {
        stopPlayingAndReset();
        var why = event.detail;
        if (why === MediaDB.NOCARD) {
            App.showOverlay('nocard');
        } else if (why === MediaDB.UNMOUNTED) {
            App.showOverlay('pluggedin');
        }
    };
    musicdb.oncardremoved = stopPlayingAndReset;
    function stopPlayingAndReset() {
        if (typeof PlayerView !== 'undefined') {
            PlayerView.stop();
        }
        if (!App.pendingPick) {
            TabBar.option = 'title';
            ModeManager.start(MODE_LIST);
        }
    }
    musicdb.onenumerable = startupOnEnumerable;
    function startupOnEnumerable() {
        if (App.currentOverlay === 'upgrade') {
            App.showOverlay(null);
        }
        App.showCurrentView(() => {
            reparsingMetadata = false;
            if (musicdb.state === MediaDB.READY) {
                startupOnReady();
            } else {
                musicdb.onready = startupOnReady;
            }
        });
    }
    function startupOnReady() {
        if (App.currentOverlay === 'nocard' || App.currentOverlay === 'pluggedin') {
            App.showOverlay(null);
        }
        if (Number(window.localStorage.getItem('musicCount')) > 0 && !BannerAd.initialized) {
            BannerAd.init();
        }
        musicdb.scan();
        musicdb.onready = postStartupOnReady;
        if (!ListView._firstLoaded && !App.pendingPick) {
            ListView.showScanning();
        }
    }
    function postStartupOnReady() {
        if (App.currentOverlay === 'nocard' || App.currentOverlay === 'pluggedin') {
            App.showOverlay(null);
        }
        if (Number(window.localStorage.getItem('musicCount')) > 0 && !BannerAd.initialized) {
            BannerAd.init();
        }
        App.showCurrentView(() => {
            musicdb.scan();
        });
    }
    var filesDeletedWhileScanning = 0;
    var filesFoundWhileScanning = 0;
    var filesFoundBatch = 0;
    var scanning = false;
    var DELETE_BATCH_TIMEOUT = 500;
    var deleteTimer = null;
    let deletedItems = [];
    let updateTimer = null;
    musicdb.onscanstart = function () {
        scanning = !this.active;
        filesFoundWhileScanning = 0;
        filesFoundBatch = 0;
        filesDeletedWhileScanning = 0;
    };
    musicdb.onscanend = function () {
        if (this.active) {
            this.active = false;
            return this.active;
        }
        scanning = false;
        if (filesFoundBatch > 0) {
            filesFoundWhileScanning = 0;
            filesFoundBatch = 0;
            App.showCurrentView();
        } else if (!ListView._firstLoaded || filesDeletedWhileScanning > 0) {
            filesDeletedWhileScanning = 0;
            musicdb.count('metadata.title', null, count => {
                window.localStorage.setItem('musicCount', count);
                App.showCurrentView();
            });
        }
        if (!firstScanDone) {
            firstScanDone = true;
            window.performance.mark('fullyLoaded');
            window.dispatchEvent(new CustomEvent('moz-app-loaded'));
        }
    };
    musicdb.oncreated = function (event) {
        let musicCount = Number(window.localStorage.getItem('musicCount'));
        if (isNaN(musicCount)) {
            musicCount = 0;
        }
        window.localStorage.setItem('musicCount', musicCount + 1);
        if (scanning) {
            var n = event.detail.length;
            filesFoundWhileScanning += n;
            filesFoundBatch += n;
            if (filesFoundWhileScanning === n) {
                ListView.resetDataSource();
                ModeManager.currentMode !== MODE_PLAYER && ListView.showScanning();
            }
        } else if (!this.active) {
            ListView.resetDataSource();
            App.showCurrentView();
            if (ModeManager.currentMode === MODE_PLAYER) {
                ModeManager.withRefresh = true;
            }
        }
    };
    function reCountAndRender() {
        window.delPromise = null;
        musicdb.count('metadata.title', null, count => {
            let musicCount = Number(window.localStorage.getItem('musicCount'));
            deleteTimer = null;
            if (musicCount != count) {
                window.localStorage.setItem('musicCount', count);
                ListView.resetDataSource();
                App.showCurrentView();
                if (ModeManager.currentMode === MODE_PLAYER) {
                    ModeManager.withRefresh = true;
                }
            }
        });
    }
    musicdb.ondeleted = function (event) {
        let deletedItem = event.detail[0];
        if (toPlaylist.enabled) {
            deletedItems.push(deletedItem);
            updateTimer && window.clearTimeout(updateTimer);
            updateTimer = window.setTimeout(() => {
                promiseUpdate = new Promise(resolve => {
                    window.asyncStorage.getItem(LIST_DATASOURCE_KEY, listData => {
                        listData.forEach(list => {
                            for (let i = 0; i < list.source.length; i++) {
                                let songData = list.source[i];
                                if (!songData) {
                                    break;
                                }
                                if (deletedItems.includes(songData.name)) {
                                    list.source.splice(i, 1);
                                    i--;
                                }
                            }
                        });
                        SubListView.listDataSource = listData;
                        if (SubListView.isInMyPlaylist) {
                            SubListView.currentTarget = listData[SubListView.listIndex];
                        }
                        resolve();
                        SubListView.updateStorage();
                        deletedItems = [];
                        updateTimer = null;
                    });
                });
            }, DELETE_BATCH_TIMEOUT);
        }
        if (scanning) {
            filesDeletedWhileScanning += event.detail.length;
            ListView.resetDataSource();
        } else {
            if (typeof PlayerView !== 'undefined') {
                for (let i = 0; i < PlayerView.dataSource.length; i++) {
                    let songData = PlayerView.dataSource[i];
                    if (songData.name === deletedItem) {
                        PlayerView.dataSource.splice(i, 1);
                        if (i <= PlayerView.currentIndex) {
                            PlayerView.currentIndex--;
                        }
                        if (PlayerView.shuffleOption) {
                            PlayerView.shuffledList.splice(PlayerView.shuffledList.indexOf(i), 1);
                            PlayerView.shuffledList = PlayerView.shuffledList.map(index => {
                                return index > i ? index - 1 : index;
                            });
                        }
                        i--;
                    }
                }
            }
            if (App.discover) {
                let index = App.discover.findIndex(songData => songData.name === deletedItem);
                index >= 0 && App.discover.splice(index, 1);
            }
            if (window.delPromise) {
                if (!window.delPromise._singleton) {
                    window.delPromise.then(() => reCountAndRender());
                    window.delPromise._singleton = true;
                }
            } else {
                deleteTimer && clearTimeout(deleteTimer);
                deleteTimer = setTimeout(() => reCountAndRender(), DELETE_BATCH_TIMEOUT);
            }
        }
    };
}