var AboutIcecastView = {
    get view() {
        return document.getElementById('about-icecast-views');
    },
    init: function aivInit() {
        this.view.classList.remove('hidden');
        this.view.addEventListener('keydown', this);
        this.view.focus();
        this.updateSoftKeys();
        this.updateTitle();
    },
    updateSoftKeys: function aivUpdateSotfKeys() {
        SoftKeyStore.register({ 'center': 'ok' }, this.view);
    },
    updateTitle: function aivupdateTitle() {
        TitleBar.updateById('opt-about');
    },
    handleEvent: function aivHandleEvent(evt) {
        let target = evt.target;
        if (!target) {
            return;
        }
        switch (evt.key) {
        case 'Enter':
        case 'Backspace':
            this.view.removeEventListener('keydown', this);
            this.view.classList.add('hidden');
            IcecastView.mode = 'main_list_mode';
            break;
        default:
            break;
        }
    }
};
window.AboutIcecastView = AboutIcecastView;