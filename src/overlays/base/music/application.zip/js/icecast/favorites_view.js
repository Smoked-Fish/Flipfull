var FavoriteView = {
    get view() {
        return document.getElementById('icecast-favorites-view');
    },
    get content() {
        return document.getElementById('icecast-favorites-content');
    },
    get listView() {
        return document.getElementById('icecast-favorites-list');
    },
    get emptyView() {
        return document.getElementById('icecast-favorites-empty');
    },
    get hasFavorite() {
        return !!this.stations.size;
    },
    init: function () {
        this.stations = this.getCachedStations();
        this.navigator = new SimpleNavigationHelper('.focusable', this.view, null, 0);
    },
    show: function () {
        const parentView = document.getElementById('i-region-views');
        parentView.classList.add('hidden');
        this.view.classList.remove('hidden');
        this.view.addEventListener('keydown', this);
        this.updateFavoriteList();
        TitleBar.updateById('icecast-favorites');
        this.updateSoftKeys();
        this.view.focus();
    },
    getCachedStations: function () {
        function objToStrMap(obj) {
            let strMap = new Map();
            for (let k of Object.keys(obj)) {
                strMap.set(k, obj[k]);
            }
            return strMap;
        }
        const cache_stations = localStorage.getItem('favorite-stations');
        if (cache_stations) {
            return objToStrMap(JSON.parse(cache_stations));
        }
        return new Map();
    },
    setCachedStations: function () {
        function strMapToObj(strMap) {
            let obj = Object.create(null);
            for (let [k, v] of strMap) {
                obj[k] = v;
            }
            return obj;
        }
        if (this.stations.size) {
            localStorage.setItem('favorite-stations', JSON.stringify(strMapToObj(this.stations)));
        } else {
            localStorage.removeItem('favorite-stations');
        }
    },
    updateSoftKeys: function () {
        const keys = this.hasFavorite ? {
            center: 'icon=play',
            right: 'options'
        } : { center: 'opt-ok' };
        SoftKeyStore.register(keys, this.view);
    },
    updateFavoriteList: function () {
        if (this.hasFavorite) {
            this.listView.replaceChildren(this.buildList(this.stations));
            this.showList();
        } else {
            this.showEmpty();
        }
    },
    buildList: function (stations) {
        const fragment = new DocumentFragment();
        for (let item of stations.values()) {
            const li = document.createElement('li');
            li.className = 'list-item icecast-item focusable';
            li.setAttribute('tabindex', '-1');
            li.dataset.name = item.name;
            li.dataset.currentSong = item.currentSong;
            li.dataset.url = item.url;
            const a = document.createElement('a');
            li.appendChild(a);
            const titleBdi = document.createElement('bdi');
            titleBdi.className = 'list-single-title bold-text p-pri';
            titleBdi.textContent = item.name;
            a.appendChild(titleBdi);
            const playingsongicon = document.createElement('div');
            if (IceCastModulePlayerView.stationURL && IceCastModulePlayerView.stationURL === item.url && IceCastModulePlayerView.playStatus === 'PLAYING') {
                playingsongicon.className = 'list-playing-icon active';
            } else {
                playingsongicon.className = 'list-playing-icon';
            }
            playingsongicon.setAttribute('data-icon', 'sound-max');
            li.appendChild(playingsongicon);
            fragment.appendChild(li);
        }
        return fragment;
    },
    showEmpty: function () {
        this.listView.classList.add('hidden');
        this.emptyView.classList.remove('hidden');
    },
    showList: function () {
        this.listView.classList.remove('hidden');
        this.emptyView.classList.add('hidden');
    },
    addFavorite: function (station) {
        this.stations.set(station.name, station);
        this.setCachedStations();
        Toaster.showToast({ message: window.api.l10n.get('toast-add-favorite') });
    },
    removeFavorite: function (name) {
        this.stations.delete(name);
        this.setCachedStations();
        Toaster.showToast({ message: window.api.l10n.get('toast-remove-favorite') });
    },
    isFavorite: function (name) {
        return this.stations.has(name);
    },
    onEnter: function (target) {
        if (!target.dataset) {
            return;
        }
        const {name, currentSong, url} = target.dataset;
        if (name && currentSong && url) {
            const currentFocus = document.activeElement;
            const showPlayer = () => {
                IceCastModulePlayerView.showPlayerView({
                    name: name,
                    currentSong: currentSong,
                    url: url,
                    previousFocus: currentFocus,
                    previousView: this.view
                });
            };
            showDataWarning(() => {
                this.view.focus();
            }, showPlayer);
        }
    },
    onBack: function () {
        this.view.removeEventListener('keydown', this);
        this.view.classList.add('hidden');
        IcecastView.mode = 'main_list_mode';
    },
    handleEvent: function iHandleEvent(evt) {
        let target = evt.target;
        if (!target) {
            return;
        }
        switch (evt.type) {
        case 'keydown':
            switch (evt.key) {
            case 'Enter':
                if (this.hasFavorite) {
                    this.onEnter(target);
                } else {
                    this.onBack();
                }
                break;
            case 'Backspace':
                evt.stopPropagation();
                evt.preventDefault();
                this.onBack();
                break;
            case 'SoftRight':
                if (this.hasFavorite) {
                    OptionMenu.show([{
                            id: 'opt-remove-favorite',
                            callback: () => {
                                this.removeFavorite(target.dataset.name);
                                this.updateFavoriteList();
                                this.updateSoftKeys();
                                this.view.focus();
                            }
                        }], () => {
                        this.view.focus();
                    });
                }
                break;
            default:
                break;
            }
            break;
        default:
            break;
        }
    }
};
window.FavoriteView = FavoriteView;