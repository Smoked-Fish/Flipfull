const ALLDATAXML = 'http://dir.xiph.org/yp.xml';
const TYPEDATAXML = 'https://dir.xiph.org/genres/';
const SEARCHDEFAULTURL = 'https://dir.xiph.org/search';
const SEARCHDATAXML = 'https://dir.xiph.org/search?q=';
const MAXSHOWNNUMBER = 30;
let searchArray = [];
const IceCastModule = {
    getAllStationData: function _getAllStationData() {
        const dataString = window.localStorage.getItem('allStationData');
        const allStationData = JSON.parse(dataString);
        return allStationData;
    },
    setAllStationData: function _setAllStationData(data) {
        const dataString = JSON.stringify(data);
        window.localStorage.setItem('allStationData', dataString);
    },
    getTypeStationData: function _getTypeStationData(type) {
        const keyWord = type + 'StationData';
        const dataString = window.localStorage.getItem(keyWord);
        const typeStationData = JSON.parse(dataString);
        return typeStationData;
    },
    setTypeStationData: function _setTypeStationData(type, data) {
        const keyWord = type + 'StationData';
        const dataString = JSON.stringify(data);
        window.localStorage.setItem(keyWord, dataString);
    },
    getAllList: function _getAllList(rescan, callback) {
        const previousData = this.getAllStationData();
        if (previousData && !rescan) {
            callback(previousData);
            return;
        }
        const xhr = new XMLHttpRequest();
        xhr.open('GET', ALLDATAXML, true);
        console.log('guirw get all start');
        xhr.onreadystatechange = () => {
            console.log('guirw get xhr.readyState is ' + xhr.readyState);
            console.log('guirw get xhr.status is ' + xhr.status);
            if (xhr.readyState === 4 && xhr.status === 200) {
                console.log('guirw get all end');
                const xmlString = xhr.responseText;
                const parse = new DOMParser();
                const xmlDoc = parse.parseFromString(xmlString, 'text/xml');
                const nameTags = xmlDoc.getElementsByTagName('server_name');
                const nameArray = [];
                Array.prototype.forEach.call(nameTags, nameTag => {
                    nameArray.push(nameTag.textContent);
                });
                const songTags = xmlDoc.getElementsByTagName('current_song');
                const typeArray = [];
                Array.prototype.forEach.call(songTags, songTag => {
                    typeArray.push(songTag.textContent);
                });
                const urlTags = xmlDoc.getElementsByTagName('listen_url');
                const urlArray = [];
                Array.prototype.forEach.call(urlTags, urlTag => {
                    urlArray.push(urlTag.textContent);
                });
                const finalJson = [];
                for (let i = 0; i < nameArray.length; i++) {
                    const pushData = {
                        name: nameArray[i],
                        type: typeArray[i],
                        url: urlArray[i]
                    };
                    finalJson.push(pushData);
                }
                this.setAllStationData(finalJson);
                callback(finalJson);
            }
        };
        xhr.send();
    },
    getListByType: function _getListByType(type, rescan, callback) {
        const previousData = this.getTypeStationData(type);
        if (previousData && !rescan) {
            callback(previousData);
            return;
        }
        const xhr = new XMLHttpRequest();
        const requestUrl = TYPEDATAXML + type;
        xhr.open('GET', requestUrl, true);
        console.log('guirw get type start');
        xhr.onreadystatechange = () => {
            console.log('guirw get type xhr.readyState is ' + xhr.readyState);
            console.log('guirw get type xhr.status is ' + xhr.status);
            if (xhr.readyState === 4 && xhr.status === 0) {
                console.log('guirw get type fail');
                callback(PreLoadModule.getPreType(type));
            }
            if (xhr.readyState === 4 && xhr.status === 200) {
                console.log('guirw get type end');
                const xmlString = xhr.responseText;
                const parse = new DOMParser();
                const xmlDoc = parse.parseFromString(xmlString, 'text/html');
                const contentArray = [];
                const contentDoms = xmlDoc.querySelectorAll('.shadow-sm');
                contentDoms.forEach(dom => {
                    const title = dom.querySelector('.card-title').textContent;
                    const subTitle = dom.querySelector('.card-subtitle').textContent;
                    const url = dom.querySelector('.btn-sm').getAttribute('href');
                    const listJson = {
                        name: title,
                        currentSong: subTitle,
                        url: url
                    };
                    contentArray.push(listJson);
                });
                this.setTypeStationData(type, contentArray);
                callback(contentArray);
            }
        };
        xhr.send();
    },
    formatKeyWord: function _formatKeyWord(keyWord) {
        let formatWord = keyWord.replace(/\s/g, '+');
        formatWord = formatWord.replace(/\//g, '%2F');
        return formatWord;
    },
    searchIndex: function _searchIndex(keyWord, callback, defaulturl) {
        const xhr = new XMLHttpRequest();
        const formatWord = this.formatKeyWord(keyWord);
        const requestUrl = defaulturl ? defaulturl : SEARCHDATAXML + formatWord;
        xhr.open('GET', requestUrl, true);
        console.log('guirw start get search');
        xhr.onreadystatechange = () => {
            console.log('guirw get search xhr.readyState is ' + xhr.readyState);
            console.log('guirw get search xhr.status is ' + xhr.status);
            if (xhr.readyState === 4 && xhr.status === 0) {
                console.log('guirw get search fail');
                callback(searchArray);
                searchArray = [];
            }
            if (xhr.readyState === 4 && xhr.status === 404) {
                console.log('guirw get search abnormal end');
                callback(searchArray);
                searchArray = [];
            }
            if (xhr.readyState === 4 && xhr.status === 200) {
                console.log('guirw get search end');
                const xmlString = xhr.responseText;
                const parse = new DOMParser();
                const xmlDoc = parse.parseFromString(xmlString, 'text/html');
                const contentDoms = xmlDoc.querySelectorAll('.shadow-sm');
                contentDoms.forEach(dom => {
                    const title = dom.querySelector('.card-title').textContent;
                    const subTitle = dom.querySelector('.card-subtitle').textContent;
                    const url = dom.querySelector('.btn-sm').getAttribute('href');
                    const listJson = {
                        name: title,
                        currentSong: subTitle,
                        url: url
                    };
                    if (url && title.includes(keyWord)) {
                        searchArray.push(listJson);
                    }
                });
                if (searchArray.length < MAXSHOWNNUMBER) {
                    const next = xmlDoc.querySelectorAll('.page-link')[1];
                    const nextURL = next && next.getAttribute('href');
                    console.log('guirw get next url :: ' + nextURL);
                    if (nextURL) {
                        this.searchIndex(keyWord, callback, SEARCHDEFAULTURL + nextURL);
                        return;
                    }
                }
                callback(searchArray);
                searchArray = [];
            }
        };
        xhr.send();
    }
};
window.IceCastModule = IceCastModule;