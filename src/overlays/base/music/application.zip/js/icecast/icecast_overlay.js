var IceCastOverlay = {
    get view() {
        return document.getElementById('icecast-overlay');
    },
    open: function (options) {
        this.setSoftKeys(options.keys);
        this.setContent(options.content);
        this.onLeft = options.onSoftLeft;
        this.onRight = options.onSoftRight;
        this.onCenter = options.onCenter;
        this.onBack = options.onBack;
        this.show();
    },
    close: function () {
        this.hide();
    },
    show: function () {
        this.view.classList.remove('hidden');
        this.view.addEventListener('keydown', this);
        this.view.focus();
    },
    hide: function () {
        this.view.removeEventListener('keydown', this);
        this.view.classList.add('hidden');
    },
    setSoftKeys: function IceCastOverlaySetSoftKeys(keys) {
        if (keys) {
            SoftKeyStore.register(keys, this.view);
        }
    },
    setContent: function IceCastOverlaySetContent(content) {
        const loadingBarEl = this.view.querySelector('.icecast-overlay-loading-bar');
        if (content.loadingBar) {
            loadingBarEl.classList.remove('hidden');
            this.view.classList.add('loading-style');
        } else {
            loadingBarEl.classList.add('hidden');
            this.view.classList.remove('loading-style');
        }
        const titleEl = this.view.querySelector('.icecast-overlay-title');
        if (content.title) {
            titleEl.setAttribute('data-l10n-id', content.title);
            titleEl.classList.remove('hidden');
        } else {
            titleEl.classList.add('hidden');
        }
        const imageEl = this.view.querySelector('.icecast-overlay-image');
        if (content.image) {
            imageEl.src = content.image;
            imageEl.classList.remove('hidden');
        } else {
            imageEl.classList.add('hidden');
        }
        const subtitleEl = this.view.querySelector('.icecast-overlay-subtitle');
        if (content.subtitle) {
            subtitleEl.setAttribute('data-l10n-id', content.subtitle);
            subtitleEl.classList.remove('hidden');
        } else {
            subtitleEl.classList.add('hidden');
        }
        const textEl = this.view.querySelector('.icecast-overlay-text');
        if (content.text) {
            textEl.setAttribute('data-l10n-id', content.text);
            textEl.classList.remove('hidden');
        } else {
            textEl.classList.add('hidden');
        }
    },
    handleEvent: function IceCastOverlayHandleEvent(evt) {
        let target = evt.target;
        if (!target) {
            return;
        }
        switch (evt.key) {
        case 'Enter':
            if (this.onCenter) {
                this.hide();
                this.onCenter();
            }
            break;
        case 'Backspace':
            evt.stopPropagation();
            evt.preventDefault();
            if (this.onBack) {
                this.hide();
                this.onBack();
            }
            break;
        default:
            break;
        }
    }
};
window.IceCastOverlay = IceCastOverlay;