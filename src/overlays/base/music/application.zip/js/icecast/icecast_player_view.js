const STATIONSTATUS_PLAYING = 'PLAYING';
const STATIONSTATUS_PAUSED = 'PAUSED';
const STATIONSTATUS_INTERRUPT = 'mozinterruptbegin';
let previousFocus = '';
let IceCastModulePlayerView = {
    get firstLaunch() {
        if (this._firstLaunch === undefined) {
            this._firstLaunch = true;
        }
        return this._firstLaunch;
    },
    set firstLaunch(isFirst) {
        this._firstLaunch = isFirst;
    },
    init: function _init() {
        if (!this.firstLaunch) {
            return;
        }
        this.firstLaunch = false;
        this.stationView = document.getElementById('i-region-views');
        this.view = document.getElementById('i-views-player');
        this.audio = document.getElementById('i-player-audio');
        this.currentSongView = document.querySelector('#i-player-cover-artist');
        this.stationNameText = document.querySelector('#i-player-cover-name bdi');
        this.currentSongText = document.querySelector('#i-player-cover-artist bdi');
        this.playTimeText = document.querySelector('#i-player-cover-album bdi');
        this.cover = document.getElementById('i-player-cover');
        this.coverImage = document.getElementById('i-player-cover-image');
        this.offscreenImage = new Image();
        this.caption = document.getElementById('i-player-cover-caption');
        this.playerseek = document.getElementById('i-player-seek');
        this.seekBar = document.getElementById('i-player-seek-bar-progress');
        this.view.addEventListener('keydown', this);
        this.audio.addEventListener('play', this);
        this.audio.addEventListener('pause', this);
        this.audio.addEventListener('timeupdate', this);
        this.audio.addEventListener('error', this);
        this.audio.addEventListener('waiting', this);
        this.audio.addEventListener('mozinterruptbegin', this);
        this.audio.addEventListener('mozinterruptend', this);
        window.addEventListener('visibilitychange', this);
        setHeadPhoneListener();
        this._audioChannelClient = setAudioChannel();
    },
    setStationInfo: function _setStationInfo(info) {
        this.stationName = info.name;
        this.stationSong = info.currentSong;
        this.stationURL = info.url;
        this.stationNameText.textContent = this.stationName;
        this.stationNameText.dataset.l10nId = this.stationName ? '' : 'unknownTitle';
        this.currentSongText.textContent = this.stationSong;
        this.currentSongText.dataset.l10nId = this.stationSong ? '' : 'unknownTitle';
        this.playTimeText.textContent = '00:00';
        this.playTimeText.dataset.l10nId = '';
        this.showUI();
        this.showInfo();
        this.view.focus();
    },
    showPlayerView: function _showPlayerView(target) {
        previousFocus = target.previousView ? target.previousView : target.previousFocus;
        console.log('guirw player previous focus is :: ' + previousFocus.tagName);
        this.favoriteFocus = target.previousView ? target.previousFocus : '';
        this.favoriteRemove = false;
        if (this.stationURL === target.url) {
            this.enterPlayer();
            return;
        }
        this.setStationInfo(target);
        this.playStationAudio();
    },
    enterPlayer: function _enterPlayer() {
        previousFocus = previousFocus ? previousFocus : document.activeElement;
        this.showUI();
        this.showInfo();
        this.updateSoftKeys();
        this.view.focus();
        if (!this.stationURL) {
            this.stationNameText.dataset.l10nId = 'not-playing';
            this.currentSongText.dataset.l10nId = '';
            this.currentSongView.classList.add('adjust-height');
            this.playTimeText.textContent = '--:--';
            this.playTimeText.dataset.l10nId = '';
            Toaster.showToast({ message: window.api.l10n.get('toast-not-playing') });
        }
    },
    playStationAudio: function _playStationAudio() {
        this.audio.removeAttribute('src');
        this.audio.load();
        this.audio.mozAudioChannelType = 'content';
        this.audio.src = this.stationURL;
        this.audio.load();
        this.playAudio();
    },
    playAudio: function _playAudio() {
        if (typeof PlayerView !== 'undefined') {
            PlayerView.audio && PlayerView.pause();
            PlayerView.seekAudio();
        }
        setTimeout(() => {
            this._audioChannelClient.requestChannel();
            this.audio.play();
        });
    },
    pauseAudio: function _pauseAudio() {
        this._audioChannelClient.abandonChannel();
        this.audio.pause();
    },
    togglePlay: function _TogglePlay() {
        if (this.playStatus === STATIONSTATUS_PLAYING) {
            this.pauseAudio();
        } else {
            this.playAudio();
        }
    },
    showUI: function _showUI() {
        this.view.classList.remove('hidden');
        document.body.classList.add('radio-mode');
    },
    showInfo: function _showInfo() {
        this.cover.classList.add('slideOut');
        this.playerseek.classList.add('slideOut');
        this.caption.classList.add('slideOut');
        this.seekBar.classList.add('seek-hide');
        this.seekBar.value = 0;
        this.setCoverImage();
    },
    setCoverImage: function _setCoverImage() {
        this.offscreenImage.src = '/style/images/station.png';
        this.coverImage.classList.remove('fadeIn');
        let url = 'url(' + this.offscreenImage.src + ')';
        this.coverImage.style.backgroundImage = url;
        this.coverImage.classList.add('fadeIn');
    },
    removeUI: function _removeUI() {
        this.view.classList.add('hidden');
        document.body.classList.remove('radio-mode');
    },
    removeInfo: function _removeInfo() {
        this.cover.classList.remove('slideOut');
        this.playerseek.classList.remove('slideOut');
        this.caption.classList.remove('slideOut');
        this.seekBar.classList.remove('seek-hide');
        this.currentSongView.classList.remove('adjust-height');
        this.removeCoverImage();
    },
    removeCoverImage: function _removeCoverImage() {
    },
    updateSoftKeys: function _updateSoftkeys() {
        SoftKeyStore.register({
            'left': 'opt-library',
            'center': this.stationURL ? this.playStatus === STATIONSTATUS_PLAYING ? 'icon=pause' : 'icon=play' : '',
            'right': this.stationURL ? 'options' : ''
        }, this.view);
    },
    updatePlayingIcon: function _updatePlayingIcon() {
        if (this.favoriteFocus) {
            previousFocus = this.favoriteFocus;
        }
        if (previousFocus.dataset.url && previousFocus.dataset.url === this.stationURL) {
            currentIcon = previousFocus.parentNode.querySelector('.list-playing-icon.active');
            if (currentIcon) {
                currentIcon.classList.remove('active');
            }
            previousFocus.querySelector('.list-playing-icon').classList.toggle('active', this.playStatus === STATIONSTATUS_PLAYING);
        }
    },
    handleEvent: function _HandleEvent(evt) {
        let target = evt.target;
        if (!target) {
            return;
        }
        switch (evt.type) {
        case 'play':
            this.playStatus = STATIONSTATUS_PLAYING;
            this.updateSoftKeys();
            break;
        case 'pause':
            this.playStatus = STATIONSTATUS_PAUSED;
            this.updateSoftKeys();
            break;
        case 'error':
            if (this.audio.error.code === 2) {
                this.playTimeText.textContent = formatTime(this.audio.currentTime);
                this.pauseAudio();
            }
            break;
        case 'timeupdate':
            this.playTimeText.textContent = formatTime(this.audio.currentTime);
            break;
        case 'waiting':
            this.playTimeText.textContent = window.api.l10n.get('playlists-loading');
            break;
        case 'mozinterruptbegin':
            if (typeof MusicComms !== 'undefined') {
                MusicComms.mozinterruptbegin = true;
            }
            this.playStatus = STATIONSTATUS_INTERRUPT;
            break;
        case 'mozinterruptend':
            if (typeof MusicComms !== 'undefined') {
                MusicComms.mozinterruptbegin = false;
            }
            this.playStatus = STATIONSTATUS_PLAYING;
            break;
        case 'keydown':
            switch (evt.key) {
            case 'SoftLeft':
                evt.preventDefault();
                this.removeUI();
                this.removeInfo();
                if (previousFocus.tagName === 'SECTION' && this.favoriteRemove) {
                    FavoriteView.updateFavoriteList();
                    FavoriteView.updateSoftKeys();
                }
                if (previousFocus.id === 'i-views-list-favorites' && IcecastView.favoriteLi.classList.contains('hidden')) {
                    previousFocus = IcecastView.searchInput;
                }
                previousFocus.focus();
                this.updatePlayingIcon();
                previousFocus = '';
                break;
            case 'SoftRight':
                if (this.stationURL) {
                    OptionMenu.show(this.buildOptionMenu(), () => {
                        this.view.focus();
                    });
                }
                evt.preventDefault();
                break;
            case 'Backspace':
                evt.preventDefault();
                this.removeUI();
                this.removeInfo();
                if (previousFocus.tagName === 'SECTION' && this.favoriteRemove) {
                    FavoriteView.updateFavoriteList();
                    FavoriteView.updateSoftKeys();
                }
                if (previousFocus.id === 'i-views-list-favorites' && IcecastView.favoriteLi.classList.contains('hidden')) {
                    previousFocus = IcecastView.searchInput;
                }
                previousFocus.focus();
                this.updatePlayingIcon();
                previousFocus = '';
                break;
            case 'Enter':
            case 'HeadsetHook':
                if (this.stationURL) {
                    this.togglePlay();
                }
                evt.preventDefault();
                break;
            case 'ArrowUp':
                AudioVolumeManager.requestVolumeUp();
                evt.preventDefault();
                break;
            case 'ArrowDown':
                AudioVolumeManager.requestVolumeDown();
                evt.preventDefault();
                break;
            case 'ArrowLeft':
                break;
            case 'ArrowRight':
                break;
            default:
                break;
            }
            break;
        case 'visibilitychange':
            if (document.hidden) {
                this.audio.removeEventListener('timeupdate', this);
            } else {
                this.audio.addEventListener('timeupdate', this);
            }
            break;
        default:
            break;
        }
    },
    buildOptionMenu: function _buildOptionMenu() {
        let options = [];
        let optAddFavorite = {
            id: 'opt-add-favorite',
            callback: () => {
                const station = {
                    name: this.stationName,
                    currentSong: this.stationSong,
                    url: this.stationURL
                };
                FavoriteView.addFavorite(station);
                this.view.focus();
                IcecastView.updateFavoriteUI();
            }
        };
        let optRemoveFavorite = {
            id: 'opt-remove-favorite',
            callback: () => {
                FavoriteView.removeFavorite(this.stationName);
                this.view.focus();
                this.favoriteRemove = true;
                IcecastView.updateFavoriteUI();
            }
        };
        if (FavoriteView.stations.has(this.stationName)) {
            options.push(optRemoveFavorite);
        } else {
            options.push(optAddFavorite);
        }
        return options;
    }
};
window.IceCastModulePlayerView = IceCastModulePlayerView;