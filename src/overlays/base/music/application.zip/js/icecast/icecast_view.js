const ICECAST_TYPE = {
    pop: {
        l10nId: 'item-pop',
        content: 'Pop'
    },
    rap: {
        l10nId: 'item-rap',
        content: 'Hip-hop%2FRap'
    },
    rock: {
        l10nId: 'item-rock',
        content: 'Rock'
    },
    country: {
        l10nId: 'item-country',
        content: 'Country'
    },
    elec: {
        l10nId: 'item-elec',
        content: 'Dance%20&%20Electronic'
    },
    rb: {
        l10nId: 'item-rb',
        content: 'Soul%20R&B'
    },
    latin: {
        l10nId: 'item-latin',
        content: 'Latin'
    },
    class: {
        l10nId: 'item-class',
        content: 'Classical'
    },
    jazz: {
        l10nId: 'item-jazz',
        content: 'Jazz'
    },
    blues: {
        l10nId: 'item-blues',
        content: 'Blues'
    },
    indie: {
        l10nId: 'item-indie',
        content: 'Indie'
    },
    alter: {
        l10nId: 'item-alter',
        content: 'Alternative'
    },
    metal: {
        l10nId: 'item-metal',
        content: 'Metal'
    },
    reg: {
        l10nId: 'item-reg',
        content: 'Reggae'
    },
    gos: {
        l10nId: 'item-gos',
        content: 'Gospel'
    },
    punk: {
        l10nId: 'item-punk',
        content: 'Punk'
    },
    folk: {
        l10nId: 'item-folk',
        content: 'Folk'
    },
    world: {
        l10nId: 'item-world',
        content: 'World%20Music'
    },
    easy: {
        l10nId: 'item-easy',
        content: 'Easy%20Listening'
    },
    old: {
        l10nId: 'item-old',
        content: 'Oldies'
    },
    talk: {
        l10nId: 'item-talk',
        content: 'Talk'
    },
    news: {
        l10nId: 'item-news',
        content: 'News'
    },
    comedy: {
        l10nId: 'item-comedy',
        content: 'Comedy'
    },
    weather: {
        l10nId: 'item-weather',
        content: 'Weather'
    },
    edm: {
        l10nId: 'item-edm',
        content: 'EDM'
    }
};
const subList = Object.create({});
Object.keys(ICECAST_TYPE).forEach(item => {
    subList[item] = `${ item }`;
});
const MODE = {
    mainList: 'main_list_mode',
    subList,
    search: 'search_mod'
};
var IcecastView = {
    get wrapper() {
        return document.getElementById('i-region-views');
    },
    get view() {
        return document.getElementById('i-views-list');
    },
    get anchor() {
        return document.getElementById('i-views-list-anchor');
    },
    get searchBox() {
        return document.getElementById('i-views-list-search');
    },
    get searchInput() {
        return document.getElementById('i-views-list-search-input');
    },
    get favoriteLi() {
        return document.getElementById('i-views-list-favorites');
    },
    get dataSource() {
        return this._dataSource;
    },
    set dataSource(source) {
        this._dataSource = source;
    },
    get mode() {
        return this._mode;
    },
    set mode(mode) {
        this._mode = mode;
        this.updateUI();
        this.restoreFocus(mode);
    },
    cacheFocus: function iRestoreFocus() {
        const curFocus = document.activeElement;
        if (curFocus && this.navigator) {
            const index = this.navigator.getElementIndex(curFocus);
            this.cacheIndex = {
                type: curFocus.dataset && curFocus.dataset.type || '',
                index
            };
        }
    },
    restoreFocus: function iRestoreFocus(to) {
        if (MODE.mainList === to && this.cacheIndex && this.cacheIndex.type) {
            const candidates = Array.from(this.view.querySelectorAll('.focusable'));
            let el = candidates[0];
            if (this.cacheIndex.index > 0) {
                el = candidates.find(e => {
                    if (e && e.dataset && e.dataset.type) {
                        return e.dataset.type === this.cacheIndex.type;
                    }
                    return false;
                });
            }
            if (this.navigator && el) {
                this.navigator.setFocus(el);
            }
        }
    },
    isSubMod: function iIsSubMod(m) {
        return this.isSubList(m) || m === MODE.search;
    },
    isSubList: function iIsSubList(m) {
        const subList = Object.values(MODE.subList);
        return subList.includes(m);
    },
    init: function iInit() {
        this.view.addEventListener('input', this);
        this.view.addEventListener('keydown', this);
        this.searchBox.addEventListener('focus', this, true);
        this.searchBox.addEventListener('blur', this, true);
        marquee(6 * 1000 / 90, 0);
        this.mode = MODE.mainList;
        IceCastModulePlayerView.init();
    },
    resetNav: function iResetNav() {
        this.navigator = new SimpleNavigationHelper('.focusable', this.view, null, 0);
        this.view.focus();
        this.navigator.refresh([]);
    },
    updateUI: function iUpdateUI() {
        this.clean();
        this.updateVisibility();
        this.updateList();
        this.updateSoftKeys();
        this.updateTitle();
        this.resetNav();
    },
    updateVisibility: function iInitUi() {
        document.body.classList.add('contain-header');
        if (MODE.mainList === this.mode) {
            Array.from(document.body.children).forEach(elt => {
                if ('title' === elt.id) {
                    elt.classList.toggle('hidden', false);
                    const title = document.getElementById('title-text');
                    title.classList.add('icecast-header');
                } else if ('i-region-views' === elt.id) {
                    elt.classList.toggle('hidden', false);
                    this.anchor.classList.remove('no-search');
                    this.searchBox.classList.remove('hidden');
                } else if ('softkeyPanel' === elt.id) {
                    elt.classList.toggle('hidden', false);
                } else {
                    elt.classList.toggle('hidden', true);
                }
            });
        } else if (this.isSubList(this.mode)) {
            this.searchBox.classList.add('hidden');
            this.anchor.classList.add('no-search');
        }
    },
    updateTitle: function iUpdateTitle() {
        if (MODE.mainList === this.mode || MODE.search === this.mode) {
            TitleBar.updateById('title-icecast-radio');
        } else if (this.isSubList(this.mode)) {
            const {l10nId} = ICECAST_TYPE[this.mode];
            l10nId && TitleBar.updateById(l10nId);
        }
    },
    updateSoftKeys: function iUpdateSotfKeys() {
        const left = MODE.search === this.mode ? 'opt-back' : 'opt-player';
        const center = MODE.mainList === this.mode ? 'select' : 'icon=play';
        SoftKeyStore.register({
            left,
            center,
            right: 'options'
        }, this.view);
        SoftKeyStore.register({
            left,
            center: this.searchInput.value ? 'search' : '',
            right: ''
        }, this.searchInput);
    },
    clean: function iClean() {
        this.navigator && this.navigator.destroy();
        this.anchor.scrollTop = 0;
        while (this.anchor.lastChild) {
            if (!RadioAd.isBannerAdNode(this.anchor.lastChild)) {
                this.anchor.removeChild(this.anchor.lastChild);
            } else {
                return;
            }
        }
    },
    setList: function (options) {
        options.forEach(option => {
            if (option.title) {
                const div = document.createElement('div');
                div.className = 'list-separator';
                const head = document.createElement('div');
                head.className = 'list-separator-head';
                div.appendChild(head);
                const text = document.createElement('bdi');
                text.className = 'list-separator-text';
                text.dataset.l10nId = option.title;
                div.appendChild(text);
                this.anchor.appendChild(div);
            } else if (option.item) {
                const li = document.createElement('li');
                li.className = 'list-item icecast-item focusable';
                li.setAttribute('tabindex', '-1');
                li.dataset.type = option.item;
                option.currentSong && (li.dataset.currentSong = option.currentSong);
                option.url && (li.dataset.url = option.url);
                const a = document.createElement('a');
                li.appendChild(a);
                const titleBdi = document.createElement('bdi');
                titleBdi.className = 'list-single-title bold-text primary p-pri';
                if (ICECAST_TYPE[option.item]) {
                    const {l10nId} = ICECAST_TYPE[option.item];
                    titleBdi.dataset.l10nId = l10nId;
                } else {
                    titleBdi.textContent = option.item;
                }
                a.appendChild(titleBdi);
                if (option.url) {
                    let playingsongicon = document.createElement('div');
                    if (IceCastModulePlayerView.stationURL && IceCastModulePlayerView.stationURL === option.url && IceCastModulePlayerView.playStatus === 'PLAYING') {
                        playingsongicon.className = 'list-playing-icon active';
                    } else {
                        playingsongicon.className = 'list-playing-icon';
                    }
                    playingsongicon.setAttribute('data-icon', 'sound-max');
                    li.appendChild(playingsongicon);
                }
                this.anchor.appendChild(li);
            }
        });
    },
    showListMessage: function (msg) {
        const div = document.createElement('div');
        div.className = 'list-msg';
        div.dataset.l10nId = msg;
        this.anchor.appendChild(div);
    },
    updateFavoriteUI: function iUpdateFavoriteUI() {
        this.favoriteLi.classList.toggle('hidden', !(MODE.mainList === this.mode && FavoriteView.hasFavorite && !this.loading));
    },
    updateList: function iUpdate() {
        let options = [];
        this.favoriteLi.classList.toggle('hidden', !(MODE.mainList === this.mode && FavoriteView.hasFavorite));
        if (MODE.mainList === this.mode) {
            options = [{ title: 'separator-popular' }];
            const list = Object.values(MODE.subList);
            list.forEach(item => {
                options.push({ item });
            });
        } else if (MODE.search === this.mode) {
            if (this.dataSource.length) {
                this.dataSource.forEach(item => {
                    options.push({
                        item: item.name,
                        currentSong: item.currentSong,
                        url: item.url
                    });
                });
            } else {
                this.showListMessage('no-station');
            }
        } else if (this.isSubList(this.mode)) {
            this.dataSource.forEach(item => {
                options.push({
                    item: item.name,
                    currentSong: item.currentSong,
                    url: item.url
                });
            });
        }
        if (options.length) {
            this.setList(options);
        }
    },
    buildOptionMenu: function iBuildOptionMenu(target) {
        const optScan = {
            id: 'opt-scan',
            callback: () => {
                IceCastOverlay.open({
                    keys: { center: '' },
                    content: {
                        loadingBar: true,
                        subtitle: 'scanning-stations'
                    }
                });
                IceCastModule.getListByType(ICECAST_TYPE[this.mode].content, true, list => {
                    IceCastOverlay.close();
                    this.dataSource = list && list.length ? list : [];
                    this.updateUI();
                    this.view.focus();
                });
            }
        };
        const optAbout = {
            id: 'opt-about',
            callback: () => {
                this.wrapper.classList.add('hidden');
                AboutIcecastView.init();
            }
        };
        const station = {
            name: target.dataset.type,
            currentSong: target.dataset.currentSong,
            url: target.dataset.url
        };
        const optAddFavorite = {
            id: 'opt-add-favorite',
            callback: () => {
                FavoriteView.addFavorite(station);
                this.view.focus();
            }
        };
        const optRemoveFavorite = {
            id: 'opt-remove-favorite',
            callback: () => {
                FavoriteView.removeFavorite(station.name);
                this.view.focus();
            }
        };
        const isFavorite = FavoriteView.isFavorite(station.name);
        let optionsArr;
        if (MODE.mainList === this.mode) {
            optionsArr = [optAbout];
        } else if (this.isSubList(this.mode)) {
            optionsArr = [
                optScan,
                isFavorite ? optRemoveFavorite : optAddFavorite
            ];
        } else {
            optionsArr = [isFavorite ? optRemoveFavorite : optAddFavorite];
        }
        return optionsArr;
    },
    onEnter: function iOnEnter(target) {
        if (!target.dataset || !target.dataset.type) {
            return;
        }
        if (MODE.mainList === this.mode && target.dataset.type === 'favorite') {
            FavoriteView.show();
        }
        if (MODE.mainList === this.mode) {
            const {type} = target.dataset;
            if (!ICECAST_TYPE[type]) {
                return;
            }
            const typeValue = ICECAST_TYPE[type].content;
            typeValue && IceCastModule.getListByType(typeValue, false, list => {
                if (list && list.length) {
                    this.dataSource = list && list.length ? list : [];
                    this.mode = MODE.subList[type];
                } else {
                    IceCastOverlay.open({
                        keys: { center: 'ok' },
                        content: {
                            title: 'icecast-radio',
                            image: '/style/images/no-radio.png',
                            subtitle: 'no-stations',
                            text: 'no-stations-retry'
                        },
                        onCenter: () => {
                            this.view.focus();
                        },
                        onBack: () => {
                            this.view.focus();
                        }
                    });
                }
            });
        } else if (this.isSubList(this.mode) || MODE.search === this.mode) {
            const currentFocus = document.activeElement;
            const showPlayer = () => {
                IceCastModulePlayerView.showPlayerView({
                    name: target.dataset.type,
                    currentSong: target.dataset.currentSong,
                    url: target.dataset.url,
                    previousFocus: currentFocus
                });
            };
            showDataWarning(() => {
                this.view.focus();
            }, showPlayer);
        }
    },
    onSearch: function iOnSearch() {
        const text = this.searchInput.value;
        if (text && !this.loading) {
            this.loading = true;
            this.updateFavoriteUI();
            this.clean();
            this.showListMessage('scanning-stations');
            SoftKeyStore.register({
                left: '',
                center: '',
                right: ''
            }, this.searchInput);
            IceCastModule.searchIndex(text, list => {
                this.loading = false;
                this.updateFavoriteUI();
                this.dataSource = list && list.length ? list : [];
                this.mode = MODE.search;
            });
        }
    },
    onBack: function iOnBack() {
        this.cacheIndex = null;
        this.navigator && this.navigator.destroy();
        document.body.classList.remove('contain-header');
        const title = document.getElementById('title-text');
        title.classList.remove('icecast-header');
        this.view.removeEventListener('input', this);
        this.view.removeEventListener('keydown', this);
        this.searchBox.removeEventListener('focus', this, true);
        this.searchBox.removeEventListener('blur', this, true);
        this.wrapper.classList.add('hidden');
        const mainView = document.getElementById('main-view');
        mainView.classList.remove('hidden');
        MainView.activate();
    },
    handleEvent: function iHandleEvent(evt) {
        let target = evt.target;
        if (!target) {
            return;
        }
        const isFocusInput = Boolean(target.id === 'i-views-list-search-input');
        switch (evt.type) {
        case 'focus':
            if (isFocusInput) {
                this.searchBox.classList.add('focused');
            }
            break;
        case 'blur':
            if (isFocusInput) {
                this.searchBox.classList.remove('focused');
            }
            break;
        case 'input':
            this.updateSoftKeys();
            break;
        case 'keydown':
            switch (evt.key) {
            case 'Enter':
                if (MODE.mainList === this.mode) {
                    this.cacheFocus();
                }
                if (isFocusInput) {
                    this.onSearch();
                } else {
                    this.onEnter(target);
                }
                break;
            case 'Backspace':
                if (isFocusInput && this.searchInput.value.length > 0) {
                    evt.preventDefault();
                } else if (this.isSubMod(this.mode)) {
                    evt.preventDefault();
                    this.mode = MODE.mainList;
                } else {
                    evt.preventDefault();
                    MainView.musicMode = true;
                    this.onBack();
                }
                break;
            case 'SoftLeft':
                if (MODE.search === this.mode) {
                    this.searchInput.value = '';
                    this.mode = MODE.mainList;
                } else {
                    IceCastModulePlayerView.enterPlayer();
                }
                break;
            case 'SoftRight':
                if (!isFocusInput) {
                    OptionMenu.show(this.buildOptionMenu(target), () => {
                        this.view.focus();
                    });
                }
                break;
            case 'ArrowLeft':
            case 'ArrowRight':
            default:
                break;
            }
            break;
        default:
            break;
        }
    }
};
window.IcecastView = IcecastView;