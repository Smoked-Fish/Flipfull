const PreLoadModule = {
    get PopData() {
        return [
            {
                name: '     ..:: RETRO HIT - РЕТРО ХИТ ::.. AMG RADIO',
                currentSong: 'On Air: МАРИНА ЖУРАВЛЁВА - НА СЕРДЦЕ РАНА У МЕНЯ',
                url: 'https://retro.amgradio.ru/Retro'
            },
            {
                name: '     ..:: RUSSIAN ROCK - РУССКИЙ РОК ::.. AMG RADIO',
                currentSong: 'On Air: БИ-2 - НИКТО НЕ ПРИДЕТ',
                url: 'https://rock.amgradio.ru/RusRock'
            },
            {
                name: '     ..:: REMIX FM ::.. AMG RADIO',
                currentSong: 'On Air: DABRO - МНЕ НЕ СТРАШНО (RAMIREZ / D. ANUCHIN)',
                url: 'https://rmx.amgradio.ru/RemixFM'
            },
            {
                name: '     ..:: HOROSHEE RADIO - ХОРОШЕЕ РАДИО ::.. AMG RADIO',
                currentSong: 'On Air: ЧИ ЛИ - РОМАШКОВОЕ ПОЛЕ',
                url: 'https://hr.amgradio.ru/Horoshee'
            },
            {
                name: '     ..:: HYPE FM  - ХАЙП FM ::.. AMG RADIO',
                currentSong: 'On Air: KAN - АНГЕЛ',
                url: 'https://hfm.amgradio.ru/HypeFM'
            },
            {
                name: '     ..:: SHTORM FM - ШТОРМ FM ::.. AMG RADIO',
                currentSong: 'On Air: SOUNDWAVES / SUGAR JESUS / NINA CARR - EASY COME, EASY GO (LA VIDA)',
                url: 'https://shtorm.amgradio.ru/shtormfm'
            },
            {
                name: '     ..:: LITE FM ::.. AMG RADIO',
                currentSong: 'On Air: YEARS AND YEARS - SWEET TALKER',
                url: 'https://litefm.amgradio.ru/litefm'
            },
            {
                name: '     ..:: MEGA RADIO  - МЕГА РАДИО ::.. AMG RADIO',
                currentSong: 'On Air: ZARA LARSSON - YOU LOVE WHO YOU LOVE',
                url: 'https://mega.amgradio.ru/mega'
            },
            {
                name: '     ..:: RUSSIAN WAVE - РУССКАЯ ВОЛНА ::.. AMG RADIO',
                currentSong: 'On Air: СЕРГЕЙ ЛАЗАРЕВ - Я ВИДЕЛ СВЕТ',
                url: 'https://ru1.amgradio.ru/RuWave48'
            },
            {
                name: '     ..:: RUSSKOE FM - РУССКОЕ FM ::.. AMG RADIO',
                currentSong: 'On Air: JONY - НИКАК',
                url: 'https://rufm.amgradio.ru/rufm'
            },
            {
                name: '     ..:: MURKA FM - МУРКА FM ::.. AMG RADIO',
                currentSong: 'On Air: ВЯЧЕСЛАВ БЫКОВ - ДЕВЧОНКА С ВИШНЕВЫМ ВКУСОМ',
                url: 'https://murka.amgradio.ru/MurkaFM'
            },
            {
                name: '     ..:: DJIN FM - ДЖИН FM ::.. AMG RADIO',
                currentSong: 'On Air: TAYLOR SWIFT - ANTI HERO',
                url: 'https://djin.amgradio.ru/djin'
            },
            {
                name: '     ..:: KIDS HIT - ДЕТСКИЙ ХИТ ::.. AMG RADIO',
                currentSong: 'On Air: ДЕТСКИЕ ПЕСНИ - МУЗЫКА',
                url: 'https://deti.amgradio.ru/Deti'
            },
            {
                name: '     ..:: Radio FRESH ::.. AMG RADIO',
                currentSong: 'On Air: ILKAY SENCAN / OLIVIA ADDAMS - OMG (OH MY GOD)',
                url: 'https://fresh.amgradio.ru/Fresh'
            },
            {
                name: 'Danubius R\uFFFDdi\uFFFD SQ',
                currentSong: 'On Air: James Blunt - Bonfire Heart',
                url: 'http://stream.danubiusradio.hu:8081/danubius_192k'
            },
            {
                name: 'RADIO BGRADIO',
                currentSong: 'On Air: МИРО И КОЙНА РУСЕВА - НАВИСОКО',
                url: 'http://play.global.audio:80/bgradio128'
            },
            {
                name: 'RUSSIAN SONGS',
                currentSong: 'On Air: ЗВОНКИЙ - Вот И Все',
                url: 'http://s2.cdnradio.ru:80/ru-aac-64'
            },
            {
                name: 'RUSSIAN SONGS',
                currentSong: 'On Air: ЗВОНКИЙ - Вот И Все',
                url: 'http://s2.cdnradio.ru:80/ru-mp3-128'
            },
            {
                name: 'Радио СИ, Екатеринбург, 103.7 FM',
                currentSong: 'On Air: Enrique Iglesias - Not In Love',
                url: 'http://188.128.117.99:8000/radioc_aacplus'
            },
            {
                name: 'Vip-Radios.FM - Crossroads',
                currentSong: 'On Air: Fabri Fibra - 03 - Io Non T\'Invidio',
                url: 'http://radio3.vip-radios.fm:8009/stream-128k-SJFlorida_autodj'
            },
            {
                name: 'Радио СИ, Екатеринбург, 103.7 FM',
                currentSong: 'On Air: Enrique Iglesias - Not In Love',
                url: 'http://188.128.117.99:8000/radioc'
            },
            {
                name: 'Danubius R\uFFFDdi\uFFFD HQ',
                currentSong: 'On Air: James Blunt - Bonfire Heart',
                url: 'http://stream.danubiusradio.hu:8081/danubius_320k'
            },
            {
                name: 'Radio Birikina',
                currentSong: 'On Air: AFRIC SIMONE - HAFANANA',
                url: 'http://ice01.fluidstream.net:80/birikina'
            },
            {
                name: 'ÐÐ\xB6ÐµÐ\xBC FM, ÐÐºÐ\xB0ÑÐµÑÐ\xB8Ð\xBDÐ\xB1ÑÑÐ\xB3, 102.5 FM',
                currentSong: 'On Air: ÐÐ\xB0Ð\xB3Ð\xB0ÑÐ\xB8Ð\xBDÐ\xB0 - ÐÑÐµÑÐ\xB0',
                url: 'http://46.61.148.62:8000/jam_aacplus'
            },
            {
                name: 'ÐÐ\xB6ÐµÐ\xBC FM, ÐÐºÐ\xB0ÑÐµÑÐ\xB8Ð\xBDÐ\xB1ÑÑÐ\xB3, 102.5 FM',
                currentSong: 'On Air: ÐÐ\xB0Ð\xB3Ð\xB0ÑÐ\xB8Ð\xBDÐ\xB0 - ÐÑÐµÑÐ\xB0',
                url: 'http://46.61.148.62:8000/jam'
            },
            {
                name: 'Радио Олимп, Челябинск, 104.5 FM',
                currentSong: 'On Air: Enya - Flora\'s Secret',
                url: 'http://188.128.117.99:8000/olimp'
            },
            {
                name: 'Radio Gelosa',
                currentSong: 'On Air: Radio Gelosa',
                url: 'http://ice01.fluidstream.net:80/gelosa'
            },
            {
                name: 'Пилот FM, Екатеринбург, 100.4 FM',
                currentSong: 'On Air: R3Hab & Vize & JP Cooper - Jet Plane',
                url: 'http://188.254.50.254:8000/pilot'
            },
            {
                name: 'Radio PASSAZH',
                currentSong: 'On Air: IMANBEK & BYOR - Belly Dancer',
                url: 'http://s2.cdnradio.ru:80/aac-64'
            },
            {
                name: 'Radio Globo',
                currentSong: 'On Air: ',
                url: 'http://globo.newradio.it:80/globorm64'
            }
        ];
    },
    get HipData() {
        return [{
                name: 'LJP Radio',
                currentSong: 'On Air: The Temptations - Just My Imagination',
                url: 'http://us.everestcast.com:1200/stream'
            }];
    },
    get RockData() {
        return [
            {
                name: '     ..:: RUSSIAN ROCK - РУССКИЙ РОК ::.. AMG RADIO',
                currentSong: 'On Air: ЗЕМФИРА - ЗНАК БЕСКОНЕЧНОСТИ',
                url: 'https://rock.amgradio.ru/RusRock'
            },
            {
                name: 'K-Rock',
                currentSong: 'On Air: allusinlove - Just Like Hell',
                url: 'http://ice10.fluidstream.net:8080/ric.mp3'
            },
            {
                name: 'Radio Marilu',
                currentSong: 'On Air: BILL CONTI - GONNA FLY NOW',
                url: 'http://ice01.fluidstream.net:80/marilu'
            },
            {
                name: 'RADIO fresh80s - Hier sind die Achtziger zuhause!',
                currentSong: 'On Air: Queen - I Want It All',
                url: 'http://s37.derstream.net:80/live.mp3'
            },
            {
                name: 'BDPST ROCK SQ',
                currentSong: 'On Air: Fozzy - I Still Burn',
                url: 'http://s2.audiostream.hu:8081/bdpstrock_192k'
            },
            {
                name: 'Radio Karnaval, 92.8FM in Moscow',
                currentSong: 'On Air: Dua Lipa - Houdini',
                url: 'http://188.254.50.253:8000/karnaval'
            },
            {
                name: 'ICE RADIO WALDKRAIBURG 4 +++ Nur Das Beste Aus 70 Jahren Rock Musik',
                currentSong: 'On Air: Magnum - Broken City',
                url: 'http://irw.tunefm.de:18310/stream'
            },
            {
                name: 'isw',
                currentSong: 'On Air: ',
                url: 'http://radioisw.icecaststream.de:8000/stream'
            },
            {
                name: 'BDPST ROCK HQ',
                currentSong: 'On Air: Fozzy - I Still Burn',
                url: 'http://s2.audiostream.hu:8081/bdpstrock_320k'
            },
            {
                name: 'Радио Альфа, Пермь, 104.1 FM',
                currentSong: 'On Air: Ночные Снайперы - Разбуди Меня',
                url: 'http://188.128.117.99:8000/alfa_mp3'
            },
            {
                name: 'SmoothJazz.com',
                currentSong: 'On Air: Dee Brown - The Thing Is... ',
                url: 'http://ais-edge91-dal03.cdnstream.com:80/2585_128.mp3'
            },
            {
                name: 'RADIO fresh80s - Hier sind die Achtziger zuhause!',
                currentSong: 'On Air: Queen - I Want It All',
                url: 'http://178.77.76.9:8000/live.mp3'
            },
            {
                name: 'ICE RADIO WALDKRAIBURG 1 Mix Spezial',
                currentSong: 'On Air: IRW-Radio - Nachrichten',
                url: 'http://irw.tunefm.de:18070/stream'
            },
            {
                name: 'Rock Arsenal, Екатеринбург, 104.5 FM',
                currentSong: 'On Air: Cage the Elephant - Mess Around',
                url: 'http://188.128.117.99:8000/rockwotalk'
            },
            {
                name: 'SmoothJazz.com',
                currentSong: 'On Air: Dee Brown - The Thing Is... ',
                url: 'http://ais-edge91-dal03.cdnstream.com:80/2585_320.mp3'
            },
            {
                name: 'Friesenradio',
                currentSong: 'On Air: Justin Timberlake - Rock Your Body',
                url: 'http://stream.laut.fm/friesenradio'
            },
            {
                name: 'LOVE FM',
                currentSong: 'On Air: ',
                url: 'http://s1.voscast.com:10242/lovefm'
            },
            {
                name: 'SmoothLounge.com',
                currentSong: 'On Air: Svoy - Looking For You ',
                url: 'http://ais-edge91-dal03.cdnstream.com:80/2586_128.mp3'
            },
            {
                name: 'Box UK Radio danceradiouk',
                currentSong: 'On Air: Darla Jade - Slow Motion',
                url: 'http://uk7.internet-radio.com:8226/live'
            },
            {
                name: 'Hard Rock Heaven - 80s Hard Rock, Hair Metal, Heavy Metal, Glam - www.hrhradio.com',
                currentSong: 'On Air: Ratt - Lay It Down',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1521_128'
            },
            {
                name: 'MOROW',
                currentSong: 'On Air: Magenta - Greed',
                url: 'http://stream.fr.morow.com:8000/morow_med.aacp'
            },
            {
                name: 'This is my server name',
                currentSong: 'On Air: Foundations - Baby, Now That I Found You',
                url: 'http://s9.citrus3.com:8398/stream'
            },
            {
                name: 'IP music - aacPlus@96 Kb/s',
                currentSong: 'On Air: The Limit - Love Attaxx *** www.ipmusic.ch',
                url: 'http://live9.avf.ch:8000/ipmusicaacplus96'
            },
            {
                name: 'R\uFFFDDIO BOM JESUS',
                currentSong: 'On Air: ',
                url: 'http://streamserver.streamingdevideo.com.br:18050/stream'
            },
            {
                name: 'IP music SLOW - aacPlus@96 Kb/s',
                currentSong: 'On Air: R. Kelly - If I Could Turn Back The Hands Of Time *** www.ipmusicslow.ch',
                url: 'http://live9.avf.ch:8000/ipmusicslowaacp96'
            },
            {
                name: 'SmoothJazz.com',
                currentSong: 'On Air: Dee Brown - The Thing Is... ',
                url: 'http://ais-edge91-dal03.cdnstream.com:80/2585_256.mp3'
            },
            {
                name: 'SmoothJazz.com',
                currentSong: 'On Air: Dee Brown - The Thing Is... ',
                url: 'http://ais-edge91-dal03.cdnstream.com:80/2585_64.aac'
            },
            {
                name: 'AGF-RADIO Stream',
                currentSong: 'On Air: Ohrenfeindt - Motormaedchen',
                url: 'http://server4.streamserver24.com:43527/autodj'
            },
            {
                name: 'RADIO fresh80s - Hier sind die Achtziger zuhause! (Mobile-Stream 128kb/s mp3)',
                currentSong: 'On Air: Earth Wind And Fire - Lets Groove',
                url: 'http://s37.derstream.net:80/128.mp3'
            },
            {
                name: 'T-ROCK',
                currentSong: 'On Air: ',
                url: 'http://ice37.fluidstream.net:80/trock.mp3'
            }
        ];
    },
    get CountryData() {
        return [
            {
                name: 'Muddy Country Radio',
                currentSong: 'On Air: ',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/2123_128.mp3'
            },
            {
                name: 'Muddy Country Radio',
                currentSong: 'On Air: ',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/2123_128.mp3'
            },
            {
                name: 'Grolloo Radio',
                currentSong: 'On Air: Rich Hopkins and Luminarios - San Francisco Blvd.',
                url: 'http://uk1.streamingpulse.com:7053/live'
            },
            {
                name: 'Muddy Country Radio',
                currentSong: 'On Air: ',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/2123_128.mp3'
            },
            {
                name: 'America\'s Country',
                currentSong: 'On Air: Brooks & Dunn - The Long Goodbye [Steers & Stripes]',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/1976_128.mp3'
            },
            {
                name: 'WSM-AM (MP3)',
                currentSong: 'On Air: WSM 1 - WSM-AM',
                url: 'http://stream01048.westreamradio.com:80/wsm-am-mp3'
            },
            {
                name: 'Irish Country Music Radio',
                currentSong: 'On Air: Rossi M - Blue Kilkenny Eyes',
                url: 'http://46.28.49.164:7502/autodj'
            },
            {
                name: 'America\'s Country',
                currentSong: 'On Air: Brooks & Dunn - The Long Goodbye [Steers & Stripes]',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/1976_128.mp3'
            },
            {
                name: 'America\'s Country',
                currentSong: 'On Air: Brooks & Dunn - The Long Goodbye [Steers & Stripes]',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/1976_128.mp3'
            },
            {
                name: 'WSM-AM (AAC)',
                currentSong: 'On Air: WSM 1 - WSM-AM',
                url: 'http://stream01047.westreamradio.com:80/wsm-am-aac'
            },
            {
                name: 'Highway 65 Radio',
                currentSong: 'On Air: Keith Urban - Wild Hearts',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1924_64'
            },
            {
                name: 'Radio Qu\uFFFDbec-Country',
                currentSong: 'On Air: Jon Pardi - Head Over Boots',
                url: 'http://play.quebec-country.com:80/'
            },
            {
                name: 'U luistert naar www.muziekteam.nl voor de beste piraten hits',
                currentSong: 'On Air: Unknown',
                url: 'http://mcp-1.streampanel.nl:18036/stream'
            },
            {
                name: 'America\'s Country',
                currentSong: 'On Air: Brooks & Dunn - The Long Goodbye [Steers & Stripes]',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/1976_64.aac'
            },
            {
                name: 'Musichitz Looktung',
                currentSong: 'On Air: เอ้าชน - ธีเดช ทองอภิชาติ x หัวโบราณ',
                url: 'http://sv2.hostpleng.com:9386/autodj'
            },
            {
                name: 'America\'s Country',
                currentSong: 'On Air: Brooks & Dunn - The Long Goodbye [Steers & Stripes]',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/1976_64.aac'
            },
            {
                name: 'KISS Country',
                currentSong: 'On Air: Glen Campbell - Rhinestone Cowboy ',
                url: 'http://cast1.torontocast.com:2100/stream'
            },
            {
                name: 'SGS',
                currentSong: 'On Air: ',
                url: 'http://stm01.virtualcast.com.br:8350/stream'
            },
            {
                name: 'America\'s Country',
                currentSong: 'On Air: Brooks & Dunn - The Long Goodbye [Steers & Stripes]',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/1976_64.aac'
            },
            {
                name: 'POWERHITZ.COM - Total Country',
                currentSong: 'On Air: Thomas Rhett - Angels ',
                url: 'http://ais-edge83-jbmedia-nyc04.cdnstream.com:80/country'
            },
            {
                name: 'HOLLAND COUNTRY RADIO',
                currentSong: 'On Air: Walker Brothers - No Regrets',
                url: 'http://stream.hosting078.nl:8072/stream'
            },
            {
                name: '.113FM Big Kickin Country',
                currentSong: 'On Air: Charlie Worsham - Could It Be',
                url: 'http://ais-edge87-113fm-bhs06.cdnstream.com:80/1715_128'
            },
            {
                name: '***Muziekknallers.nl**Keihard De Beste**op jou radio**',
                currentSong: 'On Air: Peter Smulders - El Paso',
                url: 'http://server-28.stream-server.nl:8969/stream'
            },
            {
                name: 'Howlin Country - Yesterdays Legends and Todays Hits',
                currentSong: 'On Air: Rascal Flatts - How They Remember You',
                url: 'http://cheetah.streemlion.com:1140/stream'
            },
            {
                name: 'KWPX Cowpoke Country Radio',
                currentSong: 'On Air: Derwood Brown & His Musical Brownies - Bring It On Down To My House ',
                url: 'http://pavo.prostreaming.net:8034/stream'
            },
            {
                name: 'Radio Twilight draait de mooiste hitsss',
                currentSong: 'On Air: Jan Biggel & Special Krew - stuiteruh',
                url: 'http://live.hostingbudget.nl:4270/stream'
            },
            {
                name: '.113FM Route 66',
                currentSong: 'On Air: ',
                url: 'http://ais-edge87-113fm-bhs06.cdnstream.com:80/1755_128'
            },
            {
                name: 'Gewoonpiraten altijd gezellig',
                currentSong: 'On Air: De hits uit de Jukebox. Je hoort nu: DIANE - amore jelske dei',
                url: 'http://server-67.stream-server.nl:8802/stream'
            },
            {
                name: 'Best Country Mix - http://www.Country-Radio.eu:8044/128.mp3',
                currentSong: 'On Air: Smoke! Smoke! Smoke! - Tex Williams - 00:02:57',
                url: 'http://www.Country-Radio.eu:8044/128.mp3'
            },
            {
                name: '.113FM Big Kickin Country',
                currentSong: 'On Air: Charlie Worsham - Could It Be',
                url: 'http://ais-edge88-113fm-bhs07.cdnstream.com:80/1715_128'
            }
        ];
    },
    get DanceData() {
        return [
            {
                name: 'Nrw-Radio',
                currentSong: 'On Air: ELEHA - Vielleicht',
                url: 'http://stream.laut.fm/nrwradio'
            },
            {
                name: '1000 Dance',
                currentSong: 'On Air: Jax Jones feat. Mike Dunn & MNEK - House Work',
                url: 'http://stream.laut.fm/1000dance'
            }
        ];
    },
    get SoulData() {
        return [{
                name: 'RADIO SERVICE',
                currentSong: 'On Air: dire straits - on every street',
                url: 'http://stream.radeo.fr:8000/radioservice.mp3'
            }];
    },
    get LatinData() {
        return [
            {
                name: 'RM Radio',
                currentSong: 'On Air: Rema, Selena Gomez - Calm Down',
                url: 'http://cast2.rmradio.es:8003/campillo'
            },
            {
                name: 'LATINO FM',
                currentSong: 'On Air: Frank Reyes - Amor a Distancia',
                url: 'http://s37.derstream.net:80/latinofm.mp3'
            },
            {
                name: 'WUCF-HD2',
                currentSong: 'On Air: Bossa Dorado - Tomas Martin Lopez',
                url: 'http://peridot.streamguys.com:7830/WUCF-HD2'
            },
            {
                name: 'Loca Urban Salamanca',
                currentSong: 'On Air: Loca URBAN Salamanca 87.5 FM',
                url: 'http://s3.we4stream.com:8031/liveapp'
            },
            {
                name: 'Ràdio Indiana',
                currentSong: 'On Air: INDIANA Un so que s\'encomana',
                url: 'http://streaming.martiproduccions.com:8000/indiana'
            },
            {
                name: 'LATINO FM',
                currentSong: 'On Air: Frank Reyes - Amor a Distancia',
                url: 'http://s37.derstream.net:80/latinofm-aac.mp3'
            },
            {
                name: 'Radio Haiti Fusion',
                currentSong: 'On Air: ',
                url: 'http://ec3.yesstreaming.net:2500/stream'
            },
            {
                name: 'TOP EsLa Radio Spain :: Señal Respaldo Centro Emisor',
                currentSong: 'On Air: DATZY - Fusion (Radio Edit)',
                url: 'http://topradio.uno:9000/autodj'
            },
            {
                name: 'Radio Salsa4te',
                currentSong: 'On Air: Guayacan - Mi Muchachita',
                url: 'http://radiomusic.newradio.it:80/salsa4te'
            },
            {
                name: 'WUCF-HD2_QL',
                currentSong: 'On Air: Bossa Dorado - Tomas Martin Lopez',
                url: 'http://peridot.streamguys.com:7830/WUCF-HD2_QL'
            },
            {
                name: 'Cajica Radio Internacional',
                currentSong: 'On Air: PISA. CAJICA RADIO 94.4 FM ( IDENTIDAD TOTAL ) REF. EN TU DIAL BAJO',
                url: 'http://mediacp15.rootservers.co:18180/stream'
            },
            {
                name: 'Pirate Radio GR - Mood Vibes',
                currentSong: 'On Air:  GRAMATIK - IN THIS WHOLE WORLD',
                url: 'http://live.piratefm.net:8080/mood'
            },
            {
                name: 'Vip-Radios.fm - Radio Quisqueya',
                currentSong: 'On Air: Radio Quisqueya - El Alma De La Musica !',
                url: 'http://radio3.vip-radios.fm:8000/stream-128kmp3-Quisqueya_autodj'
            },
            {
                name: 'POWERHITZ.COM - MEGA 1000 - LATIN HITS',
                currentSong: 'On Air: Martin Solveig and GTA - Intoxicated ',
                url: 'http://ais-edge83-jbmedia-nyc04.cdnstream.com:80/latin'
            },
            {
                name: 'Ràdio Indiana',
                currentSong: 'On Air: INDIANA Un so que s\'encomana',
                url: 'http://streaming.martiproduccions.com:8000/indianahd'
            },
            {
                name: 'Vip-Radios.fm - Radio Quisqueya',
                currentSong: 'On Air: Radio Quisqueya - El Alma De La Musica !',
                url: 'http://radio3.vip-radios.fm:8000/stream-128k-SJCalifornia_autodj'
            },
            {
                name: 'Fuerza809',
                currentSong: 'On Air: La Mejor De Todas - Zacarias Ferreira - ',
                url: 'http://ec1.yesstreaming.net:1770/stream'
            },
            {
                name: 'Vip-Radios.fm - Radio Quisqueya',
                currentSong: 'On Air: Radio Quisqueya - El Alma De La Musica !',
                url: 'http://radio3.vip-radios.fm:8000/stream-128k-SJTampa-Bay_autodj'
            },
            {
                name: 'UbuntuFM Latin Radio',
                currentSong: 'On Air: Anthony Lazaro | Waiting',
                url: 'http://streaming.coollective.nl:8443/UbuntuFMlatin'
            },
            {
                name: 'Radio Bizou Fm',
                currentSong: 'On Air: Radio Bizou Fm: Greg-So-Mizajou',
                url: 'http://ec3.yesstreaming.net:1450/stream'
            },
            {
                name: 'FONYE Dance',
                currentSong: 'On Air: Stevie Wonder - All I Do Cleptomaniacs Remix',
                url: 'http://puma.streemlion.com:4180/stream'
            },
            {
                name: 'TOP EsLa Radio Spain :: Señal Respaldo Centro Emisor',
                currentSong: 'On Air: DATZY - Fusion (Radio Edit)',
                url: 'http://topradio.uno:8066/stream'
            },
            {
                name: 'Fiesta Mix Radio',
                currentSong: 'On Air: La Adictiva Banda San José de Mesillas, Luis R Conriquez - JGL',
                url: 'http://c15.radioboss.fm:8566/autodj'
            },
            {
                name: 'Radio La Roca, Internacional',
                currentSong: 'On Air: ',
                url: 'http://cloud.cmcred.com:8034/stream'
            },
            {
                name: 'Radio Salsa4te',
                currentSong: 'On Air: Guayacan - Mi Muchachita',
                url: 'http://radiomusic.newradio.it:80/salsa4te-mob'
            },
            {
                name: 'Radio WoW Latin',
                currentSong: 'On Air: Tirso Duarte Ft Tuya - Cubano',
                url: 'http://ice10.fluidstream.net:8080/rwow_latin.mp3'
            },
            {
                name: 'Radio Mix de El Salvador',
                currentSong: 'On Air: Varios  - bachata clasica mix dj vins  ritmos variados ruta 279b vol 1  mmr',
                url: 'http://tuneinradiofm.com:8000/radiomixelsalvadorlive'
            },
            {
                name: 'HQExitos24',
                currentSong: 'On Air: Fuego - Una Vaina Loca Base Live ( Intro Dj El Original )',
                url: 'http://173.68.71.90:8000/HQExitos24-2'
            },
            {
                name: 'Cupido Stereo USA (((Musica Romantica)))',
                currentSong: 'On Air: Reik - Te fuiste de aqui',
                url: 'http://s6.voscast.com:9536/stream'
            },
            {
                name: 'HQExitos24',
                currentSong: 'On Air: Fuego - Una Vaina Loca Base Live ( Intro Dj El Original )',
                url: 'http://173.68.71.90:8000/HQExitos24'
            }
        ];
    },
    get ClassicalData() {
        return [
            {
                name: 'Public Domain Classical',
                currentSong: 'On Air: Antonio Vivaldi - RV 454 Concerto in D minor, III Allegro',
                url: 'http://relay.publicdomainradio.org:80/classical.mp3'
            },
            {
                name: 'Klassikaraadio',
                currentSong: 'On Air: Sven Grünberg - "Ball" filmist "Hukkunud alpinisti hotell" - Sven Grünberg',
                url: 'http://icecast.err.ee:80/klassikaraadio.mp3'
            },
            {
                name: 'Breeze',
                currentSong: 'On Air: Mannheim Steamroller - Going To Another Place',
                url: 'http://streams.radiomast.io/a2dd31a2-a524-48ce-baea-8271e1a37ab2'
            },
            {
                name: 'Splash Classical',
                currentSong: 'On Air: Paolo Ghidoni - Violin Sonata No. 2 in A major, Op. 100 - 2. Andante tranquillo - Vivace - Andante',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/2208_128.mp3'
            },
            {
                name: 'Classical FM Radio',
                currentSong: 'On Air: Béla Fleck, Mike Marshall & Edgar Meyer - In the Garden',
                url: 'http://cheetah.streemlion.com:2460/stream'
            },
            {
                name: 'Splash Classical',
                currentSong: 'On Air: Paolo Ghidoni - Violin Sonata No. 2 in A major, Op. 100 - 2. Andante tranquillo - Vivace - Andante',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/2208_128.mp3'
            },
            {
                name: 'Splash Classical',
                currentSong: 'On Air: Paolo Ghidoni - Violin Sonata No. 2 in A major, Op. 100 - 2. Andante tranquillo - Vivace - Andante',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/2208_128.mp3'
            },
            {
                name: 'KISS Classical',
                currentSong: 'On Air: WAGNER',
                url: 'http://cast1.torontocast.com:2080/stream'
            },
            {
                name: 'Classical 90.7, KVNO Mobile',
                currentSong: 'On Air: Grofe, Ferde - Grand Canyon Suite - On the Trail',
                url: 'http://kvnovm-hd1.unomaha.edu:8000/mobile.aac'
            },
            {
                name: 'Public Domain Classical',
                currentSong: 'On Air: Antonio Vivaldi - RV 454 Concerto in D minor, III Allegro',
                url: 'http://relay.publicdomainradio.org:80/classical.aac'
            },
            {
                name: 'Classical 90.7, KVNO',
                currentSong: 'On Air: Grofe, Ferde - Grand Canyon Suite - On the Trail',
                url: 'http://kvnovm-hd1.unomaha.edu:8000/listen.aac'
            },
            {
                name: 'HearMe - Very Best of Classical Music',
                currentSong: 'On Air: ',
                url: 'http://hearme.fm:8021/stream'
            },
            {
                name: 'Naim Classical',
                currentSong: 'On Air: Vermeer Quartet - Quatuor pour la fin du temps, for violin, cello, clarinet & piano, I/22~7. Cluster Of Rainbow, For The Angel Who Announces The End Of Time',
                url: 'http://mscp3.live-streams.nl:8250/class-high.aac'
            },
            {
                name: 'Naim Classical',
                currentSong: 'On Air: ',
                url: 'http://mscp3.live-streams.nl:8250/class-flac.flac'
            },
            {
                name: 'FM/HD1',
                currentSong: 'On Air: Listener-Supported Public Radio  - For Thoughtful People - Like You!',
                url: 'http://streams.radiomast.io/5567306a-66f6-4d8f-a399-520e2936e3a0'
            },
            {
                name: 'Classical Radio International',
                currentSong: 'On Air: AutoDJ: Kayser Medienverlag - Handel - Music for the Royal Fireworks',
                url: 'http://ec3.yesstreaming.net:3620/stream'
            },
            {
                name: 'Mother Earth Klassik',
                currentSong: 'On Air: Christian Ferras Berliner Philharmoniker Herbert von Karajan - Beethoven Konzert für Violine und Orchester in D Dur',
                url: 'https://motherearth.streamserver24.com/listen/motherearth_klassik/motherearth.klassik.mp3'
            },
            {
                name: 'HearMe - Very Best of Classical Music',
                currentSong: 'On Air: ',
                url: 'http://hearme.fm:8106/stream'
            },
            {
                name: 'Radio Clasica - 103.3 FM - El Salvador',
                currentSong: 'On Air: IDENT_GENERICA_3',
                url: 'http://streaming.mundoclasicaupa.com:8000/radioclasica'
            },
            {
                name: '24/7 Classical Radio',
                currentSong: 'On Air: AutoDJ: Stewart Dugdale - Lost and Lonely Souls',
                url: 'http://ec3.yesstreaming.net:3610/stream'
            },
            {
                name: 'HearMe - Beethoven',
                currentSong: 'On Air: ',
                url: 'http://hearme.fm:10003/stream'
            },
            {
                name: 'HearMe - Classical Cello',
                currentSong: 'On Air: ',
                url: 'http://hearme.fm:10004/stream'
            },
            {
                name: 'Classically',
                currentSong: 'On Air: The King\'s Singers - The Ash Grove',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1485_128'
            },
            {
                name: 'HearMe - Classical Violin',
                currentSong: 'On Air: ',
                url: 'http://hearme.fm:10007/stream'
            },
            {
                name: 'NAGA FM',
                currentSong: 'On Air: Naga FM',
                url: 'http://rdopanel.cobrasoft.org:1060/stream'
            },
            {
                name: 'VCR Live | Venice Classic Radio Italia',
                currentSong: 'On Air: Muzio Clementi (1752-1832) - Sinfonia in re Maggiore No.2 (23:14) (The Philharmonia - Francesco D\'Avalos, direttore)  { info: veniceclassicradio.eu}',
                url: 'http://vcr2gra.ondastreaming.eu:80/stream1'
            },
            {
                name: 'WZQR.FM Concert Hall',
                currentSong: 'On Air: Eva Knardahl - Lyric Pieces Book 8, Op. 65: VI. Bryllupsdag på Troldhaugen (Wedding Day at Troldhaugen)',
                url: 'http://c17.radioboss.fm:8476/autodj'
            },
            {
                name: 'Precious Radio Dream',
                currentSong: 'On Air: Bert Kaempfert - Tom Hark',
                url: 'http://preciousradio.net:8028/autodj'
            },
            {
                name: 'Metro Virtuoso Radio HD - By Metro Cast Stations',
                currentSong: 'On Air: Angeles String Quartet - 12 String Quartet in C major, Op. 76, No. 3 \u2018Emperor\u2019 \u2013 IV. Finale. Presto',
                url: 'http://eu1.reliastream.com:7092/MVR'
            },
            {
                name: 'Mother Earth Klassik',
                currentSong: 'On Air: Christian Ferras Berliner Philharmoniker Herbert von Karajan - Beethoven Konzert für Violine und Orchester in D Dur',
                url: 'https://motherearth.streamserver24.com/listen/motherearth_klassik/motherearth.klassik.aac-lo'
            }
        ];
    },
    get JazzData() {
        return [
            {
                name: 'JAZZGROOVE.org - Mix #2 (128k)',
                currentSong: 'On Air: Paul Desmond - Samba With Some Barbecue (Album Version)',
                url: 'http://streams.radiomast.io/8a384ff3-6fd1-4e5d-b47d-0cbefeffe8d7'
            },
            {
                name: 'Jazz Cafe',
                currentSong: 'On Air: Debbie Davis - Never Back to Blue',
                url: 'https://radio.wanderingsheep.net:8000/jazzcafe'
            },
            {
                name: 'JAZZGROOVE.org - Mix #2 (64k)',
                currentSong: 'On Air: Paul Desmond - Samba With Some Barbecue (Album Version)',
                url: 'http://streams.radiomast.io/ae0b58a2-0a97-484e-8f75-ef32ff194325'
            },
            {
                name: 'Costa Del Mar - Smooth Sax',
                currentSong: 'On Air: Brian Tarquin - Katchina',
                url: 'http://radio4.cdm-radio.com:8024/stream-mp3-Smooth_autodj'
            },
            {
                name: '101 SMOOTH JAZZ WEST',
                currentSong: 'On Air: Christophe Goze - The Nightfly (2022) ',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/2329_128.mp3'
            },
            {
                name: '101 SMOOTH JAZZ WEST',
                currentSong: 'On Air: Christophe Goze - The Nightfly (2022) ',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/2329_128.mp3'
            },
            {
                name: 'UrbanRadio Smooth Jazz',
                currentSong: 'On Air: Bryson Tiller - Don\'t ',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1541_128'
            },
            {
                name: 'JAZZGROOVE.org - Mix #1 (128k)',
                currentSong: 'On Air: Johnny Hodges and His Orchestra - I Didn\'t Know About You',
                url: 'http://streams.radiomast.io/f0ac4bf3-bbe5-4edb-b828-193e0fdc4f2f'
            },
            {
                name: '101 SMOOTH JAZZ WEST',
                currentSong: 'On Air: Christophe Goze - The Nightfly (2022) ',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/2329_128.mp3'
            },
            {
                name: 'RadioSkyMusic Jazz',
                currentSong: 'On Air: Marco Marconi Trio - I Mean You (Composer Thelonious Monk)',
                url: 'http://eu.publicssl.net:7006/live'
            },
            {
                name: 'SMOOTH JAZZ 247 WEST',
                currentSong: 'On Air: Nils - Coast To Coast ',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/2445_128.mp3'
            },
            {
                name: 'SMOOTH JAZZ 247 WEST',
                currentSong: 'On Air: Nils - Coast To Coast ',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/2445_128.mp3'
            },
            {
                name: 'Public Domain Jazz',
                currentSong: 'On Air: Billy Eckstine - Tenderly',
                url: 'http://relay.publicdomainradio.org:80/jazz_swing.mp3'
            },
            {
                name: 'JAZZGROOVE.org - Mix #1 (64k)',
                currentSong: 'On Air: Johnny Hodges and His Orchestra - I Didn\'t Know About You',
                url: 'http://streams.radiomast.io/700d62fe-dcc8-4171-a430-0f0393320b3d'
            },
            {
                name: 'Bay Smooth Jazz',
                currentSong: 'On Air: Steve Oliver - Highway One',
                url: 'http://radio2.vip-radios.fm:8039/stream-192kmp3-BaySmoothJazz_autodj'
            },
            {
                name: '1radio.mk - The Wave Smooth Jazz (Smoothjazztampabay.com)',
                currentSong: 'On Air: Acoustic Alchemy - Break For The Border ',
                url: 'http://ais-edge66-ams02.cdnstream.com:80/1radio_smoothjazz_128'
            },
            {
                name: 'WUCF',
                currentSong: 'On Air: Sleepers Wake, BY Bill Cunliffe and Denise Donatelli, FROM THE BACHanalia ALBUM, IS NOW PLAYING',
                url: 'http://peridot.streamguys.com:7830/WUCF'
            },
            {
                name: 'Raadio Tallinn',
                currentSong: 'On Air: UUDISED',
                url: 'http://icecast.err.ee:80/raadiotallinn.mp3'
            },
            {
                name: 'Breeze',
                currentSong: 'On Air: R. Carlos Nakai - Gourd Harvest Song',
                url: 'http://streams.radiomast.io/a2dd31a2-a524-48ce-baea-8271e1a37ab2'
            },
            {
                name: 'Lovely Instrumentals',
                currentSong: 'On Air: Jack Jezzro - They All Laughed ',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/2459_128.mp3'
            },
            {
                name: 'Smooth Jazz Mix New York',
                currentSong: 'On Air: Alexander Zonjic - Living in the Past ',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1078_128'
            },
            {
                name: 'Lovely Instrumentals',
                currentSong: 'On Air: Jack Jezzro - They All Laughed ',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/2459_128.mp3'
            },
            {
                name: 'Radio München',
                currentSong: 'On Air: Michaela Dietl - I love the sea ',
                url: 'http://stream.radiomuenchen.net:8000/rm256.mp3'
            },
            {
                name: 'WUCF-HD2',
                currentSong: 'On Air: Flying South by Pete Escovedo',
                url: 'http://peridot.streamguys.com:7830/WUCF-HD2'
            },
            {
                name: '.113FM The Wave',
                currentSong: 'On Air: Start of Advert:',
                url: 'http://ais-edge88-113fm-bhs07.cdnstream.com:80/1725_128'
            },
            {
                name: '.113FM Jazzy!',
                currentSong: 'On Air: Alfonso Gugliucci - Autumn in New York',
                url: 'http://ais-edge88-113fm-bhs07.cdnstream.com:80/1815_128'
            },
            {
                name: 'Lovely Instrumentals',
                currentSong: 'On Air: Jack Jezzro - They All Laughed ',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/2459_128.mp3'
            },
            {
                name: 'Smooth Jazz CD101.9 New York',
                currentSong: 'On Air: Basia - More Fire Than Flame ',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1277_192'
            },
            {
                name: 'Smooth Soul',
                currentSong: 'On Air: The Chi Lites - Have You Seen Her',
                url: 'https://radio.wanderingsheep.net:8010/smoothsoul'
            },
            {
                name: '1radio.mk - The Wave Smooth Jazz (Smoothjazztampabay.com)',
                currentSong: 'On Air: Acoustic Alchemy - Break For The Border ',
                url: 'http://ais-edge66-ams02.cdnstream.com:80/1radio_smoothjazz_64'
            }
        ];
    },
    get BluesData() {
        return [
            {
                name: 'Grolloo Radio',
                currentSong: 'On Air: Albert Castiglia - Quit Your Bitching',
                url: 'http://uk1.streamingpulse.com:7053/live'
            },
            {
                name: 'Свободное радио - Svobodnoe FM',
                currentSong: 'On Air: Nastya Zelenskaya - Я выбираю верить (feat. Pasha Babych)',
                url: 'http://nradio.net:8080/free'
            },
            {
                name: 'BluesMusicFan Radio',
                currentSong: 'On Air: Popa Chubby - Shakedown',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/1992_128.mp3'
            },
            {
                name: 'BluesMusicFan Radio',
                currentSong: 'On Air: Popa Chubby - Shakedown',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/1992_128.mp3'
            },
            {
                name: 'Radio Bluesflac',
                currentSong: 'On Air: Danielle Nicole - Make Love',
                url: 'http://streams.radiomast.io/radioblues-flac'
            },
            {
                name: 'American Road Radio',
                currentSong: 'On Air: Jeff Healey Band - Daze of the night - House on Fire Demos and Rarities - Blues Rock',
                url: 'http://c5.radioboss.fm:8224/autodj'
            },
            {
                name: 'BluesMusicFan Radio',
                currentSong: 'On Air: Popa Chubby - Shakedown',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/1992_128.mp3'
            },
            {
                name: 'BluesMusicFan Radio',
                currentSong: 'On Air: Popa Chubby - Shakedown',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/1992_64.aac'
            },
            {
                name: 'BluesMusicFan Radio',
                currentSong: 'On Air: Popa Chubby - Shakedown',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/1992_64.aac'
            },
            {
                name: 'BluesMusicFan Radio',
                currentSong: 'On Air: Popa Chubby - Shakedown',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/1992_64.aac'
            },
            {
                name: 'JB Radio',
                currentSong: 'On Air: ',
                url: 'http://maggie.torontocast.com:18076/flac'
            },
            {
                name: 'Rock Now Radio',
                currentSong: 'On Air: Blue Cheer - Doctor Please',
                url: 'http://s1.rocknowradio.ro:8000/airtime_128'
            },
            {
                name: 'KRDP Jazz',
                currentSong: 'On Air:  - Tom Coulson H1 (01-Mon) - Single',
                url: 'http://cp10.shoutcheap.com:8367/krdp_jazz'
            },
            {
                name: 'The Phoenix Radio',
                currentSong: 'On Air: Samantha Fish Featuring Lille Mae - Nearing Home',
                url: 'http://hello.citrus3.com:8160/stream'
            },
            {
                name: 'JAZZ TUNE RADIO ',
                currentSong: 'On Air: Guitar Shorty - I Want to Report a Crime',
                url: 'http://c30.radioboss.fm:8119/autodj'
            },
            {
                name: 'YoungBlood Radio',
                currentSong: 'On Air: Jessie Hill - Ooh Poo Pah Doo (Part 2)',
                url: 'http://c15.radioboss.fm:8556/autodj'
            },
            {
                name: 'Bonkkenks Nostalgic Music',
                currentSong: 'On Air: Bee Gees - Lamp Light - NOSTALGIC HITS ',
                url: 'http://45.32.103.238:8023/live'
            },
            {
                name: 'JZ 94.5',
                currentSong: 'On Air: ',
                url: 'http://media.streambrothers.com:18402/stream'
            },
            {
                name: 'YouRadio.nl',
                currentSong: 'On Air: Recoil - Jezebel',
                url: 'https://streaming.youradio.nl/listen/youradio/stream'
            },
            {
                name: 'Свободное радио - Svobodnoe FM - HiFi',
                currentSong: 'On Air: Nastya Zelenskaya - Я выбираю верить (feat. Pasha Babych)',
                url: 'http://nradio.net:8080/freemp3'
            },
            {
                name: 'HearMe - Blues Rock',
                currentSong: 'On Air: ',
                url: 'http://hearme.fm:8649/stream'
            },
            {
                name: '24/7 Blues Radio',
                currentSong: 'On Air: AutoDJ: Stewart Dugdale - Nurtured',
                url: 'http://ec3.yesstreaming.net:3680/stream'
            },
            {
                name: '.113FM Blues Town',
                currentSong: 'On Air: Eric Clapton - Can\'t Let You Do It',
                url: 'http://ais-edge87-113fm-bhs06.cdnstream.com:80/1816_128'
            },
            {
                name: 'Second Shadow of The Yellow Submarine I',
                currentSong: 'On Air: Brasil 690 - Don\'t Speak (Bossa Version)',
                url: 'http://radio.rikt.ru:8000/ys-radio'
            },
            {
                name: 'BCC ROCK 2 ',
                currentSong: 'On Air: RUSTY YOUNG - LOVE IS BLINDNESS  (V2023) - Single ',
                url: 'http://radio10.pro-fhi.net:9040/rockabilly96.mp3'
            },
            {
                name: 'Radio Free Amsterdam 24/7',
                currentSong: 'On Air: John Sinclair - RFA JSRS Closing TAG',
                url: 'http://s2.voscast.com:12578/stream'
            },
            {
                name: 'JB Radio',
                currentSong: 'On Air: ',
                url: 'http://m23580.contaboserver.net:8889/flac'
            },
            {
                name: 'The Contemporary Blues Place',
                currentSong: 'On Air: The Blues Brothers - From The Bottom - Made In America',
                url: 'http://login.webinternetradio.com:1080/stream'
            },
            {
                name: 'BayShore Radio Network',
                currentSong: 'On Air: Tom Scott/Jonathan Butler - Holding Back The Years',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/1700_128'
            },
            {
                name: 'BluesWave Radio',
                currentSong: 'On Air: Sonny Terry & Brownie McGhee - Bring It On Home To Me',
                url: 'http://blueswave.radio:8050/hifiblues'
            }
        ];
    },
    get IndieData() {
        return [
            {
                name: 'Radio Free Americana',
                currentSong: 'On Air: Lost Planet Airmen - Wine Do Yer Stuff',
                url: 'http://thassos.cdnstream.com:5479/live'
            },
            {
                name: 'plusfm - Electro Pop TripHop Radio - www.plusfm.net',
                currentSong: 'On Air: sir Was - Give Me A New Role',
                url: 'http://radio7.pro-fhi.net:9004/1'
            },
            {
                name: 'Le Son Parisien [Paris, France]',
                currentSong: 'On Air: James Figurine - Apologies (2006)',
                url: 'http://stream.lesonparisien.com:80/hi'
            },
            {
                name: 'QCIndie.com',
                currentSong: 'On Air: Pale Waves - Clean',
                url: 'http://stream.qcindie.com:80/live'
            },
            {
                name: 'Nakypilo Radio',
                currentSong: 'On Air: Komisiia - Дорога',
                url: 'http://fra-pioneer08.dedicateware.com:1630/stream'
            },
            {
                name: 'Lithuania | Radijo stotis "SOL FM"',
                currentSong: 'On Air: Obsimo & Hector Gachan - Seito',
                url: 'http://radiosolfm.bounceme.net:8002/solfm'
            },
            {
                name: 'Big Indie Giant Radio',
                currentSong: 'On Air: Dieselle May - Sweeter',
                url: 'http://puma.streemlion.com:1950/stream'
            },
            {
                name: 'Stony Radio',
                currentSong: 'On Air:  - The Jazz Therapist with David Lloyd ',
                url: 'http://carina.streamerr.co:8072/stream'
            },
            {
                name: 'Teerex Radio teerex',
                currentSong: 'On Air: Moonchild - Cure',
                url: 'http://janus.cdnstream.com:5173/live'
            },
            {
                name: 'RADIO FLYWEB',
                currentSong: 'On Air: FUCKSIA - CONSENSE',
                url: 'http://nrf1.newradio.it:9930/stream'
            },
            {
                name: 'Radiominor.ru - Russian Rock Channel',
                currentSong: 'On Air: Максим Свобода - Динамики 3.0',
                url: 'http://radiominor.ru:8000/radiominor_ru_rurock.mp3'
            },
            {
                name: 'Le Son Parisien [Paris, France]',
                currentSong: 'On Air: James Figurine - Apologies (2006)',
                url: 'http://stream.lesonparisien.com:80/hi.aac'
            },
            {
                name: 'RadioBue.it',
                currentSong: 'On Air: Bang Gang - My Special One',
                url: 'http://nrf1.newradio.it:10384/stream'
            },
            {
                name: 'Barfly Radio',
                currentSong: 'On Air: Lebanon Hanover - True Romantics [ Let Them Be Alien ]',
                url: 'http://ec2.yesstreaming.net:3350/stream'
            },
            {
                name: 'Nakypilo Radio',
                currentSong: 'On Air: Komisiia - Дорога',
                url: 'http://fra-pioneer08.dedicateware.com:1680/stream'
            },
            {
                name: 'KOBV-LP Bentonville Community Radio',
                currentSong: 'On Air: Perila - On A Roof ',
                url: 'http://s2.stationplaylist.com:7058/listen.aac'
            },
            {
                name: 'BigNoise - music from Siberia',
                currentSong: 'On Air: GODY.CULT - Signature: Blue',
                url: 'http://radio.bignoise.club:8000/nonstop'
            },
            {
                name: 'googeradio.com',
                currentSong: 'On Air: Jule Grasz - Sun Flares ',
                url: 'http://googeradio.dyndns-free.com:8000/listen'
            },
            {
                name: 'Le Son Parisien [Paris, France]',
                currentSong: 'On Air: ',
                url: 'http://stream.lesonparisien.com:80/live.flac'
            },
            {
                name: 'KCYP-LP - The City 97.7FM',
                currentSong: 'On Air: ',
                url: 'http://stream.thecity977.com:8000/KCYP-LP_source'
            },
            {
                name: 'HotWaxRadio.com 320k @HitIndieMusic',
                currentSong: 'On Air: We Are The Catalyst - The Awakening',
                url: 'http://stream.abyss-shoutcast.com:5236/stream'
            },
            {
                name: 'TalentCast - Independent music radio - AM 1485 kHz',
                currentSong: 'On Air: Mary Confurius - Have A Heart',
                url: 'http://talentcast.nl:8443/stream'
            },
            {
                name: '1000 Indie',
                currentSong: 'On Air: Depeche Mode - Never Let Me Down Again  (Javier Penna Remix)',
                url: 'http://1000indie.stream.laut.fm/1000indie'
            },
            {
                name: 'Click Your Radio - Classic Rock &amp; Blues',
                currentSong: 'On Air: Pink Cream 69 - Do You Like It Like That',
                url: 'http://kathy.torontocast.com:3840/stream'
            },
            {
                name: 'Radiominor.ru - Indie Rock Channel',
                currentSong: 'On Air: Deal Casino - Best Year',
                url: 'http://radiominor.ru:8000/radiominor_ru_indie.mp3'
            },
            {
                name: 'EdgeRadio',
                currentSong: 'On Air: ARTIST=BELL X1^TITLE=The End Is Nigh^ALBUM=Chop Chop^YEAR=2013 ',
                url: 'http://s2.stationplaylist.com:7114/listen.mp3'
            },
            {
                name: 'Paris Obscur',
                currentSong: 'On Air: Paris Obscur - Lonely',
                url: 'http://rocket.streamradio.fr:8190/stream'
            },
            {
                name: 'SPINS',
                currentSong: 'On Air: Cynthia Smith - Reciprocity',
                url: 'http://radioairplay.fr:1170/stream'
            },
            {
                name: '107dot5',
                currentSong: 'On Air: Fiona Apple - Criminal',
                url: 'https://www.tuneintoradio1.com/listen/107dot5/radio.mp3'
            },
            {
                name: '.113FM Indie Nation',
                currentSong: 'On Air: Start of Advert:',
                url: 'http://ais-edge87-113fm-bhs06.cdnstream.com:80/1814_128'
            }
        ];
    },
    get AlternativeData() {
        return [
            {
                name: 'Radio Afera 98,6 MHz',
                currentSong: 'On Air: THE VACCINES - IF YOU WANNA',
                url: 'http://radio.afera.com.pl:80/afera128.mp3'
            },
            {
                name: 'La Grosse Radio Rock Alternative - Pop Hits Legends Indie - From Paris - www.lagrosseradio.com',
                currentSong: 'On Air: Pop Crimes - No More Cryin\'',
                url: 'http://hd.lagrosseradio.info:8000/lagrosseradio-rock-192.mp3'
            },
            {
                name: 'New Wave Radio - The Original 80\'s Music Station',
                currentSong: 'On Air: Elton John - I\'m Still Standing ***  80\'s New Wave Radio  ***  NewWaveRadio.org',
                url: 'http://puma.streemlion.com:2910/stream'
            },
            {
                name: 'Guerrilla Radio',
                currentSong: 'On Air: Howlin\' Wolf - Do The Do (feat. Eric Clapton, Steve Winwood, Bill Wyman, Charlie Watts & Hubert Sumlin) - Muddy & The Wolf ',
                url: 'http://s2.stationplaylist.com:9460/guerrilla'
            },
            {
                name: 'AudioVision: AlternativeRadio.us - Radio For The Rest Of Us',
                currentSong: 'On Air: Nirvana - Come As You Are',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/alt64k'
            },
            {
                name: 'JPopsuki Radio!',
                currentSong: 'On Air: ayame - Lumiere Ambree (Refix)',
                url: 'http://jpopsuki.fm:8000/autodj'
            },
            {
                name: 'WLIR.FM',
                currentSong: 'On Air: Robert Palmer - Simply Irresistible',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1552_128'
            },
            {
                name: 'Le Son Parisien [Paris, France]',
                currentSong: 'On Air: Emmanuelle - Free Hifi Internet (2015)',
                url: 'http://stream.lesonparisien.com:80/hi'
            },
            {
                name: 'Radio Radieschen',
                currentSong: 'On Air: MIDNIGHT OIL  - RISING SEAS',
                url: 'http://stream01.kapper.net:8005/njoyradio-hd'
            },
            {
                name: 'THE BLAST Christian Rock Hi Fi @128 kbps',
                currentSong: 'On Air: Angel Machine - Repent',
                url: 'http://theblast-stream.theblast.fm.fastserv.com:80/128'
            },
            {
                name: '.113FM Alt-X',
                currentSong: 'On Air: George Michael & Elton John - Don\'t Let the Sun Go Down On Me (Duet with Elton John)',
                url: 'http://ais-edge88-113fm-bhs07.cdnstream.com:80/1740_128'
            },
            {
                name: 'Radio Seagull',
                currentSong: 'On Air: EM-2nd-26Feb24.mp3 - Eddy Mann',
                url: 'http://nlned.com:8000/seagull'
            },
            {
                name: 'Radio Stadtfilter 96.3Mhz Studio  41 52 203 31 00 studio1 at stadtfilter.ch',
                currentSong: 'On Air: The Knife - Neverland',
                url: 'http://streamer1.stadtfilter.net:8406/stadtfilter.mp3'
            },
            {
                name: 'Punkrockers Radio',
                currentSong: 'On Air: Riskee & The Ridicule - God Tier',
                url: 'http://stream.punkrockers-radio.de:8000/prr.mp3'
            },
            {
                name: 'Radio Radieschen',
                currentSong: 'On Air: MIDNIGHT OIL  - RISING SEAS',
                url: 'http://stream01.kapper.net:8005/radioradieschen'
            },
            {
                name: 'Urgent FM',
                currentSong: 'On Air: ',
                url: 'http://urgentstream.radiostudio.be:8000/aac'
            },
            {
                name: 'Urgent FM',
                currentSong: 'On Air: ',
                url: 'http://urgentstream.radiostudio.be:8000/live'
            },
            {
                name: '100 XR',
                currentSong: 'On Air: Fall Out Boy - So Much (For) Stardust |from: So Much (For) Stardust (2023)',
                url: 'http://xr.dockl.com:80/stream'
            },
            {
                name: 'Punkrockers Radio',
                currentSong: 'On Air: Riskee & The Ridicule - God Tier',
                url: 'http://stream.punkrockers-radio.de:8000/prr.ogg'
            },
            {
                name: 'AltRadio 128',
                currentSong: 'On Air: Gary Clark Jr. - Numb',
                url: 'http://stationaltradio.whro.org:8000/128'
            },
            {
                name: 'Radio Summernight',
                currentSong: 'On Air: 24kGoldn - Good Intentions (Official Video)',
                url: 'http://stream.laut.fm/radiosummernight'
            },
            {
                name: 'Graffiti Urban Radio',
                currentSong: 'On Air: JONAS  -  Bombe d\'eau',
                url: 'http://diffusion.lafrap.fr:8000/graffiti'
            },
            {
                name: 'Simulcast',
                currentSong: 'On Air: [IR] Bantum - Gully',
                url: 'http://streams.radiomast.io/89e24041-fdab-4b2d-95bd-830f5bfda900'
            },
            {
                name: 'POWERHITZ.COM - The Planet - The New Rock Alternative',
                currentSong: 'On Air: 24KGoldn - Mood (Ft Iann Dior) ',
                url: 'http://ais-edge83-jbmedia-nyc04.cdnstream.com:80/planet'
            },
            {
                name: 'Graffiti Urban Radio',
                currentSong: 'On Air: JONAS  -  Bombe d\'eau',
                url: 'http://diffusion.lafrap.fr:8000/graffiti.mp3'
            },
            {
                name: 'L\'UniCo Campusradio Paderborn',
                currentSong: 'On Air: Pöbel MC - Rollkragenschläger',
                url: 'http://icecast.l-uni.co:8001/lunico_high_mp3'
            },
            {
                name: 'Radio UNiCC - einzig, nicht artig ...  - www.radio-unicc.de',
                currentSong: 'On Air: Thee Attacks - Love In The City',
                url: 'http://stream.radio-unicc.de:8000/unicc_hq.mp3'
            },
            {
                name: 'Lithuania | Radijo stotis "SOL FM"',
                currentSong: 'On Air: Stephen Steinbrink - Cruiser',
                url: 'http://radiosolfm.bounceme.net:8002/solfm'
            },
            {
                name: 'RadioStadtfilter MP3',
                currentSong: 'On Air: The Knife - Neverland',
                url: 'http://streamer3.stadtfilter.net:8406/stadtfilter.mp3'
            },
            {
                name: 'OOo EKO DES GARRIGUES oOO Live from Montpellier [f] [256] [ogg]',
                currentSong: 'On Air: ',
                url: 'http://91.121.159.124:8000/eko-des-garrigues-256k.ogg'
            }
        ];
    },
    get MetalData() {
        return [
            {
                name: 'Tangra Mega Rock',
                currentSong: 'On Air: TANGRA - MEGA ROCK',
                url: 'http://stream-bg-01.radiotangra.com:8000/Tangra-high'
            },
            {
                name: 'METAL SHOP',
                currentSong: 'On Air: Iron Maiden - Infinite Dreams (88)',
                url: 'http://quincy.torontocast.com:1500/stream'
            },
            {
                name: 'La Grosse Radio Metal - Hard Heavy - From Paris - www.LaGrosseRadio.com',
                currentSong: 'On Air: Witch Ripper - Enter The Loop',
                url: 'http://hd.lagrosseradio.info:8000/lagrosseradio-metal-192.mp3'
            },
            {
                name: 'Metalzone.GR Radio',
                currentSong: 'On Air: Ascension - Reflected Life',
                url: 'http://lofos.win:28282/stream'
            },
            {
                name: 'Epic Rock Radio',
                currentSong: 'On Air: Pathosray - In Your Arms',
                url: 'http://radio.streemlion.com:4200/stream'
            },
            {
                name: 'Guerrilla Radio',
                currentSong: 'On Air: Chicano Batman - Pastel Sunrise - Dark Star b/w Pastel Sunrise - Single ',
                url: 'http://s2.stationplaylist.com:9460/guerrilla'
            },
            {
                name: 'Crucial Velocity Radio',
                currentSong: 'On Air: Strapping Young Lad - You Suck ',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/1369_128'
            },
            {
                name: 'THE BLAST Christian Rock Hi Fi @128 kbps',
                currentSong: 'On Air: Disciple - Bad Words',
                url: 'http://theblast-stream.theblast.fm.fastserv.com:80/128'
            },
            {
                name: 'Crucial Velocity Radio',
                currentSong: 'On Air: Strapping Young Lad - You Suck ',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/1369_128'
            },
            {
                name: 'Metal Heart Radio',
                currentSong: 'On Air: King Diamond - Give Me Your Soul',
                url: 'http://fr.radio-streamhosting.com:8000/metalheartradio64aac'
            },
            {
                name: 'Metal Heart Radio',
                currentSong: 'On Air: King Diamond - Give Me Your Soul',
                url: 'http://fr.radio-streamhosting.com:8000/metalheartradio128mp3'
            },
            {
                name: 'Crucial Velocity Radio',
                currentSong: 'On Air: Strapping Young Lad - You Suck ',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/1369_128'
            },
            {
                name: 'SUN FM Rock',
                currentSong: 'On Air: Rod Stewart - It\'s A Heartache',
                url: 'http://31.24.228.41:3650/stream'
            },
            {
                name: 'Metal Invasion Radio',
                currentSong: 'On Air: THE UNGUIDED - Iceheart Fragment (Re-Imagined)',
                url: 'https://radio.metal-invasion.fr/radio/8000/stream96'
            },
            {
                name: 'Violent Forces Radio: General Thrash',
                currentSong: 'On Air: Pandemic - Destined For The Gutter',
                url: 'https://www.tuneintoradio1.com/listen/violent_forces_radio/radio.mp3'
            },
            {
                name: 'La Grosse Radio Metal - Hard Heavy - From Paris - www.LaGrosseRadio.com',
                currentSong: 'On Air: Witch Ripper - Enter The Loop',
                url: 'http://hd.lagrosseradio.info:8000/lagrosseradio-metal-024.mp3'
            },
            {
                name: 'Metal Invasion Radio',
                currentSong: 'On Air: THE UNGUIDED - Iceheart Fragment (Re-Imagined)',
                url: 'https://radio.metal-invasion.fr/radio/8000/stream.mp3'
            },
            {
                name: 'Metal Devastation Radio',
                currentSong: 'On Air: Exodus - Slipping Into Madness',
                url: 'http://c13.radioboss.fm:8099/autodj'
            },
            {
                name: '100 XR',
                currentSong: 'On Air: Dayseeker - Dreamstate |from: Dark Sun (2022)',
                url: 'http://xr.dockl.com:80/stream'
            },
            {
                name: 'TotalRock Livestream',
                currentSong: 'On Air: TotalRock - The True Voice Of Rock & Metal since 2000',
                url: 'http://s3.citrus3.com:8056/stream'
            },
            {
                name: 'Tangra Mega Rock',
                currentSong: 'On Air: Unknown',
                url: 'http://stream-bg-01.radiotangra.com:8000/Tangra.ogg'
            },
            {
                name: 'Megarock Radio - All Request Rock',
                currentSong: 'On Air: Evanescence - Made of Stone',
                url: 'http://stream1.megarockradio.net:8000/stream'
            },
            {
                name: 'SUN Metal',
                currentSong: 'On Air: Fiddler\'s Green - Milk the damned cash cow (2011)',
                url: 'http://diffusion.lafrap.fr:8000/sun-metal.mp3'
            },
            {
                name: 'Rock Now Radio',
                currentSong: 'On Air: The Doors - The End',
                url: 'http://s1.rocknowradio.ro:8000/airtime_128'
            },
            {
                name: 'Metal Mixx',
                currentSong: 'On Air: Metalhead',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/1987_64.aac'
            },
            {
                name: 'Metal Mixx',
                currentSong: 'On Air: Metalhead',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/1987_64.aac'
            },
            {
                name: 'Tangra Mega Rock',
                currentSong: 'On Air: TANGRA - MEGA ROCK',
                url: 'http://stream-bg-01.radiotangra.com:8000/Tangra-middle'
            },
            {
                name: 'Violent Forces Radio: \'80s Thrash',
                currentSong: 'On Air: Whiplash - Eternal Eyes (Last Nail in the Coffin, Pt. 2)',
                url: 'https://www.tuneintoradio1.com/listen/vfr_80s/radio.mp3'
            },
            {
                name: 'THE BLASTOZOIC ERA Hi Fi Classic Christian Rock at 128 kbps',
                currentSong: 'On Air: Sixpence None The Richer - Love, Salvation, And The Fear Of Death',
                url: 'http://blastozoicera-stream.theblast.fm.fastserv.com:80/128'
            },
            {
                name: 'THE IMPLOSION Hi Fi Christian Metal/Hardcore/Metalcore  at 128 kbps',
                currentSong: 'On Air: Tourniquet - Longing for Gondwanaland',
                url: 'http://theimplosion-stream.theblast.fm.fastserv.com:80/128'
            }
        ];
    },
    get ReggaeData() {
        return [
            {
                name: 'Vibesfm.net',
                currentSong: 'On Air: Trooper',
                url: 'http://s02.whooshserver.net:9091/live.mp3'
            },
            {
                name: 'La Grosse Radio Reggae - Dub Dancehall Roots - From Paris - www.LaGrosseRadio.com',
                currentSong: 'On Air: -- IMAGE - 24h24 Sound System',
                url: 'http://hd.lagrosseradio.info:8000/lagrosseradio-reggae-192.mp3'
            },
            {
                name: 'Dakar Musique',
                currentSong: 'On Air: BABA DIALLO - NIOUKEUL',
                url: 'http://listen.senemultimedia.net:8090/stream'
            },
            {
                name: 'Reggae141.com',
                currentSong: 'On Air: Hezron - Can\'t Come Between',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1301_128'
            },
            {
                name: 'Raggakings Radio',
                currentSong: 'On Air: Slin Rockaz - 2010 Let`s Hear It Again (2011)',
                url: 'http://raggakings.radio:8888/stream.ogg'
            },
            {
                name: 'Radio Dakar City',
                currentSong: 'On Air: Baaba Maal - Tindo Quando',
                url: 'http://listen.senemultimedia.net:8000/stream'
            },
            {
                name: 'Radio Twilight draait de mooiste hitsss',
                currentSong: 'On Air: Moonlights - paradijs samoa',
                url: 'http://live.hostingbudget.nl:4270/stream'
            },
            {
                name: 'Radio Keur Massar',
                currentSong: 'On Air: OMAR PENE - Moom Tamit',
                url: 'http://listen.senemultimedia.net:8140/stream'
            },
            {
                name: 'radiobonita',
                currentSong: 'On Air: Uitblinker Sander Kwarten - Laat Me',
                url: 'http://live.hostingbudget.nl:1040/stream'
            },
            {
                name: 'Radio München',
                currentSong: 'On Air: Dis*Ka - Big Black Rainbow Over My Life ',
                url: 'http://stream.radiomuenchen.net:8000/rm256.mp3'
            },
            {
                name: 'Soul Rhythms Radio UK',
                currentSong: 'On Air: Khemistry - Who\'s Fooling You [4RjP]',
                url: 'http://uk7.internet-radio.com:8050/autodj'
            },
            {
                name: 'Jammin Vibez: Reggae Hits',
                currentSong: 'On Air: George Nooks - For You',
                url: 'https://azuracast.jammimvibez.com/listen/reggae/stream'
            },
            {
                name: 'SocaFm',
                currentSong: 'On Air: Skarpyon - Turn The Lights Down Low',
                url: 'http://cupcake.citrus3.com:8112/stream'
            },
            {
                name: 'Vintage Obscura Radio',
                currentSong: 'On Air: \'Kit Andree - Philadelphia Freedom [US, Oddball Lo-Fi Moog Soul Jazz Cover Version on Elton John song] (197x)\'',
                url: 'http://radio.vintageobscura.net:443/stream'
            },
            {
                name: 'Wicked Music For Wicked People!',
                currentSong: 'On Air: VJ Gary & The Pac To The 80s Show On www.traxfm.org - 11th August 2019',
                url: 'http://andromeda.shoutca.st:9542/autodj'
            },
            {
                name: 'Feel Jah FM',
                currentSong: 'On Air: Theme From A Summer Place - Ranny Williams-The Hippy Boys',
                url: 'http://solid9.streamupsolutions.com:8018/autodj'
            },
            {
                name: 'H24 Senegal',
                currentSong: 'On Air: Ndiagua MBAYE - Taara',
                url: 'http://listen.senemultimedia.net:8070/stream'
            },
            {
                name: 'WEST INDIAN VIBES RADIO - WIVR',
                currentSong: 'On Air: INDIAN MIX CD 1',
                url: 'http://s6.citrus3.com:8396/stream'
            },
            {
                name: 'La Grosse Radio Reggae - Dub Dancehall Roots - From Paris - www.LaGrosseRadio.com',
                currentSong: 'On Air: -- IMAGE - 24h24 Sound System',
                url: 'http://hd.lagrosseradio.info:8000/lagrosseradio-reggae-064.mp3'
            },
            {
                name: 'Belters',
                currentSong: 'On Air: THAT 70 S SOUND - THAT 70\'S SOUND - with Dave Edwards. prog 371  59.49',
                url: 'http://uk2.internet-radio.com:8008/autodj'
            },
            {
                name: 'Radio München',
                currentSong: 'On Air: Dis*Ka - Big Black Rainbow Over My Life ',
                url: 'http://stream.radiomuenchen.net:8000/rm64.ogg'
            },
            {
                name: 'YouRadio.nl',
                currentSong: 'On Air: Michael Jackson - Don\'t Stop \'Til You Get Enough (2003 Edit)',
                url: 'https://streaming.youradio.nl/listen/youradio/stream'
            },
            {
                name: 'Dreadlock Radio',
                currentSong: 'On Air: Black Uhuru - Sistren (4:35)',
                url: 'http://ic1.dread.fast-serv.com:80/dreadlockradio128'
            },
            {
                name: 'KNR Radio',
                currentSong: 'On Air: Alborosie - Kingston Town - Acoustic',
                url: 'http://usa10.fastcast4u.com:7420/stream'
            },
            {
                name: 'Reggae141.com',
                currentSong: 'On Air: Hezron - Can\'t Come Between',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1301_32'
            },
            {
                name: 'Intamixx 80s 90s Radio UK',
                currentSong: 'On Air: Advert: - Advert:',
                url: 'http://radio.intamixx.uk:8443/radio2'
            },
            {
                name: 'DMIXOLOGIST.NET',
                currentSong: 'On Air: Radio',
                url: 'http://ec1.yesstreaming.net:3580/stream'
            },
            {
                name: 'Five Star FM Radio',
                currentSong: 'On Air: Al Green - I\'m Still in Love With You',
                url: 'http://s7.citrus3.com:8128/stream'
            },
            {
                name: 'ReggaeCity Radio',
                currentSong: 'On Air: Remixfactory - good day riddim remix',
                url: 'http://s9.voscast.com:7728/stream'
            },
            {
                name: 'ReggaeSpace Auto Stream',
                currentSong: 'On Air:  - ',
                url: 'http://reggaespace.com:8010/live.mp3'
            }
        ];
    },
    get GospelData() {
        return [
            {
                name: 'Rádio Vinha FM 91,9 - Goiânia - GO - Brasil',
                currentSong: 'On Air: ',
                url: 'http://streaming.vinhafm.com.br:80/stream'
            },
            {
                name: 'Radio 90.7 FM',
                currentSong: 'On Air: Gospel 90.7 FM',
                url: 'http://www.appradio.app:8120/live'
            },
            {
                name: 'Radio OBEDIRA Online',
                currentSong: 'On Air: ',
                url: 'http://stream17.shoutcastsolutions.com:8300/live'
            },
            {
                name: 'AFFIRM SOUTHERN GOSPEL RADIO',
                currentSong: 'On Air: JONATHAN WILBURN - WINGS OF A DOVE (W. THE INSPIRATIONS) (2024)',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/1708_128'
            },
            {
                name: 'UrbanRadio Gospel',
                currentSong: 'On Air: J. Moss - God\'s Got It ',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1535_128'
            },
            {
                name: 'AFFIRM SOUTHERN GOSPEL RADIO',
                currentSong: 'On Air: JONATHAN WILBURN - WINGS OF A DOVE (W. THE INSPIRATIONS) (2024)',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/1708_128'
            },
            {
                name: 'AFFIRM SOUTHERN GOSPEL RADIO',
                currentSong: 'On Air: JONATHAN WILBURN - WINGS OF A DOVE (W. THE INSPIRATIONS) (2024)',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/1708_128'
            },
            {
                name: 'HOW RADIO 90.9 FM',
                currentSong: 'On Air: ',
                url: 'http://s7.voscast.com:9138/live'
            },
            {
                name: 'AD Bacabal',
                currentSong: 'On Air: 04 - Paz que me conduz',
                url: 'http://radios.digital:8050/stream'
            },
            {
                name: 'Gospel Hits',
                currentSong: 'On Air: Be Right Back! - ADWTAG_122000 [s1q]',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1627_128'
            },
            {
                name: 'Assembleia de Deus Online',
                currentSong: 'On Air: UMA EMISSORA SEM FRONTEIRAS~0.5',
                url: 'http://ec2.yesstreaming.net:3920/stream'
            },
            {
                name: 'Joyful FM',
                currentSong: 'On Air: Atmosphere Shift Feat. Phil Thompson - Shift',
                url: 'http://c15.radioboss.fm:8218/autodj'
            },
            {
                name: 'Rede Renacer',
                currentSong: 'On Air:  - ',
                url: 'http://cast.hoost.com.br:8055/live'
            },
            {
                name: 'Sara Varginha',
                currentSong: 'On Air: Leonardo Gonçalves - Eu acredito',
                url: 'http://server01.ouvir.radio.br:8000/autodj'
            },
            {
                name: 'Nossa Radio USA Boston',
                currentSong: 'On Air: ',
                url: 'http://www.appradio.app:8134/live'
            },
            {
                name: 'LogosRadio.info AAC 64 kb/s',
                currentSong: 'On Air: LogosRadio.info AAC 64 kb/s',
                url: 'http://logosradio.info:8000/logosradio.aac'
            },
            {
                name: 'Gospel 107.1 Fm',
                currentSong: 'On Air: Israel Houghton - True',
                url: 'http://c25.radioboss.fm:8186/autodj'
            },
            {
                name: 'LogosRadio.info MP3 128 kb/s',
                currentSong: 'On Air: logos-01-06-13',
                url: 'http://logosradio.info:8000/stream'
            },
            {
                name: 'Nossa Radio USA  Florida',
                currentSong: 'On Air: ',
                url: 'http://www.appradio.app:8135/live'
            },
            {
                name: 'Lébénè Gospel',
                currentSong: 'On Air: Onbekend - NUKUNU MAWU [eJA]',
                url: 'http://usa6.fastcast4u.com:5067/autodj'
            },
            {
                name: 'LogosRadio.info OGG 64 kb/s',
                currentSong: 'On Air: ',
                url: 'http://logosradio.info:8000/logosradio.ogg'
            },
            {
                name: 'LogosRadio.info MP3 64 kb/s',
                currentSong: 'On Air: LogosRadio.info MP3 64 kb/s',
                url: 'http://logosradio.info:8000/logosradio.mp3lo'
            },
            {
                name: 'Jammin Vibez: Reggae Hits',
                currentSong: 'On Air: Donna Marie - Heaven In Your Arms',
                url: 'https://azuracast.jammimvibez.com/listen/reggae/stream'
            },
            {
                name: 'Texas Gospel - Southern Gospel',
                currentSong: 'On Air: The Chandlers - Anchor of My Soul',
                url: 'http://quincy.torontocast.com:1950/stream'
            },
            {
                name: 'Texas Gospel - Country Gospel',
                currentSong: 'On Air: Kevin Rowe & Prodigal Sons - Heaven Above',
                url: 'http://quincy.torontocast.com:3610/stream'
            },
            {
                name: 'Rádio Athos',
                currentSong: 'On Air: J NETO NÃO TENTE SOZINHO LEGENDADO[1]',
                url: 'http://radios.digital:8102/stream'
            },
            {
                name: 'WNIAGospelRadio',
                currentSong: 'On Air: Atmosphere Of Heaven - Yahweh - Atmosphere Of Heaven Vol 2',
                url: 'http://radio.streemlion.com:2440/stream'
            },
            {
                name: 'Louvor e Adoracao',
                currentSong: 'On Air: 2F LEITURA BIBLICA DIARIA',
                url: 'http://stm14.voxhd.com.br:7898/stream'
            },
            {
                name: '90.1/104.9 - WVRS/WVRX - The Point FM',
                currentSong: 'On Air: ',
                url: 'http://stream.lentzsystems.net:8000/WVRS'
            },
            {
                name: 'Synergy1Radio',
                currentSong: 'On Air: Black History With Roderick Carter 28 - Christina Jenkins - Invented Hair Weaving',
                url: 'http://puma.streemlion.com:1900/stream'
            }
        ];
    },
    get PunkData() {
        return [
            {
                name: 'Guerrilla Radio',
                currentSong: 'On Air: Sheverb - Redemption of the River Witch - from Austin, TX, USA on Guerrilla Garage / Garage Uranium Level ',
                url: 'http://s2.stationplaylist.com:9460/guerrilla'
            },
            {
                name: 'Punkrockers Radio',
                currentSong: 'On Air: Quitters - The Brighter Shades Of Time',
                url: 'http://stream.punkrockers-radio.de:8000/prr.mp3'
            },
            {
                name: 'Punkrockers Radio',
                currentSong: 'On Air: Quitters - The Brighter Shades Of Time',
                url: 'http://stream.punkrockers-radio.de:8000/prr.ogg'
            },
            {
                name: 'Vintage Obscura Radio',
                currentSong: 'On Air: \'The Salas Brothers - Leaving You [USA, Soul, East L.A.] (1964)\'',
                url: 'http://radio.vintageobscura.net:443/stream'
            },
            {
                name: 'THE BLASTOZOIC ERA Hi Fi Classic Christian Rock at 128 kbps',
                currentSong: 'On Air: Undercover - Devotion',
                url: 'http://blastozoicera-stream.theblast.fm.fastserv.com:80/128'
            },
            {
                name: '12XU',
                currentSong: 'On Air: Monoburro - Post perversion (V.M.W) (2021)',
                url: 'http://stream.laut.fm/12xu'
            },
            {
                name: 'StreamD',
                currentSong: 'On Air: Odyssey - New York City (feat. Lillian Lopez) [SAC\'s Groove Mix]',
                url: 'http://nasir.streampanel.cloud:80/stream'
            },
            {
                name: 'BigNoise - music from Siberia',
                currentSong: 'On Air: bignoise.club - Голосуй за треки на сайте',
                url: 'http://radio.bignoise.club:8000/nonstop'
            },
            {
                name: 'FreshRock Internet Radio Station',
                currentSong: 'On Air: Элизиум - Как кошки по крышам',
                url: 'http://stream.freshrock.net:8000/128.mp3'
            },
            {
                name: 'Punkrockers Radio',
                currentSong: 'On Air: ',
                url: 'http://stream.punkrockers-radio.de:8000/mobile.opus'
            },
            {
                name: 'Alternative Flow',
                currentSong: 'On Air: Foo Fighters - White Limo',
                url: 'http://puma.streemlion.com:1090/stream'
            },
            {
                name: '107dot5',
                currentSong: 'On Air: The Cure - Halo',
                url: 'https://www.tuneintoradio1.com/listen/107dot5/radio.mp3'
            },
            {
                name: 'Phoenix Vanguard Anarchy Radio',
                currentSong: 'On Air: Adam and the Ants - Car Trouble // The Anarchy Factory - 24-Hour Punk/Adjacent/Ska/Hardcore/Plus',
                url: 'http://cheetah.streemlion.com:2820/stream'
            },
            {
                name: 'FreshRock Internet Radio Station',
                currentSong: 'On Air: Элизиум - Как кошки по крышам',
                url: 'http://stream.freshrock.net:8000/64.aac'
            },
            {
                name: 'FreshRock Internet Radio Station',
                currentSong: 'On Air: Элизиум - Как кошки по крышам',
                url: 'http://stream.freshrock.net:8000/24.aac'
            },
            {
                name: 'Punkrockers Radio',
                currentSong: 'On Air: ',
                url: 'http://stream.punkrockers-radio.de:8000/prr.flac'
            },
            {
                name: 'CAYA Radio',
                currentSong: 'On Air: Creed - One',
                url: 'https://www.tuneintoradio1.com/listen/caya_radio/64kbps.aac'
            },
            {
                name: 'Live And Loud Radio OTTO. 2.0',
                currentSong: 'On Air: Foo Fighters - This Is A Call [1N70]',
                url: 'http://patmos.cdnstream.com:9536/stream2_autodj'
            },
            {
                name: 'THE BLASTOZOIC ERA Hi Fi Classic Christian Rock at 32 kbps',
                currentSong: 'On Air: Undercover - Devotion',
                url: 'http://blastozoicera-stream.theblast.fm.fastserv.com:80/32'
            },
            {
                name: 'Verket',
                currentSong: 'On Air: Lycka Till - Listening To Victor Jara',
                url: 'http://mustafejen.se:8000/verket'
            },
            {
                name: 'postpunk',
                currentSong: 'On Air: sleepmakeswaves - The Stars Are Stigmata',
                url: 'http://100.24.34.206:80/postpunk'
            },
            {
                name: '[OFF] The Drunken Scoundrel',
                currentSong: 'On Air: The War On Drugs - Lost In The Dream',
                url: 'http://psn3.prostreaming.net:8069/live'
            },
            {
                name: 'Trash Rock',
                currentSong: 'On Air: radio highway pirates - Metal Frequency The Show',
                url: 'http://168.119.74.185:9864/autodj'
            },
            {
                name: 'THE BLASTOZOIC ERA Classic Christian Rock/Alternativ/ Metal low bit rate stream',
                currentSong: 'On Air: Undercover - Devotion',
                url: 'http://blastozoicera-stream.theblast.fm.fastserv.com:80/20'
            },
            {
                name: 'kbd',
                currentSong: 'On Air: Black Flag - You bet we\'ve got something personal against you !',
                url: 'http://34.232.52.84:80/kbd'
            },
            {
                name: 'med',
                currentSong: 'On Air: Skid Row - Big Guns',
                url: 'http://cast1.asurahosting.com:8621/med'
            },
            {
                name: 'FreshRock Internet Radio Station',
                currentSong: 'On Air: Элизиум - Как кошки по крышам',
                url: 'http://stream.freshrock.net:8000/128.aac'
            },
            {
                name: 'THE BLASTOZOIC ERA Hi Fi Classic Christian Rock at 64 kbps',
                currentSong: 'On Air: Undercover - Devotion',
                url: 'http://blastozoicera-stream.theblast.fm.fastserv.com:80/64'
            },
            {
                name: 'Verket opus',
                currentSong: 'On Air: ',
                url: 'http://mustafejen.se:8000/verket.opus'
            },
            {
                name: 'Epic Factory Entertainment Underground',
                currentSong: 'On Air: The 1975 - Love It If We Made It // Epic Factory Entertainment UNDERGROUND RADIO - Modern & Classic Indie and Alternative',
                url: 'http://cheetah.streemlion.com:5230/stream'
            }
        ];
    },
    get FolkData() {
        return [
            {
                name: 'COOL radio | Serbia',
                currentSong: 'On Air: Coby - Jao mama (ft Rouzi)',
                url: 'http://live.coolradio.rs:80/cool128'
            },
            {
                name: 'Extra Radio',
                currentSong: 'On Air: Extra',
                url: 'http://eu10.fastcast4u.com:3520/stream'
            },
            {
                name: 'IRISH PUB RADIO',
                currentSong: 'On Air: The Clancy Brothers With Robbie O\'Connell - Jug Of Punch',
                url: 'http://solid24.streamupsolutions.com:8026/live'
            },
            {
                name: 'Drentsepiraten',
                currentSong: 'On Air: Drentsepiraten - 24 uur per dag op volle toeren!',
                url: 'http://server1.streamgigant.nl:19214/drentsepiraten192'
            },
            {
                name: 'American Roots',
                currentSong: 'On Air: The Barefoot Movement - Early In The Morning',
                url: 'http://cast1.torontocast.com:2300/stream'
            },
            {
                name: 'COOL radio | Serbia',
                currentSong: 'On Air: Coby - Jao mama (ft Rouzi)',
                url: 'http://live.coolradio.rs:80/coolaac'
            },
            {
                name: 'Radio Sorrriso',
                currentSong: 'On Air: SORRRISO',
                url: 'http://ice01.fluidstream.net:80/sorriso'
            },
            {
                name: 'COOL radio | Serbia',
                currentSong: 'On Air: Coby - Jao mama (ft Rouzi)',
                url: 'http://live.coolradio.rs:80/'
            },
            {
                name: 'IOANNINA_RADIO_EPIRUS_94.5',
                currentSong: 'On Air: RADIO EPIRUS LINK',
                url: 'http://168.119.74.185:9450/stream'
            },
            {
                name: 'U luistert naar De Beste Piratenhits.',
                currentSong: 'On Air:  Welkom bij De Beste Piratenhits - Hits uit de vervlogen tijden ! U luistert naar de Non-Stop playlist van www.debestepiratenhits.nl',
                url: 'http://radio.streampanel.nl:1440/stream'
            },
            {
                name: 'COOL radio | Serbia',
                currentSong: 'On Air: Coby - Jao mama (ft Rouzi)',
                url: 'http://live.coolradio.rs:80/cool64'
            },
            {
                name: 'U luistert naar www.muziekteam.nl voor de beste piraten hits',
                currentSong: 'On Air: Unknown',
                url: 'http://mcp-1.streampanel.nl:18036/stream'
            },
            {
                name: 'Radio Orgazam Folk',
                currentSong: 'On Air: DJ DOKTORA: LIVE DOKI - 2',
                url: 'http://ams-pioneer02.dedicateware.com:1180/stream'
            },
            {
                name: 'Breeze',
                currentSong: 'On Air: Wind Machine - Land Of The Redwoods',
                url: 'http://streams.radiomast.io/a2dd31a2-a524-48ce-baea-8271e1a37ab2'
            },
            {
                name: 'rgwlow',
                currentSong: 'On Air: Vicky Leandros - Das Leben Und Ich',
                url: 'http://nr11.newradio.it:9196/rgwlow'
            },
            {
                name: '..:: Visper-Radio.com ::..',
                currentSong: 'On Air: Saban Saulic - Danima te cekam ( Original snimak )',
                url: 'http://78.46.65.254:8100/live.mp3'
            },
            {
                name: 'Radio Regenboog',
                currentSong: 'On Air: NU LIVE Zwarte Zwaluw - Tel *only sms* sms 0611084780 veel luister plezier',
                url: 'http://server-28.stream-server.nl:8829/stream'
            },
            {
                name: '***Muziekknallers.nl**Keihard De Beste**op jou radio**',
                currentSong: 'On Air: Piraten Hits - De Vampier',
                url: 'http://server-28.stream-server.nl:8969/stream'
            },
            {
                name: 'Radio Twilight draait de mooiste hitsss',
                currentSong: 'On Air: Daniel O\'Donnell - lucille',
                url: 'http://live.hostingbudget.nl:4270/stream'
            },
            {
                name: 'Radio Regenboog',
                currentSong: 'On Air: De Stemmingmakers - Ik Hoor Je Stem',
                url: 'http://server-28.stream-server.nl:8829/autodj'
            },
            {
                name: 'radiobonita',
                currentSong: 'On Air: 20 - Vader Abraham - Het smurfenli',
                url: 'http://live.hostingbudget.nl:1040/stream'
            },
            {
                name: 'Radio München',
                currentSong: 'On Air: Phonotom - Dieses Leben ',
                url: 'http://stream.radiomuenchen.net:8000/rm256.mp3'
            },
            {
                name: 'Gewoonpiraten altijd gezellig',
                currentSong: 'On Air: De hits uit de Jukebox. Je hoort nu: Jannes - Adio amore adio (knuffelversie)',
                url: 'http://server-67.stream-server.nl:8802/stream'
            },
            {
                name: 'Schwany3 Die echte Volksmusik',
                currentSong: 'On Air: Fischbachauer Dirndln u.d. Isartaler Musikanten - Aber lustig is`s scho',
                url: 'http://bone.streampanel.cloud:80/3-dieechte'
            },
            {
                name: 'American Roots',
                currentSong: 'On Air: The Barefoot Movement - Early In The Morning',
                url: 'http://cast1.torontocast.com:2340/stream'
            },
            {
                name: 'Nóta FM >> Mulatós slágerek /mobil stream/',
                currentSong: 'On Air: Matyi es a Hegedus - Jajj de nagyon reszeg vagyok',
                url: 'http://live.topfm.hu:8000/notafm'
            },
            {
                name: 'Drentsepiraten',
                currentSong: 'On Air: Drentsepiraten - 24 uur per dag op volle toeren!',
                url: 'http://server1.streamgigant.nl:19214/drentsepiraten64'
            },
            {
                name: 'CLEVELAND FM',
                currentSong: 'On Air: O Porquê Dessas Milongas ',
                url: 'http://radio.viaflux.com:9050/radio.aac'
            },
            {
                name: 'Folk',
                currentSong: 'On Air: Joe Val - T For Texas',
                url: 'http://streams.radiomast.io/a561c414-1402-4f40-91c8-dfd050d3a784'
            },
            {
                name: 'SU fm',
                currentSong: 'On Air: TRAMMPS - DISCO INFERNO',
                url: 'http://cast1.torontocast.com:2830/stream'
            }
        ];
    },
    get WorldData() {
        return [
            {
                name: 'Vintage Obscura Radio',
                currentSong: 'On Air: \'Vyacheslav Mescherin Orchestra - Persistent Robot[USSR, Electronic/Funk](197? or 198?)\'',
                url: 'http://radio.vintageobscura.net:443/stream'
            },
            {
                name: 'Intamixx 80s 90s Radio UK',
                currentSong: 'On Air: En Vogue - My Lovin\' [You\'re Never Gonna It]',
                url: 'http://radio.intamixx.uk:8443/radio2'
            },
            {
                name: 'Sirelazik',
                currentSong: 'On Air: LibreTime - offline',
                url: 'http://planner.sirelazik.com:8080/stream'
            },
            {
                name: 'Radio44',
                currentSong: 'On Air: Chihiro Yamanaka - I Have A Dream',
                url: 'http://eu.publicssl.net:7020/'
            }
        ];
    },
    get EasyData() {
        return [
            {
                name: 'Peaceful Currents Radio',
                currentSong: 'On Air: Robert Linton - Aside the River Bend',
                url: 'http://cast1.torontocast.com:2860/stream'
            },
            {
                name: 'SmoothEasyHits.com',
                currentSong: 'On Air: Lionel Richie - Sail On (With The Commodores) ',
                url: 'http://ais-edge66-ams02.cdnstream.com:80/1709_128'
            },
            {
                name: 'Peaceful Currents Radio',
                currentSong: 'On Air: Robert Linton - Aside the River Bend',
                url: 'http://cast1.torontocast.com:2660/stream'
            },
            {
                name: 'Lite RADIO',
                currentSong: 'On Air: Soul II Soul featuring Caron Wheeler - Back To Life',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/2382_128.mp3'
            },
            {
                name: 'Humboldt 101',
                currentSong: 'On Air: Boz Scaggs - Miss Sun',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/2188_128.mp3'
            },
            {
                name: 'Humboldt 101',
                currentSong: 'On Air: Boz Scaggs - Miss Sun',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/2188_128.mp3'
            },
            {
                name: 'Humboldt 101',
                currentSong: 'On Air: Boz Scaggs - Miss Sun',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/2188_128.mp3'
            },
            {
                name: 'Vintage Obscura Radio',
                currentSong: 'On Air: \'Monsieur X - Ou qué de moin [Guadeloupe, creole funk] (196?)\'',
                url: 'http://radio.vintageobscura.net:443/stream'
            },
            {
                name: 'Lite RADIO',
                currentSong: 'On Air: Soul II Soul featuring Caron Wheeler - Back To Life',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/2382_128.mp3'
            },
            {
                name: 'knixx.fm - Dein Webradio. / 256 kbp/s mp3',
                currentSong: 'On Air: Keith Urban Feat. Carrie Underwood - The Fighter -- 2017',
                url: 'http://s1.knixx.fm:5347/dein_webradio_256.mp3'
            },
            {
                name: 'Lite RADIO',
                currentSong: 'On Air: Soul II Soul featuring Caron Wheeler - Back To Life',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/2382_128.mp3'
            },
            {
                name: 'knixx.fm - Dein Webradio. / 128 kbp/s mp3',
                currentSong: 'On Air: Keith Urban Feat. Carrie Underwood - The Fighter -- 2017',
                url: 'http://s1.knixx.fm:5347/dein_webradio_128.mp3'
            },
            {
                name: 'Classic Vinyl HD',
                currentSong: 'On Air: Old Joe Clark  By: Jo Stafford - WALMRadio.com',
                url: 'http://icecast.walmradio.com:8000/classic'
            },
            {
                name: 'FM KORTRIJK',
                currentSong: 'On Air: Paul Jackson, Jr. #1_IN_848151',
                url: 'http://stream.fmkortrijk.be:8131/stream'
            },
            {
                name: 'Peaceful Currents Christmas',
                currentSong: 'On Air: Mogwai - Christmas Song',
                url: 'http://cast1.torontocast.com:3280/stream'
            },
            {
                name: 'Christmas Vinyl HD',
                currentSong: 'On Air: Christmas Tree  By: Harry Simeone Chorale - WALMRadio.com',
                url: 'http://icecast.walmradio.com:8000/christ,mas'
            },
            {
                name: 'Myall Coast Radio',
                currentSong: 'On Air: Scissor Sisters - I Don\'t Feel Like Dancin\'',
                url: 'http://streams.radiomast.io/8a7977d1-a8df-4ae4-a987-984eada92c1b'
            },
            {
                name: 'Lite RADIO',
                currentSong: 'On Air: Soul II Soul featuring Caron Wheeler - Back To Life',
                url: 'http://ais-edge147-dal03.cdnstream.com:80/2382_48.aac'
            },
            {
                name: 'Pure Lounge Radio',
                currentSong: 'On Air: Ashford & Simpson - Solid',
                url: 'http://mscp4.live-streams.nl:8140/lounge.mp3'
            },
            {
                name: 'Pure Lounge Radio',
                currentSong: 'On Air: ',
                url: 'http://mscp4.live-streams.nl:8140/lounge.ogg'
            },
            {
                name: 'Lite RADIO',
                currentSong: 'On Air: Soul II Soul featuring Caron Wheeler - Back To Life',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/2382_48.aac'
            },
            {
                name: 'Classic Hits Global HD',
                currentSong: 'On Air: Tina Turner - I Don\'t Wanna Fight Anymore',
                url: 'http://login.webinternetradio.com:1350/stream'
            },
            {
                name: 'Humboldt 101',
                currentSong: 'On Air: Boz Scaggs - Miss Sun',
                url: 'http://ais-edge94-nyc04.cdnstream.com:80/2188_64.aac'
            },
            {
                name: 'Day Spa',
                currentSong: 'On Air: Ferr & Ferry Corsten - Morning Rays',
                url: 'http://ec3.yesstreaming.net:1950/stream'
            },
            {
                name: 'knixx.fm - Dein Webradio. / 64 kbp/s aac',
                currentSong: 'On Air: Keith Urban Feat. Carrie Underwood - The Fighter -- 2017',
                url: 'http://s1.knixx.fm:5347/dein_webradio_64.aac'
            },
            {
                name: 'SmoothEasyHits.com',
                currentSong: 'On Air: Lionel Richie - Sail On (With The Commodores) ',
                url: 'http://ais-edge66-ams02.cdnstream.com:80/1709_64'
            },
            {
                name: 'SmoothEasyHits.com',
                currentSong: 'On Air: Lionel Richie - Sail On (With The Commodores) ',
                url: 'http://ais-edge65-lon01.cdnstream.com:80/1709_64'
            },
            {
                name: 'Humboldt 101',
                currentSong: 'On Air: Boz Scaggs - Miss Sun',
                url: 'http://ais-edge148-pit01.cdnstream.com:80/2188_64.aac'
            },
            {
                name: 'knixx.fm - Dein Webradio. / 32 kbp/s aac+',
                currentSong: 'On Air: Keith Urban Feat. Carrie Underwood - The Fighter -- 2017',
                url: 'http://s1.knixx.fm:5347/dein_webradio_32.aac'
            },
            {
                name: 'Artisan Radio',
                currentSong: 'On Air: Whistler 47-07-16 (268) Beyond Reasonable Doubt',
                url: 'http://artisanradio.hopto.org:8000/ArtisanRadio.mp3'
            }
        ];
    },
    get OldiesData() {
        return [
            {
                name: 'Media',
                currentSong: 'On Air: ',
                url: 'http://as.fm1.be:8000/media'
            },
            {
                name: 'Radio Grün Weiß',
                currentSong: 'On Air: Unser Sender, unsere Steiermark!',
                url: 'http://ice37.fluidstream.net:80/rgw.mp3'
            },
            {
                name: 'Forest Gold',
                currentSong: 'On Air: I Can\'t Stand The Rain by Eruption',
                url: 'https://c2.prostream365.com:8000/live'
            },
            {
                name: 'RADIO fresh80s - Hier sind die Achtziger zuhause!',
                currentSong: 'On Air: Sandra - Heaven Can Wait',
                url: 'http://s37.derstream.net:80/live.mp3'
            },
            {
                name: 'Radio Italia Anni 60',
                currentSong: 'On Air: GRAZIA DI MICHELE - LE RAGAZZE DI GAUGUIN',
                url: 'http://ice10.fluidstream.net:8080/anni60tn.aac'
            },
            {
                name: 'Radio Italia Anni 60',
                currentSong: 'On Air: GRAZIA DI MICHELE - LE RAGAZZE DI GAUGUIN',
                url: 'http://str01.fluidstream.net:80/anni60.mp3'
            },
            {
                name: 'RADIO fresh80s - Hier sind die Achtziger zuhause!',
                currentSong: 'On Air: Sandra - Heaven Can Wait',
                url: 'http://178.77.76.9:8000/live.mp3'
            },
            {
                name: 'Radio SOVA',
                currentSong: 'On Air: London Boys - Dance Dance Dance (1987)',
                url: 'http://evcast.mediacp.eu:1960/stream'
            },
            {
                name: 'Radio Opsinjoor',
                currentSong: 'On Air: Yvonne Elliman - If I Can\'t Have You (1978)',
                url: 'http://icecast.movemedia.be:8000/opsinjoor'
            },
            {
                name: 'Radio Italia Anni 60',
                currentSong: 'On Air: GRAZIA DI MICHELE - LE RAGAZZE DI GAUGUIN',
                url: 'http://ice10.fluidstream.net:8080/anni60.mp3'
            },
            {
                name: 'Radio Grün Weiß',
                currentSong: 'On Air: Unser Sender, unsere Steiermark!',
                url: 'http://ice37.fluidstream.net:80/rgw.aac'
            },
            {
                name: 'Friesenradio',
                currentSong: 'On Air: Ray Dalton - ALL WE GOT',
                url: 'http://stream.laut.fm/friesenradio'
            },
            {
                name: 'extra-radio',
                currentSong: 'On Air: Purple Schulz - Bis Ans Ende Der Welt ',
                url: 'http://s4.radionetz.de:80/extra-radio.mp3'
            },
            {
                name: 'All Oldies Channel',
                currentSong: 'On Air: Ub40 - Where Did I Go Wrong',
                url: 'http://radio.alloldieschannel.com:8000/stream'
            },
            {
                name: 'RADIO fresh80s - Hier sind die Achtziger zuhause! (Mobile-Stream 128kb/s mp3)',
                currentSong: 'On Air: Sandra - Heaven Can Wait',
                url: 'http://s37.derstream.net:80/128.mp3'
            },
            {
                name: 'WEST COAST',
                currentSong: 'On Air: Sunrize - I Need You More Than Words Can Say',
                url: 'http://radio10.pro-fhi.net:9101/192stream'
            },
            {
                name: 'ABC Fifties (50\'s)',
                currentSong: 'On Air: Frankie Laine - I Believe',
                url: 'http://cast1.torontocast.com:2270/stream'
            },
            {
                name: 'Radio Zoe Gold',
                currentSong: 'On Air: Cliff Richard - Living Doll (1959)',
                url: 'http://icecast.movemedia.be:8000/zoegold128'
            },
            {
                name: 'Radio Rosita',
                currentSong: 'On Air: Unknown',
                url: 'http://mediacp.audiostreamen.nl:8000/stream'
            },
            {
                name: 'Radio Moonlights',
                currentSong: 'On Air: Dutch boys - Ik proat plat',
                url: 'http://server1.streamgigant.nl:19177/moonlights192'
            },
            {
                name: 'U luistert naar www.muziekteam.nl voor de beste piraten hits',
                currentSong: 'On Air: Unknown',
                url: 'http://mcp-1.streampanel.nl:18036/stream'
            },
            {
                name: 'TOP FM oldies >> 50s, 60s, 70s, 80s',
                currentSong: 'On Air: TOP FM oldies',
                url: 'http://live.topfm.hu:8000/oldies.mp3'
            },
            {
                name: '==70\'s Hits==',
                currentSong: 'On Air: Barbra Streisand - The Main Event',
                url: 'http://quincy.torontocast.com:2500/stream'
            },
            {
                name: '.113FM WMRR Radio',
                currentSong: 'On Air: Maggie Lindemann - Loner',
                url: 'http://ais-edge87-113fm-bhs06.cdnstream.com:80/1788_128'
            },
            {
                name: 'Stadsradio Halle',
                currentSong: 'On Air: Zucchero  Jack Savoretti - Senza Una Donna (Without A Woman)',
                url: 'http://mscp2.live-streams.nl:8130/live'
            },
            {
                name: '.113FM WMRR Radio',
                currentSong: 'On Air: Maggie Lindemann - Loner',
                url: 'http://ais-edge88-113fm-bhs07.cdnstream.com:80/1788_128'
            },
            {
                name: 'Rewound Radio',
                currentSong: 'On Air: O.C. Smith - Little Green Apples ',
                url: 'http://rewoundradio.com:5000/rewound'
            },
            {
                name: 'Cool Oldies',
                currentSong: 'On Air: Simon & Garfunkel - The Sound of Silence - Electric Version',
                url: 'http://c14.radioboss.fm:8114/autodj'
            },
            {
                name: 'Radio Seabreeze 1395 AM',
                currentSong: 'On Air: Rico van Amstel en Elly van Loenen - Oud is Goud',
                url: 'http://mediaserv38.live-streams.nl:8025/low1'
            },
            {
                name: 'ABC 60\'s',
                currentSong: 'On Air: Skeeter Davis - The End of the World',
                url: 'http://cast1.torontocast.com:1140/stream'
            }
        ];
    },
    get TalkData() {
        return [
            {
                name: '     ..:: UMNOE RADIO - УМНОЕ РАДИО ::.. AMG RADIO',
                currentSong: 'On Air: ШАРЛЬ ПЕРРО / ЕВГЕНИЙ ШВАРЦ - ЗОЛУШКА',
                url: 'https://umnoe.amgradio.ru/Umnoe'
            },
            {
                name: '     ..:: SKAZKA FM - СКАЗКА FM ::.. AMG RADIO',
                currentSong: 'On Air: РУССКИЕ НАРОДНЫЕ СКАЗКИ - ЛЕТУЧИЙ КОРАБЛЬ',
                url: 'https://skazka.amgradio.ru/Skazka'
            },
            {
                name: 'Alex Jones - Infowars.com',
                currentSong: 'On Air: Alex Jones Show - REPLAY',
                url: 'http://audio20.d.infowars.com:80/alexjonesshow'
            },
            {
                name: 'LS4 Radio Continental 590',
                currentSong: 'On Air: ',
                url: 'http://edge04.radiohdvivo.com:9002/live'
            },
            {
                name: 'ABN Antioch OTR, Scheduled Old-time radio sub-genres and preferring today\'s date',
                currentSong: 'On Air: The Quiz Kids -  Feb 26, 1941: (36) The Name of the Largest Island ',
                url: 'http://s6.yesstreaming.net:8000/listen_live'
            },
            {
                name: 'Net FM',
                currentSong: 'On Air: Now Playing info goes here',
                url: 'http://s2.voscast.com:11392/default'
            },
            {
                name: 'SciFi Old Time Radio',
                currentSong: 'On Air: X Minus One - The Sense Of Wonder',
                url: 'http://s1.voscast.com:8652/stream'
            },
            {
                name: 'Nossa FM',
                currentSong: 'On Air:  ',
                url: 'http://radio.viaflux.com:1029/live.aac'
            },
            {
                name: 'PT. Radio Elshinta',
                currentSong: 'On Air: ',
                url: 'http://stream-ssl.arenastreaming.com:8000/jakarta'
            },
            {
                name: 'Sound Chat Radio',
                currentSong: 'On Air: ',
                url: 'http://s2.voscast.com:9058/stream'
            },
            {
                name: 'Kossuth Rádió (mp3)',
                currentSong: 'On Air: Kossuth Radio',
                url: 'http://stream002.radio.hu:80/mr1.mp3'
            },
            {
                name: 'Kossuth Rádió (aac+)',
                currentSong: 'On Air: ',
                url: 'http://stream002.radio.hu:80/mr1.aac'
            },
            {
                name: '96.9 FM GuardianRadio',
                currentSong: 'On Air: ',
                url: 'http://radiostreams.streamcomedia.com:8000/969guardianradio'
            },
            {
                name: '// 2-69 // 269 // 269fm Radio // www.269fm.com // 269fm@269fm.com //',
                currentSong: 'On Air: ',
                url: 'http://lofos.win:8006/lstream'
            },
            {
                name: 'Eagle FM',
                currentSong: 'On Air: ',
                url: 'http://s2.stationplaylist.com:7030/listen.aac+'
            },
            {
                name: 'Liberty Radio ZDK 97.1 FM',
                currentSong: 'On Air: ',
                url: 'http://s7.voscast.com:10052/stream'
            },
            {
                name: 'LCN Radio',
                currentSong: 'On Air: ',
                url: 'http://s1.voscast.com:10210/stream'
            },
            {
                name: 'RÁDIO ATALAIA',
                currentSong: 'On Air: ',
                url: 'http://radio.viaflux.com:5533/live'
            },
            {
                name: 'KTOX 1340',
                currentSong: 'On Air: ',
                url: 'http://streaming.rubinbroadcasting.com:80/ktox'
            },
            {
                name: 'Antenna 1 La Radio',
                currentSong: 'On Air: ANTONELLO VENDITTI - CI VORREBBE UN AMICO',
                url: 'http://icecast.top-ix.org:80/antennauno'
            },
            {
                name: 'Радио Движение.',
                currentSong: 'On Air: Def Leppard - Hysteria',
                url: 'http://c4.radioboss.fm:8218/autodj'
            },
            {
                name: 'Random Loveline',
                currentSong: 'On Air: Loveline-2002-03-06cf - Gorillaz',
                url: 'http://challenger.phil21.net:8000/stream'
            },
            {
                name: 'Radyo Natin Agoo',
                currentSong: 'On Air: Radyo Natin - Your Friend, Your Radio!',
                url: 'https://pinas.radyonatinfm.com/listen/dwis/agoo'
            },
            {
                name: 'Radio ENA',
                currentSong: 'On Air: ARIS PORTOSALTE - ΑΡΗΣ ΠΟΡΤΟΣΑΛΤΕ',
                url: 'http://c3.radioboss.fm:8238/autodj'
            },
            {
                name: 'CLEVELAND FM',
                currentSong: 'On Air: Luiz Marenco E Jari Terres - Andapago - 2010 - Cd 01 - 03 - Fronteiro De Alma E Pampa ',
                url: 'http://radio.viaflux.com:9050/radio.aac'
            },
            {
                name: 'stream',
                currentSong: 'On Air: Alan Fahrner - Running on Empty',
                url: 'http://canada1.reliastream.com:8125/autodj'
            },
            {
                name: 'LS4 Radio Continental 590',
                currentSong: 'On Air: ',
                url: 'http://edge05.radiohdvivo.com:9002/live'
            },
            {
                name: 'I Am Catholic Zambia online Radio',
                currentSong: 'On Air: 12. WABABA WAMAMA',
                url: 'http://ec4.yesstreaming.net:2010/stream'
            },
            {
                name: 'Pines FM Bataraza',
                currentSong: 'On Air: Pines FM Bataraza',
                url: 'https://xcite.radyoph.com/listen/pines/radio'
            },
            {
                name: 'Patriot Voice',
                currentSong: 'On Air: ',
                url: 'http://47.50.73.146:8000/mount1'
            }
        ];
    },
    get NewsData() {
        return [
            {
                name: 'Alex Jones - Infowars.com',
                currentSong: 'On Air: Alex Jones Show - REPLAY',
                url: 'http://audio20.d.infowars.com:80/alexjonesshow'
            },
            {
                name: 'LS4 Radio Continental 590',
                currentSong: 'On Air: ',
                url: 'http://edge04.radiohdvivo.com:9002/live'
            },
            {
                name: 'Movimento FM',
                currentSong: 'On Air: ',
                url: 'http://radio.viaflux.com:9750/radio.aac'
            },
            {
                name: 'Nossa FM',
                currentSong: 'On Air:  ',
                url: 'http://radio.viaflux.com:1029/live.aac'
            },
            {
                name: 'Rádio Celinauta',
                currentSong: 'On Air: ',
                url: 'http://radio.viaflux.com:1600/radio.aac'
            },
            {
                name: 'Metro Dance Radio - by Metro Cast Stations',
                currentSong: 'On Air: Mike Isai - Chrysalis (Gmj & Matter Remix)  ',
                url: 'http://eu1.reliastream.com:7017/MDR'
            },
            {
                name: 'Kossuth Rádió (mp3)',
                currentSong: 'On Air: Kossuth Radio',
                url: 'http://stream002.radio.hu:80/mr1.mp3'
            },
            {
                name: 'Kossuth Rádió (aac+)',
                currentSong: 'On Air: ',
                url: 'http://stream002.radio.hu:80/mr1.aac'
            },
            {
                name: 'Jovem Pan News Vitória',
                currentSong: 'On Air: ',
                url: 'http://r13.ciclano.io:8010/Stream'
            },
            {
                name: 'Rádio Cidade Pato Branco',
                currentSong: 'On Air: ',
                url: 'http://radio.viaflux.com:1360/live.aac'
            },
            {
                name: 'RÁDIO ATALAIA',
                currentSong: 'On Air: ',
                url: 'http://radio.viaflux.com:5533/live'
            },
            {
                name: 'UJOT FM',
                currentSong: 'On Air: Caesars - Jerk It Out',
                url: 'http://stream.ujot.fm:8000/ujotfm64'
            },
            {
                name: 'Rádio Celinauta',
                currentSong: 'On Air: ',
                url: 'http://radio.viaflux.com:1600/radio.mp3'
            },
            {
                name: 'Rdio Menorca',
                currentSong: 'On Air: ',
                url: 'http://server10.emitironline.com:8040/stream'
            },
            {
                name: 'Metro Hits Radio HD - By Metro Cast Stations',
                currentSong: 'On Air: Dermot Kennedy - Kiss Me  ',
                url: 'http://eu1.reliastream.com:7178/MHR'
            },
            {
                name: 'Radyo Natin Agoo',
                currentSong: 'On Air: Radyo Natin - Your Friend, Your Radio!',
                url: 'https://pinas.radyonatinfm.com/listen/dwis/agoo'
            },
            {
                name: 'Radio Guijuelo',
                currentSong: 'On Air: ',
                url: 'http://radio.guijuelo.es:8000/directo.ogg'
            },
            {
                name: 'CLEVELAND FM',
                currentSong: 'On Air: E BOM ESTAR COM VOCE ',
                url: 'http://radio.viaflux.com:9050/radio.aac'
            },
            {
                name: 'UJOT FM',
                currentSong: 'On Air: Caesars - Jerk It Out',
                url: 'http://stream.ujot.fm:8000/ujotfm320'
            },
            {
                name: 'Gema Surya FM',
                currentSong: 'On Air: Java Jive - Gerangan Cinta',
                url: 'http://r5.siar.us:9420/aac'
            },
            {
                name: 'FM/HD1',
                currentSong: 'On Air: Listener-Supported Public Radio  - For Thoughtful People - Like You!',
                url: 'http://streams.radiomast.io/5567306a-66f6-4d8f-a399-520e2936e3a0'
            },
            {
                name: 'The Light 810AM',
                currentSong: 'On Air: ',
                url: 'http://radiostreams.streamcomedia.com:8002/zns810am'
            },
            {
                name: 'LS4 Radio Continental 590',
                currentSong: 'On Air: ',
                url: 'http://edge05.radiohdvivo.com:9002/live'
            },
            {
                name: 'Pines FM Bataraza',
                currentSong: 'On Air: Pines FM Bataraza',
                url: 'https://xcite.radyoph.com/listen/pines/radio'
            },
            {
                name: 'Metro Love 90s Radio HD - By Metro Cast Stations',
                currentSong: 'On Air: Snap - Rhythm Is A Dancer ',
                url: 'http://eu1.reliastream.com:7031/MLR90S'
            },
            {
                name: 'Metro Love 80s Radio HD - by Metro Cast Stations',
                currentSong: 'On Air: Belinda Carlisle - Heaven Is a Place on Earth',
                url: 'http://eu1.reliastream.com:7031/MLR80S'
            },
            {
                name: 'Parlamenti adások (aac+)',
                currentSong: 'On Air: ',
                url: 'http://stream002.radio.hu:80/mr5.aac'
            },
            {
                name: 'LS4 Radio Continental 590',
                currentSong: 'On Air: ',
                url: 'http://edge04.radiohdvivo.com:9002/live5'
            },
            {
                name: 'Country Rock Radio HD - By Metro Cast Stations',
                currentSong: 'On Air: Cody Johnson - \'Til You Can\'t',
                url: 'http://eu1.reliastream.com:7093/MSRR'
            },
            {
                name: 'Metro Love Radio HD - By Metro Cast Stations',
                currentSong: 'On Air: Cher - Just like Jesse James',
                url: 'http://eu1.reliastream.com:7002/service'
            }
        ];
    },
    get ComedyData() {
        return [
            {
                name: 'TOP FM comedy >> Kabaré, humor',
                currentSong: 'On Air: A Dumaszinhaz bemutatja...',
                url: 'http://live.topfm.hu:8000/comedy.mp3'
            },
            {
                name: 'TOP FM comedy >> Kabaré, humor /mobil stream/',
                currentSong: 'On Air: A Dumaszinhaz bemutatja...',
                url: 'http://live.topfm.hu:8000/comedy'
            },
            {
                name: 'Comedy104 - A Star104.net Station',
                currentSong: 'On Air: Bill Engvall - Here\'s Your Sign',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1073_64'
            },
            {
                name: 'Madhouse Prank Call Radio',
                currentSong: 'On Air: MadhouseLive.com - Thats Right - 11/12/09 Show',
                url: 'http://s2.voscast.com:9956/stream'
            },
            {
                name: 'Random Loveline',
                currentSong: 'On Air: Loveline-2002-03-06cf - Gorillaz',
                url: 'http://challenger.phil21.net:8000/stream'
            },
            {
                name: 'Humorzender',
                currentSong: 'On Air: Jingle 16 - 16',
                url: 'http://jenny.torontocast.com:18162/stream'
            },
            {
                name: 'Comedy104 - A Star104.net Station',
                currentSong: 'On Air: Bill Engvall - Here\'s Your Sign',
                url: 'http://ais-edge114-dal02.cdnstream.com:80/1073_64a'
            },
            {
                name: 'TOP Radio HD',
                currentSong: 'On Air: Top Radio By Metro Cast - More Stations At Metrocast.top',
                url: 'http://eu1.reliastream.com:7000/MGR'
            },
            {
                name: 'All 80s Memories',
                currentSong: 'On Air: After the Fire - Der Kommissar (7" Version)',
                url: 'http://phoebe.streamerr.co:2280/stream'
            },
            {
                name: 'WALM - Old Time Radio Opus',
                currentSong: 'On Air: ',
                url: 'http://icecast.walmradio.com:8000/otr_opus'
            },
            {
                name: 'Discworld Vintage Comedy - Mobile',
                currentSong: 'On Air: Kenneth Horne - Round The Horne - S04 - E03 - Frankenstein\'s Monster',
                url: 'http://odinlistening.ddns.net:8000/discworld-mobile'
            },
            {
                name: 'Discworld Vintage Comedy',
                currentSong: 'On Air: Classic British Comedy Radio - Discworld Vintage Comedy',
                url: 'http://odinlistening.ddns.net:8000/discworld-ogg'
            },
            {
                name: 'Discworld Vintage Comedy',
                currentSong: 'On Air: Kenneth Horne - Round The Horne - S04 - E03 - Frankenstein\'s Monster',
                url: 'http://odinlistening.ddns.net:8000/discworld-aac'
            },
            {
                name: 'Discworld Vintage Comedy',
                currentSong: 'On Air: Kenneth Horne - Round The Horne - S04 - E03 - Frankenstein\'s Monster',
                url: 'http://odinlistening.ddns.net:8000/discworld'
            },
            {
                name: 'TOP Radio SD - By Metro Cast Stations',
                currentSong: 'On Air: Top Radio SD - www.metrocast.top - By Metro Cast Stations',
                url: 'http://eu1.reliastream.com:7005/MGR64'
            },
            {
                name: 'Click Your Radio Dutch',
                currentSong: 'On Air: Jo Hoogendoorn - De Beekse Toren',
                url: 'http://kathy.torontocast.com:3870/stream'
            }
        ];
    },
    get WeatherData() {
        return [
            {
                name: 'NOAA Weather Radio KIG-86, Columbus, Ohio',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/KIG86.mp3'
            },
            {
                name: 'NOAA - KEC61 Mobile,AL',
                currentSong: 'On Air:  ',
                url: 'http://radio.weatherusa.net:80/NWR/KEC61_2.mp3'
            },
            {
                name: 'Nashville TN NOAA Weather Radio',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/KIG79.mp3'
            },
            {
                name: 'KGG68 Tomball TX',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/KGG68.mp3'
            },
            {
                name: 'weatherUSA',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/KHB41_2.mp3'
            },
            {
                name: 'Des Moines, Weather Radio',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/WXL57.mp3'
            },
            {
                name: 'Oklahoma City, OK Weather Radio',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/WXK85.mp3'
            },
            {
                name: 'Manassas VA Weather Radio KHB36',
                currentSong: 'On Air: ',
                url: 'http://stream.mikev.com:80/khb36.mp3'
            },
            {
                name: 'NWR WXK30, College Station, TX',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/WXK30.mp3'
            },
            {
                name: 'Sacramento KEC57 WxRadio',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/KEC57.mp3'
            },
            {
                name: 'weatherUSA',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/KIH42_2.mp3'
            },
            {
                name: 'Omaha, Nebraska Weather Radio',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/KIH61.mp3'
            },
            {
                name: 'Hayden M',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/WWF56_2.mp3'
            },
            {
                name: 'Riverview-FL-KHB-32.mp3',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/KHB32.mp3'
            },
            {
                name: 'Minneapolis/St. Paul, MN Weather Radio',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/KEC65.mp3'
            },
            {
                name: 'Falmouth, ME - KDO95',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/KDO95.mp3'
            },
            {
                name: 'Menomonie Weather Radio',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/WXJ88.mp3'
            },
            {
                name: 'Friend, Nebraska Weather Radio',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/KZZ69.mp3'
            },
            {
                name: 'WXL37',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/WXL37.mp3'
            },
            {
                name: 'Clearwater, MN NOAA Weather Radio',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/WNG676.mp3'
            },
            {
                name: 'WXK63',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/WXK63.mp3'
            },
            {
                name: '162.550 KHB37 Wakefield, VA',
                currentSong: 'On Air: ',
                url: 'http://radio.weatherusa.net:80/NWR/KHB37_3.mp3'
            },
            {
                name: 'NKUB-HD2 Los Angeles',
                currentSong: 'On Air: [03:48 AM] NKUB-HD2',
                url: 'http://radio.1007thecube.com:8000/nkub-hd2.aac'
            }
        ];
    },
    get EDMData() {
        return [
            {
                name: 'OnlineDJRadio192',
                currentSong: 'On Air: Tom Enzy - No Scrubs (Radio Edit with Artist ID)',
                url: 'http://play-radio11.jump.bg:8000/autodj'
            },
            {
                name: 'H A P P Y H A R D C O R E - HappyHardcore.com DJ Mixes, UK Happy Hardcore, NuNRG & oldskool',
                currentSong: 'On Air: Yes ii & FNKTION II - The Bounce Generation Volume 24',
                url: 'http://streams.radiomast.io/73055724-1141-41e2-a69b-24a6ca96c8e7'
            },
            {
                name: 'ADR.FM - Electronic Dance Experience (EDE)',
                currentSong: 'On Air: Gryffin ft. ZOHARA - Remember',
                url: 'http://patmos.cdnstream.com:9683/stream2'
            },
            {
                name: 'OnlineDJRadio64',
                currentSong: 'On Air: Enei Hyroglifics - Never Tell Me Original Mix',
                url: 'http://play-radio11.jump.bg:8000/stream64_autodj'
            },
            {
                name: 'Massive Dance Radio',
                currentSong: 'On Air: Billen Ted, TeeDee, Sissy Ford - I Love You',
                url: 'http://kathy.torontocast.com:4400/stream'
            },
            {
                name: 'The EDM MEGASHUFFLE',
                currentSong: 'On Air: Kylie Minogue - Come Into My World - Single  ',
                url: 'http://maggie.torontocast.com:19030/stream'
            },
            {
                name: '109 FM',
                currentSong: 'On Air: Qudu - Essence Of The Night Original Mix',
                url: 'http://solid48.streamupsolutions.com:8077/109fm_autodj'
            },
            {
                name: 'GANORIUM Radio \u2013 100% Real Trance',
                currentSong: 'On Air: DJ Eco - Light at the End (Lost World Remix, Martin Roth Edit)',
                url: 'https://stream.ganorium.com'
            },
            {
                name: 'RAW FM - Australia\'s Leading Dance Music Radio Station',
                currentSong: 'On Air: ',
                url: 'http://asfe.stream.xy.to:6060/syd-stream-192k.mp3'
            },
            {
                name: 'DnB&EDM',
                currentSong: 'On Air: Illenium & Said The Sky - Where\'d U Go',
                url: 'https://edmdnb.com:448/listen/dnb_edm/radio.mp3'
            },
            {
                name: 'RAW FM - Australia\'s Leading Dance Music Radio Station',
                currentSong: 'On Air: ',
                url: 'http://asfe.stream.xy.to:6060/syd-stream-64k.mp3'
            },
            {
                name: 'Pidi Radio Your LGBTQ Radio',
                currentSong: 'On Air: Becky Hill - Never Be Alone',
                url: 'https://azuracast.pidiradio.nl/listen/pidi_radio/radio.aac'
            },
            {
                name: 'RAW FM - Australia\'s Leading Dance Music Radio Station',
                currentSong: 'On Air: ',
                url: 'http://asfe.stream.xy.to:6060/syd-stream-192k.aac'
            },
            {
                name: 'RADIOEX',
                currentSong: 'On Air: AutoDJ: Hits 90\'s - Edition \u21161',
                url: 'http://globalic.stream:1530/stream'
            },
            {
                name: 'THE BLAST BLENDER 128 kbps Hi-Fi Christian Hot CHR',
                currentSong: 'On Air: Faith Massive - Possibilities',
                url: 'http://theblender-stream.theblast.fm.fastserv.com:80/128'
            },
            {
                name: 'BEST Radio (128Kbps)',
                currentSong: 'On Air: Andy Moor feat. Sue McLaren - Trespass (Lemon & Einar K Radio Edit)',
                url: 'http://stream.radiobest.eu:8000/128'
            },
            {
                name: 'Air Connect Radio',
                currentSong: 'On Air: Miley Cyrus / Stevie Nicks - Midnight Sky (Edge of Midnight) (feat. Stevie Nicks)',
                url: 'http://stream.airconnectradio.com:9003/ac192.mp3'
            },
            {
                name: 'JR.FM Vocal House Radio',
                currentSong: 'On Air: Selva, VINAI, Dubdogz, Malou - I Don\'t Mind (Extended Mix)  ',
                url: 'http://s2.stationplaylist.com:7064/listen.mp3'
            },
            {
                name: '06- Radio Te Amo',
                currentSong: 'On Air: Unknown - Rojo Hasta Que No Respire Más',
                url: 'http://radio.produccionescasaverde.com:8700/rta_autodj'
            },
            {
                name: 'BEST Radio (192Kbps)',
                currentSong: 'On Air: Andy Moor feat. Sue McLaren - Trespass (Lemon & Einar K Radio Edit)',
                url: 'http://stream.radiobest.eu:8000/192'
            },
            {
                name: 'Mangialsonic Radio',
                currentSong: 'On Air: MangialSonic Radio',
                url: 'http://www.mangialsonic.com.ar:8020/chm.mp3'
            },
            {
                name: 'THE BLAST BLENDER Hi Fi Christian Hot CHR at 64 kbps ',
                currentSong: 'On Air: Faith Massive - Possibilities',
                url: 'http://theblender-stream.theblast.fm.fastserv.com:80/64'
            },
            {
                name: 'EDR',
                currentSong: 'On Air: Electronic Dance Radio',
                url: 'http://nrf1.newradio.it:10464/stream'
            },
            {
                name: '24/7 EDM Radio',
                currentSong: 'On Air: AutoDJ: Kayser Medienverlag - kmedien10066',
                url: 'http://ec6.yesstreaming.net:1450/stream'
            },
            {
                name: 'MYHITMUSIC! RADIO -  ENCORE DANCE',
                currentSong: 'On Air: TRIGGER4 MP - MyHitMusic',
                url: 'http://151.80.43.143:8020/-aac_autodj.mp3'
            },
            {
                name: 'R5K',
                currentSong: 'On Air: Krewella - Alive',
                url: 'http://azuracast.horus.ca.deck8.net:8000/radio.mp3'
            },
            {
                name: 'BEST Radio (28Kbps)',
                currentSong: 'On Air: Andy Moor feat. Sue McLaren - Trespass (Lemon & Einar K Radio Edit)',
                url: 'http://stream.radiobest.eu:8000/28'
            },
            {
                name: 'KOBV-LP Bentonville Community Radio',
                currentSong: 'On Air: Andy Bey - Never Let Me Go ',
                url: 'http://s2.stationplaylist.com:7058/listen.aac'
            },
            {
                name: 'MangialSonic Radio',
                currentSong: 'On Air: ',
                url: 'http://www.mangialsonic.com.ar:8020/chm'
            },
            {
                name: 'AmpUpRadio',
                currentSong: 'On Air: OneRepublic - Run [AmpUpRadio]',
                url: 'http://stream.ampupradio.com/tophits.mp3'
            }
        ];
    },
    getPreType: function (r) {
        const e = {
            Pop: this.PopData,
            'Hip-hop%2FRap': this.HipData,
            Rock: this.RockData,
            Country: this.CountryData,
            'Dance%20&%20Electronic': this.DanceData,
            'Soul%20R&B': this.SoulData,
            Latin: this.LatinData,
            Classical: this.ClassicalData,
            Jazz: this.JazzData,
            Blues: this.BluesData,
            Indie: this.IndieData,
            Alternative: this.AlternativeData,
            Metal: this.MetalData,
            Reggae: this.ReggaeData,
            Gospel: this.GospelData,
            Punk: this.PunkData,
            Folk: this.FolkData,
            'World%20Music': this.WorldData,
            'Easy%20Listening': this.EasyData,
            Oldies: this.OldiesData,
            Talk: this.TalkData,
            News: this.NewsData,
            Comedy: this.ComedyData,
            Weather: this.WeatherData,
            EDM: this.EDMData
        };
        return e[r];
    }
};
window.PreLoadModule = PreLoadModule;