var FLACMetadata = function () {
    var INTFIELDS = [
        'tracknum',
        'trackcount',
        'discnum',
        'disccount'
    ];
    var FLACFIELDS = {
        title: 'title',
        artist: 'artist',
        album: 'album',
        tracknumber: 'tracknum',
        tracktotal: 'trackcount',
        discnumber: 'discnum',
        disctotal: 'disccount'
    };
    function parse(blobview, metadata) {
        blobview.seek(4);
        return new Promise((resolve, reject) => {
            metadata.tag_format = 'flac';
            var hasVorbisComment = false;
            var hasPicture = false;
            function processBlock(block) {
                if (!block) {
                    resolve(metadata);
                    return false;
                }
                if (block.blockType === 4) {
                    readAllComments(block.view, metadata);
                    hasVorbisComment = true;
                } else if (block.blockType === 6) {
                    LazyLoader.load('js/metadata/vorbis_picture.js', () => {
                        metadata.picture = VorbisPictureComment.readPicFrame(block.view);
                        metadata.picture.start += block.view.viewOffset;
                        metadata.picture.end += block.view.viewOffset;
                    });
                    hasPicture = true;
                }
                return !hasVorbisComment || !hasPicture;
            }
            findMetadataBlocks(blobview, processBlock);
        });
    }
    function findMetadataBlocks(blobview, callback) {
        readMetadataBlockHeader(blobview).then(block => {
            if (!callback(block) || block.last) {
                callback(null);
            } else {
                block.view.advance(block.length - block.view.index);
                findMetadataBlocks(block.view, callback);
            }
        }).catch(err => {
            console.error('Error finding FLAC metadata:', err);
            callback(null);
        });
    }
    function readMetadataBlockHeader(blobview) {
        return new Promise((resolve, reject) => {
            var header = blobview.readUnsignedByte();
            var last = (header & 128) === 128;
            var blockType = header & 127;
            var length = blobview.readUint24(false);
            blobview.getMore(blobview.viewOffset + blobview.index, length + 4, (more, err) => {
                if (err) {
                    reject(err);
                    return;
                }
                resolve({
                    last: last,
                    blockType: blockType,
                    length: length,
                    view: more
                });
            });
        });
    }
    function readAllComments(page, metadata) {
        var vendorStringLength = page.readUnsignedInt(true);
        page.advance(vendorStringLength);
        var numComments = page.readUnsignedInt(true);
        var seenFields = {};
        for (var i = 0; i < numComments; i++) {
            try {
                var comment = readComment(page);
                if (comment) {
                    if (Object.prototype.hasOwnProperty.call(seenFields, comment.field)) {
                        metadata[comment.field] += ' / ' + comment.value;
                    } else {
                        metadata[comment.field] = comment.value;
                        seenFields[comment.field] = true;
                    }
                }
            } catch (e) {
                console.warn('Error parsing ogg metadata frame', e);
            }
        }
        return metadata;
    }
    function readComment(page) {
        var commentLength = page.readUnsignedInt(true);
        var comment = page.readUTF8Text(commentLength);
        var equal = comment.indexOf('=');
        if (equal === -1) {
            throw new Error('missing delimiter in comment');
        }
        var fieldname = comment.substring(0, equal).toLowerCase().replace(' ', '');
        var propname = FLACFIELDS[fieldname];
        if (propname) {
            var value = comment.substring(equal + 1);
            if (INTFIELDS.indexOf(propname) !== -1) {
                value = parseInt(value, 10);
            }
            return {
                field: propname,
                value: value
            };
        }
        return null;
    }
    return { parse: parse };
}();