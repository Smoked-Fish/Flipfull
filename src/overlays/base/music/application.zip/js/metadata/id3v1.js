var ID3v1Metadata = function () {
    function parse(blobview, metadata) {
        var blob = blobview.blob;
        return new Promise((resolve, reject) => {
            BlobView.get(blob, blob.size - 128, 128, (footer, error) => {
                if (error) {
                    reject(error);
                    return;
                }
                try {
                    var magic = footer.getASCIIText(0, 3);
                    if (magic === 'TAG') {
                        resolve(parseID3v1Metadata(footer, metadata));
                    } else {
                        resolve(metadata);
                    }
                } catch (e) {
                    reject(e);
                }
            });
        });
    }
    function parseID3v1Metadata(footer, metadata) {
        let album, artist, title;
        if (footer.getUint8(3) > 128) {
            title = footer.getGBKText(3, 30);
            artist = footer.getGBKText(33, 30);
            album = footer.getGBKText(63, 30);
        } else {
            title = footer.getASCIIText(3, 30);
            artist = footer.getASCIIText(33, 30);
            album = footer.getASCIIText(63, 30);
        }
        var p = title.indexOf('\0');
        if (p !== -1) {
            title = title.substring(0, p);
        }
        p = artist.indexOf('\0');
        if (p !== -1) {
            artist = artist.substring(0, p);
        }
        p = album.indexOf('\0');
        if (p !== -1) {
            album = album.substring(0, p);
        }
        metadata.tag_format = 'id3v1';
        metadata.title = title || undefined;
        metadata.artist = artist || undefined;
        metadata.album = album || undefined;
        var b1 = footer.getUint8(125);
        var b2 = footer.getUint8(126);
        if (b1 === 0 && b2 !== 0) {
            metadata.tracknum = b2;
        }
        return metadata;
    }
    return { parse: parse };
}();