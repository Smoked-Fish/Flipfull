var ID3v2Metadata = function () {
    var ID3V2FRAMES = {
        TPE1: 'artist',
        TP1: 'artist',
        TALB: 'album',
        TAL: 'album',
        TIT2: 'title',
        TT2: 'title',
        TRCK: 'tracknum',
        TRK: 'tracknum',
        TPOS: 'discnum',
        TPA: 'discnum',
        APIC: 'picture',
        PIC: 'picture'
    };
    var ID3V2SECONDARYFRAMES = {
        TRCK: 'trackcount',
        TRK: 'trackcount',
        TPOS: 'disccount',
        TPA: 'disccount'
    };
    function parse(blobview, metadata) {
        var header = parseHeader(blobview);
        if (header.version > 4) {
            console.warn('mp3 file with unknown metadata version');
            return Promise.resolve(metadata);
        }
        metadata.tag_format = header.versionString;
        return new Promise((resolve, reject) => {
            blobview.getMore(blobview.index, header.length, (moreview, err) => {
                if (err) {
                    reject(err);
                    return;
                }
                try {
                    parseFrames(header, moreview, metadata);
                    resolve(metadata);
                } catch (e) {
                    reject(e);
                }
            });
        });
    }
    function parseHeader(blobview) {
        blobview.seek(3);
        var header = {
            get versionString() {
                return 'id3v2.' + this.version + '.' + this.revision;
            },
            get tagUnsynchronized() {
                return (this.flags & 128) !== 0;
            },
            get hasExtendedHeader() {
                return (this.flags & 64) !== 0;
            }
        };
        header.version = blobview.readUnsignedByte();
        header.revision = blobview.readUnsignedByte();
        header.flags = blobview.readUnsignedByte();
        header.length = blobview.readID3Uint28BE();
        return header;
    }
    function parseFrames(header, blobview, metadata) {
        if (header.tagUnsynchronized && header.version === 3) {
            blobview = deunsync(blobview, header.length);
        }
        if (header.hasExtendedHeader) {
            var extendedHeaderSize;
            if (header.version === 4) {
                extendedHeaderSize = blobview.readID3Uint28BE() - 4;
            } else {
                extendedHeaderSize = blobview.readUnsignedInt();
            }
            blobview.advance(extendedHeaderSize);
        }
        while (blobview.index < blobview.byteLength) {
            if (blobview.getUint8(blobview.index) === 0) {
                break;
            }
            parseFrame(header, blobview, metadata);
        }
    }
    function parseFrame(header, blobview, metadata) {
        var frameUnsynchronized = false, frameflags, frameid, framesize;
        switch (header.version) {
        case 2:
            frameid = blobview.readASCIIText(3);
            framesize = blobview.readUint24();
            frameflags = 0;
            break;
        case 3:
            frameid = blobview.readASCIIText(4);
            framesize = blobview.readUnsignedInt();
            frameflags = blobview.readUnsignedShort();
            break;
        case 4:
            frameid = blobview.readASCIIText(4);
            framesize = blobview.readID3Uint28BE();
            frameflags = blobview.readUnsignedShort();
            frameUnsynchronized = (frameflags & 2) !== 0;
            break;
        default:
        }
        var nextframe = blobview.index + framesize;
        var propname = ID3V2FRAMES[frameid];
        if (!propname) {
            blobview.seek(nextframe);
            return;
        }
        if ((frameflags & 253) !== 0) {
            console.warn('Skipping', frameid, 'frame with flags', frameflags);
            blobview.seek(nextframe);
            return;
        }
        try {
            var framevalue, frameview;
            if (frameUnsynchronized) {
                frameview = deunsync(blobview, framesize);
                framesize = frameview.sliceLength;
            } else {
                frameview = blobview;
            }
            switch (frameid) {
            case 'TPE1':
            case 'TP1':
            case 'TALB':
            case 'TAL':
            case 'TIT2':
            case 'TT2':
                framevalue = readTextFrame(header, frameview, framesize);
                break;
            case 'TRCK':
            case 'TRK':
            case 'TPOS':
            case 'TPA':
                framevalue = readNumericPairFrame(header, frameview, framesize);
                if (framevalue[1] !== null) {
                    metadata[ID3V2SECONDARYFRAMES[frameid]] = framevalue[1];
                }
                framevalue = framevalue[0];
                break;
            case 'APIC':
            case 'PIC':
                framevalue = readPicFrame(header, frameview, framesize);
                break;
            default:
                console.error('Should not have gotten here');
            }
            if (framevalue) {
                metadata[propname] = framevalue;
            }
        } catch (e) {
            console.warn('Error parsing mp3 metadata frame', frameid, ':', e);
        }
        blobview.seek(nextframe);
    }
    function deunsync(view, framesize) {
        var data = new Uint8Array(framesize);
        var was0xff = false;
        var dataIndex = 0;
        for (var i = 0; i < framesize; i++) {
            var b = view.readUnsignedByte();
            if (was0xff && b === 0) {
                continue;
            }
            was0xff = b === 255;
            data[dataIndex++] = b;
        }
        var deunsyncedView = new BlobView.getFromArrayBuffer(data.buffer, 0, dataIndex, view.littleEndian);
        deunsyncedView.deunsynced = true;
        return deunsyncedView;
    }
    function readTextFrame(header, view, size, encoding) {
        if (encoding === undefined) {
            encoding = view.readUnsignedByte();
            size -= 1;
        }
        if (encoding === 0 && view.getUint8(view.index) > 128) {
            return view.readGBKText(size);
        }
        if (header.version === 4) {
            return readEncodedTextArray(view, size, encoding);
        }
        return readEncodedText(view, size, encoding);
    }
    function readNumericPairFrame(header, view, size, encoding) {
        var text = readTextFrame(header, view, size, encoding);
        var pair = text.split('/', 2).map(val => {
            var i = parseInt(val, 10);
            return isNaN(i) || !isFinite(i) ? null : i;
        });
        if (pair.length === 1) {
            pair.push(null);
        }
        return pair;
    }
    function readPicFrame(header, view, size) {
        var start = view.index;
        var encoding = view.readUnsignedByte();
        var mimetype;
        if (header.version === 2) {
            mimetype = view.readASCIIText(3);
            if (mimetype === 'JPG') {
                mimetype = 'image/jpeg';
            } else if (mimetype === 'PNG') {
                mimetype = 'image/png';
            }
        } else {
            mimetype = view.readNullTerminatedLatin1Text(size - 1);
        }
        view.readUnsignedByte();
        readEncodedText(view, size - (view.index - start), encoding);
        var picstart = view.sliceOffset + view.viewOffset + view.index;
        var picsize = size - (view.index - start);
        var picend = picstart + picsize;
        if (view.deunsynced) {
            return {
                flavor: 'unsynced',
                blob: new Blob([view.buffer.slice(picstart, picend)], { type: mimetype })
            };
        }
        return {
            flavor: 'embedded',
            start: picstart,
            end: picend,
            type: mimetype
        };
    }
    function readEncodedTextArray(view, size, encoding) {
        var text;
        switch (encoding) {
        case 0:
            text = view.readASCIIText(size);
            break;
        case 1:
            text = view.readUTF16Text(size, undefined);
            break;
        case 2:
            text = view.readUTF16Text(size, false);
            break;
        case 3:
            text = view.readUTF8Text(size);
            break;
        default:
            throw Error('unknown text encoding');
        }
        return text.replace(/\0+$/, '').replace('\0', ' / ');
    }
    function readEncodedText(view, size, encoding) {
        switch (encoding) {
        case 0:
            return view.readNullTerminatedLatin1Text(size);
        case 1:
            return view.readNullTerminatedUTF16Text(size, undefined);
        case 2:
            return view.readNullTerminatedUTF16Text(size, false);
        case 3:
            return view.readNullTerminatedUTF8Text(size);
        default:
            throw Error('unknown text encoding');
        }
    }
    return { parse: parse };
}();