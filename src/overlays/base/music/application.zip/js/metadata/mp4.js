var MP4Metadata = function () {
    var MP4ATOMS = {
        '\xA9alb': 'album',
        '\xA9art': 'artist',
        '\xA9ART': 'artist',
        'aART': 'artist',
        '\xA9nam': 'title',
        'trkn': 'tracknum',
        'disk': 'discnum',
        'covr': 'picture'
    };
    var MP4INTPAIRATOMS = {
        'trkn': 'trackcount',
        'disk': 'disccount'
    };
    var MP4Types = {
        'M4A ': true,
        'M4B ': true,
        'mp41': true,
        'mp42': true,
        'isom': true,
        'iso2': true
    };
    var MP4Codecs = {
        'mp4a': true,
        'samr': true,
        'sawb': true,
        'sawp': true
    };
    function parse(blobview, metadata) {
        if (!checkMP4Type(blobview, MP4Types)) {
            return Promise.reject(new Error('Unknown MP4 file type'));
        }
        metadata.tag_format = 'mp4';
        return findMoovAtom(blobview, metadata).then(result => {
            if (!result) {
                throw Error('No playable streams.');
            }
            return parseMoovAtom(result.atom, result.size, metadata);
        });
    }
    function checkMP4Type(blobview, types) {
        var majorbrand = blobview.getASCIIText(8, 4);
        if (majorbrand in types) {
            return true;
        }
        var index = 16;
        var size = blobview.getUint32(0);
        while (index < size) {
            var compatiblebrand = blobview.getASCIIText(index, 4);
            index += 4;
            if (compatiblebrand in types) {
                return true;
            }
        }
        return false;
    }
    function findMoovAtom(atom) {
        return new Promise((resolve, reject) => {
            var offset = atom.sliceOffset + atom.viewOffset;
            var size = atom.readUnsignedInt();
            var type = atom.readASCIIText(4);
            if (size === 0) {
                size = atom.blob.size - offset;
            } else if (size === 1) {
                size = atom.readUnsignedInt() * 4294967296 + atom.readUnsignedInt();
            }
            if (type === 'moov') {
                atom.getMore(offset, size, moov => {
                    resolve({
                        atom: moov,
                        size: size
                    });
                });
            } else if (offset + size + 16 <= atom.blob.size) {
                atom.getMore(offset + size, 16, moov => {
                    try {
                        findMoovAtom(moov).then(result => {
                            resolve(result);
                        });
                    } catch (e) {
                        reject(e);
                    }
                });
            } else {
                resolve(null);
            }
        });
    }
    function parseMoovAtom(data, end, metadata) {
        data.advance(8);
        while (data.index < end) {
            var size = data.readUnsignedInt();
            var type = data.readASCIIText(4);
            var nextindex = data.index + size - 8;
            if (type === 'udta') {
                parseUdtaAtom(data, end, metadata);
            } else if (type === 'trak') {
                data.advance(-8);
                if (seekChildAtoms(data, [
                        'mdia',
                        'minf'
                    ])) {
                    if (searchChildAtom(data, 'vmhd')) {
                        throw Error('Found video track in MP4 container');
                    }
                    if (searchChildAtom(data, 'smhd')) {
                        if (seekChildAtoms(data, [
                                'stbl',
                                'stsd'
                            ])) {
                            data.advance(20);
                            var codec = data.readASCIIText(4);
                            if (!(codec in MP4Codecs)) {
                                throw Error('Unsupported format in MP4 container: ' + codec);
                            }
                        }
                    }
                } else {
                    throw Error('Not enough metadata in MP4 container!');
                }
            }
            data.seek(nextindex);
        }
        return metadata;
    }
    function seekChildAtoms(data, atoms) {
        return atoms.every(atom => {
            return seekChildAtom(data, atom);
        });
    }
    function seekChildAtom(data, atom) {
        var start = data.index;
        var length = data.readUnsignedInt();
        data.advance(4);
        while (data.index < start + length) {
            var size = data.readUnsignedInt();
            var type = data.readASCIIText(4);
            if (type === atom) {
                data.advance(-8);
                return true;
            }
            data.advance(size - 8);
        }
        return false;
    }
    function searchChildAtom(data, atom) {
        var start = data.index;
        var result = seekChildAtom(data, atom);
        data.seek(start);
        return result;
    }
    function parseUdtaAtom(data, end, metadata) {
        while (data.index < end) {
            var size = data.readUnsignedInt();
            var type = data.readASCIIText(4);
            if (type === 'meta') {
                parseMetaAtom(data, data.index + size - 8, metadata);
                data.seek(end);
                return;
            }
            data.advance(size - 8);
        }
    }
    function parseMetaAtom(data, end, metadata) {
        data.advance(4);
        while (data.index < end) {
            var size = data.readUnsignedInt();
            var type = data.readASCIIText(4);
            if (type === 'ilst') {
                parseIlstAtom(data, data.index + size - 8, metadata);
                data.seek(end);
                return;
            }
            data.advance(size - 8);
        }
    }
    function parseIlstAtom(data, end, metadata) {
        while (data.index < end) {
            var size = data.readUnsignedInt();
            var type = data.readASCIIText(4);
            var next = data.index + size - 8;
            var propname = MP4ATOMS[type];
            if (propname) {
                try {
                    var value = getMetadataValue(data, next, type);
                    if (type in MP4INTPAIRATOMS) {
                        metadata[propname] = value.number;
                        if (value.count) {
                            metadata[MP4INTPAIRATOMS[type]] = value.count;
                        }
                    } else {
                        metadata[propname] = value;
                    }
                } catch (e) {
                    console.warn('skipping', type, ':', e);
                }
            }
            data.seek(next);
        }
    }
    function getMetadataValue(data, end, atomtype) {
        while (data.index < end) {
            var size = data.readUnsignedInt();
            var type = data.readASCIIText(4);
            if (type !== 'data') {
                data.advance(size - 8);
                continue;
            }
            var datatype = data.readUnsignedInt() & 16777215;
            data.advance(4);
            var datasize = size - 16;
            if (atomtype in MP4INTPAIRATOMS) {
                data.advance(2);
                var number = data.readUnsignedShort();
                var count = data.readUnsignedShort();
                return {
                    number: number,
                    count: count
                };
            }
            switch (datatype) {
            case 1:
                return data.readUTF8Text(datasize);
            case 13:
                return {
                    flavor: 'embedded',
                    start: data.sliceOffset + data.viewOffset + data.index,
                    end: data.sliceOffset + data.viewOffset + data.index + datasize,
                    type: 'image/jpeg'
                };
            case 14:
                return {
                    flavor: 'embedded',
                    start: data.sliceOffset + data.viewOffset + data.index,
                    end: data.sliceOffset + data.viewOffset + data.index + datasize,
                    type: 'image/png'
                };
            default:
                throw Error('unexpected type in data atom');
            }
        }
        throw Error('no data atom found');
    }
    return { parse: parse };
}();