var OggMetadata = function () {
    var INTFIELDS = [
        'tracknum',
        'trackcount',
        'discnum',
        'disccount'
    ];
    var OGGFIELDS = {
        title: 'title',
        artist: 'artist',
        album: 'album',
        tracknumber: 'tracknum',
        tracktotal: 'trackcount',
        discnumber: 'discnum',
        disctotal: 'disccount',
        metadata_block_picture: 'picture'
    };
    function EndOfPageError() {
    }
    function parse(blobview, metadata) {
        readIdentificationHeader(blobview);
        return readCommentHeader(blobview, metadata);
    }
    function readIdentificationHeader(page) {
        var header = readPageHeader(page);
        if (header.segmentTable.length !== 1) {
            throw new Error('ogg identification header expected as only packet of first page');
        }
        page.advance(header.segmentTable[0]);
    }
    function readCommentHeader(page, metadata) {
        var header = readPageHeader(page);
        var sum = function (a, b) {
            return a + b;
        };
        var commentLength = header.segmentTable.reduce(sum, 0);
        return new Promise((resolve, reject) => {
            page.getMore(page.index, commentLength, (fullpage, err) => {
                if (err) {
                    reject(err);
                    return;
                }
                try {
                    var firstByte = fullpage.readByte();
                    var valid = false;
                    switch (firstByte) {
                    case 3:
                        valid = fullpage.readASCIIText(6) === 'vorbis';
                        metadata.tag_format = 'vorbis';
                        break;
                    case 79:
                        valid = fullpage.readASCIIText(7) === 'pusTags';
                        metadata.tag_format = 'opus';
                        break;
                    default:
                        break;
                    }
                    if (!valid) {
                        reject(new Error('malformed ogg comment packet'));
                        return;
                    }
                    readAllComments(fullpage, metadata);
                    LazyLoader.load('js/metadata/vorbis_picture.js', () => {
                        VorbisPictureComment.parsePictureComment(metadata).then(resolve);
                    });
                } catch (e) {
                    reject(e);
                }
            });
        });
    }
    function readPageHeader(page) {
        var capturePattern = page.readASCIIText(4);
        if (capturePattern !== 'OggS') {
            throw new Error('malformed ogg page header');
        }
        page.advance(22);
        var pageSegments = page.readUnsignedByte();
        var segmentTable = page.readUnsignedByteArray(pageSegments);
        return { segmentTable: segmentTable };
    }
    function readAllComments(page, metadata) {
        var vendorStringLength = page.readUnsignedInt(true);
        page.advance(vendorStringLength);
        var numComments = page.readUnsignedInt(true);
        var seenFields = {};
        for (var i = 0; i < numComments; i++) {
            try {
                var comment = readComment(page);
                if (comment) {
                    if (comment.field === 'picture' && !Object.prototype.hasOwnProperty.call(seenFields, comment.field)) {
                        metadata[comment.field] = comment.value;
                        seenFields[comment.field] = true;
                    } else if (Object.prototype.hasOwnProperty.call(seenFields, comment.field)) {
                        metadata[comment.field] += ' / ' + comment.value;
                    } else {
                        metadata[comment.field] = comment.value;
                        seenFields[comment.field] = true;
                    }
                }
            } catch (e) {
                if (e instanceof EndOfPageError) {
                    return;
                }
                console.warn('Error parsing ogg metadata frame', e);
            }
        }
    }
    function readComment(page) {
        if (page.remaining() < 4) {
            throw new EndOfPageError();
        }
        var commentLength = page.readUnsignedInt(true);
        if (commentLength > page.remaining()) {
            throw new EndOfPageError();
        }
        var comment = page.readUTF8Text(commentLength);
        var equal = comment.indexOf('=');
        if (equal === -1) {
            throw new Error('missing delimiter in comment');
        }
        var fieldname = comment.substring(0, equal).toLowerCase().replace(' ', '');
        var propname = OGGFIELDS[fieldname];
        if (propname) {
            var value = comment.substring(equal + 1);
            if (INTFIELDS.indexOf(propname) !== -1) {
                value = parseInt(value, 10);
            }
            return {
                field: propname,
                value: value
            };
        }
    }
    return { parse: parse };
}();