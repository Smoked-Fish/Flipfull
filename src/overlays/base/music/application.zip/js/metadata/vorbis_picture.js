var VorbisPictureComment = function () {
    function readPicFrame(view) {
        var kind = view.readUnsignedInt();
        if (kind != 3) {
            return null;
        }
        var len = view.readUnsignedInt();
        var mimetype = view.readASCIIText(len);
        if (mimetype == '-->') {
            console.error('URL for cover art is not supported from Vorbis comment.');
            return null;
        }
        len = view.readUnsignedInt();
        view.readNullTerminatedUTF8Text(len);
        view.advance(16);
        var piclength = view.readUnsignedInt();
        var picstart = view.index;
        return {
            flavor: 'embedded',
            start: picstart,
            end: picstart + piclength,
            type: mimetype
        };
    }
    function base64DecToArr(sBase64, nBlocksSize) {
        function b64ToUint6(nChr) {
            return nChr > 64 && nChr < 91 ? nChr - 65 : nChr > 96 && nChr < 123 ? nChr - 71 : nChr > 47 && nChr < 58 ? nChr + 4 : nChr === 43 ? 62 : nChr === 47 ? 63 : 0;
        }
        var sB64Enc = sBase64.replace(/[^A-Za-z0-9\+\/]/g, '');
        var nInLen = sB64Enc.length;
        var nOutLen = nBlocksSize ? Math.ceil((nInLen * 3 + 1 >> 2) / nBlocksSize) * nBlocksSize : nInLen * 3 + 1 >> 2;
        var taBytes = new Uint8Array(nOutLen);
        for (var nInIdx = 0, nMod3, nMod4, nOutIdx = 0, nUint24 = 0; nInIdx < nInLen; nInIdx++) {
            nMod4 = nInIdx & 3;
            nUint24 |= b64ToUint6(sB64Enc.charCodeAt(nInIdx)) << 18 - 6 * nMod4;
            if (nMod4 === 3 || nInLen - nInIdx === 1) {
                for (nMod3 = 0; nMod3 < 3 && nOutIdx < nOutLen; nMod3++, nOutIdx++) {
                    taBytes[nOutIdx] = nUint24 >>> (16 >>> nMod3 & 24) & 255;
                }
                nUint24 = 0;
            }
        }
        return taBytes;
    }
    function parsePictureComment(metadata) {
        return new Promise((resolve, reject) => {
            if (!metadata.picture) {
                resolve(metadata);
                return;
            }
            var value = metadata.picture;
            try {
                var binary = base64DecToArr(value);
                var aBlob = new Blob([binary]);
                BlobView.get(aBlob, 0, aBlob.size, (block, err) => {
                    var prop = readPicFrame(block);
                    if (prop) {
                        metadata.picture = {
                            flavor: 'unsynced',
                            blob: aBlob.slice(prop.start, prop.end, prop.type)
                        };
                    }
                    resolve(metadata);
                }, BlobView.bigEndian);
            } catch (e) {
                console.warn('Error parsing picture comment', e.message);
                resolve(metadata);
            }
        });
    }
    return {
        readPicFrame: readPicFrame,
        parsePictureComment: parsePictureComment
    };
}();