const SETTINGS_OPTION_KEY = 'settings_option_key';
const MARQUEE_SPEED = 6 * 1000 / 90;
const MARQUEE_INTERVAL = 0;
var App = function () {
    let bScanning = false;
    let overlay = document.getElementById('overlay');
    let promisePick = null;
    let isShowFullscreenAds = false;
    const isActivity = document.URL.indexOf('#pick') > -1;
    const app = {
        pendingPick: null,
        currentOverlay: null,
        knownSongs: [],
        discover: null,
        appVersion: '3.0.11',
        showOverlay: showOverlay,
        showCorrectOverlay: showCorrectOverlay,
        showCurrentView: showCurrentView
    };
    if (isActivity) {
        promisePick = new Promise(resolve => {
            navigator.serviceWorker.addEventListener('message', ({data}) => {
                const keepSWStateInterval = setInterval(() => {
                    if (navigator.serviceWorker.controller) {
                        navigator.serviceWorker.controller.postMessage({ isDummy: true });
                    } else {
                        console.log('navigator.serviceWorker.controller is null');
                    }
                }, 300000);
                app.pendingPick = data;
                app.pendingPick.postResult = function (data) {
                    navigator.serviceWorker.controller.postMessage({
                        activityHandlerId: this.activityHandlerId,
                        activityResult: data
                    });
                    clearInterval(keepSWStateInterval);
                    window.close();
                };
                resolve();
            });
        });
        window.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                App.pendingPick.postResult({});
            }
        });
    }
    init();
    function init() {
        initOverlay();
        window.api.l10n.once(() => {
            window.performance.mark('navigationLoaded');
            initDB();
            ListView.init();
            SubListView.init();
            SearchView.init();
            TabBar.init();
            setStartMode();
            window.performance.mark('navigationInteractive');
            marquee(MARQUEE_SPEED, MARQUEE_INTERVAL);
            document.addEventListener('visibilitychange', handleVisibilityChange);
            if (!isActivity) {
                ListView.activate({ option: 'playlist' });
                jioDongleStatusListener();
            }
        });
        navigator.b2g.audioChannelManager.volumeControlChannel = 'content';
        const xhr = new XMLHttpRequest();
        xhr.open('GET', '/manifest.webmanifest');
        xhr.send();
        xhr.onload = () => {
            const data = JSON.parse(xhr.response);
            app.appVersion = data.b2g_features.version;
        };
    }
    function setStartMode() {
        if (isActivity) {
            TabBar.option = 'title';
            ModeManager.start(MODE_PICKER);
        } else {
            TabBar.option = 'playlist';
            ModeManager.start(MODE_LIST);
        }
    }
    function initOverlay() {
        overlay.addEventListener('keydown', e => {
            if (e.key === 'Enter' && !bScanning || e.key === 'Backspace' || e.key === 'EndCall') {
                if (app.pendingPick) {
                    e.preventDefault();
                    app.pendingPick.postResult({});
                    return;
                }
                if (typeof getKaiAd === 'function' && e.key !== 'EndCall') {
                    e.preventDefault();
                    const overLay = document.getElementById('overlay');
                    const mainView = document.getElementById('main-view');
                    overLay.classList.add('hidden');
                    mainView.classList.remove('hidden');
                    MainView.switchPage = false;
                    MainView.activate();
                    return;
                }
                if (!window.closeResolve) {
                    new Promise(resolve => {
                        window.closeResolve = resolve;
                    }).then(() => {
                        window.close();
                    });
                }
            } else if (e.key === 'SoftRight') {
                Dialog.show('about-dialog-content-version', { n: app.appVersion }, () => {
                    app.showOverlay('empty');
                }, () => {
                    app.showOverlay('empty');
                }, {
                    headerl10nId: 'about',
                    type: 'hint',
                    secondValue: 'about-dialog-content-developer'
                });
            } else if (e.key !== 'MicrophoneToggle' && e.key !== 'VolumeDown' && e.key !== 'VolumeUp' && e.key !== 'AudioVolumeDown' && e.key !== 'AudioVolumeUp' && e.key !== 'Camera' && e.key !== 'Message') {
                e.preventDefault();
                e.stopPropagation();
            }
        });
        overlay.addEventListener('keyup', e => {
            if (e.key === 'Enter' && !bScanning) {
                if (window.closeResolve) {
                    window.closeResolve = null;
                    window.close();
                }
            }
        });
    }
    function showOverlay(id) {
        bScanning = id === 'scanning';
        if (bScanning) {
            SoftKeyStore.register({ center: '' }, overlay);
        } else {
            SoftKeyStore.register({
                'left': '',
                'center': 'ok',
                'right': 'about'
            }, overlay);
        }
        document.activeElement.blur();
        if (OptionMenu.isActive() && document.activeElement.tagName === 'BODY') {
            OptionMenu.element.focus();
        }
        app.currentOverlay = id;
        function setVisibility(visible) {
            Array.from(document.body.children).forEach(elt => {
                if (elt.id === 'overlay') {
                    elt.classList.toggle('hidden', !visible);
                    visible && elt.focus();
                } else if (elt.id === 'region-views') {
                    elt.classList.toggle('hidden', visible);
                } else {
                    elt.setAttribute('aria-hidden', visible);
                }
            });
        }
        if (id === null) {
            setVisibility(false);
            return;
        }
        let l10nIds = { 'text': id + '-text' };
        let textElement = document.getElementById('overlay-text');
        textElement.dataset.l10nId = l10nIds.text;
        if ('pick-empty' === id) {
            textElement.setAttribute('role', 'option');
            textElement.setAttribute('aria-labelledby', 'title-text overlay-text');
        }
        setVisibility(true);
    }
    function showCorrectOverlay(count) {
        if (typeof count === 'undefined' || count > 0) {
            app.showOverlay(null);
        } else if (reparsingMetadata) {
            app.showOverlay('upgrade');
        } else if (App.pendingPick) {
            app.showOverlay('pick-empty');
        } else {
            app.showOverlay('empty');
        }
    }
    function showCurrentView(callback) {
        LazyLoader.load('js/metadata/album_art.js', () => {
            if (promisePick) {
                promisePick.then(() => {
                    if (ModeManager.currentMode === MODE_PLAYER) {
                        ModeManager.withRefresh = true;
                        if (PlayerView.isGhost) {
                            PlayerView.stop();
                            ModeManager.pop();
                            ListView.resetUI();
                        }
                    } else {
                        ListView.resetUI();
                        callback && callback();
                    }
                });
            } else if (ModeManager.currentMode === MODE_LIST) {
                ListView.resetUI();
                callback && callback();
            } else if (ModeManager.currentMode === MODE_SUBLIST) {
                if (window.localStorage.getItem('musicCount') === '0') {
                    ModeManager.start(MODE_LIST);
                    ListView.resetUI();
                    return;
                }
                ModeManager._modeStack.splice(-1, 1);
                if (SubListView.isInMyPlaylist) {
                    if (promiseUpdate) {
                        promiseUpdate.then(() => {
                            SubListView.activateSubListView();
                        });
                    } else {
                        SubListView.activateSubListView();
                    }
                } else {
                    ListView.activateSubListView();
                }
            }
        });
    }
    function jioDongleStatusListener() {
        if (navigator.dongleManager) {
            navigator.dongleManager.ondonglestatuschange = event => {
                let mode = ModeManager.currentMode;
                if (event.isConnected) {
                    if (mode === MODE_PLAYER) {
                        playByDongle(PlayerView);
                    }
                }
                if (mode === MODE_LIST || mode === MODE_SEARCH_FROM_LIST) {
                    ListView.updateSoftKeys();
                } else if (mode === MODE_SUBLIST || mode === MODE_SUBLIST_LIST || mode === MODE_SEARCH_FROM_SUBLIST) {
                    SubListView.updateSoftKeys();
                }
            };
        }
    }
    function handleVisibilityChange() {
        if (window.closeResolve) {
            return window.closeResolve();
        }
        if (!document.hidden) {
            if (!isShowFullscreenAds) {
                showFullscreenAd();
            }
            if (OptionMenu.isActive() && !Dialog.isActive()) {
                OptionMenu.element.focus();
            } else if (Dialog.isActive() || ModeManager.currentMode === MODE_PLAYER) {
                let oldFocusElement = document.activeElement;
                const targetFocusElement = Dialog.isActive() ? Dialog.element : PlayerView.view;
                const checkFocus = function () {
                    targetFocusElement.removeEventListener('focus', checkFocus);
                    if (document.querySelectorAll(':focus').length > 1 && oldFocusElement.classList.contains('focusable')) {
                        if (oldFocusElement.nodeName === 'INPUT') {
                            oldFocusElement.parentNode.classList.remove('focused');
                        }
                        let cloneNode = oldFocusElement.cloneNode(true);
                        oldFocusElement.parentElement.replaceChild(cloneNode, oldFocusElement);
                        oldFocusElement = null;
                    }
                };
                if (oldFocusElement !== targetFocusElement) {
                    targetFocusElement.addEventListener('focus', checkFocus);
                    targetFocusElement.focus();
                }
            } else if (!Dialog.isActive() && typeof PlayerView !== 'undefined' && PlayerView.playStatus === PLAYSTATUS_STOPPED && ModeManager.currentMode === MODE_LIST) {
                ListView.view.focus();
            }
            if (firstScanDone) {
                musicdb.active = true;
                musicdb.scan();
            }
        }
        if (typeof getKaiAd !== 'function' && document.hidden && typeof PlayerView !== 'undefined' && (PlayerView.playStatus === PLAYSTATUS_PLAYING || PlayerView.playStatus === PLAYSTATUS_PAUSED)) {
            OptionMenu.isActive() && OptionMenu.cancel();
            Dialog.isActive() && Dialog.cancel();
            if (isDongleConnect()) {
                return;
            }
            ModeManager._modeStack = [
                MODE_LIST,
                MODE_PLAYER
            ];
            ModeManager._updateMode();
            ModeManager.clearState();
        }
    }
    return app;
}();