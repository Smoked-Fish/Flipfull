const BANNER_AD_STATES = {
    NOT_INITIALIZED: 'NOT_INITIALIZED',
    ERROR: 'ERROR',
    LOADING: 'LOADING',
    READY: 'READY'
};
const FULL_COLLAPSE_ANIMATION_DURATION_MS = 500;
var BannerAd = {
    get container() {
        return document.getElementById('banner-ad-container');
    },
    get placeholder() {
        return document.getElementById('banner-ad-placeholder');
    },
    isBannerAdNode(node) {
        return node === this.container || node === this.placeholder;
    },
    setState(state) {
        const asyncEffects = this.state === BANNER_AD_STATES.LOADING && state === BANNER_AD_STATES.ERROR ? this.collapsePlaceholder() : Promise.resolve();
        asyncEffects.then(() => {
            setElClassesByCond({
                'banner-ad-loading': state === BANNER_AD_STATES.LOADING,
                'banner-ad-loaded': state === BANNER_AD_STATES.READY
            }, this.container.parentElement);
            setElClassesByCond({ focusable: state === BANNER_AD_STATES.READY }, this.container);
        });
        this.state = state;
    },
    init: function bannerAd_init() {
        this.initialized = true;
        this.rowHeight = 60;
        this.container.addEventListener('keydown', e => this.onKeydown(e));
        SoftKeyStore.register({
            left: 'opt-player',
            center: 'go',
            right: ''
        }, this.container);
        if (typeof getKaiAd !== 'function') {
            return;
        }
        getKaiAd({
            app: 'Music',
            publisher: 'e6dfb88f-ca58-4816-85ad-27eb07964d34',
            container: this.container,
            slot: 'musicBannerAd',
            h: 60,
            w: 240,
            timeout: 10000,
            blacklistCache: {
                ttl: 24 * 3600,
                initiallyHideAd: true
            },
            onloadstart: () => {
                this.setState(BANNER_AD_STATES.LOADING);
            },
            onerror: err => {
                console.error('bannerAd error:', err);
                this.setState(BANNER_AD_STATES.ERROR);
            },
            onready: ad => {
                this.ad = ad;
                this.setState(BANNER_AD_STATES.READY);
                ad.call('display', {});
            }
        });
    },
    onKeydown: function bannerAd_onKeydown(e) {
        switch (e.key) {
        case 'Enter':
            if (this.ad) {
                this.ad.call('click');
            }
            e.stopPropagation();
            break;
        case 'SoftRight':
            e.stopPropagation();
            break;
        default:
            break;
        }
    },
    collapsePlaceholder() {
        const visibleHeight = this.rowHeight - this.container.parentElement.scrollTop;
        const collapseAnimation = visibleHeight > 0 ? this.animatePlaceholderCollapse(visibleHeight) : Promise.resolve();
        return collapseAnimation.then(() => {
            this.container.parentElement.scrollTop -= this.rowHeight;
        });
    },
    animatePlaceholderCollapse(visibleHeight) {
        const visibleRatio = visibleHeight / this.rowHeight;
        const duration = FULL_COLLAPSE_ANIMATION_DURATION_MS * visibleRatio;
        this.placeholder.style.transition = `margin-top ${ duration / 1000 }s ease-out`;
        this.placeholder.style.marginTop = -visibleHeight + 'px';
        return new Promise(resolve => setTimeout(resolve, duration));
    }
};