var TAB_PLAYLISTS = 'tabs-playlists';
var TAB_ARTISTS = 'tabs-artists';
var TAB_ALBUM = 'tabs-albums';
var TAB_SONGS = 'tabs-songs';
var TabBar = {
    optionsList: [
        'playlist',
        'artist',
        'album',
        'title'
    ],
    tabList: [
        TAB_PLAYLISTS,
        TAB_ARTISTS,
        TAB_ALBUM,
        TAB_SONGS
    ],
    get size() {
        return this.optionsList.length;
    },
    set option(choice) {
        this._option = choice;
    },
    isRtl: () => 'rtl' === document.documentElement.dir || 'rtl' === document.dir,
    get option() {
        if (ModeManager.currentMode === MODE_SEARCH_FROM_LIST_PICK) {
            return 'title';
        }
        return this._option;
    },
    get activeTab() {
        return this._activeTab;
    },
    set activeTab(index) {
        var size = this.size;
        if (index < 0) {
            index = size - 1;
        } else if (index >= size) {
            index = 0;
        }
        this._activeTab = index;
        this.tab.select(index);
        this.anchors[this.activeTab].classList.remove('hidden');
        this.changePanel(this.tabList[index]);
    },
    get activateId() {
        return this.anchors[this.activeTab].id;
    },
    clearAll: function () {
        for (var i = 0; i < this.size; i++) {
            this.anchors[i].classList.add('hidden');
        }
    },
    back: function () {
        this.activeTab = this.isRtl() ? this.activeTab + 1 : this.activeTab - 1;
    },
    next: function () {
        this.activeTab = this.isRtl() ? this.activeTab - 1 : this.activeTab + 1;
    },
    init: function tabInit() {
        this.option = 'title';
        this.anchors = document.querySelectorAll('gaia-tabs a');
        this.tab = document.getElementById('tabs');
        this._activeTab = 0;
        this.onKeyDown = this.onKeyDown.bind(this);
        window.addEventListener('keydown', this.onKeyDown);
    },
    onKeyDown: function (evt) {
        if (!MainView.switchPage) {
            return;
        }
        if (ModeManager.currentMode !== MODE_LIST || document.activeElement === ListView.searchInput && ListView.searchInput.value !== '') {
            return;
        }
        if (OptionMenu.isActive() || Dialog.isActive() || ListView.showLoading) {
            return;
        }
        switch (evt.key) {
        case 'ArrowLeft':
            if (!OptionMenu.isActive()) {
                this.back();
            }
            break;
        case 'ArrowRight':
            if (!OptionMenu.isActive()) {
                this.next();
            }
            break;
        default:
            break;
        }
    },
    changePanel: function (viewName) {
        if (this.option != this.optionsList[this.activeTab]) {
            this.option = this.optionsList[this.activeTab];
            if (!SearchView.searchListView.classList.contains('hidden')) {
                ListView.searchInput.value = '';
                ListView.anchor.classList.remove('hidden');
                document.body.classList.remove('search-from-sublist-mode');
                SearchView.searchListView.classList.add('search-from-list-mode');
            }
        }
        switch (viewName) {
        case TAB_PLAYLISTS:
            ModeManager.start(MODE_LIST);
            ListView.activate({ option: this.option });
            document.querySelector('#views-list').classList.add(TAB_PLAYLISTS);
            break;
        case TAB_ARTISTS:
        case TAB_ALBUM:
        case TAB_SONGS:
            document.querySelector('#views-list').classList.remove(TAB_PLAYLISTS);
            var info = {
                key: 'metadata.' + this.option,
                range: null,
                direction: this.option === 'title' ? 'next' : 'nextunique',
                option: this.option
            };
            ModeManager.start(MODE_LIST);
            ListView.activate(info);
            break;
        default:
            break;
        }
    }
};