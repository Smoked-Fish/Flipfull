const LIST_BATCH_SIZE = 10;
const PLAYLIST = 'playlists-my-playlists';
const LOADBUNDARY = 3;
const DEFAULT_DONGLE_LIMIT = 50;
var ListView = {
    get view() {
        return document.getElementById('views-list');
    },
    get anchor() {
        return document.getElementById('views-list-anchor');
    },
    get mainView() {
        return document.getElementById('main-view');
    },
    get listView() {
        return document.getElementById('region-views');
    },
    get searchBox() {
        return document.getElementById('views-list-search');
    },
    get searchInput() {
        return document.getElementById('views-list-search-input');
    },
    get isFocusingInput() {
        return Boolean(this.searchInput === document.activeElement);
    },
    get dataSource() {
        return this._dataSource;
    },
    set dataSource(source) {
        this._dataSource = source;
    },
    get focusIndex() {
        return this._focusIndex;
    },
    set focusIndex(idx) {
        this._focusIndex = idx;
    },
    get viewLength() {
        return ModeManager.currentMode === MODE_SEARCH_FROM_LIST || ModeManager.currentMode === MODE_SEARCH_FROM_LIST_PICK ? SearchView.dataSource.length : this.dataSource.length;
    },
    get listItems() {
        return this.anchor ? this.anchor.querySelectorAll('li.focusable') : [];
    },
    get items() {
        return ModeManager.currentMode === MODE_SEARCH_FROM_LIST || ModeManager.currentMode === MODE_SEARCH_FROM_LIST_PICK ? SearchView.list_anchor.children : this.listItems;
    },
    get mode() {
        return this._mode;
    },
    set mode(mode) {
        if (mode !== 'normal') {
            document.body.classList.add('contain-header');
        } else {
            document.body.classList.remove('contain-header');
        }
        this._mode = mode;
        this.view.setAttribute('mode', mode);
        this.view.focus();
        this.updateUI();
    },
    get currentTarget() {
        return this._currentTarget;
    },
    set currentTarget(target) {
        this._currentTarget = target;
    },
    get listLoaded() {
        return this._listLoaded;
    },
    set listLoaded(loaded) {
        setElClassesByCond({ 'list-hasdata': this.dataSource.length > 0 }, this.anchor);
        this._listLoaded = loaded;
    },
    playlistArray: [
        {
            metadata: { l10nId: PLAYLIST },
            option: 'lists'
        },
        {
            metadata: { l10nId: 'playlists-discover' },
            option: 'date'
        },
        {
            metadata: { l10nId: 'playlists-most-played' },
            option: 'played'
        },
        {
            metadata: { l10nId: 'playlists-recently-added' },
            option: 'date'
        }
    ],
    init: function lvInit() {
        this._firstLoaded = false;
        this.selected = new Map();
        this.limit = 0;
        this.focusIndex = 0;
        this.indexBeforeDelete = 0;
        this.songsData = [];
        this.albumData = [];
        this.artistData = [];
        this.clean();
        this.view.addEventListener('input', this);
        this.view.addEventListener('keydown', this);
        this.searchBox.addEventListener('focus', this, true);
        this.searchBox.addEventListener('blur', this, true);
        this.mode = 'normal';
        this.navigator = new SimpleNavigationHelper('.focusable', this.view, null, 1);
    },
    updateUI: function lvUpdateUI() {
        this.updateSoftKeys();
        this.updateTitle();
    },
    updateTitle: function lvUpdateTitle() {
        if (this.mode === 'normal') {
            TitleBar.updateById('music');
        }
        if (this.mode === 'picker') {
            TitleBar.text.classList.add('picker-title');
            TitleBar.updateById('picker-title');
        }
        if (this.mode === 'edit') {
            TitleBar.updateById('song-num-checked', { n: this.selected.size });
        }
        if (this.mode === 'multipicker') {
            TitleBar.updateById('song-num-checked', { n: this.selected.size });
        }
    },
    updatePlayingIcon: function lvUpdatePlayingIcon() {
        if (typeof PlayerView === 'undefined') {
            return;
        }
        let playSongName = PlayerView.playSongName;
        let currentIcon = this.anchor.querySelector('.list-playing-icon.active');
        if (currentIcon) {
            currentIcon.classList.remove('active');
        }
        if (PlayerView.playStatus !== PLAYSTATUS_PLAYING) {
            return;
        }
        this.dataSource.some((data, index) => {
            if (data.name === playSongName) {
                try {
                    this.anchor.querySelector(`[data-index='${ index }']`).querySelector('.list-playing-icon').classList.add('active');
                } catch (e) {
                }
                return true;
            }
        });
    },
    updateSoftKeys: function lvUpdateSotfKeys() {
        if (this.showLoading) {
            SoftKeyStore.unregister(this.view);
            return;
        }
        if (this.mode === 'normal') {
            let isHide = isDongleConnect();
            SoftKeyStore.register({
                'left': isHide ? '' : 'opt-player',
                'center': this.type === 'title' ? isHide ? 'select' : 'icon=play' : 'select',
                'right': this.type === 'title' ? isHide ? '' : 'options' : 'about'
            }, this.view);
            SoftKeyStore.register({
                'left': isHide ? '' : 'opt-player',
                'center': '',
                'right': ''
            }, this.searchInput);
        } else if (this.mode === 'edit') {
            if (ModeManager.currentMode === MODE_LIST_FROM_SUBLIST || ModeManager.currentMode === MODE_SEARCH_FROM_LIST_PICK) {
                SoftKeyStore.register({
                    'left': this.selected.size === this.viewLength ? 'none' : 'all',
                    'center': 'select',
                    'right': this.selected.size === 0 ? '' : 'next'
                }, this.view);
                SoftKeyStore.register({
                    'left': this.selected.size === this.viewLength ? 'none' : 'all',
                    'center': '',
                    'right': ''
                }, this.searchInput);
            } else if (toPlaylist.state) {
                SoftKeyStore.register({
                    'left': this.selected.size === this.viewLength ? 'none' : 'all',
                    'center': 'select',
                    'right': this.selected.size > 0 ? 'next' : ''
                }, this.view);
            } else {
                SoftKeyStore.register({
                    'left': this.selected.size === this.viewLength ? 'none' : 'all',
                    'center': 'select',
                    'right': this.selected.size > 0 ? 'delete' : ''
                }, this.view);
                SoftKeyStore.register({
                    'left': this.selected.size === this.viewLength ? 'none' : 'all',
                    'center': '',
                    'right': ''
                }, this.searchInput);
            }
        } else if (this.mode === 'picker') {
            SoftKeyStore.register({
                'left': 'cancel',
                'center': 'select',
                'right': ''
            }, this.view);
        } else if (this.mode === 'multipicker') {
            SoftKeyStore.register({
                'left': '',
                'center': 'select',
                'right': this.selected.size === 0 ? '' : 'opt-play'
            }, this.view);
        }
        this.updateItemSoftKey();
    },
    updateItemSoftKey: function lvUpdateSoftKey() {
        if (this.items.length === 0) {
            return;
        }
        for (let i = 0; i < this.items.length; i++) {
            this.items[i].dataset.selected === 'true' ? SoftKeyStore.register({ 'center': 'deselect' }, this.items[i]) : SoftKeyStore.unregister(this.items[i]);
        }
    },
    updateSelectedItems: function () {
        let selectedItems = this.anchor.querySelectorAll('[data-selected="true"]');
        Array.from(selectedItems).map(item => {
            item.dataset.selected = false;
        });
        for (let index of this.selected.keys()) {
            let target = this.anchor.querySelector(`[data-index='${ index }']`);
            if (target) {
                target.dataset.selected = true;
            }
        }
    },
    clean: function lvClean() {
        this.cancelEnumeration();
        this.info = null;
        this.handle = null;
        this.dataSource = [];
        this.selected.clear();
        this.index = 0;
        this.reverseIndex = 0;
        this.lastDataIndex = 0;
        this.removeNodewithoutBanner();
        this.view.scrollTop = 0;
        this.needReset = false;
    },
    removeNodewithoutBanner: function lvRemoveNodewithoutBanner() {
        if (this.anchor.lastChild) {
            while (!BannerAd.isBannerAdNode(this.anchor.lastChild)) {
                this.anchor.removeChild(this.anchor.lastChild);
            }
        }
    },
    resetUI: function lvReset() {
        let option = TabBar.option;
        let info = {
            key: 'metadata.' + option,
            range: null,
            direction: option === 'title' ? 'next' : 'nextunique',
            option: option
        };
        this.activate(info, () => {
            if (this.indexBeforeDelete) {
                let focusNode = null;
                this.indexBeforeDelete = Math.min(this.dataSource.length - 1, this.indexBeforeDelete);
                this.isNeedLoadNearestNodes(this.indexBeforeDelete);
                focusNode = this.anchor.querySelector(`[data-index='${ this.indexBeforeDelete }']`);
                if (focusNode) {
                    this.focusIndex = this.indexBeforeDelete;
                    this.navigator.setFocus(focusNode);
                    this.setFocus(this.view);
                }
                this.indexBeforeDelete = 0;
            }
        });
    },
    cancelEnumeration: function lvCancelEnumeration() {
        if (this.handle) {
            musicdb.cancelEnumeration(this.handle);
        }
    },
    activate: function lvActivate(info, callback) {
        this.type = info.option;
        this.navigator.destroy();
        if (ModeManager.currentMode === MODE_LIST_FROM_SUBLIST) {
            this.mode = 'edit';
        } else if (App.pendingPick) {
            this.mode = App.pendingPick.source.data.selectMode === 'multiple' ? 'multipicker' : 'picker';
            this.limit = App.pendingPick.source.data.limit || DEFAULT_DONGLE_LIMIT;
        } else {
            this.mode = 'normal';
        }
        this.updateUI();
        if (this.type === 'playlist') {
            this.navigator = new SimpleNavigationHelper('.focusable', this.view, null, 0);
            let musicCount = window.localStorage.getItem('musicCount');
            if (musicCount) {
                App.showCorrectOverlay(Number(musicCount));
                this.clean();
                this.playlistArray.forEach(playlist => {
                    this.update(this.type, playlist);
                });
                this.listLoaded = true;
                this.view.focus();
                if (!this._firstLoaded) {
                    this._firstLoaded = true;
                    window.dispatchEvent(new CustomEvent('visuallyLoaded'));
                    window.performance.mark('visuallyLoaded');
                    window.performance.mark('contentInteractive');
                }
            } else {
                this.showScanning();
            }
        } else {
            var option = ModeManager.currentMode === MODE_PICKER || ModeManager.currentMode === MODE_LIST_FROM_SUBLIST ? 0 : 1;
            this.navigator = new SimpleNavigationHelper('.focusable', this.view, null, option);
            musicdb.count('metadata.' + info.option, null, count => {
                if (info.option !== this.type) {
                    return;
                }
                this.clean();
                this.info = info;
                this.info.count = count;
                App.showCorrectOverlay(count);
                let musicCount = Number(window.localStorage.getItem('musicCount'));
                if (musicCount === count) {
                    if (this.type === 'title' && this.songsData.length > 0 || this.type === 'artist' && this.artistData.length > 0 || this.type === 'album' && this.albumData.length > 0) {
                        this.updateDataSource(false);
                        this.showLoading = true;
                        this.updateSoftKeys();
                        this.quickLoadAndUpdate({
                            option: info.option,
                            data: this.dataSource,
                            count: this.dataSource.length,
                            range: LIST_BATCH_SIZE
                        });
                        this.updatePlayingIcon();
                        this.showLoading = false;
                        this.updateSoftKeys();
                        callback && callback();
                        return;
                    }
                }
                window.localStorage.setItem('musicCount', count);
                this.handle = musicdb.enumerate(info.key, info.range, info.direction, record => {
                    if (record) {
                        if (!App.pendingPick || !record.metadata.locked) {
                            this.dataSource.push(record);
                        }
                        if (!this.showLoading) {
                            this.showLoading = true;
                            this.updateSoftKeys();
                        }
                    }
                    if (App.pendingPick || info.option === 'title') {
                        App.knownSongs = this.dataSource;
                    }
                    if (!record) {
                        this.updateDataSource(true);
                        this.quickLoadAndUpdate({
                            option: info.option,
                            data: this.dataSource,
                            count: this.dataSource.length,
                            range: LIST_BATCH_SIZE
                        });
                        this.updatePlayingIcon();
                        this.showLoading = false;
                        this.updateSoftKeys();
                        if (window.performance.getEntriesByName('music-delete-start', 'mark').length > 0) {
                            window.performance.mark('music-delete-end');
                            window.performance.measure('performance-music-delete', 'music-delete-start', 'music-delete-end');
                            window.performance.clearMarks('music-delete-start');
                            window.performance.clearMarks('music-delete-end');
                        }
                        if (App.pendingPick && !this._firstLoaded) {
                            this._firstLoaded = true;
                            window.dispatchEvent(new CustomEvent('visuallyLoaded'));
                            window.performance.mark('visuallyLoaded');
                            window.performance.mark('contentInteractive');
                        }
                        callback && callback();
                    }
                });
            });
        }
    },
    showScanning: function lvShowScanning() {
        App.showOverlay('scanning');
    },
    update: function lvUpdate(option, result) {
        if (result === null) {
            App.showCorrectOverlay();
            return;
        }
        this.dataSource.push(result);
        this.anchor.appendChild(createListElement(option, result, this.index));
        this.index++;
    },
    quickLoadAndUpdate: function lvQuickLoadAndUpdate(options) {
        let {option, data, count, range} = options;
        this.listLoaded = false;
        this.reverseIndex = count;
        if (!data) {
            return;
        }
        let length = data.length;
        if (length <= range * 2) {
            let fragment = document.createDocumentFragment();
            enumerateData.call(this, data, fragment, false);
            this.anchor.appendChild(fragment);
            this.listLoaded = true;
            if (!OptionMenu.isActive()) {
                this.updateFocus(option);
            }
        } else if (length > range * 2) {
            let head = data.slice(0, range);
            let body = data.slice(range, 0 - range);
            let foot = data.slice(0 - range);
            let fragmentHead = document.createDocumentFragment();
            let fragmentFoot = document.createDocumentFragment();
            enumerateData.call(this, head, fragmentHead, false);
            enumerateData.call(this, foot, fragmentFoot, true);
            this.anchor.appendChild(fragmentHead);
            this.anchor.appendChild(fragmentFoot);
            if (!OptionMenu.isActive()) {
                this.updateFocus(option);
            }
            this.countinueLoad = function lvCountinueLoad(dir) {
                start.call(this, dir, body);
            };
        }
        function start(dir, body) {
            let fragmentBody = document.createDocumentFragment();
            if (dir === 'top') {
                if (body.length < range) {
                    enumerateData.call(this, body, fragmentBody, false);
                    this.anchor.insertBefore(fragmentBody, document.querySelector(`#views-list-anchor >
            li.list-item[data-index='${ this.index - body.length - 1 }']`).nextSibling);
                    this.listLoaded = true;
                } else {
                    let _body = body.splice(0, range);
                    enumerateData.call(this, _body, fragmentBody, false);
                    this.anchor.insertBefore(fragmentBody, document.querySelector(`#views-list-anchor >
            li.list-item[data-index='${ this.index - range - 1 }']`).nextSibling);
                }
            } else {
                let oldHeight = this.anchor.scrollHeight;
                if (body.length < range) {
                    enumerateData.call(this, body, fragmentBody, true);
                    this.anchor.insertBefore(fragmentBody, document.querySelector(`#views-list-anchor >
            li.list-item[data-index='${ this.reverseIndex + body.length }']`));
                    this.listLoaded = true;
                } else {
                    let _body = body.splice(0 - range);
                    enumerateData.call(this, _body, fragmentBody, true);
                    this.anchor.insertBefore(fragmentBody, document.querySelector(`#views-list-anchor >
            li.list-item[data-index='${ this.reverseIndex + range }']`));
                }
                this.anchor.scrollTop += this.anchor.scrollHeight - oldHeight;
            }
        }
        function enumerateData(dataArr, targetDom, isReverse) {
            if (isReverse) {
                this.reverseIndex = this.reverseIndex - Math.min(dataArr.length, LIST_BATCH_SIZE);
            }
            let isSelected;
            let reverseIndex = this.reverseIndex;
            for (let i = 0; i < dataArr.length; i++) {
                let data = dataArr[i];
                if (!isReverse) {
                    isSelected = this.selected.get(this.index);
                    targetDom.appendChild(createListElement(option, data, this.index, null, isSelected));
                    this.index++;
                } else {
                    isSelected = this.selected.get(reverseIndex);
                    targetDom.appendChild(createListElement(option, data, reverseIndex, null, isSelected));
                    reverseIndex++;
                }
            }
        }
    },
    isNeedLoadNearestNodes: function (index) {
        if (this.listLoaded || typeof PlayerView === 'undefined' || PlayerView.status === PLAYSTATUS_STOPPED) {
            return;
        }
        if (typeof index === 'undefined') {
            let songName = PlayerView.playSongName;
            this.dataSource.some((data, i) => {
                if (data.name === songName) {
                    index = i;
                    return true;
                }
            });
        }
        let dis = {
            top: index - (this.index - 1),
            bottom: this.reverseIndex - index
        };
        if (dis.top > 0 && dis.bottom > 0) {
            let nearDir = dis.top > dis.bottom ? 'bottom' : 'top';
            let n = Math.ceil(dis[nearDir] / LIST_BATCH_SIZE);
            if (dis[nearDir] % LIST_BATCH_SIZE === 0 || dis[nearDir] % LIST_BATCH_SIZE > LIST_BATCH_SIZE - LOADBUNDARY) {
                n++;
            }
            let render = () => {
                if (n > 0) {
                    this.countinueLoad(nearDir);
                    n--;
                    render();
                }
            };
            render();
        } else if (dis.top <= 0 && dis.top > 0 - LOADBUNDARY) {
            this.countinueLoad('top');
        } else if (dis.bottom <= 0 && dis.bottom > 0 - LOADBUNDARY) {
            this.countinueLoad('bottom');
        }
    },
    resetDataSource: function () {
        this.songsData = [];
        this.artistData = [];
        this.albumData = [];
    },
    updateDataSource: function (bSet) {
        switch (this.type) {
        case 'title':
            if (bSet) {
                this.songsData = JSON.parse(JSON.stringify(this.dataSource));
            } else {
                this.dataSource = this.songsData;
            }
            break;
        case 'album':
            if (bSet) {
                this.albumData = JSON.parse(JSON.stringify(this.dataSource));
            } else {
                this.dataSource = this.albumData;
            }
            break;
        case 'artist':
            if (bSet) {
                this.artistData = JSON.parse(JSON.stringify(this.dataSource));
            } else {
                this.dataSource = this.artistData;
            }
            break;
        default:
            this.dataSource = [];
        }
    },
    updateFocus: function (option) {
        if (ModeManager.withRefresh) {
            let nodeList = this.anchor.querySelectorAll('.focusable');
            let node = nodeList[0];
            ModeManager.withRefresh = false;
            this.focusIndex = 0;
            if (PlayerView.playStatus !== 'STOPPED' && PlayerView.playSongName !== '') {
                if (option === 'title') {
                    let songName = PlayerView.playSongName;
                    Array.from(nodeList).some((el, i) => {
                        if (el.dataset.songName === songName) {
                            node = el;
                            this.focusIndex = i;
                            return true;
                        }
                    });
                } else if (this.currentTarget) {
                    let keyRange = this.currentTarget.dataset.keyRange;
                    Array.from(nodeList).some((el, i) => {
                        if (el.dataset.keyRange === keyRange) {
                            node = el;
                            this.focusIndex = i;
                            return true;
                        }
                    });
                }
            }
            this.navigator.setFocus(node);
            this.setFocus(this.view);
        } else {
            this.focusIndex = 0;
            this.setFocus(this.view);
        }
    },
    setFocus: function (element) {
        setTimeout(() => {
            element.focus();
        });
    },
    playWithShuffleAll: function lvPlayWithShuffleAll() {
        let dataSource = this.dataSource;
        let info = this.info;
        if (ModeManager && ModeManager.currentMode === MODE_SEARCH_FROM_LIST) {
            dataSource = SearchView.dataSource;
            info.count = SearchView.dataSource.length;
        }
        ModeManager.push(MODE_PLAYER, () => {
            PlayerView.setSourceType(TYPE_MIX);
            PlayerView.dataSource = dataSource;
            PlayerView.setDBInfo(info);
            PlayerView.setShuffle(true);
            PlayerView.play(PlayerView.shuffledList[0], true);
        });
    },
    playWithIndex: function lvPlayWithIndex(index) {
        let dataSource = this.dataSource;
        let info = Object.assign({}, this.info);
        if (ModeManager && ModeManager.currentMode === MODE_SEARCH_FROM_LIST) {
            dataSource = SearchView.dataSource;
            info.count = SearchView.dataSource.length;
        }
        ModeManager.push(MODE_PLAYER, () => {
            if (App.pendingPick) {
                PlayerView.setSourceType(TYPE_SINGLE);
            } else {
                PlayerView.setSourceType(TYPE_MIX);
            }
            this.cancelEnumeration();
            if (PlayerView.shuffleOption) {
                PlayerView.dataSource = dataSource;
                PlayerView.setDBInfo(info);
                PlayerView.shuffleList(index);
                PlayerView.play(PlayerView.shuffledList[0], true);
            } else {
                PlayerView.dataSource = dataSource;
                PlayerView.setDBInfo(info);
                PlayerView.play(index, true);
            }
        });
    },
    activateSubListView: function lvActivateSubListView(target) {
        let data, index, keyRange, option;
        if (target && target.listName) {
            option = 'list';
            index = SubListView.listIndex;
            data = target;
            keyRange = null;
        } else {
            this.currentTarget = target || this.currentTarget;
            option = this.currentTarget.dataset.option;
            index = this.currentTarget.dataset.index;
            if (ModeManager.currentMode === MODE_LIST) {
                data = this.dataSource[index];
            } else if (ModeManager.currentMode === MODE_SUBLIST) {
                if (ModeManager.prevMode === MODE_SEARCH_FROM_LIST) {
                    data = this.dataSource[this.currentTarget.dataset.originIndex];
                } else {
                    data = this.dataSource[index];
                }
            } else if (ModeManager.currentMode === MODE_SEARCH_FROM_LIST) {
                data = this.dataSource[this.currentTarget.dataset.originIndex];
            }
            index = null;
            keyRange = this.currentTarget.dataset.keyRange !== 'all' ? IDBKeyRange.only(this.currentTarget.dataset.keyRange) : null;
        }
        if (data) {
            SubListView.activate(option, data, index, keyRange, 'next', () => {
                ModeManager.push(option === 'lists' ? MODE_SUBLIST_LIST : MODE_SUBLIST);
            });
        }
    },
    buildOptionMenu: function lvBuildOptionMenu() {
        let target = document.activeElement;
        let optShuffleAll = {
            id: 'opt-shuffleall',
            callback: () => {
                this.playWithShuffleAll();
            }
        };
        let optAddToPlaylist = {
            id: 'opt-addtoplaylist',
            callback: () => {
                this.mode = 'edit';
                toPlaylist.state = true;
            }
        };
        let optShare = {
            id: 'opt-share',
            callback: () => {
                this.view.focus();
                startActivity(this.dataSource[target.dataset.originIndex || target.dataset.index], 'share');
            }
        };
        let optSetRingTone = {
            id: 'opt-setring',
            callback: () => {
                this.view.focus();
                startActivity(this.dataSource[target.dataset.originIndex || target.dataset.index], 'set-ringtone');
            }
        };
        let optDelete = {
            id: 'opt-delete',
            callback: () => {
                Dialog.show('delete-album-songs', { n: 1 }, () => {
                    this.view.focus();
                }, () => {
                    this.deleteSelected(target);
                });
            }
        };
        let optMulselect = {
            id: 'opt-mulselect',
            callback: () => {
                this.mode = 'edit';
            }
        };
        let optionsArr;
        if (MainView.bLowMemoryDevice) {
            optionsArr = [
                optDelete,
                optMulselect
            ];
        } else {
            optionsArr = [
                optShare,
                optSetRingTone,
                optDelete,
                optMulselect
            ];
        }
        if (toPlaylist.enabled) {
            optionsArr.unshift(optShuffleAll, optAddToPlaylist);
        } else {
            optionsArr.unshift(optShuffleAll);
        }
        return optionsArr;
    },
    multiDelete: function lvMultiDelete() {
        if (this.selected.size > 0) {
            Dialog.show('delete-album-songs', { n: this.selected.size }, () => {
                this.view.focus();
            }, () => {
                this.deleteSelected();
            });
        }
    },
    deleteSelected: function lvDeleteCurrent(target) {
        window.performance.mark('music-delete-start');
        if (this.selected.size === 0) {
            this.selected.set(this.focusIndex, true);
        }
        let index = 0;
        let size = this.selected.size;
        let delResolve;
        window.delPromise = new Promise(resolve => {
            delResolve = resolve;
        });
        this.selected.forEach((value, key) => {
            var songName = target !== undefined ? target.dataset.songName : this.dataSource[key].name;
            if (typeof PlayerView !== 'undefined' && songName === PlayerView.playSongName) {
                PlayerView.stop();
            }
            musicdb.deleteFile(songName, () => {
                index++;
                if (index === size) {
                    delResolve();
                }
            });
        });
        if (ModeManager.currentMode === MODE_SEARCH_FROM_LIST) {
            this.searchInput.value = '';
            ModeManager.pop();
        } else {
            this.indexBeforeDelete = this.focusIndex;
        }
        this.selected.clear();
    },
    addSelected: function lvAddCurrent(index) {
        let addedNum = this.selected.size;
        let targetPlaylist = SubListView.listDataSource[index];
        this.selected.forEach((value, key) => {
            let data = JSON.parse(JSON.stringify(this.dataSource[key]));
            data.id = createHash(HASH_NUM);
            targetPlaylist.source.unshift(data);
        });
        SubListView.updateStorage();
        this.selected.clear();
        if (!toPlaylist.enabled) {
            toPlaylist.enabled = true;
        }
        Toaster.showToast({
            message: addedNum > 1 ? addedNum + ' ' + window.api.l10n.get('add-to-playlist-songs-hint') + ' ' + targetPlaylist.listName : window.api.l10n.get('add-to-playlist-song-hint') + ' ' + targetPlaylist.listName,
            latency: 2000
        });
    },
    toggle: function lvToggleCurrent(item, option, idx) {
        let index;
        let isNeeded;
        if (item) {
            if (ModeManager.currentMode === MODE_SEARCH_FROM_LIST || ModeManager.currentMode === MODE_SEARCH_FROM_LIST_PICK) {
                index = Number(item.dataset.originIndex);
            } else {
                index = Number(item.dataset.index);
                idx && index != idx && (isNeeded = true);
            }
        } else {
            index = idx;
        }
        let select = () => {
            this.selected.set(index, true);
            if (item) {
                item.dataset.selected = true;
                isNeeded && this.selected.set(idx, true);
                const checkbox = item.querySelector('.check-icon');
                checkbox && checkbox.setAttribute('aria-checked', true);
            }
        };
        let deSelect = () => {
            this.selected.delete(index);
            if (item) {
                item.dataset.selected = false;
                isNeeded && this.selected.delete(idx);
                const checkbox = item.querySelector('.check-icon');
                checkbox && checkbox.setAttribute('aria-checked', false);
            }
        };
        if (option === 'selectAll') {
            select();
        } else if (option === 'deselectAll') {
            deSelect();
        } else if (this.selected.has(index)) {
            deSelect();
        } else {
            if (this.mode === 'multipicker' && this.selected.size >= this.limit) {
                return;
            }
            select();
        }
        if (!option) {
            this.updateUI();
        }
    },
    toggleAll: function lvToggleAll(option) {
        if ((ModeManager.currentMode === MODE_SEARCH_FROM_LIST || ModeManager.currentMode === MODE_SEARCH_FROM_LIST_PICK) && this.viewLength === 0) {
            return;
        }
        if (!option) {
            if (this.selected.size === this.viewLength) {
                option = 'deselectAll';
            } else {
                option = 'selectAll';
            }
        }
        for (let i = 0; i < this.viewLength; i++) {
            this.toggle(this.items[i], option, i);
        }
        this.updateUI();
    },
    updateFocusIndex: function (index, key) {
        if (key) {
            if (key === 'ArrowUp') {
                if (this.isFocusingInput) {
                    index = this.dataSource.length - 1;
                } else {
                    index -= 1;
                }
            } else if (key === 'ArrowDown') {
                if (this.isFocusingInput) {
                    index = 0;
                } else {
                    index += 1;
                }
            }
            this.focusIndex = index;
        }
    },
    handleEvent: function lvHandleEvent(evt) {
        let target = evt.target;
        let showStorageHint = function () {
            Toaster.showToast({
                message: window.api.l10n.get('storage-not-ready'),
                latency: 2000
            });
        };
        if (!target) {
            return;
        }
        let index = Number(target.dataset.index) || 0;
        this.updateFocusIndex(index, evt.key);
        if (this.focusIndex < 0 || this.focusIndex >= this.dataSource.length) {
            this.searchInput.removeAttribute('aria-hidden');
        } else {
            this.searchInput.setAttribute('aria-hidden', true);
        }
        switch (evt.type) {
        case 'focus':
            if (target.id === 'views-list-search-input') {
                this.searchBox.classList.add('focused');
            }
            break;
        case 'blur':
            if (target.id === 'views-list-search-input') {
                this.searchBox.classList.remove('focused');
            }
            break;
        case 'input':
            if (target.id === 'views-list-search-input' && !evt.isComposing) {
                if (target.value === '' && (ModeManager.currentMode === MODE_SEARCH_FROM_LIST || ModeManager.currentMode === MODE_SEARCH_FROM_LIST_PICK)) {
                    SearchView.clean(SearchView.list_anchor);
                    ModeManager.pop();
                    this.updateUI();
                } else if (ModeManager.currentMode === MODE_SEARCH_FROM_LIST || ModeManager.currentMode === MODE_SEARCH_FROM_LIST_PICK) {
                    return SearchView.search(target.value);
                } else if (ModeManager.currentMode === MODE_LIST_FROM_SUBLIST) {
                    ModeManager.push(MODE_SEARCH_FROM_LIST_PICK);
                } else if (target.value !== '') {
                    ModeManager.push(MODE_SEARCH_FROM_LIST);
                }
                SearchView.search(target.value);
            }
            break;
        case 'keydown':
            switch (evt.key) {
            case 'ArrowLeft':
            case 'ArrowRight':
                this.focusIndex = 0;
                if (App.pendingPick) {
                    evt.stopPropagation();
                } else if (!firstScanDone) {
                    evt.stopPropagation();
                    showStorageHint();
                } else if (this.mode === 'edit') {
                    evt.stopPropagation();
                }
                break;
            case 'ArrowUp':
                if (!this.listLoaded && document.activeElement.getAttribute('data-index') == this.reverseIndex + LOADBUNDARY) {
                    this.countinueLoad('bottom');
                    TabBar.option === 'title' && this.updatePlayingIcon();
                }
                break;
            case 'ArrowDown':
                if (!this.listLoaded && document.activeElement.getAttribute('data-index') == this.index - 1 - LOADBUNDARY) {
                    this.countinueLoad('top');
                    TabBar.option === 'title' && this.updatePlayingIcon();
                }
                break;
            case 'Enter':
                if (!firstScanDone) {
                    if (this.mode === 'picker' && target.dataset.index) {
                        musicdb.getFile(this.dataSource[this.focusIndex].name, () => {
                            this.playWithIndex(this.focusIndex);
                        }, () => {
                            showStorageHint();
                        });
                    } else {
                        showStorageHint();
                    }
                } else if (this.mode === 'normal') {
                    if (this.type === 'title') {
                        if (target.dataset.index) {
                            return isDongleConnect() ? playByDongle(this) : this.playWithIndex(this.focusIndex);
                        }
                    }
                    this.activateSubListView(target);
                } else if (this.mode === 'edit') {
                    if (target.classList.contains('list-item')) {
                        this.toggle(target);
                    }
                } else if (this.mode === 'multipicker') {
                    if (target.classList.contains('list-item')) {
                        this.toggle(target);
                    }
                } else if (this.mode === 'picker') {
                    if (target.dataset.index) {
                        this.playWithIndex(this.focusIndex);
                    }
                }
                break;
            case 'HeadsetHook':
                if (!firstScanDone) {
                    showStorageHint();
                } else if (this.mode !== 'picker' && typeof PlayerView !== 'undefined' && (PlayerView.playStatus === PLAYSTATUS_PLAYING || PlayerView.playStatus === PLAYSTATUS_PAUSED)) {
                    PlayerView.togglePlay();
                } else if (this.mode === 'normal') {
                    ModeManager.playWithInit();
                }
                break;
            case 'Backspace':
                if (App.pendingPick) {
                    evt.preventDefault();
                    App.pendingPick.postResult({});
                    return;
                }
                if (this.mode === 'edit') {
                    evt.preventDefault();
                    if (ModeManager.currentMode === MODE_LIST_FROM_SUBLIST) {
                        this._mode = 'normal';
                        this.view.setAttribute('mode', 'normal');
                        this.toggleAll('deselectAll');
                        ModeManager.pop();
                    } else if (ModeManager.currentMode === MODE_SEARCH_FROM_LIST_PICK) {
                        if (this.searchInput.value.length > 0) {
                            this.navigator.setFocus(this.searchInput);
                        }
                    } else {
                        this.toggleAll('deselectAll');
                        this.mode = 'normal';
                        if (toPlaylist.state) {
                            toPlaylist.state = false;
                        }
                    }
                } else if (this.searchInput.value.length > 0) {
                    evt.preventDefault();
                    this.navigator.setFocus(this.searchInput);
                } else if (typeof getKaiAd === 'function') {
                    this.mainView.classList.remove('hidden');
                    this.listView.classList.add('hidden');
                    MainView.activate();
                    MainView.switchPage = false;
                    evt.preventDefault();
                }
                break;
            case 'SoftLeft':
                if (App.pendingPick) {
                    App.pendingPick.postResult({});
                } else if (!firstScanDone) {
                    showStorageHint();
                } else if (this.mode === 'edit') {
                    this.toggleAll();
                } else if (this.mode === 'normal' && !isDongleConnect()) {
                    ModeManager.playWithInit(true);
                }
                break;
            case 'SoftRight':
                if (this.mode === 'normal') {
                    if (!this.searchBox.classList.contains('focused') && !isDongleConnect()) {
                        if (this.type === 'title') {
                            OptionMenu.show(this.buildOptionMenu(), () => {
                                this.view.focus();
                            });
                        } else {
                            Dialog.show('about-dialog-content-version', { n: App.appVersion }, () => {
                                this.view.focus();
                            }, () => {
                                this.view.focus();
                            }, {
                                headerl10nId: 'about',
                                type: 'hint',
                                secondValue: 'about-dialog-content-developer'
                            });
                        }
                    }
                } else if (this.mode === 'edit') {
                    if (target.type === 'search') {
                        return;
                    }
                    if (ModeManager.currentMode === MODE_LIST_FROM_SUBLIST || ModeManager.currentMode === MODE_SEARCH_FROM_LIST_PICK) {
                        if (target.id === 'views-list-search-input' || this.selected.size === 0) {
                            return;
                        }
                        if (!SubListView.isInMyPlaylist) {
                            let name = SubListView.textInput.value.trim();
                            let data = {
                                id: createHash(HASH_NUM),
                                listName: name,
                                metadata: { title: name },
                                source: []
                            };
                            SubListView.listDataSource.unshift(data);
                            SubListView.updateStorage();
                            SubListView.focusIndex = 0;
                            SubListView.listIndex = 0;
                            SubListView.currentTarget = SubListView.listDataSource[0];
                            SubListView.textInput.value = '';
                            SubListView.listNeedReset = true;
                        }
                        this.addSelected(SubListView.listIndex);
                        ModeManager._modeStack = [
                            MODE_LIST,
                            MODE_SUBLIST_LIST
                        ];
                        this._mode = 'normal';
                        this.view.setAttribute('mode', 'normal');
                        this.activateSubListView(SubListView.currentTarget);
                        SubListView.searchInput.value = '';
                    } else if (toPlaylist.state) {
                        if (this.selected.size === 0) {
                            return;
                        }
                        let selected = [];
                        for (let k of this.selected.keys()) {
                            selected.push(k);
                        }
                        selected.forEach(k => {
                            let data = JSON.parse(JSON.stringify(this.dataSource[k]));
                            data.id = createHash(HASH_NUM);
                            toPlaylist.source.push(data);
                        });
                        this.mode = 'normal';
                        this.toggleAll('deselectAll');
                        SubListView.activate('lists', null, null, null, null, () => {
                            SubListView.mode = 'edit';
                            ModeManager.push(MODE_SUBLIST_LIST);
                        });
                    } else {
                        this.multiDelete();
                    }
                } else if (this.mode === 'multipicker') {
                    if (this.selected.size === 0) {
                        return;
                    }
                    let data = [];
                    let selected = this.dataSource.filter((obj, i) => {
                        return this.selected.has(i);
                    });
                    selected.forEach(obj => {
                        let item = {};
                        item.path = obj.name;
                        item.title = obj.metadata.title;
                        data.push(item);
                    });
                    App.pendingPick.postResult(data);
                }
                break;
            default:
                break;
            }
            break;
        default:
            break;
        }
    }
};
window.ListView = ListView;