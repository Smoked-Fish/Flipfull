var MainView = {
    get view() {
        return document.getElementById('mainview-list');
    },
    get listView() {
        return document.getElementById('region-views');
    },
    get radioView() {
        return document.getElementById('i-region-views');
    },
    get image() {
        return document.getElementById('image');
    },
    appVersion: '3.0.11',
    isLoaded: false,
    bLowMemoryDevice: false,
    musicMode: true,
    switchPage: false,
    cacheIndex: 0,
    init: function lvInit() {
        this.view.addEventListener('keydown', this);
        this.view.addEventListener('focus', this, true);
        document.addEventListener('visibilitychange', this.handleVisibilityChange.bind(this));
        this.navigator = new SimpleNavigationHelper('.focusable', this.view, null, 0);
        this.view.focus();
        this.navigator.refresh([]);
        this.updateSoftKeys();
        const xhr = new XMLHttpRequest();
        xhr.open('GET', '/manifest.webmanifest');
        xhr.send();
        xhr.onload = () => {
            const data = JSON.parse(xhr.response);
            this.appVersion = data.b2g_features.version;
        };
        window.dispatchEvent(new CustomEvent('visuallyLoaded'));
        window.performance.mark('visuallyLoaded');
    },
    updateSoftKeys: function lvUpdateSotfKeys() {
        console.log('register softkey');
        SoftKeyStore.register({
            'center': 'select',
            'right': 'about'
        }, this.view);
    },
    changeImage: function lvChangeImage() {
        let currentFocus = document.activeElement.id;
        if (currentFocus === 'local-music') {
            this.image.src = './style/images/img-music.png';
        } else if (currentFocus === 'icecast-radio') {
            this.image.src = './style/images/img-radio.png';
        }
    },
    activate: function lvActivate() {
        this.navigator.destroy();
        this.navigator = new SimpleNavigationHelper('.focusable', this.view, null, this.cacheIndex);
        this.view.focus();
        this.navigator.refresh([]);
        this.updateSoftKeys();
    },
    handleEvent: function lvHandleEvent(evt) {
        let target = evt.target;
        if (!target) {
            return;
        }
        switch (evt.key) {
        case 'Enter':
            if (target.id === 'local-music') {
                this.cacheIndex = 0;
                this.musicMode = true;
                this.switchPage = true;
                if (this.isLoaded) {
                    App.showCurrentView();
                } else {
                    LazyLoader.load('js/music.js', () => {
                        this.isLoaded = true;
                    });
                }
                this.view.parentElement.classList.add('hidden');
            } else if (target.id === 'icecast-radio') {
                this.cacheIndex = 1;
                if (!isOnline()) {
                    IceCastOverlay.open({
                        keys: { center: 'ok' },
                        content: {
                            title: 'icecast-radio',
                            image: '/style/images/no-connection.png',
                            subtitle: 'no-internet',
                            text: 'no-internet-retry'
                        },
                        onCenter: () => {
                            this.view.focus();
                        },
                        onBack: () => {
                            this.view.focus();
                        }
                    });
                } else {
                    this.musicMode = false;
                    this.switchPage = false;
                    FavoriteView.init();
                    IcecastView.init();
                    if (!RadioAd.initialized) {
                        RadioAd.init();
                    }
                }
            }
            break;
        case 'SoftRight':
            Dialog.show('about-dialog-content-version', { n: this.appVersion }, () => {
                this.view.focus();
            }, () => {
                this.view.focus();
            }, {
                headerl10nId: 'about',
                type: 'hint',
                secondValue: 'about-dialog-content-developer'
            });
            break;
        default:
            break;
        }
        if (evt.type === 'focus') {
            this.changeImage();
        }
    },
    handleVisibilityChange: function lvHandleVisibilityChange() {
        const PLAYINGSTATUS = 'PLAYING';
        if (!document.hidden && ModeManager.currentMode === MODE_PLAYER) {
            this.musicMode = true;
            this.switchPage = true;
            this.view.parentElement.classList.add('hidden');
            this.radioView.classList.add('hidden');
            this.listView.classList.remove('hidden');
            document.body.classList.remove('contain-header');
            const title = document.getElementById('title-text');
            title.classList.remove('icecast-header');
        }
        if (document.hidden && typeof PlayerView !== 'undefined' && PlayerView.playStatus === PLAYINGSTATUS) {
            OptionMenu.isActive() && OptionMenu.cancel();
            Dialog.isActive() && Dialog.cancel();
            if (isDongleConnect()) {
                return;
            }
            ModeManager._modeStack = [
                MODE_LIST,
                MODE_PLAYER
            ];
            ModeManager._updateMode();
            ModeManager.clearState();
            if (IceCastModulePlayerView.view) {
                IceCastModulePlayerView.removeUI();
            }
        }
        if (document.hidden && IceCastModulePlayerView.playStatus === PLAYINGSTATUS && !document.body.classList.contains('radio-mode')) {
            OptionMenu.isActive() && OptionMenu.cancel();
            Dialog.isActive() && Dialog.cancel();
            if (this.musicMode) {
                this.view.parentElement.classList.remove('hidden');
                this.listView.classList.add('hidden');
                this.activate();
                this.musicMode = false;
                this.switchPage = false;
                FavoriteView.init();
                IcecastView.init();
                ModeManager.setListMode(MODE_LIST);
            }
            IceCastModulePlayerView.enterPlayer();
        }
    }
};
function initSession() {
    LazyLoader.load([
        'http://shared.localhost/js/session/lib_session.js',
        'http://shared.localhost/js/session/task_scheduler.js',
        'http://shared.localhost/js/session/audio_volume_manager/audio_volume_manager.js',
        'http://shared.localhost/js/session/device_capability/device_capability.js',
        'http://shared.localhost/js/helper/softkey/softkey_register.js'
    ], () => {
        const servicesArray = [
            'devicecapabilityService',
            'audiovolumeService'
        ];
        window.libSession.initService(servicesArray).then(() => {
            AudioVolumeManager.init();
            DeviceCapabilityManager.get('hardware.memory').then(memOnDevice => {
                MainView.bLowMemoryDevice = memOnDevice === 256;
            });
            DeviceCapabilityManager.get('device.key.volume').then(hasVolumeKey => {
                window.hasVolumeKey = hasVolumeKey;
            });
        });
    });
}
function handleVisuallyLoaded() {
    initSession();
    const asyncComponents = [
        'http://shared.localhost/js/utils/common/text_normalizer.js',
        'http://shared.localhost/js/utils/toaster/toaster.js',
        'js/dialog.js'
    ];
    LazyLoader.load(asyncComponents).catch(() => {
        console.error('load asyncComponents failed.');
    });
}
window.MainView = MainView;
function showFullscreenAd() {
    if (typeof getKaiAd !== 'function') {
        return;
    }
    getKaiAd({
        app: 'Music',
        publisher: 'e6dfb88f-ca58-4816-85ad-27eb07964d34',
        timeout: 10000,
        blacklistCache: {
            ttl: 24 * 3600,
            initiallyHideAd: true
        },
        onerror: err => {
            console.log('guirw preloadFullscreenAd error:', err);
        },
        onready: ad => {
            const softkeyClasslist = document.getElementById('softkeyPanel').classList;
            const prevActiveElement = document.activeElement;
            softkeyClasslist.toggle('hidden', true);
            ad.call('display');
            ad.on('display', () => {
                isShowFullscreenAds = true;
            });
            ad.on('close', () => {
                softkeyClasslist.toggle('hidden', false);
                prevActiveElement.focus();
                isShowFullscreenAds = false;
            });
        }
    });
}
if (typeof getKaiAd !== 'function' || document.URL.indexOf('#pick') > -1) {
    MainView.musicMode = true;
    MainView.switchPage = true;
    MainView.view.parentElement.classList.add('hidden');
    LazyLoader.load('js/music.js', () => {
        App.showCurrentView();
    });
} else {
    window.api.l10n.once(() => {
        MainView.init();
    });
    showFullscreenAd();
}
window.addEventListener('visuallyLoaded', handleVisuallyLoaded);
if (document.URL.indexOf('#pick') === -1) {
    const commsFiles = [
        'http://shared.localhost/js/helper/bluetooth/bluetooth_helper.js',
        'js/remote_controls.js',
        'js/communications.js'
    ];
    LazyLoader.load(commsFiles).then(() => {
        MusicComms.init();
    });
}