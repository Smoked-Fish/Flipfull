var SearchView = {
    get searchListView() {
        return document.getElementById('list-search');
    },
    get searchSubListView() {
        return document.getElementById('sublist-search');
    },
    get list_anchor() {
        return document.getElementById('list-search-results');
    },
    get sublist_anchor() {
        return document.getElementById('sublist-search-results');
    },
    init: function svInit() {
        this.dataSource = [];
    },
    clean: function svClean(node) {
        node.innerHTML = '';
        findScrollElement(node).scrollTop = 0;
        function findScrollElement(_node) {
            let styles = window.getComputedStyle(_node);
            if (styles.overflowY !== 'visible') {
                return _node;
            }
            return findScrollElement(_node.parentNode);
        }
    },
    search: function svSearch(query) {
        if (!query) {
            return;
        }
        let queryLowerCased = query.toLocaleLowerCase();
        query = Normalizer.toAscii(queryLowerCased);
        this.dataSource = [];
        let elements, searchResult;
        let option = TabBar.option;
        let selected;
        if (ModeManager.currentMode === MODE_SEARCH_FROM_LIST || ModeManager.currentMode === MODE_SEARCH_FROM_LIST_PICK) {
            selected = ListView.selected;
            elements = ListView.dataSource;
            searchResult = this.searchListView.children[1].children[1];
        } else if (ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST) {
            selected = SubListView.selected;
            elements = SubListView.dataSource;
            option = 'title';
            searchResult = this.searchSubListView.children[1].children[1];
        }
        this.clean(searchResult);
        for (let i = 0; i < elements.length; i++) {
            let resultLowerCased = elements[i].metadata[option].toLocaleLowerCase();
            if (Normalizer.toAscii(resultLowerCased).indexOf(query) !== -1) {
                this.dataSource.push(elements[i]);
                let isSelected;
                if (selected.has(i)) {
                    isSelected = true;
                }
                let element = createListElement(option, elements[i], this.dataSource.length - 1, query, isSelected, String(i));
                searchResult.appendChild(element);
            } else {
                selected.delete(i);
            }
        }
        this.showSearchResult(searchResult);
    },
    showSearchResult: function _showSearchResult(searchResult) {
        if (ModeManager.currentMode === MODE_SEARCH_FROM_LIST || ModeManager.currentMode === MODE_SEARCH_FROM_LIST_PICK) {
            if (searchResult.children.length === 0) {
                this.searchListView.children[0].classList.remove('hidden');
                this.searchListView.children[1].classList.add('hidden');
                let option = TabBar.option === 'title' ? 'search-no-result' : TabBar.option + 's-search-no-result';
                this.searchListView.children[0].children[0].dataset.l10nId = option;
            } else {
                this.searchListView.children[0].classList.add('hidden');
                this.searchListView.children[1].classList.remove('hidden');
                document.querySelector('#search-list-count').textContent = searchResult.children.length;
                document.querySelector('#search-list-option').dataset.l10nId = 'search-' + TabBar.option + 's';
            }
            ListView.updateUI();
        } else if (ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST) {
            if (searchResult.children.length === 0) {
                this.searchSubListView.children[0].classList.remove('hidden');
                this.searchSubListView.children[1].classList.add('hidden');
            } else {
                this.searchSubListView.children[0].classList.add('hidden');
                this.searchSubListView.children[1].classList.remove('hidden');
                document.querySelector('#search-sublist-count').textContent = this.dataSource.length;
            }
            SubListView.updateSoftKeys();
            SubListView.updateTitle();
        }
    },
    updateDataSource: function (target, deleteNode) {
        let type = SubListView.isInMyPlaylist ? 'id' : 'name';
        for (let i = 0; i < this.dataSource.length; i++) {
            if (this.dataSource[i][type] === target) {
                this.dataSource.splice(i, 1);
                if (deleteNode) {
                    let parentNode = ModeManager.currentMode === MODE_SEARCH_FROM_LIST ? this.list_anchor : this.sublist_anchor;
                    parentNode.removeChild(parentNode.children[i]);
                }
                break;
            }
        }
    }
};
window.SearchView = SearchView;