const LIST_DATASOURCE_KEY = 'list_datasource_key';
const HASH_NUM = 8;
const SUBLIST_BATCH_SIZE = 40;
const SUBLIST_BATCH_TIME = 10;
const toPlaylist = {
    enabled: false,
    state: false,
    source: []
};
var SubListView = {
    get view() {
        return document.getElementById('views-sublist');
    },
    get dataSource() {
        return this._dataSource;
    },
    get listDataSource() {
        return this._listDataSource;
    },
    get viewLength() {
        return ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST ? SearchView.dataSource.length : this.dataSource.length;
    },
    get listItems() {
        return this.anchor ? this.anchor.querySelectorAll('li.focusable') : [];
    },
    get items() {
        return ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST ? SearchView.sublist_anchor.children : this.listItems;
    },
    get anchor() {
        return document.getElementById('views-sublist-anchor');
    },
    get list_anchor() {
        return document.getElementById('views-sublist-list-anchor');
    },
    get searchInput() {
        return document.getElementById('views-sublist-search-input');
    },
    get isFocusingInput() {
        return Boolean(this.searchInput === document.activeElement);
    },
    get searchBox() {
        return document.getElementById('views-sublist-search');
    },
    get textInput() {
        return document.getElementById('views-sublist-create-playlist-input');
    },
    get textBox() {
        return document.getElementById('views-sublist-create-playlist');
    },
    set dataSource(source) {
        this._dataSource = source;
    },
    set listDataSource(source) {
        this._listDataSource = source;
    },
    get isInMyPlaylist() {
        return this.listIndex !== null;
    },
    get mode() {
        return this._mode;
    },
    set mode(mode) {
        this._mode = mode;
        this.view.setAttribute('mode', mode);
        this.view.focus();
        this.updateSoftKeys();
        this.updateTitle();
    },
    get isPreloadedList() {
        return this.playlistL10nId && this.playlistL10nId !== PLAYLIST;
    },
    init: function slv_init() {
        this.selected = new Map();
        this.handle = null;
        this.dataSource = [];
        this.listDataSource = [];
        this.selectedSource = [];
        this.index = 0;
        this.focusIndex = 0;
        this.listIndex = null;
        this.view.addEventListener('input', this);
        this.view.addEventListener('keydown', this);
        this.searchBox.addEventListener('focus', this, true);
        this.searchBox.addEventListener('blur', this, true);
        this.textBox.addEventListener('focus', this, true);
        this.textBox.addEventListener('blur', this, true);
        this.mode = 'normal';
        this.updateSoftKeys();
        window.asyncStorage.getItem(LIST_DATASOURCE_KEY, listData => {
            if (listData && listData.length > 0) {
                toPlaylist.enabled = true;
            }
        });
    },
    clean: function slv_clean(option) {
        if (this.handle) {
            musicdb.cancelEnumeration(this.handle);
        }
        if (option === 'lists') {
            this.list_anchor.innerHTML = '';
        } else {
            this.dataSource = [];
            this.anchor.innerHTML = '';
        }
        this.index = 0;
        this.view.scrollTop = 0;
        this.selected.clear();
    },
    updatePlayingIcon: function lv_updatePlayingIcon(isUnique) {
        if (typeof PlayerView === 'undefined') {
            return;
        }
        let playSongName = PlayerView.playSongName;
        let currentIcon = this.anchor.querySelector('.list-playing-icon.active');
        if (currentIcon) {
            currentIcon.classList.remove('active');
        }
        if (PlayerView.playStatus !== PLAYSTATUS_PLAYING) {
            return;
        }
        if (!isUnique) {
            findPlayingIcon.call(this, playSongName, 'name');
        } else if (PlayerView.playSongId) {
            findPlayingIcon.call(this, PlayerView.playSongId, 'id');
        } else {
            findPlayingIcon.call(this, playSongName, 'name');
        }
        function findPlayingIcon(target, type) {
            this.dataSource.some((data, index) => {
                if (data[type] === target) {
                    try {
                        this.anchor.querySelector(`[data-index='${ index }']`).querySelector('.list-playing-icon').classList.add('active');
                    } catch (e) {
                    }
                    return true;
                }
            });
        }
    },
    updateSoftKeys: function lv_updateSoftKeys(isUpdateItems = true) {
        if (this.batchUpdateTimer) {
            SoftKeyStore.unregister(this.view);
            return;
        }
        if (this.mode === 'normal') {
            let isHide = isDongleConnect();
            switch (ModeManager.currentMode) {
            case MODE_SUBLIST:
            case MODE_SEARCH_FROM_SUBLIST:
                if (this.dataSource.length === 0) {
                    if (this.isInMyPlaylist) {
                        SoftKeyStore.register({
                            'left': isHide ? '' : 'opt-player',
                            'center': '',
                            'right': 'options'
                        }, this.view);
                    } else {
                        SoftKeyStore.register({
                            'left': '',
                            'center': 'ok',
                            'right': ''
                        }, this.view);
                    }
                } else {
                    SoftKeyStore.register({
                        'left': isHide ? '' : 'opt-player',
                        'center': isHide ? 'select' : 'icon=play',
                        'right': this.isPreloadedList || isHide ? '' : 'options'
                    }, this.view);
                    SoftKeyStore.register({
                        'left': isHide ? '' : 'opt-player',
                        'center': '',
                        'right': ''
                    }, this.searchInput);
                }
                isUpdateItems && this.updateItemSoftKey();
                break;
            case MODE_SUBLIST_LIST:
                if (this.listDataSource.length === 0) {
                    SoftKeyStore.register({
                        'left': isHide ? '' : 'opt-player',
                        'center': '',
                        'right': 'opt-create'
                    }, this.view);
                } else {
                    SoftKeyStore.register({
                        'left': isHide ? '' : 'opt-player',
                        'center': 'select',
                        'right': 'options'
                    }, this.view);
                }
                break;
            case MODE_SUBLIST_CREATE_LIST:
                SoftKeyStore.register({
                    'left': '',
                    'center': '',
                    'right': 'next'
                }, this.textInput);
                break;
            default:
                break;
            }
        } else if (ModeManager.currentMode !== MODE_SUBLIST_LIST) {
            if (this.isInMyPlaylist) {
                SoftKeyStore.register({
                    'left': this.selected.size === this.viewLength ? 'none' : 'all',
                    'center': 'select',
                    'right': this.isRemove ? this.selected.size > 0 ? 'remove' : '' : this.selected.size > 0 ? 'delete' : ''
                }, this.view);
                SoftKeyStore.register({
                    'left': this.selected.size === this.viewLength ? 'none' : 'all',
                    'center': '',
                    'right': ''
                }, this.searchInput);
            } else {
                if (toPlaylist.state) {
                    SoftKeyStore.register({
                        'left': this.selected.size === this.viewLength ? 'none' : 'all',
                        'center': 'select',
                        'right': this.selected.size > 0 ? 'next' : ''
                    }, this.view);
                } else {
                    SoftKeyStore.register({
                        'left': this.selected.size === this.viewLength ? 'none' : 'all',
                        'center': 'select',
                        'right': this.selected.size > 0 ? 'delete' : ''
                    }, this.view);
                }
                SoftKeyStore.register({
                    'left': this.selected.size === this.viewLength ? 'none' : 'all',
                    'center': '',
                    'right': ''
                }, this.searchInput);
            }
            isUpdateItems && this.updateItemSoftKey();
        } else {
            SoftKeyStore.register({
                'left': '',
                'center': 'select',
                'right': ''
            }, this.view);
        }
    },
    updateTitle: function lv_updateTitle() {
        if (this.mode === 'normal') {
            if (ModeManager.currentMode === MODE_SUBLIST_CREATE_LIST) {
                TitleBar.updateById('playlists-create-playlists');
            } else if (ModeManager.currentMode === MODE_SUBLIST_LIST) {
                TitleBar.updateById('playlists-my-playlists');
            } else {
                setTimeout(() => {
                    TitleBar.updateByContent(this.albumName);
                });
            }
        }
        if (this.mode === 'edit') {
            if (ModeManager.currentMode === MODE_SUBLIST_LIST) {
                TitleBar.updateById('playlists-choose-playlists');
            } else {
                TitleBar.updateById('song-num-checked', { n: this.selected.size });
            }
        }
    },
    updateItemSoftKey: function lv_updateSoftKey() {
        if (this.items.length === 0) {
            return;
        }
        for (let i = 0; i < this.items.length; i++) {
            this.items[i].dataset.selected === 'true' ? SoftKeyStore.register({ 'center': 'deselect' }, this.items[i]) : SoftKeyStore.unregister(this.items[i]);
        }
    },
    buildOptionMenu: function lv_buildOptionMenu() {
        let target = document.activeElement;
        let optionsArr = [];
        let optShuffleAll = {
            id: 'opt-shuffleall',
            callback: () => {
                this.playWithShuffleAll();
            }
        };
        let optAddToPlaylist = {
            id: 'opt-addtoplaylist',
            callback: () => {
                this.mode = 'edit';
                toPlaylist.state = true;
            }
        };
        let optAddSongs = {
            id: 'opt-addsongs',
            callback: () => {
                ModeManager.push(MODE_LIST_FROM_SUBLIST, () => {
                    let info = {
                        key: 'metadata.title',
                        range: null,
                        direction: 'next',
                        option: 'title'
                    };
                    ListView.activate(info, () => {
                        ListView.needReset = true;
                    });
                });
            }
        };
        let optRemoveSongs = {
            id: 'opt-removesongs',
            callback: () => {
                this.isRemove = true;
                this.mode = 'edit';
            }
        };
        let optShare = {
            id: 'opt-share',
            callback: () => {
                this.view.focus();
                startActivity(this.dataSource[this.focusIndex], 'share');
            }
        };
        let optSetRingTone = {
            id: 'opt-setring',
            callback: () => {
                this.view.focus();
                startActivity(this.dataSource[this.focusIndex], 'set-ringtone');
            }
        };
        let optDelete = {
            id: 'opt-delete',
            callback: () => {
                Dialog.show('delete-album-songs', { n: 1 }, () => {
                    this.view.focus();
                }, () => {
                    this.deleteSelected(target);
                });
            }
        };
        let optMulselect = {
            id: 'opt-mulselect',
            callback: () => {
                this.mode = 'edit';
            }
        };
        let optCreatePlaylist = {
            id: 'opt-createplaylist',
            callback: () => {
                ModeManager.push(MODE_SUBLIST_CREATE_LIST);
                this.navigator.setFocus(this.textInput);
                this.updateSoftKeys();
            }
        };
        let optRename = {
            id: 'opt-rename',
            callback: () => {
                Dialog.show(null, null, () => {
                    this.view.focus();
                }, () => {
                    this.renameSelectedList(target);
                }, {
                    headerl10nId: 'rename',
                    type: 'input',
                    primaryValue: target.querySelector('bdi').textContent
                });
            }
        };
        let optDeleteList = {
            id: 'opt-delete',
            callback: () => {
                Dialog.show('delete-playlist', null, () => {
                    this.view.focus();
                }, () => {
                    this.deleteSelectedList(target);
                }, { headerl10nId: 'delete' });
            }
        };
        if (MainView.bLowMemoryDevice) {
            optionsArr = [
                optDelete,
                optMulselect
            ];
        } else {
            optionsArr = [
                optShare,
                optSetRingTone,
                optDelete,
                optMulselect
            ];
        }
        if (this.isInMyPlaylist) {
            if (this.dataSource.length === 0) {
                optionsArr = [optAddSongs];
            } else {
                optionsArr.unshift(optShuffleAll, optAddSongs, optRemoveSongs);
            }
        } else if (toPlaylist.enabled && this.playlistL10nId === null) {
            optionsArr.unshift(optShuffleAll, optAddToPlaylist);
        } else {
            optionsArr.unshift(optShuffleAll);
        }
        if (ModeManager.currentMode === MODE_SUBLIST_LIST) {
            optionsArr = [
                optCreatePlaylist,
                optRename,
                optDeleteList
            ];
        }
        return optionsArr;
    },
    playWithShuffleAll: function lv_playWithShuffleAll() {
        let dataSource = ModeManager.currentMode === MODE_SUBLIST ? this.dataSource : SearchView.dataSource;
        ModeManager.push(MODE_PLAYER, () => {
            PlayerView.setSourceType(TYPE_LIST);
            PlayerView.dataSource = dataSource;
            PlayerView.setShuffle(true);
            PlayerView.play(PlayerView.shuffledList[0], true);
        });
    },
    deleteSelected: function lv_deleteSelected(target) {
        let songName = target.dataset.songName;
        let delResolve;
        window.delPromise = new Promise(resolve => {
            delResolve = resolve;
        });
        if (typeof PlayerView !== 'undefined' && songName === PlayerView.playSongName) {
            PlayerView.stop();
        }
        if (this.isInMyPlaylist) {
            if (ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST) {
                this.searchInput.value = '';
                ModeManager.pop();
            } else {
                this.indexBeforeDelete = this.focusIndex;
            }
            window.delPromise = null;
            return musicdb.deleteFile(songName);
        }
        musicdb.deleteFile(songName, () => delResolve());
        if (ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST) {
            this.searchInput.value = '';
            ModeManager.pop();
        } else {
            this.indexBeforeDelete = this.focusIndex;
        }
    },
    deleteMultiSelected: function lv_deleteMultiSelected() {
        if (this.selected.size === 0) {
            return;
        }
        let length = this.selected.size;
        let deletedItems = [];
        let isUnique = this.isInMyPlaylist;
        let index = 0;
        let delResolve;
        window.delPromise = new Promise(resolve => {
            delResolve = resolve;
        });
        this.selected.forEach((value, key) => {
            let songName = this.dataSource[key].name;
            if (typeof PlayerView !== 'undefined' && songName === PlayerView.playSongName) {
                PlayerView.stop();
            }
            if (isUnique) {
                if (!deletedItems.includes(songName)) {
                    if (window.delPromise) {
                        window.delPromise = null;
                    }
                    deletedItems.push(songName);
                    musicdb.deleteFile(songName);
                }
            } else {
                musicdb.deleteFile(songName, () => {
                    index++;
                    if (index === length) {
                        delResolve();
                    }
                });
            }
        });
        if (ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST) {
            this.searchInput.value = '';
            ModeManager.pop();
        } else {
            this.indexBeforeDelete = this.focusIndex;
        }
        this.mode = 'normal';
        this.selected.clear();
    },
    removeMultiSelected: function lv_removeMultiSelected() {
        let indexCompensate = 0;
        let playerIndexDiff = 0;
        let selects = [];
        let playSongId = typeof PlayerView !== 'undefined' ? PlayerView.playSongId : '';
        let containsPlaySong;
        if (playSongId !== '') {
            containsPlaySong = this.dataSource.some(songData => {
                return songData.id === playSongId;
            });
        }
        this.selected.forEach((value, key) => {
            selects.push(key);
        });
        selects.sort((a, b) => a - b);
        selects.forEach(index => {
            let songItem = this.anchor.children[index + indexCompensate];
            this.dataSource.splice(index + indexCompensate, 1);
            this.anchor.removeChild(songItem);
            if (ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST) {
                SearchView.updateDataSource(songItem.dataset.id, true);
            }
            if (containsPlaySong) {
                if (playSongId === songItem.dataset.id) {
                    PlayerView.stop();
                } else if (index <= PlayerView.currentIndex) {
                    playerIndexDiff++;
                }
            }
            indexCompensate--;
        });
        if (containsPlaySong && PlayerView.playStatus === PLAYSTATUS_PLAYING) {
            PlayerView.currentIndex -= playerIndexDiff;
        }
        this.isRemove = false;
        this.updateStorage();
        this.mode = 'normal';
        this.selected.clear();
        this.updateSubListView();
    },
    deleteSelectedList: function lv_deleteSelected(target) {
        let listId = target.dataset.id;
        this.listDataSource.forEach((list, i) => {
            if (listId === list.id) {
                this.listDataSource.splice(i, 1);
                this.updateStorage();
                this.list_anchor.removeChild(this.list_anchor.children[i]);
            }
        });
        for (let i = 0; i < this.list_anchor.children.length; i++) {
            this.list_anchor.children[i].dataset.index = i;
        }
        this.indexBeforeDelete = this.focusIndex;
        this.updateSubListView();
    },
    renameSelectedList: function lv_deleteSelected(target) {
        let listName = target.querySelector('bdi').textContent;
        let value = document.getElementById('dialog-content-input').value.trim();
        let listId = target.dataset.id;
        this.listDataSource.forEach((list, i) => {
            if (list.id === listId) {
                this.listDataSource[i].listName = value;
                this.listDataSource[i].metadata.title = value;
                this.updateStorage();
                this.list_anchor.children[i].querySelector('bdi').textContent = value;
            }
        });
        this.view.focus();
    },
    updateSubListView: function lv_updateSubListView() {
        if (!this.list_anchor.classList.contains('hidden') && this.list_anchor.children.length === 0) {
            toPlaylist.enabled = false;
            this.hideNode(this.list_anchor);
            this.showNode(this.anchor.parentNode.querySelector('#views-no-my-playlists'));
            this.updateSoftKeys();
            this.view.focus();
        } else if (!this.anchor.classList.contains('hidden') && this.anchor.children.length === 0) {
            if (this.isInMyPlaylist) {
                this.hideNode(this.anchor);
                this.hideNode(this.searchBox);
                this.showNode(this.anchor.parentNode.querySelector('#views-no-songs-added'));
            } else {
                ModeManager.start(MODE_LIST);
            }
        } else {
            if (ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST) {
                this.searchInput.value = '';
                ModeManager.pop();
            }
            if (ModeManager.currentMode === MODE_SUBLIST_LIST) {
                if (this.indexBeforeDelete) {
                    let focusNode = null;
                    this.indexBeforeDelete = Math.min(this.listDataSource.length - 1, this.indexBeforeDelete);
                    focusNode = this.list_anchor.querySelector(`[data-index='${ this.indexBeforeDelete }']`);
                    if (focusNode) {
                        this.focusIndex = this.indexBeforeDelete;
                        this.navigator.setFocus(focusNode);
                    }
                    this.indexBeforeDelete = 0;
                }
            }
            if (this.isInMyPlaylist) {
                this.updateIndexes();
            }
            this.updateNumbers();
            this.view.focus();
        }
    },
    updateSelectedItems: function () {
        let selectedItems = this.anchor.querySelectorAll('[data-selected="true"]');
        Array.from(selectedItems).map(item => {
            item.dataset.selected = false;
        });
        for (let index of this.selected.keys()) {
            let target = this.anchor.querySelector(`[data-index='${ index }']`);
            if (target) {
                target.dataset.selected = true;
            }
        }
    },
    multiSelete: function lvMultiSelete() {
        if (this.selected.size > 0) {
            Dialog.show('delete-album-songs', { n: this.selected.size }, () => {
                this.view.focus();
            }, () => {
                this.deleteMultiSelected();
            });
        }
    },
    toggle: function lvToggleCurrent(item, option) {
        let index;
        if (ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST) {
            index = Number(item.dataset.originIndex);
        } else {
            index = Number(item.dataset.index);
        }
        if (isNaN(index)) {
            return;
        }
        let select = () => {
            this.selected.set(index, true);
            item.dataset.selected = true;
            const checkbox = item.querySelector('.check-icon');
            checkbox && checkbox.setAttribute('aria-checked', true);
        };
        let deSelect = () => {
            this.selected.delete(index);
            item.dataset.selected = false;
            const checkbox = item.querySelector('.check-icon');
            checkbox && checkbox.setAttribute('aria-checked', false);
        };
        if (option === 'selectAll') {
            select();
        } else if (option === 'deselectAll') {
            deSelect();
        } else if (this.selected.has(index)) {
            deSelect();
        } else {
            select();
        }
        if (!option) {
            this.updateSoftKeys();
            this.updateTitle();
        }
    },
    toggleAll: function lvToggleAll(option) {
        if (ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST && this.viewLength === 0) {
            return;
        }
        if (!option) {
            if (this.selected.size === this.viewLength) {
                option = 'deselectAll';
            } else {
                option = 'selectAll';
            }
        }
        for (let i = 0; i < this.items.length; i++) {
            this.toggle(this.items[i], option);
        }
        this.updateSoftKeys();
        this.updateTitle();
    },
    updateNumbers: function lvUpdateNumbers() {
        let numbers = document.querySelectorAll('.list-song-index');
        for (let i = 0; i < numbers.length; i++) {
            numbers[i].textContent = i + 1;
        }
    },
    updateIndexes: function lvUpdateIndexes() {
        for (let i = 0; i < this.listItems.length; i++) {
            this.listItems[i].dataset.index = i;
        }
    },
    activate: function (option, data, index, keyRange, direction, callback) {
        let targetOption;
        if (option === 'lists') {
            targetOption = 'lists';
        } else if (option === 'list') {
            targetOption = 'list';
        } else if (option === 'date') {
            targetOption = 'date';
        } else {
            targetOption = 'metadata.' + option;
        }
        this.navigator && this.navigator.destroy();
        this.hideNode(this.searchBox);
        this.clean(option);
        this.navigator = new SimpleNavigationHelper('.focusable', this.view, null, option === 'lists' ? 0 : 1);
        index !== null && (this.listIndex = index);
        if (targetOption === 'lists') {
            window.asyncStorage.getItem(LIST_DATASOURCE_KEY, listData => {
                this.listDataSource = listData ? listData : [];
                if (this.listDataSource.length > 0) {
                    this.update(this.listDataSource, 'list');
                } else {
                    setTimeout(() => this.updateSoftKeys());
                }
                if (callback) {
                    callback();
                }
            });
            return;
        }
        if (targetOption === 'list') {
            this.dataSource = data.source;
            this.albumName = data.listName;
            if (this.dataSource.length > 0) {
                this.update(this.dataSource, 'song-multi-title');
            } else {
                setTimeout(() => this.updateSoftKeys());
            }
            if (callback) {
                callback();
            }
            return;
        }
        this.handle = musicdb.enumerateAll(targetOption, keyRange, direction, dataArray => {
            if (dataArray.length === 0) {
                ModeManager.start(MODE_LIST);
                ListView.resetUI();
                return;
            }
            var albumNameL10nId;
            var playListOption;
            if (option === 'album') {
                let noTrackArr = [];
                let hasTrackArr = dataArray.filter(data => {
                    if (!data.metadata.tracknum) {
                        noTrackArr.push(data);
                        return false;
                    }
                    return true;
                });
                hasTrackArr.sort((e1, e2) => e1.metadata.tracknum - e2.metadata.tracknum);
                noTrackArr.sort((e1, e2) => e1.metadata.title > e2.metadata.title ? 1 : -1);
                dataArray = hasTrackArr.concat(noTrackArr);
            }
            if (option === 'artist') {
                this.albumName = data.metadata.artist || window.api.l10n.get('unknownArtist');
            } else if (option === 'album') {
                this.albumName = data.metadata.album || window.api.l10n.get('unknownAlbum');
            } else if (option === 'title') {
                this.albumName = data.metadata.title || window.api.l10n.get('unknownTitle');
            } else {
                this.albumName = window.api.l10n.get(data.metadata.l10nId);
                this.playlistL10nId = data.metadata.l10nId;
                albumNameL10nId = data.metadata.l10nId;
                playListOption = albumNameL10nId ? albumNameL10nId.substring(10) : '';
            }
            if (playListOption === 'discover') {
                if (!App.discover) {
                    const count = 30;
                    dataArray.sort(() => {
                        return 0.5 - Math.random();
                    });
                    if (dataArray.length > count) {
                        this.dataSource = dataArray.slice(0, count);
                    } else {
                        this.dataSource = dataArray;
                    }
                    App.discover = this.dataSource;
                } else {
                    if (App.discover.length === 0) {
                        ModeManager.start(MODE_LIST);
                        ListView.resetUI();
                        return;
                    }
                    this.dataSource = App.discover;
                }
            } else if (playListOption === 'most-played') {
                const mostplaycount = 50;
                dataArray.forEach(item => {
                    if (item.metadata.played > 0) {
                        this.dataSource.push(item);
                    }
                });
                if (this.dataSource.length > 0) {
                    this.dataSource.sort((a, b) => {
                        return b.metadata.played - a.metadata.played;
                    });
                }
                if (this.dataSource.length > mostplaycount) {
                    this.dataSource = this.dataSource.slice(0, mostplaycount);
                }
            } else if (playListOption === 'recently-added') {
                var nowTime = new Date().getTime();
                const displayTime = 2 * 7 * 24 * 60 * 60 * 1000;
                dataArray.forEach(item => {
                    if (nowTime - item.firstParseTime < displayTime) {
                        this.dataSource.push(item);
                    }
                });
                if (this.dataSource.length > 0) {
                    this.dataSource.sort((a, b) => {
                        return b.date - a.date;
                    });
                }
            } else {
                this.dataSource = dataArray;
            }
            let inPlaylist = option !== 'artist' && option !== 'album' && option !== 'title';
            if (inPlaylist) {
                this.update(this.dataSource, 'song-multi-title');
            } else if (option === 'album') {
                this.update(this.dataSource, 'song-track');
            } else {
                this.update(this.dataSource, 'song');
            }
            if (callback) {
                callback();
            }
        });
    },
    viewController: function _viewController(mode, options = {}) {
        options.playlistL10nId && (this.playlistL10nId = options.playlistL10nId);
        switch (mode) {
        case MODE_SUBLIST:
        case MODE_SUBLIST_LIST:
            this.updateTitle();
            this.hideNode(this.textBox);
            this.hideNode(this.searchBox);
            this.hideNode(SearchView.searchSubListView);
            this.hideNode(Array.from(this.anchor.parentNode.children));
            this.showNode(this.anchor.parentNode);
            if (options.playlistL10nId && (mode === MODE_SUBLIST && this.dataSource.length === 0 || mode === MODE_SUBLIST_LIST && this.listDataSource.length === 0)) {
                if (this.isInMyPlaylist) {
                    this.showNode(this.anchor.parentNode.querySelector('#views-no-songs-added'));
                } else {
                    this.showNode(this.anchor.parentNode.querySelector('#' + options.playlistL10nId.replace('playlists', 'views-no')));
                }
            } else if (mode !== MODE_SUBLIST_LIST) {
                this.showNode(this.searchBox);
                this.showNode(this.anchor);
            } else {
                this.showNode(this.list_anchor);
            }
            break;
        case MODE_SEARCH_FROM_SUBLIST:
            this.hideNode(this.anchor.parentNode);
            this.showNode(this.searchBox);
            this.showNode(SearchView.searchSubListView);
            break;
        case MODE_SUBLIST_CREATE_LIST:
            this.updateTitle();
            this.hideNode(this.anchor.parentNode);
            this.showNode(this.textBox);
            break;
        default:
            break;
        }
    },
    showNode: function (node) {
        if (Array.isArray(node)) {
            node.forEach(el => {
                el.classList.remove('hidden');
            });
        } else {
            node.classList.remove('hidden');
        }
    },
    hideNode: function (node) {
        if (Array.isArray(node)) {
            node.forEach(el => {
                el.classList.add('hidden');
            });
        } else {
            node.classList.add('hidden');
        }
    },
    update: function slvUpdate(source, option) {
        if (!source || source.length === 0) {
            setTimeout(() => this.updateSoftKeys());
            return;
        }
        let _this = this;
        batchUpdate();
        function batchUpdate() {
            _this.batchUpdateTimer = setTimeout(() => {
                chunkData(source, option, SUBLIST_BATCH_SIZE, _this.index, batchUpdate);
            }, SUBLIST_BATCH_TIME);
        }
        function chunkData(source, type, num, start, callback) {
            let arr = source.slice(start, start + num);
            if (arr.length > 0) {
                let fragment = document.createDocumentFragment();
                arr.forEach(data => {
                    fragment.appendChild(createListElement(type, data, _this.index));
                    _this.index++;
                });
                if (type === 'list') {
                    _this.list_anchor.appendChild(fragment);
                } else {
                    _this.anchor.appendChild(fragment);
                }
                if (start === 0) {
                    _this.updateSoftKeys(false);
                    _this.view.focus();
                }
                fragment = null;
                callback();
            } else {
                if (_this.indexBeforeDelete) {
                    _this.indexBeforeDelete = Math.min(_this.dataSource.length - 1, _this.indexBeforeDelete);
                    const focusNode = _this.anchor.querySelector(`[data-index='${ _this.indexBeforeDelete }']`);
                    if (focusNode) {
                        _this.focusIndex = _this.indexBeforeDelete;
                        _this.navigator.setFocus(focusNode);
                    }
                    _this.indexBeforeDelete = 0;
                }
                _this.batchUpdateTimer = null;
                _this.updatePlayingIcon(_this.isInMyPlaylist);
                _this.navigator.refresh([]);
                setTimeout(() => {
                    _this.updateSoftKeys(false);
                    _this.view.focus();
                });
            }
        }
    },
    updateStorage: function slvUpdateStorage(source) {
        window.asyncStorage.setItem(LIST_DATASOURCE_KEY, source || this.listDataSource);
    },
    activePlayView: function (target, source) {
        if (target.dataset.index) {
            ModeManager.push(MODE_PLAYER, () => {
                let targetIndex = Number(target.dataset.index);
                let forcePlay = SubListView.isInMyPlaylist && !target.lastChild.classList.contains('active');
                PlayerView.setSourceType(TYPE_LIST);
                PlayerView.dataSource = source;
                if (PlayerView.shuffleOption) {
                    PlayerView.shuffleList(targetIndex);
                    PlayerView.play(PlayerView.shuffledList[0], true, false, forcePlay);
                } else {
                    PlayerView.play(targetIndex, true, false, forcePlay);
                }
            });
        }
    },
    activateSubListView: function lvActivateSubListView(target) {
        let index = ModeManager.currentMode === MODE_SUBLIST_LIST && !this.isInMyPlaylist ? this.focusIndex : null;
        this.currentTarget = target || this.currentTarget;
        this.activate('list', this.currentTarget, index, null, 'next', () => {
            ModeManager.push(MODE_SUBLIST);
        });
    },
    updateFocusIndex: function (index, key) {
        if (key) {
            if (key === 'ArrowUp') {
                if (this.isFocusingInput) {
                    index = this.dataSource.length - 1;
                } else if (ModeManager.currentMode === MODE_SUBLIST_LIST && index === 0) {
                    index = this.listDataSource.length - 1;
                } else {
                    index -= 1;
                }
            } else if (key === 'ArrowDown') {
                if (this.isFocusingInput) {
                    index = 0;
                } else if (ModeManager.currentMode === MODE_SUBLIST_LIST && index === this.listDataSource.length - 1) {
                    index = 0;
                } else {
                    index += 1;
                }
            }
            this.focusIndex = index;
        }
    },
    judgementBack: function slvJudgementBack() {
        if (this.isInMyPlaylist) {
            if (this.listNeedReset) {
                this.activate('lists');
            }
            this.navigator.initialFocusIndex = 0;
            ModeManager.pop();
            if (ModeManager.currentMode === MODE_SUBLIST_LIST) {
                this.navigator.setFocus(this.list_anchor.children[this.listIndex]);
                this.listIndex = null;
                this.listNeedReset = false;
                this.updateSoftKeys();
            }
        } else {
            ModeManager.pop();
            if (ListView.needReset) {
                App.showCurrentView();
            }
        }
    },
    handleEvent: function slvHandleEvent(evt) {
        var target = evt.target;
        if (!target || this.batchUpdateTimer) {
            return evt.preventDefault();
        }
        let index = Number(target.dataset.index) || 0;
        this.updateFocusIndex(index, evt.key);
        if (this.focusIndex < 0 || this.focusIndex >= this.dataSource.length) {
            this.searchInput.removeAttribute('aria-hidden');
        } else {
            this.searchInput.setAttribute('aria-hidden', true);
        }
        switch (evt.type) {
        case 'input':
            if (target.id === 'views-sublist-search-input' && !evt.isComposing) {
                if (target.value === '' && ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST) {
                    SearchView.clean(SearchView.sublist_anchor);
                    this.judgementBack();
                    this.updateSoftKeys();
                } else if (target.value !== '') {
                    if (ModeManager.currentMode === MODE_SUBLIST) {
                        ModeManager.push(MODE_SEARCH_FROM_SUBLIST);
                    }
                    SearchView.search(target.value);
                }
            }
            break;
        case 'blur':
            if (target.id === 'views-sublist-search-input') {
                this.searchBox.classList.remove('focused');
            } else if (target.id === 'views-sublist-create-playlist-input') {
                this.textBox.classList.remove('focused');
            }
            break;
        case 'focus':
            if (target.id === 'views-sublist-search-input') {
                this.searchBox.classList.add('focused');
            } else if (target.id === 'views-sublist-create-playlist-input') {
                this.textBox.classList.add('focused');
            }
            break;
        case 'keydown':
            switch (evt.key) {
            case 'Backspace':
                evt.preventDefault();
                if (this.mode === 'normal') {
                    if (target.id === 'views-sublist-search-input') {
                        if (this.searchInput.value.length > 0) {
                            this.navigator.setFocus(this.searchInput);
                        } else {
                            this.judgementBack();
                        }
                    } else if (target.id === 'views-sublist-create-playlist-input') {
                        if (this.textInput.value.length > 0) {
                            this.navigator.setFocus(this.textInput);
                        } else {
                            ModeManager.pop();
                            this.updateSoftKeys();
                        }
                    } else if (this.searchInput.value.length > 0) {
                        this.navigator.setFocus(this.searchInput);
                    } else {
                        this.judgementBack();
                    }
                } else {
                    this.mode = 'normal';
                    this.toggleAll('deselectAll');
                    this.updateSoftKeys();
                    if (this.isRemove) {
                        this.isRemove = false;
                    }
                    if (toPlaylist.state) {
                        if (ModeManager.currentMode === MODE_SUBLIST_LIST) {
                            toPlaylist.state = false;
                            this.playlistL10nId = null;
                            toPlaylist.source = [];
                            ModeManager.pop();
                            if (ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST) {
                                this.navigator.setFocus(SearchView.sublist_anchor.children[0]);
                            } else {
                                this.navigator.setFocus(this.anchor.children[0]);
                            }
                        } else {
                            toPlaylist.state = false;
                        }
                    }
                }
                break;
            case 'Enter':
                if (this.mode === 'normal') {
                    if (ModeManager.currentMode === MODE_SUBLIST_LIST) {
                        let target = this.listDataSource[this.focusIndex];
                        target && this.activateSubListView(target);
                    } else if (ModeManager.currentMode === MODE_SUBLIST || ModeManager.currentMode == MODE_SEARCH_FROM_SUBLIST) {
                        if (isDongleConnect()) {
                            return playByDongle(this);
                        }
                        let dataSource = ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST ? SearchView.dataSource : this.dataSource;
                        if (dataSource.length === 0 && !this.isInMyPlaylist) {
                            this.judgementBack();
                            return;
                        }
                        this.activePlayView(target, dataSource);
                    }
                } else {
                    if (ModeManager.currentMode === MODE_SUBLIST_LIST && toPlaylist.state) {
                        let addedNum = toPlaylist.source.length;
                        let targetPlaylist = this.listDataSource[this.focusIndex];
                        toPlaylist.state = false;
                        this.mode = 'normal';
                        this.playlistL10nId = null;
                        targetPlaylist.source = toPlaylist.source.concat(targetPlaylist.source);
                        this.updateStorage();
                        toPlaylist.source = [];
                        ModeManager.pop();
                        if (this.listIndex === this.focusIndex && ModeManager.currentMode === MODE_PLAYER) {
                            if (ModeManager.prevMode === MODE_SEARCH_FROM_SUBLIST) {
                                this.searchInput.value = '';
                                ModeManager._modeStack.splice(-2, 1);
                            }
                            this.currentTarget = targetPlaylist;
                            PlayerView.dataSource = targetPlaylist.source;
                            PlayerView.currentIndex++;
                            this.needReset = true;
                        }
                        if (ModeManager.currentMode === MODE_SUBLIST) {
                            this.updateSoftKeys();
                            this.navigator.setFocus(this.anchor.children[0]);
                        }
                        if (ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST) {
                            this.toggleAll('deselectAll');
                            this.updateSoftKeys();
                            this.navigator.setFocus(SearchView.sublist_anchor.children[0]);
                        }
                        Toaster.showToast({
                            message: addedNum > 1 ? addedNum + ' ' + window.api.l10n.get('add-to-playlist-songs-hint') + ' ' + targetPlaylist.listName : window.api.l10n.get('add-to-playlist-song-hint') + ' ' + targetPlaylist.listName,
                            latency: 2000
                        });
                        return;
                    }
                    this.toggle(target);
                }
                break;
            case 'HeadsetHook':
                if (typeof PlayerView !== 'undefined' && (PlayerView.playStatus === PLAYSTATUS_PLAYING || PlayerView.playStatus === PLAYSTATUS_PAUSED)) {
                    PlayerView.togglePlay();
                } else if (this.mode === 'normal' && (ModeManager.currentMode === MODE_SUBLIST || ModeManager.currentMode === MODE_SEARCH_FROM_SUBLIST)) {
                    ModeManager.playWithInit();
                }
                break;
            case 'SoftLeft':
                if (this.mode === 'normal') {
                    if (isDongleConnect()) {
                        return;
                    }
                    if (target.id !== 'views-sublist-create-playlist-input') {
                        this.searchInput.value = '';
                    }
                    if (this.dataSource.length > 0 || ModeManager.currentMode === MODE_SUBLIST_LIST || this.isInMyPlaylist) {
                        ModeManager.playWithInit(true);
                    }
                } else {
                    this.toggleAll();
                }
                this.updateSoftKeys();
                break;
            case 'SoftRight':
                if (this.mode === 'normal') {
                    let searchBoxClass = this.searchBox.classList;
                    switch (ModeManager.currentMode) {
                    case MODE_SUBLIST:
                    case MODE_SEARCH_FROM_SUBLIST:
                        if (this.isPreloadedList || isDongleConnect()) {
                            return;
                        }
                        if (this.dataSource.length === 0) {
                            if (this.isInMyPlaylist) {
                                OptionMenu.show(this.buildOptionMenu(), () => {
                                    this.view.focus();
                                });
                            }
                        } else if (!searchBoxClass.contains('focused')) {
                            OptionMenu.show(this.buildOptionMenu(), () => {
                                this.view.focus();
                            });
                        }
                        break;
                    case MODE_SUBLIST_LIST:
                        if (this.listDataSource.length === 0) {
                            ModeManager.push(MODE_SUBLIST_CREATE_LIST);
                            this.navigator.setFocus(this.textInput);
                            this.updateSoftKeys();
                        } else {
                            OptionMenu.show(this.buildOptionMenu(), () => {
                                this.view.focus();
                            });
                        }
                        break;
                    case MODE_SUBLIST_CREATE_LIST: {
                            if (this.textInput.value.trim() === '') {
                                return;
                            }
                            ModeManager._modeStack.push(MODE_LIST_FROM_SUBLIST);
                            let info = {
                                key: 'metadata.title',
                                range: null,
                                direction: 'next',
                                option: 'title'
                            };
                            ListView.activate(info, () => {
                                ModeManager._updateMode();
                                ListView.needReset = true;
                            });
                            break;
                        }
                    default:
                        break;
                    }
                } else {
                    if (target.type === 'search') {
                        return;
                    }
                    if (ModeManager.currentMode === MODE_SUBLIST_LIST || this.selected.size === 0) {
                        return;
                    }
                    if (!this.isInMyPlaylist && toPlaylist.state) {
                        for (let k of this.selected.keys()) {
                            let data = JSON.parse(JSON.stringify(this.dataSource[k]));
                            data.id = createHash(HASH_NUM);
                            toPlaylist.source.push(data);
                        }
                        this.activate('lists', null, null, null, null, () => {
                            ModeManager.push(MODE_SUBLIST_LIST);
                        });
                    } else if (this.isInMyPlaylist) {
                        if (this.isRemove) {
                            this.removeMultiSelected();
                        } else {
                            this.multiSelete();
                        }
                    } else if (this.selected.size !== 0) {
                        this.multiSelete();
                    }
                }
                break;
            default:
                break;
            }
            break;
        default:
            break;
        }
    }
};
window.SubListView = SubListView;