const handlerMap = {};
let resolveIdleTimeExtension = null;
const log = (...args) => {
    console.log('[music][sw.js]', ...args);
};
const addWebActivityRequestHandler = async handler => {
    const activityHandlerId = `${ +new Date() }`;
    handlerMap[activityHandlerId] = handler;
    log('addWebActivityRequestHandler: ', activityHandlerId);
    return activityHandlerId;
};
const removeWebActivityRequestHandler = async activityHandlerId => {
    delete handlerMap[activityHandlerId];
    log('removeWebActivityRequestHandler: ', activityHandlerId);
};
self.addEventListener('install', event => {
    event.waitUntil(self.skipWaiting());
});
self.addEventListener('activate', event => {
    event.waitUntil(self.clients.claim());
});
self.onsystemmessage = evt => {
    if (evt.name === 'activity') {
        const handler = evt.data.webActivityRequestHandler();
        addWebActivityRequestHandler(handler).then(activityHandlerId => {
            const data = {
                source: handler.source,
                activityHandlerId
            };
            switch (handler.source.name) {
            case 'pick':
                evt.waitUntil(clients.openWindow('index.html#pick', { disposition: 'inline' }).then(windowClient => {
                    if (windowClient) {
                        windowClient.postMessage(data);
                    }
                }));
                break;
            case 'open':
                evt.waitUntil(clients.openWindow('open.html', { disposition: 'inline' }).then(windowClient => {
                    if (windowClient) {
                        windowClient.postMessage(data);
                    }
                }));
                break;
            default:
                break;
            }
            const idleTimeExtension = new Promise(resolve => {
                resolveIdleTimeExtension = resolve;
            });
            evt.waitUntil(idleTimeExtension);
        });
    } else if ('media-button' === evt.name) {
        evt.waitUntil(clients.matchAll({
            includeUncontrolled: true,
            type: 'window'
        }).then(clientList => {
            for (let i = 0; i < clientList.length; i++) {
                if (clientList[i].url.indexOf('index.html') > 0) {
                    clientList[i].postMessage(evt.data.json().message);
                }
            }
        }));
    }
};
self.onmessage = evt => {
    const {data} = evt;
    if (data.isDummy) {
        return;
    }
    if (data.activityHandlerId) {
        const handler = handlerMap[data.activityHandlerId];
        if (data.isError) {
            handler.postError(data.activityResult);
        } else {
            handler.postResult(data.activityResult);
        }
        removeWebActivityRequestHandler(data.activityHandlerId);
    }
    if (resolveIdleTimeExtension) {
        resolveIdleTimeExtension();
        resolveIdleTimeExtension = null;
    }
};