'use strict';
/* eslint "camelcase": 'off' */
require.config({
  baseUrl: '/js',
  paths: {
    modules: 'modules',
    panels: 'panels'
  },
  shim: {
    utils: {
      exports: ''
    }
  },
  modules: [
    {
      name: 'main'
    },
    {
      name: 'modules/apn/apn_settings_manager',
      exclude: [
        'main',
        'modules/async_storage',
        'modules/mvvm/observable',
        'modules/apn/apn_const'
      ]
    },
    {
      name: 'modules/apn_tct/apn_settings_manager',
      exclude: [
        'main',
        'modules/async_storage',
        'modules/mvvm/observable',
        'modules/apn/apn_const'
      ]
    },
    {
      name: 'panels/root/panel',
      exclude: ['main', 'modules/apps_cache']
    },
    {
      name: 'panels/languages/panel',
      exclude: ['main']
    },
    {
      name: 'panels/app_notices_list/panel',
      exclude: ['main', 'modules/apps_cache']
    },
    {
      name: 'panels/screen_lock/panel',
      exclude: ['main']
    },
    {
      name: 'panels/screen_lock_passcode/panel',
      exclude: ['main']
    },
    {
      name: 'panels/display/panel',
      exclude: ['main', 'modules/mvvm/observable']
    },
    {
      name: 'panels/input_methods/panel',
      exclude: ['main']
    },
    {
      name: 'panels/input_languages_selection/panel',
      exclude: ['main']
    },
    {
      name: 'panels/app_storage/panel',
      exclude: ['main', 'modules/app_storage', 'modules/apps_cache']
    },
    {
      name: 'panels/wifi/panel',
      exclude: ['main']
    },
    {
      name: 'panels/wifi_auth/panel',
      exclude: ['main']
    },
    {
      name: 'panels/wifi_enter_certificate_nickname/panel',
      exclude: ['main']
    },
    {
      name: 'panels/wifi_join_hidden/panel',
      exclude: ['main']
    },
    {
      name: 'panels/wifi_manage_certificates/panel',
      exclude: ['main']
    },
    {
      name: 'panels/wifi_manage_networks/panel',
      exclude: ['main']
    },
    {
      name: 'panels/wifi_select_certificate_file/panel',
      exclude: ['main']
    },
    {
      name: 'panels/wifi_status/panel',
      exclude: ['main']
    },
    {
      name: 'panels/wifi_wps/panel',
      exclude: ['main']
    },
    {
      name: 'panels/date_time/panel',
      exclude: ['main', 'modules/mvvm/observable']
    },
    {
      name: 'panels/search/panel',
      exclude: ['main']
    },
    {
      name: 'panels/sound/panel',
      exclude: ['main']
    },
    {
      name: 'panels/simcard_manager/panel',
      exclude: ['main']
    },
    {
      name: 'panels/hotspot/panel',
      exclude: ['main', 'modules/mvvm/observable']
    },
    {
      name: 'panels/hotspot_wifi_settings/panel',
      exclude: ['main', 'modules/mvvm/observable']
    },
    {
      name: 'panels/about/panel',
      exclude: ['main']
    },
    {
      name: 'panels/about_more_info/panel',
      exclude: ['main']
    },
    {
      name: 'panels/developer/panel',
      exclude: ['main', 'modules/apps_cache']
    },
    {
      name: 'panels/developer_hud/panel',
      exclude: ['main']
    },
    {
      name: 'panels/call_barring/panel',
      exclude: ['main', 'modules/mvvm/observable']
    },
    {
      name: 'panels/call_barring_passcode_change/panel',
      exclude: ['main']
    }
  ]
});
