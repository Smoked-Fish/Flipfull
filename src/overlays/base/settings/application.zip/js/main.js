/* global ScreenLayout */

'use strict';
require(['config/require'], function() { //eslint-disable-line
  define('boot', function(require) { //eslint-disable-line
    /*
     * The following are the scripts used by many other scripts. We load them
     * at once here. These should be move to the dependency of each panel in the
     * future.
     */
    require('utils');
    require('modules/settings');

    const SettingsService = require('modules/settings_service');

    function isInitialPanel(panel) {
      if (Settings.isTabletAndLandscape()) {
        return panel === Settings.initialPanelForTablet;
      }
      return panel === `#${window.LaunchContext.initialPanelId}`;
    }

    window.addEventListener(
      'panelready',
      function onPanelReady(e) {
        if (!isInitialPanel(e.detail.current)) {
          return;
        }

        window.removeEventListener('panelready', onPanelReady);

        // Activate the animation.
        document.body.dataset.ready = true;
      },
      false
    );

    /**
     * In two column layout, the root panel should not be deactivated. We pass
     * the id of the root panel to SettingsService so that it won't deactivate
     * the root panel when in two column.
     * XXX: Currently we don't separate the navigation logic of one column and
     *      two column layout, so that the root panel will not be deactivated
     *      in one column layout.
     */
    SettingsService.init({
      rootPanelId: 'root',
      context: window.LaunchContext
    });

    const options = {
      SettingsService,
      ScreenLayout
    };
    Settings.init(options);

    /*
     * Tell audio channel manager that we want to adjust the notification
     * channel if the user press the volumeup/volumedown buttons in Settings.
     */
    if (navigator.b2g.audioChannelManager) {
      navigator.b2g.audioChannelManager.volumeControlChannel = 'notification';
    }
  });

  require(['boot']); // eslint-disable-line
});
