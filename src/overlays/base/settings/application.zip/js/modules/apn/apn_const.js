/**
 * The apn constants
 */
'use strict';
define(function() { //eslint-disable-line
  const APN_TYPES = ['default', 'mms', 'supl', 'dun', 'ims'];

  const CP_APN_KEY = 'ril.data.cp.apns';
  const DEFAULT_APN_KEY = 'ril.data.default.apns';

  // Used for detecting if plmn or mvno match result has been changed.
  const CACHED_PLMN_MVNO_KEY = 'apn.cached.plmn_mvno';

  const APN_LIST_KEY = 'apn.list';
  const APN_SELECTIONS_KEY = 'apn.selections';
  const DEFAULT_APN_SETTINGS_KEY = 'ril.data.default.apnSettings';

  const MCC_SETTINGS_KEY = [
    'operatorvariant.mcc',
    'operatorvariant.mcc.sim1',
    'operatorvariant.mcc.sim2'
  ];
  const MNC_SETTINGS_KEY = [
    'operatorvariant.mnc',
    'operatorvariant.mnc.sim1',
    'operatorvariant.mnc.sim2'
  ];

  const MVNO_SETTINGS_KEY = [
    'operatorvariant.mvno',
    'operatorvariant.mvno.sim1',
    'operatorvariant.mvno.sim2'
  ];

  const EU_ROAMING_ENABLED_KEY = 'eu-roaming.enabled';
  const EU_ROAMING_FILE_PATH = '/resources/eu-roaming.json';

  const APN_PROPS = [
    'carrier',
    'apn',
    'user',
    'passwd',
    'httpproxyhost',
    'httpproxyport',
    'mmsc',
    'mmsproxy',
    'mmsport',
    'authtype',
    'types',
    'protocol',
    'roaming_protocol',

    /**
     * _id is an internal property for identifying apn items received via
     * client provisioning.
     */
    '_id'
  ];

  return {
    get APN_TYPES() {
      return APN_TYPES;
    },
    get CP_APN_KEY() {
      return CP_APN_KEY;
    },
    get DEFAULT_APN_KEY() {
      return DEFAULT_APN_KEY;
    },
    get CACHED_PLMN_MVNO_KEY() {
      return CACHED_PLMN_MVNO_KEY;
    },
    get MVNO_SETTINGS_KEY() {
      return MVNO_SETTINGS_KEY;
    },
    get APN_LIST_KEY() {
      return APN_LIST_KEY;
    },
    get APN_SELECTIONS_KEY() {
      return APN_SELECTIONS_KEY;
    },
    get DEFAULT_APN_SETTINGS_KEY() {
      return DEFAULT_APN_SETTINGS_KEY;
    },
    get MCC_SETTINGS_KEY() {
      return MCC_SETTINGS_KEY;
    },
    get MNC_SETTINGS_KEY() {
      return MNC_SETTINGS_KEY;
    },
    get EU_ROAMING_ENABLED_KEY() {
      return EU_ROAMING_ENABLED_KEY;
    },
    get EU_ROAMING_FILE_PATH() {
      return EU_ROAMING_FILE_PATH;
    },
    get APN_PROPS() {
      return APN_PROPS;
    }
  };
});
