/**
 * ApnItem is a wrapper of apn objects.
 *
 * @module modules/apn/apn_item
 */
'use strict';
define(function() { //eslint-disable-line
  const APN_CATEGORY = {
    PRESET: 'preset',
    CUSTOM: 'custom',
    EU: 'eu'
  };

  /**
   * @class ApnItem
   * @params {String} id
   * @params {String} category
   * @params {Object} apn
   * @returns {ApnItem}
   */
  function ApnItem(id, category, apn) {
    this.itemId = id;
    this.itemCategory = category;
    this.itemApn = apn;
  }

  ApnItem.prototype = {
    get id() {
      return this.itemId;
    },
    get category() {
      return this.itemCategory;
    },
    get apn() {
      return this.itemApn;
    }
  };

  const constructor = function constructor(id, category, apn) {
    return new ApnItem(id, category, apn);
  };
  constructor.APN_CATEGORY = APN_CATEGORY;

  return constructor;
});
