/* global ApnHelper */
/**
 * ApnSettingsManager provides functions for managing apn items. When an item
 * is selected to be used, ApnSettingsManager also helps convert the selection
 * to the real settings expected by the platform.
 * ApnSettingsManager does its task by coordinating the following objects:
 * - ApnList
 *     There is an ApnList object for each sim. ApnList stores ApnItem objects
 *     representing apns come from the apn.json database, client provisioning
 *     messages, and user's creation. Each ApnItem has an id assigned upon
 *     the creation. The id is used to recored users' apn selection.
 * - ApnSelections
 *     ApnSelections stores the id of the apn being used on each apn
 *     type.
 * - ApnSettings
 *     ApnSettings wraps the apn settings stored in the moz settings database
 *     and provides simple interface for manipulation.
 * Implementation details please refer to {@link ApnSettingsManager}.
 *
 * @module modules/apn/apn_settings_manager
 */
'use strict';
define(function(require) { //eslint-disable-line
  const AsyncStorage = require('modules/async_storage');
  const ApnConst = require('modules/apn/apn_const');
  const ApnUtils = require('modules/apn/apn_utils');
  const ApnItem = require('modules/apn/apn_item');
  const ApnSettings = require('modules/apn/apn_settings');
  const ApnList = require('modules/apn/apn_list');
  const ApnSelections = require('modules/apn/apn_selections');

  const { APN_TYPES } = ApnConst;
  const { APN_LIST_KEY } = ApnConst;
  const { CACHED_PLMN_MVNO_KEY } = ApnConst;
  const { DEFAULT_APN_SETTINGS_KEY } = ApnConst;
  const { CP_APN_KEY } = ApnConst;
  // Const { MVNO_SETTINGS_KEY } = ApnConst;

  const RESTORE_MODE = {
    ALL: 0,
    ONLY_APN_ITEMS: 1
  };

  /**
   * @class ApnSettingsManager
   * @requires module:modules/async_storage
   * @requires module:modules/apn/apn_const
   * @requires module:modules/apn/apn_utils
   * @requires module:modules/apn/apn_item
   * @requires module:modules/apn/apn_settings
   * @requires module:modules/apn/apn_list
   * @requires module:modules/apn/apn_selections
   * @returns {ApnSettingsManager}
   */
  function ApnSettingsManager() {
    this.apnLists = {};
    this.apnSelections = ApnSelections();
    this.apnSettings = ApnSettings();

    this.readyPromises = {};
    this.defaultApnSettingChanged = {};
    this.cpApnSettings = {};

    Object.defineProperty(this, 'RESTORE_MODE', {
      configurable: false,
      get() {
        return RESTORE_MODE;
      }
    });
  }

  ApnSettingsManager.prototype = {
    /**
     * Ensures the current apn items are up-to-date. When the current plmn
     * does not equal to the cached plmn, we should restore the apn items.
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @returns {Promise}
     */
    ready(serviceId) {
      if (!this.readyPromises[serviceId]) {
        const that = this;
        let plmn = {};
        // Register default apn changed observer
        that.addObservers(serviceId);
        // Get current plmn information
        return that.getPlmnAndMvnoInfo(serviceId).then(values => {
          plmn = values;
          that.readyPromises[serviceId] = AsyncStorage.getItem(
            CACHED_PLMN_MVNO_KEY
          ).then(cacheValues => {
            const cachePlmn = cacheValues && cacheValues[serviceId];
            if (
              plmn.length === 0 ||
              (cachePlmn &&
                plmn[0] === cachePlmn[0] &&
                plmn[1] === cachePlmn[1] &&
                JSON.stringify(plmn[2]) === JSON.stringify(cachePlmn[2]))
            ) {
              DebugHelper.debug(`simcard ${serviceId}not change`);
              return;
            }

            cacheValues = cacheValues || {};
            cacheValues[serviceId] = plmn;
            // Get the default preset apns by restoring.
            // eslint-disable-next-line
                  return Promise.all([
              /*
               * In this case we only restore apn items
               * but not apn settings.
               */
              that.restore(serviceId, RESTORE_MODE.ONLY_APN_ITEMS),
              AsyncStorage.setItem(CACHED_PLMN_MVNO_KEY, cacheValues)
            ]);
          });
        });
      }
      return this.readyPromises[serviceId];
    },

    /**
     * Register default APN changed observer
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     */
    addObservers(serviceId) {
      this.defaultApnSettingChanged[serviceId] = () => {
        this.readyPromises[serviceId] = null;
      };

      SettingsDBCache.observe(
        DEFAULT_APN_SETTINGS_KEY,
        '',
        this.defaultApnSettingChanged[serviceId],
        true
      );
      SettingsDBCache.observe(CP_APN_KEY, {}, cpApnJson => {
        if (cpApnJson && cpApnJson[serviceId]) {
          this.getPlmnAndMvnoInfo(serviceId).then(values => {
            const networkType =
              navigator.b2g.mobileConnections[serviceId].data.type;
            const [mcc, mnc] = values;
            const apnList = this.apnList(serviceId);
            this.cpApnSettings = ApnHelper.getCompatible(
              cpApnJson[serviceId],
              mcc,
              mnc,
              networkType
            );
            const cpApns = ApnUtils.separateApnsByType(this.cpApnSettings);
            if (cpApns.length) {
              this.ready(serviceId)
                .then(() => this.apnList(serviceId).items())
                .then(apnItems => {
                  cpApns.forEach(apn => {
                    const matchedApnItem = apnItems.find(
                      apnItem => apnItem.apn.itemId === apn.itemId
                    );
                    if (matchedApnItem) {
                      // Update exist apn by cp apn
                      apnList.updateByWap(apn.itemId, apn);
                    } else {
                      apn.deletedCpApn = false;
                      apnList.add(apn, ApnItem.APN_CATEGORY.PRESET);
                    }
                  });
                });
            }
          });
        }
      });
    },

    /**
     * Get current mcc/mnc information
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @returns {Promise Array}
     */
    getPlmnAndMvnoInfo(serviceId) {
      return Promise.all([
        ApnUtils.getOperatorCode(serviceId, 'mcc'),
        ApnUtils.getOperatorCode(serviceId, 'mnc'),
        ApnUtils.getOperatorCode(serviceId, 'mvno')
      ]).then(values => values || {});
    },

    /**
     * Returns the id of the first preset apn item.
     *
     * @param {Number} serviceId
     * @param {String} apnType
     * @returns {Promise String}
     */
    deriveActiveApnIdFromItems(serviceId, apnType) {
      return this.apnItems(serviceId, apnType).then(apnItems => {
        const filterapnItems = apnItems.filter(
          apnItem => apnItem.apn.deletedCpApn !== true
        );
        if (filterapnItems.length) {
          return filterapnItems.sort(ApnUtils.sortByCategory)[0].id;
        }
        return null;
      });
    },

    /**
     * Returns the id of the apn item that matches the current apn setting of
     * the specified apn type.
     *
     * @param {Number} serviceId
     * @param {String} apnType
     * @returns {Promise String}
     */
    deriveActiveApnIdFromSettings(serviceId, apnType) {
      return Promise.all([
        this.apnItems(serviceId, apnType),
        this.apnSettings.get(serviceId, apnType)
      ]).then(results => {
        const [apnItems, apnInUse] = results;
        const cpApns = ApnUtils.separateApnsByType(this.cpApnSettings);
        const apnList = this.apnList(serviceId);
        let updateApnItem = null;

        // ApnInUse is the apn that RIL is currently using.
        if (apnInUse) {
          const existApnItem = apnItems.find(
            apnItem => apnItem.apn.itemId === apnInUse.itemId
          );

          const matchedApnItem = apnItems.find(apnItem =>
            ApnUtils.isMatchedApn(apnItem.apn, apnInUse)
          );

          if (cpApns.length) {
            updateApnItem = cpApns.find(
              apnItem => apnItem.itemId === apnInUse.itemId
            );
          }

          if (updateApnItem) {
            /*
             * Check if current using apn is in cp apn list and current apn
             * list:
             * 1. in both lists, and no need to update
             * 2. in both lists, but need to update by cp apn
             * 3. in cp apn list but not in current apn list, need to add
             */
            if (matchedApnItem) {
              return matchedApnItem.id;
            } else if (existApnItem) {
              return apnList.updateByWap(apnInUse.itemId, apnInUse);
            }
            apnInUse.deletedCpApn = false;
            return apnList.add(apnInUse, ApnItem.APN_CATEGORY.PRESET);
          } else if (matchedApnItem) {
            return matchedApnItem.id;
          } else if (apnItems.length > 0) {
            /*
             * Current using apn is not in current apn list,
             * Suppose it is CUSTOM apn and obsere whether cause issue.
             */
            const category = ApnItem.APN_CATEGORY.CUSTOM;
            return this.addApn(serviceId, apnInUse, category);
          }
          return null;
        }
        return null;
      });
    },

    /**
     * Return the apn type an apn that is actively being used for.
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} apnId
     *                 id of the apn being checked.
     * @returns {Promise String}
     */
    getApnAppliedType(serviceId, apnId) {
      return this.apnSelections
        .get(serviceId)
        .then(apnSelection =>
          APN_TYPES.find(apnType => apnSelection[apnType] === apnId)
        );
    },

    /**
     * Store the current apn selection to apn settings to the settings database.
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} apnType
     */
    storeApnSettingByType(serviceId, apnType) {
      return this.apnSelections
        .get(serviceId) // eslint-disable-next-line
        .then(apnSelection => {
          const apnList = this.apnList(serviceId);
          const apnId = apnSelection[apnType];
          if (apnId) {
            // Get the apn item of apnType.
            return apnList.item(apnId);
          }
        })
        .then(apnItem => {
          if (apnItem) {
            return this.apnSettings.update(serviceId, apnType, apnItem.apn);
          }
          return this.apnSettings.update(serviceId, apnType, null);
        });
    },

    /**
     * Get the apn item list of a sim slot.
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @returns {ApnList} The apn item list.
     */
    apnList(serviceId) {
      let apnList = this.apnLists[serviceId];
      if (!apnList) {
        apnList = ApnList(APN_LIST_KEY + serviceId);
        this.apnLists[serviceId] = apnList;
      }
      return apnList;
    },

    /**
     * Get the apn items of an apn type for a sim slot.
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} apnType
     * @returns {Promise Array<ApnItem>} The apn items.
     */
    apnItems(serviceId, apnType) {
      return this.ready(serviceId)
        .then(() => this.apnList(serviceId).items())
        .then(
          apnItems =>
            (apnItems &&
              apnItems.filter(ApnUtils.apnTypeFilter.bind(null, apnType))) ||
            []
        );
    },

    /**
     * Restore the apn items of a category.
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {ApnList} apnList
     * @param {Array<Object>} apnsForRestoring
     *                        The function use this to restore the apn items.
     * @param {ApnItem.APN_CATEGORY} category
     *                               The category of the items to be resotred.
     * @returns {Promise Array<String>} The id of the restored apn items.
     */
    restoreApnItemsOfCategory(apnList, apnsForRestoring, category) {
      return apnList
        .items()
        .then(apnItems => {
          // Remove all existing preset apns.
          apnItems = apnItems || [];
          const promises = [];
          apnItems // eslint-disable-next-line
            .filter(apnItem => {
              if (apnItem.category === category) {
                return true;
              }
            })
            .forEach(apnItem => {
              promises.push(apnList.remove(apnItem.id));
            });

          return Promise.all(promises);
        })
        .then(() => {
          // Add default preset apns.
          const promises = [];
          if (apnsForRestoring) {
            apnsForRestoring = apnsForRestoring.filter(
              apnItem => apnItem.user_visible !== 'false'
            );
            apnsForRestoring.forEach(apns => {
              promises.push(apnList.add(apns, category));
            });
          }
          return Promise.all(promises);
        });
    },

    /**
     * Get current carrier mcc code by service Id
     */
    getServiceIdMcc(serviceId) {
      return ApnUtils.getOperatorCode(serviceId, 'mcc');
    },

    /**
     * Restore the apn items and apn settings to the default. Apn items of
     * the category ApnItem.APN_CATEGORY.PRESET and ApnItem.APN_CATEGORY.EU are
     * restored. User created apn items (custom apns) will be delete. The
     * preset apn items are from the apn.json database and client provisioning
     * messages.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {String} serviceId
     * @param {Number} mode
     *                 The possible values are defined in RESTORE_MODE. We
     *                 restore both apn items and apn settings by default. Only
     *                 apn items are restored when mode is
     *                 RESTORE_MODE.ONLY_APN_ITEMS.
     * @returns {Promise}
     */
    restore(serviceId, mode) {
      const mobileConnection = navigator.b2g.mobileConnections[serviceId];
      const networkType = mobileConnection.data.type;
      const apnList = this.apnList(serviceId);
      const that = this;
      let presetApns = null;

      return (
        that
          .getPlmnAndMvnoInfo(serviceId)
          .then(values => {
            /*
             * Get default apns and client provisioning apns matching the mcc/mnc
             * codes.
             */
            const [mcc, mnc] = values;

            return Promise.all([
              ApnUtils.getEuApns(),
              ApnUtils.getDefaultApns({ mcc, mnc, networkType }, serviceId),
              ApnUtils.getCpApns({ mcc, mnc, networkType }, serviceId)
            ]);
          })
          .then(results => {
            // Restore preset and eu apns.
            const euApns = ApnUtils.separateApnsByType(results[0]);
            const defaultApns = results[1] || [];
          const cpApns = results[2]; // eslint-disable-line

            if (cpApns && cpApns.length) {
              cpApns.forEach(cpApn => {
                cpApn.deletedCpApn = false;
              });
            }
            presetApns = ApnUtils.separateApnsByType(
              Array.prototype.concat.apply([], defaultApns.concat(cpApns))
            );

            return that
              .restoreApnItemsOfCategory(
                apnList,
                euApns,
                ApnItem.APN_CATEGORY.EU
              )
              .then(() =>
                that.restoreApnItemsOfCategory(
                  apnList,
                  null,
                  ApnItem.APN_CATEGORY.CUSTOM
                )
              )
              .then(() =>
                that.restoreApnItemsOfCategory(
                  apnList,
                  presetApns,
                  ApnItem.APN_CATEGORY.PRESET
                )
              );
          })
          .then(
            () => that.apnSelections.clear(serviceId)

            /*
             * We simply clear the apn selections. The selections will be restored
             * based on the current apn settings when it is being queried.
             */
          )
          // eslint-disable-next-line
        .then(() => {
            if (mode !== RESTORE_MODE.ONLY_APN_ITEMS) {
              return that.apnSettings.restore(serviceId, presetApns);
            }
          })
      );
    },

    /**
     * Query apn items matching the mcc/mnc codes in the apn.json
     * database and the one received through client provisioning messages.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} apnType
     * @returns {Promise Array<ApnItem>} The apn items
     */
    queryApns(serviceId, apnType) {
      return this.getActiveApnId(serviceId, apnType).then(activeApnId =>
        this.apnItems(serviceId, apnType).then(items => {
          items.forEach(apnItem => {
            apnItem.active = apnItem.id === activeApnId;
            if (apnItem.active && apnItem.apn.deletedCpApn) {
              apnItem.apn.deletedCpApn = false;
              this.apnSettings.update(serviceId, apnType, apnItem.apn);
            }
          });
          return items;
        })
      );
    },

    /**
     * Add an apn to a sim slot.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {Object} apn
     * @param {ApnItem.APN_CATEGORY} category
     * @returns {Promise}
     */
    addApn(serviceId, apn, category) {
      return this.ready(serviceId).then(() =>
        this.apnList(serviceId).add(
          apn,
          category || ApnItem.APN_CATEGORY.CUSTOM
        )
      );
    },

    /**
     * Remove an apn from a sim slot.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} id
     *                 id of the apn item to be added.
     * @returns {Promise}
     */
    removeApn(serviceId, id) {
      return (
        this.ready(serviceId)
          .then(() => this.apnList(serviceId).remove(id))
          .then(
            () => this.getApnAppliedType(serviceId, id)
            // Check if the removed apn is actively being used.
          )
          // eslint-disable-next-line
        .then((matchedApnType) => {
            if (matchedApnType) {
              return this.deriveActiveApnIdFromItems(
                serviceId,
                matchedApnType
              ).then(activeApnId =>
                this.setActiveApnId(serviceId, matchedApnType, activeApnId)
              );
            }
          })
      );
    },

    /**
     * Update an apn item.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} id
     *                 id of the apn item to be updated.
     * @param {Object} apn
     * @returns {Promise}
     */
    updateApn(serviceId, id, apn) {
      return (
        this.ready(serviceId)
          .then(() => this.apnList(serviceId).update(id, apn))
          .then(
            () => this.getApnAppliedType(serviceId, id)
            // Check if the updated apn is actively being used.
          )
          // eslint-disable-next-line
        .then((matchedApnType) => {
            if (matchedApnType) {
              if (apn.deletedCpApn) {
                return this.deriveActiveApnIdFromItems(
                  serviceId,
                  matchedApnType
                ).then(activeApnId =>
                  this.setActiveApnId(serviceId, matchedApnType, activeApnId)
                );
              }
              return this.storeApnSettingByType(serviceId, matchedApnType);
            }
          })
      );
    },

    /**
     * Get the id of the apn that is actively being used for an apn type.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} apnType
     * @returns {Promise String}
     */
    getActiveApnId(serviceId, apnType) {
      const that = this;
      return this.ready(serviceId)
        .then(() => that.apnSelections.get(serviceId))
        .then(apnSelection => apnSelection && apnSelection[apnType])
        .then(activeApnId => {
          if (activeApnId) {
            return activeApnId;
          }

          /*
           * If there is no existing active apn id, try to derive the id from
           * the current apn settings.
           */
          return that
            .deriveActiveApnIdFromSettings(serviceId, apnType)
            .then(apnId => {
              // Set the id as the active apn id.
              that.setActiveApnId(serviceId, apnType, apnId);
              return apnId;
            });
        })
        .then(activeApnId => {
          /*
           * If there is still no active apn id, means that the apn settings
           * have not been set and we need to derive a default id from the
           * current apn items (stored in the apn list).
           */
          if (activeApnId) {
            return activeApnId;
          }
          return '';
        });
    },

    /**
     * Set the id of an apn that is to be used for an apn type.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} apnType
     * @param {String} id
     * @returns {Promise}
     */
    setActiveApnId(serviceId, apnType, id) {
      return (
        this.ready(serviceId)
          .then(() => this.apnSelections.get(serviceId))
          // eslint-disable-next-line
        .then((apnSelection) => {
            if (apnSelection[apnType] !== id) {
              apnSelection[apnType] = id;
              return this.storeApnSettingByType(serviceId, apnType);
            }
          })
      );
    }
  };

  return new ApnSettingsManager();
});
