/* global ApnHelper */
/**
 * ApnSettingsManager provides functions for managing apn items. When an item
 * is selected to be used, ApnSettingsManager also helps convert the selection
 * to the real settings expected by the platform.
 * ApnSettingsManager does its task by coordinating the following objects:
 * - ApnList
 *     There is an ApnList object for each sim. ApnList stores ApnItem objects
 *     representing apns come from the apn.json database, client provisioning
 *     messages, and user's creation. Each ApnItem has an id assigned upon
 *     the creation. The id is used to recored users' apn selection.
 * - ApnSelections
 *     ApnSelections stores the id of the apn being used on each apn
 *     type.
 * - ApnSettings
 *     ApnSettings wraps the apn settings stored in the moz settings database
 *     and provides simple interface for manipulation.
 * Implementation details please refer to {@link ApnSettingsManager}.
 *
 * @module modules/apn/apn_settings_manager
 */
'use strict';
define(function(require) { //eslint-disable-line
  const AsyncStorage = require('modules/async_storage');
  const ApnConst = require('modules/apn_tct/apn_const');
  const ApnUtils = require('modules/apn_tct/apn_utils');
  const ApnItem = require('modules/apn_tct/apn_item');
  const ApnSettings = require('modules/apn_tct/apn_settings');
  const ApnList = require('modules/apn_tct/apn_list');
  const ApnSelections = require('modules/apn_tct/apn_selections');
  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4307,
  //Restructure omacp code and optimize feature
  const OmaHelper = require('modules/apn_tct/oma_helper');
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4307,

  const { APN_TYPES } = ApnConst;
  const { APN_LIST_KEY } = ApnConst;
  const { CACHED_PLMN_MVNO_KEY } = ApnConst;
  const { DEFAULT_APN_SETTINGS_KEY } = ApnConst;
  const { CP_APN_KEY } = ApnConst;
  // Const { MVNO_SETTINGS_KEY } = ApnConst;

  const RESTORE_MODE = {
    ALL: 0,
    ONLY_APN_ITEMS: 1,
    ONLY_FOR_OMACP_UPDATE: 2 //[BUGFIX]-Add by GCCSZ.kaiyun.yan,12/15/2023,GF7TF-4405,
  };

  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3524,
  //Development apn settings feature
  function log(msg) {
      dump('TctApn: apn_settings_manager: ' + msg);
  }
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3524,

  /**
   * @class ApnSettingsManager
   * @requires module:modules/async_storage
   * @requires module:modules/apn/apn_const
   * @requires module:modules/apn/apn_utils
   * @requires module:modules/apn/apn_item
   * @requires module:modules/apn/apn_settings
   * @requires module:modules/apn/apn_list
   * @requires module:modules/apn/apn_selections
   * @returns {ApnSettingsManager}
   */
  function ApnSettingsManager() {
    this.apnLists = {};
    this.apnSelections = ApnSelections();
    this.apnSettings = ApnSettings();

    this.readyPromises = {};
    this.defaultApnSettingChanged = {};
    this.cpApnSettings = {};

    //[BUGFIX]-Add-BEGIN by GCCSZ.kaiyun.yan,11/24/2024,GF5GTMO-5459
    //Optimize apn restore feature
    this.deriveActive = false;
    //[BUGFIX]-Add-END by GCCSZ.kaiyun.yan,GF5GTMO-5459

    Object.defineProperty(this, 'RESTORE_MODE', {
      configurable: false,
      get() {
        return RESTORE_MODE;
      }
    });
  }

  ApnSettingsManager.prototype = {
    /**
     * Ensures the current apn items are up-to-date. When the current plmn
     * does not equal to the cached plmn, we should restore the apn items.
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @returns {Promise}
     */
    ready(serviceId) {
      //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,11/18/2024,GF5GTMO-5352,
      //The APN added by the secret code page cannot be displayed on normal page
      let readyPromise = this.readyPromises[serviceId];
      let go = (!readyPromise);
      log('ready:: serviceId=' + serviceId + ' go=' + go + ' readyPromise=' + readyPromise);

      if (go) {
      //if (!this.readyPromises[serviceId]) {
      //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-5352,
        const that = this;
        let plmn = {};
        // Register default apn changed observer
        that.addObservers(serviceId);
        // Get current plmn information
        return that.getPlmnAndMvnoInfo(serviceId).then(values => {
          plmn = values;

          //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4307,
          //Restructure omacp code and optimize feature
          log('ready: serviceId=' + serviceId + ' plmn=' + plmn
              + ' RIL_DATA_OMA_APNUPDATED=' + OmaHelper.RIL_DATA_OMA_APNUPDATED
              + ' RIL_CP_APN_UPDATED=' + OmaHelper.RIL_CP_APN_UPDATED);
          let promises = [];
          promises.push(AsyncStorage.getItem(CACHED_PLMN_MVNO_KEY));
          if (typeof OmaHelper != undefined) {
            promises.push(OmaHelper.getSetting(OmaHelper.RIL_DATA_OMA_APNUPDATED));
            promises.push(OmaHelper.getSetting(OmaHelper.RIL_CP_APN_UPDATED));
          }
          /**
          that.readyPromises[serviceId] = AsyncStorage.getItem(
            CACHED_PLMN_MVNO_KEY
          ).then(cacheValues => {
          **/
          that.readyPromises[serviceId] = Promise.all(promises).then(result => {
            let cacheValues = result[0];
            log('ready: serviceId=' + serviceId + ' result=' + JSON.stringify(result));
          //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4307,

            const cachePlmn = cacheValues && cacheValues[serviceId];

            //[BUGFIX]-Mod-BEGIN by GCCSZ.kaiyun.yan,12/29/2023,GF7TF-4405,
            const dmApnUpdated = result[1] === undefined ? false : (result[1] != null);
            const cpApnUpdated = result[2] === undefined ? false : (result[2] != null);
            let restoreMode = RESTORE_MODE.ONLY_APN_ITEMS;
            log('ready: dmApnUpdated=' + dmApnUpdated + ' cpApnUpdated=' + cpApnUpdated
                + ' result=' + JSON.stringify(result) + ' restoreMode=' + restoreMode);
            /**
            if (
              plmn.length === 0 ||
              (cachePlmn &&
                plmn[0] === cachePlmn[0] &&
                plmn[1] === cachePlmn[1] &&
                JSON.stringify(plmn[2]) === JSON.stringify(cachePlmn[2]))
            ) {
              DebugHelper.debug(`simcard ${serviceId}not change`);
              return;
            }
            **/

            if (
              plmn.length === 0 ||
              (cachePlmn &&
              plmn[0] === cachePlmn[0] &&
              plmn[1] === cachePlmn[1] &&
              JSON.stringify(plmn[2]) === JSON.stringify(cachePlmn[2]))
            ) {
              log(`simcard ${serviceId}not change`);
              if (dmApnUpdated) {
                  //Do nothing
              } else if (cpApnUpdated) {
                  restoreMode = RESTORE_MODE.ONLY_FOR_OMACP_UPDATE;
              } else {
                  return;
              }
            }
            //[BUGFIX]-Mod-END by GCCSZ.kaiyun.yan,GF7TF-4405,

            cacheValues = cacheValues || {};
            cacheValues[serviceId] = plmn;

            // Get the default preset apns by restoring.
            // eslint-disable-next-line

            //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4307,
            //Restructure omacp code and optimize feature
            //      return Promise.all([
              /*
               * In this case we only restore apn items
               * but not apn settings.
               */
            //  that.restore(serviceId, RESTORE_MODE.ONLY_APN_ITEMS),
            //  AsyncStorage.setItem(CACHED_PLMN_MVNO_KEY, cacheValues)
            //]);

            promises = [];
            promises.push(that.restore(serviceId, restoreMode));
            promises.push(AsyncStorage.setItem(CACHED_PLMN_MVNO_KEY, cacheValues));
            if (typeof OmaHelper != undefined) {
              promises.push(OmaHelper.setSetting(OmaHelper.RIL_DATA_OMA_APNUPDATED, null));
              promises.push(OmaHelper.setSetting(OmaHelper.RIL_CP_APN_UPDATED, null));
            }
            return Promise.all(promises);
            //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-4307,
          });
        });
      }
      return this.readyPromises[serviceId];
    },

    /**
     * Register default APN changed observer
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     */
    addObservers(serviceId) {
      this.defaultApnSettingChanged[serviceId] = () => {
        //[BUGFIX]-Add-BEGIN by GCCSZ.kaiyun.yan,11/24/2024,GF5GTMO-5459
        //Optimize apn restore feature
        log('defaultApnSettingChanged: reset readyPromises' + serviceId);
        //[BUGFIX]-Add-END by GCCSZ.kaiyun.yan,GF5GTMO-5459
        this.readyPromises[serviceId] = null;
      };

      SettingsDBCache.observe(
        DEFAULT_APN_SETTINGS_KEY,
        '',
        this.defaultApnSettingChanged[serviceId],
        true
      );
      SettingsDBCache.observe(CP_APN_KEY, {}, cpApnJson => {
        //[BUGFIX]-Add-BEGIN by GCCSZ.kaiyun.yan,11/24/2024,GF7TF-4405,GF5GTMO-5459
        //Optimize apn restore feature
        if (OmaHelper) {
          let changed = this.defaultApnSettingChanged[serviceId];
          if (changed) {
            changed();
          }
          this.deriveActive = true;
          log('observeCpApn: use TCT OMACP, call defaultApnSettingChanged and return, deriveActive=' + this.deriveActive);
          return;
        }
        //[BUGFIX]-Add-END by GCCSZ.kaiyun.yan,GF7TF-4405,GF5GTMO-5459
        if (cpApnJson && cpApnJson[serviceId]) {
          this.getPlmnAndMvnoInfo(serviceId).then(values => {
            const networkType =
              navigator.b2g.mobileConnections[serviceId].data.type;
            const [mcc, mnc] = values;
            const apnList = this.apnList(serviceId);
            this.cpApnSettings = ApnHelper.getCompatible(
              cpApnJson[serviceId],
              mcc,
              mnc,
              networkType
            );
            const cpApns = ApnUtils.separateApnsByType(this.cpApnSettings);
            if (cpApns.length) {
              this.ready(serviceId)
                .then(() => this.apnList(serviceId).items())
                .then(apnItems => {
                  cpApns.forEach(apn => {
                    const matchedApnItem = apnItems.find(
                      apnItem => apnItem.apn.itemId === apn.itemId
                    );
                    if (matchedApnItem) {
                      // Update exist apn by cp apn
                      apnList.updateByWap(apn.itemId, apn);
                    } else {
                      apn.deletedCpApn = false;
                      apnList.add(apn, ApnItem.APN_CATEGORY.PRESET);
                    }
                  });
                });
            }
          });
        }
      });
    },

    /**
     * Get current mcc/mnc information
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @returns {Promise Array}
     */
    getPlmnAndMvnoInfo(serviceId) {
      return Promise.all([
        ApnUtils.getOperatorCode(serviceId, 'mcc'),
        ApnUtils.getOperatorCode(serviceId, 'mnc'),
        ApnUtils.getOperatorCode(serviceId, 'mvno')
      ]).then(values => values || {});
    },

    /**
     * Returns the id of the first preset apn item.
     *
     * @param {Number} serviceId
     * @param {String} apnType
     * @returns {Promise String}
     */
    deriveActiveApnIdFromItems(serviceId, apnType) {
      return this.apnItems(serviceId, apnType).then(apnItems => {
        const filterapnItems = apnItems.filter(
          apnItem => apnItem.apn.deletedCpApn !== true
        );
        if (filterapnItems.length) {
          return filterapnItems.sort(ApnUtils.sortByCategory)[0].id;
        }
        return null;
      });
    },

    //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4308,
    //Restructure apn settings manager code
    deriveActiveApnIdFromSettingsTct(serviceId, apnType) {
      let that = this;//[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,11/06/2023,GF7TF-3769,
      return Promise.all([
        this.apnItems(serviceId, apnType),
        this.apnSettings.get(serviceId, apnType)
      ]).then(results => {
        const [apnItems, apnInUse] = results;

        //[BUGFIX]-Add-BEGIN by GCCSZ.kaiyun.yan,12/15/2023,GF7TF-4405,
        let apnItemsCount = (apnItems === undefined || !Array.isArray(apnItems)) ? -1 : apnItems.length;
        log('deriveActiveApnIdFromSettingsTct: serviceId=' + serviceId + ' apnType=' + apnType
                + ' apnItemsCount=' + apnItemsCount + ' apnItems=' + JSON.stringify(apnItems));
        //[BUGFIX]-Add-END by GCCSZ.kaiyun.yan,GF7TF-4405,

        log('deriveActiveApnIdFromSettingsTct: apnInUse= '+JSON.stringify(apnInUse));

        var filterPreset = function(item) {
            log('deriveActiveApnIdFromSettingsTct: item._category is ' + item._category);
            return item._category == "custom";
        }
        // apnInUse is the apn that RIL is currently using.
        var custApnItems = apnItems;

        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,11/06/2023,GF7TF-4405,GF7TF-3769,
        let apnInUseDefault;
        if (apnType == 'default') {
          //[BUGFIX]-Mod-BEGIN by GCCSZ.kaiyun.yan,12/15/2023,GF7TF-4405,
          apnInUseDefault = ApnUtils.findActiveApn(serviceId, apnType, apnInUse, apnItems);
          //[BUGFIX]-Mod-END by GCCSZ.kaiyun.yan,GF7TF-4405,
        } else {
          apnInUseDefault = apnInUse;
        }

        log('deriveActiveApnIdFromSettingsTct: custApnItems is ' + JSON.stringify(custApnItems));
        log('deriveActiveApnIdFromSettingsTct: apnInUseDefault is ' + JSON.stringify(apnInUseDefault));

         //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,11/06/2023,GF7TF-3769,
         while(Array.isArray(apnInUseDefault)) {
             apnInUseDefault = apnInUseDefault[0];
             log('deriveActiveApnIdFromSettingsTct: apnInUseDefault=' + JSON.stringify(apnInUseDefault));
         }
         //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-3769,

         if (apnInUseDefault && custApnItems) {
             var matchedApnItem = custApnItems.find(function (apnItem) {
                 return ApnUtils.isMatchedApn_ex(apnItem.itemApn, apnInUseDefault);
             });

             log('deriveActiveApnIdFromSettingsTct: matchedApnItem=' + JSON.stringify(matchedApnItem));//[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,11/06/2023,GF7TF-3769,

             if (matchedApnItem) {
                 // Has matched apn in the existing apns.
                 return matchedApnItem.itemId;
             } else {
                 var category = (apnInUse.carrier === '_custom_') ?
                     ApnItem.APN_CATEGORY.CUSTOM : ApnItem.APN_CATEGORY.PRESET;
                 return null;
                 //return this.addApn(serviceId, apnInUse, category);
             }
         } else {
             return null;
         }
      });
    },
    //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4308,

    /**
     * Returns the id of the apn item that matches the current apn setting of
     * the specified apn type.
     *
     * @param {Number} serviceId
     * @param {String} apnType
     * @returns {Promise String}
     */
    deriveActiveApnIdFromSettings(serviceId, apnType) {

      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4308,
      //Restructure apn settings manager code
      log('deriveActiveApnIdFromSettings: serviceId=' + serviceId + ' apnType=' + apnType + ' OmaHelper=' + OmaHelper);
      if (!apnType || apnType == '*') {
        log('deriveActiveApnIdFromSettings: change apnType from ' + apnType + ' to default');
        apnType = 'default';
      }
      if (OmaHelper) {
         return this.deriveActiveApnIdFromSettingsTct(serviceId, apnType);
      }
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4308,

      return Promise.all([
        this.apnItems(serviceId, apnType),
        this.apnSettings.get(serviceId, apnType)
      ]).then(results => {
        const [apnItems, apnInUse] = results;
        const cpApns = ApnUtils.separateApnsByType(this.cpApnSettings);
        const apnList = this.apnList(serviceId);
        let updateApnItem = null;

        // ApnInUse is the apn that RIL is currently using.
        if (apnInUse) {
          const existApnItem = apnItems.find(
            apnItem => apnItem.apn.itemId === apnInUse.itemId
          );

          const matchedApnItem = apnItems.find(apnItem =>
            ApnUtils.isMatchedApn(apnItem.apn, apnInUse)
          );

          if (cpApns.length) {
            updateApnItem = cpApns.find(
              apnItem => apnItem.itemId === apnInUse.itemId
            );
          }

          if (updateApnItem) {
            /*
             * Check if current using apn is in cp apn list and current apn
             * list:
             * 1. in both lists, and no need to update
             * 2. in both lists, but need to update by cp apn
             * 3. in cp apn list but not in current apn list, need to add
             */
            if (matchedApnItem) {
              return matchedApnItem.id;
            } else if (existApnItem) {
              return apnList.updateByWap(apnInUse.itemId, apnInUse);
            }
            apnInUse.deletedCpApn = false;
            return apnList.add(apnInUse, ApnItem.APN_CATEGORY.PRESET);
          } else if (matchedApnItem) {
            return matchedApnItem.id;
          } else if (apnItems.length > 0) {
            /*
             * Current using apn is not in current apn list,
             * Suppose it is CUSTOM apn and obsere whether cause issue.
             */
            const category = ApnItem.APN_CATEGORY.CUSTOM;
            return this.addApn(serviceId, apnInUse, category);
          }
          return null;
        }
        return null;
      });
    },

    /**
     * Return the apn type an apn that is actively being used for.
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} apnId
     *                 id of the apn being checked.
     * @returns {Promise String}
     */
    getApnAppliedType(serviceId, apnId) {
      return this.apnSelections
        .get(serviceId)
        .then(apnSelection =>
          APN_TYPES.find(apnType => apnSelection[apnType] === apnId)
        );
    },

    /**
     * Store the current apn selection to apn settings to the settings database.
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} apnType
     */
    storeApnSettingByType(serviceId, apnType) {
      return this.apnSelections
        .get(serviceId) // eslint-disable-next-line
        .then(apnSelection => {
          const apnList = this.apnList(serviceId);
          const apnId = apnSelection[apnType];
          if (apnId) {
            // Get the apn item of apnType.
            return apnList.item(apnId);
          }
        })
        .then(apnItem => {
          if (apnItem) {
            return this.apnSettings.update(serviceId, apnType, apnItem.apn);
          }
          return this.apnSettings.update(serviceId, apnType, null);
        });
    },

    //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-3715,
    //apn selection feature development
    storeApnSettings(serviceId, newApns) {
      this.apnSettings.updateApns(serviceId, newApns);
    },
    //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3715,

    /**
     * Get the apn item list of a sim slot.
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @returns {ApnList} The apn item list.
     */
    apnList(serviceId) {
      let apnList = this.apnLists[serviceId];
      if (!apnList) {
        apnList = ApnList(APN_LIST_KEY + serviceId);
        this.apnLists[serviceId] = apnList;
      }
      return apnList;
    },

    /**
     * Get the apn items of an apn type for a sim slot.
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} apnType
     * @returns {Promise Array<ApnItem>} The apn items.
     */
    // Task10427965-lijuan.li@tcl.com-START
    //apnItems(serviceId, apnType) {
    apnItems(serviceId, apnType, options) {
      log('apnItems: serviceId=' + serviceId + ' apnType=' + apnType
          + ' options=' + JSON.stringify(options));
      return this.ready(serviceId)
        // Task10427965-lijuan.li@tcl.com-START
        //.then(() => this.apnList(serviceId).items())
        .then(() => this.apnList(serviceId).items(options))
        .then(
          apnItems =>
            (apnItems &&
              apnItems.filter(ApnUtils.apnTypeFilter.bind(null, apnType))) ||
            []
        );
    },

    /**
     * Restore the apn items of a category.
     *
     * @access private
     * @memberOf ApnSettingsManager.prototype
     * @param {ApnList} apnList
     * @param {Array<Object>} apnsForRestoring
     *                        The function use this to restore the apn items.
     * @param {ApnItem.APN_CATEGORY} category
     *                               The category of the items to be resotred.
     * @returns {Promise Array<String>} The id of the restored apn items.
     */
    restoreApnItemsOfCategory(apnList, apnsForRestoring, category) {
      return apnList
        .items()
        .then(apnItems => {
          // Remove all existing preset apns.
          apnItems = apnItems || [];
          const promises = [];
          apnItems // eslint-disable-next-line
            .filter(apnItem => {
              if (apnItem.category === category) {
                return true;
              }
            })
            .forEach(apnItem => {
              promises.push(apnList.remove(apnItem.id));
            });

          return Promise.all(promises);
        })
        .then(() => {
          // Add default preset apns.
          const promises = [];
          if (apnsForRestoring) {
            apnsForRestoring = apnsForRestoring.filter(
              //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,11/06/2023,GF7TF-4103,
              //apnItem => apnItem.user_visible !== 'false'
              apnItem => true
              //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF7TF-4103,
            );
            apnsForRestoring.forEach(apns => {
              promises.push(apnList.add(apns, category));
            });
          }
          return Promise.all(promises);
        });
    },

    /**
     * Get current carrier mcc code by service Id
     */
    getServiceIdMcc(serviceId) {
      return ApnUtils.getOperatorCode(serviceId, 'mcc');
    },

    /**
     * Restore the apn items and apn settings to the default. Apn items of
     * the category ApnItem.APN_CATEGORY.PRESET and ApnItem.APN_CATEGORY.EU are
     * restored. User created apn items (custom apns) will be delete. The
     * preset apn items are from the apn.json database and client provisioning
     * messages.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {String} serviceId
     * @param {Number} mode
     *                 The possible values are defined in RESTORE_MODE. We
     *                 restore both apn items and apn settings by default. Only
     *                 apn items are restored when mode is
     *                 RESTORE_MODE.ONLY_APN_ITEMS.
     * @returns {Promise}
     */
    restore(serviceId, mode) {
      const mobileConnection = navigator.b2g.mobileConnections[serviceId];
      const networkType = mobileConnection.data.type;
      const apnList = this.apnList(serviceId);
      const that = this;
      let presetApns = null;

      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,11/24/2024,GF5GTMO-3722,GF5GTMO-5459
      let apns = {presetApns:[], cpApns:[], customApns:[]};
      let sim = {mcc: '', mnc: '', mvno: ''};
      log('restore: serviceId=' + serviceId + ' mode=' + mode + ' networkType=' + networkType);
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3722,GF5GTMO-5459

      return (
        that
          .getPlmnAndMvnoInfo(serviceId)
          .then(values => {
            /*
             * Get default apns and client provisioning apns matching the mcc/mnc
             * codes.
             */
            //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4308,
            //Restructure apn settings manager code
            //const [mcc, mnc] = values;
            const [mcc, mnc, mvno] = values;
            sim.mcc = mcc;
            sim.mnc = mnc;
            sim.mccmnc = mcc + '' + mnc;
            sim.mvno = mvno;
            log('restore: serviceId=' + serviceId + ' sim=' + JSON.stringify(sim));
            let promises = [];
            promises.push(ApnUtils.getEuApns());
            promises.push(ApnUtils.getDefaultApns({ mcc, mnc, networkType }, serviceId));
            log('restore: OmaHelper=' + OmaHelper);
            if (OmaHelper) {
              log('restore: OmaHelper.getCpApns');
              promises.push(OmaHelper.getCpApns(mcc, mnc, mvno));
            } else {
              log('restore: ApnUtils.getCpApns');
              promises.push(ApnUtils.getCpApns({ mcc, mnc, networkType }, serviceId));
            }
            //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,01/12/2024,GF7TF-4564,
            if (apnList) {
              promises.push(apnList.items());
            }
            //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,01/12/2024,GF7TF-4564,

            return Promise.all(promises);
            /**
            return Promise.all([
              ApnUtils.getEuApns(),
              ApnUtils.getDefaultApns({ mcc, mnc, networkType }, serviceId),
              ApnUtils.getCpApns({ mcc, mnc, networkType }, serviceId)
            ]);
            **/
            //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-4308,
          })
          .then(results => {
            //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4308,
            //Restructure apn settings manager code
            // Restore preset and eu apns.
            /**
            const euApns = ApnUtils.separateApnsByType(results[0]);
            const defaultApns = results[1] || [];
            const cpApns = results[2]; // eslint-disable-line
            **/
            let euApns = Array.prototype.concat.apply([], results[0]);
            let defaultApns = Array.prototype.concat.apply([], results[1]);
            let cpApns; // eslint-disable-line
            let cpApnSettings = Array.prototype.concat.apply([], results[2]);
            let apnItems = Array.prototype.concat.apply([], results[3]);
            log('restore: euApns=' + JSON.stringify(euApns));
            log('restore: defaultApns=' + JSON.stringify(defaultApns));
            log('restore: cpApnSettings=' + JSON.stringify(cpApnSettings));
            log('restore: apnItems=' + JSON.stringify(apnItems));

            if (cpApns && cpApns.length) {
              cpApns.forEach(cpApn => {
                cpApn.deletedCpApn = false;
              });
            }

            if (OmaHelper) {
              //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,11/24/2024,GF5GTMO-5459
              //Optimize apn restore feature
              let apnItemsCount = Array.isArray(apnItems) ? apnItems.length : -1;
              let srcApns = defaultApns;
              let mergedApns = defaultApns;
              if (mode == RESTORE_MODE.ONLY_FOR_OMACP_UPDATE) {
                srcApns = ApnUtils.getApnsFromItems(apnItems);
              }
              //mergeCpApn
              mergedApns = OmaHelper.mergeCpApn(srcApns, cpApnSettings, sim.mccmnc, sim.mvno);
              let mergedCount = Array.isArray(mergedApns) ? mergedApns.length : 0;
              if (mergedCount > 0) {
                for (let apn of mergedApns) {
                  if (!apn) {
                    log('restore: apn is null, continue, apn=' + JSON.stringify(apn));
                    continue;
                  }
                  let category = ApnUtils.getApnCategory(apn);
                  let apnSource = ApnUtils.isNumber(apn.apn_source) ? (+apn.apn_source) : -1;
                  if (apnSource >= 0) {
                    apns.cpApns.push(apn);
                  } else if (category == ApnItem.APN_CATEGORY.PRESET) {
                    apns.presetApns.push(apn);
                  } else if (category == ApnItem.APN_CATEGORY.CUSTOM) {
                    apns.customApns.push(apn);
                  }
                }
              }
              log('restore: apnItemsCount=' + apnItemsCount + ' mergedCount=' + mergedCount
                  + ' presetApns.length=' + apns.presetApns.length
                  + ' cpApns.length=' + apns.cpApns.length
                  + ' customApns.length=' + apns.customApns.length
                  + ' customApns=' + JSON.stringify(apns.customApns));
              presetApns = Array.prototype.concat.apply([], apns.presetApns.concat(apns.cpApns));
              //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,11/24/2024,GF5GTMO-5459
            } else {
              presetApns = ApnUtils.separateApnsByType(
                Array.prototype.concat.apply([], defaultApns.concat(cpApns))
              );
            }
            log('restore: presetApns=' + JSON.stringify(presetApns));
            /**
            presetApns = ApnUtils.separateApnsByType(
              Array.prototype.concat.apply([], defaultApns.concat(cpApns))
            );
            **/
            //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-4308,

            return that
              .restoreApnItemsOfCategory(
                apnList,
                euApns,
                ApnItem.APN_CATEGORY.EU
              )
              .then(() => {
                //[BUGFIX]-Mod-BEGIN by GCCSZ.kaiyun.yan,11/24/2024,GF7TF-4405,GF5GTMO-5459
                //Optimize apn restore feature
                /**
                that.restoreApnItemsOfCategory(
                  apnList,
                  null,
                  ApnItem.APN_CATEGORY.CUSTOM
                )
                **/
                that.restoreApnItemsOfCategory(
                  apnList,
                  apns.customApns,
                  ApnItem.APN_CATEGORY.CUSTOM
                )
                //[BUGFIX]-Mod-END by GCCSZ.kaiyun.yan,GF7TF-4405,GF5GTMO-5459
              })
              .then(() =>
                that.restoreApnItemsOfCategory(
                  apnList,
                  presetApns,
                  ApnItem.APN_CATEGORY.PRESET
                )
              );
          })
          .then(
            () => that.apnSelections.clear(serviceId)

            /*
             * We simply clear the apn selections. The selections will be restored
             * based on the current apn settings when it is being queried.
             */
          )
          // eslint-disable-next-line
        .then(() => {
            //[BUGFIX]-Mod-BEGIN by GCCSZ.kaiyun.yan,12/15/2023,GF7TF-4405,
            //if (mode !== RESTORE_MODE.ONLY_APN_ITEMS) {
            if (mode === RESTORE_MODE.ALL) {
            //[BUGFIX]-Mod-END by GCCSZ.kaiyun.yan,GF7TF-4405,
              return that.apnSettings.restore(serviceId, presetApns);
            }
          })
      );
    },

    /**
     * Query apn items matching the mcc/mnc codes in the apn.json
     * database and the one received through client provisioning messages.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} apnType
     * @returns {Promise Array<ApnItem>} The apn items
     */
    //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3524,GF5GTMO-3715
    //Development apn settings feature
    //queryApns(serviceId, apnType) {
    queryApns(serviceId, apnType, options) {
      let fromSecretCode = false;
      if (options) {
        fromSecretCode = options.fromSecretCode;
      }
      let activeApnTypes = [];
      if (!apnType || apnType == '*') {
        activeApnTypes.push('default');
        /**
        if (fromSecretCode == false) {
          activeApnTypes.push('default');
        } else {
          activeApnTypes = APN_TYPES;
        }
        **/
      } else {
        activeApnTypes.push(apnType);
      }
      let activeApnCount = Array.isArray(activeApnTypes) ? activeApnTypes.length : -1;
      let allPromise = [];
      for(let type of activeApnTypes) {
        let p = new Promise((resolve, reject) => {
          //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,11/24/2024,GF5GTMO-5459
          //Optimize apn restore feature
          return resolve(this.getActiveApnId(serviceId, type, this.deriveActive));
          //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,GF5GTMO-5459
        });
        allPromise.push(p);
      }

      //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,11/18/2024,GF5GTMO-5352,
      //The APN added by the secret code page cannot be displayed on normal page
      let allPromiseCount = Array.isArray(allPromise) ? allPromise.length : -1;
      log('queryApns: serviceId=' + serviceId + ' apnType=' + apnType
          + ' options=' + JSON.stringify(options) + ' activeApnCount=' + activeApnCount
          + ' activeApnTypes=' + JSON.stringify(activeApnTypes)
          + ' allPromiseCount=' + allPromiseCount + ' allPromise=' + JSON.stringify(allPromise));
      //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,11/18/2024,GF5GTMO-5352,

      return Promise.all(allPromise).then(results => {
        let activeCount = Array.isArray(results) ? results.length : -1;
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,11/24/2024,GF5GTMO-5459
        //Optimize apn restore feature
        log('queryApns: set deriveActive from ' + this.deriveActive + ' to false');
        this.deriveActive = false;
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,GF5GTMO-5459

        log('queryApns: activeCount=' + activeCount + ' results=' + JSON.stringify(results));
        log('queryApns: options=' + JSON.stringify(options));
        //this.apnItems(serviceId, apnType).then(items => {
        return this.apnItems(serviceId, apnType, options).then(items => {
          log('queryApns: itemsCount=' + (Array.isArray(items) ? items.length : -1));
          if (activeCount < 1) {
            return Promise.resolve(items);
          }

          items.forEach(apnItem => {
            log('queryApns: apnItem=' + JSON.stringify(apnItem));
            apnItem.active = results.indexOf(apnItem.id) >= 0;
            log('queryApns: apnItem.active=' + apnItem.active + ' apnItem.id=' + apnItem.id);
            if (apnItem.active && apnItem.apn.deletedCpApn) {
              apnItem.apn.deletedCpApn = false;
              this.apnSettings.update(serviceId, apnType, apnItem.apn);
            }
          });
          return Promise.resolve(items);
        })
      });
    },
    //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-3524,GF5GTMO-3715

    /**
     * Add an apn to a sim slot.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {Object} apn
     * @param {ApnItem.APN_CATEGORY} category
     * @returns {Promise}
     */
    addApn(serviceId, apn, category) {
      return this.ready(serviceId).then(() =>
        this.apnList(serviceId).add(
          apn,
          category || ApnItem.APN_CATEGORY.CUSTOM
        )
      );
    },

    /**
     * Remove an apn from a sim slot.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} id
     *                 id of the apn item to be added.
     * @returns {Promise}
     */
    removeApn(serviceId, id) {
      return (
        this.ready(serviceId)
          .then(() => this.apnList(serviceId).remove(id))
          .then(
            () => this.getApnAppliedType(serviceId, id)
            // Check if the removed apn is actively being used.
          )
          // eslint-disable-next-line
        .then((matchedApnType) => {
            if (matchedApnType) {
              return this.deriveActiveApnIdFromItems(
                serviceId,
                matchedApnType
              ).then(activeApnId =>
                this.setActiveApnId(serviceId, matchedApnType, activeApnId)
              );
            }
          })
      );
    },

    /**
     * Update an apn item.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} id
     *                 id of the apn item to be updated.
     * @param {Object} apn
     * @returns {Promise}
     */
    updateApn(serviceId, id, apn) {
      return (
        this.ready(serviceId)
          .then(() => this.apnList(serviceId).update(id, apn))
          .then(
            () => this.getApnAppliedType(serviceId, id)
            // Check if the updated apn is actively being used.
          )
          // eslint-disable-next-line
        .then((matchedApnType) => {
            if (matchedApnType) {
              if (apn.deletedCpApn) {
                return this.deriveActiveApnIdFromItems(
                  serviceId,
                  matchedApnType
                ).then(activeApnId =>
                  this.setActiveApnId(serviceId, matchedApnType, activeApnId)
                );
              }
              return this.storeApnSettingByType(serviceId, matchedApnType);
            }
          })
      );
    },

    /**
     * Get the id of the apn that is actively being used for an apn type.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} apnType
     * @returns {Promise String}
     */
    //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,11/24/2024,GF5GTMO-5459
    //getActiveApnId(serviceId, apnType) {
    getActiveApnId(serviceId, apnType, force) {
      //[BUGFIX]Add by yelee, 2025/02/08, GF5GTMO-6174
      if (!apnType || apnType === '*') {
        log('getActiveApnId: change apnType from ' + apnType + ' to default.');
        apnType = 'default';
      }
      const that = this;
      return this.ready(serviceId)
        .then(() => that.apnSelections.get(serviceId))
        .then(apnSelection => apnSelection && apnSelection[apnType])
        .then(activeApnId => {

          //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,11/24/2024,GF5GTMO-5459
          //Optimize apn restore feature
          log('getActiveApnId: serviceId=' + serviceId + ' apnType=' + apnType
              + ' force=' + force + ' activeApnId=' + activeApnId);
          if (activeApnId && !force) {
            return activeApnId;
          }
          /**
          if (activeApnId) {
            return activeApnId;
          }
          **/
          //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-5459

          /*
           * If there is no existing active apn id, try to derive the id from
           * the current apn settings.
           */
          return that
            .deriveActiveApnIdFromSettings(serviceId, apnType)
            .then(apnId => {
              // Set the id as the active apn id.
              that.setActiveApnId(serviceId, apnType, apnId);
              return apnId;
            });
        })
        .then(activeApnId => {
          /*
           * If there is still no active apn id, means that the apn settings
           * have not been set and we need to derive a default id from the
           * current apn items (stored in the apn list).
           */
          if (activeApnId) {
            return activeApnId;
          }
          return '';
        });
    },

    /**
     * Set the id of an apn that is to be used for an apn type.
     *
     * @access public
     * @memberOf ApnSettingsManager.prototype
     * @param {Number} serviceId
     * @param {String} apnType
     * @param {String} id
     * @returns {Promise}
     */
    //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,11/13/2024,GF5GTMO-5277,
    //setActiveApnId(serviceId, apnType, id) {
    setActiveApnId(serviceId, apnType, id, options) {

      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4308,GF5GTMO-5277,
      //Restructure apn settings manager code
      log('setActiveApnId: serviceId=' + serviceId + ' apnType=' + apnType + ' id=' + id);
      if (!apnType || apnType == '*') {
        log('setActiveApnId: change apnType from ' + apnType + ' to default');
        apnType = 'default';
      }

      let that = this;
      let editable = false;
      if (options) {
          editable = (options.editable == 'true' || options.editable == true);
      }
      let promises = [];
      promises.push(this.apnSelections.get(serviceId));
      if (id) {
        promises.push(this.apnList(serviceId).item(id));
      }
      log('setActiveApnId: that=' + that + ' promises.length=' + promises.length
          + ' editable=' + editable + ' options=' + JSON.stringify(options));
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4308,GF5GTMO-5277,

      return (
        this.ready(serviceId)
          //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,11/13/2024,GF5GTMO-5277,
          //Implement feature to update non default apn to data call
          //.then(() => this.apnSelections.get(serviceId))
          // eslint-disable-next-line
        //.then((apnSelection) => {
          .then(() => { return Promise.all(promises); })
        .then((result) => {
            let apnSelection = result[0]
            let apnItem = result[1];
            let apn = apnItem && apnItem.apn;
          //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-5277,

            //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4308,GF5GTMO-5277,
            //Restructure apn settings manager code
            log('setActiveApnId: apnType=' + apnType + ' apnSelection=' + JSON.stringify(apnSelection));
            log('setActiveApnId: apnType=' + apnType + ' apnItem=' + JSON.stringify(apnItem));

            let updateTask = function(id, type, apn) {
              apnSelection[type] = id;
              log('setActiveApnId: updateTask: id=' + id + ' type=' + type + ' apn=' + JSON.stringify(apn));
              log('setActiveApnId: updateTask: apnSelection=' + JSON.stringify(apnSelection));
              return that.apnSettings.update(serviceId, type, apn);
            };
            if (apn) {
              let apnTypesCount = Array.isArray(apn.types) ? apn.types.length : 0;
              let apnTypeIndex = apnTypesCount > 0 ? apn.types.indexOf(apnType) : -1;
              log('setActiveApnId: apnTypesCount=' + apnTypesCount + ' apn.types=' + JSON.stringify(apn.types)
                  + ' apnType=' + apnType + ' apnTypeIndex=' + apnTypeIndex);
              if (apnTypesCount > 0 && (apnTypeIndex < 0 || editable)) {
                let updateTasks = [];
                let apns = [ apn ];
                apns = ApnUtils.separateApnsByType(apns);
                let apnsCount = Array.isArray(apns) ? apns.length : 0;
                log('setActiveApnId: apnsCount=' + apnsCount);
                if (apnsCount > 0) {
                  for (let a of apns) {
                    let aType = a && Array.isArray(a.types) && a.types[0];
                    log('setActiveApnId: a=' + JSON.stringify(a));
                    if (!aType) {
                      continue;
                    }
                    let task = new Promise((resolve, reject) => {
                        return resolve(updateTask(id, aType, a));
                    });
                    updateTasks.push(task);
                  }
                  log('setActiveApnId: updateTasks.length=' + updateTasks.length);
                  if (updateTasks.length > 0) {
                      return Promise.all(updateTasks);
                  }
                }
              }
            }
            log('setActiveApnId: storeApnSettingByType: id=' + id
                + ' apnSelection[' + apnType + ']=' + apnSelection[apnType]);
            //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4308,GF5GTMO-5277,

            if (apnSelection[apnType] !== id) {
              apnSelection[apnType] = id;
              return this.storeApnSettingByType(serviceId, apnType);
            }
          })
      );
    }
  };

  return new ApnSettingsManager();
});
