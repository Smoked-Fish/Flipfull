/* global ApnHelper, SimCardHelper */
/**
 * The apn utilities
 */
'use strict';
define(function(require) { //eslint-disable-line
  const ApnConst = require('modules/apn_tct/apn_const');
  const ApnItem = require('modules/apn_tct/apn_item');

  const { CP_APN_KEY } = ApnConst;
  const { DEFAULT_APN_KEY } = ApnConst;
  const { MCC_SETTINGS_KEY } = ApnConst;
  const { MNC_SETTINGS_KEY } = ApnConst;
  const { MVNO_SETTINGS_KEY } = ApnConst;
  const { APN_PROPS } = ApnConst;
  const { EU_ROAMING_FILE_PATH } = ApnConst;

  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3537,
  //Development apn editor feature
  function log(msg) {
      dump('TctApn: apn_utils: ' + msg);
  }
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3537,

  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4303,
  //Restructure apn editor code and optimize feature
  function getResValue(resName, def) {
    let ret = def;
    let resVal;
    const getRes = window.api.l10n.get;
    if (getRes) {
      resVal = getRes(resName);
      if (resVal && resVal != '') {
        ret = resVal;
      }
    }
    log('getResValue: resName=' + resName + ' resVal=' + resVal + ' resValType=' + (typeof resVal)
        + ' def=' + def + ' ret=' + ret + ' getRes=' + getRes);
    return ret;
  }
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4303,

  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,02/06/2024,GF7TF-4794,
  //Add MCC MNC MVNO_TYPE MVNO_MATCH_DATA items
  function getIccInfo(iccCardIndex) {
      let iccInfo = null;
      let iccCard = SimCardHelper.getIccInfo(iccCardIndex);
      if (iccCard) {
          iccInfo = iccCard.iccInfo;
      }
      return iccInfo;
  }
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-4794,

  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,10/16/2023,GF7TF-3658,
  function isTfSim(iccIndex) {
      let iccInfo;
      let iccCard = SimCardHelper.getIccInfo(iccIndex);
      if (iccCard) {
          iccInfo = iccCard.iccInfo;
      }
      if (iccInfo) {
          let mcc = iccInfo.mcc;
          let mnc = iccInfo.mnc;
          let gid1 = iccInfo.gid1 + '';
          let gid1Upper = gid1.toUpperCase() + '';
          let mccmnc = mcc.concat(mnc) + '';
          log('isTfSim: mccmnc=' + mccmnc + ' gid1=' + gid1 + ' gid1Upper=' + gid1Upper);
          if (mccmnc === '310410' || mccmnc === '310280' || mccmnc === '311180' || mccmnc === '310950') {
              if (gid1Upper.indexOf('DEFF') == 0 || gid1Upper.indexOf('DDFF') == 0) {
                  return true
              }
          } else if (mccmnc === '310260' || mccmnc === '310240') {
              if (gid1Upper.indexOf('DEFF') == 0 || gid1Upper.indexOf('534D') == 0 || gid1Upper.indexOf('4D4B') == 0) {
                  return true
              }
          } else if (mccmnc === '311480' || mccmnc.indexOf('31059') == 0) {
              if (gid1Upper.indexOf('BA01270000000000') == 0) {
                  return true
              }
          } else if (mccmnc === '330110') {
              if (gid1Upper.indexOf('DEFF') == 0) {
                  return true
              }
          }
      }
      return false;
  }
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-3658,

  function getOperatorCode(serviceId, type) {
    let value = '';
    let key = '';
    const isDoubleSimSlot = SimCardHelper.isDoubleSimSlot();
    if (type === 'mcc') {
      value = '000';
      key = isDoubleSimSlot
        ? MCC_SETTINGS_KEY[serviceId + 1]
        : MCC_SETTINGS_KEY[0];
    } else if (type === 'mnc') {
      value = '00';
      key = isDoubleSimSlot
        ? MNC_SETTINGS_KEY[serviceId + 1]
        : MNC_SETTINGS_KEY[0];
    } else if (type === 'mvno') {
      value = [];
      key = isDoubleSimSlot
        ? MVNO_SETTINGS_KEY[serviceId + 1]
        : MVNO_SETTINGS_KEY[0];
    } else {
      const error = 'invalid type';
      return Promise.reject(error);
    }

    return new Promise(resolve => {
      SettingsDBCache.getSetting(key).then(results => {
        if (results && Array.isArray(results) && results[0]) {
          // eslint-disable-next-line prefer-destructuring
          value = results[0];
        }
        resolve(value);
      });
    });
  }

  /**
   * Helper function. Filter APNs by apn type.
   *
   * @param {String} type
   *                 The apn type we would like to include.
   * @param {ApnItem} apnItem
   */
  function apnTypeFilter(type, apnItem) {
    if (!type || !apnItem || !apnItem.apn.types) {
      return false;
    } else if (type === '*') {
      return true;
    }
    return apnItem.apn.types.indexOf(type) !== -1;
  }

  /**
   * Query <apn> elements matching the mcc/mnc arguments in the apn.json
   * database
   *
   * @param {String} mcc
   * @param {String} mnc
   * @param {String} networkType
   *                 The network type which the APN must be compatible with.
   */
  function getDefaultApns(Obj, serviceId) {
    // Should fallback to the JSON file if we don't get the apns
    return new Promise(resolve => {
      SettingsDBCache.getSetting(DEFAULT_APN_KEY).then(value => {
        const { mcc, mnc, networkType } = Obj;
        const result = value[serviceId] || {};
        const apns = {};
        apns[mcc] = {};
        apns[mcc][mnc] = result || {};
        resolve(ApnHelper.getCompatible(apns, mcc, mnc, networkType)); // eslint-disable-line
      });
    });
  }

  /**
   * Query <apn> elements matching the mcc/mnc arguments in the database
   * received through client provisioning messages.
   *
   * @param {String} mcc
   * @param {String} mnc
   * @param {String} networkType
   *                 The network type which the APN must be compatible with.
   */
  function getCpApns(Obj, serviceId) {
    return new Promise(resolve => {
      SettingsDBCache.getSetting(CP_APN_KEY).then(value => {
        const { mcc, mnc, networkType } = Obj;
        const apns = value || {};
        resolve(
          ApnHelper.getCompatible(apns[serviceId], mcc, mnc, networkType)
        ); // eslint-disable-line
      });
    });
  }

  let euApnChecked = false;
  let euApns = null;

  /**
   * Return the EU apns for roaming.
   */
  function getEuApns() {
    if (euApnChecked) {
      return Promise.resolve(euApns);
    }
    return LazyLoader.getJSON(EU_ROAMING_FILE_PATH)
      .then(result => {
        euApnChecked = true;

        /*
         * Only return eu apns when both home and foreign operators are
         * Specified.
         */
        if (
          result.home &&
          result.foreign &&
          Object.keys(result.home).length > 0 &&
          Object.keys(result.foreign).length > 0
        ) {
          euApns = result.defaultApns;
        }
        return euApns;
      })
      .catch(() => {
        euApnChecked = true;
        return null;
      });
  }

  function generateId() {
    // Should refine this
    return Math.random()
      .toString(36)
      .substr(2, 9);
  }

  function cloneApn(apn) {
    const newApn = {};
    for (let p in apn) { // eslint-disable-line
      newApn[p] = apn[p];
    }
    return newApn;
  }

  function separateApnsByType(apns) {
    if (!apns) {
      return [];
    }
    return apns.reduce((result, apn) => {
      // Separate the apn by type
      apn.types.forEach(type => {
        const newApn = cloneApn(apn);
        newApn.types = [type];
        result.push(newApn);
      });
      return result;
    }, []);
  }

  function isMatchedApn(apn1, apn2) {
    if (!apn1 || !apn2) {
      return false;
    }

    // Check if the type of apn1 is the subset of apn2
    if (!apn1.types.every(type => apn2.types.indexOf(type) !== -1)) {
      return false;
    }

    return APN_PROPS.every(prop => {
      if (prop === 'types') {
        // We've already check this property
        return true;
      }
      return apn1[prop] === apn2[prop];
    });
  }

    function isMatchedApn_ex(apn1, apn2) {
        if (apn1 == null || apn2 == null) {
            return false;
        }

        // Check if the type of apn1 is the subset of apn2
        if (!apn1.types.some(function(type) {
                return (apn2.types.indexOf(type) !== -1);
            })) {
            return false;
        }

        return APN_PROPS.every(function(prop) {
            if (prop === 'types') {
                // we've already check this property
                return true;
            } else {
                return apn1[prop] === apn2[prop];
            }
        });
    }

    function isMatchedApnByNameAndType(apn1, apn2) {
        if (apn1 == null || apn2 == null) {
            return false;
        }
        log('isMatchedApnByNameAndType: apn1[carrier] = ' + JSON.stringify(apn1['carrier']));
        log('isMatchedApnByNameAndType: apn2[carrier] = ' + JSON.stringify(apn2['carrier']));
        if(apn1['carrier'] !== apn2['carrier']) {
            log('isMatchedApnByNameAndType: return false');
            return false;
        }
        // Check if the type of apn1 is the subset of apn2
        if (apn1.types.length !== apn2.types.length) {
          return false;
        }
        var isSame = true;
        for (var index = 0; index <apn1.types.length; index++) {
          var type = apn1.types[index];
          if (apn2.types.indexOf(type) == -1) {
              isSame = false;
              break;
          }
        }
        log('isMatchedApnByNameAndType: return true');
        return isSame;
    }

  // [TF:TF_REQ_DEVICE SPEC_065]  Task8676326,GF7TF-4352-lijuan.li@tcl.com-begin
  function isVzwCard(iccIndex) {
      let connection = navigator.b2g.mobileConnections;
      if (connection[iccIndex]) {
          let iccId = connection[iccIndex].iccId;
          if (iccId) {
              let iccInfo = navigator.b2g.iccManager.getIccById(iccId).iccInfo;
              if (iccInfo.iccid.indexOf('891480') != -1) {
                  dump('apn_utils vzw card!');
                  if (iccInfo) { //[BUGFIX]Add by yelee,GF7OM-965,2024/02/22
                      let gid = iccInfo.gid1 + '';
                      let gidUpper = gid.toUpperCase() + '';
                      dump('apn_utils: gid = ' + gid + ', gidUpper = ' + gidUpper);
                      if(!gidUpper.indexOf('BA01490000000000') == 0) {
                          dump('apn_utils: isVzwCard and not spectrum sim!');
                          return true;
                      }
                  }
              }
              if (iccInfo) {
                  let mcc = iccInfo.mcc;
                  let mnc = iccInfo.mnc;
                  let gid1 = iccInfo.gid1 + '';
                  let gid1Upper = gid1.toUpperCase() + '';
                  let mccmnc = mcc.concat(mnc);
                  dump('apn_utils: check isVzwCard, mccmnc = ' + mccmnc + ', gid1 = ' + gid1);
                  if (gid1Upper.indexOf('BA01270000000000') == 0 && (mccmnc.indexOf('31059') == 0 || mccmnc === '311480')) {
                      return true;
                  } else if (gid1Upper.indexOf('BAE2000000000000') == 0 && mccmnc === '311480') {
                      return true;
                  } else if (mccmnc.indexOf('31059') == 0) {
                      return true;
                  }
              }
          }
      }
      return false;
  }
  // [TF:TF_REQ_DEVICE SPEC_065]  Task8676326,GF7TF-4352-lijuan.li@tcl.com-end

  // [VZW:VZ_REQ_LTEDATA_6742,VZ_REQ_LTEDATA_6754] Task8735674-lijuan.li@tcl.com-begin
  function setSystemProp(index, value) {
      return new Promise(function(resolve, reject) {
          window.navigator.mozSysProp.setSysProp(index, value,
              function setCallback(index, succeeded, err) {
                  dump('APNs: setting index = ' + index + '; succeeded =' +
                      succeeded + '; err = '+ err);

                  if (succeeded) {
                      resolve();
                  } else {
                      reject();
                  }
              });
      });
  }
  // [VZW:VZ_REQ_LTEDATA_6742,VZ_REQ_LTEDATA_6754] Task8735674-lijuan.li@tcl.com-end


  function sortByCategory(apn1, apn2) {
    if (apn1.category === ApnItem.APN_CATEGORY.PRESET) {
      return true;
    } else if (apn2.category === ApnItem.APN_CATEGORY.PRESET) {
      return false;
    }
    return true;
  }

  function clone(apn) {
    return JSON.parse(JSON.stringify(apn));
  }

    function getRecentInstallCpApns(mcc, mnc, mvnoData) {
        return new Promise((resolve, reject) => {
            SettingsDBCache.getSetting('ril.recent.install.cp.apns').then((result)=>{
                dump('APNs: apn_utils _getRecentInstallCpApns apns = '+JSON.stringify(result));
                if (!result) {
                    result = [];
                }
                resolve(ApnHelper.getCompatibleWithMvnoData(result, mcc, mnc, mvnoData));
            });
        });
    }

    function getCpApns(mcc, mnc) {
        return new Promise((resolve, reject) => {
            var cpApnList = {};
            navigator.b2g.engmodeManager.checkIsFileExist('/otapkg/omacp/omacp.txt').then((result) => {
                if ('NO_EXIST' == result) {
                    resolve([]);
                } else {
                    navigator.b2g.engmodeManager.fileReadLE('omacp_file').then((exitingApns) => {
                        if (exitingApns != undefined && exitingApns != '' && exitingApns) {
                            var apns = JSON.parse(exitingApns);
                            cpApnList = apns[0];
                            dump('apn_utils cpApnList= ' + JSON.stringify(cpApnList));
                        }
                        resolve(ApnHelper.getCompatibleWithMvnoData(cpApnList, mcc, mnc));
                    });
                }
            });
        });
    }

    function clearRecentInstallSettings(mcc, mnc, mvnoData) {
        return new Promise((resolve, reject) => {
            SettingsObserver.getValue('ril.recent.install.cp.apns').then((data)=>{
                if (data){
                    data = {};
                    data[mcc]={};
                    data[mcc][mnc]={};
                    data[mcc][mnc][mvnoData]=[];
                    SettingsObserver.setValue([{
                        name: 'ril.recent.install.cp.apns',
                        value: data
                    }]).then(()=>{
                        resolve();
                    });
                }
            });
        });
    }

  // Task11024288-lijuan.li@tcl.com-begin
  function isUsccCard(iccIndex) {
      let iccInfo;
      let iccCard = SimCardHelper.getIccInfo(iccIndex);
      if (iccCard) {
          iccInfo = iccCard.iccInfo;
      }
      if (iccInfo) {
          let mcc = iccInfo.mcc;
          let mnc = iccInfo.mnc;
          let mccmnc = mcc.concat(mnc);
          dump('apn_utils mccmnc = '+mccmnc);
          if (mccmnc === '20404' || mccmnc === '310730' || mccmnc === '311220'
              || mccmnc === '311221'|| mccmnc === '311222'|| mccmnc === '311223'
              || mccmnc === '311224'|| mccmnc === '311225'|| mccmnc === '311226'
              || mccmnc === '311227'|| mccmnc === '311228'|| mccmnc === '311229'
              || mccmnc === '311580'|| mccmnc === '311581'|| mccmnc === '311582'
              || mccmnc === '311583'|| mccmnc === '311584'|| mccmnc === '311585'
              || mccmnc === '311586'|| mccmnc === '311587'|| mccmnc === '311588'
              || mccmnc === '311589') {
              return true
          }
      }
      return false;
  }
  // Task11024288-lijuan.li@tcl.com-end

  //[BUGFIX]Add by yelee,GF7OM-966,2024/02/26
  function isSpectrumSim(iccIndex) {
      let connection = navigator.b2g.mobileConnections;
      if (connection[iccIndex]) {
          let iccId = connection[iccIndex].iccId;
          if (iccId) {
              let iccInfo = navigator.b2g.iccManager.getIccById(iccId).iccInfo;
              if (iccInfo) {
                  let mcc = iccInfo.mcc;
                  let mnc = iccInfo.mnc;
                  let gid1 = iccInfo.gid1 + '';
                  let gid1Upper = gid1.toUpperCase() + '';
                  let mccmnc = mcc.concat(mnc);
                  dump('apn_utils: check isSpectrumSim, mccmnc = ' + mccmnc + ', gid1 = ' + gid1);
                  if (gid1Upper.indexOf('BA01490000000000') == 0 && mccmnc === '311480') {
                      return true;
                  } else if (mccmnc === '31420') {
                      return true;
                  }
              }
          }
      }
      return false;
  }

  //[BUGFIX]-Add-BEGIN by GCCSZ.kaiyun.yan,12/21/2023,GF7TF-4405,
  function deepCompare(obj1, obj2) {
    log('deepCompare: START');
    //undefined
    if (obj1 === undefined || obj2 === undefined) {
      log('deepCompare: obj1=' + obj1 + ' obj2=' + obj2);
      return false;
    }

    //Non Object
    if (typeof obj1 !== "object" || typeof obj2 !== "object") {
      log('deepCompare: obj1==obj2');
      return obj1 == obj2;
    }

    if (obj1 === obj2) {
      log('deepCompare: obj1 is obj2');
      return true;
    }

    let obj1Json = JSON.stringify(obj1);
    let obj2Json = JSON.stringify(obj2);
    if (obj1Json == obj2Json) {
      log('deepCompare: obj1Json==obj2Json obj1Json=' + obj1Json);
      return true;
    }

    let keys1 = Object.keys(obj1);
    let keys2 = Object.keys(obj2);
    let keys1Count = Array.isArray(keys1) ? keys1.length : -1;
    let keys2Count = Array.isArray(keys2) ? keys2.length : -1;
    if (keys1Count < 1 || keys2Count < 1 || keys1Count != keys2Count) {
      log('deepCompare: keys1Count=' + keys1Count + ' keys2Count=' + keys2Count);
      return false;
    }

    for(let i = 0; i < keys1Count; i++) {
      let key = keys1[i];
      if (key === undefined) {
        continue;
      }
      let val1 = obj1[key];
      let val2 = obj2[key];
      log('deepCompare: key=' + key + ' val1=' + val1 + ' val2=' + val2);
      if (val1 != val2) {
        return false;
      }
    }
    return true;
  }

  function findActiveApn(serviceId, apnType, apnInUse, apnItems) {
    let apnInUseCount = Array.isArray(apnInUse) ? apnInUse.length : 0;
    let apnItemsCount = Array.isArray(apnItems) ? apnItems.length : 0;
    let maxCount = apnItemsCount > apnInUseCount ? apnItemsCount : apnInUseCount;

    if (apnInUseCount > 0) {
      let apnInUse_0 = apnInUse[0];
      let apnInUse_i = apnInUse[serviceId];
      if (Array.isArray(apnInUse_i)) {
        apnInUse = apnInUse_i;
      } else if (Array.isArray(apnInUse_0)) {
        apnInUse = apnInUse_0;
      }
      apnInUseCount = Array.isArray(apnInUse) ? apnInUse.length : 0;
    }

    log('findActiveApn: START: serviceId=' + serviceId + ' apnType=' + apnType
            + ' apnInUseCount=' + apnInUseCount + ' apnItemsCount=' + apnItemsCount
            + ' maxCount=' + maxCount);

    if (apnItemsCount < 1) {
      return undefined;
    }

    let apnInUseDefault;
    let apnInUseBackup;
    let maxApnSource = -1;
    //Loop apnItems
    for(let i = 0; i < apnItemsCount; i++) {
      let apnItem = apnItems[i];
      let aApn = apnItem === undefined ? undefined : apnItem.itemApn;
      log('findActiveApn: index=' + i + ' aApn=' + JSON.stringify(aApn));
      if (aApn === undefined) {
        continue;
      }

      let aTypes = aApn.types;
      let aIsDefaultApn = Array.isArray(aTypes) ? aTypes.indexOf('default') >= 0 : false;
      let aApnSource = aApn.apn_source;
      log('findActiveApn: index=' + i + ' aTypes=' + JSON.stringify(aTypes)
              + ' aIsDefaultApn=' + aIsDefaultApn + ' aApnSource=' + aApnSource);
      if (aIsDefaultApn != true) {
        continue;
      }

      if (apnInUseBackup === undefined) {
        apnInUseBackup = aApn;
      }
      if (aApnSource !== undefined && aApnSource > maxApnSource) {
        maxApnSource = aApnSource;
        apnInUseDefault = aApn;
        log('findActiveApn: maxApnSource=' + maxApnSource + ' aApnSource=' + aApnSource);
      }

      for (let j = 0; j < apnInUseCount; j++) {
        let bApn = apnInUse[j];
        if (bApn === undefined) {
          continue;
        }
        let isSame = deepCompare(bApn, aApn);
        if (isSame != true) {
          continue;
        }
        if (apnInUseDefault === undefined) {
          apnInUseDefault = aApn;
        }
        log('findActiveApn: index=' + i + ' bApn=' + JSON.stringify(bApn));
        let bTypes = bApn.types;
        let bApnSource = bApn.apn_source;
        if (bApnSource !== undefined && bApnSource > maxApnSource) {
          maxApnSource = bApnSource;
          apnInUseDefault = aApn;
          log('findActiveApn: maxApnSource=' + maxApnSource);
        }
      }
    }

    log('findActiveApn: END: apnInUseDefault=' + JSON.stringify(apnInUseDefault)
            + ' apnInUseBackup=' + JSON.stringify(apnInUseBackup)
            + ' maxApnSource=' + maxApnSource);

    if (apnInUseDefault === undefined) {
      if (apnInUseBackup !== undefined) {
        apnInUseDefault = apnInUseBackup;
      } else {
        apnInUseDefault = apnItems[0];
      }
    }

    return apnInUseDefault;
  }

  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,11/24/2024,GF5GTMO-5459
  //Optimize apn restore feature
  function isNumber(input) {
      return (/^-?[\d.]+$/.test(input));
  }

  function getApnsFromItems(apnItems) {
    let apns = [];
    if (Array.isArray(apnItems) && apnItems.length > 0) {
      for (let apnItem of apnItems) {
        let apn = apnItem && apnItem.apn;
        if (!apn) {
          log('getApnsFromItems: apn is null, apn=' + apn);
          continue;
        }
        apn.category = apnItem.category;
        apns.push(apn);
      }
    }
    return apns;
  }

  function getApnCategory(apn) {
    if (!apn) {
      log('getApnCategory: apn is null, return unknown, apn=' + JSON.stringify(apn));
      return 'unknown';
    }
    let apnSource = isNumber(apn.apn_source) ? (+apn.apn_source)
        : ((apn.apn && isNumber(apn.apn.apn_source)) ? (+apn.apn.apn_source) : -1);
    let category = ApnItem.APN_CATEGORY.PRESET;
    if (apnSource >= 0) {
      log('getApnCategory: apnSource=' + apnSource + ', change category from '
          + apn.category + ' to preset,' + ' apn=' + JSON.stringify(apn));
      apn.category = ApnItem.APN_CATEGORY.PRESET;
    } else if (apn.category == ApnItem.APN_CATEGORY.CUSTOM) {
      category = ApnItem.APN_CATEGORY.CUSTOM;
    }
    log('getApnCategory:-----> category=' + category + ' apnSource=' + apnSource
        + ' apn.apn_source=' + apn.apn_source + ' apn=' + JSON.stringify(apn));
    return category;
  }
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-5459

  function updateApnList(apnList, apnItems, mergedApns) {
    let itemApns = [];
    let apnItemsCount = Array.isArray(apnItems) ? apnItems.length : -1;
    let mergedApnsCount = Array.isArray(mergedApns) ? mergedApns.length : -1;
    let loopCount = mergedApnsCount > apnItemsCount ? mergedApnsCount : apnItemsCount;
    log('updateApnList: mergedApnsCount=' + mergedApnsCount + ' loopCount=' + loopCount
           + ' mergedApns=' + JSON.stringify(mergedApns));
    if (apnItemsCount > 0) {
       for (let apnItem of apnItems) {
           if (apnItem === undefined || apnItem == null) {
               continue;
           }
           itemApns.push(apnItem.apn);
       }
    }
    if (loopCount > 0) {
      for (let i = 0; i < loopCount; i++) {
        let apnItem = apnItems[i];
        let apn = mergedApns[i];
        if (i < apnItemsCount) {
          if (apnItem !== undefined && apnItem != null) {
            let category = apnItem.category;
            let itemApn = apnItem.apn;
            let apnSource = -1;
            if (itemApn !== undefined && itemApn != null) {
                if (itemApn.apn_source !== undefined) {
                    apnSource = itemApn.apn_source;
                    apnSource = +apnSource;
                }
                log('restore: apnSource=' + apnSource
                        + ' carrier=' + itemApn.carrier
                        + ' category=' + apnItem.category);
            }
            if (apnItem.category == ApnItem.APN_CATEGORY.CUSTOM
                    && apnSource >= 0) {
                apnItem.category = ApnItem.APN_CATEGORY.PRESET;
                log('restore: category=' + apnItem.category);
            }
          }
        } else if (i >= apnItemsCount) {
          if (apn !== undefined && apn != null) {
              apnList.add(apn, ApnItem.APN_CATEGORY.PRESET);
          }
        }
      }
    }
    if (apnItemsCount > 0) {
        let apnItem = apnItems[0];
        log('updateApnList apnItem=' + JSON.stringify(apnItem));
        if (apnItem !== undefined) {
            apnList.update(apnItem.id, apnItem.apn);
        }
    }
  }
  //[BUGFIX]-Add-END by GCCSZ.kaiyun.yan,GF7TF-4405,

  //[BUGFIX]-Add-BEGIN by GCCSZ.kaiyun.yan,12/10/2023,GF7TF-4405,
  function handleOptions(inputElement, name, value) {
    if (!inputElement || !name || !value) {
        return;
    }

    let currentOpts = inputElement.options;
    let currentOptsCount = currentOpts ? currentOpts.length : -1;
    if (currentOptsCount < 1) {
        return;
    }

    let defaultOpts = [];
    if (name == 'protocol' || name == 'roaming_protocol') {
        defaultOpts = ['NOTDEFINED', 'IP', 'IPV6', 'IPV4V6'];
    } else if (name == 'authtype') {
        defaultOpts = ['NOTDEFINED', 'NONE', 'PAP', 'CHAP', 'PAPORCHAP'];
    }

    let defaultOptsCount = defaultOpts.length;
    let valueUpper = value.toUpperCase();
    let index = defaultOpts.indexOf(valueUpper);
    log('handleOptions: name:' + name + ' value=' + value + ' valueUpper=' + valueUpper
        + ' currentOptsCount=' + currentOptsCount + ' defaultOptsCount=' + defaultOptsCount
        + ' index=' + index);

    if (defaultOptsCount < 1) {
        return;
    } else if (currentOptsCount == defaultOptsCount) {
        if (index < 0) {
            currentOpts.add(new Option(value, value));
        }
    } else if (currentOptsCount > defaultOptsCount) {
        for (let i=(currentOptsCount - 1); i >= defaultOptsCount; i--) {
            currentOpts.remove(i);
        }
        if (index < 0) {
            currentOpts.add(new Option(value, value));
        }
    }
  }
  //[BUGFIX]-Add-END by GCCSZ.kaiyun.yan,GF7TF-4405,

  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,12/05/2023,GF7TF-4131,
  //The protocol is showed as notdefined
  function covertProtocol(aProtocol) {
      let bProtocol = 'notDefined';
      if (!aProtocol) {
          return bProtocol;
      }

      let aProtocolUpper = aProtocol.toUpperCase();
      if (aProtocolUpper == 'IP' || aProtocolUpper == 'IPV4') {
          bProtocol = 'IP';
      } else if (aProtocolUpper == 'IPV6' || aProtocolUpper == 'IPV4V6') {
          bProtocol = aProtocolUpper;
      } else {
          bProtocol = aProtocol;
      }
      log('covertProtocol: aProtocol=' + aProtocol + ' bProtocol=' + bProtocol);
      return bProtocol;
    }

  function convertAuthType(aAuth) {
      let bAuth = 'notDefined';
      if (!aAuth) {
          return bAuth;
      }

      let aAuthLower = aAuth.toLowerCase();
      if (aAuthLower == '-1') {
          bAuth = 'notDefined';
      } else if (aAuthLower == '0' || aAuthLower == 'none') {
          bAuth = 'none';
      } else if (aAuthLower == '1' || aAuthLower == 'pap') {
          bAuth = 'pap';
      } else if (aAuthLower == '2' || aAuthLower == 'chap') {
          bAuth = 'chap';
      } else if (aAuthLower == '3' || aAuthLower == 'paporchap') {
          bAuth = 'papOrChap';
      } else {
          bAuth = aAuth;
      }
      log('convertAuthType: aAuth=' + aAuth + ' bAuth=' + bAuth);
      return bAuth;
  }
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-4131,

  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4303,
  //Restructure apn editor code and optimize feature
  function setNodeVisible(element, visible) {
    log('setNodeVisible: visible=' + visible + ' element=' + element.outerHTML);
    if (!element) {
      log('setNodeVisible: element is null');
      return;
    }
    visible = visible == false ? false : true;
    try {
      console.dir(element.style);

      if (element.classList) {
        let hasHidden = element.classList.contains('hidden');
        if (visible) {
          if (hasHidden) {
            element.classList.remove('hidden');
          }
        } else {
          if (!hasHidden) {
            element.classList.add('hidden');
          }
        }
        let hasHidden2 = element.classList.contains('hidden');
        log('setNodeVisible: from ' + !hasHidden + ' to ' + !hasHidden2);
      }
    } catch (e) {
      log('setNodeVisible: error=' + e);
    }
  }

  function setNodeEnabled(element, enabled) {
    log('setNodeEnabled: enabled=' + enabled + ' element=' + element);
    if (!element) {
      log('setNodeEnabled: element is null');
      return;
    }
    enabled = enabled == false ? false : true;
    try {

      let hasDisabled = element.hasAttribute('disabled');
      let disabled = false;
      if (hasDisabled) {
        disabled = element.getAttribute('disabled');
      }
      log('setNodeEnabled: disabled=' + disabled + ' hasDisabled=' + hasDisabled);
      if (enabled) {
        if (disabled) {
          element.removeAttribute('disabled', 'disabled');
        }
      } else {
        element.setAttribute('disabled', 'disabled');
      }
    } catch (e) {
      log('setNodeEnabled: error=' + e);
    }
  }
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4303,

  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,03/11/2024,GF7TF-4854,
  //The UI display format is not uniformed for each field.
  function setApnNodeEnabled(inputElement, enabled) {
    log('setApnNodeEnabled: enabled=' + enabled + ' inputElement=' + inputElement);
    if (!inputElement) {
      log('setApnNodeEnabled: inputElement is null');
      return;
    }
    enabled = enabled == false ? false : true;
    let textColor = enabled ? 'black' : 'gray';
    try {
      //disabled
      setNodeEnabled(inputElement, enabled);
      //color
      if (inputElement.style) {
        inputElement.style.color = textColor;
      }
      let menuItem = inputElement.closest('[role="menuitem"]');
      let pElement = menuItem && menuItem.getElementsByTagName('p');
      if (Array.isArray(pElement)) {
        pElement = pElement[0];
      }
      log('setApnNodeEnabled: pElement=' + pElement);
      if (pElement && pElement.style) {
        pElement.style.color = textColor;
      }
    } catch (e) {
      log('setApnNodeEnabled: error=' + e);
    };
  }
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-4854,

  //[BUGFIX]Add BEGIN by yelee,GF7TF-4879,2024/02/20
  function bitmaskToRatString(aBitmask) {
    if (aBitmask == 0 || aBitmask === undefined) {
      return "unspecified";
    }
    let rat = "";
    let splitResult = aBitmask.split("|");
    log('bitmaskToRatString: splitResult = '+ splitResult);
    rat = splitResult.map(x => ApnConst.GECKO_RADIO_TECH[x]).join(",").slice(0,-1)
    return rat;
  }

  function bitmaskToString(aBearerBitmask) {
    if (aBearerBitmask == 0 || aBearerBitmask === undefined) {
      return 0;
    }

    let val = "";
    for (let i = 1; i < 20; i++) {
      if ((aBearerBitmask & (1 << (i - 1))) != 0) {
        val = val.concat(i + "|");
      }
    }
    return val;
  }

  function stringToBearer(aNetworkTypes) {
    log('StringToBearer aNetworkTypes = ' + aNetworkTypes);
    if (aNetworkTypes == 0 || aNetworkTypes === undefined) {
      return 0;
    }
    let bitcode = '0';
    let bearerBin = "";
    let bearer = 0;
    let networkTypesArray = aNetworkTypes.split(",");
    bitcode = Array.from(networkTypesArray, aNetworkTypes => ApnConst.NETWORK_TYPE_MAP[aNetworkTypes]);
    bitcode =  bitcode.sort(function(a, b) {
      return a - b;
    });
    log('StringToBearer bitcode = ' + bitcode);
    let bearerArray = new Array(20).fill(0);
    for (let i = 0; i < bitcode.length; i++) {
        bearerArray[bitcode[i]-1] = 1;
        log('StringToBearer bitcode[i] = ' + bitcode[i]);
    }
    log('StringToBearer bearerArray = ' + bearerArray);
    bearerBin = bearerArray.reverse().join("");
    bearer = parseInt(bearerBin,2);
    log('StringToBearer bearer = ' + bearer);
    return bearer;
  }

  function convertNetworkTypeToBearer(aNetworkTypes) {
    log('convertNetworkTypeToBearer aNetworkTypes = ' + aNetworkTypes);
    if (aNetworkTypes == 0 || aNetworkTypes === undefined) {
      return 0;
    }
    let bitcode = '0';
    let bearerBin = "";
    let bearer = 0;
    let networkTypesArray = aNetworkTypes.split(",");
    bitcode = Array.from(networkTypesArray, aNetworkTypes => ApnConst.NETWORK_TYPE_MAP[aNetworkTypes]);  //bitcode array  like [18,14]
    bitcode =  bitcode.sort(function(a, b) {
      return a - b;
    });
    log('convertNetworkTypeToBearer bitcode = ' + bitcode);
    let bearerArray = new Array(20).fill(0);
    for (let i = 0; i < bitcode.length; i++) {
        bearerArray[bitcode[i]-1] = 1;
        log('convertNetworkTypeToBearer: StringToBearer bitcode[i] = ' + bitcode[i]);
    }
    log('convertNetworkTypeToBearer bearerArray = ' + bearerArray);
    bearerBin = bearerArray.reverse().join("");
    bearer = parseInt(bearerBin,2);
    log('convertNetworkTypeToBearer bearer = ' + bearer);
    return bearer;
  }
  //[BUGFIX]Add END by yelee,GF7TF-4879,2024/02/20

  return {
    getOperatorCode,
    apnTypeFilter,
    getDefaultApns,
    getCpApns,
    getEuApns,
    generateId,
    separateApnsByType,
    isMatchedApn,
    sortByCategory,
    clone,
    isMatchedApn_ex,
    isMatchedApnByNameAndType,
    getRecentInstallCpApns,
    clearRecentInstallSettings,
    setSystemProp,
    handleOptions,
    covertProtocol,
    convertAuthType,
    setNodeVisible,
    setNodeEnabled,
    setApnNodeEnabled,
    getResValue,
    getIccInfo,
    isTfSim,
    isVzwCard,
    isUsccCard,
    isSpectrumSim,
    bitmaskToRatString,
    bitmaskToString,
    stringToBearer,
    convertNetworkTypeToBearer,
    findActiveApn,
    //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,11/24/2024,GF5GTMO-5459
    //Optimize apn restore feature
    isNumber,
    getApnsFromItems,
    getApnCategory,
    //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-5459
    updateApnList
  };
});
