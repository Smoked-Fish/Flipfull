/******************************************************************************/
/*                                                               Date:09/2024 */
/*                                PRESENTATION                                */
/*                                                                            */
/*       Copyright 2024 TCL Communication Technology Holdings Limited.        */
/*                                                                            */
/* This material is company confidential, cannot be reproduced in any form    */
/* without the written permission of TCL Communication Technology Holdings    */
/* Limited.                                                                   */
/*                                                                            */
/* -------------------------------------------------------------------------- */
/*  Author :  kaiyun.yan                                                      */
/*  Email  :  kaiyun.yan@tcl.com                                              */
/*  Role   :                                                                  */
/*  Reference documents :                                                     */
/* -------------------------------------------------------------------------- */
/* ========================================================================== */
/*     Modifications on Features list / Changes Request / Problems Report     */
/* -------------------------------------------------------------------------- */
/*    date   |        author        |         Key          |     comment      */
/* ----------|----------------------|----------------------|----------------- */
/* 09/21/2024|      kaiyun.yan      |     GF5GTMO-4307     |For OMACP & OMADM */
/*           |                      |                      |feature           */
/*           |                      |                      |development       */
/* ----------|----------------------|----------------------|----------------- */
/******************************************************************************/
/**
 * The oma utilities
 */
'use strict';
define(function(require) { //eslint-disable-line

  //OMACP FILE
  const OMACP_FILE_PATH = "/otapkg/omacp/omacp.txt";
  const OMACP_FILE_TAG = "omacp_file";
  const FILE_EXIST_STRING = "EXIST";
  const FILE_NO_EXIST_STRING = "NO_EXIST";
  //DM update flag
  const RIL_DATA_OMA_APNUPDATED = "ril.data.oma.apnupdated";
  //CP update flag
  const RIL_CP_APN_UPDATED = "ril.cp.apn.updated";
  //APN_KEY
  const DM_APN_SETTINGS_KEYS = [
    'ril.data.dm.apnSettings.sim1',
    'ril.data.dm.apnSettings.sim2'
  ];
  const RIL_DATA_MMS_APNS = "ril.data.mms.apns";
  //APN_TYPE
  const APN_TYPES = ["default", "emergency", "ims", "mms", "xcap",
      "dun", "hipri", "supl", "mcx", "vsim", "bip", "enterprise", "rcs", "ia", "*"];
  //MCCMNC START
  const MCCMNC_TMO = ['310260', '31026', '31031', '310160', '310200', '310210', '310220', '310230',
       '310240', '310250', '310260', '310490', '310310', '310660', '310800'];
  const MCCMNC_TF = ['310410', '310280', '310260', '310240', '330110', '311480',
  '310590', '310591', '310592', '310593', '310594', '310595', '310596', '310597', '310598', '310599'];
  const GID_TF = ['DEFF', 'DDFF', '534D', '4D4B', 'BA01270000000000'];
  //MCCMNC END

  function log(msg) {
    dump('oma_helper: ' + msg);
  }

  /**
  * ril.data.oma.apnupdated
  * ril.cp.apn.updated
  **/
  function getSetting(key) {
    log('getSetting: key=' + key);
    return new Promise((resolve, reject) => {
      SettingsObserver.getValue(key).then((value)=>{
        log('getSetting: key=' + key + ' value=' + value);
        return resolve(value);
      });
    });
  }

  function setSetting(key, val) {
    let kv = { name: key, value: val };
    let kvs = [];
    kvs.push(kv);
    log('setSetting: key=' + key + ' val=' + val + ' kvs=' + JSON.stringify(kvs));
    return new Promise((resolve, reject) => {
      if (!key) {
        log('setSetting: key is null, return');
        return resolve();
      }
      SettingsObserver.setValue(kvs).then(()=>{
        return resolve();
      });
    });
  }

  function getMvnoInfo(mvno) {
    let mvnoCount = (mvno && Array.isArray(mvno)) ? mvno.length : -1;
    let mvnoInfo = { mvnoType: '', mvnoData: ''};
    if (Array.isArray(mvno)) {
      log('getMvnoInfo: mvno is array: mvno.length=' + mvno.length + ' mvno=' + JSON.stringify(mvno));
      if (mvno.length > 0) {
        for (let i = 0; i < mvnoCount; i++) {
          let mvnoItem = mvno[i];
          if (!mvnoItem) {
              continue;
          }
          let match = (mvnoItem.match && mvnoItem.match == true) ? true : false;
          let type = mvnoItem.mvnoType;
          let data = mvnoItem.mvnoMatchData;
          log('getMvnoInfo match=' + match + ' type=' + type + ' data=' + data);
          if (match == true) {
              mvnoInfo.mvnoType = type;
              mvnoInfo.mvnoData = data;
              break;
          }
        }
      }
    } else if (typeof mvno == 'string') {
      log('getMvnoInfo: mvno is string: mvno=' + mvno);
    }
    if (!mvnoInfo.mvnoType) {
      mvnoInfo.mvnoType = '';
    }
    if (!mvnoInfo.mvnoData) {
      mvnoInfo.mvnoData = '';
    }
    return mvnoInfo;
  }

  function isTfSim(mccmnc, mvnoType, mvnoData) {
      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,12/21/2023,GF7TF-4430,
      mccmnc = mccmnc === undefined ? '' : mccmnc + '';
      mvnoType = mvnoType === undefined ? '' : mvnoType + '';
      mvnoData = mvnoData === undefined ? '' : mvnoData + '';
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-4430,
      const mvnoTypeUpper = mvnoType ? mvnoType.toUpperCase() : '';
      const mvnoDataUpper = mvnoData ? mvnoData.toUpperCase() : '';
      if ('GID' == mvnoTypeUpper && GID_TF.indexOf(mvnoDataUpper) >= 0
              && MCCMNC_TF.indexOf(mccmnc) >= 0) {
          return true;
      }
      return false;
  }

  function mergeApnType(aTypes, bTypes) {
      let aTypesCount = Array.isArray(aTypes) ? aTypes.length : -1;
      let bTypesCount = Array.isArray(bTypes) ? bTypes.length : -1;
      log('mergeApnType: aTypesCount=' + aTypesCount + ' aTypes=' + JSON.stringify(aTypes));
      log('mergeApnType: bTypesCount=' + bTypesCount + ' bTypes=' + JSON.stringify(bTypes));
      if (bTypesCount < 1) {
          return aTypes;
      } else {
          if (aTypesCount < 1) {
              return bTypes;
          }
      }

      let mergedTypes = aTypes;
      for(let i = 0; i < bTypesCount; i++) {
          let bType = bTypes[i];
          if (bType === undefined) {
              continue;
          }
          let index = aTypes.indexOf(bType);
          //contains bType, skip
          if (index >= 0) {
              continue;
          }
          //else add bType
          mergedTypes.push(bType);
      }

      log('mergeApnType: END: mergedTypes=' + JSON.stringify(mergedTypes));
      return mergedTypes;
  }

  function mergeApn(aApn, bApn) {
      log('mergeApn: aApn=' + JSON.stringify(aApn));
      log('mergeApn: bApn=' + JSON.stringify(bApn));
      if (bApn === undefined) {
          return aApn;
      } else {
          if (aApn === undefined) {
              return bApn;
          }
      }
      let bApnKeys = Object.keys(bApn);
      let bApnKeysCount = Array.isArray(bApnKeys) ? bApnKeys.length : -1;
      log('mergeApn: bApnKeysCount=' + bApnKeysCount);
      if (bApnKeysCount < 1) {
          return aApn;
      }

      let mergedApn = aApn;
      for(let i = 0; i < bApnKeysCount; i++) {
          let key = bApnKeys[i];
          let aVal;
          let bVal;
          //[BUGFIX]-Mod-BEGIN by GCCSZ.kaiyun.yan,01/12/2024,GF7OM-851
          let ret;
          if (key !== undefined && key != '') {
              aVal = aApn[key];
              bVal = bApn[key];

              if (bVal !== undefined) {
                  if ('types' == key) {
                      ret = mergeApnType(aApn.types, bApn.types);
                  } else if ('user_visible' == key) {
                      if ((aVal + '') == 'true' || (bVal + '') == 'true') {
                          ret = true;
                      } else {
                          ret = bApn[key];
                      }
                  } else {
                      ret = bApn[key];
                  }
                  mergedApn[key] = ret;
              }
          }
          log('mergeApn::: index=' + i + ' key=' + key + ' aVal=' + aVal + ' bVal=' + bVal + ' ret=' + ret);
          //[BUGFIX]-Mod-END by GCCSZ.kaiyun.yan,GF7OM-851
      }
      log('mergeApn: END: mergedApn=' + JSON.stringify(mergedApn));
      return mergedApn;
  }

  function mergeCpApn(defaultApns, cpApns, mccmnc, mvno) {

      let defaultApnsCount = Array.isArray(defaultApns) ? defaultApns.length : -1;
      let cpApnsCount = Array.isArray(cpApns) ? cpApns.length : -1;
      let mvnoInfo = getMvnoInfo(mvno);
      let mvnoType = '';
      let mvnoData = '';
      //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,11/11/2024,GF5GTMO-4541,
      //Remove the judgment of whether it is an array, as the input mvnoInfo may not be an array
      if (mvnoInfo) {
          mvnoType = mvnoInfo.mvnoType;
          mvnoData = mvnoInfo.mvnoData;
          //[BUGFIX]-Add-BEGIN by GCSSZ.fen-li,02/21/2024,GF7TF-4851
          mvnoData = mvnoData && (mvnoData + '').toUpperCase();
          //[BUGFIX]-Add-END by GCSSZ.fen-li,GF7TF-4851
      }
      let bIsTfSim = isTfSim(mccmnc, mvnoType, mvnoData);
      log('mergeCpApn: START: mccmnc=' + mccmnc + ' mvnoType=' + mvnoType + ' mvnoData=' + mvnoData
              + ' mvnoInfo=' + JSON.stringify(mvnoInfo)
              + ' bIsTfSim=' + bIsTfSim + ' defaultApnsCount=' + defaultApnsCount
              + ' cpApnsCount=' + cpApnsCount);

      if (cpApnsCount < 1) {
          return defaultApns;
      }

      if (defaultApnsCount < 1) {
          if (cpApnsCount > 0) {
              return cpApns;
          } else {
              return defaultApns;
          }
      }

      log('mergeCpApn: defaultApns=' + JSON.stringify(defaultApns));
      log('mergeCpApn: cpApns=' + JSON.stringify(cpApns));

      const APN_TYPES = ['default', 'mms', 'supl'];
      const BEARER_WLAN_ONLY = 131072;

      let mergedApns = defaultApns;
      for(let i = 0; i < cpApnsCount; i++) {
          let cpApn = cpApns[i];
          if (cpApn === undefined) {
              continue;
          }
          //[BUGFIX]-Add-BEGIN by GCSSZ.fen-li,02/21/2024,GF7TF-4851
          let cpMvNoData = cpApn.mvno_match_data && (cpApn.mvno_match_data + '').toUpperCase();
          log('mergeCpApn: cpMvNoData=' + cpMvNoData + ", mvnoData : " + mvnoData);
          if ((mvnoData && cpMvNoData && mvnoData !== cpMvNoData) || (mvnoData && !cpMvNoData) || (!mvnoData && cpMvNoData)) {
              log('mergeCpApn: cpMvNoData and mvnoData not the same , return');
              continue;
          }
          //[BUGFIX]-Add-END by GCSSZ.fen-li,02/21/2024,GF7TF-4851

          let cpCarrier = cpApn.carrier;
          let cpTypes = cpApn.types;
          if (Array.isArray(cpTypes) != true) {
              cpTypes = [];
          }
          let cpTypesCount = Array.isArray(cpTypes) ? cpTypes.length : 0;
          let cpBearer = cpApn.bearer;

          log('mergeCpApn: index=' + i + ' cpCarrier=' + cpCarrier
                  + ' cpTypes=' + JSON.stringify(cpTypes) + ' cpTypesCount=' + cpTypesCount
                  + ' cpBearer=' + cpBearer);

          //Filter APN
          let mergedApnsCount = Array.isArray(mergedApns) ? mergedApns.length : -1;
          let filteredApn;
          if (mergedApnsCount > 0) {
              for (const defApn of mergedApns) {
                  if (defApn === undefined) {
                      continue;
                  }

                  let defCarrier = defApn.carrier;
                  let defTypes = defApn.types;
                  if (Array.isArray(defTypes) != true) {
                      defTypes = [];
                  }
                  let defBearer = defApn.bearer;

                  log('mergeCpApn: index=' + i + ' filterApn: defCarrier=' + defCarrier
                          + ' defTypes=' + JSON.stringify(defTypes));

                  if (defCarrier === undefined || defCarrier != cpCarrier) {
                      continue;
                  }

                  let matchedApn;
                  for(const apnType of APN_TYPES) {
                      log('mergeCpApn: index=' + i + ' filterApn: apnType=' + apnType + ' cpBearer=' + cpBearer
                              + ' defBearer=' + defBearer);
                      if (apnType === undefined || apnType == '') {
                          continue;
                      }
                      if (cpBearer != BEARER_WLAN_ONLY && defBearer == BEARER_WLAN_ONLY) {
                          continue;
                      }
                      if (cpTypes.indexOf(apnType) >= 0 && defTypes.indexOf(apnType) >= 0) {
                          matchedApn = defApn;
                          break;
                      }
                  }
                  //If matched apn, break
                  if(matchedApn !== undefined) {
                      log('mergeCpApn: index=' + i + ' filterApn: matchedApn=' + JSON.stringify(matchedApn));
                      filteredApn = matchedApn;
                      break;
                  }

                  log('mergeCpApn: index=' + i + ' filterApn: matchedApn is undefined');
                  let fTypes = [];
                  if (filteredApn !== undefined && Array.isArray(filteredApn.types)) {
                      fTypes = filteredApn.types;
                  }
                  if (fTypes.indexOf('default') < 0) {
                      filteredApn = defApn;
                  } else {
                      log('mergeCpApn: index=' + i + ' filterApn: filteredApn=' + JSON.stringify(filteredApn));
                  }
              }
          }

          log('mergeCpApn: index=' + i + ' mergedApnsCount=' + mergedApnsCount
                  + ' filteredApn=' + JSON.stringify(filteredApn));

          if (filteredApn !== undefined) {
              let filteredTypes = filteredApn.types;
              if (Array.isArray(filteredTypes) != true) {
                  filteredTypes = [];
              }

              if ((cpTypes.indexOf('default') >= 0
                      || cpTypes.indexOf('supl') >= 0)
                      && (filteredTypes.indexOf("mms") >= 0
                      || filteredTypes.indexOf("default") >= 0
                      || filteredTypes.indexOf("supl") >= 0)) {
                  //Use preset mmsc
                  if (filteredApn.mmsc !== undefined && filteredApn.mmsc != '') {
                      cpApn.mmsc = filteredApn.mmsc;
                  }
                  //Use preset mmsproxy
                  if (filteredApn.mmsproxy !== undefined && filteredApn.mmsproxy != '') {
                      cpApn.mmsproxy = filteredApn.mmsproxy;
                  }
                  //Use preset mmsport
                  if (filteredApn.mmsport !== undefined && filteredApn.mmsport != '') {
                      cpApn.mmsport = filteredApn.mmsport;
                  }
              } else if ((cpTypes.indexOf('mms') >= 0)
                      && (filteredTypes.indexOf("mms") >= 0
                      || filteredTypes.indexOf("default") >= 0
                      || filteredTypes.indexOf("supl") >= 0)) {
                  //Do nothing
              }
              //For TF REQ START
              if (bIsTfSim == true) {
                  log('mergeCpApn: index=' + i + ' mergeApn: TF REQ:'
                          + ' protocol=' + cpApn.protocol + '->' + filteredApn.protocol
                          + ' roaming_protocol=' + cpApn.roaming_protocol + '->' + filteredApn.roaming_protocol
                          + ' bearer=' + cpApn.bearer + '->' + filteredApn.bearer);
                  //TF REQ: Use preset instead of OMACP
                  cpApn.protocol = filteredApn.protocol;
                  cpApn.roaming_protocol = filteredApn.roaming_protocol;
                  if (filteredApn.bearer != BEARER_WLAN_ONLY) {
                      cpApn.bearer = filteredApn.bearer;
                  }
              }
              //For TF REQ END

              //Add mergedApn
              filteredApn = mergeApn(filteredApn, cpApn);
          } else {
              //For TF REQ START
              if (bIsTfSim == true && mergedApnsCount > 0) {
                  let matchedApn;
                  for(const defApn of mergedApns) {
                      if (defApn === undefined) {
                          continue;
                      }

                      if (cpBearer != BEARER_WLAN_ONLY && defApn.bearer == BEARER_WLAN_ONLY) {
                          log('mergeCpApn: index=' + i + ' addApn: TF REQ: ignore wlan bearer apn');
                          continue;
                      }
                      //Get Member
                      let defTypes = defApn.types;
                      if (Array.isArray(defTypes) != true) {
                          defTypes = [];
                      }
                      //Loop cpTypes
                      if (cpTypesCount > 0) {
                          for (const cpType of cpTypes) {
                              if (cpType === undefined || cpType == '') {
                                  continue;
                              }
                              //If defTypes does not contains cpType, continue
                              if (defTypes.indexOf(cpType) < 0) {
                                  continue;
                              }
                              matchedApn = defApn;
                              break;
                          }
                      }
                      log('mergeCpApn: index=' + i + ' addApn: TF REQ: matchedApn=' + matchedApn);
                      if (matchedApn !== undefined) {
                          log('mergeCpApn: index=' + i + ' addApn: TF REQ:'
                                  + ' protocol=' + cpApn.protocol + '->' + defApn.protocol
                                  + ' roaming_protocol=' + cpApn.roaming_protocol + '->' + defApn.roaming_protocol
                                  + ' bearer=' + cpApn.bearer + '->' + defApn.bearer
                                  + ' matchedApn=' + JSON.stringify(matchedApn));
                          //TF REQ: Use preset instead of OMACP
                          cpApn.protocol = matchedApn.protocol;
                          cpApn.roaming_protocol = matchedApn.roaming_protocol;
                          cpApn.bearer = matchedApn.bearer;
                          break;
                      }
                  }
              }
              //For TF REQ END

              //Add cpApn
              mergedApns.push(cpApn);
          }
          log('mergeCpApn: index=' + i + ' filteredApn=' + JSON.stringify(filteredApn));
      }

      let mergedApnsCount = Array.isArray(mergedApns) ? mergedApns.length : -1;
      log('mergeCpApn: END: mergedApnsCount=' + mergedApnsCount
              + ' mergedApns=' + JSON.stringify(mergedApns));
      return mergedApns;
  }

  function getCompatible(list, mcc, mnc) {
    const apns = list[mcc] ? list[mcc][mnc] || [] : [];
    return apns;
  }

  function getCompatibleWithMvnoData(list, mcc, mnc, mvnoData) {
    log('getCompatibleWithMvnoData: mccmnc=' + mcc + mnc + ' mvnoData=' + mvnoData);
    log('getCompatibleWithMvnoData: typeof mvnoData=' + (typeof mvnoData));
    if (!mvnoData || (typeof mvnoData == 'string' && mvnoData.toLowerCase().indexOf('ff') == 0)) {
      mvnoData = '';
    }

    if (!list) {
      log('getCompatibleWithMvnoData: list is null, return');
      return [];
    }

    var apns;
    if (list[mcc]) {
      apns = list[mcc][mnc] ? (list[mcc][mnc][mvnoData.toLowerCase()] || []) : [];
    } else {
      apns = [];
    }
    return apns;
  }

  function isFileExist(filePath) {
    log('isFileExist: filePath=' + filePath);

    return new Promise((resolve, reject) => {
      let exist = false;
      if (!filePath) {
        return resolve(exist);
      }
      navigator.b2g.engmodeManager.checkIsFileExist(filePath).then((result) => {
        if (result == FILE_EXIST_STRING) {
          exist = true;
        }
        log('isFileExist: result=' + result + ' exist=' + exist);
        return resolve(exist);
      });
    });
  }

  function createCpFile() {
    log('createCpFile: START');
    return new Promise((resolve, reject) => {
      navigator.b2g.engmodeManager.addOmacp('FILE').then(() => {
        log('createCpFile:');
        return resolve();
      });
    });
  }

  function readFile(fileTag) {
    log('readFile: fileTag=' + fileTag);
    return new Promise((resolve, reject) => {
      let ret;

      //FOR DEBUG START
      if (fileTag == OMACP_FILE_TAG) {
        //let cpApnString = '[{"460":{"11":{"":[{"NAPID":"test222_NAPID","carrier":"TEST","apn":"test222","authtype":"1","user":"222","password":"12345","protocol":"IP","roaming_protocol":"IP","types":["default"],"itemId":"70b18186-f733-48b3-b905-98d747078c27"},{"NAPID":"test222_NAPID","carrier":"TEST_supl","apn":"test222","apnFormat":"APN","authtype":"1","user":"222","password":"12345","protocol":"IP","roaming_protocol":"IP","types":["supl"],"itemId":"dee9c74c-bf2a-4573-9f7e-d495386ee9c3"}]}}}]';
        let cpApnString = '';
        //ret = JSON.parse(cpApnString);
        ret = cpApnString;
        log('readFile: ret=' + JSON.stringify(ret));
      }
      //FOR DEBUG END

      navigator.b2g.engmodeManager.fileReadLE(fileTag).then((result) => {
        log('readFile: result=' + JSON.stringify(result));
        ret = result;
        return resolve(ret);
      }).catch(error => {
        log('readFile: error=' + JSON.stringify(error));
        return resolve(ret);
      });
    });
  }

  function readCpApns() {
    log('readCpApns: OMACP_FILE_PATH=' + OMACP_FILE_PATH + ' OMACP_FILE_TAG=' + OMACP_FILE_TAG);
    return new Promise((resolve, reject) => {
      isFileExist(OMACP_FILE_PATH).then((exist) => {
        log('readCpApns: exist=' + exist);
        /**
        if (exist == false) {
          resolve([]);
        } else {
          readFile(OMACP_FILE_TAG).then((existingApns) => {
              log('readCpApns: existingApns=' + JSON.stringify(existingApns));
              resolve(existingApns);
          });
        }
        **/
        readFile(OMACP_FILE_TAG).then((existingApns) => {
            log('readCpApns: existingApns=' + JSON.stringify(existingApns));
            resolve(existingApns);
        });
      });
    });
  }

  function getCpApns(mcc, mnc, mvno) {
    log('getCpApns: mccmnc=' + mcc + mnc + ' mvno=' + mvno);
    return new Promise((resolve, reject) => {
      if (!mcc || !mnc) {
        log('getCpApns: mccmnc is null, return');
        resolve({});
      }
      let cpApnList = {};
      readCpApns().then(existingApns => {
        log('getCpApns: existingApns=' + JSON.stringify(existingApns));
        if (existingApns != undefined && existingApns != '' && existingApns) {
          let apns = JSON.parse(existingApns);
          cpApnList = apns[0];
          log('getCpApns: cpApnList=' + JSON.stringify(cpApnList));
        }

        let cpApnData = getCompatible(cpApnList, mcc, mnc);
        let keys = Object.keys(cpApnData);
        let cpApns;
        let keysCount = keys ? keys.length : -1;
        log('getCpApns: keysCount=' + keysCount + ' keys=' + JSON.stringify(keys));

        let mvnoInfo = getMvnoInfo(mvno);
        let mvnoData = mvnoInfo && mvnoInfo.mvnoData;
        log('getCpApns: mvnoData=' + mvnoData);
        if (!mvnoData || (typeof mvnoData == 'string' && mvnoData.toLowerCase().indexOf('ff') == 0)) {
          log('getCpApns: change mvnoData to ""');
          mvnoData = '';
        }
        let keyIndex = keys.indexOf(mvnoData);
        if (keyIndex >= 0) {
            cpApns = cpApnData[mvnoData]
        }

        //getCpApns by first key
        if (cpApns === undefined) {
            if (keysCount < 1) {
                log('getCpApns: keysCount < 1, set cpApns to []');
                cpApns = [];
            } else if (keysCount == 1 && mvnoData === undefined) {//[BUGFIX]-Mod by GCSSZ.fen-li,02/21/2024,GF7TF-4851
                let key = keys[0];
                cpApns = cpApnData[key];
                log('getCpApns: key=' + key);
            }
        }

        log('getCpApns: keyIndex=' + keyIndex + ' cpApns=' + JSON.stringify(cpApns));
        return resolve(cpApns);
      });
    });
  }

  return {
    get RIL_DATA_OMA_APNUPDATED() {
      return RIL_DATA_OMA_APNUPDATED;
    },
    get RIL_CP_APN_UPDATED() {
      return RIL_CP_APN_UPDATED;
    },
    getSetting,
    setSetting,
    isFileExist,
    readFile,
    readCpApns,
    createCpFile,
    getCpApns,
    isTfSim,
    mergeApnType,
    mergeApn,
    mergeCpApn
  };
});
