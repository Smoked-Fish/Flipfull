/* global AccountHelper SimCardHelper */
'use strict';
define(function (require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createAboutPanel() {
    let elements = {};
    let eSIMVerMode = false;
    const OPTIONAL_PROFILES = 2;
    const LOW_BATTERY_LEVEL = 0.3; //Task10115967-bin.shen@tcl.com
    const ANTI_THEFT_KEY = 'antitheft.enabled';
    const link = 'https://support.kaiostech.com/en/support/tickets/new';

    function checkFactoryReset() {
      if (ApiManager.battery && ApiManager.battery.level < LOW_BATTERY_LEVEL) {
        const dialogConfig = {
          title: {},
          body: { id: 'battery-warning-body', args: {} },
          accept: {
            name: 'Ok',
            l10nId: 'ok',
            priority: 2,
            callback() {
              DebugHelper.debug('battery is low');
            }
          }
        };
        DialogHelper.show(dialogConfig);
      } else {
        checkScreenLock();
      }
    }

    function checkScreenLock() {
      SettingsDBCache.getSetting('lockscreen.passcode-lock.enabled').then(
        enabled => {
          if (enabled) {
            Settings.setCurrentPanel('#screen_lock_passcode', {
              mode: 'confirm',
              origin: '#about'
            });
          } else {
            Settings.setCurrentPanel('#reset_phone_progress');
          }
        }
      );
    }

    function renderPhoneNumberElement(iccInfo, index, isMultiSim) {
      const span = document.createElement('span');
      let msisdn = null;

      if (iccInfo) {
        msisdn = iccInfo.msisdn || iccInfo.mdn;
      }

      if (msisdn) {
        if (isMultiSim) {
          l10n.setAttributes(span, 'deviceInfo-MSISDN-with-index', {
            index: index + 1,
            msisdn
          });
        } else {
          span.textContent = msisdn;
        }
      } else if (iccInfo && iccInfo.iccid) {
        if (isMultiSim) {
          l10n.setAttributes(span, 'unknown-phoneNumber-sim', {
            index: index + 1
          });
        } else {
          span.setAttribute('data-l10n-id', 'unknown-phoneNumber');
        }
      } else if (isMultiSim) {
        l10n.setAttributes(span, 'noSim-with-index-and-colon', {
          index: index + 1
        });
      } else {
        span.setAttribute('data-l10n-id', 'noSimCard');
      }
      return span;
    }

    function loadHardwareInfo() {
      if (!SimCardHelper.hasValidCard()) {
        elements.deviceInfoPhoneNum.classList.add('hidden');
        return;
      }
      const conns = ApiManager.connections;

      const isMultiSim = conns.length > 1;
      // Only show the list item when there are valid iccinfos.
      let hideListItem = true;

      // Update msisdns
      while (elements.deviceInfoMsisdns.hasChildNodes()) {
        elements.deviceInfoMsisdns.removeChild(
          elements.deviceInfoMsisdns.lastChild
        );
      }

      Array.prototype.forEach.call(conns, (conn, index) => {
        const { iccId } = conn;
        let iccObj = null;
        let iccInfo = null;

        if (!iccId && !isMultiSim) {
          return;
        }

        if (iccId) {
          iccObj = ApiManager.iccManager.getIccById(iccId);
        }

        if (iccObj) {
          iccInfo = iccObj.iccInfo; //eslint-disable-line
        }

        hideListItem = false;
        const span = renderPhoneNumberElement(iccInfo, index, isMultiSim);
        elements.deviceInfoMsisdns.appendChild(span);
      });

      elements.deviceInfoPhoneNum.classList.toggle('hidden', hideListItem);
    }

    function signOutAndReset() {
      // It should add code to sign out kaios account.
      if (AccountHelper.kaiAccountLogin) {
        SettingsDBCache.getSetting(ANTI_THEFT_KEY).then(value => {
          if (!value) {
            checkFactoryReset();
          } else {
            ActivityHelper.start({
              name: 'account-manager',
              data: {
                authenticatorId: 'kaiaccount',
                action: 'showOtherPage',
                publicKey: AccountHelper.publicKey,
                flow: 'checkPassword',
                args: [AccountHelper.kaiAccountInfo.userData, 'resetfactory']
              }
            }).then(
              response => {
                AccountHelper.decryptKey(response).then(result => {
                  if (result && result.result === 'success') {
                    checkFactoryReset();
                  } else {
                    DebugHelper.debug(
                      `disableAntitheft result:${JSON.stringify(result)}`
                    );
                  }
                });
              },
              err => {
                DebugHelper.log(
                  `disableAntitheft error:${JSON.stringify(err)}`
                );
              }
            );
          }
        });
      } else {
        checkFactoryReset();
      }
    }

    function showRestDialog(evt) {
      if (evt.key === 'Enter') {
        let text = '';
        let callback = null;
        switch (evt.target.id) {
          case 'reset-phone':
            if (
              evt.target.querySelector('button').textContent ===
              l10n.get('reset-device')
            ) {
              text = l10n.get('reset-warning-body-1');
            } else {
              text = [
                l10n.get('reset-warning-body-1'),
                l10n.get('reset-warning-body-2')
              ].join('\n');
            }
            callback = signOutAndReset;
            break;
          case 'reset-esims':
            if (eSIMVerMode) {
              elements.reseteSIMsSelect.focus();
              return;
            }
            text = l10n.get('esim-reset-warning');
            callback = () => {
              deleteeSIMs(OPTIONAL_PROFILES, () => {
                ToastHelper.showToast('esim-reset');
              });
            };
            break;
          case 'reset-entire-phone':
            text = [
              l10n.get('reset-warning-body-1'),
              l10n.get('reset-warning-body-4')
            ].join('\n');
            callback = () => {
              deleteeSIMs(OPTIONAL_PROFILES, signOutAndReset);
            };
            break;
          default:
            return;
        }
        const dialogConfig = {
          title: { id: 'reset-warning-title', args: {} },
          body: { text },
          cancel: {
            name: 'Cancel',
            l10nId: 'cancel',
            priority: 1,
            callback() {
              DebugHelper.debug('Reset cancel');
            }
          },
          confirm: {
            name: 'Reset',
            l10nId: 'reset',
            priority: 3,
            callback
          }
        };
        DialogHelper.show(dialogConfig);
      }
    }

    function deleteeSIMs(mode, callback) {
      if (!window.IsOnline()) {
        ToastHelper.showToast('remove-error');
      } else if (ApiManager.eUiccManager) {
        ApiManager.eUiccManager.resetMemory(mode).then(
          () => {
            if (typeof callback === 'function') {
              callback();
            }
          },
          error => {
            DebugHelper.debug(`deleteeSIMs error:${error}`);
            /*
             * ResetMemory will return error even when there is no profile,
             * so we should handle it as success
             */
            if (typeof callback === 'function') {
              callback();
            }
          }
        );
      }
    }

    function updateAboutLegalInfoItem(enabled) {
      elements.aboutLegalInfoItem.classList.toggle('hidden', !enabled);
      window.dispatchEvent(new CustomEvent('refresh'));
    }

    function fotaKeydownHandler(evt) {
      if (evt.key === 'Enter') {
        ActivityHelper.start({
          name: 'launch-fota',
          data: { param: 'startFromSettings' }
        });
      }
    }

    function checkCustomerSupport() {
      SettingsDBCache.getSettings(
        ['customer.support.enabled', 'language.current'],
        results => {
          const customerSupport = results['customer.support.enabled'];
          const currentLanguage = results['language.current'];
          if (
            customerSupport &&
            currentLanguage.startsWith('en-') &&
            AccountHelper.kaiAccountLogin
          ) {
            elements.customerSupport.classList.remove('hidden');
          } else {
            elements.customerSupport.classList.add('hidden');
          }
          window.dispatchEvent(new CustomEvent('refresh'));
        }
      );
    }

    function keyDownHandler(evt) {
      switch (evt.key) {
        case 'Enter':
          window.open(link, '', 'dialog');
          break;
        default:
          break;
      }
    }

    function selectMode() {
      const mode = parseInt(elements.reseteSIMsSelect.value, 10);
      if (!mode) {
        return;
      }
      deleteeSIMs(mode, () => {
        ToastHelper.showToast('esim-reset');
      });
    }

    //Defect10627195-bin.shen@tcl.com-begin
    function loadBuildNum() {
      var info = '';
      /*if (navigator.b2g.engmodeManager) {
        Promise.all([
          navigator.b2g.engmodeManager.getPropertyValue('ro.vendor.tct.ver.system'),
          navigator.b2g.engmodeManager.getPropertyValue('ro.vendor.tct.ver.vendor')]).then((value) => {
            let mainSoftware = value[0].substr(1, 3) + value[0].substr(6, 1);
            let perso = value[0].substr(4, 4);
            let vendor_perso = value[1].substr(4, 4);
            if (perso !== vendor_perso) {
              if(window.operatorName == 'TMO'){
                info = mainSoftware + perso;
              } else {
                info = mainSoftware;
              }
            } else {
              let daily_number = value[0].substr(7, 1);
              info = mainSoftware + '-' + daily_number;
            }
            elements.buildNumber.querySelector('small').textContent = info;
          }, (err) => {
            dump('settings, get software error');
          });
      }*/
      var value = [];
      let Dmy;
      let Model;
      if (window.remoteHelper) {
        window.remoteHelper.getproperty('ro.vendor.tct.ver.system', (response) => {
          dump('settings  ro.vendor.tct.ver.system=' + response);
          value[0] = JSON.parse(response).value;
          window.remoteHelper.getproperty('ro.tct.ver.system', (response) => {
            dump('settings  ro.tct.ver.system=' + response);
            value[1] = JSON.parse(response).value;
            window.remoteHelper.getproperty('ro.tct.ver.product', (response) => {
              value[2] = JSON.parse(response).value;
              dump('settings  ro.tct.ver.product=' + response);
              navigator.b2g.engmodeManager.getPropertyValue('ro.product.model').then(svlaue => {
                Model = svlaue;
                if (Model == 'T435D') {
                  navigator.b2g.engmodeManager.getPropertyValue('ro.product.tcl.dumysuffix').then(isvlaue => {
                  Dmy = isvlaue;
                  value[3] = Dmy;
                  if (value.length === 4) {
                    let mainSoftware = value[0].substr(1, 3) + value[0].substr(6, 1);
                    let perso = value[1].substr(4, 4);
                    let vendor_perso = value[2].substr(4, 4);
                    if (perso !== vendor_perso) {
                        info = mainSoftware + Dmy;
                    } else {
                      let daily_number = value[0].substr(7, 1);
                      info = mainSoftware + '-' + daily_number +Dmy;
                    }
                  } else {
                    dump('settings, get software error');
                  }
                  elements.buildNumber.querySelector('small').textContent = info;
                });
              }else {
                if (value.length === 3) {
                let mainSoftware = value[0].substr(1, 3) + value[0].substr(6, 1);
                let perso = value[1].substr(4, 4);
                let vendor_perso = value[2].substr(4, 4);
                if (perso !== vendor_perso) {
                    info = mainSoftware + perso;
                } else {
                  let daily_number = value[0].substr(7, 1);
                  info = mainSoftware + '-' + daily_number;
                }
              } else {
                 dump('settings, get software error');
              }
              elements.buildNumber.querySelector('small').textContent = info;
              }
              });
              });
          });
        });
      }
    }
    //Defect10627195-bin.shen@tcl.com-end

    return SettingsPanel({
      onInit(panel) {
        elements = {
          items: panel.querySelectorAll('li'),
          resetButton: panel.querySelector('.reset-phone'),
          reseteSIMsButton: panel.querySelector('.reset-esims'),
          reseteSIMsSelect: panel.querySelector('.reset-esims select'),
          resetEntireButton: panel.querySelector('.reset-entire-phone'),
          osVersion: panel.querySelector('#os-version'),
          buildNumber: panel.querySelector('#build_number'), // Task10114420-tfzhang@tcl.com-add
          aboutLegalInfoItem: panel.querySelector('.about-legal-info'),
          customerSupport: panel.querySelector('.customer-support'),
          deviceInfoPhoneNum: panel.querySelector('.deviceinfo-phone-num'),
          hardwareVersion: panel.querySelector('#hardware-version'),
          deviceInfoMsisdns: panel.querySelector('.deviceInfo-msisdns'),
          /*fotaSettings: panel.querySelector('#fota-settings')*/
        };
        /*window.api.session.has_service('Fota').then(
          value => {
            DebugHelper.log(`Fota Service:${value}`);
            if (value) {
              elements.fotaSettings.classList.remove('hidden');
            } else {
              elements.fotaSettings.classList.add('hidden');
            }
          },
          err => {
            elements.fotaSettings.classList.add('hidden');
            DebugHelper.log(`Can not got service of fota:${err}`);
          }
        );*/
        if (window.hasESIM) {
          elements.reseteSIMsButton.classList.remove('hidden');
          elements.resetEntireButton.classList.remove('hidden');
          elements.resetButton.querySelector('button').textContent = l10n.get(
            'reset-device-data'
          );
          SettingsDBCache.getSetting('esim.test.mode.enabled').then(value => {
            eSIMVerMode = !!value;
            elements.reseteSIMsSelect.classList.toggle('hidden', !eSIMVerMode);
          });
        }
      },

      onBeforeShow(panel, options) {
        loadHardwareInfo();
        if (options.origin === '#screen_lock_passcode') {
          SettingsDBCache.getSetting('lockscreen.passcode-lock.enabled').then(
            enabled => {
              if (!enabled) {
                Settings.setCurrentPanel('#reset_phone_progress');
              }
            }
          );
        }
        SettingsDBCache.getSetting('deviceinfo.software').then(value => {
          if (value === '') {
            elements.osVersion.classList.add('hidden');
          } else {
            elements.osVersion.classList.remove('hidden');
            elements.osVersion.querySelector('small').textContent = value;
          }
        });
        loadBuildNum();//Defect10627195-bin.shen@tcl.com
		
        navigator.b2g.engmodeManager.getPropertyValue('ro.tct.trace.pth').then(value => {
            elements.hardwareVersion.querySelector('small').textContent = value;
        });
		
        checkCustomerSupport();
        SettingsSoftkey.init(SoftParams.defaultSelect);
        ListFocusHelper.updateSoftkey(panel);
        SettingsDBCache.observe(
          'about.legal.info.enabled',
          true,
          updateAboutLegalInfoItem
        );
        ListFocusHelper.addEventListener(elements.items);
        elements.resetButton.addEventListener('keydown', showRestDialog);
        elements.resetEntireButton.addEventListener('keydown', showRestDialog);
        elements.reseteSIMsButton.addEventListener('keydown', showRestDialog);
        /*elements.fotaSettings.addEventListener('keydown', fotaKeydownHandler);*/
        elements.customerSupport.addEventListener('keydown', keyDownHandler);
        elements.reseteSIMsSelect.addEventListener('change', selectMode);
      },

      onBeforeHide() {
        SettingsDBCache.unobserve(
          'about.legal.info.enabled',
          updateAboutLegalInfoItem
        );
        ListFocusHelper.removeEventListener(elements.items);
        elements.resetButton.removeEventListener('keydown', showRestDialog);
        elements.reseteSIMsButton.removeEventListener(
          'keydown',
          showRestDialog
        );
        elements.resetEntireButton.removeEventListener(
          'keydown',
          showRestDialog
        );
        /*elements.fotaSettings.removeEventListener(
          'keydown',
          fotaKeydownHandler
        );*/
        elements.customerSupport.removeEventListener('keydown', keyDownHandler);
      }
    });
  };
});
