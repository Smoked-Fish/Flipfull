'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createAboutKaiosPanel() {
    return SettingsPanel({
      onInit(panel) {
        SettingsDBCache.getSetting('allow.kids.mode').then(value => {
          panel.querySelector('#about-age').classList.toggle('hidden', !!value);
          window.dispatchEvent(new CustomEvent('refresh'));
        });
      },
      onBeforeShow: function onBeforeShow() {
        SettingsSoftkey.init(SoftParams.defaultSelect);
        SettingsSoftkey.show();
        Customization.initUIBySettings(['debug.performance_data.settings.ui']);
        Customization.addListener(['debug.performance_data.settings.ui']);
      },
      onBeforeHide: function onBeforeHide() {
        SettingsSoftkey.hide();
        Customization.removeListener(['debug.performance_data.settings.ui']);
      }
    });
  };
});
