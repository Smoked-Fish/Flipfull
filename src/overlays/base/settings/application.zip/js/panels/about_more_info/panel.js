/* global DeviceInfo, HardwareInfo, dump */

/* eslint no-unused-vars: "off" */
'use strict';
define(function (require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  require('panels/about_more_info/device_info');
  require('panels/about_more_info/hardware_info');

  const SOFTWARE_TAG = 'deviceinfo.software_tag';
  const FIRMWARE_REVISION = 'deviceinfo.firmware_revision';
  const BASE_VERSION = 'deviceinfo.base_version';
  let keyArray = [];
  let elements = null;

  function keyDwnHandler(evt) {
    switch (evt.key) {
      case 'SoftLeft':
      case 'SoftRight':
        keyArray.push(evt.key);
        checkDeveloperMode();
        break;
      default:
        cleanKeyArray();
        break;
    }
  }

  function checkDeveloperMode() {
    const string = keyArray.join(' ');
    if (
      string.indexOf(
        'SoftLeft SoftLeft SoftRight SoftLeft SoftRight SoftRight'
      ) > -1
    ) {
      cleanKeyArray();
      SettingsDBCache.getSetting('developer.menu.enabled').then(value => {
        SettingsDBCache.saveSettings({ 'developer.menu.enabled': !value });
        if (!value) {
          dump('settings: set debugger.remote-mode as adb-devtools');
          SettingsDBCache.saveSettings({
            'debugger.remote-mode': 'adb-devtools'
          });
          ToastHelper.showToast('developer-mode-on');
        } else {
          SettingsDBCache.saveSettings({
            'debugger.remote-mode': 'disabled'
          });
          ToastHelper.showToast('developer-mode-off');
        }
      });
    }
  }

  function cleanKeyArray() {
    keyArray = [];
  }

  function updateSmallItem(element, value) {
    if (value === '') {
      element.classList.add('hidden');
    } else {
      element.querySelector('small').textContent = value;
    }
  }

  return function createAboutMoreInfoPanel() {
    const hardwareInfo = new HardwareInfo();
    const deviceInfo = new DeviceInfo();

    return SettingsPanel({
      onInit(panel) {
        deviceInfo.init({
          listImeis: panel.querySelector('.list-imeis'),
          listMeids: panel.querySelector('.list-meids'),
          listIccIds: panel.querySelector('.list-iccids'),
          deviceInfoEid: panel.querySelector('.deviceInfo-eid'),
          deviceInfoImeis: panel.querySelector('.deviceInfo-imeis'),
          deviceInfoMeids: panel.querySelector('.deviceInfo-meids'),
          deviceInfoIccIds: panel.querySelector('.deviceInfo-iccids')
        });
        hardwareInfo.init({
          deviceInfoMac: panel.querySelector('[data-name="deviceinfo.mac"]'),
          fields: panel.querySelectorAll('[data-name="deviceinfo.bt_address"]')
        });
        elements = {
          osVersion: panel.querySelector('#os-version-li'),
          softTag: panel.querySelector('#soft-tag-li'),
          firmwareRevision: panel.querySelector('#firmware-revision-li'),
          baseVersion: panel.querySelector('#base-version-li')
        };
      },

      onBeforeShow() {
        SettingsSoftkey.hide();
        SettingsDBCache.getSettings(
          [SOFTWARE_TAG, FIRMWARE_REVISION, BASE_VERSION],
          results => {
            updateSmallItem(elements.softTag, results[SOFTWARE_TAG]);
            updateSmallItem(
              elements.firmwareRevision,
              results[FIRMWARE_REVISION]
            );
            updateSmallItem(elements.baseVersion, results[BASE_VERSION]);
          }
        );
        hardwareInfo.loadBluetoothAddress();
        DeviceFeature.ready(() => {
          if (DeviceFeature.getValue('buildType') === 'user') {
            elements.osVersion.addEventListener('keydown', keyDwnHandler);
            elements.osVersion.addEventListener('blur', cleanKeyArray);
          }
        });
      },

      onBeforeHide() {
        DeviceFeature.ready(() => {
          if (DeviceFeature.getValue('buildType') === 'user') {
            elements.osVersion.removeEventListener('keydown', keyDwnHandler);
            elements.osVersion.removeEventListener('blur', cleanKeyArray);
          }
        });
      }
    });
  };
});
