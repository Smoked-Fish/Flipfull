/* global SliderHandler */
'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  require('panels/accessibility/slider_handler');

  return function createAccessibilityPanel() {
    const listElements = document.querySelectorAll('#accessibility li');
    let elements = {};
    const CAPTIONS_KEY = 'accessibility.captions';
    const SCREENREADER_KEY = 'accessibility.screenreader';
    const VOLUME_BALANCE_KEY = 'accessibility.volume_balance';
    const VOLUME_BALANCE_STRING = [
      'L5',
      'L4',
      'L3',
      'L2',
      'L1',
      '0',
      'R1',
      'R2',
      'R3',
      'R4',
      'R5'
    ];
    var TTY_MODE_KEY = 'tty.mode.enabled'; //Porting from [TMO:GID-MTRREQ-460421]Task10115053-yanli.zhang-for RTT-TTY On/Off Controls on 2024/8/29-add
    function updateCaptionsStatus(enabled) {
      const l10nId = enabled ? 'on' : 'off';
      elements.captionsDesc.setAttribute('data-l10n-id', l10nId);
    }

    function updateReadoutStatus(enabled) {
      const l10nId = enabled ? 'on' : 'off';
      elements.readoutModeDesc.setAttribute('data-l10n-id', l10nId);
    }

    function updateVolumeBalanceStatus(value) {
      const convertValue = value / 10;
      elements.volumebalanceDesc.setAttribute(
        'data-l10n-id',
        `balance-${VOLUME_BALANCE_STRING[convertValue]}`
      );
    }

    //Porting from [TMO:GID-MTRREQ-460421]Task10115053-yanli.zhang-for RTT-TTY On/Off Controls on 2024/8/29-begin
    function updateRttStatusTct(value) {
      dump('Settings: _updateRttStatusTct and value is: ' + value);
      if (value === 'full' && OperatorUtils.isSubjectToTMOFamily()) {
        SettingsDBCache.getSetting('ril.rtt.enabled').then(result => {
          dump('Settings: updateRttStatusTct result = ' + result);
          var lastMozSettingValue = result;
          if (!lastMozSettingValue) {
            SettingsDBCache.saveSettings({'ril.rtt.enabled': true});
            SettingsDBCache.saveSettings({'ril.rtt.preferredSettings': 'visible-during-calls'});
            elements.rttDesc.setAttribute('data-l10n-id', 'on');
            ToastHelper.showToast('auto_turn_on_rtt');
          }
        });
      }
    }
    //Porting from [TMO:GID-MTRREQ-460421]Task10115053-yanli.zhang-for RTT-TTY On/Off Controls on 2024/8/29-end

    //Porting from [TMO:GID-MTRREQ-460422]Task10115048-yanli.zhang-for customizing the tty mode for tmo on 2024/8/29-begin
    function addOptionForTTY(value) {
      if (value) {
        let option = document.createElement('OPTION');
        option.value = value;
        option.setAttribute('data-l10n-id', value);
        elements.ttySelect.options.add(option);
      }
    }
    //Porting from [TMO:GID-MTRREQ-460422]Task10115048-yanli.zhang-for customizing the tty mode for tmo on 2024/8/29-end

    function updateRttStatus(enabled) {
      const l10nId = enabled ? 'on' : 'off';
      //Porting from [VZW:VZ_REQ_RTT-UX_4626885]Task10051780-yanli.zhang-for customizing the rtt menu for vzw on 2024/8/29-begin
      //Porting from Task11329883 - [ATT:<CDR-RTT-240>]-yanli.zhang@tcl.com-for hiding the rtt switch in att-modify
      if (!OperatorUtils.isATTFamily() && !OperatorUtils.isVZWFamily()) {
        elements.rttDesc.setAttribute('data-l10n-id', l10nId);
      }
      //Porting from [VZW:VZ_REQ_RTT-UX_4626885]Task10051780-yanli.zhang-for customizing the rtt menu for vzw on 2024/8/29-end
    }

    return SettingsPanel({
      onInit: function onInit(panel) {
        elements = {
          captionsDesc: panel.querySelector('.captions small'),
          readOutMode: panel.querySelector('.readout-mode').parentNode,
          readoutModeDesc: panel.querySelector('.readout-mode small'),
          rttDesc: panel.querySelector('#rtt-desc'),
          ttyMode: document.getElementById('ttymode'), //Porting from [VZW:VZ_REQ_UNIDESIGN_33706]Task10051780-yanli.zhang-for removing tty for vzw on 2024/8/29-add
          ttySelect: document.getElementById('ttyselect'), //Porting from [TMO:GID-MTRREQ-460422]Task10115048-yanli.zhang-for customizing the tty mode for tmo on 2024/8/29-add
          volumeBalance: panel.querySelector('.slider-container'),
          volumebalanceDesc: panel.querySelector(
            '.slider-container span.level'
          ),
          volumebalanceContainer: panel.querySelector('.slider-container')
        };

        const volumebalance = new SliderHandler();
        volumebalance.init(elements.volumebalanceContainer);
        DeviceFeature.ready(() => {
          if (
            DeviceFeature.getValue('lowMemory') !== 'true' &&
            DeviceFeature.getValue('readout') === 'true'
          ) {
            elements.readOutMode.classList.remove('hidden');
          }
          //if (DeviceFeature.getValue('rtt') === 'true') {
            const rttHeader = panel.querySelector('#rtt-header');
            const rttItem = panel.querySelector('#rtt-item');
            //Porting from GF7EE-1562-yanli.zhang-[RTT]EE network not support RTT, please remove the RTT menu  on 2024/8/29 begin
            if(OperatorUtils.getBuildOperatorName() !== 'EE'){
              rttHeader.classList.remove('hidden');
              rttItem.classList.remove('hidden');
            }
            //Porting from GF7EE-1562-yanli.zhang-[RTT]EE network not support RTT, please remove the RTT menu  on 2024/8/29 end
          //}
        });
        //Porting from [VZW:VZ_REQ_UNIDESIGN_33706]Task10051780-yanli.zhang-for removing tty for vzw on 2024/8/29-begin; GF7EE-1219-yanli.zhang-Have TTY menu in settings but ID card show no need it.
        if (OperatorUtils.isVZWFamily() || OperatorUtils.isATTFamily() || OperatorUtils.getBuildOperatorName() === 'EE'
            || OperatorUtils.isUSCCFamily()) { //Modify for GF5GTMO-8467 xiaolei.yin 20251028
          elements.ttyMode.classList.add('hidden');
        }
        //Porting from [VZW:VZ_REQ_UNIDESIGN_33706]Task10051780-yanli.zhang-for removing tty for vzw on 2024/8/29-end
        //Porting from [TMO:GID-MTRREQ-460422]Task10115048-yanli.zhang-for customizing the tty mode for tmo on 2024/8/29-begin
        if (OperatorUtils.isSPRINTFamily()) {
          addOptionForTTY('vco');
          addOptionForTTY('hco');
          elements.ttySelect.options[1].setAttribute('data-l10n-id', 'full');
        }
        //Porting from [TMO:GID-MTRREQ-460422]Task10115048-yanli.zhang-for customizing the tty mode for tmo on 2024/8/29-end

        elements.volumeBalance.onfocus = () => {
          elements.volumebalanceDesc.setAttribute('aria-live', 'assertive');
        };
        elements.volumeBalance.onblur = () => {
          elements.volumebalanceDesc.removeAttribute('aria-live');
        };
      },

      onBeforeShow(panel) {
        SettingsSoftkey.init(SoftParams.defaultSelect);
        SettingsSoftkey.show();
        ListFocusHelper.updateSoftkey(panel);
        ListFocusHelper.addEventListener(listElements);
      },

      onBeforeHide() {
        SettingsSoftkey.hide();
        ListFocusHelper.removeEventListener(listElements);
      },

      onShow() {
        SettingsDBCache.observe(CAPTIONS_KEY, false, updateCaptionsStatus);

        SettingsDBCache.observe(SCREENREADER_KEY, false, updateReadoutStatus);

        SettingsDBCache.observe(
          VOLUME_BALANCE_KEY,
          50,
          updateVolumeBalanceStatus
        );
        SettingsDBCache.observe('ril.rtt.enabled', false, updateRttStatus);
        SettingsDBCache.observe(TTY_MODE_KEY, 'off', updateRttStatusTct);//Porting from [TMO:GID-MTRREQ-460421]Task10115053-yanli.zhang-for RTT-TTY On/Off Controls on 2024/8/29-add
      },

      onHide() {
        SettingsDBCache.unobserve(CAPTIONS_KEY, updateCaptionsStatus);

        SettingsDBCache.unobserve(SCREENREADER_KEY, updateReadoutStatus);

        SettingsDBCache.unobserve(
          VOLUME_BALANCE_KEY,
          updateVolumeBalanceStatus
        );
        SettingsDBCache.unobserve('ril.rtt.enabled', updateRttStatus);
        SettingsDBCache.unobserve(TTY_MODE_KEY, updateRttStatusTct);//Porting from [TMO:GID-MTRREQ-460421]Task10115053-yanli.zhang-for RTT-TTY On/Off Controls on 2024/8/29-add
      }
    });
  };
});
