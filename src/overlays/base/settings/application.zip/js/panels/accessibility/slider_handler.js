'use strict';
(function sliderHandler(exports) {
  const SETTING_NAME = 'accessibility.volume_balance';
  const volumeBalanceStr = [
    'L5',
    'L4',
    'L3',
    'L2',
    'L1',
    '0',
    'R1',
    'R2',
    'R3',
    'R4',
    'R5'
  ];
  const SETTING_VALUE_DEFAULT = 50;

  const SliderHandler = function SliderHandler() {
    this.sliderContainer = null;
    this.sliderElement = null;
    this.sliderLabel = null;
    this.sliderValue = null;
  };

  SliderHandler.prototype = {
    init: function init(container) {
      this.sliderContainer = container;
      this.sliderElement = container.querySelector('input');
      this.sliderLabel = container.querySelector('span.level');

      SettingsDBCache.observe(
        SETTING_NAME,
        SETTING_VALUE_DEFAULT,
        this.setSliderValue.bind(this)
      );
      this.sliderContainer.addEventListener(
        'keydown',
        this.keydownHandler.bind(this)
      );
    },

    keydownHandler: function keydownHandler(evt) {
      // Add support to RTL
      const isRtl = window.document.dir === 'rtl';
      const arrowLR = isRtl
        ? ['ArrowRight', 'ArrowLeft']
        : ['ArrowLeft', 'ArrowRight'];
      switch (evt.key) {
        case arrowLR[0]:
          this.saveVolumeBalance(
            this.sliderValue <= 0 ? 0 : this.sliderValue - 10
          );
          evt.preventDefault();
          break;

        case arrowLR[1]:
          this.saveVolumeBalance(
            this.sliderValue >= 100 ? 100 : this.sliderValue + 10
          );
          evt.preventDefault();
          break;

        default:
          break;
      }
    },

    setSliderValue: function setSliderValue(value) {
      this.sliderElement.value = value;
      this.sliderValue = value;
      /*
       * The slider is transparent if the value is not set yet, display it
       * once the value is set.
       */
      if (this.sliderElement.style.opacity !== 1) {
        this.sliderElement.style.opacity = 1;
      }
      this.sliderLabel.textContent = volumeBalanceStr[value / 10];
    },

    saveVolumeBalance: function saveVolumeBalance(value) {
      const settingObject = {};
      settingObject[SETTING_NAME] = parseInt(value, 10);
      SettingsDBCache.saveSettings(settingObject);
    }
  };

  exports.SliderHandler = SliderHandler;
})(window);
