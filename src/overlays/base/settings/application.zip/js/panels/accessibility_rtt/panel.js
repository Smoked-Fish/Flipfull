'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  var SettingsService = require('modules/settings_service');//Porting from Task11359741 - [ATT:CDR-RTT-160]-yanli.zhang@tcl.com-for showing the rtt welcome message of att on 2024/9/2-add

  return function createAccessibilityRttPanel() {
    const RTT_ENABLED = 'ril.rtt.enabled';
    const RTT_PREFERRED_ENABLED = 'ril.rtt.preferredSettings';
    let elements = null;
    //Porting from Task10115053-yanli.zhang-KaiOS bug, handleChange can't get the elements on 2024/08/29-begin
    var rttDescription = document.getElementById('rtt-desc');
    var rttPreference = document.getElementById('accessaccessibility-rtt-preference');
    var rttPreferenceSelect =
          document.querySelectorAll('#accessaccessibility-rtt-preference select');
    //Porting from Task10115053-yanli.zhang-KaiOS bug, handleChange can't get the elements on 2024/08/29-end

    function handleChange(value, key) {
      if (key === RTT_ENABLED) {
        const stringId = value ? 'on' : 'off';
        //Porting from [VZW:VZ_REQ_RTT-UX_4626885]Task10051780-yanli.zhang-for customizing the rtt menu for vzw on 2024/08/29-begin
        //Porting from Task11329883 - [ATT:<CDR-RTT-240>]-yanli.zhang@tcl.com-for hiding the rtt switch in att-modify on 2024/9/2
        if (!OperatorUtils.isATTFamily() && !OperatorUtils.isVZWFamily()) {
          rttDescription.setAttribute('data-l10n-id', stringId);
        }
        //Porting from [VZW:VZ_REQ_RTT-UX_4626885]Task10051780-yanli.zhang-for customizing the rtt menu for vzw on 2024/08/29-end
        elements.rttPreference.classList.toggle('hidden', !value);
      } else if (key === RTT_PREFERRED_ENABLED) {
        //Porting from Defect-GF7TF-3704-begin chaofan.shi 2023/10/30
        if((value == 'always-visible-automatic') && !OperatorUtils.isTMOFamily()){
          rttPreferenceSelect.value = 'visible-during-calls';
        }else {
          rttPreferenceSelect.value = value;
        }
        //Porting from Defect-GF7TF-3704-end chaofan.shi 2023/10/30
      }
      window.dispatchEvent(new CustomEvent('refresh'));
    }

    //Porting from Task11359741 - [ATT:<CDR-RTT-160>]-yanli.zhang@tcl.com-for showing the rtt welcome message of att on 2024/9/2-begin
    function handleRttModeChange() {
      if (elements.rttSelector.value === 'always-visible-manual' && OperatorUtils.isATTFamily()) {
        dump('settings-rtt:should_show_rtt_welcome_att: ' + window.localStorage.getItem('should_show_rtt_welcome_att'));
        if (!window.localStorage.getItem('should_show_rtt_welcome_att')) {
          SettingsService.navigate('accessibility_rtt_welcome_att');
        }
      }
    }
    //Porting from Task11359741 - [ATT:<CDR-RTT-160>]-yanli.zhang@tcl.com-for showing the rtt welcome message of att on 2024/9/2-end

    return SettingsPanel({
      onInit: function onInit(panel) {
        elements = {
          rttPreference: panel.querySelector(
            '#accessaccessibility-rtt-preference'
          ),
          rttPreferenceSelect: panel.querySelector(
            '#accessaccessibility-rtt-preference select'
          ),
          rttHelp: panel.querySelector('#rtt-help'),//Porting from [VZW:VZ_REQ_RTT-UX_5950012]Task10051539-yanli.zhang-for developing rtt help feature on 2024/8/29-add
          //Porting from [VZW:VZ_REQ_RTT-UX_4626885]Task10051780-yanli.zhang-for customizing the rtt menu for vzw-begin
          rttSwitch: panel.querySelector('#rtt-switch'),
          rttSelector: panel.querySelector('#rtt-select'),
          rttPreferenceSpan: panel.querySelector('#accessaccessibility-rtt-preference-span'),
          //Porting from [VZW:VZ_REQ_RTT-UX_4626885]Task10051780-yanli.zhang-for customizing the rtt menu for vzw-end
          rttDescription: panel.querySelector('#rtt-desc')
        };
        //Porting from [VZW:VZ_REQ_RTT-UX_5950012]Task10051539-yanli.zhang-for developing rtt help feature-begin
        if (OperatorUtils.isVZWFamily()) {
          elements.rttHelp.classList.remove('hidden');
          //Porting from [VZW:VZ_REQ_RTT-UX_4626885]Task10051780-yanli.zhang-for customizing the rtt menu for vzw-begin
          elements.rttSwitch.classList.add('hidden');
          if (elements.rttSelector.options.length >= 3) {
            elements.rttSelector.options.remove(2);
            elements.rttSelector.options[0].setAttribute('data-l10n-id', 'rtt_accessibility_off');
            elements.rttSelector.options[1].setAttribute('data-l10n-id', 'rtt_accessibility_on');
          }
          elements.rttPreferenceSpan.setAttribute('data-l10n-id', 'accessibility-rtt-preference-vzw');
          //Porting from [VZW:VZ_REQ_RTT-UX_4626885]Task10051780-yanli.zhang-for customizing the rtt menu for vzw-end
        }
        //Porting from [VZW:VZ_REQ_RTT-UX_5950012]Task8679922-yanli.zhang-for developing rtt help feature-end

        //Porting from Task11329872 - [ATT:<CDR-RTT-230>]-yanli.zhang@tcl.com-for customizing the rtt settings for ATT on 2024/9/2-begin
        if (OperatorUtils.isATTFamily()) {
          elements.rttSwitch.classList.add('hidden');
          if (elements.rttSelector.options.length >= 3) {
            dump('Settings: this is att, we are going to customize the items.');
            elements.rttSelector.options.remove(2);
            elements.rttSelector.options[1].setAttribute('data-l10n-id', 'always-visible');
          }
        }
        //Porting from Task11329872 - [ATT:<CDR-RTT-230>]-yanli.zhang@tcl.com-for customizing the rtt settings for ATT on 2024/9/2-end

        //Porting from [TMO:GID-MTRREQ-482352]Task10123898-yanli.zhang-for developing rtt help for tmo-begin
        //Porting from Task11099455-yanli.zhang-for developing rtt help for uscc-modify
        if (OperatorUtils.isSubjectToTMOFamily() || OperatorUtils.isUSCCFamily()) {
          elements.rttHelp.classList.remove('hidden');
        }
        //Porting from [TMO:GID-MTRREQ-482352]Task10123898-yanli.zhang-for developing rtt help for tmo-end

        //Begin added by yanli.zhang GF5GTMO-8442 on 2025/10/21
        if (OperatorUtils.isUSCCFamily()) {
          if (elements.rttSelector.options.length >= 3) {
            dump('Settings: this is uscc, we are going to customize the items.');
            elements.rttSelector.options.remove(2);
          }
        }
        //End added by yanli.zhang GF5GTMO-8442 on 2025/10/21
      },

      onBeforeShow() {
        SettingsDBCache.observe(RTT_ENABLED, false, handleChange);
        SettingsDBCache.observe(
          RTT_PREFERRED_ENABLED,
          'visible-during-calls',
          handleChange
        );
        elements.rttSelector.addEventListener('change', handleRttModeChange);//Porting from Task11359741 - [ATT:<CDR-RTT-160>]-yanli.zhang@tcl.com-for showing the rtt welcome message of att on 2024/9/2
        SettingsSoftkey.show();
      },

      onBeforeHide() {
        SettingsDBCache.unobserve(RTT_ENABLED, handleChange);
        SettingsDBCache.unobserve(RTT_PREFERRED_ENABLED, handleChange);
        elements.rttSelector.removeEventListener('change', handleRttModeChange);//Porting from Task11359741 - [ATT:<CDR-RTT-160>]-yanli.zhang@tcl.com-for showing the rtt welcome message of att on 2024/9/2
      }
    });
  };
});
