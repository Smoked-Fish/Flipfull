/**
 * [VZW:VZ_REQ_RTT-UX_5950012]
 * Task10051539-shiyan.luo@tcl.com-add this file for rtt help
 */
define(function (require) {
  'use strict';

  var SettingsPanel = require('modules/settings_panel');
  var SettingsService = require('modules/settings_service');

  return function rtt_help_content_panel() {
    // [TMO:GID-MTRREQ-482352]Task10123898-shiyan.luo@tcl.com-for developing rtt help for tmo-begin
    var elements = {};
    var url = 'https://www.t-mobile.com/responsibility/consumer-info/accessibility-policy?filter=speech';
    // [TMO:GID-MTRREQ-482352]Task10123898-shiyan.luo@tcl.com-for developing rtt help for tmo-end
    var lastSoftkey = SettingsSoftkey.getLastPara();

    // [TMO:GID-MTRREQ-482352]Task10123898-shiyan.luo@tcl.com-for developing rtt help for tmo-modify
    function _initSoftKeyForNoraml() {
      var softkeyParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [{
          name: 'Back',
          l10nId: 'back',
          priority: 2,
          method: function () {
            SettingsService.navigate('accessibility_rtt');
          }
        }]
      };
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    // [TMO:GID-MTRREQ-482352]Task10123898-shiyan.luo@tcl.com-for developing rtt help for tmo-begin
    function _initSoftKeyForUrl() {
      var softkeyParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [{
          name: 'Back',
          l10nId: 'back',
          priority: 2,
          method: function () {
            SettingsService.navigate('accessibility_rtt');
          }
        },
        {
          name: 'openUrl',
          l10nId: 'open-url',
          priority: 3,
          method: function () {
            window.open(url, '_blank ');
          }
        }]
      };
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }
    // [TMO:GID-MTRREQ-482352]Task10123898-shiyan.luo@tcl.com-for developing rtt help for tmo-end

    return SettingsPanel({
      onInit: function (panel) {
        // [TMO:GID-MTRREQ-482352]Task10123898-shiyan.luo@tcl.com-for developing rtt help for tmo-begin
        elements = {
          panel: panel,
          rttHelpTextVZW: panel.querySelector('#rtt-help-text-vzw'),
          rttHelpTextTMO: panel.querySelector('#rtt-help-text-tmo'),
          rttHelpHref: panel.querySelector('#rtt-help-href-tmo') // Task11099455-shiyan.luo@tcl.com-for developing rtt help for uscc-add
        };
        // [TMO:GID-MTRREQ-482352]Task10123898-shiyan.luo@tcl.com-for developing rtt help for tmo-end
      },

      onBeforeShow: function () {
        // [TMO:GID-MTRREQ-482352]Task10123898-shiyan.luo@tcl.com-for developing rtt help for tmo-begin
        if (OperatorUtils.isSubjectToTMOFamily()) {
          _initSoftKeyForUrl();
          elements.rttHelpTextTMO.classList.remove('hidden');
          elements.rttHelpTextVZW.classList.add('hidden');
        } else if (OperatorUtils.isVZWFamily()) {
          _initSoftKeyForNoraml();
          elements.rttHelpTextTMO.classList.add('hidden');
          elements.rttHelpTextVZW.classList.remove('hidden');
        // Task11099455-shiyan.luo@tcl.com-for developing rtt help for uscc-begin
        } else if (OperatorUtils.isUSCCFamily()) {
          _initSoftKeyForNoraml();
          elements.rttHelpTextTMO.classList.remove('hidden');
          elements.rttHelpTextVZW.classList.add('hidden');
          elements.rttHelpHref.style.visibility = "hidden"; //Modify for GF5GTMO-8470 xiaolei.yin 20251023
        // Task11099455-shiyan.luo@tcl.com-for developing rtt help for uscc-end
        }
        // [TMO:GID-MTRREQ-482352]Task10123898-shiyan.luo@tcl.com-for developing rtt help for tmo-end
      },

      onBeforeHide: function () {
        SettingsSoftkey.init(lastSoftkey);
        // [TMO:GID-MTRREQ-482352]Task10123898-shiyan.luo@tcl.com-for developing rtt help for tmo-begin
        elements.rttHelpTextTMO.classList.add('hidden');
        elements.rttHelpTextVZW.classList.add('hidden');
        // [TMO:GID-MTRREQ-482352]Task10123898-shiyan.luo@tcl.com-for developing rtt help for tmo-end
      }
    });
  };
});
