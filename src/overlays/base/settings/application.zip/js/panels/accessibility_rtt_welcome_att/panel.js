/* global SettingsSoftkey */
/**
 * [ATT:<CDR-RTT-160>]Task11359741-shiyan.luo@tcl.com-for showing the rtt welcome message of att-add this file
 */

define(function (require) {
    'use strict';

    var SettingsPanel = require('modules/settings_panel');
    var SettingsService = require('modules/settings_service');
    var elements = {};

    function handleChange() {
        dump('settings-rtt:changed and checked is ' + elements.showAgain.checked);
        if (elements.showAgain.checked) {
            window.localStorage.setItem('should_show_rtt_welcome_att', 'true');
        } else {
            window.localStorage.setItem('should_show_rtt_welcome_att', '');
        }
    }

    return function accessibility_rtt_welcome_att_panel() {
        // init the soft key, one for select and one for exit.
        function _initSoftKey() {
            var softkeyParams = {
                menuClassName: 'menu-button',
                header: {
                    l10nId: 'message'
                },
                items: [{
                    name: 'Select',
                    l10nId: 'select',
                    priority: 2,
                    method: function() {}
                },{
                    name: 'Ok',
                    l10nId: 'ok_button',
                    priority: 3,
                    method: function() {
                        SettingsService.navigate('accessibility_rtt');
                    }
                }]
            };
            SettingsSoftkey.init(softkeyParams);
            SettingsSoftkey.show();
        }

        return SettingsPanel({
            onInit: function (panel) {
                elements = {
                    panel:panel,
                    showAgain: document.getElementById('checkbox_show_again'),
                };
            },

            onBeforeShow: function () {
                _initSoftKey();
                elements.showAgain.addEventListener('change', handleChange);
            },

            onBeforeHide: function () {
                elements.showAgain.removeEventListener('change', handleChange);
                // for recovery the soft key params
                var softkeyParams = {
                    menuClassName: 'menu-button',
                    header: {
                        l10nId: 'message'
                    },
                    items: [{
                        name: 'Select',
                        l10nId: 'select',
                        priority: 2,
                        method: function() {}
                    }]
                };
                SettingsSoftkey.init(softkeyParams);
                SettingsSoftkey.hide();
            },
        });
    };
});
