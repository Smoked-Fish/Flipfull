'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createAddeSIMPanel() {
    let elements = null;
    const softkeyParams = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'options'
      },
      items: [
        {
          get name() {
            return ActivityHandler.currentActivity ? 'back' : 'cancel';
          },
          get l10nId() {
            return ActivityHandler.currentActivity ? 'back' : 'cancel';
          },
          priority: 1,
          method() {
            if (ActivityHandler.currentActivity) {
              ActivityHandler.postResult();
            } else {
              NavigationMap.navigateBack();
            }
          }
        },
        {
          name: 'Select',
          l10nId: 'select',
          priority: 2
        },
        {
          get name() {
            return ActivityHandler.currentActivity ? 'skip' : '';
          },
          get l10nId() {
            return ActivityHandler.currentActivity ? 'skip' : '';
          },
          priority: 3,
          method() {
            if (ActivityHandler.currentActivity) {
              ActivityHandler.postResult({ onNext: true });
            }
          }
        }
      ]
    };

    function keyDownHandler(evt) {
      if (ActivityHandler.currentActivity) {
        if (evt.key === 'Backspace') {
          evt.preventDefault();
          evt.stopPropagation();
        }
      }
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          container: panel.querySelector('div'),
          scan: panel.querySelector('#scan')
        };
        if (!ApiManager.eUiccManager) {
          if (ActivityHandler.currentActivity) {
            ActivityHandler.postResult();
          }
          return;
        }
        const eid = panel.querySelector('#eid');
        SettingsDBCache.getSetting('esim.test.mode.enabled').then(
          eSIMVerMode => {
            const address = panel.querySelector('#address');
            // [GF5GTMO-4253] show smdp+ address menu all time, yuwei.fang, 2024-09-19
            // don't show in SUW
            if (ActivityHandler.currentActivity) {
              address.classList.toggle('hidden', true);
            } else {
              address.classList.toggle('hidden', false);
            }
            eid.classList.toggle('verMode', !!eSIMVerMode);
            if (eSIMVerMode) {
              NavigationMap.menuReset();
            }
          }
        );

        ApiManager.eUiccManager.getEid().then(
          number => {
            eid.textContent = l10n.get('eid-number', { number });
          },
          err => {
            DebugHelper.debug(`getEid error:${err}`);
            if (ActivityHandler.currentActivity) {
              ActivityHandler.postResult();
            }
          }
        );
      },
      onBeforeShow() {
        elements.container.addEventListener('keydown', keyDownHandler);
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
      },

      onBeforeHide() {
        elements.container.removeEventListener('keydown', keyDownHandler);
        SettingsSoftkey.hide();
      },

      onShow(panel, options) {
        if (options && options.toFocus === 1) {
          // Focus to scan QR code
          NavigationMap.menuReset(elements.scan);
        }
      }
    });
  };
});
