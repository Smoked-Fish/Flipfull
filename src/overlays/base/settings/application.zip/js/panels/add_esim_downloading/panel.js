'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  const defaultCode = ['UseSMDP', 'UseSMDS'];
  return function createAddeSIMDownloadingPanel() {
    let elements = null;
    let activeCode = '';
    let downloadDirectlyPhase = 0;
    // [GF5GTMO-4455] begin added by yuwei.fang, 2024-10-21
    let SMDPAddress = '';
    let SMDPAddrList = [];
    let SMDPIndex = 0;
    // [GF5GTMO-4455] end added by yuwei.fang, 2024-10-21
    const SMDP_KEY = 'esim.smdp.address';
    let sdmpValue = null;
    // 'confirm-code', 'confirmation', 'downloading', 'downloaded'
    let downloadState = '';
    const softkeyItems = [
      {
        name: 'Cancel',
        l10nId: 'cancel',
        priority: 1,
        method() {
          if (downloadState === 'confirmation') {
            ApiManager.eUiccManager.setUserConsent(false);
          }
          NavigationMap.navigateBack();
        }
      },
      {
        name: 'Select',
        l10nId: 'select',
        priority: 2,
        method() {
          ApiManager.eUiccManager.setUserConsent(true);
        }
      },
      {
        name: 'ok',
        l10nId: 'ok',
        priority: 2,
        method() {
          if (downloadState === 'failed') {
            Settings.isBackHref = true;
            Settings.setCurrentPanel('#add_esim', { toFocus: 1 });
          } else {
            //[GF5GTMO-5829] begin modified by yuwei.fang, 2024-12-16
            //[GF5GTMO-6893] begin modified by yuwei.fang, 2025-03-19
            if (ApiManager.connections[0].iccId == null) {
              dump("add_esim_downloading: pSIM absent, enable an eSIM");
              checkWhetherEnableeSIM();
            } else {
              dump("add_esim_downloading: pSIM present, needn't enable eSIM");
              if (ActivityHandler.currentActivity) {
                ActivityHandler.postResult({ onNext: true });
              } else {
                backToSIMCardManger();
              }
            }
            //[GF5GTMO-6893] end modified by yuwei.fang, 2025-03-19
            //[GF5GTMO-5829] end modified by yuwei.fang, 2024-12-16
          }
        }
      },
      {
        get name() {
          return elements.codeInput.value ? 'next' : '';
        },
        get l10nId() {
          return elements.codeInput.value ? 'next' : '';
        },
        priority: 3,
        method() {
          if (elements.codeInput.value) {
            addProfile(elements.codeInput.value);
          }
        }
      },
      {
        name: '',
        l10nId: '',
        priority: 1
      }
    ];
    const softkeyParams = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'options'
      },
      get items() {
        if (downloadState === 'confirm-code') {
          return [softkeyItems[0], softkeyItems[3]];
        }
        if (downloadState === 'confirmation') {
          return [softkeyItems[0], softkeyItems[1]];
        }
        if (downloadState === 'downloading') {
          return [softkeyItems[4]];
        }
        if (downloadState === 'downloaded') {
          return [softkeyItems[2]];
        }
        if (downloadState === 'failed') {
          return [softkeyItems[2]];
        }
        return [];
      }
    };

    function showConfirmCodeScreen() {
      downloadState = 'confirm-code';
      elements.addeSIMDownloading.dataset.state = 'confirmation-code';
      elements.primaryInfo.textContent = l10n.get('enter-code');
      elements.secondaryInfo.textContent = '';
      elements.progressBar.classList.add('hidden');
      elements.confirmationCode.classList.remove('hidden');
      elements.add.classList.add('hidden');
      elements.codeInput.focus();
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    function showConfirmationScreen() {
      downloadState = 'confirmation';
      elements.addeSIMDownloading.dataset.state = 'confirmation';
      elements.primaryInfo.textContent = l10n.get('add-esim-title');
      elements.secondaryInfo.textContent = l10n.get('connect-esim');
      elements.progressBar.classList.add('hidden');
      elements.confirmationCode.classList.add('hidden');
      elements.add.classList.remove('hidden');
      window.dispatchEvent(new CustomEvent('refresh'));
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    function showDownloadingScreen() {
      downloadState = 'downloading';
      elements.addeSIMDownloading.dataset.state = 'downloading';
      elements.primaryInfo.textContent = l10n.get('downloading');
      elements.secondaryInfo.textContent = l10n.get('please-wait');
      elements.progressBar.classList.remove('hidden');
      elements.confirmationCode.classList.add('hidden');
      elements.add.classList.add('hidden');
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    function showDownloadedScreen() {
      downloadState = 'downloaded';
      elements.addeSIMDownloading.dataset.state = 'downloaded';
      elements.primaryInfo.textContent = l10n.get('esim-added-1');
      elements.secondaryInfo.textContent = l10n.get('esim-added-2');
      elements.progressBar.classList.add('hidden');
      elements.confirmationCode.classList.add('hidden');
      elements.add.classList.add('hidden');
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    function showAddedFailedScreen() {
      downloadState = 'failed';
      elements.addeSIMDownloading.dataset.state = 'failed';
      elements.primaryInfo.textContent = l10n.get('added-failed-title');
      elements.secondaryInfo.textContent = l10n.get('added-failed');
      elements.progressBar.classList.add('hidden');
      elements.confirmationCode.classList.add('hidden');
      elements.add.classList.add('hidden');
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    function enableProfile(iccid) {
      ApiManager.eUiccManager.enableProfile(iccid).then(
        () => {
          DebugHelper.debug('enableProfile success');
          // [GF5GTMO-4795] begin modified by yuwei.fang, 2024-10-31
          if (ActivityHandler.currentActivity) {
            dump("add_esim_downloading: in FTU, now go to next procedure");
            ActivityHandler.postResult({ onNext: true });
          } else {
            dump("add_esim_downloading: not in FTU, go back to sim manager");
            // [GF5GTMO-4870] added by yuwei.fang, 2024-10-30
            backToSIMCardManger();
          }
          // [GF5GTMO-4795] end modified by yuwei.fang, 2024-10-31
        },
        error => {
          DebugHelper.debug(`enableProfile error:${error}`);
          if (ActivityHandler.currentActivity) {
            ActivityHandler.postResult({ onNext: true });
          } else {
            backToSIMCardManger();
          }
        }
      );
    }

    async function addProfile(confirmCode) {
      showDownloadingScreen();
      if (!window.IsOnline()) {
        // Don't back too qu
        setTimeout(() => {
          showToastAndBack('network-error');
        }, 200);
        return;
      }
      let promise = null;
      if (confirmCode) {
        DebugHelper.log('addProfile sendConfirmCode');
        promise = ApiManager.eUiccManager.sendConfirmCode(confirmCode);
      } else {
        let code = activeCode;
        // [GF5GTMO-4455] begin modified by yuwei.fang, 2024-10-21
        if (code === '') {
          if (downloadDirectlyPhase > 1) {
            return;
          }
          downloadDirectlyPhase++;
          // fix multi SMDP address resolution
          if (SMDPIndex < SMDPAddrList.length) {
            dump("add_esim_downloading: try to download from SMDPAddrList[" + SMDPIndex + "]: " + SMDPAddrList[SMDPIndex]);
            // set to next SMDP Address
            await setSMDPAddr(SMDPAddrList[SMDPIndex++]);
            // stay at SMDP phase
            if (downloadDirectlyPhase === 2) downloadDirectlyPhase--;
          }
          code = defaultCode[downloadDirectlyPhase-1];
        }
        dump("add_esim_downloading: addProfile - downloadDirectlyPhase = " + downloadDirectlyPhase + ", code = " + code);
        // [GF5GTMO-4455] end modified by yuwei.fang, 2024-10-21
        promise = ApiManager.eUiccManager.addProfile(code, '');
      }
      promise.then(
        () => {
          DebugHelper.log('addProfile successful');
        },
        err => {
          DebugHelper.log(`addProfile error:${err}`);
          if (err !== 'Need-user-confirmmation-code') {
            showToastAndBackToScan();
          }
        }
      // [GF5GTMO-8504]-BGN-ADD restore SMDP address, by yuwei.fang, 2025/10/27
      ).finally(() => {
        dump("add_esim_downloading: restore SMDP address");
        setSMDPAddr(SMDPAddress);
      });
      // [GF5GTMO-8504]-END-ADD restore SMDP address, by yuwei.fang, 2025/10/27
    }

    // [GF5GTMO-4455] begin added by yuwei.fang, 2024-10-21
    function setSMDPAddr(address) {
      return new Promise(resolve => {
        ApiManager.eUiccManager.setSMDPAddr(address).then(
          () => {
            dump("add_esim_downloading: set SMDP address: " + address + " done");
            resolve();
          },
          error => {
            dump("add_esim_downloading: set SMDP address failed: " + error);
          }
        );
      });
    }
    // [GF5GTMO-4455] end added by yuwei.fang, 2024-10-21

    function checkWhetherEnableeSIM() {
      ApiManager.eUiccManager.queryProfiles().then(
        profiles => {
          let iccid = '';
          for (let index = 0; index < profiles.length; index++) {
            const profile = profiles[index];
            if (profile.state === 'active') {
              if (ActivityHandler.currentActivity) {
                ActivityHandler.postResult({ onNext: true });
              } else {
                backToSIMCardManger();
              }
              return;
            }
            if (profile.profileClass === 'operational') {
              iccid = profile.iccid; // eslint-disable-line
            }
          }
          enableProfile(iccid);
        },
        error => {
          DebugHelper.debug(`queryProfiles error:${error}`);
          if (ActivityHandler.currentActivity) {
            ActivityHandler.postResult({ onNext: true });
          } else {
            backToSIMCardManger();
          }
        }
      );
    }

    function backToSIMCardManger() {
      Settings.isBackHref = true;
      Settings.setCurrentPanel('#simcard_manager');
    }

    function showToastAndBack(msgId) {
      ToastHelper.showToast(msgId);
      NavigationMap.navigateBack();
    }

    function showToastAndBackToScan() {
      ToastHelper.showToast('download-error');
      Settings.isBackHref = true;
      Settings.setCurrentPanel('#add_esim', { toFocus: 1 });
    }

    function onKeyDown(evt) {
      if (evt.key === 'Backspace') {
        if (downloadState === 'downloading') {
          evt.preventDefault();
          evt.stopPropagation();
        } else if (downloadState === 'downloaded' &&
          ActivityHandler.currentActivity) {
          ActivityHandler.postResult({ onNext: true });
        }
      }
    }

    function downloadDefaultSmdp() {
      if (sdmpValue.length) {
        const addr = sdmpValue.shift();
        ApiManager.eUiccManager.setSMDPAddr(addr).then(
          () => {
            DebugHelper.debug(`setSMDPAddr successfully`);
            activeCode = defaultCode[0]; // eslint-disable-line
            addProfile();
          },
          error => {
            DebugHelper.debug(`setSMDPAddr error:${error}`);
            showToastAndBackToScan();
          });
      } else {
        showToastAndBackToScan();
      }
    }

    function updateCustomSimcardsName() {
      SettingsDBCache.getSetting('custom.simcards.name').then(value => {
        const values = value || {};
        ApiManager.eUiccManager.queryProfiles().then(
          profiles => {
            for (let index = 0; index < profiles.length; index++) {
              const profile = profiles[index];
              values[profile.iccid] = profile.nickName || profile.spName;
            }
            SettingsDBCache.saveSettings({
              'custom.simcards.name': values
            });
          },
          error => {
            DebugHelper.debug(`updateCustomEsimName queryProfiles error:${error}`);
          }
        );
      });
    }

    return SettingsPanel({
      onInit(panel, options) {
        activeCode = options.activeCode || activeCode;// eslint-disable-line
        elements = {
          addeSIMDownloading: panel.querySelector('.add-esim-downloading'),
          primaryInfo: panel.querySelector('.primary-info'),
          secondaryInfo: panel.querySelector('.secondary-info'),
          progressBar: panel.querySelector('#gaia-progress'),
          codeInput: panel.querySelector('#code-input'),
          add: panel.querySelector('#add'),
          confirmationCode: panel.querySelector('#confirmation-code')
        };
        ApiManager.eUiccManager.onindicationreceived = event => {
          DebugHelper.log(`onindicationreceived status:${event.status}`);
          if (event.status === 'error') {
            if (event.cause === 'network-error') {
              showToastAndBack('network-error');
            } else if (downloadDirectlyPhase === 1) {
              addProfile();
            } else if (downloadDirectlyPhase === 2) {
              if (sdmpValue === null) {
                SettingsDBCache.getSetting(SMDP_KEY).then(value => {
                  // [TCTTEL-5482]-fix SM-DP+ address empty issue, by yuwei.fang, 2025/10/23
                  sdmpValue = typeof value === 'string' && value.length ?
                    value.split(',') : [];
                  DebugHelper.log(`sdmpValue from settings is:${sdmpValue}`);
                  downloadDefaultSmdp();
                });
              } else {
                downloadDefaultSmdp();
              }
            } else {
              showAddedFailedScreen();
            }
          } else if (event.status === 'get-user-consent') {
            showConfirmationScreen();
          } else if (event.status === 'send-conf-code-request') {
            showConfirmCodeScreen();
          } else if (
            event.status === 'download-progress' ||
            event.status === 'installation-progress'
          ) {
            showDownloadingScreen();
          } else if (event.status === 'installation-complete') {
            showDownloadedScreen();
            updateCustomSimcardsName();
          }
        };
        // [GF5GTMO-4455] begin modified by yuwei.fang, 2024-10-21
        // init and save global SMDP address
        dump("add_esim_downloading: initialize global SMDP address");
        ApiManager.eUiccManager.getSMDPAddr().then(
          value => {
            SMDPAddress = value.split(';')[0].split('SMDPAddr:')[1];
            if (SMDPAddress) {
              SMDPAddrList = SMDPAddress.split(',');
            }
            dump("add_esim_downloading: init SMDPAddrList: [" + SMDPAddrList + "]");
            addProfile();
          }
        ).catch(error => {
            dump("add_esim_downloading: getSMDPAddr() error: " + error);
          }
        );
        // [GF5GTMO-4455] end modified by yuwei.fang, 2024-10-21
      },

      onBeforeShow() {
        elements.codeInput.oninput = () => {
          SettingsSoftkey.init(softkeyParams);
          SettingsSoftkey.show();
        };
        elements.addeSIMDownloading.addEventListener('keydown', onKeyDown);
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
      },

      onBeforeHide() {
        elements.codeInput.oninput = null;
        SettingsSoftkey.hide();
        elements.addeSIMDownloading.removeEventListener('keydown', onKeyDown);
      },

      onUninit() {
        ApiManager.eUiccManager.onindicationreceived = null;
      }
    });
  };
});
