'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createAnswerModePanel() {
    const ANSWER_MODE_KEY = 'phone.answer.flipopen.enabled';
    const FLIP_GO_HOME_KEY = 'flip.gohome.enabled';

    function handleSettings() {
      ToastHelper.showToast('changessaved');
    }

    return SettingsPanel({
      onBeforeShow: function onBeforeShow() {
        SettingsDBCache.observe(ANSWER_MODE_KEY, true, handleSettings, true);
        SettingsDBCache.observe(FLIP_GO_HOME_KEY, true, handleSettings, true);
      },

      onBeforeHide: function onBeforeHide() {
        SettingsDBCache.unobserve(ANSWER_MODE_KEY, handleSettings);
        SettingsDBCache.unobserve(FLIP_GO_HOME_KEY, handleSettings);
      }
    });
  };
});
