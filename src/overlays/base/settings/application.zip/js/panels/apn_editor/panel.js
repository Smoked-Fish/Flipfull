'use strict';
define(function(require) { //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  const ApnSettingsManager = require('modules/apn/apn_settings_manager');

  return function apnEditorPanel() {
    const DM_PROTOCOL = 'dm.apnSettings.protocol';
    let elements = null;
    let listElements = null;
    let serviceId = 0;
    let isApnChanged = false;
    const inputElements = {};
    let editMode = null;
    let editApnItem = null;
    let editType = null;

    const APN_PROPERTY_DEFAULTS = {
      carrier: '',
      apn: '',
      user: '',
      password: '',
      proxy: '',
      port: '',
      mmsc: '',
      mmsproxy: '',
      mmsport: '',
      authtype: 'notDefined',
      types: ['default'],
      protocol: 'notDefined',
      roaming_protocol: 'notDefined' //eslint-disable-line
    };

    const APN_PROPERTIES = Object.keys(APN_PROPERTY_DEFAULTS);

    const VALUE_CONVERTERS = {
      TO_STRING: {
        types(types) {
          if (types && Array.isArray(types) && types.length) {
            return types.join(', ');
          }
          return 'default';
        }
      },
      TO_DATA: {
        types(string) {
          return string.split(',').map(str => str.trim());
        }
      }
    };

    function updateSoftKey(enableSave) {
      if (typeof enableSave === Constants.UNDEFINED) {
        enableSave = checkMandatoryItems();
      }
      const params = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [
          {
            name: 'Cancel',
            l10nId: 'cancel',
            priority: 1,
            method() {
              openWarningDialog();
            }
          }
        ]
      };

      if (enableSave) {
        params.items.push({
          name: 'Save',
          l10nId: 'save',
          priority: 3,
          method() {
            onApnSave();
          }
        });
      }

      SettingsSoftkey.init(params);
      SettingsSoftkey.show();
    }

    function keyDownHandler(evt) {
      if (NavigationMap.currentActivatedLength > 0) {
        return;
      }

      if (evt.key === 'Backspace' || evt.key === 'EndCall') {
        evt.preventDefault();
        evt.stopPropagation();
        openWarningDialog();
      }
    }

    function checkMandatoryItems() {
      const name = elements.apnName.value;
      const type = elements.apnType.value;
      const carrier = elements.apnCarrier.value;

      return name !== '' && type !== '' && carrier !== '';
    }

    function backToPrevious() {
      Settings.isBackHref = true;
      Settings.setCurrentPanel('#apn_list', {
        serviceId,
        action: editMode
      });
    }

    const showApnChangeWarningDialog = () => {
      return new Promise(resolve => {
        const dialogConfig = {
          title: { id: 'confirmation', args: {} },
          body: { id: 'change-apn-warning-message', args: {} },
          desc: { id: 'change-apn-warning-question', args: {} },
          cancel: {
            name: 'Cancel',
            l10nId: 'cancel',
            priority: 1,
            callback() {
              resolve(false);
            }
          },
          confirm: {
            name: 'Ok',
            l10nId: 'ok',
            priority: 3,
            callback() {
              resolve(true);
            }
          }
        };
        DialogHelper.show(dialogConfig);
      });
    };

    function convertValue(value, converter) {
      if (converter) {
        return converter(value);
      }
      return value;
    }

    function exportApnSetting() {
      const newApnSetting = {};
      APN_PROPERTIES.forEach(name => {
        const inputElement = inputElements[name];
        if (inputElement && !inputElement.classList.contains('hidden')) {
          newApnSetting[name] = convertValue(
            inputElement.value,
            VALUE_CONVERTERS.TO_DATA[name]
          );
        }
      });
      return newApnSetting;
    }

    function onApnSave() {
      /*
       * Display the warning only when Data roaming is turned on and it is
       * the current APN in use that’s being edited.
       */
      Promise.all([
        ApnSettingsManager.getActiveApnId(serviceId, editType),
        new Promise(resolve => {
          SettingsDBCache.getSetting('ril.data.roaming_enabled').then(value => {
            resolve(value);
          });
        })
      ])
        .then(results => {
          const [activeApnId, dataRoamingEnabled] = results;
          if (activeApnId === editApnItem.id && dataRoamingEnabled) {
            return showApnChangeWarningDialog();
          }
          return true;
        })
        .then(result => {
          if (result) {
            if (editMode === 'new') {
              const newApnSetting = exportApnSetting();
              newApnSetting.types = [editType];
              ApnSettingsManager.addApn(serviceId, newApnSetting).then(() => {
                backToPrevious();
                ToastHelper.showToast('changessaved');
              });
            } else {
              const newApnSetting = exportApnSetting();
              ApnSettingsManager.updateApn(
                serviceId,
                editApnItem.id,
                newApnSetting
              ).then(() => {
                backToPrevious();
                ToastHelper.showToast('changessaved');
              });
            }
          }
        });
    }

    function openWarningDialog() {
      if (!isApnChanged) {
        backToPrevious();
        return;
      }

      const dialogConfig = {
        title: { id: 'confirmation', args: {} },
        body: { id: 'apn-editor-warning-body', args: {} },
        desc: { id: 'apn-editor-warning-desc', args: {} },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1
        },
        confirm: {
          name: 'Discard',
          l10nId: 'discard',
          priority: 3,
          callback() {
            backToPrevious();
          }
        }
      };

      if (checkMandatoryItems()) {
        dialogConfig.accept = {
          name: 'Save',
          l10nId: 'save',
          priority: 2,
          callback() {
            onApnSave();
          }
        };
      }

      DialogHelper.show(dialogConfig);
    }

    function setCursorToEnd(el) {
      const range = document.createRange();
      range.selectNodeContents(el);
      range.collapse(false);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      if (el.setSelectionRange) {
        el.setSelectionRange(el.value.length, el.value.length);
      }
    }

    function focusChange() {
      const input = elements.panel.querySelector('.focus input');
      if (input) {
        input.focus();
        if ('INPUT' === document.activeElement.tagName) {
          setCursorToEnd(document.activeElement);
        }
      }
    }

    function fillInputElements(apn) {
      APN_PROPERTIES.forEach(name => {
        if (inputElements[name]) {
          const value = apn[name] || APN_PROPERTY_DEFAULTS[name];
          inputElements[name].value = convertValue(
            value,
            VALUE_CONVERTERS.TO_STRING[name]
          );
        }
      });
    }

    function ApnChange() {
      isApnChanged = true;
    }

    function ObserveDMProtocol(protocol) {
      let hidden = true;
      if (!protocol) {
        // Is undefined/null/''
        hidden = false;
      }

      if (elements.protocolItem.classList.contains('hidden') !== hidden) {
        elements.protocolItem.classList.toggle('hidden', hidden);
        elements.roamingItem.classList.toggle('hidden', hidden);
        window.dispatchEvent(new CustomEvent('refresh'));
      }
    }

    return SettingsPanel({
      onInit: function onInit(panel, options) {
        elements = {
          panel,
          apnType: panel.querySelector('input.types'),
          apnCarrier: panel.querySelector('input.carrier'),
          apnName: panel.querySelector('input.apn'),
          protocolItem: panel.querySelector('#protocol-item'),
          roamingItem: panel.querySelector('#roaming-item')
        };

        APN_PROPERTIES.forEach(name => {
          inputElements[name] = panel.querySelector(`.${name}`);
        });

        listElements = panel.querySelectorAll('li');
        serviceId = options.serviceId || serviceId;
        isApnChanged = false;
        editMode = options.mode || 'new';
        editApnItem = options.item || {};
        editType = options.type || 'default';
        if (editMode === 'new') {
          editApnItem = {
            apn: {
              types: [editType]
            }
          };
          updateSoftKey(false);
        } else {
          updateSoftKey(true);
        }
        fillInputElements(editApnItem.apn);
      },

      onBeforeShow: function onBeforeShow() {
        ListFocusHelper.addEventListener(listElements, focusChange);
        window.addEventListener('keydown', keyDownHandler, true);
        SettingsDBCache.observe(DM_PROTOCOL, '', ObserveDMProtocol);
        elements.panel.addEventListener('input', ApnChange);
        elements.panel.addEventListener('change', ApnChange);

        elements.apnCarrier.addEventListener('input', updateSoftKey);
        elements.apnName.addEventListener('input', updateSoftKey);
        elements.apnType.addEventListener('input', updateSoftKey);
      },

      onBeforeHide: function onBeforeHide() {
        ListFocusHelper.removeEventListener(listElements, focusChange);
        window.removeEventListener('keydown', keyDownHandler, true);
        SettingsDBCache.unobserve(DM_PROTOCOL, ObserveDMProtocol);
        elements.panel.removeEventListener('input', ApnChange);
        elements.panel.removeEventListener('change', ApnChange);

        elements.apnCarrier.removeEventListener('input', updateSoftKey);
        elements.apnName.removeEventListener('input', updateSoftKey);
        elements.apnType.removeEventListener('input', updateSoftKey);
      }
    });
  };
});
