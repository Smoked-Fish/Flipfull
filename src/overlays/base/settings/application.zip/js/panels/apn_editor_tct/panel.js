'use strict';
define(function(require) { //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  const ApnSettingsManager = require('modules/apn_tct/apn_settings_manager');
  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3537,
  //Development apn editor feature
  const ApnUtils = require('modules/apn_tct/apn_utils');
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3537,

  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3537,
  //Development apn editor feature
  function log(msg) {
      dump('TctApn: apn_editor_tct: ' + msg);
  }
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3537,

  return function apnEditorPanel() {
    const DM_PROTOCOL = 'dm.apnSettings.protocol';
    let elements = null;
    let listElements = null;
    let serviceId = 0;
    let isApnChanged = false;
    const inputElements = {};
    let editMode = null;
    let editApnItem = null;
    let editType = null;
    //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4303,
    //Restructure apn editor code and optimize feature
    let editable = false;
    //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4303,

    const APN_PROPERTY_DEFAULTS = {
      carrier: '',
      apn: '',
      user: '',
      password: '',
      proxy: '',
      port: '',
      mmsc: '',
      mmsproxy: '',
      mmsport: '',
      authtype: 'notDefined',
      types: ['default'],
      protocol: 'notDefined',
      roaming_protocol: 'notDefined', //eslint-disable-line
      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,02/06/2024,GF7TF-4794,GF7TF-4879
      //Add MCC MNC MVNO_TYPE MVNO_MATCH_DATA items
      mcc: '',
      mnc: '',
      mvno_type: 'notDefined',
      mvno_match_data: ''
      //bearer:''
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-4794,GF7TF-4879
    };

    const APN_PROPERTIES = Object.keys(APN_PROPERTY_DEFAULTS);

    const VALUE_CONVERTERS = {
      TO_STRING: {
        types(types) {
          if (types && Array.isArray(types) && types.length) {
            return types.join(', ');
          }
          return 'default';
        }
      },
      TO_DATA: {
        types(string) {
          return string.split(',').map(str => str.trim());
        }
      }
    };

    function updateSoftKey(enableSave) {

      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,10/14/2024,GF5GTMO-4611,
      //APN can be saved when name or APN is empty
      //enableSave={"isTrusted":true}
      let enableSaveType = typeof enableSave;
      log('updateSoftKey: enableSaveType=' + enableSaveType + ' enableSave=' + JSON.stringify(enableSave));
      if (enableSaveType != 'boolean' && enableSaveType != 'string') {
        enableSave = checkMandatoryItems();
      }
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4611,

      if (typeof enableSave === Constants.UNDEFINED) {
        enableSave = checkMandatoryItems();
      }
      const params = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [
          {
            name: 'Cancel',
            l10nId: 'cancel',
            priority: 1,
            method() {
              openWarningDialog();
            }
          }
        ]
      };

      if (enableSave) {
        params.items.push({
          name: 'Save',
          l10nId: 'save',
          priority: 3,
          method() {
            onApnSave();
          }
        });
      }

      SettingsSoftkey.init(params);
      SettingsSoftkey.show();
    }

    function keyDownHandler(evt) {
      if (NavigationMap.currentActivatedLength > 0) {
        return;
      }

      if (evt.key === 'Backspace' || evt.key === 'EndCall') {
        evt.preventDefault();
        evt.stopPropagation();
        openWarningDialog();
      }
    }

    function checkMandatoryItems() {
      const name = elements.apnName.value;
      const type = elements.apnType.value;
      const carrier = elements.apnCarrier.value;

      return name !== '' && type !== '' && carrier !== '';
    }

    function backToPrevious() {
      //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4303,
      //Restructure apn editor code and optimize feature
      log('backToPrevious: serviceId=' + serviceId + ' editMode=' + editMode + ' editable=' + editable);

      Settings.isBackHref = true;
      Settings.setCurrentPanel('#apn_list_tct', {
        serviceId,
        action: editMode,
        editable: editable
      });
      /**
      Settings.setCurrentPanel('#apn_list', {
        serviceId,
        action: editMode
      });
      **/
      //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-4303,
    }

    const showApnChangeWarningDialog = () => {
      return new Promise(resolve => {
        const dialogConfig = {
          title: { id: 'confirmation', args: {} },
          body: { id: 'change-apn-warning-message', args: {} },
          desc: { id: 'change-apn-warning-question', args: {} },
          cancel: {
            name: 'Cancel',
            l10nId: 'cancel',
            priority: 1,
            callback() {
              resolve(false);
            }
          },
          confirm: {
            name: 'Ok',
            l10nId: 'ok',
            priority: 3,
            callback() {
              resolve(true);
            }
          }
        };
        DialogHelper.show(dialogConfig);
      });
    };

    function convertValue(value, converter) {
      if (converter) {
        return converter(value);
      }
      return value;
    }

    function exportApnSetting() {
      const newApnSetting = {};
      APN_PROPERTIES.forEach(name => {
        const inputElement = inputElements[name];
        if (inputElement && !inputElement.classList.contains('hidden')) {
          newApnSetting[name] = convertValue(
            inputElement.value,
            VALUE_CONVERTERS.TO_DATA[name]
          );
        }
      });
      return newApnSetting;
    }

    function onApnSave() {
      /*
       * Display the warning only when Data roaming is turned on and it is
       * the current APN in use that’s being edited.
       */
      Promise.all([
        ApnSettingsManager.getActiveApnId(serviceId, editType),
        new Promise(resolve => {
          SettingsDBCache.getSetting('ril.data.roaming_enabled').then(value => {
            resolve(value);
          });
        })
      ])
        .then(results => {
          const [activeApnId, dataRoamingEnabled] = results;
          if (activeApnId === editApnItem.id && dataRoamingEnabled) {
            return showApnChangeWarningDialog();
          }
          return true;
        })
        .then(result => {
          if (result) {
            if (editMode === 'new') {
              const newApnSetting = exportApnSetting();

              //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,11/13/2024,GF5GTMO-5277,
              //Implement feature to update non default apn to data call
              log("commitNew: serviceId=" + serviceId + " editType=" + editType
                  + ' newApnSetting=' + JSON.stringify(newApnSetting));
              //newApnSetting.types = [editType];
              if (!newApnSetting.types || !Array.isArray(newApnSetting.types) || newApnSetting.types.length < 1) {
                  log("commitNew: apnType is empty set apnType to " + editType);
                  newApnSetting.types = [editType];
              }
              //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-5277,

              ApnSettingsManager.addApn(serviceId, newApnSetting).then(() => {
                backToPrevious();
                ToastHelper.showToast('changessaved');
              });
            } else {
              const newApnSetting = exportApnSetting();

              //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,10/16/2023,GF7TF-3658,
              let hasXcap = newApnSetting.types.indexOf('xcap') !== -1;
              let apnType = localStorage.getItem('apn_editor_apn_type', '');
              log("commitEdit: newApnSetting=" + newApnSetting + " hasXcap=" + hasXcap + " apnType=" + apnType);
              if (apnType.indexOf('xcap') !== -1 && !hasXcap) {
                  newApnSetting.types = newApnSetting.types + ',xcap';
              }
              //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-3658,

              //[BUGFIX]Add-BEGIN by yelee,GF7TF-4879,2024/02/21
              let bearerString = newApnSetting.bearer;
              log("commitEdit: bearerString=" + newApnSetting.bearer);
              newApnSetting.bearer = ApnUtils.convertNetworkTypeToBearer(bearerString);
              log("commitEdit: newApnSetting.bearer=" + newApnSetting.bearer);
              //[BUGFIX]Add-END by yelee,GF7TF-4879,2024/02/21

              ApnSettingsManager.updateApn(
                serviceId,
                editApnItem.id,
                newApnSetting
              ).then(() => {
                backToPrevious();
                ToastHelper.showToast('changessaved');
              });
            }
          }
        });
    }

    function openWarningDialog() {
      if (!isApnChanged) {
        backToPrevious();
        return;
      }

      const dialogConfig = {
        title: { id: 'confirmation', args: {} },
        body: { id: 'apn-editor-warning-body', args: {} },
        desc: { id: 'apn-editor-warning-desc', args: {} },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1
        },
        confirm: {
          name: 'Discard',
          l10nId: 'discard',
          priority: 3,
          callback() {
            backToPrevious();
          }
        }
      };

      if (checkMandatoryItems()) {
        dialogConfig.accept = {
          name: 'Save',
          l10nId: 'save',
          priority: 2,
          callback() {
            onApnSave();
          }
        };
      }

      DialogHelper.show(dialogConfig);
    }

    function setCursorToEnd(el) {
      const range = document.createRange();
      range.selectNodeContents(el);
      range.collapse(false);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      if (el.setSelectionRange) {
        el.setSelectionRange(el.value.length, el.value.length);
      }
    }

    function focusChange() {
      const input = elements.panel.querySelector('.focus input');
      if (input) {
        input.focus();
        if ('INPUT' === document.activeElement.tagName) {
          setCursorToEnd(document.activeElement);
        }
      }
    }

    //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3537,
    //Development apn editor feature
    function fillInputElementsNoneEditable(apnItem, editable) {

      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,02/06/2024,GF7TF-4794,
      //Add MCC MNC MVNO_TYPE MVNO_MATCH_DATA items
      let iccInfo = ApnUtils.getIccInfo(serviceId);
      let mcc = iccInfo && iccInfo.mcc;
      let mnc = iccInfo && iccInfo.mnc;
      let gid1 = iccInfo && iccInfo.gid1;
      mcc = mcc || '000';
      mnc = mnc || '00';
      gid1 = (gid1 === undefined || gid1 == null || gid1 == '') ? '' : gid1 + '';
      gid1 = gid1.toLowerCase();
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-4794,

      let isVzwSim = ApnUtils.isVzwCard(serviceId);
      let isTfSim = ApnUtils.isTfSim(serviceId);
      let isUsccSim = ApnUtils.isUsccCard(serviceId);
      log('fillInputElementsNoneEditable: serviceId=' + serviceId + ' mccmnc=' + mcc + mnc + ' gid1=' + gid1
          + ' isVzwSim=' + isVzwSim + ' isTfSim=' + isTfSim + ' isUsccSim=' + isUsccSim
          + ' iccInfo=' + JSON.stringify(iccInfo));

      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,10/16/2023,GF7TF-3658,
      localStorage.setItem('apn_editor_apn_type', '');
      let category = apnItem.category + '';
      let isPresetApn = category.indexOf('preset') != -1;
      let bearer = 0;  //[BUGFIX]Add by yelee,GF7TF-4879,2024/02/19
      if (apnItem) {
        if (apnItem.apn) {
          bearer = apnItem.apn.bearer;
        }
      }
      log('fillInputElementsNoneEditable: editable=' + editable + ' isPresetApn=' + isPresetApn
          + ' category=' + category + ' bearer=' + bearer);
      log('fillInputElementsNoneEditable: apnItem=' + JSON.stringify(apnItem) + ' bearer=' + bearer);
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-3658,

      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/24/2024,GF5GTMO-4321,
      //Hide save option when all APN parameters are disabled
      let enableSave = false;
      let enableItem = function(inputElement, enabled) {
        ApnUtils.setApnNodeEnabled(inputElement, enabled);
        if (enabled == true) {
          enableSave = true;
        }
      };
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,09/24/2024,GF5GTMO-4321,

      APN_PROPERTIES.forEach(name => {
        const inputElement = inputElements[name];
        if (inputElement) {
          //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4303,
          //Restructure apn editor code and optimize feature
          let menuItem = inputElement.closest('[role="menuitem"]');
          //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4303,

          if ((apnItem.category == 'preset' || isUsccSim) && editable !== 'true' ) { // [SPRINT:GTR-DATA-00220] Task10117204-lijuan.li@tcl.com
              //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,03/11/2024,GF7TF-4854,
              //The UI display format is not uniformed for each field.
              //inputElement.setAttribute('disabled', 'disabled');
              enableItem(inputElement, false);
              //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF7TF-4854,
          } else {
              //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,03/11/2024,GF7TF-4854,
              //The UI display format is not uniformed for each field.
              //inputElement.removeAttribute('disabled', 'disabled');
              enableItem(inputElement, true);
              //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF7TF-4854,
          }

          if (name === 'apn') {
            // [SPRINT:GTR-DATA-00220] Task10117204-lijuan.li@tcl.com
            if (isVzwSim && editable !== 'true') {
              //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,03/11/2024,GF7TF-4854,
              //The UI display format is not uniformed for each field.
              //inputElement.removeAttribute('disabled', 'disabled');
              enableItem(inputElement, true);
              //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF7TF-4854,
            }
          }

          if (name === 'carrier') {
            // Task11024288-lijuan.li@tcl.com-begin
            if (isUsccSim && editable !== 'true') {
              //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,03/11/2024,GF7TF-4854,
              //The UI display format is not uniformed for each field.
              //inputElement.removeAttribute('disabled', 'disabled');
              enableItem(inputElement, true);
              //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF7TF-4854,
            }
            // Task11024288-lijuan.li@tcl.com-end
          }

          //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,10/16/2023,GF7TF-3658,
          //const value = apn[name] || APN_PROPERTY_DEFAULTS[name];
          let initValue = (apnItem.apn && apnItem.apn[name.toLowerCase()]) || APN_PROPERTY_DEFAULTS[name];
          let value = initValue;

          if (name === 'types') {
            //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4303,
            //Restructure apn editor code and optimize feature
            ApnUtils.setNodeVisible(menuItem, true);
            //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4303,

            if (isPresetApn && isTfSim) {
              let valueStr = value + '';
              if (valueStr.indexOf(',xcap') != -1) {
                value = valueStr.replace(',xcap', '').split(',');
                localStorage.setItem('apn_editor_apn_type', valueStr);
              } else if (valueStr.indexOf('xcap,') != -1) {
                value = valueStr.replace('xcap,', '').split(',');
                localStorage.setItem('apn_editor_apn_type', valueStr);
              }
              let apnType = localStorage.getItem('apn_editor_apn_type', '');
            }
          }
          //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF7TF-3658,

          //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,12/05/2023,GF7TF-4131,
          //The protocol is showed as notdefined
          if (name == 'protocol' || name == 'roaming_protocol') {
              value = ApnUtils.covertProtocol(value);
          }
          if (name == 'authtype') {
              value = ApnUtils.convertAuthType(value);
          }
          //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-4131,

          //[BUGFIX]-Add-BEGIN by GCCSZ.kaiyun.yan,12/10/2023,GF7TF-4405,
          ApnUtils.handleOptions(inputElement, name, value);
          //[BUGFIX]-Add-END by GCCSZ.kaiyun.yan,GF7TF-4405,

          //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,02/06/2024,GF7TF-4794,
          //Add MCC MNC MVNO_TYPE MVNO_MATCH_DATA items
          if (name == 'mcc') {
              value = value || mcc;
          } else if (name == 'mnc') {
              value = value || mnc;
          } else if (name == 'mvno_type') {
              if (value !== undefined && value != null && value != '' && value != 'notDefined') {
                  value = (value + '').toLowerCase();
              }
          } else if (name == 'bearer') {  //[BUGFIX]Add by yelee,GF7TF-4879,2024/02/19
              if(value && isNaN(value)) {
                value = ApnUtils.stringToBearer(value);
              }
              let bearerString = ApnUtils.bitmaskToString(value);
              value = ApnUtils.bitmaskToRatString(bearerString) || bearer;
          }
          //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-4794,

          let enabled;
          let visible;
          if (menuItem) {
            enabled = !menuItem.hasAttribute('disabled');
            visible = menuItem.classList && !menuItem.classList.contains('hidden');
          }
          log("fillInputElementsNoneEditable: name=" + name + ' value=' + value + ' initValue=' + initValue
              + ' enabled=' + enabled + ' visible=' + visible + ' menuItem=' + menuItem);

          inputElement.value = convertValue(
            value,
            VALUE_CONVERTERS.TO_STRING[name]
          );
        }
      });

      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/24/2024,GF5GTMO-4321,
      //Hide save option when all APN parameters are disabled
      log('fillInputElementsNoneEditable: enableSave=>' + enableSave);
      updateSoftKey(enableSave);
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4321,

    }
    //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3537,

    function fillInputElements(apn) {
      log('fillInputElements: apn=' + JSON.stringify(apn));
      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,02/06/2024,GF7TF-4794,
      //Add MCC MNC MVNO_TYPE MVNO_MATCH_DATA items
      let iccInfo = ApnUtils.getIccInfo(serviceId);
      let mcc = iccInfo && iccInfo.mcc;
      let mnc = iccInfo && iccInfo.mnc;
      let gid1 = iccInfo && iccInfo.gid1;
      let bearer = '0';
      mcc = mcc || '000';
      mnc = mnc || '00';
      gid1 = (gid1 === undefined || gid1 == null || gid1 == '') ? '' : gid1 + '';
      gid1 = gid1.toLowerCase();
      log('fillInputElements: serviceId=' + serviceId + ' mccmnc=' + mcc + mnc + ' gid1=' + gid1
          + ' iccInfo=' + iccInfo + ' bearer=' + bearer);
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7TF-4794,

      APN_PROPERTIES.forEach(name => {
        const inputElement = inputElements[name];
        //if (inputElements[name]) {
        if (inputElement) {
          //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4303,
          //Restructure apn editor code and optimize feature
          let menuItem = inputElement.closest('[role="menuitem"]');
          //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4303,

          //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,03/11/2024,GF7TF-4854,
          //The UI display format is not uniformed for each field.
          //inputElement.removeAttribute('disabled');
          ApnUtils.setApnNodeEnabled(inputElement, true);
          //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF7TF-4854,

          //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,02/06/2024,GF7TF-4794,
          //Add MCC MNC MVNO_TYPE MVNO_MATCH_DATA items
          /**
          const value = apn[name] || APN_PROPERTY_DEFAULTS[name];
          **/
          let value =
            (apn && apn[name.toLowerCase()]) || APN_PROPERTY_DEFAULTS[name];

          if (name == 'mcc') {
              value = mcc;
          } else if (name == 'mnc') {
              value = mnc;
          } else if (name == 'mvno_type') {
              if (gid1 != '') {
                  value = 'gid';
              }
          } else if (name == 'mvno_match_data') {
              if (gid1 != '') {
                  value = gid1;
              }
          } else if (name == 'bearer') {
              if (bearer != '') {
                  value = bearer;
              }
          } else if (name == 'types') {
            //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4303,GF5GTMO-6017
            //Restructure apn editor code and optimize feature
            //if (editable == 'true') {
                ApnUtils.setNodeVisible(menuItem, true);
            //}
            //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4303,GF5GTMO-6017
          }

          inputElement.value = convertValue(
            value,
            VALUE_CONVERTERS.TO_STRING[name]
          );
          /**
          inputElements[name].value = convertValue(
            value,
            VALUE_CONVERTERS.TO_STRING[name]
          );
          **/
          //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF7TF-4794,
        }
      });
    }

    function ApnChange() {
      isApnChanged = true;
    }

    function ObserveDMProtocol(protocol) {
      let hidden = true;
      if (!protocol) {
        // Is undefined/null/''
        hidden = false;
      }
      if (elements.protocolItem.classList.contains('hidden') !== hidden) {
        elements.protocolItem.classList.toggle('hidden', hidden);
        elements.roamingItem.classList.toggle('hidden', hidden);
        window.dispatchEvent(new CustomEvent('refresh'));
      }
    }

    return SettingsPanel({
      onInit: function onInit(panel, options) {
        elements = {
          panel,
          apnType: panel.querySelector('input.types'),
          apnCarrier: panel.querySelector('input.carrier'),
          apnName: panel.querySelector('input.apn'),
          protocolItem: panel.querySelector('#protocol-item'),
          roamingItem: panel.querySelector('#roaming-item')
        };

        APN_PROPERTIES.forEach(name => {
          inputElements[name] = panel.querySelector(`.${name}`);
        });

        listElements = panel.querySelectorAll('li');
        serviceId = options.serviceId || serviceId;
        isApnChanged = false;
        editMode = options.mode || 'new';
        editApnItem = options.item || {};
        editType = options.type || 'default';

        //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3537,
        //Development apn editor feature
        editable = options.editable == 'true' ? 'true' : 'false';
        log('onInit: editMode=' + editMode + ' editable=' + editable + ' editType=' + editType
            + ' serviceId=' + serviceId);
        if (editMode === 'new') {
          //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,10/16/2024,GF5GTMO-4615,
          //The new added APN cannot be selected
          if (editType == '*') {
            editType = 'default';
          }
          //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-4615,
          editApnItem = {
            apn: {
              types: [editType]
            }
          };
          updateSoftKey(false);
          fillInputElements(editApnItem.apn);
        } else {
          updateSoftKey(true);
          fillInputElementsNoneEditable(editApnItem, editable);
        }
        //fillInputElements(editApnItem.apn);
        //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-3537,
      },

      onBeforeShow: function onBeforeShow() {
        ListFocusHelper.addEventListener(listElements, focusChange);
        window.addEventListener('keydown', keyDownHandler, true);
        SettingsDBCache.observe(DM_PROTOCOL, '', ObserveDMProtocol);
        elements.panel.addEventListener('input', ApnChange);
        elements.panel.addEventListener('change', ApnChange);

        elements.apnCarrier.addEventListener('input', updateSoftKey);
        elements.apnName.addEventListener('input', updateSoftKey);
        elements.apnType.addEventListener('input', updateSoftKey);
      },

      onBeforeHide: function onBeforeHide() {
        ListFocusHelper.removeEventListener(listElements, focusChange);
        window.removeEventListener('keydown', keyDownHandler, true);
        SettingsDBCache.unobserve(DM_PROTOCOL, ObserveDMProtocol);
        elements.panel.removeEventListener('input', ApnChange);
        elements.panel.removeEventListener('change', ApnChange);

        elements.apnCarrier.removeEventListener('input', updateSoftKey);
        elements.apnName.removeEventListener('input', updateSoftKey);
        elements.apnType.removeEventListener('input', updateSoftKey);
      }
    });
  };
});
