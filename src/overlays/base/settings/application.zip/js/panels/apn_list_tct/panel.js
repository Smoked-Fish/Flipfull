/**
 * The apn list panel
 */

'use strict';
define(function(require) { //eslint-disable-line
  const ListView = require('modules/mvvm/list_view');
  const SettingsPanel = require('modules/settings_panel');
  const ApnSettingsManager = require('modules/apn_tct/apn_settings_manager');
  const ApnTemplateFactory = require('panels/apn_list_tct/apn_template_factory');
  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3542,
  //Development apn list feature
  const ApnUtils = require('modules/apn_tct/apn_utils');
  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,GF5GTMO-3542,

  return function createApnSettingsPanel() {
    let focusId = 0;
    //[Bugfix]Add-BEGIN by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13
    let preFocusId = -1;
    let preFocusItemId = null;
    //[Bugfix]Add-END by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13
    const itemsOBJ = {};
    let serviceIdNum = 0;
    let apnType = 'default';
    let rootElement = null;
    let mainHeader = null;
    let header = null;
    let apnListViewRoot = null;
    let apnListView = null;
    let role = null;
    let listElements = [];

    //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3524,
    //Development apn settings feature
    let self;
    let initOptions;
    let editable = false;
    let operator = '';
    let queryOptions = {};
    //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3524,

    const HEADER_L10N_MAP = {
      default: 'dataSettings-header',
      mms: 'messageSettings-header',
      ims: 'imsSettings-header2',
      supl: 'suplSettings-header',
      dun: 'dunSettings-header'
    };

    const returnTop = () => {
      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-3715,
      //apn selection feature development
      log('returnTop: apnType=' + apnType);
      if (!apnType || apnType == '*') {
        Settings.setCurrentPanel('#carrier');
        return;
      }
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3715,
      Settings.setCurrentPanel('#apn_settings_tct');
    };

    const onApnItemEdit = focusItem => {
      //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3524,
      //Development apn settings feature
      /**
      Settings.setCurrentPanel('#apn_editor_tct', {
        mode: 'edit',
        serviceId: serviceIdNum,
        type: apnType,
        item: focusItem
      });
      **/
      log('onApnItemEdit: serviceIdNum=' + serviceIdNum + ' apnType=' + apnType
          + ' editable=' + editable + ' focusItem=' + JSON.stringify(focusItem));
      Settings.setCurrentPanel('#apn_editor_tct', {
        mode: 'edit',
        serviceId: serviceIdNum,
        type: apnType,
        item: focusItem,
        editable: editable
      });
      //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-3524,
    };

    //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3543,
    //Development apn list feature
    const onApnItemMoreInfo = focusItem => {
      Settings.setCurrentPanel('#apn_editor_tct', {
        mode: 'info',
        serviceId: serviceIdNum,
        type: apnType,
        item: focusItem,
        editable: false
      });
    };
    //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-3543,

    const onApnItemDefaultSet = (serviceId, type, radio, focusItem) => {
      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4308,
      //Restructure apn settings manager code
      log('onApnItemDefaultSet: serviceId=' + serviceId + ' type=' + type + ' radio=' + radio);
      log('onApnItemDefaultSet: focusItem=' + JSON.stringify(focusItem));
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4308,

      const setActive = () => {
        focusItem.active = true;
        radio.checked = true;
        //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,11/13/2024,GF5GTMO-5277,
        //Implement feature to update non default apn to data call
        //ApnSettingsManager.setActiveApnId(serviceId, type, focusItem.id);
        ApnSettingsManager.setActiveApnId(serviceId, type, focusItem.id, { editable });
        //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-5277,
        ToastHelper.showToast('changessaved');
      };

      SettingsDBCache.getSetting('ril.data.roaming_enabled').then(value => {
        if (value === true) {
          // Only display the warning when roaming is enabled.
          setActive();
        } else {
          /*
           * XXX: We need to make this to the next tick to the UI gets updated
           * because we've prevented the default behavior in the handler.
           */
          setTimeout(() => {
            setActive();
          });
        }
      });
    };

    //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3524,
    //Development apn settings feature
    function log(msg) {
        dump('TctApn: apn_list_tct: ' + msg);
    }
    //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3524,

    //[BUGFIX]-Add-BEGIN by GCCSZ.kaiyun.yan,12/15/2023,GF7TF-4405,
    function sortDefaultApnItemAsTop(apnItems) {
        let apnItemsCount = Array.isArray(apnItems) ? apnItems.length : -1;
        if (apnItemsCount < 1) {
            return apnItems;
        }

        let defApnItems = [];
        let otherApnItems = [];
        for(let i = 0; i < apnItemsCount; i++) {
            let apnItem = apnItems[i];
            let apn = apnItem === undefined ? undefined : apnItem.itemApn;
            if (apn === undefined) {
                continue;
            }
            let types = apn.types;
            let isDefaultApn = Array.isArray(types) ? types.indexOf('default') >= 0 : false;
            if (isDefaultApn == true) {
                defApnItems.push(apnItem);
            } else {
                otherApnItems.push(apnItem);
            }
        }
        let retApnItems = Array.prototype.concat.apply(defApnItems, otherApnItems);
        log('sortDefaultApnItemAsTop: retApnItems=' + JSON.stringify(retApnItems));
        return retApnItems;
    }
    //[BUGFIX]-Add-END by GCCSZ.kaiyun.yan,GF7TF-4405,

    /**
     * Get the focused li element's index
     *
     */
    function getFocusPos(Element) {
      if (!Element) return -1;
      const liList = Element.querySelectorAll('li');
      for (let i = 0; i < liList.length; i++) {
        if (
          liList[i].classList.contains('focus') ||
          liList[i].classList.contains('focus1')
        ) {
          focusId = i;
          return focusId;
        }
      }
      return -1;
    }

    const onApnAddAction = (serviceId, type, root) => {
      focusId = getFocusPos(root);
      //[Bugfix]Add by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13
      preFocusItemId = rootElement.querySelector('.focus label').dataset.id;
      log('preFocusItemId: ' + preFocusItemId);
      //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3524,GF5GTMO-4618
      //Development apn settings feature
      /**
      Settings.setCurrentPanel('#apn_editor_tct', {
        mode: 'new',
        serviceId,
        type
      });
      **/
      Settings.setCurrentPanel('#apn_editor_tct', {
        mode: 'new',
        serviceId,
        type,
        editable: editable
      });
      //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-3524,GF5GTMO-4618
    };

    const onBackBtnClick = () => {
      log('onBackBtnClick: role=' + role + ' apnType=' + apnType);
      if (role === 'activity') {
        role = null;
        Settings.finishActivityRequest();
      } else {
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-3715,
        //apn selection feature development
        if (!apnType || apnType == '*') {
          Settings.setCurrentPanel('#carrier');
          return;
        }
        //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3715,
        Settings.setCurrentPanel('#apn_settings_tct');
      }
    };

    function registerSoftkey() {
      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3542,
      //Development apn list feature
      let isUsccSim = ApnUtils.isUsccCard(serviceIdNum);
      let isVzwSim = ApnUtils.isVzwCard(serviceIdNum);
      let isSpectrumSim = ApnUtils.isSpectrumSim(serviceIdNum);
      log('registerSoftkey: editable=' + editable + ' isUsccSim=' + isUsccSim
          + ' isVzwSim=' + isVzwSim + ' isSpectrumSim=' + isSpectrumSim);
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3542,

      const softkeyAdd = {
        name: 'Add Apn',
        l10nId: 'add-apn',
        priority: 1,
        method: () => {
          //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3542,
          //onApnAddAction(serviceIdNum, apnType, rootElement);
          //[BUGFIX]Mod by yelee for GF5GTMO-8471 on 2025/10/23
          const dataItemId = rootElement.querySelector('.focus label').dataset
              .id;
          log('registerSoftkey: dataItemId=' + dataItemId);
          if (isUsccSim && editable !== 'true' && dataItemId !== 'undefined') { // Task11024288-lijuan.li@tcl.com
              onApnItemMoreInfo(itemsOBJ[dataItemId]);
          } else {
              onApnAddAction(serviceIdNum, apnType, rootElement);
          }
          //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-3542,
        }
      };
      const softkeySelect = {
        name: 'Select',
        l10nId: 'select',
        priority: 2,
        method: () => {
          if (!rootElement.querySelector('.focus label')) {
            return;
          }
          const dataItemId = rootElement.querySelector('.focus label').dataset
            .id;
          const radioElement = rootElement.querySelector('.focus input');
          onApnItemDefaultSet(
            serviceIdNum,
            apnType,
            radioElement,
            itemsOBJ[dataItemId]
          );
          //[BUGFIX]Mod END by yelee,GF7TF-3547,2023/10/19
          //SettingsSoftkey.hide();
          //returnTop();
        }
      };
      const softkeyOption = [
        {
          name: 'Edit',
          l10nId: 'edit',
          priority: 7,
          method: () => {
            focusId = getFocusPos(rootElement);
            const dataItemId = rootElement.querySelector('.focus label').dataset
              .id;
            onApnItemEdit(itemsOBJ[dataItemId]);
          }
        },
        {
          name: 'Delete',
          l10nId: 'delete-apn',
          priority: 8,
          method: () => {
            const dataItemId = rootElement.querySelector('.focus label').dataset
              .id;
            const focusItem = itemsOBJ[dataItemId];
            const dialogConfig = {
              title: { id: 'confirmation', args: {} },
              body: {
                id: 'delete-apn-confirm',
                args: {
                  apnName: focusItem.apn.carrier
                }
              },
              cancel: {
                l10nId: 'cancel',
                priority: 1
              },
              confirm: {
                l10nId: 'delete-apn',
                priority: 3,
                callback: () => {
                  if (focusItem.apn.deletedCpApn === false) {
                    log('updateApn: serviceIdNum=' + serviceIdNum + ' apnId=' + focusItem.id
                        + ' focusItem=' + JSON.stringify(focusItem));
                    focusItem.apn.deletedCpApn = true;
                    ApnSettingsManager.updateApn(
                      serviceIdNum,
                      focusItem.id,
                      focusItem.apn
                    )
                      .then(() => {
                        onApnDelete(rootElement, focusItem.apn.carrier);
                      })
                      .then(() => {
                        updateUI();
                      });
                  } else {
                    log('removeApn: serviceIdNum=' + serviceIdNum + ' apnId=' + focusItem.id
                        + ' focusItem=' + JSON.stringify(focusItem));
                    ApnSettingsManager.removeApn(serviceIdNum, focusItem.id)
                      .then(() => {
                        onApnDelete(rootElement, focusItem.apn.carrier);
                      })
                      .then(() => {
                        updateUI();
                      });
                  }
                }
              }
            };
            DialogHelper.show(dialogConfig);
          }
        }
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3716
        //Add reset to default option to apn list
        ,{
            name: 'Reset to Default',
            l10nId: 'reset-apn',
            priority: 9,
            method() {
                resetApn();
            }
        }
        //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3716
      ];

      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3716
      //Add reset to default option to apn list
      const softkeyOption_resetApn = [
          {
              name: 'Reset to Default',
              l10nId: 'reset-apn',
              priority: 8,
              method() {
                  resetApn();
              }
          }
      ];
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3716

      const softkeyOption_moreInfo = [
          {
              name: 'More Info',
              l10nId: 'more-info',
              priority: 7,
              method: function() {
                  focusId = getFocusPos(rootElement);
                  const dataItemId=rootElement.querySelector('.focus label').dataset.id;
                  onApnItemMoreInfo(itemsOBJ[dataItemId]);
              }
          },
          {
              name: 'Reset to Default',
              l10nId: 'reset-apn',
              priority: 8,
              method() {
                  resetApn();
              }
          }
      ];

      //[BUGFIX]Add by yelee,GF7OM-966,2024/02/26
      const softkeyOption_moreInfo_noReset = [
          {
              name: 'More Info',
              l10nId: 'more-info',
              priority: 7,
              method: function() {
                  focusId = getFocusPos(rootElement);
                  const dataItemId=rootElement.querySelector('.focus label').dataset.id;
                  onApnItemMoreInfo(itemsOBJ[dataItemId]);
              }
          }
      ];

      const softkeyParams = {
        header: { l10nId: 'options' },
        items: []
      };
      let focusLabel = rootElement.querySelector('.focus label');
      if (!focusLabel) {
        focusLabel = rootElement.querySelector('li label');
      }
      //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,03/26/2024,GF7OM-1053,
      //User has the ability to add an APN.
      //softkeyParams.items.push(softkeyAdd);
      if ((!isVzwSim && !isSpectrumSim) || editable == 'true') {
          softkeyParams.items.push(softkeyAdd);
      }
      log('registerSoftkey: focusLabel=>' + focusLabel);
      if (!focusLabel) {
          log('registerSoftkey: focusLabel is ' + focusLabel + ', add softkeyOption_resetApn');
          //softkeyParams.items.push(softkeyOption_resetApn);
          softkeyParams.items.push.apply(softkeyParams.items, softkeyOption_resetApn);
      }
      //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF7OM-1053,

      if (focusLabel) {
        softkeyParams.items.push(softkeySelect);
        const dataItemId = focusLabel.dataset.id;
        const focusItem = itemsOBJ[dataItemId];
        //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,03/26/2024,GF7OM-1053,GF5GTMO-4322
        /**
        if (
          focusItem.itemCategory !== 'preset' ||
          focusItem.itemApn.carrier !== 'Jio 4G'
        ) {
          // eslint-disable-next-line
          softkeyParams.items.push.apply(softkeyParams.items, softkeyOption);
        }
        **/
        if (isSpectrumSim) {
          softkeyParams.items.push.apply(softkeyParams.items, softkeyOption_moreInfo_noReset);
          log('registerSoftkey: Spectrum require to remove Reset menu.');
        } else if (focusItem.itemCategory !== 'preset' || editable == 'true' || (operator === 'USCC' && !isUsccSim)) { // Task11024288-lijuan.li@tcl.com
          // eslint-disable-next-line
          softkeyParams.items.push.apply(softkeyParams.items, softkeyOption);
        } else if ((focusItem.itemCategory !== 'preset' || focusItem.itemApn.carrier !== 'Jio 4G')
            && editable == 'true') {
          // eslint-disable-next-line
          softkeyParams.items.push.apply(softkeyParams.items, softkeyOption);
        } else {
          softkeyParams.items.push.apply(softkeyParams.items, softkeyOption_moreInfo);
        }
        //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF7OM-1053,GF5GTMO-4322
      }
      SettingsSoftkey.init(softkeyParams);
    }

    //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-3716,
    //Add reset to default option to apn list
    function resetApnWarningDialog() {
        return new Promise(resolve => {
            const dialogConfig = {
                title: { id: 'apnSettings-reset', args: {} },
                body: { id: 'reset-apn-warning-message', args: {} },
                cancel: {
                    name: 'Cancel',
                    l10nId: 'cancel',
                    priority: 1,
                    callback() {
                        resolve(false);
                        DialogHelper.destroy();
                    }
                },
                confirm: {
                    name: 'Reset',
                    l10nId: 'reset-apn',
                    priority: 3,
                    callback() {
                        resolve(true);
                        DialogHelper.destroy();
                    }
                }
            };

            DialogHelper.show(dialogConfig);
        });
    }

    function resetApn() {
      log('resetApn: serviceIdNum=' + serviceIdNum);
      resetApnWarningDialog().then(result => {
        log('resetApn: result=' + result);
        if (result) {
          /**
          ApnSettingsManager.restore(serviceIdNum).then(() => {
            ToastHelper.showToast('apnSettings-reset-toast');
          });
          **/
          resetUserApn(serviceIdNum).then((result) => {
            if (!result) {
              restoreApnSettings();
            }
          });
        }
      });
    }

    function restoreApnSettings() {

      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-3722,
      //TypeError: mobileConnection is undefined
      let rootPanel = rootElement;
      log('restoreApnSettings: onBeforeShow: serviceIdNum=' + serviceIdNum
          + ' self=' + JSON.stringify(self) + ' rootPanel=' + JSON.stringify(rootPanel)
          + ' initOptions=' + JSON.stringify(initOptions));
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3722,

      ApnSettingsManager.restore(serviceIdNum).then(() => {
        ToastHelper.showToast('apnSettings-reset-toast');

        //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-3722,
        //TypeError: mobileConnection is undefined
        //self.onBeforeShow(rootPanel, new Object);
        if (self) {
          self.onBeforeShow(rootPanel, initOptions);
        }
        //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-3722,

      });
    }

    function resetUserApn(serviceId) {
      return new Promise((resolve, reject) => {
        SettingsObserver.getValue('ril.data.user.apn3.initialname').then((initialNames) => {
          log('resetUserApn: initialNames, value='+ JSON.stringify(initialNames));
          let connection = navigator.b2g.mobileConnections;
          if (!connection[0]) {
            dump('resetUserApn: connection get failed');
            resolve(false);
            return;
          }

          let iccId = connection[0].iccId;
          log('resetUserApn: iccid, value='+ JSON.stringify(iccId));
          if (!iccId) {
            resolve(false);
            return;
          }

          log('resetUserApn: start reset');
          SettingsObserver.getValue('ril.data.user.apn3updatename').then((userNames)=>{
            if (userNames && userNames[iccId]) {
              delete userNames[iccId];
              SettingsObserver.setValue([{
                name:'ril.data.user.apn3updatename',
                value: userNames}]);
            }
          });

          if (initialNames === undefined || initialNames == null || initialNames.length == 0) {
            log('resetUserApn: initialNames is null');
            resolve(false);
            return;
          }

          let initialName = initialNames[iccId];
          if (!initialName) {
            log('resetUserApn: initialName of iccid ' + iccId + "is null");
            resolve(false);
            return;
          }

          delete initialNames[iccId];
          SettingsObserver.setValue([{
            name:'ril.data.user.apn3.initialname',
            value: initialNames}]);

          SettingsObserver.getValue('ril.data.default.apns').then((defaultApns) => {
            log('resetUserApn: defaultApns, value='+ JSON.stringify(defaultApns));
            if (!defaultApns) {
              resolve(false);
              return;
            }

            const apnList = defaultApns[serviceId] || {};
            if (!apnList) {
              resolve(false);
              return;
            }

            for (const curApn of apnList) {
              if (curApn && curApn.class === '3' && curApn.apn != initialName) {
                log('resetUserApn: reset name to initial name, value='+ initialName);
                resolve(true);
                curApn.apn = initialName;
                SettingsObserver.setValue([{
                  name:'ril.data.default.apns',
                  value: defaultApns
                }]).then(() => {
                  restoreApnSettings();
                });
                log('resetUserApn: defaultApns after modify, value='+ JSON.stringify(defaultApns));
              }
            }
            resolve(false);
          });
        });
      });
    }
    //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3716,

    function updateSoftkey() {
      registerSoftkey();
      SettingsSoftkey.show();
    }

    function updateUI() {
      //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-3715,
      //apn selection feature development
      let focusPanel = 'apn_list';
      if (apnType == '*') {
        focusPanel = 'apn_list_tct';
      }
      log('updateUI: apnType=' + apnType + ' focusPanel=' + focusPanel
          + ' queryOptions=' + JSON.stringify(queryOptions));
      //ApnSettingsManager.queryApns(serviceIdNum, apnType).then(apnItems => {
      ApnSettingsManager.queryApns(serviceIdNum, apnType, queryOptions).then(apnItems => {
      //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,GF5GTMO-3715,

        let find = false;
        Object.keys(apnItems).forEach(key => {
          if (apnItems[key].active) {
            const activeApnItem = rootElement.querySelector(
              `[data-id="${apnItems[key].id}"]`
            );
            if (activeApnItem) {
              activeApnItem.querySelector('input').checked = true;

              //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-3715,
              //apn selection feature development
              /**
              ListFocusHelper.requestFocus(
                'apn_list',
                activeApnItem.parentNode
              );
              **/
              ListFocusHelper.requestFocus(
                focusPanel,
                activeApnItem.parentNode
              );
              //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-3715,

              find = true;
            }
          }
        });
        if (!find) {
          window.dispatchEvent(new CustomEvent('refresh'));
        }
      });
    }

    function getElementByType(type, root, id) {
      const liList = root.querySelectorAll('li');
      let i = 0;
      //[Bugfix]Add-BEGIN by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13
      if (type === 'edit' || type === 'info' || type === 'new' || (!type && preFocusId >= 0)) {
        for (; i < liList.length; i++) {
          if (i === id) {
            return liList[i];
          }
        }
      } else {
        for (; i < liList.length; i++) {
          const radio = liList[i].querySelector('input');
          if (radio.checked === true) {
            return liList[i];
          }
        }
      }
      return liList[0];
    }

    /*
     * After we deleted an apn , we should remove it from apn-list
     * and reset focus && navigation map && refresh softkeys
     */
    function onApnDelete(root, apnName) {
      return new Promise(resolve => {
        const focusElement = root.querySelector('li.focus');

        ListFocusHelper.removeEventListener(listElements, updateSoftkey);
        focusElement.parentNode.removeChild(focusElement);
        listElements = document.querySelectorAll('.apn-list li');
        ListFocusHelper.addEventListener(listElements, updateSoftkey);
        updateSoftkey();
        ToastHelper.showToast('apn-deleted', {
          apnName
        });
        resolve();
      });
    }

    //[Bugfix]Add-BEGIN by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13
    function requireFocus(needFocused) {
      if (needFocused && focusId > 0) {
        const items = rootElement.querySelectorAll('.apn-list li');
        if (items && items.length > 0) {
          items[0].classList.remove('focus', 'selected');
        }
        needFocused.classList.add('focus', 'selected');
        needFocused.focus();
        log('requireFocus: request focus to: ' + focusId);
      }
    }
    //[Bugfix]Add-END by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13

    return SettingsPanel({

      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4302,
      //Restructure apn list code and optimize feature
      //onInit: function onInit(panel) {
      onInit: function onInit(panel, options) {
        log('onInit: options=' + JSON.stringify(options));
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4302,

        rootElement = panel;
        mainHeader = rootElement.querySelector('gaia-header');
        header = mainHeader.querySelector('h1');
        apnListViewRoot = rootElement.querySelector('.apn-list');
        mainHeader.addEventListener('action', onBackBtnClick);
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-3716,
        //Add reset to default option to apn list
        self = this;
        //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3716,
      },

      //[Bugfix]Add-BEGIN by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13
      onShow: function onShow(panel, options) {
        const needFocused = getElementByType(
            options.action,
            rootElement,
            focusId
        );
        requireFocus(needFocused)
      },
      //[Bugfix]Add-BEGIN by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13

      onBeforeShow: function onBeforeShow(panel, options) {
        role = options.role || role;
        if (options.type) {
          focusId = 0;
        }
        //[Bugfix]Add-BEGIN by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13
        if (options.type === '*' && preFocusId > 0) {
          focusId = preFocusId;
        }
        //[Bugfix]Add-END by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3542,GF5GTMO-4302
        //Development apn list feature
        log('onBeforeShow: START: options=' + JSON.stringify(options));
        if (!options) {
          log('onBeforeShow: options is null, change to {}');
          options = {};
        }
        if (!options.serviceId) {
          log('onBeforeShow: options.serviceId is null, change to 0');
          options.serviceId = 0;
        }
        if (!options.type) {
          log('onBeforeShow: options.type is null, change to *');
          options.type = '*';
        }
        if (mainHeader) {
          let initBackPage = mainHeader.getAttribute('data-href');
          log('onBeforeShow: initBackPage=' + initBackPage + ' options.backPage=' + options.backPage);
          if (options.backPage && options.backPage != '') {
            if (options.backPage != initBackPage) {
              mainHeader.setAttribute('data-href', options.backPage);
            }
          }
          /**
          else if (options.type == '*') {
            if ('#carrier' != initBackPage) {
              mainHeader.setAttribute('data-href', '#carrier');
            }
          }
          **/
        }

        initOptions = options;
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,GF5GTMO-3542,GF5GTMO-4302

        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,11/06/2023,GF7TF-4103,
        let fromSecretCode = false;
        if(ActivityHandler.activitySource !== null && ActivityHandler.activitySource.data.editable === 'true') {
            log('onBeforeShow: launch by secret code!');
            editable = 'true';
            fromSecretCode = true;
        } else if (options.editable == true || options.editable == 'true') {
            log('onBeforeShow: options.editable is true');
            editable = 'true';
            fromSecretCode = true;
        }
        queryOptions.editable = editable;
        queryOptions.fromSecretCode = fromSecretCode;
        //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,11/06/2023,GF7TF-4103,

        /*
         * When back from apn editor, there is no type and serviceId specified
         * so that we use the original type and service id.
         */
        apnType = options.type || apnType;
        serviceIdNum =
          (options.serviceId === typeof options.serviceId) === 'undefined'
            ? serviceIdNum
            : options.serviceId;

        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,06/03/2024,GF7EE-1533,
        //APN settings listed as "Apn Settings" - NOK
        let mccmnc = '';
        let iccCard;
        let iccInfo;
        try {
            iccCard = SimCardHelper.getIccInfo(serviceIdNum);
            iccInfo = iccCard && iccCard.iccInfo;
            if (iccInfo) {
                mccmnc = iccInfo.mcc + '' + iccInfo.mnc;
            }
        } catch (e) {
            log('onBeforeShow: Exception=' + JSON.stringify(e));
        }
        let titleResName = HEADER_L10N_MAP[apnType];
        if ('23430' == mccmnc || '23433' == mccmnc) {
            //titleResName = 'apn-list-title-new';
        } else if ('*' == apnType) {
            titleResName = 'apnSettings-header';
        } else {
            titleResName = HEADER_L10N_MAP[apnType];
        }
        //header.setAttribute('data-l10n-id', HEADER_L10N_MAP[apnType]);
        header.setAttribute('data-l10n-id', titleResName);
        //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF7EE-1533,

        const apnTemplate = ApnTemplateFactory(apnType, null, null, itemsOBJ);


        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3524,
        //Development apn settings feature
        let promises = [];
        promises.push(ApnSettingsManager.queryApns(serviceIdNum, apnType, queryOptions));
        promises.push(navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name'));
        promises.push(navigator.b2g.engmodeManager.getPropertyValue('ro.product.model'));

        log('onBeforeShow: serviceIdNum=' + serviceIdNum + ' apnType=' + apnType
            + ' editable=' + editable + ' fromSecretCode=' + fromSecretCode
            + ' mccmnc=' + mccmnc + ' titleResName=' + titleResName + ' mainHeader=' + mainHeader
            + ' options=' + JSON.stringify(options) + ' queryOptions=' + JSON.stringify(queryOptions));
        log('onBeforeShow: Promise.all=' + promises.length);
        //ApnSettingsManager.queryApns(serviceIdNum, apnType).then(apnItems => {
        Promise.all(promises).then(result => {
          let apnItems = result[0];
          let apnItemsCount = Array.isArray(apnItems) ? apnItems.length : -1;

          // Task11024288-lijuan.li@tcl.com
          operator = result[1];

          //[BUGFIX]-Add-BEGIN by GCSSZ.fen-li,01/04/2024, GF7VZW-7531,
          let model = result[2];
          let isVoiceOnlyDevice = false;
          if (model === 'T435V') {
            isVoiceOnlyDevice = true;
          }
          //[BUGFIX]-Add-END by GCSSZ.fen-li,01/04/2024, GF7VZW-7531,

          log('onBeforeShow: queryApns: apnItemsCount=' + apnItemsCount + ' operator=' + operator
              + ' model=' + model + ' isVoiceOnlyDevice=' + isVoiceOnlyDevice);
        //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3524,

          updateSoftkey();

          //[BUGFIX]-Mod-BEGIN by GCCSZ.kaiyun.yan,12/15/2023,GF7TF-4405,GF7TF-4103,GF7VZW-7531
          //const filterapnItems = apnItems.filter(apnItem => {
          let filterapnItems = apnItems.filter(apnItem => {
            //return apnItem.apn.deletedCpApn !== true;
            let apn = apnItem.apn;
            let apnTypes = apn && apn.types;
            let isVisible = fromSecretCode ? true : apn.user_visible != 'false';
            let ret = apn.deletedCpApn !== true && isVisible && (!isVoiceOnlyDevice || apnItem.apn.types.indexOf('default') === -1);
            //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-3715,
            //apn selection feature development
            if (apnTypes && apnTypes.indexOf('default') >= 0) {
              apnItem.selectable = true;
            } else {
              apnItem.selectable = false;
            }
            log('onBeforeShow: ret=' + ret + ' isVisible=' + isVisible
                + ' user_visible=' + apn.user_visible
                + ' apnItem=' + JSON.stringify(apnItem));
            //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3715,
            return ret;
          });

          filterapnItems = sortDefaultApnItemAsTop(filterapnItems);

          //[Bugfix]Mod-BEGIN by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13
          let preFocusItemPos = 0;
          filterapnItems.forEach(apn => {
            if (options.action === 'new' && preFocusItemId && apn && apn.itemId === preFocusItemId) {
              focusId = preFocusItemPos;
              log('item[' + focusId + '] matched preFocusItem: ' + preFocusItemId);
              preFocusItemId = null;
            }
            preFocusItemPos++;
          });
          //[Bugfix]Mod-END by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13
          //[BUGFIX]-Mod-END by GCCSZ.kaiyun.yan,GF7TF-4405,GF7TF-4103,GF7VZW-7531

          apnListView = ListView(apnListViewRoot, filterapnItems, apnTemplate);
          const needFocused = getElementByType(
            options.action,
            rootElement,
            focusId
          );
          ListFocusHelper.requestFocus(rootElement, needFocused);
          listElements = document.querySelectorAll('.apn-list li');
          ListFocusHelper.addEventListener(listElements, updateSoftkey);
          updateSoftkey();
        });
      },

      onBeforeHide: function onBeforeHide() {
        ListFocusHelper.removeEventListener(listElements, updateSoftkey);
      },

      onHide: function onHide() {
        //[Bugfix]Mod by yafangwei, GF5GTMO-6174, Fix focus issue, 2025/02/13
        preFocusId = getFocusPos(rootElement);
        if (apnListView) {
          apnListView.destroy();
          apnListView = null;
        }
      }
    });
  };
});
