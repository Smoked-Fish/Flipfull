/* global AppOrigin */
'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  const AppStorageList = require('panels/app_storage/app_storage_list');

  return function createAppStoragePanel() {
    let elements = null;
    let systemCleaning = false;
    let otherCleaning = false;
    const AppStorageListModule = AppStorageList();

    const params = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [
        {
          name: 'Open',
          l10nId: 'open',
          priority: 2,
          method() {
            const li = document.querySelector('li.focus');
            const url = AppStorageListModule.appList[li.index].manifestUrl;
            window.open(url, '_blank', 'kind=app,noopener=yes');
            if (ActivityHandler.currentActivity) {
              ActivityHandler.postResult();
            }
          }
        },
        {
          name: 'Clean',
          l10nId: 'clean',
          priority: 3,
          method() {
            showDialog();
          }
        }
      ]
    };

    function updateDisplay(app) {
      if (!systemCleaning && !otherCleaning) {
        AppStorageListModule.updateAppSize(app);
      }
    }

    function closeApps(manifestUrl) {
      ActivityHelper.start({
        name: 'app-data-clean',
        data: {
          manifestURL: manifestUrl,
          killOnly: false
        }
      });
    }

    function clearSmsData(app) {
      const msgList = [];
      const iterable = ApiManager.messageManager
        .getMessages(null, false)
        .values();

      function circleMap() {
        iterable.next().then(result => {
          if (!result.done) {
            msgList.push(result.value);
            circleMap();
          } else {
            ApiManager.messageManager.delete(msgList);
            otherCleaning = false;
            updateDisplay(app);
          }
        });
      }
      circleMap();
    }

    function cleanOtherData(app) {
      if (app.manifestUrl === AppOrigin.getManifestURL('contact')) {
        otherCleaning = true;
        ApiManager.contactsManager.clear().then(
          () => {
            DebugHelper.debug('Contacts clean success');
            otherCleaning = false;
            updateDisplay(app);
          },
          err => {
            DebugHelper.debug(`Contacts clean error:${JSON.stringify(err)}`);
            otherCleaning = false;
            updateDisplay(app);
          }
        );
      } else if (app.manifestUrl === AppOrigin.getManifestURL('sms')) {
        otherCleaning = true;
        clearSmsData(app);
      }
    }

    function showDialog() {
      const dialogConfig = {
        title: {
          id: 'confirmation',
          args: {}
        },
        body: {
          id: 'application-data-delete',
          args: {}
        },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback() {
            DebugHelper.debug('SettingsSoftkey cancel');
          }
        },
        confirm: {
          name: 'Delete',
          l10nId: 'delete',
          priority: 3,
          callback() {
            elements.applicationProgress.classList.remove('hidden');
            elements.applicationList.classList.add('hidden');
            SettingsSoftkey.hide();
            const li = document.querySelector('li.focus');
            const url = AppStorageListModule.appList[li.index].manifestUrl;
            closeApps(url);
            cleanOtherData(AppStorageListModule.appList[li.index]);
            systemCleaning = true;
            ApiManager.apps.clear(url, Constants.CLEAR_TYPE.STORAGE).then(
              result => {
                DebugHelper.debug(
                  `clear manifestUrl:${url}\n result:${result}`
                );
                systemCleaning = false;
                updateDisplay(AppStorageListModule.appList[li.index]);
              },
              err => {
                DebugHelper.debug(`clear manifestUrl:${url}\n error:${err}`);
                systemCleaning = false;
                updateDisplay(AppStorageListModule.appList[li.index]);
              }
            );
          }
        }
      };
      DialogHelper.show(dialogConfig);
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          header: panel.querySelector('gaia-header'),
          applicationProgress: panel.querySelector('#application-progress'),
          applicationList: panel.querySelector('#application-list')
        };
        this.once = true;
        AppStorageListModule.init(elements);
      },

      onBeforeShow(panel, options) {
        elements.header.setAttribute(
          'data-href',
          options.originHref ? options.originHref : '#root'
        );
        SettingsDBCache.getSettings(
          ['icc.applications', 'airplaneMode.enabled'],
          results => {
            const items = JSON.parse(results['icc.applications']);
            const stkEnabled =
              items && 'object' === typeof items && Object.keys(items).length;
            if (Object.keys(items).length === 1) {
              // eslint-disable-next-line
            for (let key in items) {
                if (items[key].entries) {
                  AppStorageListModule.stkConfig.stkTitle = items[key].entries
                    .title
                    ? items[key].entries.title
                    : '';
                  break;
                }
              }
            }

            if (stkEnabled && results['airplaneMode.enabled'] === false) {
              AppStorageListModule.stkConfig.isSupport = true;
            } else {
              AppStorageListModule.stkConfig.isSupport = false;
            }
          }
        );

        elements.applicationProgress.classList.remove('hidden');
        elements.applicationList.classList.add('hidden');
        if (!this.once) {
          AppStorageListModule.init(elements);
        } else {
          this.once = false;
        }
        SettingsSoftkey.init(params);
        SettingsSoftkey.hide();
      },

      onHide() {
        const childs = elements.applicationList.childNodes;
        for (let i = childs.length - 1; i >= 0; i--) {
          elements.applicationList.removeChild(childs[i]);
        }
      },

      onBeforeHide() {
        const listElements = document.querySelectorAll(
          '#application_storage li'
        );
        ListFocusHelper.removeEventListener(listElements);
      }
    });
  };
});
