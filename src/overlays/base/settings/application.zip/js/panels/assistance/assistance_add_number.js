/* global SettingsSoftkey */

define(function(require) {
  'use strict';

  var SettingsPanel = require('modules/settings_panel');
  var SettingsService = require('modules/settings_service');
  var TAG = 'QUICK_CONTACT_assistance_add_number';

  return function ctor_assistance_add_number_panel() {
    var add_number_manual;
    var add_number_from_contacts;


    function updateSKs() {
      var params_ok = {
        menuClassName: 'menu-button',
        header: { l10nId:'message' },
        items: [{
          name: 'ok',
          l10nId: 'ok',
          priority: 2
        }]
      };

      SettingsSoftkey.init(params_ok);
      SettingsSoftkey.show();
    }

    /**
     * Handle add number manual button click.
     */
    function handleAddNumberManualClick() {
        var contactProps = {target:'phone',from: 'SOS'};
        let activity = new WebActivity('new', {
            type: 'webcontacts/contact',
            caller: 'Settings',
            params: contactProps
        });
        activity.start().then(
            (data) => {
                navigateToAssistanceNumber(data); //GF7TF-3502-yanli.zhang
            },
            (err) => {
                showNewContactErrorToast();
            }
        );
      //   var contactProps = {target:'phone',from: 'SOS'};
      // var activity = new MozActivity({
      //       name: 'new',
      //       data: {
      //           type: 'webcontacts/contact',
      //           caller: 'Settings',
      //           params: contactProps
      //       }
      //   });
      // activity.onsuccess = function(contactEvent) {
      //     SettingsService.navigate('assistance_number');
      // }
      // activity.onerror = function() {
      //   showNewContactErrorToast();
      // }
    }

    function showNewContactErrorToast() {
      var toast = {
        messageL10nId: 'assistance_new_contact_error',
        latency: 3000,
        useTransition: true
      };
      Toaster.showToast(toast);
    }

    /**
     * Handle add number manual button click.
     */
    function handleAddNumberFromContactsClick() {
        let activity = new WebActivity('pick', {
            type: 'webcontacts/contact',
            caller: 'Settings'
        });
        activity.start().then(
            (data) => {
                navigateToAssistanceNumber(data);//GF7TF-3502-yanli.zhang
            },
            (err) => {
                showPickContactErrorToast();
            }
        );
    }

    //GF7TF-3502-yanli.zhang-begin
    function navigateToAssistanceNumber(data){
        dump(TAG + ": data = "+JSON.stringify(data));
        var contact = data && data.contact;
        if(contact == undefined || !contact.tel || contact.tel.length < 1) {
            var toast = {
                messageL10nId: 'assistance_contact_number_empty',
                latency: 3000,
                useTransition: true
            };
            //Toaster.showToast(toast);
            return;
        }
        var number = contact.tel[0].value;
        var quickContactInfo = {
            id:'',
            name:'',
            number:'',
            iccId:''
        };
        var name = '';
        if(contact.name) {
            //GF7TF-3502-yanli.zhang-Still display as "Empty" after adding QD number by manual begin
            if(Array.isArray(contact.name)){
               name = contact.name[0];
            } else if(typeof contact.name === "string"){
               name = contact.name
            }
            //GF7TF-3502-yanli.zhang-Still display as "Empty" after adding QD number by manual end
        }
        quickContactInfo.id = contact.id;
        quickContactInfo.name = name;
        quickContactInfo.number = number;
        // Defect9482109-bin.shen@tcl.com-begin
        if(contact && contact.category && contact.category.indexOf('SIM')) {
            if (window.remoteHelper) {
                window.remoteHelper.getproperty('vendor.radio.sim.iccid', (response)=>{
                    quickContactInfo.iccId = JSON.parse(response).value;
                    // Defect9482109-bin.shen@tcl.com-end
                    var strQuickContactInfo = JSON.stringify(quickContactInfo);
                    SettingsObserver.setValue([{name:"quick.contact.info", value: strQuickContactInfo},
                                                {name:'quick.contact.enable', value:true}]);
                });
            }
        } else {
            var strQuickContactInfo = JSON.stringify(quickContactInfo);
            dump(TAG+"handleAddNumberFromContactsClick"+'--strQuickContactInfo = '+strQuickContactInfo);
            SettingsObserver.setValue([{name:"quick.contact.info", value: strQuickContactInfo},
                {name:'quick.contact.enable', value:true}]);
        }
        SettingsService.navigate('assistance_number');
    }
    //GF7TF-3502-yanli.zhang-end

    function showPickContactErrorToast() {
      var toast = {
        messageL10nId: 'assistance_new_contact_error',
        latency: 3000,
        useTransition: true
      };
      Toaster.showToast(toast);
    }

    function handleKeydown(evt) {
      var key = evt.key;
      if (key == 'Enter' || key == 'Accept') {
        var current = document.querySelector('#assistance_add_number li.focus p');
        if (current !== null) {
          if (current === add_number_manual) {
            handleAddNumberManualClick();
          } else if(current === add_number_from_contacts) {
            handleAddNumberFromContactsClick();
          }
        }
      }

    }

    return SettingsPanel({
      onInit: function(panel) {
        add_number_manual = panel.querySelector('.add_number_manual');
        add_number_from_contacts = panel.querySelector('.add_number_from_contacts');
      },

      onBeforeShow: function() {
        window.addEventListener('keydown', handleKeydown);
        updateSKs();
      },

      onBeforeHide: function() {
        window.removeEventListener('keydown', handleKeydown);
        SettingsSoftkey.hide();
      }
    });
  };
});
