/* global SettingsSoftkey */

define(function(require) {
  'use strict';

  var SettingsPanel = require('modules/settings_panel');
  var SettingsService = require('modules/settings_service');
  var TAG = 'QUICK_CONTACT_assistance_number';

  return function ctor_assistance_number_panel() {
    var quickContactInfo = null;
    var quick_contact_has_set = false;
    var assistance_number;
    var quick_contact_is_exist = false;

    function updateSKs() {
      dump("assistance_number updateSKs");
      var params_add = {
        menuClassName: 'menu-button',
        header: { l10nId:'message' },
        items: [{
          name: 'add',
          l10nId: 'add_number_softkey_add',
          priority: 2,
          method: () => {
            handleNumberClick();
          }
        }]
      };
      var params_option = {
        header: { l10nId:'add_number_option' },
        items: [{
          name: 'edit',
          l10nId: 'assistance_edit_number',
          priority: 3,
          method: () => {
            editQuickContact();
          }
        },
        {
          name: 'delete',
          l10nId: 'assistance_delete_number',
          priority: 7,
          method: () => {
            //deleteQuickContact();
            showDialog();//Defect9438306-bin.shen@tcl.com
          }
        }]
      };

      //Defect9493093-bin.shen@tcl.com-begin
      var params_delete = {
        header: { l10nId:'add_number_option' },
        items: [{
          name: 'delete',
          l10nId: 'assistance_delete_number',
          priority: 3,
          method: () => {
            //deleteQuickContact();
            showDialog();//Defect9438306-bin.shen@tcl.com
          }
        }]
      };
      //Defect9493093-bin.shen@tcl.com-end

      dump("assistance_number updateSKs quick_contact_has_set = " + quick_contact_has_set);
      dump("assistance_number updateSKs quick_contact_is_exist = " + quick_contact_is_exist);
      if(!quick_contact_has_set) {
        SettingsSoftkey.init(params_add);
      } else if(!quick_contact_is_exist) {
        SettingsSoftkey.init(params_delete);//Defect9493093-bin.shen@tcl.com
      } else {
         SettingsSoftkey.init(params_option);
      }
      SettingsSoftkey.show();
    }

    //Defect9493093-bin.shen@tcl.com-begin
    function checkContactExistOrNot() {
      dump(TAG+"assistance_number checkContactExistOrNot begin");
      if(!quickContactInfo) {
        dump("assistance_number checkContactExistOrNot !quickContactInfo");
        updateSKs();
        return;
      }
      var filter = {
        filterBy: [ContactsManager.FilterByOption.TEL],
        filterValue: quickContactInfo.number,
        filterOption: ContactsManager.FilterOption.EQUALS
      };
      ContactsManager.find(filter).then(cursor => {
          cursor.next().then(contacts => {
              dump(TAG + 'sos contact contacts = '+JSON.stringify(contacts));
              quick_contact_is_exist = false;//GF7TF-3485-yanli.zhang-Don't update and lose RSK after editing QD number
              if (!contacts.length) {
                  dump(TAG+"check_default_contacts find fail !contacts.length");
                  cursor.release();
                  quick_contact_is_exist = false;
                  updateSKs();
              } else {
                  var contact = contacts[0];
                  if (quickContactInfo.id === contact.id && ((contact.name && quickContactInfo.name === contact.name)
                      || ((quickContactInfo.name === '' ) && (contact.tel && contact.tel.length > 0 && quickContactInfo.number === contact.tel[0].value)))){
                      quick_contact_is_exist = true;
                      dump(TAG+"assistance_number checkContactExistOrNot exist contact");
                  }
                  updateSKs(); //GF7TF-3485-yanli.zhang-Don't update and lose RSK after editing QD number
                  cursor.release();
              }
          }, () => {
              dump("check_default_contacts find fail");
              cursor.release();
              quick_contact_is_exist = false;
              updateSKs();
          });
      });
    }
    //Defect9493093-bin.shen@tcl.com-end

    function initItems() {
      dump("assistance_number initItems");
      var strQuickContactInfo;
      SettingsDBCache.getSetting('quick.contact.info').then((value)=>{
          strQuickContactInfo = value;
          if(strQuickContactInfo == "" || strQuickContactInfo == undefined) {
              assistance_number.setAttribute('data-l10n-id', 'assistance_number_empty');
              quick_contact_has_set = false;
          } else {
              updateContactInfo(strQuickContactInfo);
              quick_contact_has_set = true;
          }
      }).then(()=>{
          checkContactExistOrNot();
      })
    }

    function updateContactInfo(strQuickContactInfo) {
      quickContactInfo = JSON.parse(strQuickContactInfo);
      dump(TAG + ' updateContactInfo + strQuickContactInfo'+strQuickContactInfo);
      if(quickContactInfo && quickContactInfo.name && quickContactInfo.name != ''){
        assistance_number.textContent = quickContactInfo.name;
      } else if(quickContactInfo && quickContactInfo.number && quickContactInfo.number != ''){
        assistance_number.textContent = quickContactInfo.number;
      } else {
        assistance_number.setAttribute('data-l10n-id', 'assistance_number_empty');
      }
    }

    function resetItems(strQuickContactInfo) {
      if(strQuickContactInfo == undefined || strQuickContactInfo == '') {
        assistance_number.setAttribute('data-l10n-id', 'assistance_number_empty');
        quick_contact_has_set = false;
      } else {
        updateContactInfo(strQuickContactInfo);
        quick_contact_has_set = true;
        checkContactExistOrNot();//Defect9493093-bin.shen@tcl.com; GF7VZW-6980-yanli.zhang-Will enter incorrect screen after delete quick dial number and Tap Activation
      }
      dump("assistance_number resetItems");
    }

    /**
      * Handle add number manual button click.
      */
    function handleNumberClick() {
      SettingsService.navigate('assistance_add_number');
    }

      //Defect9438306-bin.shen@tcl.com-begin
    function showDialog() {
        var dialogConfig = {
            title: {id: 'confirmation', args: {}},
            body: {id: 'assistant_delete_confir', args: {}},
            cancel: {
                l10nId:'cancel',
                priority:1,
                callback: function(){
                    dialog.destroy();
                },
            },
            confirm: {
                l10nId: 'delete',
                priority: 3,
                callback: function(){
                  deleteQuickContact();
                },
            },
        };

        //var dialog = new ConfirmDialogHelper(dialogConfig);
        //dialog.show(document.getElementById('app-confirmation-dialog'));
        DialogHelper.show(dialogConfig);
    }
    //Defect9438306-bin.shen@tcl.com-end

    /**
     * Handle add number manual button click.
     */
    function deleteQuickContact() {
     var result = SettingsObserver.setValue(
         [{name:"quick.contact.info", value: ""},
         {name: 'quick.contact.enable', value:false}]).then(()=>{
         var toast = {
             messageL10nId: 'assistant_delete_toast',
             latency: 3000,
             useTransition: true
         };
         Toaster.showToast(toast);
         SettingsService.navigate('assistance');
     });
    }

    function addSettingsChangeListenr() {
        SettingsObserver.observe("quick.contact.info", '', (value) => {
          callback(value);
        }, true);

    }

    function removeSettingsChangeListenr() {
        SettingsObserver.unobserve("quick.contact.info",callback);
    }

    function callback(value) {
      dump("assistance_number callback");
      var strQuickContactInfo = value;
      resetItems(strQuickContactInfo);
    }

    /**
     * Handle add number manual button click.
     */
    function editQuickContact() {
        var contactId = quickContactInfo.id;
        var contactProps = {id: contactId, from: 'SOS'};
        let activity = new WebActivity('edit', {
            type: 'webcontacts/contact',
            caller: 'Settings',
            params: contactProps
        });
        activity.start().then(
            (data) => {
                updateQdNumber(data); //GF7VZW-6982-yanli.zhang-Don't update and lose RSK after editing QD number
            },
            (err) => {
                showEidtContactErrorToast();
            }
        );
    }

    //GF7VZW-6982-yanli.zhang-Don't update and lose RSK after editing QD number-begin
    function updateQdNumber(data){
        dump(TAG + ": data = "+JSON.stringify(data));
        var contact = data && data.contact;
        if(contact == undefined || !contact.tel || contact.tel.length < 1) {
            var toast = {
                messageL10nId: 'assistance_contact_number_empty',
                latency: 3000,
                useTransition: true
            };
			//modify by jiapeng.zhang for GF7TF-4097 on 2023/11/07
            //Toaster.showToast(toast);
            return;
        }
        var number = contact.tel[0].value;
        var quickContactInfo = {
            id:'',
            name:'',
            number:'',
            iccId:''
        };
        var name = '';
        if(contact.name && Array.isArray(contact.name)) {
            name = contact.name[0];
        }
        quickContactInfo.id = contact.id;
        quickContactInfo.name = name;
        quickContactInfo.number = number;
        // Defect9482109-bin.shen@tcl.com-begin
        if(contact && contact.category && contact.category.indexOf('SIM')) {
            if (window.remoteHelper) {
                window.remoteHelper.getproperty('vendor.radio.sim.iccid', (response)=>{
                    quickContactInfo.iccId = JSON.parse(response).value;
                    // Defect9482109-bin.shen@tcl.com-end
                    var strQuickContactInfo = JSON.stringify(quickContactInfo);
                    SettingsObserver.setValue([{name:"quick.contact.info", value: strQuickContactInfo},
                                                {name:'quick.contact.enable', value:true}]);
                });
            }
        } else {
            var strQuickContactInfo = JSON.stringify(quickContactInfo);
            dump(TAG+"updateQdNumber "+'--strQuickContactInfo = '+strQuickContactInfo);
            SettingsObserver.setValue([{name:"quick.contact.info", value: strQuickContactInfo},
                {name:'quick.contact.enable', value:true}]);
        }
    }
    //GF7VZW-6982-yanli.zhang-Don't update and lose RSK after editing QD number-end

    function showEidtContactErrorToast() {
      var toast = {
        messageL10nId: 'assistance_edit_contact_error',
        latency: 3000,
        useTransition: true
      };
      Toaster.showToast(toast);
    }

    return SettingsPanel({
      onInit: function(panel) {
        assistance_number = panel.querySelector('.assistance_number');
      },

      onBeforeShow: function() {
        dump("assistance_number onBeforeShow");
        initItems();
        //updateSKs();
        // checkContactExistOrNot();//Defect9493093-bin.shen@tcl.com
        addSettingsChangeListenr();
      },

      onBeforeHide: function() {
        removeSettingsChangeListenr();
        SettingsSoftkey.hide();
      }
    });
  };
});
