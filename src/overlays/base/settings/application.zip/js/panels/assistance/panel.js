/* global SettingsSoftkey */

define(function(require) {
  'use strict';

  var SettingsPanel = require('modules/settings_panel');

  return function ctor_assistance_panel() {
    // We use this flag to identify permissions_table.json has been loaded or
    // not.
    var elements = {};

    function updateSKs() {
      var params = {
        menuClassName: 'menu-button',
        header: { l10nId:'message' },
        items: [{
          name: 'Ok',
          l10nId: 'ok',
          priority: 2
        }]
      };
      SettingsSoftkey.init(params);
      SettingsSoftkey.show();
    }

    //Defect9438306-bin.shen@tcl.com-begin
    function updateActivationValue() {
      SettingsObserver.getValue('quick.contact.enable').then((value)=>{
        var activation = document.querySelector('.quick_contact_enable');
        activation.value = value;
        //GF7VZW-6981-yanli.zhang begin
        if(value === undefined){
            SettingsObserver.setValue([{name: 'quick.contact.enable', value:false}]);
            activation.value = false;
        }
        //GF7VZW-6981-yanli.zhang end
      });

      //add by jiapeng.zhang for GF5GTMO-4638 on 2024/10/22
      window.remoteHelper.getproperty('persist.sys.flashing.enabled', (response) => {
        let value = JSON.parse(response).value;
        elements.flashlightSelect.value = value === 'true' ? 'true' : 'false';
      });
    }
    //Defect9438306-bin.shen@tcl.com-end

    return SettingsPanel({
      onInit: function(panel) {
        elements = {
          list: panel.querySelector('.app-list'),
          flashlightSelect: panel.querySelector('#flashlight-select')
        };
        //add by jiapeng.zhang for GF5GTMO-4638 on 2024/10/22
        elements.flashlightSelect.addEventListener('change', () => {
          let enable = elements.flashlightSelect.value;
          dump('persist.sys.flashing.enabled: ' + enable);
          if(enable != undefined){
            navigator.b2g.engmodeManager.setPropertyLE('settings_flashing',enable);
          }
        });
        //end by jiapeng.zhang for GF5GTMO-4638 on 2024/10/22
      },

      onBeforeShow: function() {
        updateSKs();
        updateActivationValue(); //Defect9438306-bin.shen@tcl.com
      },

      onBeforeHide: function() {
        SettingsSoftkey.hide();
      }
    });
  };
});
