/**
 * Porting from Defect11475881-yanli.zhang@tcl.com-for assisted dialing on 2024/9/4
 */

/* global CountryList,  */
'use strict';
define(function(require) {

  const SettingsPanel = require('modules/settings_panel');

  return function createAssistedDialingPanel() {
    let elements = null;
    let listElements = null;
    let serviceId = 0;
    let countryList = null;
    let currentMcc;
    function initSoftKey() {
      SettingsSoftkey.init(SoftParams.defaultSelect);
      SettingsSoftkey.show();
    }

    function registerSoftkey() {
      const softkeyOk = {
        name: 'OK',
        l10nId: 'ok',
        priority: 1,
        method: () => {
          SettingsObserver.setValue([{
            name: 'current.location',
              value: elements.locationInput.value
          }]);
          SettingsSoftkey.hide();
        }
      };
      const softkeyOption = [
        {
          name: 'Reset',
          l10nId: 'reset',
          priority: 7,
          method: () => {
            elements.locationInput.value = "United States of America";
          }
        },
        {
          name: 'Location',
          l10nId: 'location',
          priority: 8,
          method: () => {
            currentMcc = navigator.b2g.mobileConnections[0].voice.network.mcc;
            dump('assisted_dialing currentMcc is : ' + currentMcc);
            for (let coun in countryList) {
              if (currentMcc === countryList[coun].mcc) {
                elements.locationInput.value = countryList[coun].name;
                break ;
              }
            }
          }
        }
      ];
      const softkeyParams = {
        header: { l10nId: 'fxa-options' },
        items: []
      };
      softkeyParams.items.push(softkeyOk);
      softkeyParams.items.push.apply(softkeyParams.items, softkeyOption);
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    function setValue() {
      dump('assisted_dialing setValue value is : ' + elements.assistedDialingSelect.value);
      SettingsObserver.setValue([{
        name: 'assisted.dialing.is.on',
          value: elements.assistedDialingSelect.value
      }]);
    }

    return SettingsPanel({
      onInit(panel, options) {
        serviceId = options.serviceId || serviceId;
        elements = {
          panel,
            assistedDialingSwitch: panel.querySelector('#assisted_dialing_switch'),
          assistedDialingSelect: panel.querySelector('#assisted-dialing-enabled'),
            countryRefer: panel.querySelector('#refer_country'),
            countrySel: panel.querySelector('#country-current'),
            locationInput: panel.querySelector('#location_input')
        };
        SettingsObserver.getValue('current.location').then((result) => {
          dump('assisted_dialing current.location value = ' + result);
          if (result) {
            elements.locationInput.value = result;
          } else {
            elements.locationInput.value = "United States of America";
          }
        });
        LazyLoader.load(
            [`${Constants.SHARD_ORIGIN}/js/helper/country/country_list.js`],
            () => {
              CountryList.get((countries, currentCountry) => {
                  dump('assisted_dialing countries : ' + JSON.stringify(countries));
                  countryList = countries;
              });
            });
          SettingsObserver.getValue('assisted.dialing.is.on').then((result) => {
              dump('assisted_dialing assisted.dialing.is.on value = ' + result);
              if (result) {
                elements.assistedDialingSelect.value = result;
              } else {
                elements.assistedDialingSelect.value = false;
              }
          });
        listElements = panel.querySelectorAll('li');
        elements.countryRefer.onclick = () => {
          Settings.setCurrentPanel('#country_list', {
            serviceId,
              countryList: countryList
          });
        };
      },

      onBeforeShow(panel, options) {
        serviceId = options.serviceId || serviceId;
        SettingsObserver.getValue('current.country').then((result) => {
          dump('assisted_dialing current.country value = ' + result);
          if (result === undefined) {
            elements.countrySel.textContent = "United States of America";
          } else {
            elements.countrySel.textContent = JSON.parse(result).name;
          }
        });
        elements.assistedDialingSwitch.addEventListener('focus', initSoftKey);
        elements.countryRefer.addEventListener('focus', initSoftKey);
        elements.locationInput.addEventListener('focus', registerSoftkey);
        elements.assistedDialingSelect.addEventListener('change', setValue);
      },
      onBeforeHide() {
        SettingsObserver.setValue([{
          name: 'current.location',
            value: elements.locationInput.value
        }]);
        elements.assistedDialingSwitch.removeEventListener('focus', initSoftKey);
        elements.countryRefer.removeEventListener('focus', initSoftKey);
        elements.locationInput.removeEventListener('focus', registerSoftkey);
        elements.assistedDialingSelect.removeEventListener('change', setValue);
        SettingsSoftkey.hide();
      }
    });
  };
});
