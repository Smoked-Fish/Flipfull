/* global BluetoothContext */
/* eslint-disable prefer-destructuring */
'use strict';

define(function(require) { //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createBluetoothPanel() {
    let elements = null;
    const listElements = document.querySelectorAll('#bluetooth li');

    function updateEnableCheckbox() {
      const state = BluetoothContext.info.state;
      if (state === 'enabled') {
        elements.bluetoothEnable.checked = true;
        elements.bluetoothDisable.checked = false;
      } else {
        elements.bluetoothDisable.checked = true;
        elements.bluetoothEnable.checked = false;
      }
    }

    function updateVisibleCheckbox() {
      const discoverable = BluetoothContext.info.discoverable;
      elements.visibleSelect.options[0].selected = discoverable;
      elements.visibleSelect.options[1].selected = !discoverable;
    }

    function updateBluetoothList() {
      const state = BluetoothContext.info.state;

      const booleanFlag = state !== 'enabled';

      if (booleanFlag) {
        elements.visibleItem.classList.add('hidden');
        elements.myPhoneNameItem.classList.add('hidden');
        elements.nearbyDeviceItem.classList.add('hidden');
        elements.pairedDevicesItem.classList.add('hidden');
        elements.enableMsg.classList.remove('hidden');
      } else {
        elements.visibleItem.classList.remove('hidden');
        elements.myPhoneNameItem.classList.remove('hidden');
        elements.nearbyDeviceItem.classList.remove('hidden');
        elements.pairedDevicesItem.classList.remove('hidden');
        elements.enableMsg.classList.add('hidden');
      }
      if (state === 'enabled' || state === 'disabled') {
        window.dispatchEvent(new CustomEvent('refresh'));
      }
    }

    function updatePhoneName() {
      elements.phoneName.textContent = BluetoothContext.info.name;
    }

    function onEnableCheckboxClick() {
      BluetoothContext.setEnabled(true).then(result => {
        if (result) {
          ToastHelper.showToast(`bluetooth-current-status-on`);
        }
      });
    }

    function onDisableCheckboxClick() {
      BluetoothContext.setEnabled(false).then(result => {
        if (result) {
          ToastHelper.showToast(`bluetooth-current-status-off`);
        }
      });
    }

    function onVisibleCheckBoxClick() {
      const checkbox = elements.visibleSelect.value === 'true';
      const status = checkbox ? 'on' : 'off';
      BluetoothContext.setDiscoverable(checkbox).then(result => {
        if (result) {
          ToastHelper.showToast(`bluetooth-visible-status-${status}`);
        }
      });
    }

    function updateEnableHigtlight(state) {
      let liItem = null;
      if (state === 'enabled') {
        liItem = elements.items[0];
      } else {
        liItem = elements.items[1];
      }
      ListFocusHelper.requestFocus(elements.panel, liItem);
    }

    function refreshBTInfo() {
      updateVisibleCheckbox();
      updateEnableCheckbox();
      updatePhoneName();
      updateBluetoothList();
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          panel,
          enableMsg: panel.querySelector('#bluetooth-enable-msg'),
          enableCheckbox: panel.querySelector('.bluetooth-status input'),
          bluetoothEnable: panel.querySelector('#bluetooth-enabled-radio'),
          bluetoothDisable: panel.querySelector('#bluetooth-disable-radio'),

          visibleItem: panel.querySelector('#device-visible'),
          visibleCheckBox: panel.querySelector('.device-visible input'),
          visibleSelect: panel.querySelector('#device-visible select'),

          myPhoneNameItem: panel.querySelector('#myPhone-name'),
          phoneName: panel.querySelector('#bluetooth-device-name'),

          pairedDevicesItem: panel.querySelector('#bluetooth-paired-device'),

          nearbyDeviceItem: panel.querySelector('#bluetooth-devices-nearby'),

          items: panel.querySelectorAll('li')
        };
      },

      onBeforeShow() {
        SettingsSoftkey.init(SoftParams.defaultSelect);
        SettingsSoftkey.show();

        window.addEventListener('adapter-info-change', refreshBTInfo);
        refreshBTInfo();

        ListFocusHelper.addEventListener(listElements);

        elements.bluetoothEnable.addEventListener(
          'change',
          onEnableCheckboxClick
        );
        elements.bluetoothDisable.addEventListener(
          'change',
          onDisableCheckboxClick
        );

        elements.visibleSelect.addEventListener(
          'change',
          onVisibleCheckBoxClick
        );
      },

      onShow(panel, options) {
        if (!options.visibilityChange) {
          updateEnableHigtlight(BluetoothContext.info.state);
        }
      },

      onBeforeHide() {
        ListFocusHelper.removeEventListener(listElements);

        elements.visibleSelect.removeEventListener(
          'change',
          onVisibleCheckBoxClick
        );

        elements.bluetoothEnable.removeEventListener(
          'change',
          onEnableCheckboxClick
        );
        elements.bluetoothDisable.removeEventListener(
          'change',
          onDisableCheckboxClick
        );
      }
    });
  };
});
