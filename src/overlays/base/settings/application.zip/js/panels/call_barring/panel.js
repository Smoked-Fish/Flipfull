/* global CallBarring*/

'use strict';
define(function(require) { //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  require('panels/call_barring/call_barring');

  return function createCallBarringPanel() {
    let serviceId = 0;
    let elements = null;
    const callBarring = CallBarring;
    let mobileConnection = null;
    let cbSettings = {};
    let refresh = null;
    let updating = null;
    let listElements = {};
    let callType = 'voice';

    /**
     * @HACK To Enable the select option
     */
    function enableSelect(evt) {
      if (evt.key === 'Enter') {
        const select = document.querySelector('li.focus select');
        if (!select) {
          return;
        }
        if (!updating) {
          select.classList.remove('hidden');
          select.focus();
        }
        select.classList.add('hidden');
      }
    }

    /**
     * Updates a Call Barring item with a new status.
     * @parameter item DOM 'li' element to update
     * @parameter newStatus Object with data for the update. Of the form:
     * {
     *   disabled:[true|false], // optional, new disabled state
     *   checked: [true|false], // optional, new checked state for the input
     *   message: [string]      // optional, new message for the description
     * }
     */
    function updateCallBarringItem(item, newStatus) {
      const descText = item.querySelector('small');
      const select = item.querySelector('select');

      // Disable the item
      if (typeof newStatus.disabled === 'boolean') {
        if (newStatus.disabled) {
          item.setAttribute('aria-disabled', true);
          item.classList.add('none-select');
        } else {
          item.removeAttribute('aria-disabled');
          item.classList.remove('none-select');
        }
        ListFocusHelper.updateSoftkey(elements.currentPanel);

        if (select) {
          select.disabled = newStatus.disabled;
        }
      }

      // Update the select value
      if (select && typeof newStatus.checked === 'boolean') {
        select.value = newStatus.checked ? 'true' : 'false';
      }

      // Update the description
      function getSelectValue() {
        const enabled = select.value === 'true';
        let status = '';
        if (select) {
          status = enabled ? 'enabled' : 'disabled';
        }
        return status;
      }

      if (descText && updating) {
        descText.setAttribute('data-l10n-id', 'callSettingsQuery');
      } else {
        // Clear the data-l10n-id information
        descText.innerHTML = '';
        descText.setAttribute('data-l10n-id', getSelectValue());
      }
    }

    /**
     * Shows the passcode input screen for the user to introduce the PIN
     * needed to activate/deactivate a service
     */
    function callBarringChange(evt) {
      const settingValue = evt.target.name;
      const enabled = evt.target.value;
      Settings.setCurrentPanel('#call_barring_passcode', {
        type: callType,
        serviceId,
        settingValue,
        enabled
      });
    }

    function onClickEventHandler() {
      Settings.setCurrentPanel('#call_barring_passcode_change', {
        type: callType,
        serviceId
      });
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          currentPanel: panel,
          header: panel.querySelector('#call-cb-header'),
          title: panel.querySelector('#call-cb-header h1'),
          changePasscodeButton: panel.querySelector('#li-cb-pswd button')
        };
        listElements = panel.querySelectorAll('li');
        cbSettings = {
          baoc: document.getElementById('li-cb-baoc'),
          boic: document.getElementById('li-cb-boic'),
          boicExhc: document.getElementById('li-cb-boicExhc'),
          baic: document.getElementById('li-cb-baic'),
          baicR: document.getElementById('li-cb-baicR')
        };
      },

      onBeforeShow(panel, options) {
        serviceId = options.serviceId || serviceId;
        callType = options.type || 'voice';
        DeviceFeature.ready(() => {
          if (DeviceFeature.getValue('vilte') === 'true') {
            elements.header.setAttribute('data-href', '#call_cb_settings_list');
            if (callType === 'video') {
              elements.title.setAttribute('data-l10n-id', 'video-call-header');
            } else {
              elements.title.setAttribute('data-l10n-id', 'voice-call-header');
            }
          } else {
            elements.header.setAttribute('data-href', '#call');
            elements.title.setAttribute('data-l10n-id', 'callBarring-header');
          }
        });

        mobileConnection = ApiManager.connections[serviceId];

        if (
          options &&
          options.origin &&
          options.origin === '#call_barring_passcode_change'
        ) {
          refresh = false;
          updating = false;
        } else {
          refresh = true;
          updating = true;
          // Update the call barring item value status
          for (let element in cbSettings) { // eslint-disable-line
            callBarring[element] = false;
            updateCallBarringItem(cbSettings[element], {
              checked: false,
              disabled: true
            });
          }
        }

        for (let i in cbSettings) { //eslint-disable-line
          cbSettings[i]
            .querySelector('select')
            .addEventListener('change', callBarringChange);
        }

        ListFocusHelper.addEventListener(listElements);
        SettingsSoftkey.init(SoftParams.defaultSelect);
        ListFocusHelper.updateSoftkey(panel);
      },

      onShow() {
        if (refresh) {
          callBarring.getAll(mobileConnection, callType).then(() => {
            updating = callBarring.updating; // eslint-disable-line
            updateCallBarringItem(cbSettings.baoc, {
              checked: callBarring.baoc,
              disabled: !callBarring.baocEnabled
            });
            updateCallBarringItem(cbSettings.boic, {
              checked: callBarring.boic,
              disabled: !callBarring.boicEnabled
            });
            updateCallBarringItem(cbSettings.boicExhc, {
              checked: callBarring.boicExhc,
              disabled: !callBarring.boicExhcEnabled
            });
            updateCallBarringItem(cbSettings.baic, {
              checked: callBarring.baic,
              disabled: !callBarring.baicEnabled
            });
            updateCallBarringItem(cbSettings.baicR, {
              checked: callBarring.baicR,
              disabled: !callBarring.baicREnabled
            });
          });
        }

        window.addEventListener('keydown', enableSelect);
        elements.changePasscodeButton.addEventListener(
          'click',
          onClickEventHandler
        );
      },

      onHide() {
        window.removeEventListener('keydown', enableSelect);
        elements.changePasscodeButton.removeEventListener(
          'click',
          onClickEventHandler
        );
      },

      onBeforeHide() {
        for (let i in cbSettings) { //eslint-disable-line
          cbSettings[i]
            .querySelector('select')
            .removeEventListener('change', callBarringChange);
        }
        ListFocusHelper.removeEventListener(listElements);
      },

      onUninit() {
        CallBarring.updating = false;
      }
    });
  };
});
