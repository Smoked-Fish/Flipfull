// [TMO:GID-MTRREQ-7340]Task10123902-shiyan.luo@tcl.com-for showing call time-add this file
define(function (require) {
    'use strict';

    var SettingsPanel = require('modules/settings_panel');
    const lastKey = 'devicewipe.calllog.calltimes.last_call_duration';
    const moKey = 'devicewipe.calllog.calltimes.cumulative_dialedcall_duration';
    const mtKey = 'devicewipe.calllog.calltimes.cumulative_receivedcall_duration';
    const totleKey = 'devicewipe.calllog.calltimes.cumulative_allcall_duration';
    var _self;

    return function () {
        return SettingsPanel({
            onInit: function (panel) {
                _self = this;
                this._elements = {
                    lastcall: panel.querySelector('.duration-lastcall'),
                    outgoingcalls: panel.querySelector('.duration-outgoingcalls'),
                    incomingcalls: panel.querySelector('.duration-incomingcalls'),
                    allcalls: panel.querySelector('.duration-allcalls'),
                    lifetime: panel.querySelector('.duration-lifetime'),
                    resetcalltimers: panel.querySelector('.duration-call-timers')
                };

                this._elements.lastcall.onclick = function () {
                    this._showDialog('Call-timer-reset-confirm', function () {
                        this._resetInfo(lastKey)
                        this._updateInfo(lastKey, this._elements.lastcall);
                    }.bind(this))
                }.bind(this);
                this._elements.outgoingcalls.onclick = function () {
                    this._showDialog('Call-timer-reset-confirm', function () {
                        this._resetInfo(moKey);
                        this._updateInfo(moKey, this._elements.outgoingcalls);
                    }.bind(this))
                }.bind(this);
                this._elements.incomingcalls.onclick = function () {
                    this._showDialog('Call-timer-reset-confirm', function () {
                        this._resetInfo(mtKey);
                        this._updateInfo(mtKey, this._elements.incomingcalls);
                    }.bind(this))
                }.bind(this);
                this._elements.allcalls.onclick = function () {
                    this._showDialog('Call-timer-reset-confirm', function () {
                        this._resetInfo(totleKey);
                        this._updateInfo(totleKey, this._elements.allcalls);
                    }.bind(this))
                }.bind(this);
                this._elements.resetcalltimers.onclick = function () {
                    this._showDialog('Call-timer-reset-confirm', function () {
                        this._resetAllInfoBesideLifeTimer();
                        this._update();
                    }.bind(this))
                }.bind(this);
            },

            onBeforeShow: function () {
                SettingsSoftkey.show();
                this._elements.lifetime.parentNode.addEventListener('focus', function () {
                    SettingsSoftkey.hide();
                });
                this._elements.lifetime.parentNode.addEventListener('blur', function () {
                    SettingsSoftkey.show();
                });
                this._update();
            },

            _update: function () {
                this._updateInfo(lastKey, this._elements.lastcall);
                this._updateInfo(moKey, this._elements.outgoingcalls);
                this._updateInfo(mtKey, this._elements.incomingcalls);
                this._updateInfo(totleKey, this._elements.allcalls);

                let lifeTimeDuration;
                navigator.b2g.engmodeManager.fileReadLE('call_data').then((callInfo) => {//Modified by zhang-lei for Task GF5GTMO-4231 on 2024/09/19
                    dump('call-duration: callInfo is: ' + callInfo);
                    if (callInfo) {
                        try {
                            let valueJson = JSON.parse(callInfo);
                            lifeTimeDuration = parseInt(valueJson.duration);
                        } catch (e) {
                            dump('call-duration: not found call_duration tmp file,some error happend！');
                        }
                    }
                    _self._elements.lifetime.textContent = _self._formatTimes(lifeTimeDuration);
                }, () => {
                    _self._elements.lifetime.textContent = _self._formatTimes(lifeTimeDuration);
                });
            },

            _updateInfo: function (key, widget) {
                window.SettingsObserver.getValue(key).then((value)=>{
                    dump('call-duration updateInfo onsuccess key:' + key + '  value:' + value);
                    widget.textContent = _self._formatTimes(value);
                });
            },
            _formatTimes: function (seconds) {
                if (seconds <= 0 || isNaN(seconds) || !seconds) {
                    dump('call-duration error format!');
                    return '00:00:00';
                }
                var h = parseInt(seconds / 3600);
                var m = parseInt((seconds - h * 3600) / 60);
                var s = seconds - h * 3600 - m * 60;
                if (s < 10)
                    s = '0' + s;
                if (m < 10)
                    m = '0' + m;
                if (h < 10)
                    h = '0' + h;
                var str = h + ":" + m + ":" + s;
                dump('call-duration str：' + str);
                return str;
            },

            _resetAllInfoBesideLifeTimer: function () {
                this._resetInfo(lastKey);
                this._resetInfo(moKey);
                this._resetInfo(mtKey);
                this._resetInfo(totleKey);
                this._update();
            },

            _resetInfo: function (key) {
                dump('call-duration:_resetInfo:' + key);
                var resetResult = window.SettingsObserver.setValue([{
                    name: key,
                    value: 0
                }]);
                resetResult.then(
                    result => {
                        dump('call-duration: reset successfully and result is: ' + result);
                    }
                );
            },

            _showDialog: function (msgId, callbackOk) {
                if (!msgId) {
                    return;
                }

                var dialogConfig = {
                    title: {
                        id: 'settings',
                        args: {}
                    },
                    body: {
                        id: msgId,
                        args: {}
                    },
                    cancel: {
                        name: 'Cancel',
                        l10nId: 'cancel',
                        priority: 1,
                        callback: function () {
                        }
                    },
                    confirm: {
                        name: 'Ok',
                        l10nId: 'ok',
                        priority: 3,
                        callback: callbackOk
                    },
                };
                //var dialog = new ConfirmDialogHelper(dialogConfig);
                //dialog.show(document.getElementById('app-confirmation-dialog'));
                DialogHelper.show(dialogConfig);
            },
        });
    };
});
