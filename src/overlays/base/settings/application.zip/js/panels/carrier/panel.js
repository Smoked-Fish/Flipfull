/* global SimCardHelper */
'use strict';
define(function(require) { //eslint-disable-line

  const SettingsPanel = require('modules/settings_panel');
  //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3524,
  //const APN_PANEL_NAME = 'apn_settings_tct';
  const APN_PANEL_NAME = 'apn_list_tct';
  //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-3524,

  return function createCarrierPanel() {
    let listElements = null;
    let elements = null;

    function handleDataConnection() {
      ToastHelper.showToast('changessaved');
    }

    function updateUIBySlot() {
      //[BUGFIX]Add-Begin by haoshuai.yu for GF5GTMO-7051 on 05/07/2025
      if (SimCardHelper.isDoubleSimSlot()) {
        elements.carrierSim2.classList.remove('hidden');
        for (let index = 0; index < ApiManager.connections.length; index++) {
          if (ApiManager.connections[index].iccId) {
            SimCardHelper.getOperatorName(ApiManager.connections[index]).then(
              value => {
                const targetElement = index === 0 ? elements.carrierSim1 : elements.carrierSim2;
                targetElement.querySelector('span').textContent = value.toString();
              }
            );
            SimCardHelper.getPhoneNumber(SimCardHelper.getIccId(index)).then(number => {
              const targetElement = index === 0 ? elements.carrierSim1 : elements.carrierSim2;
              targetElement.querySelector('.number').textContent = number.toString();
            });
          } else {
            const item =
              index === 0 ? elements.carrierSim1 : elements.carrierSim2;
            const spnItem = index === 0 ? elements.apnSim1 : elements.apnSim2;
            disableItem(item, false);
            disableItem(spnItem, false);
          }
        }
        elements.apnSim2.classList.remove('hidden');
        elements.apnSim1
          .querySelector('span')
          .setAttribute('data-l10n-id', 'apn-sim1');
      } else {
        elements.carrierSim2.classList.add('hidden');
        elements.carrierSim1
          .querySelector('span')
          .setAttribute('data-l10n-id', 'dataNetwork');

        SimCardHelper.getOperatorName(ApiManager.connections[0]).then(value => {
          elements.carrierSim1.querySelector('span').textContent = value.toString();
        });

        SimCardHelper.getPhoneNumber(SimCardHelper.getIccId(index)).then(number => {
          elements.carrierSim1.querySelector('.number').textContent = number.toString();
        });



        elements.apnSim2.classList.add('hidden');
        elements.apnSim1
          .querySelector('span')
          .setAttribute('data-l10n-id', 'apnSettings');
      }
      //[BUGFIX]Add-End by haoshuai.yu for GF5GTMO-7051 on 05/07/2025
    }

    function configDataCounterItem() {
      navigator.b2g.activityUtils.getInstalled('network-stats').then(result => {
        elements.dataCounter.classList.toggle('hidden', result.length === 0);
      });
    }

    function toggleDataCounterItem(enabled) {
      disableItem(elements.dataCounter, enabled);
    }

    function disableItem(item, enabled) {
      if (!item) {
        return;
      }
      item.classList.toggle('none-select', !enabled);
      if (enabled) {
        item.removeAttribute('aria-disabled');
      } else {
        item.setAttribute('aria-disabled', true);
      }
    }

    function handleEvent(evt) {
      const { target } = evt;
      evt.preventDefault();
      evt.stopPropagation();

      if (target.classList.contains('none-select')) {
        return;
      }

      switch (target.id) {
        case 'carrier-sim1':
          Settings.setCurrentPanel('carrier_detail', {
            serviceId: 0
          });
          break;
        case 'carrier-sim2':
          Settings.setCurrentPanel('carrier_detail', {
            serviceId: 1
          });
          break;
        case 'apn-sim1':
          //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3524,
          //Development apn settings feature
          dump('carrier: click apn-sim1 to enter ' + APN_PANEL_NAME);
          //Settings.setCurrentPanel('apn_settings', { serviceId: 0 });
          Settings.setCurrentPanel(APN_PANEL_NAME, { serviceId: 0 });
          //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-3524,
          break;
        case 'apn-sim2':
          //[BUGFIX]-Mod-BEGIN by GCSSZ.kaiyun.yan,08/19/2024,GF5GTMO-3524,
          //Development apn settings feature
          dump('carrier: click apn-sim2 to enter ' + APN_PANEL_NAME);
          //Settings.setCurrentPanel('apn_settings', { serviceId: 1 });
          Settings.setCurrentPanel(APN_PANEL_NAME, { serviceId: 1 });
          //[BUGFIX]-Mod-END by GCSSZ.kaiyun.yan,GF5GTMO-3524,
          break;
        case 'liItem-dataCounter':
          ActivityHelper.start({ name: 'network-stats' });
          break;
        default:
          break;
      }
    }

    function updateDataRegion(enabled) {
      ComponentsHelper.updateSelect(elements.dataConnectionSelect, enabled);
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          carrierSim1: panel.querySelector('#carrier-sim1'),
          carrierSim1Desc: panel.querySelector('#carrier-sim1 .number'),
          carrierSim2: panel.querySelector('#carrier-sim2'),
          carrierSim2Desc: panel.querySelector('#carrier-sim2 .number'),
          dataConnectionSelect: panel.querySelector(
            '#liItem-dataConnection select'
          ),
          dataCounter: panel.querySelector('#liItem-dataCounter'),
          dataRoaming: panel.querySelector('#liItem-dataRoaming'),
          dataRoamingDesc: panel.querySelector('#data-roaming-desc'),
          roamingPreference: panel.querySelector(
            '#operator-roaming-preference'
          ),
          apnSim1: panel.querySelector('#apn-sim1'),
          apnSim1Desc: panel.querySelector('#apn-sim1 small'),
          apnSim2: panel.querySelector('#apn-sim2'),
          apnSim2Desc: panel.querySelector('#apn-sim2 small')
        };
        listElements = panel.querySelectorAll('#carrier li');
        if (ActivityHandler.currentActivity) {
          if (ActivityHandler.activityPanelId === 'connectivity_settings') {
            const header = panel.querySelector('gaia-header');
            header.setAttribute('data-href', '#connectivity_settings');
          }
        }
      },

      onBeforeShow(panel) {
        navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name').then((value) => {
          //Defect#GF7TF-3653-Add by qingsong.liao@tcl.com-start
          if(value === 'TF'){
            elements.carrierSim1Desc.classList.add('hidden');
          }
          //Defect#GF7TF-3653-Add by qingsong.liao@tcl.com-end
        });
        SettingsSoftkey.init(SoftParams.defaultSelect);
        ListFocusHelper.updateSoftkey(panel);
        ListFocusHelper.addEventListener(listElements);
        Customization.initUIForItem(['dataConnection', 'dataRoaming']);
        Customization.addListener([
          'data.settings.ui',
          'dm.data.settings.ui',
          'data.roaming.settings.ui',
          'airplaneMode.status',
          'ril.data.roaming_enabled'
        ]);
        SettingsDBCache.observe(
          'ril.data.enabled',
          true,
          updateDataRegion,
          true
        );
        updateUIBySlot();
        configDataCounterItem();
        SettingsDBCache.observe(
          'ril.data.enabled',
          true,
          toggleDataCounterItem
        );
        elements.dataConnectionSelect.addEventListener(
          'change',
          handleDataConnection
        );
        elements.carrierSim1.addEventListener('click', handleEvent);
        elements.carrierSim2.addEventListener('click', handleEvent);
        elements.apnSim1.addEventListener('click', handleEvent);
        elements.apnSim2.addEventListener('click', handleEvent);
        elements.dataCounter.addEventListener('click', handleEvent);
      },

      onBeforeHide() {
        Customization.removeListener([
          'data.settings.ui',
          'dm.data.settings.ui',
          'data.roaming.settings.ui',
          'airplaneMode.status',
          'ril.data.roaming_enabled'
        ]);
        SettingsDBCache.unobserve('ril.data.enabled', updateDataRegion);
        ListFocusHelper.removeEventListener(listElements);
        SettingsDBCache.unobserve('ril.data.enabled', toggleDataCounterItem);
        elements.dataConnectionSelect.removeEventListener(
          'change',
          handleDataConnection
        );
        elements.carrierSim1.removeEventListener('click', handleEvent);
        elements.carrierSim2.removeEventListener('click', handleEvent);
        elements.apnSim1.removeEventListener('click', handleEvent);
        elements.apnSim2.removeEventListener('click', handleEvent);
        elements.dataCounter.removeEventListener('click', handleEvent);
      }
    });
  };
});
