/******************************************************************************/
/*                                                               Date:02/2024 */
/*                                PRESENTATION                                */
/*                                                                            */
/*       Copyright 2024 TCL Communication Technology Holdings Limited.        */
/*                                                                            */
/* This material is company confidential, cannot be reproduced in any form    */
/* without the written permission of TCL Communication Technology Holdings    */
/* Limited.                                                                   */
/*                                                                            */
/* -------------------------------------------------------------------------- */
/*  Author :  kaiyun.yan                                                      */
/*  Email  :  kaiyun.yan@tcl.com                                              */
/*  Role   :                                                                  */
/*  Reference documents :                                                     */
/* -------------------------------------------------------------------------- */
/* ========================================================================== */
/*     Modifications on Features list / Changes Request / Problems Report     */
/* -------------------------------------------------------------------------- */
/*    date   |        author        |         Key          |     comment      */
/* ----------|----------------------|----------------------|----------------- */
/* 02/06/2024|      kaiyun.yan      |      GF7TF-4794      |Carrier Data Set- */
/*           |                      |                      |tings feature de- */
/*           |                      |                      |velopment         */
/* ----------|----------------------|----------------------|----------------- */
/******************************************************************************/

define(function(require) {
    'use strict';

    const SettingsPanel = require('modules/settings_panel');

    const HOME_PAGE_GOOGLE = 'http://www.google.com';
    const HOME_PAGE_TF = 'http://m.tracfone.com';
    const MCCMNC_TF = ['310410', '310280', '311180', '310950', '310260', '310240', '330110', '311480'];
    const GID1_TF = ['DEFF', 'DDFF', '534D', '4D4B', 'BA01270000000000'];

    return function createCarrierDataPanel() {
        let rootElement = null;
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-4013,
        //Add quick data profile option
        let serviceIdNum = 0;
        let apnSettingsKey;
        //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4013,

        function log(msg) {
            dump('carrier_data_settings: ' + msg);
        }

        function getResValue(resName, def) {
          let ret = def;
          let resVal;
          const getRes = window.api.l10n.get;
          if (getRes) {
            resVal = getRes(resName);
            if (resVal && resVal != '') {
              ret = resVal;
            }
          }
          log('getResValue: resName=' + resName + ' resVal=' + resVal + ' resValType=' + (typeof resVal)
              + ' def=' + def + ' ret=' + ret + ' getRes=' + getRes);
          return ret;
        }

        function getIccInfo(iccCardIndex) {
            let iccInfo = null;
            let iccCard = SimCardHelper.getIccInfo(iccCardIndex);
            if (iccCard) {
                iccInfo = iccCard.iccInfo;
            }
            return iccInfo;
        }

        function setCarrierData(rootElement, id, content, def) {
            if (rootElement === undefined) {
                log('setCarrierData: rootElement is undefined');
                return;
            }
            let aElement = rootElement.querySelector('span#' + id);
            if (aElement === undefined) {
                log('setCarrierData: aElement is undefined');
                return;
            }
            if (content === undefined || content == null || content == '') {
                content = def;
            }
            aElement.textContent = content;
        }

        function updateUI() {

            log('updateUI: START: serviceIdNum=' + serviceIdNum + ' apnSettingsKey=' + apnSettingsKey);

            new Promise(function(resolve, reject) {
                SettingsObserver.getValue(apnSettingsKey).then((apnSettings)=> {
                    log('updateUI: apnSettings=' + JSON.stringify(apnSettings));
                    resolve(apnSettings);
                });
            }).then((value) => {
                log('updateUI: value=' + JSON.stringify(value));
                //getNotSetString
                let notSet = getResValue();
                let carrierData;
                if (Array.isArray(value)) {
                    for (let item of value) {
                        if (item === undefined || item == null) {
                            continue;
                        }
                        if (!Array.isArray(item.types) || (item.types.indexOf('default') < 0)) {
                            continue;
                        }
                        log('updateUI: item=' + JSON.stringify(item));
                        carrierData = {};
                        carrierData.proxies = item.proxy || '';
                        carrierData.ppp_id = item.user || '';
                        carrierData.ppp_password = item.password || '';
                        carrierData.server_name = item.server || '';
                        break;
                    }
                }
                //Get homepage
                let homepage = HOME_PAGE_GOOGLE;
                let iccInfo = getIccInfo(serviceIdNum);
                let mccmnc = '';
                let gid1 = '';
                let gid1Upper = '';
                if (iccInfo != null) {
                    mccmnc = iccInfo.mcc + '' + iccInfo.mnc;
                    gid1 = (iccInfo.gid1 === undefined || iccInfo.gid1 == null) ? '' : iccInfo.gid1;
                    gid1Upper = gid1.toUpperCase() + '';
                    //isTfSim
                    if (MCCMNC_TF.indexOf(mccmnc) >= 0) {
                        for(let item of GID1_TF) {
                            if (gid1Upper.startsWith(item)) {
                                homepage = HOME_PAGE_TF;
                                break;
                            }
                        }
                    }
                }
                log('updateUI: carrierData=' + JSON.stringify(carrierData)
                        + ' homepage=' + homepage + ' mccmnc=' + mccmnc + ' gid1=' + gid1
                        + ' iccInfo=' + iccInfo + ' notSet=' + notSet);
                //setCarrierData
                if (carrierData !== undefined) {
                    setCarrierData(rootElement, 'homepage_txt', homepage, notSet);
                    setCarrierData(rootElement, 'proxies_txt', carrierData.proxies, notSet);
                    setCarrierData(rootElement, 'pppid_txt', carrierData.ppp_id, notSet);
                    setCarrierData(rootElement, 'ppppassword_txt', carrierData.ppp_password, notSet);
                    setCarrierData(rootElement, 'servername_txt', carrierData.server_name, notSet);
                    setCarrierData(rootElement, 'posturi_txt', '/servlets/mms', notSet);
                    setCarrierData(rootElement, 'subscriberid_txt', serviceIdNum + '', notSet);
                } else {
                    setCarrierData(rootElement, 'homepage_txt', homepage, notSet);
                    setCarrierData(rootElement, 'proxies_txt', notSet, notSet);
                    setCarrierData(rootElement, 'pppid_txt', notSet, notSet);
                    setCarrierData(rootElement, 'ppppassword_txt', notSet, notSet);
                    setCarrierData(rootElement, 'servername_txt', notSet, notSet);
                    setCarrierData(rootElement, 'posturi_txt', notSet, notSet);
                    setCarrierData(rootElement, 'subscriberid_txt', serviceIdNum + '', notSet);
                }
            });
        }

        function _initSoftKey() {
          var softkeyParams = {
            menuClassName: 'menu-button',
            header: {
              l10nId: 'message'
            },
            items: [{
              name: 'Select',
              l10nId: 'select',
              priority: 2,
              method: function () {
              }
            }]
          };
          SettingsSoftkey.init(softkeyParams);
          SettingsSoftkey.show();
        }

        return SettingsPanel({
            onInit: function onInit(panel) {
                log('onInit');
                rootElement = panel;
                //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4305,
                //Restructure carrier data settings code and optimize feature
                let mainHeader = rootElement.querySelector('gaia-header');
                let header = mainHeader.querySelector('h1');
                log('onInit: rootElement=' + rootElement + ' mainHeader=' + mainHeader + ' header=' + header);
                if (header) {
                  if (!header.textContent || header.textContent == '') {
                    header.textContent = 'Carrier Data Settings';
                  }
                }
                //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4305,
            },
            onBeforeShow: function onBeforeShow(panel, options) {

                //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-4013,
                //Add quick data profile option
                log('onBeforeShow: options=' + JSON.stringify(options));
                if (!options) {
                  options = {};
                }
                if (!options.serviceId) {
                  options.serviceId = 0;
                }
                serviceIdNum = options.serviceId;
                apnSettingsKey = 'ril.data.dm.apnSettings.sim' + (serviceIdNum == 1 ? 2 : 1);
                //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4013,

                _initSoftKey();
                updateUI();
            },
            onBeforeHide: function onBeforeHide() {
                log('onBeforeHide');
                SettingsSoftkey.hide();
            },
            onShow: function onShow() {
                log('onShow');
            },
            onHide: function onHide() {
                log('onHide');
            }
        });
    };
});
