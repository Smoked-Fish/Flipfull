/* global SimCardHelper SupportedNetworkTypeHelper */
'use strict';
define(function(require) { //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  require('utils/supported_network_type_helper');
  return function createCarrierOperatorSettings() {
    let elements = null;
    let serviceIndex = 0;
    let mobileConnection = null;
    const networkTypeMapping = {};
    let currentNetworkType = null;
    let listElements = null;

    function disableAutomaticSelectionState(disabled) {
      if (disabled) {
        elements.networkType.setAttribute('aria-disabled', 'true');
        elements.opAutoSelect.setAttribute('aria-disabled', 'true');
        elements.networkType.classList.add('none-select');
        elements.opAutoSelect.classList.add('none-select');
        SettingsSoftkey.hide();
      } else {
        elements.networkType.removeAttribute('aria-disabled');
        elements.opAutoSelect.removeAttribute('aria-disabled');
        elements.networkType.classList.remove('none-select');
        elements.opAutoSelect.classList.remove('none-select');
        SettingsSoftkey.show();
      }
      window.dispatchEvent(new CustomEvent('refresh'));
    }

    function updateAutomaticOperatorSelection(connection) {
      const mode = connection.networkSelectionMode;
      if (mode === 'automatic') {
        elements.opAutoDesc.setAttribute('data-l10n-id', 'on');
      } else {
        elements.opAutoDesc.setAttribute('data-l10n-id', 'off');
      }
    }

    // It only used in this file. It have been move here.
    function isSubSidyLock(index) {
      const SUBSIDY_LOCK_SIM_NETWORK = 1;
      if (navigator.subsidyLockManager) {
        return new Promise(resolve => {
          navigator.subsidyLockManager[index]
            .getSubsidyLockStatus()
            .then(value => {
              if (value && value.includes(SUBSIDY_LOCK_SIM_NETWORK)) {
                resolve(true);
              } else {
                resolve(false);
              }
            });
        });
      }
      return Promise.resolve(false);
    }

    function getDefaultPreferredNetworkType(index) {
      return new Promise(resolve => {
        Promise.all([
          mobileConnection.getSupportedNetworkTypes(),
          isSubSidyLock(index)
        ]).then(values => {
          let allTypes = [
            'nr',
            'lte',
            'wcdma',
            'tdscdma',
            'gsm',
            'cdma',
            'evdo'
          ];
          if (values[1]) {
            if (values[0].indexOf('lte') > -1) {
              allTypes = ['wcdma', 'tdscdma', 'gsm', 'cdma', 'evdo'];
            } else {
              allTypes = ['gsm', 'cdma', 'evdo'];
            }
          }
          const types = allTypes.filter(type => {
            return values[0] && values[0].indexOf(type) !== -1;
          });
          resolve(types);
        });
      });
    }

    function updateNetworkTypeSelector(supportedNetworks) {
      if (
        !mobileConnection.getPreferredNetworkType ||
        !supportedNetworks.networkTypes
      ) {
        return;
      }

      while (elements.networkTypeSelect.hasChildNodes()) {
        elements.networkTypeSelect.removeChild(
          elements.networkTypeSelect.lastChild
        );
      }

      mobileConnection.getPreferredNetworkType().then(
        result => {
          currentNetworkType = result;
          addNetworkTypes(result);
        },
        () => {
          DebugHelper.log('getPreferredNetworkType error');
          addNetworkTypes('lte');
        }
      );

      function addNetworkTypes(networkType) {
        const supportedNetworkTypes = supportedNetworks.networkTypes;
        if (networkType) {

          if (networkType.indexOf('nr') > -1) {
            elements.nrServiceSelectDesc.setAttribute('data-l10n-id', 'on');
            //GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project -begin
            updateVoNRMenu(true);
            //GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project -end
          } else {
            elements.nrServiceSelectDesc.setAttribute('data-l10n-id', 'off');
            //GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project -begin
            updateVoNRMenu(false);
            //GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project -end
          }

          if (networkType.indexOf('gsm') > -1) {
            elements.gsmServiceSelectDesc.setAttribute('data-l10n-id', 'on');
          } else {
            elements.gsmServiceSelectDesc.setAttribute('data-l10n-id', 'off');
          }

          supportedNetworkTypes.forEach(type => {
            const option = document.createElement('option');
            option.value = type;
            option.selected = networkType === type;
            // Show user friendly network mode names
            if (type in networkTypeMapping) {
              option.text = networkTypeMapping[type];
            } else {
              const l10nId = supportedNetworks.l10nIdForType(type);
              option.setAttribute('data-l10n-id', l10nId);
              // Fallback to the network type
              if (!l10nId) {
                option.textContent = type;
              }
            }
            elements.networkTypeSelect.appendChild(option);
          });
        } else {
          DebugHelper.debug('carrier: could not retrieve network type');
        }
      }
    }

    //GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project -begin
    function updateVoNRMenu(showVoNR) {
      SettingsObserver.getValue('vonr.menu.show').then((value)=>{
        if (
          typeof(value) === 'undefined' || !value ||
          value === 'false' || value === '0'
        ) {
          DebugHelper.log('updateVoNRMenu value:' + value);
          return;
        }

        //GF5GTMO-8493-jianfeng.hao - Hide VoNR for USCC card -begin
        var simOperator = OperatorUtils.getSimOperatorNameByIndex(serviceIndex);
        DebugHelper.log('updateVoNRMenu simOperator = ' + simOperator + ', serviceIndex = ' + serviceIndex);
        if (simOperator === 'USCC' ) {
          showVoNR = false;
        }
        //GF5GTMO-8493-jianfeng.hao - Hide VoNR for USCC card -end

        if (showVoNR) {
          elements.vonrServiceSelect.classList.remove('hidden');
        } else {
          elements.vonrServiceSelect.classList.add('hidden');
        }

        NavigationMap.refresh();
      });
    }

    function updateVoNRServiceStatus() {
      mobileConnection.isVoNrEnabled().then(result => {
        DebugHelper.log("updateVoNRServiceStatus isVoNREnabled: " + result);
        if (result) {
          elements.vonrServiceSelectDesc.setAttribute('data-l10n-id', 'on');
        } else {
          elements.vonrServiceSelectDesc.setAttribute('data-l10n-id', 'off');
        }
      });
    }
    //GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project -end

    function eventHandler(evt) {
      const selector = evt.target;
      const type = selector.value;
      if (currentNetworkType !== type) {
        disableAutomaticSelectionState(true);
        const request = mobileConnection.setPreferredNetworkType(type);
        request.onsuccess = () => {
          const key = 'ril.radio.preferredNetworkType';
          SettingsDBCache.getSetting(key).then(function gotPNT(value) {
            const cset = {};
            value[serviceIndex] = type;
            cset[key] = value;
            SettingsDBCache.saveSettings(cset);
            currentNetworkType = type;
            ToastHelper.showToast('changessaved');
          });
          disableAutomaticSelectionState(false);
        };
        request.onerror = () => {
          DebugHelper.debug(`setPreferredNetworkType ${request.error.message}`);
          if (request.error.message === 'NotAllowedWhenNCK') {
            const checkKey = 'force.nckDialog.show';
            SettingsDBCache.getSetting(checkKey).then(value => {
              const checkValue = value;
              if (checkValue) {
                Settings.setCurrentPanel('#simnck', {
                  serviceId: serviceIndex
                });
              } else {
                ToastHelper.showToast('devicelocked');
              }
              selector.value = currentNetworkType;
            });
          }
          disableAutomaticSelectionState(false);
        };
      }
    }

    function updateNetworkTypeLimitedItemsDisplay(conn) {
      // The following features are limited to GSM types.
      const voiceType = conn.voice && conn.voice.type;

      function doUpdate(mode) {
        if (mode !== 'gsm') {
          elements.opAutoSelect.classList.add('hidden');
        } else {
          elements.opAutoSelect.classList.remove('hidden');
        }
      }

      if (!voiceType) {
        getDefaultPreferredNetworkType(serviceIndex).then(
          supportedNetworkTypes => {
            const result = SupportedNetworkTypeHelper(supportedNetworkTypes);

            if (result.gsm || result.wcdma || result.lte) {
              doUpdate('gsm');
            } else {
              doUpdate('cdma');
            }
          }
        );
      } else {
        doUpdate(Constants.NETWORK_TYPE_MAP[voiceType]);
      }
    }

    function cardStatusChange(evt) {
      const cardIndex = evt.detail.index;
      if (cardIndex !== serviceIndex) {
        return;
      }
      updateNetworkTypeLimitedItemsDisplay(mobileConnection);
    }

    function handleEvent(evt) {
      const { target } = evt;
      evt.preventDefault();
      evt.stopPropagation();
      if (target.classList.contains('none-select')) {
        return;
      }
      switch (target.id) {
        case 'operator-autoSelect':
          Settings.setCurrentPanel('carrier_operator_settings', {
            serviceId: serviceIndex
          });
          break;
        case 'liItem-nrMenu':
          Settings.setCurrentPanel('carrier_nrmenu_settings', {
            serviceId: serviceIndex
          });
          break;
        case 'liItem-gsmMenu':
          Settings.setCurrentPanel('carrier_gsmmenu_settings', {
            serviceId: serviceIndex
          });
          break;
        //GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project -begin
        case 'vonr-menu':
          DebugHelper.log("click vonr-menu");
          Settings.setCurrentPanel('carrier_vonrmenu_settings', {
            serviceId: serviceIndex
          });
          break;
        //GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project -end
        default:
          break;
      }
    }

    return SettingsPanel({
      onInit(panel, options) {
        serviceIndex = options.serviceId;
        mobileConnection = ApiManager.connections[serviceIndex];
        if (!mobileConnection.setPreferredNetworkType) {
          NavigationMap.navigateBack();
        }
        elements = {
          header: panel.querySelector('gaia-header h1'),
          networkType: panel.querySelector('#network-type'),
          networkTypeSelect: panel.querySelector('#preferredNetworkType'),
          nrServiceSelect: panel.querySelector('#liItem-nrMenu'),
          nrServiceSelectDesc: panel.querySelector('#nr-menu-desc'),
          gsmServiceSelect: panel.querySelector('#liItem-gsmMenu'),
          gsmServiceSelectDesc: panel.querySelector('#gsm-menu-desc'),
          opAutoSelect: panel.querySelector('#operator-autoSelect'),
          opAutoDesc: panel.querySelector('#auto-select-desc'),
          //GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project -begin
          vonrServiceSelect: panel.querySelector('#vonr-menu'),
          vonrServiceSelectDesc: panel.querySelector('#vonr-menu-desc')
          //GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project -end
        };
        listElements = panel.querySelectorAll('li');
      },

      onBeforeShow(panel, options) {
        serviceIndex = options.serviceId;
        mobileConnection = ApiManager.connections[serviceIndex];

        if (SimCardHelper.isDoubleSimSlot()) {
          l10n.setAttributes(elements.header, 'simSettingsWithIndex', {
            index: serviceIndex + 1
          });
        }

        //[BUGFIX]Add-Begin by haoshuai.yu for GF5GTMO-8437 on 10/23/2025
        var simOperator = OperatorUtils.getSimOperatorNameByIndex(serviceIndex);
        DebugHelper.log('simOperator = ' + simOperator + ', serviceIndex = ' + serviceIndex);
        if (simOperator === 'USCC' ) {
          elements.nrServiceSelect.classList.add('hidden');
          elements.gsmServiceSelect.classList.add('hidden');
        } else {
            elements.nrServiceSelect.classList.remove('hidden');
            elements.gsmServiceSelect.classList.remove('hidden');
        }
        //[BUGFIX]Add-End by haoshuai.yu for GF5GTMO-8437 on 10/23/2025

        //[TASK]Add-Begin By haoshuai.yu for GF5GTMO-3595, GF5GTMO-4733 on 08/27/2024
        elements.networkType.classList.add('hidden');
        SettingsObserver.getValue('hidemenu.networkType.temp').then((result) => {
          DebugHelper.log('hidemenu.networkType.temp = ' + result);
          if (result == 1) {
            elements.networkType.classList.remove('hidden');
          } else {
            elements.networkType.classList.add('hidden');
          }
        }).catch((error) => {
          DebugHelper.log('Error getting the value: ' + error);
          elements.networkType.classList.add('hidden');
        });
        //[TASK]Add-End By haoshuai.yu for GF5GTMO-3595, GF5GTMO-4733 on 08/27/2024

        getDefaultPreferredNetworkType(serviceIndex).then(
          supportedNetworkTypes => {
            const supportedNetworkTypeHelper = SupportedNetworkTypeHelper(
              supportedNetworkTypes
            );
            updateNetworkTypeSelector(supportedNetworkTypeHelper);
          }
        );
        disableAutomaticSelectionState(false);
        updateAutomaticOperatorSelection(mobileConnection);
        updateNetworkTypeLimitedItemsDisplay(mobileConnection);
        updateVoNRServiceStatus();//GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project

        SettingsSoftkey.init(SoftParams.defaultSelect);
        ListFocusHelper.updateSoftkey(panel);
        ListFocusHelper.addEventListener(listElements);
        window.addEventListener('SIM-voicechange', cardStatusChange);
        elements.networkTypeSelect.addEventListener('blur', eventHandler);
        elements.nrServiceSelect.addEventListener('click', handleEvent, true);
        elements.gsmServiceSelect.addEventListener('click', handleEvent, true);
        elements.opAutoSelect.addEventListener('click', handleEvent, true);
        //GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project -begin
        elements.vonrServiceSelect.addEventListener('click', handleEvent, true);
        //GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project -end
      },

      onBeforeHide() {
        ListFocusHelper.removeEventListener(listElements);
        window.removeEventListener('SIM-voicechange', cardStatusChange);
        elements.networkTypeSelect.removeEventListener('blur', eventHandler);
        elements.nrServiceSelect.removeEventListener('click', handleEvent, true);
        elements.gsmServiceSelect.removeEventListener('click', handleEvent, true);
        elements.opAutoSelect.removeEventListener('click', handleEvent, true);
      }
    });
  };
});
