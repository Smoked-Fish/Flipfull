/* global SimCardHelper SupportedNetworkTypeHelper */
'use strict';
define(function(require) { //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createGsmMenuPanel() {
    let currentSettingsValue = false;

    let elements = null;
    let serviceIndex = 0;
    let mobileConnection = null;
    const networkTypeMapping = {};
    let currentNetworkType = null;

    let switchOn = null;
    let switchOff = null;

    let isNrAvailable = true;

    let isGsmAvailable = true;

    function updateNetworkTypeSelector() {
      if (
        !mobileConnection.getPreferredNetworkType
      ) {
        return;
      }

      mobileConnection.getPreferredNetworkType().then(
        result => {
          currentNetworkType = result;
          if (currentNetworkType.indexOf('nr') > -1) {
            isNrAvailable = true;
          } else {
            isNrAvailable = false;
          }
          if (currentNetworkType.indexOf('gsm') > -1) {
            isGsmAvailable = true;
          } else {
            isGsmAvailable = false;
          }
        },
        () => {
          DebugHelper.log('getPreferredNetworkType error');
        }
      );
    }

    function eventHandler(evt) {
      const enabled = evt.target.value === '1';
      if (currentSettingsValue === enabled) {
        evt.preventDefault();
        evt.stopPropagation();
        Settings.setCurrentPanel('#carrier_detail', {
          serviceId: serviceIndex
        });
        return;
      }

      const selector = evt.target;
      let networkType;

      const handleNetworkTypeUpdate = (networktype) => {
        DebugHelper.log('networktype: ' + networktype);
        const request = mobileConnection.setPreferredNetworkType(networktype);
        request.onsuccess = () => {
          const key = 'ril.radio.preferredNetworkType';
          SettingsDBCache.getSetting(key).then(function gotPNT(value) {
            const cset = {};
            value[serviceIndex] = networktype;
            cset[key] = value;
            SettingsDBCache.saveSettings(cset);
            currentNetworkType = networktype;
            ToastHelper.showToast('changessaved');
          });
        };
        request.onerror = () => {
          DebugHelper.debug(`setPreferredNetworkType ${request.error.message}`);
        };
        Settings.setCurrentPanel('#carrier_detail', {
          serviceId: serviceIndex
        });
      };

      switch (selector.value) {
        case '1':
          evt.preventDefault();
          evt.stopPropagation();
          networkType = isNrAvailable ? 'nr/lte/wcdma/gsm' : 'lte/wcdma/gsm';
          handleNetworkTypeUpdate(networkType);
          break;
        case '0':
          evt.preventDefault();
          evt.stopPropagation();
          //[BUGFIX]Add-Begin by haoshuai.yu for GF5GTMO-4654 on 10/24/2024
          closeGSMWarningDialog().then(result => {
              if (result) {
                  networkType = isNrAvailable ? 'nr/lte/wcdma' : 'lte/wcdma';
                  handleNetworkTypeUpdate(networkType);
              }
          });
          //[BUGFIX]Add-End by haoshuai.yu for GF5GTMO-4654 on 10/24/2024
          break;
        default:
          // Do nothing for default case
          break;
      }
    }

    function keyDownHandler(evt) {
       DebugHelper.log('keyDownHandler: ' + evt.key + 'serviceId: ' + serviceIndex);
      switch (evt.key) {
        case 'Backspace':
          evt.preventDefault();
          evt.stopPropagation();
          Settings.setCurrentPanel('#carrier_detail', {
            serviceId: serviceIndex
          });
          break;
        default:
          break;
      }
    }

    function closeGSMWarningDialog() {
      return new Promise(resolve => {
        const dialogConfig = {
          title: { id: 'disable_2g_Alert_title', args: {} },
          body: { id: 'gsmmenu-attention-message', args: {} },
          cancel: {
            name: 'No',
            l10nId: 'disable_2g_alert_cancel',
            priority: 1,
            callback() {
              resolve(false);
              DialogHelper.destroy();
            }
          },
          confirm: {
            name: 'Yes',
            l10nId: 'disable_2g_alert_ok',
            priority: 3,
            callback() {
              resolve(true);
              DialogHelper.destroy();
            }
          }
        };

        DialogHelper.show(dialogConfig);
      });
    }

    return SettingsPanel({
      onInit(panel, options) {
        serviceIndex = options.serviceId;
        DebugHelper.log('serviceIndex: ' + serviceIndex);
        //[TASK]Add-Begin By haoshuai.yu for GF5GTMO-4456 on 10/24/2024
        mobileConnection = ApiManager.connections[serviceIndex];
        //[TASK]Add-End By haoshuai.yu for GF5GTMO-4456 on 10/24/2024
        //[BUGFIX]Add-Begin By haoshuai.yu for GF5GTMO-5472 on 11/25/2024
        this.elements = {
          panel,
          params: {
            menuClassName: 'menu-button',
            header: { l10nId: 'message' },
            items: [
              {
                name: 'Cancel',
                l10nId: 'cancel',
                priority: 1,
                method() {
                  Settings.setCurrentPanel('#carrier_detail', {
                    serviceId: serviceIndex
                   });
                }
              },
              {
                name: 'Select',
                l10nId: 'select',
                priority: 2
              }
            ]
          }
        };
        //[BUGFIX]Add-End By haoshuai.yu for GF5GTMO-5472 on 11/25/2024
        this.initUI();
      },

      setValue(evt) {
        const enabled = evt.target.value === '1' || false;
        if (currentSettingsValue === enabled) {
          evt.preventDefault();
          evt.stopPropagation();
          Settings.setCurrentPanel('#carrier_detail', {
            serviceId: serviceIndex
          });
        }

        const option = {};
        Settings.setCurrentPanel('#carrier_detail');

        switchOn.checked = enabled;
        switchOff.checked = !enabled;
        ToastHelper.showToast('changessaved');
      },

      updateInfo(enabled) {
        currentSettingsValue = enabled;
        switchOn.checked = enabled;
        switchOff.checked = !enabled;
      },

      onBeforeShow(panel, options) {
        //[TASK]Add-Begin By haoshuai.yu for GF5GTMO-4456 on 10/24/2024
        serviceIndex = options.serviceId;
        DebugHelper.log('onBeforeShow serviceIndex: ' + serviceIndex);
        mobileConnection = ApiManager.connections[serviceIndex];
        //[TASK]Add-Begin By haoshuai.yu for GF5GTMO-4456 on 10/24/2024
        updateNetworkTypeSelector();
        SettingsSoftkey.init(this.elements.params);
        SettingsSoftkey.show();
        switchOn.addEventListener('click', eventHandler, true);
        switchOff.addEventListener('click', eventHandler, true);
        window.addEventListener('keydown', keyDownHandler, true);
        mobileConnection.getPreferredNetworkType().then(result => {
          const networkType = result;
          const liItem = panel.querySelectorAll('li');
          if (networkType.indexOf('gsm') > -1) {
            ListFocusHelper.requestFocus(panel, liItem[0]);
            this.updateInfo(true);
          } else {
            ListFocusHelper.requestFocus(panel, liItem[1]);
            this.updateInfo(false);
          }
        });
      },

      onShow(panel, options) {
        if (!options.visibilityChange) {
          mobileConnection.getPreferredNetworkType().then(result => {
            const networkType = result;
            const liItem = panel.querySelectorAll('li');
            if (networkType.indexOf('gsm') > -1) {
              ListFocusHelper.requestFocus(panel, liItem[0]);
              this.updateInfo(true);
            } else {
              ListFocusHelper.requestFocus(panel, liItem[1]);
              this.updateInfo(false);
            }
          });
        }
      },

      onBeforeHide() {
        switchOn.removeEventListener('click', eventHandler, true);
        switchOff.removeEventListener('click', eventHandler, true);
        window.removeEventListener('keydown', keyDownHandler, true);
      },

      initUI() {
        switchOn = this.elements.panel.querySelector("li input[value='1']");
        switchOff = this.elements.panel.querySelector("li input[value='0']");
      }
    });
  };
});
