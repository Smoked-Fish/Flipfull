/* global */
'use strict';

define(function(require) { //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createCellBroadcastMessagePanel() {
    const rilCbDisabled = 'ril.cellbroadcast.disabled';
    const SEARCH_LIST = 'ril.cellbroadcast.searchlist';
    const PRESET_LIST = 'ril.cellbroadcast.preset.channelslist';
    const CUSTOM_LIST = 'ril.cellbroadcast.custom.channelslist';
    let elements = {};
    let serviceId = 0;
    let listElements = null;

    function initSoftKey() {
      const softkeyParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [
          {
            name: 'Select',
            l10nId: 'select',
            priority: 2
          }
        ]
      };
      SettingsSoftkey.init(softkeyParams);
    }

    function updateChannelsPanel(disable) {
      if (disable) {
        elements.cellBroadcastConfig.setAttribute('aria-disabled', true);
        elements.cellBroadcastConfig.classList.add('none-select');
      } else {
        elements.cellBroadcastConfig.removeAttribute('aria-disabled');
        elements.cellBroadcastConfig.classList.remove('none-select');
      }

      SettingsDBCache.getSetting(rilCbDisabled).then(value => {
        const cbResult = value;
        cbResult[serviceId] = disable;
        SettingsDBCache.saveSettings({
          'ril.cellbroadcast.disabled': cbResult
        });
      });
    }

    function updateCbSwitch() {
      SettingsDBCache.getSetting(rilCbDisabled).then(result => {
        const value = result[serviceId] ? 'false' : 'true';
        updateChannelsPanel(result[serviceId]);
        elements.cellBroadcastSwitch.value = value;
        elements.cellBroadcastSwitch.classList.remove('hidden');
      });
    }

    function getDefaultChannel(slot, index) {
      return {
        simSlot: slot,
        channelType: 'preset',
        channelName: 'CB channel',
        channelId: index,
        enabled: true,
        disabled: true
      };
    }

    function convertToPreset(index, channelObj) {
      const list = [];
      if (channelObj.gsm) {
        const gsmChannelList = channelObj.gsm.split(',');
        for (let i = 0; i < gsmChannelList.length; i++) {
          list.push(getDefaultChannel(index, gsmChannelList[i]));
        }
      }
      if (channelObj.cdma) {
        const gsmChannelList = channelObj.cdma.split(',');
        for (let i = 0; i < gsmChannelList.length; i++) {
          list.push(getDefaultChannel(index, gsmChannelList[i]));
        }
      }
      return list;
    }

    function updateSlotChanged(channelObj, list, slotIndex) {
      let searchListIdsGMS = [];
      let searchListIdsCDMA = [];
      if (channelObj.gsm) {
        searchListIdsGMS = searchListIdsGMS.concat(channelObj.gsm.split(','));
      }
      if (channelObj.cdma) {
        searchListIdsCDMA = searchListIdsCDMA.concat(
          channelObj.cdma.split(',')
        );
      }

      for (let i = list.custom.length - 1; i > -1; i--) {
        const item = list.custom[i];
        if (item.simSlot === slotIndex && item.enabled) {
          // Remove unwanted custom channels
          if (
            (item.isGSM && searchListIdsGMS.indexOf(item.channelId) === -1) ||
            (!item.isGSM && searchListIdsCDMA.indexOf(item.channelId) === -1)
          ) {
            list.custom.splice(i, 1);
          } else if (item.isGSM) {
            const index = searchListIdsGMS.indexOf(item.channelId);
            searchListIdsGMS.splice(index, 1);
          } else {
            const index = searchListIdsCDMA.indexOf(item.channelId);
            searchListIdsCDMA.splice(index, 1);
          }
        }
      }
      const presetObj = {};
      presetObj.gsm = searchListIdsGMS.join(',');
      presetObj.cdma = searchListIdsCDMA.join(',');
      list.preset = list.preset.concat(convertToPreset(slotIndex, presetObj));
    }

    return SettingsPanel({
      onInit(panel) {
        listElements = document.querySelectorAll('li');
        elements = {
          cellBroadcastSwitch: panel.querySelector(
            '#cellBroadcast-mode-select'
          ),
          cellBroadcastConfig: panel.querySelector('#cell-broadcast-config')
        };
        elements.cellBroadcastSwitch.addEventListener('change', evt => {
          const disable = evt.target.value !== 'true';
          updateChannelsPanel(disable);
          ToastHelper.showToast('changessaved');
        });

        SettingsDBCache.getSettings([SEARCH_LIST, CUSTOM_LIST], results => {
          DebugHelper.debug(`SEARCH_LIST:${JSON.stringify(SEARCH_LIST)}`);
          DebugHelper.debug(`CUSTOM_LIST:${JSON.stringify(CUSTOM_LIST)}`);
          const slot1SearchList =
            Object.keys(results[SEARCH_LIST][0]).length > 0
              ? results[SEARCH_LIST][0]
              : {};
          const slot2SearchList =
            Object.keys(results[SEARCH_LIST][1]).length > 0
              ? results[SEARCH_LIST][1]
              : {};
          const list = { preset: [], custom: results[CUSTOM_LIST] || [] };
          updateSlotChanged(slot1SearchList, list, 0);
          updateSlotChanged(slot2SearchList, list, 1);
          const cSet = {};
          cSet[PRESET_LIST] = list.preset;
          cSet[CUSTOM_LIST] = list.custom;
          DebugHelper.log(
            `updatePresetAndCustomChannel:${JSON.stringify(cSet)}`
          );
          SettingsDBCache.saveSettings(cSet);
        });
      },

      onBeforeShow(panel, options) {
        serviceId = options.serviceId || serviceId;
        initSoftKey();
        ListFocusHelper.addEventListener(listElements);
        updateCbSwitch();
      },

      onBeforeHide() {
        ListFocusHelper.removeEventListener(listElements);
      }
    });
  };
});
