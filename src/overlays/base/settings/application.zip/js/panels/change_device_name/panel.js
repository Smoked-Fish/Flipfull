/* global  BluetoothContext */
'use strict';
define(function(require) { //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createChangeDeviceNamePanel() {
    let elements = null;
    let nameEntered = null;

    const softKeyParams = {
      items: [
        {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          method() {
            NavigationMap.navigateBack();
          }
        }
      ]
    };

    function handleEvent(evt) {
      if (evt.key === 'Enter') {
        evt.stopPropagation();
        evt.preventDefault();
      }
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          updateNameInput: panel.querySelector('#update-device-name-input')
        };
        elements.updateNameInput.value = BluetoothContext.info.name;
        SettingsSoftkey.init(softKeyParams);
        elements.updateNameInput.oninput = e => {
          const inputString = e.target.value;
          nameEntered = inputString.replace(/^\s+|\s+$/gu, '');
          if (nameEntered === '') {
            if (softKeyParams.items.length > 1) {
              softKeyParams.items.pop();
            }
          } else if (softKeyParams.items.length === 1) {
            softKeyParams.items.push({
              name: 'Save',
              l10nId: 'save',
              priority: 3,
              method: () => {
                BluetoothContext.setName(nameEntered).then(result => {
                  if (result) {
                    ToastHelper.showToast('changessaved');
                  }
                  NavigationMap.navigateBack();
                });
              }
            });
          }
          SettingsSoftkey.init(softKeyParams);
          SettingsSoftkey.show();
        };
      },

      onBeforeShow() {
        // Focus the input field to trigger showing the keyboard
        const cursorPos = elements.updateNameInput.value.length;
        elements.updateNameInput.setSelectionRange(cursorPos, cursorPos);
      },

      onShow() {
        SettingsSoftkey.show();
        elements.updateNameInput.focus();
        window.addEventListener('keydown', handleEvent, true);
      },

      onHide() {
        SettingsSoftkey.hide();
        window.removeEventListener('keydown', handleEvent, true);
      }
    });
  };
});
