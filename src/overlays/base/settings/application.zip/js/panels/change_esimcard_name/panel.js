'use strict';
define(function (require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createChangeCardNamePanel() {
    let index = 0;
    let iccid = '';
    let spName = '';
    let elements = null;
    const softKeyParams = {
      items: [
        {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          method() {
            NavigationMap.navigateBack();
          }
        },
        {
          name: 'Save',
          l10nId: 'save',
          priority: 3,
          method: saveAndBack
        }
      ]
    };

    function saveAndBack() {
      let nameEntered = elements.nameInput.value;
      nameEntered = nameEntered.replace(/^\s+|\s+$/g, '');
      if (!nameEntered.length) {
        nameEntered = spName;
      }
      ApiManager.eUiccManager.updateProfileNickName(iccid, nameEntered).then(
        () => {
          Settings.isBackHref = true;
          Settings.setCurrentPanel('#esimcard_manager', {
            name: nameEntered
          });
          updateCustomSimcardsName(iccid, nameEntered);
        },
        error => {
          DebugHelper.debug(`updateProfileNickName error:${error}`);
        }
      );
    }

    function handleEvent(evt) {
      if (evt.key === 'Enter') {
        evt.stopPropagation();
        elements.nameInput.focus();
      }
    }

    function updateCustomSimcardsName(iccId, name) {
      SettingsDBCache.getSetting('custom.simcards.name').then(value => {
        const values = value || {};
        if (values[iccId] === name) {
          return;
        }
        values[iccId] = name;
        SettingsDBCache.saveSettings({
          'custom.simcards.name': values
        });
      });
    }

    return SettingsPanel({
      onInit(panel, options) {
        elements = {
          nameInput: panel.querySelector('input')
        };
        index = options.index || index;
        iccid = options.iccid || iccid;
        spName = options.spName || spName;
        const { name } = options;
        elements.nameInput.value = name;
        /*
         * Two extra chars are added to the new eSIM name,
         * so here we should remove these chars.
         */
        if (
          name &&
          name[0] === '\u2068' &&
          name[name.length - 1] === '\u2069'
        ) {
          elements.nameInput.value = name.substring(1, name.length - 1);
        }
        const cursorPos = elements.nameInput.value.length;
        elements.nameInput.setSelectionRange(cursorPos, cursorPos);
      },

      onBeforeShow() {
        SettingsSoftkey.init(softKeyParams);
        SettingsSoftkey.show();
        elements.nameInput.addEventListener('keydown', handleEvent);
      },

      onShow() {
        elements.nameInput.focus();
      },

      onBeforeHide() {
        elements.nameInput.removeEventListener('keydown', handleEvent);
        SettingsSoftkey.hide();
      }
    });
  };
});
