'use strict';
define(function (require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createChangeSMDPAddressPanel() {
    let elements = null;
    const softKeyParams = {
      items: [
        {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          method() {
            NavigationMap.navigateBack();
          }
        },
        {
          name: 'Save',
          l10nId: 'save',
          priority: 3,
          method: saveAndBack
        }
      ]
    };

    function saveAndBack() {
      let addressEntered = elements.addressInput.value;
      addressEntered = addressEntered.replace(/^\s+|\s+$/g, '');
      ApiManager.eUiccManager.setSMDPAddr(addressEntered).then(
        () => {
          DebugHelper.debug(`setSMDPAddr successfully`);
          NavigationMap.navigateBack();
        },
        error => {
          DebugHelper.debug(`setSMDPAddr error:${error}`);
        }
      );
    }

    function handleEvent(evt) {
      if (evt.key === 'Enter') {
        evt.stopPropagation();
        elements.addressInput.focus();
      }
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          addressInput: panel.querySelector('input')
        };
        ApiManager.eUiccManager
          .getSMDPAddr()
          .then(value => {
            DebugHelper.log(`getSMDPAddr:${value}`);
            // Similar as "SMDPAddr:https://SM-V4-103-A-GTM.PR.GO-ESIM.COM;SMDSAddr:"
            if (value && value.split(';')[0]) {
              // eslint-disable-next-line
              elements.addressInput.value = value
                .split(';')[0]
                .split('SMDPAddr:')[1];
              const cursorPos = elements.addressInput.value.length;
              elements.addressInput.setSelectionRange(cursorPos, cursorPos);
            }
          })
          .catch(error => {
            DebugHelper.log(`getSMDPAddr error:${error}`);
          });
      },

      onBeforeShow() {
        SettingsSoftkey.init(softKeyParams);
        SettingsSoftkey.show();
        elements.addressInput.addEventListener('keydown', handleEvent);
      },

      onShow() {
        elements.addressInput.focus();
      },

      onBeforeHide() {
        elements.addressInput.removeEventListener('keydown', handleEvent);
        SettingsSoftkey.hide();
      }
    });
  };
});
