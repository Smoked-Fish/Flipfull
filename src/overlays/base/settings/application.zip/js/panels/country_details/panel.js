/**
 * Porting from Defect11475881-yanli.zhang@tcl.com-for assisted dialing on 2024/9/4
 */

/* global CountryList */
'use strict';
define(function(require) { //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createCountryDetailsPanel() {
    let serviceId = 0;
    let elements = null;
    let country = null;
    let defaultCountryValue = null;
    function initSoftKey() {
      const softkeyOk = {
        name: 'Save',
        l10nId: 'save',
        priority: 1,
        method: () => {
            saveCountryInformation();
          Settings.setCurrentPanel('#country_list', {
              serviceId
          });
        }
      };
      const softkeyOption = [
        {
          name: 'Reset',
          l10nId: 'reset',
          priority: 7,
          method: () => {
              elements.countryCode.value = defaultCountryValue.countrycode;
              elements.iddCode.value = defaultCountryValue.idd;
              elements.nddCode.value = defaultCountryValue.ndd;
              elements.cityCode.value = defaultCountryValue.areacitycode;
              elements.length.value = defaultCountryValue.length;
          }
        },
        {
          name: 'Cancel',
          l10nId: 'cancel_button',
          priority: 8,
          method: () => {
          }
        }
      ];
      const softkeyParams = {
        header: { l10nId: 'fxa-options' },
        items: []
      };
      softkeyParams.items.push(softkeyOk);
      softkeyParams.items.push.apply(softkeyParams.items, softkeyOption);
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    function saveCountryInformation() {
      const obj = {};
      obj.name = country.name;
      obj.mcc = country.mcc;
      obj.countrycode = elements.countryCode.value;
      obj.idd = elements.iddCode.value;
      obj.ndd = elements.nddCode.value;
      obj.areacitycode = elements.cityCode.value;
      obj.length = elements.length.value;
      dump('country_details setValue  is : ' + JSON.stringify(obj));
      SettingsObserver.setValue([{
          name: country.name,
          value: JSON.stringify(obj)
        }]);
    }

    return SettingsPanel({
      onInit(panel, options) {
          elements = {
          countryCode: panel.querySelector('#countryCode_input'),
              iddCode: panel.querySelector('#IDD_input'),
              nddCode: panel.querySelector('#NDD_input'),
              cityCode: panel.querySelector('#cityCode_input'),
              length: panel.querySelector('#numberLength_input')
          };
      },

      onBeforeShow(panel, options) {
          dump('country_details country : ' + JSON.stringify(options.country));
          country = options.country;
          defaultCountryValue = options.defaultCountryValue;
          elements.countryCode.value = country.countrycode;
          elements.iddCode.value = country.idd;
          elements.nddCode.value = country.ndd;
          elements.cityCode.value = country.areacitycode;
          elements.length.value = country.length;
          initSoftKey();
      },

      onBeforeHide() {
        SettingsSoftkey.hide();
      }
    });
  };
});
