/**
 * Porting from Defect11475881-yanli.zhang@tcl.com-for assisted dialing on 2024/9/4
 */

/* global CountryList */
'use strict';
define(function(require) {
  const SettingsPanel = require('modules/settings_panel');

  return function createCountryListPanel() {
    let serviceId = 0;
    let elements = null;
    let referCountry = null;
    let defaultCountry = null;
    let idNumber = null;
    let userCountryList = null;
    function initSoftKey() {
      var softkeyParams = {
            menuClassName: 'menu-button',
            header: {
                l10nId: 'message'
            },
            items: [{
                name: 'OK',
                l10nId: 'ok',
                priority: 1,
                method: function () {
                  setCurrentCountry();
                  SettingsObserver.getValue(referCountry.name).then((result) => {
                      dump('country_list click ok result = ' + result);
                      if (result === undefined) {
                          SettingsObserver.setValue([{
                              name: 'current.country',
                              value: JSON.stringify(referCountry)
                          }]);
                      } else {
                          SettingsObserver.setValue([{
                              name: 'current.country',
                              value: result
                          }]);
                          referCountry = JSON.parse(result);
                      }
                      Settings.setCurrentPanel('#assisted_dialing', {
                          serviceId,
                          country: referCountry
                        });
                    });
                }
            }, {
                name: 'Set',
                l10nId: 'set',
                priority: 3,
                method: function () {
                    setCurrentCountry();
                    SettingsObserver.getValue(referCountry.name).then((result) => {
                        dump('country_list click set  result = ' + result);
                        if (result === undefined) {
                            SettingsObserver.setValue([{
                                name: 'current.country',
                                value: JSON.stringify(referCountry)
                            }]);
                        } else {
                            SettingsObserver.setValue([{
                                name: 'current.country',
                                value: result
                            }]);
                            referCountry = JSON.parse(result);
                        }
                        Settings.setCurrentPanel('#country_details', {
                            serviceId,
                            id: idNumber,
                            country: referCountry,
                            defaultCountryValue: defaultCountry
                        });
                    });
                }
            }]
        };
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
    }

   function setCurrentCountry() {
      const li = document.querySelector('#country_list li.focus');
      if (li) {
          const { id } = document.activeElement;
        referCountry = userCountryList[id];
        defaultCountry = userCountryList[id];
        idNumber = id;
        dump('country_list setCurrentCountry country : ' + JSON.stringify(referCountry));
      }
    }

    return SettingsPanel({
      onInit(panel, options) {
        serviceId = options.serviceId || serviceId;
        elements = {
          countryContainer: panel.querySelector('#countryContainer')
        };
        if (options.countryList) {
            userCountryList = options.countryList;
        }
        elements.countryContainer.innerHTML = '';
        var i = 0;
        if (userCountryList) {
            for (let coun in userCountryList) {
                const li = document.createElement('li');
                const nameContainer = document.createElement('span');
                li.id = i;
                nameContainer.dir = 'auto';
                nameContainer.textContent = userCountryList[coun].name;
                li.appendChild(nameContainer);
                elements.countryContainer.appendChild(li);
                i++;
            }
            window.dispatchEvent(new CustomEvent('refresh'));
        }
      },

      onBeforeShow(panel, options) {
        initSoftKey();
      },

      onBeforeHide() {
        SettingsSoftkey.hide();
      }
    });
  };
});
