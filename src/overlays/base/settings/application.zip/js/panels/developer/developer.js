/* global ScreenLayout AppOrigin */
'use strict';
define(function() { // eslint-disable-line

  /**
   * @alias module:developer/developer
   * @class Developer
   * @returns {Developer}
   */
  const Developer = function Developer() {
    this.developerElements = null;
  };

  Developer.prototype = {
    /**
     * Initialization.
     *
     * @access public
     * @memberOf Developer.prototype
     * @param  {HTMLElement} elements
     */
    init: function init(elements) {
      this.developerElements = elements;

      this.developerElements.ftuLauncher.addEventListener(
        'click',
        this.launchFTU
      );

      /*
       * Hide software home button whenever the device has no hardware
       * home button
       */
      if (!ScreenLayout.getCurrentLayout('hardwareHomeButton')) {
        this.developerElements.softwareHomeButton.style.display = 'none';
        // Always set homegesture enabled on tablet, so hide the setting
        if (!ScreenLayout.getCurrentLayout('tiny')) {
          this.developerElements.homegesture.style.display = 'none';
        }
      }
    },

    /**
     * Launch FTU app.
     *
     * @access private
     * @memberOf Developer.prototype
     */
    launchFTU: function launchFTU() {
      const manifestUrl = AppOrigin.getManifestURL('ftu');
      window.open(manifestUrl, '_blank', 'kind=app,noopener=yes');
    }
  };

  return function developer() {
    return new Developer();
  };
});
