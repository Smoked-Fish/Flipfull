/* global  BluetoothContext, BTConnectionManager */
'use strict';
define(function(require) { //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createNearbyDevicePanel() {
    const DEVICE_TYPES = [
      'audio-card',
      'input-keyboard',
      'audio-input-microphone'
    ];
    let elements = null;
    let currentPairingItem = null;
    let discoveringEnabled = false;
    let isPairing = false;
    let firstFoundDevice = true;

    const selectParams = {
      items: [
        {
          name: 'select',
          l10nId: 'select',
          priority: 2,
          method() {
            handleSelect();
          }
        }
      ]
    };

    const selectAndScanParams = {
      items: [
        {
          name: 'select',
          l10nId: 'select',
          priority: 2,
          method() {
            handleSelect();
          }
        },
        {
          name: 'Rescan',
          l10nId: 'rescan',
          priority: 3,
          method: () => {
            searchAgain();
          }
        }
      ]
    };

    const scanParams = {
      items: [
        {
          name: 'Rescan',
          l10nId: 'rescan',
          priority: 3,
          method: () => {
            searchAgain();
          }
        }
      ]
    };

    function searchAgain() {
      discoveringEnabled = true;
      BluetoothContext.startDiscovery().then(result => {
        if (result) {
          elements.devicesList.innerHTML = '';
          elements.searchingDevices.classList.remove('hidden');
          elements.noDevicesNearby.classList.add('hidden');
          firstFoundDevice = true;
          SettingsSoftkey.hide();
          DebugHelper.log('searchAgain success.');
        } else {
          if (elements.devicesList.childElementCount === 0) {
            elements.searchingDevices.classList.add('hidden');
            elements.noDevicesNearby.classList.remove('hidden');
          }
          updateSoftkey(scanParams);
          firstFoundDevice = false;
          discoveringEnabled = false;
          DebugHelper.log('searchAgain failed.');
        }
      });
    }

    function updateSoftkey(params) {
      if (isPairing) {
        SettingsSoftkey.hide();
      } else {
        SettingsSoftkey.init(params);
        SettingsSoftkey.show();
      }
    }

    function updateSoftkeyByPaired(paired) {
      if (paired) {
        updateSoftkey(scanParams);
      } else {
        updateSoftkey(selectAndScanParams);
      }
    }

    function focusChanged(evt) {
      const focusItem = evt.detail.focusedElement;
      if (isPairing || !focusItem.classList.contains('bluetooth-device')) {
        SettingsSoftkey.hide();
        return;
      }

      if (discoveringEnabled) {
        updateSoftkey(selectParams);
      } else {
        updateSoftkeyByPaired(focusItem.device.paired);
      }
    }

    function updateSearchingStatus(e) {
      const { discovering } = e.detail;
      discoveringEnabled = discovering;
      if (discovering) {
        elements.devicesList.classList.remove('hidden');
        elements.searchingDevices.classList.remove('hidden');
        elements.noDevicesNearby.classList.add('hidden');
        updateSoftkey(selectParams);
      } else {
        const devicesNearby = BluetoothContext.getRemoteDevices();
        if (devicesNearby.length === 0) {
          elements.noDevicesNearby.classList.remove('hidden');
          elements.searchingDevices.classList.add('hidden');
          elements.devicesList.classList.add('hidden');
          updateSoftkey(scanParams);
        } else {
          elements.searchingDevices.classList.add('hidden');
          updateSoftkey(selectAndScanParams);
        }
      }
    }

    function updatePairedSoftkey(e) {
      const { device } = e.detail;
      if (device.paired) {
        const pairedItem = elements.panel.querySelector(
          `li[address="${device.address}"]`
        );
        if (pairedItem) {
          const smallElement = pairedItem.querySelector('small');
          smallElement.setAttribute('data-l10n-id', 'paried-with-device');
          smallElement.setAttribute(
            'data-l10n-args',
            JSON.stringify({
              deviceName: device.name
            })
          );
        }
      }

      const focusItem = elements.panel.querySelector('li.focus');
      if (focusItem) {
        updateSoftkeyByPaired(focusItem.device.paired);
      }
    }

    function connectHeadsetDevice(deviceItem) {
      if (DEVICE_TYPES.indexOf(deviceItem.type) > -1) {
        BTConnectionManager.connectDevice(true, deviceItem).then(result => {
          DebugHelper.log(`connectHeadsetDevice result :${result}`);
        });
      }
    }

    function showConfirmDialog(device) {
      const dialogConfig = {
        title: { id: 'error-pair-title', args: {} },
        body: {
          id: 'error-pair-fail',
          args: { devicename: device.name }
        },
        desc: { id: 'error-pair-checkpin', args: {} },
        cancel: {
          l10nId: 'cancel',
          priority: 1,
          callback() {
            isPairing = false;
            updateSoftkeyByPaired(false);
          }
        },
        confirm: {
          l10nId: 'pair',
          priority: 3,
          callback() {
            toPairDevice(device, currentPairingItem);
          }
        }
      };
      DialogHelper.show(dialogConfig);
    }

    function toPairDevice(device, pairingItem) {
      currentPairingItem = pairingItem;
      currentPairingItem.setAttribute('aria-disabled', 'true');
      device.paired = 'pairing';
      isPairing = true;
      device.updateDescriptionText();
      updateItemDescriptionText(currentPairingItem, null, device);
      elements.searchingDevices.classList.add('hidden');
      SettingsSoftkey.hide();
      BluetoothContext.pairDevice(true, device.address).then(result => {
        isPairing = false;
        if (result) {
          connectHeadsetDevice(device);
          device.paired = true;

          currentPairingItem.removeAttribute('aria-disabled');
          updateSoftkeyByPaired(true);
        } else {
          device.paired = false;

          device.state = 'pairFailed';
          device.updateDescriptionText();
          if (currentPairingItem) {
            updateItemDescriptionText(currentPairingItem, null, device);
            showConfirmDialog(device);
            currentPairingItem.removeAttribute('aria-disabled');
            updateSoftkey(selectAndScanParams);
          }
        }
      });
    }

    // eslint-disable-next-line max-params
    function updateItemDescriptionText(li, element, device) {
      if (!element) {
        element = li.querySelector('small');
      }
      switch (device.descriptionText) {
        case 'tapToConnect':
          li.removeAttribute('aria-disabled');
          li.classList.remove('none-select');
          element.setAttribute('data-l10n-id', 'paried-with-device');
          element.setAttribute(
            'data-l10n-args',
            JSON.stringify({
              deviceName: device.name
            })
          );
          break;
        case 'pairing':
          li.setAttribute('aria-disabled', true);
          li.classList.add('none-select');
          element.setAttribute('data-l10n-id', 'device-status-pairing');
          break;
        case 'paired':
          li.removeAttribute('aria-disabled');
          li.classList.remove('none-select');
          element.setAttribute('data-l10n-id', 'paried-with-device');
          element.setAttribute(
            'data-l10n-args',
            JSON.stringify({
              deviceName: device.name
            })
          );
          break;
        case 'connecting':
          li.setAttribute('aria-disabled', true);
          li.classList.add('none-select');
          element.setAttribute('data-l10n-id', 'device-status-connecting');
          break;
        case 'connectedWithDeviceMedia':
          li.removeAttribute('aria-disabled');
          li.classList.remove('none-select');
          element.setAttribute('data-l10n-id', 'device-status-tap-disconnect');
          break;
        case 'connectedWithDevice':
          li.removeAttribute('aria-disabled');
          li.classList.remove('none-select');
          element.setAttribute('data-l10n-id', 'device-status-tap-disconnect');
          break;
        case 'connectedWithMedia':
          li.removeAttribute('aria-disabled');
          li.classList.remove('none-select');
          element.setAttribute('data-l10n-id', 'device-status-tap-disconnect');
          break;
        case 'connectedWithNoProfileInfo':
          li.removeAttribute('aria-disabled');
          li.classList.remove('none-select');
          element.setAttribute('data-l10n-id', 'device-status-connected');
          break;
        case 'disconnected':
          if (device.hasAudioCard || device.type === 'input-keyboard') {
            li.removeAttribute('aria-disabled');
            li.classList.remove('none-select');
            if ('#device_in_area' === Settings.getCurrentPanel()) {
              element.setAttribute('data-l10n-id', 'paried-with-device');
              element.setAttribute(
                'data-l10n-args',
                JSON.stringify({
                  deviceName: device.name
                })
              );
            } else {
              element.removeAttribute('data-l10n-id');
              element.setAttribute('data-l10n-id', 'device-status-tap-connect');
            }
          }
          break;
        case 'pairFailure':
          li.removeAttribute('aria-disabled');
          li.classList.remove('none-select');
          element.setAttribute('data-l10n-id', 'device-status-tap-pair');
          break;
        default:
          break;
      }
    }

    function createDeviceItem(device) {
      const nameElement = document.createElement('span');
      nameElement.textContent =
        device.name !== '' ? device.name : device.address;
      nameElement.classList.add('no-wrap');
      const descSmall = document.createElement('small');
      if (DEVICE_TYPES.indexOf(device.type) > -1) {
        if (device.connectionStatus === 'connected') {
          descSmall.setAttribute(
            'data-l10n-id',
            'device-status-tap-disconnect'
          );
        } else {
          descSmall.setAttribute('data-l10n-id', 'device-status-tap-connect');
        }
      } else {
        descSmall.setAttribute('data-l10n-id', 'device-status-tap-pair');
      }
      descSmall.classList.add('no-wrap');

      const li = document.createElement('li');
      const anchor = document.createElement('a');
      li.classList.add('bluetooth-device');
      const type = device.type === '' ? 'unknown' : `${device.type}`;
      li.classList.add(`bluetooth-type-${type}`);
      li.device = device;
      li.setAttribute('address', device.address);
      updateItemDescriptionText(li, descSmall, device);

      anchor.appendChild(nameElement);
      anchor.appendChild(descSmall); // Should append this first
      li.appendChild(anchor);
      return li;
    }

    function updateListItem(e) {
      const { device } = e.detail;
      const li = createDeviceItem(device);
      if (firstFoundDevice) {
        firstFoundDevice = false;
        li.classList.add('focus');
        li.focus();
        updateSoftkey(selectParams);
        elements.searchingDevices.classList.add('hidden');
        elements.devicesList.classList.remove('hidden');
      }
      elements.devicesList.appendChild(li);
      window.dispatchEvent(new CustomEvent('refresh'));
    }

    function handleSelect() {
      const focusItem = document.querySelector('.focus');
      if (!focusItem) {
        return;
      }

      toPairDevice(focusItem.device, focusItem);
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          panel,
          devicesList: panel.querySelector('#devices-list'),
          searchingDevices: panel.querySelector('#searching-devices'),
          noDevicesNearby: panel.querySelector('#no-devices-nearby')
        };
      },

      onBeforeShow() {
        document.addEventListener('focusChanged', focusChanged);

        window.addEventListener('discovering-change', updateSearchingStatus);
        window.addEventListener('paired-change', updatePairedSoftkey);
        window.addEventListener('new-device-found', updateListItem);
      },

      onShow() {
        if (isPairing) {
          return;
        }
        searchAgain();
      },

      onBeforeHide() {
        document.removeEventListener('focusChanged', focusChanged);
        window.removeEventListener('discovering-change', updateSearchingStatus);
        window.removeEventListener('paired-change', updatePairedSoftkey);
        window.removeEventListener('new-device-found', updateListItem);
      },

      onHide() {
        BluetoothContext.stopDiscovery();
      },
      onUninit() {
        currentPairingItem = null;
        discoveringEnabled = false;
        isPairing = false;
        firstFoundDevice = true;
      }
    });
  };
});
