'use strict';
define(function(require) { //eslint-disable-line

  const SettingsPanel = require('modules/settings_panel');

  return function createEmergencyAlertPanel() {
    //Defect10732663-jianfeng.hao-[Patch]Do not show 'DESELECT' when the option is clicked-begin
    const CMAS_DB_LIST = [
      'cmas.volume.enable',
      'cmas.vibrate.enable',
      'cmas.extreme.enabled',
      'cmas.severe.enabled',
      'cmas.amber.enabled',
      'cmas.safety.enabled',
      'cmas.weatest.enabled',
      'cmas.monthlytest.enabled',
      'spanish.alert.enabled'
    ];
    //Defect10732663-jianfeng.hao-[Patch]Do not show 'DESELECT' when the option is clicked-end
    //[USCC][CMAS][RC1.1.27]Task10980517-jianfeng.hao-begin
    const CMAS_ALERT_LIST = [
      'cmas.extreme.enabled',
      'cmas.severe.enabled',
      'cmas.amber.enabled',
      'cmas.safety.enabled',
      'cmas.weatest.enabled',
      'cmas.monthlytest.enabled',
      'cmas.volume.enable',
      'cmas.vibrate.enable'
    ];
    let isShowDialog = false;//whether the confirm dialog has been showed.
    //[USCC][CMAS][RC1.1.27]Task10980517-jianfeng.hao-end

    let listElements = null;
    let elements = null;

    const deselectParams = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [
        {
          name: 'Deselect',
          l10nId: 'deselect',
          priority: 2
        }
      ]
    };

    function updateSoftKey() {
      const focusedElement = elements.currentPanel.querySelector('.focus');
      if (!focusedElement || focusedElement.classList.contains('none-select')) {
        SettingsSoftkey.hide();
        return;
      }
      const inputElement = focusedElement.querySelector('input');
      if (inputElement && inputElement.checked) {
        SettingsSoftkey.init(deselectParams);
      } else {
        SettingsSoftkey.init(SoftParams.defaultSelect);
      }
      SettingsSoftkey.show();
    }

    //[USCC][CMAS][RC1.1.27]Task10980517-jianfeng.hao-begin
    //When uncheck the alert checkbox, will pop up confirm dialog.
    function popupConfirmDialog() {
      const focusedElement = elements.currentPanel.querySelector('.focus');
      if (!focusedElement || focusedElement.classList.contains('none-select')) {
        return;
      }
      const inputElement = focusedElement.querySelector('input');
      if (inputElement && !inputElement.checked && !isShowDialog) {
        //uncheck box
        showConfirmDialog(inputElement);
      }
    }

    function showConfirmDialog(inputElement) {
      const dialogConfig = {
        title: {
          id: 'forgetNetwork-confirmation',
          args: {}
        },
        body: {
          id: 'uncheck_alert_tip',
          args: {}
        },
        cancel: {
          l10nId: 'cancel',
          priority: 1,
          callback: () => {
            isShowDialog = false;
            inputElement.checked = true;
            let data_name = inputElement.getAttribute('data-name');
            const cSet = {};
            cSet[data_name] = true;
            SettingsDBCache.saveSettings(cSet);
          }
        },
        confirm: {
          l10nId: 'yes',
          priority: 3,
          callback: () => {
            isShowDialog = false;
          }
        }
      };

      isShowDialog = true;
      DialogHelper.show(dialogConfig);
    }
    //[USCC][CMAS][RC1.1.27]Task10980517-jianfeng.hao-begin

    function keyDownHandler(evt) {
      evt.stopPropagation();
      ActivityHelper.start({
        name: 'alert_inbox'
      });
    }

    function updateServerDisplay(enabled, severeEnabled) {
      elements.extremeInput.checked = enabled;
      elements.severeInput.checked =
        typeof severeEnabled !== Constants.UNDEFINED ? severeEnabled : enabled;
      elements.severeInput.disabled = !enabled;
      if (enabled) {
        elements.severeItem.classList.remove('none-select');
        elements.severeItem.removeAttribute('aria-disabled');
      } else {
        elements.severeItem.setAttribute('aria-disabled', true);
        elements.severeItem.classList.add('none-select');
      }
    }

    function handleExtremeChange(enabled) {
      updateServerDisplay(enabled);
      const cSet = {};
      cSet['cmas.severe.enabled'] = enabled;
      SettingsDBCache.saveSettings(cSet);
    }

    //Defect10732663-jianfeng.hao-[Patch]Do not show 'DESELECT' when the option is clicked-begin
    function addAlertDBListenerForSoftKey() {
      CMAS_DB_LIST.forEach(key => {
        SettingsDBCache.observe(key, true, updateSoftKey, true);
      });

      //[USCC][CMAS][RC1.1.27]Task10980517-jianfeng.hao-begin
      if (OperatorUtils.isUSCCFamily()) {
        CMAS_ALERT_LIST.forEach(key => {
          SettingsDBCache.observe(key, true, popupConfirmDialog, true);
        });
      }
      //[USCC][CMAS][RC1.1.27]Task10980517-jianfeng.hao-end
    }

    function removeAlertDBListenerForSoftKey() {
      CMAS_DB_LIST.forEach(key => {
        SettingsDBCache.unobserve(key, updateSoftKey);
      });

      //[USCC][CMAS][RC1.1.27]Task10980517-jianfeng.hao-begin
      if (OperatorUtils.isUSCCFamily()) {
        CMAS_ALERT_LIST.forEach(key => {
          SettingsDBCache.unobserve(key, popupConfirmDialog);
        });
      }
      //[USCC][CMAS][RC1.1.27]Task10980517-jianfeng.hao-end
    }
    //Defect10732663-jianfeng.hao-[Patch]Do not show 'DESELECT' when the option is clicked-end

    return SettingsPanel({
      onInit(panel) {
        elements = {
          currentPanel: panel,
          alertInbox: panel.querySelector('#alert-inbox'),
          receiveAlertBody: panel.querySelector('#receive-alert-body'),
          severeItem: panel.querySelector('#severe-item'),
          presidentialItem: panel.querySelector('#presidential-item'),
          extremeInput: panel.querySelector(
            'input[data-name="cmas.extreme.enabled"]'
          ),
          severeInput: panel.querySelector(
            'input[data-name="cmas.severe.enabled"]'
          )
          // Task10125288-daijun.xiao@tcl.com - add Spanish Alert option - begin
          ,
          receiveSpanishAlert: panel.querySelector('#receive-additional-language')
          // Task10125288-daijun.xiao@tcl.com - add Spanish Alert option - end
          // Task10125301-daijun.xiao@tcl.com - add Reminder option - begin
          ,
          reminderOption: panel.querySelector('#alert-reminder')
          // Task10125301-daijun.xiao@tcl.com - add Reminder option - end
        };
		//GF7VZW-6064 zhihai.yu -begin
		let presidentialLabel = panel.querySelector('#presidential-label');
		if (isShowAsNationalAlert()) {
			presidentialLabel.textContent = window.api.l10n.get('national-alert');
		}else {
			presidentialLabel.textContent = window.api.l10n.get('presidential-alert');
		}
		//GF7VZW-6064 zhihai.yu -end
        listElements = panel.querySelectorAll('li');
      },

      onBeforeShow() {
        updateSoftKey();
        SettingsDBCache.getSettings(
          ['cmas.settings.show', 'cmas.extreme.enabled', 'cmas.severe.enabled'],
          result => {
            const alertBodyShow = result['cmas.settings.show'];
            const extremeEnabled = result['cmas.extreme.enabled'];
            const severeEnabled = result['cmas.severe.enabled'];
            if (alertBodyShow) {
              elements.receiveAlertBody.classList.remove('hidden');
            }
            //add by zhihai.yu for GF7EE-879-begin
            if(isNeedShowPresidentialMenu()){
               elements.presidentialItem.classList.remove('hidden');
            }else{
               elements.presidentialItem.classList.add('hidden');
            }
            //add by zhihai.yu for GF7EE-879-end
            // Task10125288-daijun.xiao@tcl.com - add Spanish Alert option - begin
            if (isNeedShowSpanishMenu()) {
              elements.receiveSpanishAlert.classList.remove('hidden');
            }
            // Task10125288-daijun.xiao@tcl.com - add Spanish Alert option - end
            // Task10125301-daijun.xiao@tcl.com - add Reminder option - begin
            if (isNeedReminderMenu()) {
              elements.reminderOption.classList.remove('hidden');
            }
            // Task10125301-daijun.xiao@tcl.com - add Reminder option - end
            updateServerDisplay(extremeEnabled, severeEnabled);
            window.dispatchEvent(new CustomEvent('refresh'));
          }
        );
        SettingsDBCache.observe(
          'cmas.extreme.enabled',
          true,
          handleExtremeChange,
          true
        );
        // Task10125288-daijun.xiao@tcl.com - add Spanish Alert option - begin
        if (isNeedObserSpanishMenuValue()) {
          SettingsDBCache.observe(
            'spanish.alert.enabled',
            false,
            handleSpanishmenuChange,
            true
          );
        }
        // Task10125288-daijun.xiao@tcl.com - add Spanish Alert option - end
        ListFocusHelper.addEventListener(listElements, updateSoftKey);
        elements.alertInbox.addEventListener('click', keyDownHandler);

        //Defect10732663-jianfeng.hao-[Patch]Do not show 'DESELECT' when the option is clicked-begin
        addAlertDBListenerForSoftKey();
        //Defect10732663-jianfeng.hao-[Patch]Do not show 'DESELECT' when the option is clicked-end
      },

      onBeforeHide() {
        // Task10125288-daijun.xiao@tcl.com - add Spanish Alert option - begin
       if (isNeedObserSpanishMenuValue()) {
          SettingsDBCache.unobserve(
            'spanish.alert.enabled',
            handleSpanishmenuChange
          );
        }
       // Task10125288-daijun.xiao@tcl.com - add Spanish Alert option - end
        SettingsDBCache.unobserve('cmas.extreme.enabled', handleExtremeChange);
        elements.alertInbox.removeEventListener('click', keyDownHandler);
        ListFocusHelper.removeEventListener(listElements, updateSoftKey);

        //Defect10732663-jianfeng.hao-[Patch]Do not show 'DESELECT' when the option is clicked-begin
        removeAlertDBListenerForSoftKey();
        //Defect10732663-jianfeng.hao-[Patch]Do not show 'DESELECT' when the option is clicked-end
      }
    });
  };

  // Task10125288-daijun.xiao@tcl.com - add Spanish Alert option - begin
  function isNeedShowSpanishMenu() {
    if (OperatorUtils.isTMOFamily() || OperatorUtils.isMetroPCSFamily()) {
      return false;
    }
    return true;
  };

  function isNeedObserSpanishMenuValue() {
    let ret = false;
    if (!isNeedShowSpanishMenu()) {
      return ret;
    }
    if (OperatorUtils.isVZWFamily()) {
      ret = true;
    }

    return ret;
  };

  function handleSpanishmenuChange(value) {
    dump("xdj----handleSpanishmenuChange:"+value);
    if (OperatorUtils.isVZWFamily()) {
      setProp('spanish.alert.enabled',value ? 1 : 0);
    }
  };

  function setProp(key, value) {
    window.remoteHelper.setproperty(key,value,(response)=>{
      dump('remoteHelper success ,setpropery');
    }, ()=>{
      dump('remoteHelper error ,setpropery' + key);
    });
  };
  // Task10125288-daijun.xiao@tcl.com - add Spanish Alert option - end

  // Task10125301-daijun.xiao@tcl.com - add Reminder option - begin
  function isNeedReminderMenu() {
    let ret = false;
    // [VZW:VZ_REQ_CMAS_25043]-daijun.xiao@tcl.com-REMINDER-begin
    if (OperatorUtils.isVZWFamily()) {
      ret = true;
    }
    // [VZW:VZ_REQ_CMAS_25043]-daijun.xiao@tcl.com-REMINDER-end

    return ret;
  };
  // Task10125301-daijun.xiao@tcl.com - add Reminder option - end

  function isShowAsNationalAlert() {
    let ret = true;
    //task GF7EE-862 zhihai.yu@tcl.com-begin
    let mccMnc = OperatorUtils.getMccMnc();
    dump("zhy----mccmnc=:"+mccMnc);
    if(mccMnc && mccMnc.startsWith('214')){
      ret = false;
    }
    //task GF7EE-862 zhihai.yu@tcl.com-end
    return ret;
  };

  //add by zhihai.yu for GF7EE-879-begin
  function isNeedShowPresidentialMenu() {

    let ret = true;
    let buildOptName = OperatorUtils.getBuildOperatorName();
    dump("zhy----buildOptName=:"+buildOptName);

    let mccMnc = OperatorUtils.getMccMnc();
    dump("zhy----mccmnc=:"+mccMnc);
    if((mccMnc && mccMnc.startsWith('234')) || buildOptName == "EE"){
      ret = false;
    }
    return ret;
  };
  //add by zhihai.yu for GF7EE-879-end
});
