/**
 * Created by gangchen on 14/6/19.
 */
define(['require','modules/settings_panel','modules/settings_service'],function(require) {
  'use strict';
  var SettingsPanel = require('modules/settings_panel');
  var SettingsService = require('modules/settings_service');

  return function about_source_code_panel() {
    var _iframe;
    var previousLanguage = null;
    var currentLanguage = null;
    var url = 'https://www.tclusa.com/mobile/end-user-license-agreement/';
    var projectName;//Defect10803287-tfzhang@tcl.com

    let isVoiceOnly = false;
    navigator.b2g.engmodeManager.getPropertyValue('ro.product.model').then((model) => {
      if (model === 'T435V') {
        // dump("is voice only true");
        isVoiceOnly = true;
        console.log(`apnItems isVoiceOnly-->: ${isVoiceOnly}`);
      }
    });
    function _initIframe() {
      _iframe.focus();
    }

    function _initSoftKey() {
      const softkeyParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [{
          name: 'openUrl',
          l10nId: 'open-url',
          priority: 2,
          method: function () {
          }
        }]
      };
      const softkeyParamsNone = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [{
          name: '',
          l10nId: '',
          priority: 2,
          method: function() {}
        }]
      };

      if (isVoiceOnly){
        console.log(`apnItems chaozhongwang: is VoiceOnly`);
        SettingsSoftkey.init(softkeyParamsNone);
      }else {
        SettingsSoftkey.init(softkeyParams);
        console.log(`apnItems chaozhongwang:is Not  VoiceOnly`);
      }
      SettingsSoftkey.show();
    }

    function keyDownHandlerIsVoiceOnly(evt) {
      switch (evt.key) {
        case 'Backspace':
          NavigationMap.navigateBack();
          evt.preventDefault();
          break;
        default:
          break;
      }
    }

    function checkCurrentLanguage() {
      // Task10114480-tfzhang@tcl.com-modify-begin
      window.SettingsObserver.getValue('language.current').then((value)=>{
        currentLanguage = value;
        if (previousLanguage !== currentLanguage) {
          getLicense();
          previousLanguage = currentLanguage;
        }
      });
      // Task10114480-tfzhang@tcl.com-modify-end
    }

    function keyDownHandler(evt) {
      switch (evt.key) {
        case 'Enter':
          //Defect10803287-tfzhang@tcl.com-add-begin
          // if(projectName === 'VZW'){
            url = 'https://www.tclusa.com/mobile/end-user-license-agreement/';
          // }else{
          //   url = 'https://us.alcatelmobile.com/terms-conditions/';
          // }
          //Defect10803287-tfzhang@tcl.com-add-end
          // Task10114480-tfzhang@tcl.com-modify-begin
          let activity = new WebActivity(
            'view',
            {
              type: 'url',
              url: url,
              isPrivate: false
            }
          );
          activity.start();
          // Task10114480-tfzhang@tcl.com-modify-end
        case 'Backspace':
          SettingsService.navigate('about_legal');
          evt.preventDefault();
          break;
      }
    }

    function isExistFile(testURL, callback) {
      let xmlHttp = new XMLHttpRequest();

      xmlHttp.onreadystatechange = () => {
        if (xmlHttp.readyState === 4) {
          if (xmlHttp.status === 200) {
            //file at URL exist
            callback(true);
          } else {
            callback(false);
          }
        }
      };

      xmlHttp.open("GET", testURL);
      try {
        xmlHttp.send();
      } catch(e) {
        callback(false);
      }
    }

    function getLicense() {
      // Task10114480-tfzhang@tcl.com-modify-begin
      //Defect10803287-tfzhang@tcl.com-modify-begin
      Promise.all([window.SettingsObserver.getValue('language.current'),
        navigator.b2g.engmodeManager.getPropertyValue("ro.operator.name")]).then((value)=>{
          let lang = value[0];
          let licensePath;
          let defaultLicensePath;
          projectName = value[1];
          // if(value[1] === 'VZW'){
            licensePath = 'shared/locales/kaios_license/end_user_license_tcl.' + lang + '.html';
            defaultLicensePath = 'shared/locales/kaios_license/end_user_license_tcl.en-US.html';
          // }else{
          //   licensePath = 'shared/locales/kaios_license/end_user_license.' + lang + '.html';
          //   defaultLicensePath = 'shared/locales/kaios_license/end_user_license.en-US.html';
          // }
          isExistFile(licensePath, (isExist) => {
            _iframe.src = isExist ? licensePath : defaultLicensePath;
            _iframe.onload = () => {
              _iframe.contentDocument.body.setAttribute('style','word-wrap : break-word !important');
              if (!isVoiceOnly){
                _iframe.contentDocument.addEventListener('keydown', keyDownHandler);
              }else {
                _iframe.contentDocument.addEventListener('keydown', keyDownHandlerIsVoiceOnly);
                const links = _iframe.contentDocument.getElementsByTagName("a");
                console.log(`apnItems chaozhongwang:    ${links.length}`);
                for (let i = 0; i < links.length; i++) {
                  links[i].removeAttribute("href");
                  links[i].style.color = "black";
                  console.log(`apnItems chaozhongwang:links: ${links[i]}`);
                }
              }
            }
          });
        });
        //Defect10803287-tfzhang@tcl.com-modify-begin
      // Task10114480-tfzhang@tcl.com-modify-end
    }

    return SettingsPanel({
      onInit: function (panel) {
        _iframe = document.getElementById('end_user_license_iframe');
        checkCurrentLanguage();
      },

      onBeforeShow: function() {
        _initSoftKey();
        window.addEventListener('panelready', _initIframe);
        _iframe.contentDocument.addEventListener('keydown', keyDownHandler);
        _iframe.contentDocument.dir = window.document.dir;
        checkCurrentLanguage();
      },

      onBeforeHide: function () {
        SettingsSoftkey.hide();
        window.removeEventListener('panelready', _initIframe);
        _iframe.contentDocument.removeEventListener('keydown', keyDownHandler);
        _iframe.contentDocument.removeEventListener('keydown', keyDownHandlerIsVoiceOnly);
      }
    });
  };
});
