/**
 * [GF5GTMO-4249] download eSIM by inputting Activation code
 * created by yuwei.fang, 2024-09-30
 */

'use strict';
define(function (require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createInputActivationCodePanel() {
    let elements = null;
    const PROFILE_BEGAINING = 'LPA:';
    const softKeyParams = {
      items: [
        {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          method() {
            NavigationMap.navigateBack();
          }
        },
        {
          name: 'Done',
          l10nId: 'done',
          priority: 3,
          method: downloadEsimByActivationCode
        }
      ]
    };

    function downloadEsimByActivationCode() {
      let stringEntered = elements.stringInput.value;
      stringEntered = stringEntered.replace(/^\s+|\s+$/g, '');
      // go to download eSIM
      addProfile(stringEntered.split(PROFILE_BEGAINING)[1]);
    }

    function addProfile(data) {
      Settings.isBackHref = true;
      Settings.setCurrentPanel('#add_esim_downloading', { activeCode: data });
    }

    function handleEvent(evt) {
      if (evt.key === 'Enter') {
        evt.stopPropagation();
        elements.stringInput.focus();
      }
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          stringInput: panel.querySelector('input')
        };
      },

      onBeforeShow() {
        SettingsSoftkey.init(softKeyParams);
        SettingsSoftkey.show();
        elements.stringInput.addEventListener('keydown', handleEvent);
      },

      onShow() {
        elements.stringInput.focus();
      },

      onBeforeHide() {
        elements.stringInput.removeEventListener('keydown', handleEvent);
        SettingsSoftkey.hide();
      }
    });
  };
});
