'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createSimcardNamePanel() {
    let index = 0;
    let profileIndex = 0;
    let elements = null;
    let profile = {};
    let currentPanel = null;
    let listElements = null;
    let updating = false;
    const deselectParams = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [
        {
          name: 'Deselect',
          l10nId: 'deselect',
          priority: 2
        }
      ]
    };

    function toggleeSIMState() {
      if (elements.checkbox.checked) {
        disableScreen(true);
        ApiManager.eUiccManager.disableProfile(profile.iccid).then(
          () => {
            setTimeout(() => {
              elements.checkbox.checked = false;
              disableScreen(false);
              ToastHelper.showToast('esim-disabled', { index: index + 1 });
            }, 6000); // To make sure the state can be updated to modem
          },
          error => {
            disableScreen(false);
            ToastHelper.showToast('disable-error', { index: index + 1 });
            DebugHelper.debug(`disableProfile error:${error}`);
          }
        );
      } else {
        disableItem(elements.state, true);
        ApiManager.eUiccManager.enableProfile(profile.iccid).then(
          () => {
            disableItem(elements.state, false);
            elements.checkbox.checked = true;
            updateItems();
            updateSoftKey();
          },
          error => {
            disableItem(elements.state, false);
            ToastHelper.showToast('enable-error', { index: index + 1 });
            DebugHelper.debug(`enableProfile error:${error}`);
          }
        );
      }
    }

    function disableItem(item, disable) {
      item.disabled = disable;
      item.classList.toggle('none-select', disable);
      if (disable) {
        item.setAttribute('aria-disabled', disable);
      } else {
        item.removeAttribute('aria-disabled');
      }
    }

    function disableScreen(disable) {
      disableItem(elements.state, disable);
      disableItem(elements.esimcard, disable);
      disableItem(elements.remove, disable);
      updating = disable;
      if (disable) {
        SettingsSoftkey.hide();
      } else {
        updateItems();
        updateSoftKey();
      }
    }

    function handleKeydown(evt) {
      if (evt.key === 'Backspace' && updating) {
        evt.preventDefault();
        evt.stopPropagation();
      }
    }

    function handleClick(evt) {
      evt.stopPropagation();
      evt.preventDefault();
      if (evt.target.disabled) {
        return;
      }
      switch (evt.target.id) {
        case 'state':
          toggleeSIMState();
          break;
        case 'esimcard':
          Settings.setCurrentPanel('#change_esimcard_name', {
            index,
            iccid: profile.iccid,
            name: elements.name.textContent,
            spName: profile.spName
          });
          break;
        case 'remove-esim':
          removeeSIM();
          break;
        default:
          break;
      }
    }

    function deleteProfile() {
      ApiManager.eUiccManager.deleteProfile(profile.iccid).then(
        () => {
          disableScreen(false);
          ToastHelper.showToast('esim-removed');
          NavigationMap.navigateBack();
          updateCustomSimcardsName(profile.iccid);
        },
        error => {
          disableScreen(false);
          ToastHelper.showToast('remove-error');
          DebugHelper.debug(`deleteProfile error:${error}`);
        }
      );
    }

    function updateCustomSimcardsName(iccId) {
      SettingsDBCache.getSetting('custom.simcards.name').then(value => {
        const values = value || {};
        if (values[iccId]) {
          delete values[iccId];
          SettingsDBCache.saveSettings({
            'custom.simcards.name': values
          });
        }
      });
    }

    function removeeSIM() {
      const active = elements.checkbox.checked;

      const dialogConfig = {
        title: { id: 'remove-esim' },
        body: { id: 'remove-esim-dialog', args: { index: index + 1 } },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1
        },
        confirm: {
          name: 'remove',
          l10nId: 'remove',
          priority: 3,
          callback() {
            if (!window.IsOnline()) {
              ToastHelper.showToast('remove-error');
              return;
            }
            disableScreen(true);
            if (active) {
              ApiManager.eUiccManager.disableProfile(profile.iccid).then(
                () => {
                  setTimeout(() => {
                    deleteProfile();
                  }, 6000); // To make sure the state can be updated to modem
                },
                error => {
                  DebugHelper.debug(`disableProfile error:${error}`);
                  disableScreen(false);
                  ToastHelper.showToast('remove-error');
                }
              );
            } else {
              deleteProfile();
            }
          }
        }
      };
      DialogHelper.show(dialogConfig);
    }

    function updateItems() {
      if (!profile || !profile.profilePolicy) {
        return;
      }
      switch (profile.profilePolicy) {
        case 'delete-not-allowed':
          disableItem(elements.remove, true);
          break;
        case 'disable-not-allowed':
          if (elements.checkbox.checked) {
            disableItem(elements.state, true);
          }
          break;
        case 'delete-on-disable-not-allowed':
          if (!elements.checkbox.checked) {
            disableItem(elements.remove, true);
          }
          break;
        default:
          break;
      }
    }

    function updateSoftKey() {
      const focusedElement = currentPanel.querySelector('.focus');
      if (!focusedElement || focusedElement.classList.contains('none-select')) {
        SettingsSoftkey.hide();
        return;
      }
      const inputElement = focusedElement.querySelector('input');
      if (inputElement && inputElement.checked) {
        SettingsSoftkey.init(deselectParams);
      } else {
        SettingsSoftkey.init(SoftParams.defaultSelect);
      }
      SettingsSoftkey.show();
    }

    function showConfirmationScreen(event){
      var text;
      switch (event.policyMask) {
        //PROFILE_TYPE_DISABLE_NOT_ALLOWED
        case 1:
          text = l10n.get('ppr1-message');
          break;
        //PROFILE_TYPE_DELETE_NOT_ALLOWED
        case 2:
          text = l10n.get('ppr2-message');
          break;
        //PROFILE_TYPE_DELETE_ON_DISABLE
        case 4:
          text = l10n.get('ppr3-message');
          break;
        default:
          break;
      }
      if(!text){
        return;
      }
      const dialogConfig = {
        body: { text },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback() {
            ApiManager.eUiccManager.setUserConsent(false);
          }
        },
        confirm: {
          name: 'Ok',
          l10nId: 'ok',
          priority: 3,
          callback(){
            ApiManager.eUiccManager.setUserConsent(true);
          }
        }
      };
      DialogHelper.show(dialogConfig);
    }

    return SettingsPanel({
      onInit(panel, options) {
        index = options.index || index;
        profileIndex = options.profileIndex || profileIndex;
        elements = {
          header: panel.querySelector('#esimcard-id'),
          state: panel.querySelector('#state'),
          remove: panel.querySelector('#remove-esim'),
          checkbox: panel.querySelector('#state input[type="checkbox"]'),
          name: panel.querySelector('#current-esimcard-name'),
          esimcard: panel.querySelector('#esimcard')
        };
        currentPanel = panel;
        listElements = panel.querySelectorAll('li');
        ApiManager.eUiccManager.queryProfiles().then(profiles => {
          profile = profiles[profileIndex];
          elements.checkbox.checked = profile.state === 'active';
          l10n.setAttributes(elements.header, 'esim-with-index', {
            index: index + 1
          });
          l10n.setAttributes(elements.name, 'current-sim-name', {
            name: profile.nickName || profile.spName
          });
          updateItems();
          updateSoftKey();
        });
          //Task GF5GTMO-1960 GF5GTMO-1961 guanzhong.zhu.cd@tcl.com UI on PPR2 rule and PPR1 rule check-begin
          ApiManager.eUiccManager.onindicationreceived = event => {
          DebugHelper.log(`esimcard_manager onindicationreceived status:${event.status}`);
          if(event.userConsentRequired){
            showConfirmationScreen(event);
          }
          //Task GF5GTMO-1960 GF5GTMO-1961 guanzhong.zhu.cd@tcl.com UI on PPR2 rule and PPR1 rule check-end
        };
      },

      onBeforeShow(panel, options) {
        currentPanel.addEventListener('click', handleClick);
        currentPanel.addEventListener('keydown', handleKeydown);
        if (options.name) {
          l10n.setAttributes(elements.name, 'current-sim-name', {
            name: options.name
          });
        }
        ListFocusHelper.addEventListener(listElements, updateSoftKey);
      },
      onBeforeHide() {
        SettingsSoftkey.hide();
        currentPanel.removeEventListener('click', handleClick);
        currentPanel.removeEventListener('keydown', handleKeydown);
        ListFocusHelper.removeEventListener(listElements, updateSoftKey);
      }
    });
  };
});
