'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  const jsQR = require('utils/jsQR');

  return function createQRCodePanel() {
    let ctx = null;
    let interval = null;
    let elements = null;
    const PROFILE_BEGAINING = 'LPA:';
    const softkeyParams = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'options'
      },
      items: [
        {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          method() {
            NavigationMap.navigateBack();
          }
        },
        // [GF5GTMO-4249] begin added by yuwei.fang, 2024-09-30
        {
          name: 'Input',
          l10nId: 'input',
          priority: 3,
          method() {
            Settings.setCurrentPanel('#esimcard_activation_code');
          }
        }
        // [GF5GTMO-4249] end added by yuwei.fang, 2024-09-30
      ]
    };
    function scan() {
      if (DialogHelper.dialog && DialogHelper.dialog.childElementCount) {
        return;
      }
      interval = setInterval(() => {
        if (ctx) {
          ctx.drawImage(
            elements.video,
            0,
            0,
            elements.canvas.width,
            elements.canvas.height
          );
          const imageData = ctx.getImageData(
            0,
            0,
            elements.canvas.width,
            elements.canvas.height
          );
          const code = jsQR(imageData.data, imageData.width, imageData.height);
          if (code && code.data) {
            stopScan();
            const profile = code.data;
            if (profile.startsWith(PROFILE_BEGAINING)) {
              showConfirmDialog(profile);
            } else {
              showErrorDialog();
            }
          }
        }
      }, 1000 / 30);
    }

    function stopScan() {
      if (interval) {
        window.clearInterval(interval);
      }
    }

    function delayScan() {
      setTimeout(() => {
        if (elements.video.srcObject) {
          scan();
        }
      }, 500); // To make sure the dialog is closed
    }

    function showConfirmDialog(data) {
      const dialogConfig = {
        title: { id: 'confirmation' },
        body: {
          id: 'add-esim-from',
          args: {
            data
          }
        },
        cancel: {
          l10nId: 'cancel',
          priority: 1,
          callback: () => {
            delayScan();
          }
        },
        confirm: {
          l10nId: 'add',
          priority: 2,
          callback: () => {
            addProfile(data.split(PROFILE_BEGAINING)[1]);
          }
        },
        backcallback: () => {
          delayScan();
        }
      };
      DialogHelper.show(dialogConfig);
    }

    function showErrorDialog() {
      const dialogConfig = {
        title: { id: 'confirmation' },
        body: {
          id: 'qr-error'
        },
        accept: {
          name: 'ok',
          l10nId: 'ok',
          priority: 2,
          callback: () => {
            delayScan();
          }
        },
        backcallback: () => {
          delayScan();
        }
      };
      DialogHelper.show(dialogConfig);
    }

    function addProfile(data) {
      Settings.isBackHref = true;
      Settings.setCurrentPanel('#add_esim_downloading', { activeCode: data });
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          video: panel.querySelector('#video'),
          canvas: panel.querySelector('#canvas')
        };
      },

      onBeforeShow() {
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
        ctx = elements.canvas.getContext('2d');
        navigator.mediaDevices
          .getUserMedia({ video: { facingMode: 'environment' } })
          .then(stream => {
            elements.video.srcObject = stream;
            elements.video.play();
          });

        elements.video.addEventListener('play', scan);
      },

      onBeforeHide() {
        SettingsSoftkey.hide();
        stopScan();
        elements.video.removeEventListener('play', scan);
        elements.video.pause();
        if (elements.video.srcObject) {
          elements.video.srcObject.getTracks().forEach(track => track.stop());
          elements.video.srcObject = null;
        }
      }
    });
  };
});
