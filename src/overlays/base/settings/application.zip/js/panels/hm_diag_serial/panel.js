/* [OpCommon]Task10204324-yumei.chen@tcl.com-MMIcode-##3424# open or close Diag and Serial */
/* [GF7VZW-6938] modify shangpeng.su 2023.10.11 */
/* [GF7TF-3625] modify shangpeng.su 2023.10.18  */
/* [GF7VZW-7847] modify shangpeng.su 2024.04.15 */
'use strict';
define(function (require) {

  var SettingsPanel = require('modules/settings_panel');
  var usb_function_current;
  var diag_boolean;
  var serial_boolean;
  var rmnet_config = "diag,serial_cdev,rmnet,adb";
  var def_usb_config = "diag,serial_cdev,rmnet,dpl,adb";


  return function diag_serial_panel() {
    var elements = {};
    var RMNET_SHOW = false;

    // Init the UI status according to the usb config
    function _initDiagSerialStatus() {
        window.remoteHelper.getproperty('sys.usb.config',　(response) => {
              usb_function_current = JSON.parse(response).value;
              dump('diag-serial init get usb success=' + usb_function_current);
              diag_boolean = (usb_function_current.indexOf("diag") > -1);
              serial_boolean = (usb_function_current.indexOf("serial_cdev") > -1);
              if ('true' === RMNET_SHOW) {
                elements.rmnetItem.classList.remove('hidden');
              }
              if (diag_boolean) {
                elements.enableDiagCheckBox.checked = true;
              }
              if (serial_boolean) {
                elements.enableSerialCheckBox.checked = true;
              }
              // Defect7613550-yumei.chen@tcl.com-Add Enable Rmnet checkbox-begin
              if (rmnet_config === usb_function_current) {
                elements.enableRmnetCheckBox.checked = true;
                elements.enableDiagCheckBox.disabled = true;
                elements.enableSerialCheckBox.disabled = true;
              } else {
                elements.enableDiagCheckBox.disabled = false;
                elements.enableSerialCheckBox.disabled = false;
              }
              // Defect7613550-yumei.chen@tcl.com-Add Enable Rmnet checkbox-end
              NavigationMap.refresh();
              setUsbPortProp(usb_function_current);
          },(e)=> {
             dump('diag-serial _initDiagSerialStatus get usb error ' + e);
          });
    }
    // Defect7613550-yumei.chen@tcl.com-Add Enable Rmnet checkbox-begin
    function _exchangeRmnet() {
      var usb_will = def_usb_config;
      if (elements.enableRmnetCheckBox.checked) {
        elements.enableDiagCheckBox.disabled = true;
        elements.enableDiagCheckBox.checked = true;
        elements.enableSerialCheckBox.disabled = true;
        elements.enableSerialCheckBox.checked = true;
        usb_will = rmnet_config;
      } else {
        elements.enableDiagCheckBox.disabled = false;
        elements.enableSerialCheckBox.disabled = false;
      }
       navigator.b2g.engmodeManager.setPropertyLE("usb_config", usb_will)
         .then(result => {
           let success = ('process-finished' === result);
           dump('diag-serial setpropery sys.usb.config, response='
               + (success ? 'success' : 'fail'));
         });
       //setUsbProperty(usb_will);
       setUsbPortProp(usb_will);
    }
    // Defect7613550-yumei.chen@tcl.com-Add Enable Rmnet checkbox-end

    // Enable the diag port event's logic
    function _exchangeDiagPort() {
        window.remoteHelper.getproperty('sys.usb.config',　(response) => {
            usb_function_current = JSON.parse(response).value;
           var enableDiag = false;
           dump('diag-serial exchange Diag usb current=' + usb_function_current);
           if (elements.enableDiagCheckBox.checked) {
             if (usb_function_current.indexOf("adb") > -1
                 && usb_function_current.indexOf("serial_cdev") > -1) {
               usb_function_current = "diag,serial_cdev,rmnet,adb";
             } else if (usb_function_current.indexOf("adb") === -1
                 && usb_function_current.indexOf("serial_cdev") > -1) {
               usb_function_current = "diag,serial_cdev,rmnet";
             } else if (usb_function_current.indexOf("adb") > -1
                 && usb_function_current.indexOf("serial_cdev") === -1) {
                usb_function_current = "diag,adb";
             } else if (usb_function_current.indexOf("adb") === -1
                 && usb_function_current.indexOf("serial_cdev") === -1) {
                usb_function_current = "diag";
             }
             enableDiag = true;
           } else {
             if (usb_function_current.indexOf("adb") > -1
                 && usb_function_current.indexOf("serial_cdev") > -1) {
               usb_function_current = "rndis,serial_cdev,adb";
             } else if (usb_function_current.indexOf("adb") === -1
                 && usb_function_current.indexOf("serial_cdev") > -1) {
               usb_function_current = "rndis,serial_cdev";
             } else if (usb_function_current.indexOf("adb") > -1
                 && usb_function_current.indexOf("serial_cdev") === -1) {
                if (usb_function_current.indexOf('mtp') > -1) {
                  usb_function_current = "mtp,adb";
                } else {
                  usb_function_current = "mass_storage,adb";
                }
             } else if (usb_function_current.indexOf("adb") === -1
                 && usb_function_current.indexOf("serial_cdev") === -1) {
                if (usb_function_current.indexOf('mass_storage') > -1) {
                  usb_function_current = "mass_storage";
                } else {
                  usb_function_current = "mtp";
                }
             }
           }
           dump('diag-serial usb will be set ' + usb_function_current);
           navigator.b2g.engmodeManager.setPropertyLE("usb_config", usb_function_current)
             .then(result => {
               let success = ('process-finished' === result);
               dump('diag-serial setpropery sys.usb.config, response='
                   + (success ? 'success' : 'fail'));
               if (success) {
                 ToastHelper.showToastForHideMenu(
                    enableDiag ? 'Diag is opened' : 'Diag is closed');
               }
             });
          //setUsbProperty(usb_function_current);
          setUsbPortProp(usb_function_current);
        }, (e)=> {
           dump('diag-serial get usb error ' + e);
        });
    }

    // Enable the serial port event's logic
    function _exchangeSerialPort() {
        window.remoteHelper.getproperty('sys.usb.config',　(response) => {
           usb_function_current = JSON.parse(response).value;
           var enableSerial = false;
           dump('diag-serial  exchange serial current usb=' + usb_function_current);
           if (elements.enableSerialCheckBox.checked) {
               if (usb_function_current.indexOf("adb") > -1
                   && usb_function_current.indexOf("diag") > -1) {
                 usb_function_current = "diag,serial_cdev,rmnet,adb";
               } else if (usb_function_current.indexOf("adb") === -1
                   && usb_function_current.indexOf("diag") > -1) {
                 usb_function_current = "diag,serial_cdev,rmnet";
               } else if (usb_function_current.indexOf("adb") > -1
                   && usb_function_current.indexOf("diag") === -1) {
                 usb_function_current = "rndis,serial_cdev,adb";
               } else if (usb_function_current.indexOf("adb") === -1
                   && usb_function_current.indexOf("diag") === -1) {
                 usb_function_current = "rndis,serial_cdev";
               }
               enableSerial = true;
           } else {
               if (usb_function_current.indexOf("adb") > -1
                   && usb_function_current.indexOf("diag") > -1) {
                 usb_function_current = "diag,adb";
               } else if (usb_function_current.indexOf("adb") === -1
                   && usb_function_current.indexOf("diag") > -1) {
                 usb_function_current = "diag";
               } else if (usb_function_current.indexOf("adb") > -1
                   && usb_function_current.indexOf("diag") === -1) {
                 if (usb_function_current.indexOf('mass_storage') > -1) {
                   usb_function_current = "mass_storage,adb";
                 } else if (usb_function_current.indexOf('mtp') > -1) {
                   usb_function_current = "mtp,adb";
                 } else {
                   usb_function_current = "adb";
                 }
               } else if (usb_function_current.indexOf("adb") === -1
                   && usb_function_current.indexOf("diag") === -1) {
                 if (usb_function_current.indexOf('mass_storage') > -1) {
                   usb_function_current = "mass_storage";
                 } else {
                   usb_function_current = "mtp";
                 }
               }
           }
           dump('diag-serial usb will be set ' + usb_function_current);
           navigator.b2g.engmodeManager.setPropertyLE("usb_config", usb_function_current)
             .then(result => {
                let success = ('process-finished' === result);
                dump('diag-serial setpropery sys.usb.config, response='
                    + (success ? 'success' : 'fail'));
                if (success) {
                  ToastHelper.showToastForHideMenu(
                       enableSerial ? 'Serial is opened' : 'Serial is closed');
                }
             });
            //setUsbProperty(usb_function_current);
            setUsbPortProp(usb_function_current);
        }, (e)=> {
            dump('diag-serial get usb error ' + e);
        });
    }

    //Make sure it works after the restart
    function setUsbProperty(usb_will) {
      navigator.b2g.engmodeManager.setPropertyLE("persist_usb_config", usb_will)
        .then(result => {
          let success = ('process-finished' === result);
          dump('diag-serial setpropery persist.sys.usb.config, response='
              + (success ? 'success' : 'fail'));
        });
    }

    function setUsbPortProp(usb_will) {
      let portOpen = 'false';
      if (
        elements.enableDiagCheckBox.checked ||
        elements.enableSerialCheckBox.checked ||
        elements.enableRmnetCheckBox.checked
      ) {
        portOpen = 'true';
      }

      navigator.b2g.engmodeManager.setPropertyLE("usb_port_open", portOpen)
        .then(result => {
          let success = ('process-finished' === result);
          dump('diag-serial setpropery persist.sys.usb.port.open, response='
              + (success ? 'success' : 'fail'));
        });
      setUsbPortConfig(portOpen == 'true' ? usb_will : "");
    }

    function setUsbPortConfig(port_config) {
      navigator.b2g.engmodeManager.setPropertyLE("usb_port_config", port_config)
        .then(result => {
          let success = ('process-finished' === result);
          dump('diag-serial setpropery persist.sys.usb.port.config, response='
              + (success ? 'success' : 'fail'));
        });
    }

    return SettingsPanel({
      onInit: function (panel) {
        dump("Settings-Diag:SettingsPanel--onInit");
        elements = {
          enableRmnetCheckBox: panel.querySelector('#checkbox_rmnet'),
          enableDiagCheckBox: panel.querySelector('#checkbox_diag'),
          enableSerialCheckBox: panel.querySelector('#checkbox_serial'),
          rmnetItem: panel.querySelector('#enable_rmnet')
        };
        if (!navigator.b2g.engmodeManager) {
           dump('diag-serial engmodeManager is undefined');
           return;
        }
        navigator.b2g.engmodeManager.getPropertyValue('ro.customized.rmnet')
          .then((result) => {
             RMNET_SHOW = result;
             dump('diag-serial get rmnet customiztion success=' + RMNET_SHOW);
           }, (e) => {
               dump('diag-serial get rmnet customiztion error ' + e);
           });
        if (!window.remoteHelper) {
           dump('diag-serial window.remoteHelper is undefined');
           return;
        }
        elements.enableDiagCheckBox.addEventListener('change', _exchangeDiagPort);
        elements.enableSerialCheckBox.addEventListener('change', _exchangeSerialPort);
        elements.enableRmnetCheckBox.addEventListener('change', _exchangeRmnet);
        _initDiagSerialStatus();
      }
    });
  };
});
