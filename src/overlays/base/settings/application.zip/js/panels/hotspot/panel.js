/* global SIMSlotManager, WebActivity, ConfirmDialogHelper  */
/** Task-10217008 modify shangpen.su@tcl.com 2020.11.18 **/
/** Defect-10620107 modify shangpeng.su@tcl.com 2021.01.07 **/
/** Defect-10614673 modify shangpeng.su@tcl.com 2021.01.15 **/
/** Task-10683224 modify shangpeng.su 2021.01.26 **/
/** Defect-10683186 modify shangpeng.su 2021.01.31 **/
/** Defect-10769509 modify shangpeng.su 2021.03.09 **/
/** Defect-11097915/11061801 modify shangpeng.su 2021.05.12 **/
'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  const wifiManager = WifiHelper.getWifiManager();

  return function createPanel() {
    const HOTSPOT_WIFI_ENABLED = 'tethering.wifi.enabled';
    const DM_WIFI_UI = 'dm.tethering.wifi.settings.ui';
    const HOTSPOT_USB_ENABLED = 'tethering.usb.enabled';
    const DM_USB_UI = 'dm.tethering.usb.settings.ui';
    const WIFI_SSID_KEY = 'tethering.wifi.ssid';
    const WIFI_BAND_KEY = 'tethering.wifi.band.type';
    const WIFI_SECURITY_KEY = 'tethering.wifi.security.type';
    const WIFI_PASSWORD_KEY = 'tethering.wifi.security.password';
    //Task-10232569 add-begin shangpeng.su@tcl.com 2020.11.25
    const WIFI_BROADCAST_SSID_KEY = 'tethering.wifi.broadcast.ssid';
    //Task-10232569 add-end shangpeng.su@tcl.com 2020.11.25
    //Task-10296940 add-begin shangpeng.su@tcl.com 2020.11.27
    const WIFI_MAX_NUM_STA = 'tethering.wifi.maxnumsta';
    //Task-10296940 add-end shangpeng.su@tcl.com 2020.11.27
    //Defect-10582137 add-begin shangpeng.su@tcl.com 2020.12.25
    const TETHERING_MHS_CHECK_INGORE = 'tethering.mhs.check.ignore';
    //Defect-10582137 add-end shangpeng.su@tcl.com 2020.12.25
    //Defect-10648763 add-begin shangpeng.su 2021.01.14
    const WIFI_SHOW_PASSWORD_KEY = 'tethering.wifi.show.password';
    //Defect-10648763 add-end shangpeng.su 2021.01.14
    const DATA_KEY = 'ril.data.enabled';
    const WIFI_KEY = 'wifi.enabled';
    const USB_STORAGE_KEY = 'ums.enabled';
    //Task-10232568 add-begin shangpeng.su@tcl.com 2020.11.20
    const WIFI_SAVED_KEY = 'wifi.saved.enabled';
    //Task-10232568 add-end shangpeng.su@tcl.com 2020.11.20
    //add begin by tailiangchen for defect-10950562
    const TETHERING_WIFI_USB_CHANGE = 'tethering.wifi.usb.change';
    //add end by tailiangchen for defect-10950562
    const WIFI_AP_BAND = 'tethering.wifi.band';

    let currentConfig = {};
    let elements = null;
    //Task-10217007/10217863 add-begin shangpeng.su@tcl.com 2020.11.17
    let operator = null;
    let showDialog = false;
    let isVzwRoaming = false;
    let needShowHotspotTurnOnDialog = false;
    //Task-10217007/10217863 add-end shangpeng.su@tcl.com 2020.11.17

    //Task-10297039-BEGIN ganghong.liu 2020-12-15
    var APNSETTING = 'ril.data.default.apnSettings'; //gf3:ril.data.apnSettings
    var sprOperator = '';
    var apnAvailable = false;
    //Task-10297039-END

    //[GF7TF-3565] add-begin shangpeng.su 2023.10.08
    let needVzwProvisioningcheck = false;
    //[GF7TF-3565] add-end shangpeng.su 2023.10.08
    //add by tailiangchen for jira GF5GTMO-8460
    let CU = '';

    const hotspotSettings = {};
    const hotspotUI = {
      isWifiShow: true,
      isUsbShow: true
    };
    let timeoutId = null;
    let listElements = null;

    //add begin by tailiangchen for defect-11084703
    const showpass = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [
        {
          name: 'Show',
          l10nId: 'show-vzw',
          priority: 3,
          method() {
            const cSet = {};
            cSet[WIFI_SHOW_PASSWORD_KEY] = true;
            elements.wifiPasswordDes.textContent = hotspotSettings.password;
            SettingsSoftkey.init(hidepass);
            SettingsSoftkey.show();
            window.dispatchEvent(new CustomEvent('refresh'));
            SettingsDBCache.saveSettings(cSet);
          }
        }
      ]
    };
    const hidepass = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [
        {
          name: 'Hide',
          l10nId: 'hide-vzw',
          priority: 3,
          method() {
            const cSet = {};
            cSet[WIFI_SHOW_PASSWORD_KEY] = false;
            elements.wifiPasswordDes.textContent = '********';
            window.dispatchEvent(new CustomEvent('refresh'));
            SettingsSoftkey.init(showpass);
            SettingsSoftkey.show();
            SettingsDBCache.saveSettings(cSet);
          }
        }
      ]
    };
    //add begin by tailiangchen for defect-11084703

    const checkPage = function checkPage() {
      if (!(hotspotUI.isWifiShow || hotspotUI.isUsbShow)) {
        Settings.setCurrentPanel('root');
      }
    };

    const handleSettingsChange = function handleSettingsChange(value, name) {
      switch (name) {
        case DM_WIFI_UI:
          if (value === Constants.MDM.HIDE) {
            hotspotUI.isWifiShow = false;
            elements.wifiTetheringSection.classList.add('hidden');
            checkPage();
          } else {
            hotspotUI.isWifiShow = true;
            elements.wifiTetheringSection.classList.remove('hidden');
          }
          break;
        case DM_USB_UI:
          if (value === Constants.MDM.HIDE) {
            hotspotUI.isUsbShow = false;
            elements.usbTetheringSection.classList.add('hidden');
            checkPage();
          } else {
            hotspotUI.isUsbShow = true;
            elements.usbTetheringSection.classList.remove('hidden');
          }
          break;
        case HOTSPOT_WIFI_ENABLED:
          currentConfig.wifiHotspotEnabled = value;
          elements.wifiHotspotSelect.value = value;
          if (value) {
            elements.hotspotSettingsItem.setAttribute('aria-disabled', true);
          } else {
            elements.hotspotSettingsItem.removeAttribute('aria-disabled');
          }
          handleWifiHotspot(value);//Defect-10585632 add shangpeng.su 2020.12.28
          break;
        case HOTSPOT_USB_ENABLED:
          currentConfig.usbTetheringEnabled = value;
          elements.usbTetheringSelect.value = value;
          break;
        case WIFI_SSID_KEY:
          hotspotSettings.ssid = value;
          elements.wifiSsidDes.textContent = value;
          break;
        case WIFI_AP_BAND:
          hotspotSettings.band = value;
          elements.wifiBandDes.textContent =
            l10n.get(value === '2.4G' ? '24g-band' : '5g-band');
          break;
        case WIFI_SECURITY_KEY:
          hotspotSettings.security = value;
          elements.wifiSecurityTypeDes.textContent = l10n.get(
            `hotspot-${value}`
          );
          if (value === 'open') {
            elements.wifiPasswordItem.classList.add('hidden');
            elements.wifiPasswordItem.setAttribute('aria-disabled', true);
          } else {
            elements.wifiPasswordItem.classList.remove('hidden');
            elements.wifiPasswordItem.setAttribute('aria-disabled', false);
          }

          if (operator === 'TMO' && value === 'wpa2-psk' &&
              DeviceFeature.getValue('firstSetHotspotPwd') === 'true') {
            console.log('susp_test, firstSetHotspotpwd with wifi-hotspot-select');
            DeviceFeature.setLocalStorageItem('firstSetHotspotPwd', 'false');
            onWifiHotspotSelect(true);
          }
          NavigationMap.refresh();//Defect-10791303 add shangpeng.su 2021.02.06
          break;
        case WIFI_PASSWORD_KEY:
          if (!value) {
            //Defect-10614637 modify-begin shangpeng.su 2021.01.06
            if (operator === 'VZW' || operator === 'TF') { //add by tailiangchen for jira GF7TF-4110
              value = generateHotspotPasswordByCustomLength(12);  //password length is 12
            //Defect-10665840 add-begin shangpeng.su 2021.01.20
            } else if (operator === 'TMO') {
              break;
              //Defect-10665840 add-end shangpeng.su 2021.01.20
            //add begin by tailiangchen for jira GF7EE-1080
            } else if (operator === 'EE') {
              value = generateHotspotPasswordByCustomLength(10);  //EE password length is 10
            //add end by tailiangchen for jira GF7EE-1080
            } else {
              value = generateHotspotPassword();
            }
            //Defect-10614637 modify-end shangpeng.su 2021.01.06
            const cSet = {};
            cSet[WIFI_PASSWORD_KEY] = value;
            SettingsDBCache.saveSettings(cSet);
          }
          hotspotSettings.password = value;
          updateWifiPasswordDes();//Defect-10976389 modify shangpeng.su 2021.04.01
          break;
        case DATA_KEY:
          currentConfig.isDataEnabled = value;
          break;
        case WIFI_KEY:
          currentConfig.isWifiEnabled = value;
          break;
        case WIFI_SAVED_KEY:
          currentConfig.isWifiSavedEnabled = value;
          break;
        case USB_STORAGE_KEY:
          currentConfig.isUsbStorageEnabled = value;
          break;
        case WIFI_BROADCAST_SSID_KEY:
          hotspotSettings.broadcastSsid = value;
          break;
        //Defect-10582137 add-begin shangpeng.su@tcl.com 2020.12.25
        case TETHERING_MHS_CHECK_INGORE:
          currentConfig.ignoreMhsCheck = value;
          //add begin by tailiangchen for jira GF5GTMO-5751
          if ('TMO' === operator) {
            currentConfig.ignoreMhsCheck = true;
          }
          //add end by tailiangchen for jira GF5GTMO-5751
          break;
        //Defect-10582137 add-end shangpeng.su@tcl.com 2020.12.25
        //Defect-10648763 add-begin shangpeng.su 2021.01.14
        case WIFI_SHOW_PASSWORD_KEY:
          hotspotSettings.showPassword = value;
          updateWifiPasswordDes();//Defect-10976389 modify shangpeng.su 2021.04.01
          break;
        //Defect-10648763 add-end shangpeng.su 2021.01.14
        default:
          break;
      }
    };

    //Defect-11098002 modify-begin shangpeng.su 2021.05.12
    //Defect-10976389 modify-begin shangpeng.su 2021.04.01
    //Defect-10879689 modify-begin shangpeng.su 2021.03.17
    //Defect-10665840 add-begin shangpeng.su 2021.01.20
    function updateWifiPasswordDes() {
      elements.wifiPasswordDes.textContent = hotspotSettings.password;
      if (
        (operator === 'TMO' || operator === 'VZW' || operator === 'USCC' || operator === 'TF') &&  //add by tailiangchen for jira GF7TF-3555
        hotspotSettings.password
      ) {
        elements.wifiPasswordDes.textContent =
          hotspotSettings.showPassword ? hotspotSettings.password : '********';
      }
    };
    //Defect-10665840 add-end shangpeng.su 2021.01.20
    //Defect-10879689 modify-end shangpeng.su 2021.03.17
    //Defect-10976389 modify-end shangpeng.su 2021.04.01
    //Defect-11098002 modify-end shangpeng.su 2021.05.12

    //Defect-10585632 modify-begin shangpeng.su 2020.12.28
    function handleWifiHotspot(value) {
      if (operator === 'VZW' && value && needShowHotspotTurnOnDialog) {
        showWifiHotspotTurnedOnDialog();
        needShowHotspotTurnOnDialog = false;
      }

      //Task-10296943 add-begin shangpeng.su@tcl.com 2020.12.03
      if (value) {
        elements.hotspotConnDevicesItem.addEventListener(
          'click', handleHotspotConnDevicesClick);
        elements.hotspotBlockDevicesItem.addEventListener(
          'click', handleHotspotBlockDevicesClick);
        elements.hotspotConnDevicesItem.removeAttribute('aria-disabled');
        elements.hotspotBlockDevicesItem.removeAttribute('aria-disabled');
        //Defect10615603-bin.shen@tcl.com-begin
        elements.hotspotConnDevicesItem.classList.remove('none-select');
        elements.hotspotBlockDevicesItem.classList.remove('none-select');
        //Defect10615603-bin.shen@tcl.com-end
        //Defect-10696833 add-begin shangpeng.su 2021.02.02
        elements.hotspotSettingsItem.classList.add('none-select');
        //Defect-10696833 add-end shangpeng.su 2021.02.02
      } else {
        elements.hotspotConnDevicesItem.removeEventListener(
          'click', handleHotspotConnDevicesClick);
        elements.hotspotBlockDevicesItem.removeEventListener(
          'click', handleHotspotBlockDevicesClick);
        elements.hotspotConnDevicesItem.setAttribute('aria-disabled', true);
        elements.hotspotBlockDevicesItem.setAttribute(
          'aria-disabled', true);
        //Defect10615603-bin.shen@tcl.com-begin
        elements.hotspotConnDevicesItem.classList.add('none-select');
        elements.hotspotBlockDevicesItem.classList.add('none-select');
        //Defect10615603-bin.shen@tcl.com-end
        //Defect-10696833 add-begin shangpeng.su 2021.02.02
        elements.hotspotSettingsItem.classList.remove('none-select');
        //Defect-10696833 add-end shangpeng.su 2021.02.02
      }
      //Task-10296943 add-end shangpeng.su@tcl.com 2020.12.03
    };
    //Defect-10585632 modify-end shangpeng.su 2020.12.28

    //Task-10296943 add-begin shangpeng.su@tcl.com 2020.12.03
    function handleHotspotConnDevicesClick() {
      Settings.setCurrentPanel('hotspot_connected_devices', null);
    };

    function handleHotspotBlockDevicesClick() {
      Settings.setCurrentPanel('hotspot_blocked_devices', null);
    };
    //Task-10296943 add-end shangpeng.su@tcl.com 2020.12.03
    const updateUsbTetheringStatus = function updateUsbTetheringStatus(
      statusValue
    ) {
      if (statusValue) {
        elements.usbTetheringItem.removeAttribute('aria-disabled');
        elements.usbTetheringItem.classList.remove('none-select');
        elements.usbTetheringSelect.disabled = false;
        elements.usbTetheringItem.classList.remove('none-select');//Defect-10747737 ganghong.liu 2021-02-22
      } else {
        elements.usbTetheringSelect.disabled = true;
        elements.usbTetheringItem.setAttribute('aria-disabled', true);
        elements.usbTetheringItem.classList.add('none-select');
      }
      ListFocusHelper.updateSoftkey(elements.panel);//Defect-10747737 ganghong.liu 2021-02-22, ref:10562667

      //elements.usbTetheringItem.classList.add('none-select');

      ListFocusHelper.updateSoftkey();
    };

    function showConfirmDialog(element, message, desc) {
      const dialogConfig = {
        title: { id: 'internetSharing', args: {} },
        body: { id: message, args: {} },
        desc: { id: desc, args: {} },
        accept: {
          name: 'OK',
          l10nId: 'ok',
          priority: 2,
          callback() {
            elements.value = false;
          }
        }
      };
      DialogHelper.show(dialogConfig);
    }

    function showSIMCardDialog(element) {
      //add begin by tailiangchen for defect-10878572
      if(operator === 'VZW'){
        showConfirmDialog(
          element,
          'no-sim-card-message-1',
          Customization.getWifiCertifiedStrId(
            'no-sim-card-message-2-vzw',
            'no-sim-card-message-2-vzw'
          )
        );
      } else {
        showConfirmDialog(
          element,
          'no-sim-card-message-1',
            Customization.getWifiCertifiedStrId(
              'no-sim-card-message-2',
              'no-sim-card-message-2-wlan'
            )
        );
      }
      //add end by tailiangchen for defect-10878572
    }

    function showNetworkDialog() {
      //add begin by tailiangchen for defect-10878572
      if(operator === 'VZW'){
        showConfirmDialog(
          Customization.getWifiCertifiedStrId(
            'turn-on-network-message-vzw',
            'turn-on-network-message-vzw'
          ),
          ''
        );
      } else {
        showConfirmDialog(
          Customization.getWifiCertifiedStrId(
            'turn-on-network-message',
            'turn-on-network-message-wlan'
          ),
          ''
        );
      }
      //add end by tailiangchen for defect-10878572
    }

    function setWifiTetheringEnabled() {
      //Task-10296940 modify-begin shangpeng.su@tcl.com 2020.11.27
      //Task-10232569 modify-begin shangpeng.su@tcl.com 2020.11.25
      SettingsDBCache.getSettings([WIFI_SSID_KEY, WIFI_SECURITY_KEY,
          WIFI_PASSWORD_KEY, WIFI_BROADCAST_SSID_KEY, WIFI_MAX_NUM_STA,WIFI_AP_BAND],
        result => {
          ApiManager.tetheringManager.setTetheringEnabled(true, 'wifi', {
            ssid: result[WIFI_SSID_KEY],
            security: result[WIFI_SECURITY_KEY],
            key: result[WIFI_PASSWORD_KEY],
            hidden: !result[WIFI_BROADCAST_SSID_KEY],
            maxNumSta: result[WIFI_MAX_NUM_STA],
            band: result[WIFI_AP_BAND]
          });
          console.log('apconfig  band = ' + result[WIFI_AP_BAND] + ' broadcast?= ' + result[WIFI_BROADCAST_SSID_KEY]);
        }
      );
      //Task-10232569 modify-end shangpeng.su@tcl.com 2020.11.25
      //Task-10296940 modify-end shangpeng.su@tcl.com 2020.11.27
    }

    function resetWifiSavedStateWhenCancel() {
      if (currentConfig.isWifiSavedEnabled) {
        console.log('susp_test, reset wifi saved state and wifi');
        const cSet = {};
        cSet[WIFI_KEY] = true;
        cSet[WIFI_SAVED_KEY] = false;
        SettingsDBCache.saveSettings(cSet);
      }
    }

    function saveUsbTethering(value) {
      const cSet = {};
      cSet[HOTSPOT_USB_ENABLED] = value;
      updateUsbTetheringStatus(false);
      SettingsDBCache.saveSettings(cSet);
      updateUsbItemStatus();
    }

    function updateUsbItemStatus() {
      updateUsbTetheringStatus(false);
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
      timeoutId = setTimeout(() => {
        updateUsbTetheringStatus(currentConfig.isUSBInserted);
        timeoutId = null;
      }, 5000);
    }

    function showWifiDialogByWifiHotspot() {
      let bodyId = 'wifi-off-dialog-hotspot';
      let confirmId = 'open';
      let cancelId = 'cancel';

      switch (operator) {
        case 'TMO':
        case 'USCC'://Defect-11082549 add shangpeng.su 2021.04.30
          bodyId = 'wifi-off-dialog-hotspot-tmo';
          confirmId = 'turnOn';//Defect-11104085 modify shangpeng.su 2021.05.13
          break;
        case 'VZW':
          bodyId = 'wifi-off-dialog-hotspot-vzw';
          confirmId = 'ok';
          cancelId = 'cancel-vzw';
          //Task-10217006 add-begin shangpen.su@tcl.com 2020.11.19
          let isConnected = wifiManager.connection && (wifiManager.connection.status === 'connected');    //fix by tailiangchen for defect-11388834
          if (isConnected) {
            confirmId = 'yes';
            cancelId = 'cancel';
            bodyId = 'wifi-disconnect-dialog-hotspot-vzw';
          }
          //Task-10217006 add-end shangpen.su@tcl.com 2020.11.19
          break;
      }
      let body = { id: bodyId, args: {} };
      let cancelCallback = function () {
        elements.wifiHotspotSelect.value = false;
        DebugHelper.debug('Reset cancel');
      };
      let confirmCallback = function () {
        if (currentConfig.isWifiEnabled) {
          const cSet = {};
          cSet[WIFI_KEY] = false;
          cSet[WIFI_SAVED_KEY] = currentConfig.isWifiEnabled;
          SettingsDBCache.saveSettings(cSet);
        }
        if (currentConfig.isFTUHotspot) {
          showFtuDialogForHotspot(true);
        } else {
          if (isVzwRoaming) {
            showRoamDialog();
          } else {
            enableTethering('hotspot');
          }
        }
      };
      //add begin by tailiangchen for defect-10878572
      let options;
      if(operator === 'VZW'){
        options =
          {
            type: 'confirm',
            titleId: 'wifi-hotspot-vzw',
            body: body,
            cancelId: cancelId,
            confirmId: confirmId,
            backcallback: cancelCallback,
            cancelCallback: cancelCallback,
            confirmCallback: confirmCallback
          };
      } else {
        options =
          {
            type: 'confirm',
            titleId: 'wifi-hotspot',
            body: body,
            cancelId: cancelId,
            confirmId: confirmId,
            backcallback: cancelCallback,
            cancelCallback: cancelCallback,
            confirmCallback: confirmCallback
          };
      }
      //add end by tailiangchen for defect-10878572
      showConfirmDialogCustom(options);
    }

    function showWifiDialogByUSBTetheringTmo() {
      let body = { id: 'wifi-off-dialog-hotspot-tmo', args: {} };
      let cancelCallback = function () {
        elements.usbTetheringSelect.value = false;
        DebugHelper.debug('Reset cancel');
      };
      let confirmCallback = function () {
        const cSet = {};
        cSet[WIFI_KEY] = false;
        cSet[WIFI_SAVED_KEY] = true;
        SettingsDBCache.saveSettings(cSet);
        if (currentConfig.isUsbStorageEnabled) {
          showUsbStorageDialogByUSBTethering();
        } else if (currentConfig.isFTUTethering) {
          showFtuDialogForUsbTethering(cSet);
        } else {
          enableTethering('usb');
        }
      };
      let options =
        {
          type: 'confirm',
          titleId: 'usb-tethering',
          body: body,
          cancelId: 'cancel',
          confirmId: 'turnOn',//Defect-11104085 modify shangpeng.su 2021.05.13
          backcallback: cancelCallback,
          cancelCallback: cancelCallback,
          confirmCallback: confirmCallback
        };
      showConfirmDialogCustom(options);
    }
    //Task-10217007/10217863 modify-end shangpeng.su@tcl.com 2020.11.17

    function showWifiDialogByUSBTethering() {
      const cSet = {};
      const bodyId = Customization.getWifiCertifiedStrId(
        'is-warning-hotspot-tethering-message',
        'is-warning-hotspot-tethering-message-wlan'
      );
      const config = {
        title: { id: 'usb-tethering-header', args: {} },
        body: { id: bodyId, args: {} },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback() {
            elements.usbTetheringSelect.value = false;
            DebugHelper.debug('Reset cancel');
          }
        },
        confirm: {
          name: 'Turn On',
          l10nId: 'turnOn',
          priority: 3,
          callback() {
            cSet[WIFI_KEY] = false;
            //Defect-11082472 add-begin shangpeng.su 2021.05.12
            if (currentConfig.isWifiEnabled) {
              cSet[WIFI_SAVED_KEY] = true;
            }
            //Defect-11082472 add-end shangpeng.su 2021.05.12
            SettingsDBCache.saveSettings(cSet);
            if (currentConfig.isUsbStorageEnabled) {
              showUsbStorageDialogByUSBTethering();
            } else if (currentConfig.isFTUTethering) {
              //cSet[WIFI_KEY] = false;
              //SettingsDBCache.saveSettings(cSet);
              showFtuDialogForUsbTethering(cSet);
            } else {
              //saveUsbTethering(true);
              enableTethering('usb');
            }
          }
        }
      };
      DialogHelper.show(config);
    }

    function showHotspotDialogByUSBTethering() {
      const cSet = {};
      //add begin by tailiangchen for defect-10878572
      var bodyId;
      if(operator === 'VZW'){
        bodyId = Customization.getWifiCertifiedStrId(
          'is-warning-tethering-wifi-message-vzw',
          'is-warning-tethering-wifi-message-vzw'
        );
      } else {
        bodyId = Customization.getWifiCertifiedStrId(
          'is-warning-tethering-wifi-message',
          'is-warning-tethering-wlan-message'
        );
      }
      //add end by tailiangchen for defect-10878572

      const config = {
        title: { id: 'usb-tethering-header', args: {} },
        body: { id: bodyId, args: {} },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback() {
            elements.usbTetheringSelect.value = false;
            DebugHelper.debug('usb-tethering-off-dialog-hotspot cancel');
          }
        },
        confirm: {
          name: 'Turn On',
          l10nId: 'turnOn',
          priority: 3,
          callback() {
            if (currentConfig.isUsbStorageEnabled) {
              //cSet[HOTSPOT_WIFI_ENABLED] = false;
              //SettingsDBCache.saveSettings(cSet);
              showUsbStorageDialogByUSBTethering();
            } else if (currentConfig.isFTUTethering) {
              //cSet[HOTSPOT_WIFI_ENABLED] = false;
              //SettingsDBCache.saveSettings(cSet);
              showFtuDialogForUsbTethering(true);
            } else {
              //cSet[HOTSPOT_WIFI_ENABLED] = false;
              //SettingsDBCache.saveSettings(cSet);
              enableTethering('usb');
              //saveUsbTethering(true);
            }
          }
        }
      };
      DialogHelper.show(config);
    }

    function showUsbStorageDialogByUSBTethering() {
      const cSet = {};
      const config = {
        title: { id: 'usb-tethering-header', args: {} },
        body: { id: 'usb-storage-off-dialog', args: {} },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback() {
            resetWifiSavedStateWhenCancel();
            elements.usbTetheringSelect.value = false;
            DebugHelper.debug('Reset cancel');
          }
        },
        backcallback: () => {
          resetWifiSavedStateWhenCancel();
          elements.usbTetheringSelect.value = false;
        },
        confirm: {
          name: 'Turn On',
          l10nId: 'turnOn',
          priority: 3,
          callback() {
            if (currentConfig.isFTUTethering) {
              cSet[USB_STORAGE_KEY] = false;
              SettingsDBCache.saveSettings(cSet);
              showFtuDialogForUsbTethering(true);
            } else {
              cSet[USB_STORAGE_KEY] = false;
              SettingsDBCache.saveSettings(cSet);
              enableTethering('usb');
              //saveUsbTethering(true);
            }
          }
        }
      };
      DialogHelper.show(config);
    }

    function showFtuDialogForUsbTethering(oneBtn) {
      const config = {
        title: { id: 'usb-tethering-header', args: {} },
        body: { id: 'ftu-usb-tethering', args: {} }
      };
      if (oneBtn) {
        config.accept = {
          name: 'ok',
          l10nId: 'ok',
          priority: 2,
          callback() {
            DeviceFeature.setLocalStorageItem('firstTethering', 'false');
            currentConfig.isFTUTethering = false;
            enableTethering('usb');
            //saveUsbTethering(true);
          }
        };
        config.backcallback = () => {
          resetWifiSavedStateWhenCancel();
          elements.usbTetheringSelect.value = false;
        };
      } else {
        config.cancel = {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback() {
            elements.usbTetheringSelect.value = false;
            DebugHelper.debug('Reset cancel');
          }
        };
        config.confirm = {
          name: 'Turn On',
          l10nId: 'turnOn',
          priority: 3,
          callback() {
            DeviceFeature.setLocalStorageItem('firstTethering', 'false');
            currentConfig.isFTUTethering = false;
            enableTethering('usb');
            //saveUsbTethering(true);
          }
        };
      }
      DialogHelper.show(config);
    }

    function showUsbTetheringDialogByHotspot() {
      const cSet = {};

      //add begin by tailiangchen for defect-10878572
      var header;
      var bodyId;
      if(operator === 'VZW'){
        header = Customization.getWifiCertifiedStrId(
          'is-warning-wifi-header-vzw',
          'is-warning-wifi-header-vzw'
        );
        bodyId = Customization.getWifiCertifiedStrId(
          'is-warning-wifi-tethering-message-vzw',
          'is-warning-wifi-tethering-message-vzw'
        );
      } else {
        header = Customization.getWifiCertifiedStrId(
          'is-warning-wifi-header',
          'is-warning-wlan-header'
        );
        bodyId = Customization.getWifiCertifiedStrId(
          'is-warning-wifi-tethering-message',
          'is-warning-wlan-tethering-message'
        );
      }
      //add end by tailiangchen for defect-10878572
      const config = {
        title: { id: header, args: {} },
        body: { id: bodyId, args: {} },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback() {
            elements.wifiHotspotSelect.value = false;
            DebugHelper.debug('usb-tethering-off-dialog-hotspot cancel');
          }
        },
        confirm: {
          name: 'Turn On',
          l10nId: 'turnOn',
          priority: 3,
          callback() {
            if (currentConfig.isFTUHotspot) {
              showFtuDialogForHotspot(true);
              cSet[HOTSPOT_USB_ENABLED] = false;
              SettingsDBCache.saveSettings(cSet);
            } else {
              if (isVzwRoaming) {
                showRoamDialog();
              } else {
                enableTethering('hotspot');
              }
            }
          }
        }
      };
      DialogHelper.show(config);
    }

    function showFtuDialogForHotspot(oneBtn) {
      //add begin by tailiangchen for defect-10878572
      var header;
      if(operator === 'VZW'){
        header = Customization.getWifiCertifiedStrId(
          'is-warning-wifi-header-vzw',
          'is-warning-wifi-header-vzw'
        );
      } else {
        header = Customization.getWifiCertifiedStrId(
          'is-warning-wifi-header',
          'is-warning-wlan-header'
        );
      }
      //add begin by tailiangchen for defect-10878572
      const config = {
        title: { id: header, args: {} }
      };
      config.body = {
        id: 'ftu-wifi-hotspot',
        args: {}
      };
      if (oneBtn) {
        config.accept = {
          name: 'OK',
          l10nId: 'ok',
          priority: 2,
          callback() {
            if (isVzwRoaming) {
              showRoamDialog();
            } else {
              enableTethering('hotspot');
            }
          }
        };
        config.backcallback = function() {
          resetWifiSavedStateWhenCancel();
          elements.wifiHotspotSelect.value = false;
        };
      } else {
        config.cancel = {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback() {
            elements.wifiHotspotSelect.value = false;
            DebugHelper.debug('Wifi hotspot FTU cancel');
          }
        };
        config.confirm = {
          name: 'Turn On',
          l10nId: 'turnOn',
          priority: 3,
          callback() {
            if (isVzwRoaming) {
              showRoamDialog();
            } else {
              enableTethering('hotspot');
            }
          }
        };
      }
      DialogHelper.show(config);
    }

    //Task-10217008 add-begin shangpen.su@tcl.com 2020.11.18
    function showWifiHotspotTurnedOnDialog() {
      //Defect-10978227 modify-begin shangpeng.su 2021.04.01
      let password = hotspotSettings.security === 'open' ? 'null' : hotspotSettings.password;
      let body = {
        id: 'hotspot-setup-message-text-vzw',
        args: {
          ssid: elements.wifiSsidDes.textContent,
          password: password
        }
      };
      //Defect-10978227 modify-end shangpeng.su 2021.04.01
      let acceptCallback = function () {};
      let options =
        {
          type: 'accept',
          titleId: 'wifi-hotspot-title-vzw',
          body: body,
          acceptCallback: acceptCallback
        };
      showConfirmDialogCustom(options);
    }

    function showRoamDialog() {
      let body = { id: 'wifi-hotspot-dialog-roaming-text-vzw', args: {} };
      let cancelCallback = function () {
        elements.wifiHotspotSelect.value = false;
        DebugHelper.debug('Reset roaming cancel');
        resetWifiSavedStateWhenCancel();
      };
      let confirmCallback = function () {
        enableTethering('hotspot');
      };
      let options =
        {
          type: 'confirm',
          titleId: 'wifi-hotspot-dialog-roaming-title-vzw',
          body: body,
          cancelId: 'cancel',
          confirmId: 'continue',
          backcallback: cancelCallback,
          cancelCallback: cancelCallback,
          confirmCallback: confirmCallback
        };
      showConfirmDialogCustom(options);
    }

    //Task-10217008 add-begin shangpen.su@tcl.com 2020.11.18
    function showConfirmDialogCustom(options) {
      const config = {
        title: { id: options.titleId, args: {} },
        body: options.body,
        backcallback: options.backcallback
      };
      if (options.type === 'confirm') {
        config.cancel = {
          name: 'Cancel',
          l10nId: options.cancelId,
          priority: 1,
          callback: options.cancelCallback
        };
        config.confirm = {
          name: 'Open',
          l10nId: options.confirmId,
          priority: 3,
          callback: options.confirmCallback
        }
      } else if (options.type === 'accept'){
        config.accept = {
          name: 'OK',
          l10nId: 'ok',
          priority: 2,
          callback: options.acceptCallback
        };
      }
      DialogHelper.show(config);
    }

    const handleChange = function handleChange(evt) {
      evt.stopPropagation();
      document.querySelector('.focus').focus();
      const { target } = evt;
      const value = target.value === 'true' || false;
      const cSet = {};
      switch (target.id) {
        case 'wifi-hotspot-select':
          //Defect-10665840 add-begin shangpeng.su 2021.01.20
          if (value && operator === 'TMO' &&
            hotspotSettings.security === 'wpa2-psk' && !hotspotSettings.password) {
            elements.wifiHotspotSelect.value = false;
            hotspotSettings.firstSetPwdWithEnable = true;
            Settings.setCurrentPanel('hotspot_wifi_settings', {
              settings: hotspotSettings
            });
            return;
          } else {
            hotspotSettings.firstSetPwdWithEnable = false;
          }
          //Defect-10665840 add-end shangpeng.su 2021.01.20
          onWifiHotspotSelect(value);
          break;
        case 'usb-tethering-select':
          if (value) {
            //Defect-10582137 modify-begin shangpeng.su@tcl.com 2020.12.25
            if (!currentConfig.ignoreMhsCheck && !currentConfig.hasSIMCard) {
              showSIMCardDialog(target);
              return;
            }
            if (!currentConfig.ignoreMhsCheck && !currentConfig.isDataEnabled) {
              showNetworkDialog(target);
              return;
            }
            //Defect-10582137 modify-end shangpeng.su@tcl.com 2020.12.25

            updateShowDialog(true);

            if (currentConfig.isWifiEnabled) {
              if (showDialog) {
                showWifiDialogByUSBTetheringTmo();
              } else {
                showWifiDialogByUSBTethering();
              }
              //Task-10217007/10217863 modify-end shangpeng.su@tcl.com 2020.11.17
            } else if (currentConfig.wifiHotspotEnabled) {
              showHotspotDialogByUSBTethering();
            } else if (currentConfig.isUsbStorageEnabled) {
              showUsbStorageDialogByUSBTethering();
            } else if (currentConfig.isFTUTethering) {
              showFtuDialogForUsbTethering(false);
            } else {
              enableTethering('usb');
              //saveUsbTethering(true);
            }
          } else {
            saveUsbTethering(value);
          }
          break;
        default:
          break;
      }
    };

    const handleEvent = function handleEvent(evt) {
      evt.stopPropagation();
      evt.preventDefault();
      if (
        elements.hotspotSettingsItem.getAttribute('aria-disabled') === 'true'
      ) {
        return;
      }
      Settings.setCurrentPanel('hotspot_wifi_settings', {
        settings: hotspotSettings
      });
    };

    function onWifiHotspotSelect(value) {
      if (value) {
        //Defect-10582137 modify-begin shangpeng.su@tcl.com 2020.12.25
        if (!currentConfig.ignoreMhsCheck && !currentConfig.hasSIMCard) {
          showSIMCardDialog(target);
          elements.wifiHotspotSelect.value = false;
          return;
        }
        if (!currentConfig.ignoreMhsCheck && !currentConfig.isDataEnabled) {
          showNetworkDialog(target);
          elements.wifiHotspotSelect.value = false;
          return;
        }
        //Defect-10582137 modify-end shangpeng.su@tcl.com 2020.12.25

        //Task-10217007/10217863 modify-begin shangpeng.su@tcl.com 2020.11.17
        updateShowDialog(false);

        if (currentConfig.isWifiEnabled && showDialog) {
          showWifiDialogByWifiHotspot();
        } else if (currentConfig.usbTetheringEnabled) {
          showUsbTetheringDialogByHotspot();
        } else if (currentConfig.isFTUHotspot) {
          showFtuDialogForHotspot(false);
        } else {
          if (isVzwRoaming) {
            showRoamDialog();
          } else {
            enableTethering('hotspot');
          }
        }
      } else {
        const cSet = {};
        cSet[HOTSPOT_WIFI_ENABLED] = false;
        SettingsDBCache.saveSettings(cSet);
      }
    }

    function generateHotspotPassword() {
      const words = [
        'amsterdam',
        'ankara',
        'auckland',
        'belfast',
        'berlin',
        'boston',
        'calgary',
        'caracas',
        'chicago',
        'dakar',
        'delhi',
        'dubai',
        'dublin',
        'houston',
        'jakarta',
        'lagos',
        'lima',
        'madrid',
        'newyork',
        'osaka',
        'oslo',
        'porto',
        'santiago',
        'saopaulo',
        'seattle',
        'stockholm',
        'sydney',
        'taipei',
        'tokyo',
        'toronto'
      ];
      let password = words[Math.floor(Math.random() * words.length)];
      for (let i = 0; i < 4; i++) {
        password += Math.floor(Math.random() * 10);
      }
      return password;
    }

    //Defect-10614637 add-begin shangpeng.su 2021.01.06
    function generateHotspotPasswordByCustomLength(value) {
      const letterList =
        [
          '0123456789',
          "%&',;=?$^",
          'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        ];
      let letterCheckList = [false, false, false];
      let password = '';
      let pwdLength = value;
      for (let i = 0; i < pwdLength; i ++) {
        let randomNum = Math.floor(Math.random() * 10);
        let char = letterList[randomNum % 3].charAt(
          Math.floor(Math.random() * letterList[randomNum % 3].length));
        letterCheckList[randomNum % 3] = true;
        let isValid = letterCheckList[0] && letterCheckList[1] && letterCheckList[2];
        if ((i === (pwdLength - 2) || (i === pwdLength -1 )) && !isValid) {
          for (let j = 0; j < letterCheckList.length; j ++) {
            if (!letterCheckList[j]) {
              letterCheckList[j] = true;
              char = letterList[j].charAt(
                Math.floor(Math.random() * letterList[j].length));
              break;
            }
          }
        }
        password += char;
      }
      return password;
    }
    //Defect-10614637 add-end shangpeng.su 2021.01.06

    const getStorageBoolean = function getStorageBoolean(key) {
      const boolValue = DeviceFeature.getValue(key) || 'true';
      const enabled = boolValue === 'true' || false;
      return enabled;
    };

    const usbInsertChange = function usbInsertChange(evt) {
      currentConfig.isUSBInserted = evt.deviceAttached;
      DebugHelper.log(`onusbstatuschange:${currentConfig.isUSBInserted}`);
      updateUsbTetheringStatus(currentConfig.isUSBInserted);
    };

    const tetheringStatesChange = function tetheringStatesChange(evt) {
      if (evt.isTrusted) {
        updateUsbTetheringStatus(currentConfig.isUSBInserted);
      }
    };

    function initActiveSIMSlot() {
      SIMSlotManager.getSlots().forEach(SIMSlot => {
        if (!SIMSlot.isAbsent()) {
          currentConfig.activeSIMCard = SIMSlot;
          isVzwRoaming = (operator === 'VZW'
            && SIMSlot.conn.data && SIMSlot.conn.data.roaming);
        }
      });

      if (currentConfig.activeSIMCard === null) {
        currentConfig.hasSIMCard = false;
      } else {
        currentConfig.activeSIMCard.conn.addEventListener(
          'cardstatechange',
          updateActiveSIMSlot
        );
        updateActiveSIMSlot();
      }
    }

    //Defect-10760539 modify-begin shangpeng.su 2021.02.23
    //Task-10228658 add-begin shangpeng.su@tclc.om 2020.11.19
    function customDefaultSsid() {
      //add begin by tailiangchen for jira GF5GTMO-8460
      let SSID_KEY = 'tethering.wifi.ssid';
      if ( (CU.length >= 10) && (CU.substring(8,10) === '3U') ) {
        SSID_KEY = 'tethering.wifi.uscc.ssid';
        console.log('sub cu = ' + CU.substring(8,10));
       }
      //add end by tailiangchen for jira GF5GTMO-8460
      //Defecet-10614629 modify-begin shangpeng.su 2021.01.06
      SettingsDBCache.getSetting(SSID_KEY).then(value => {
        let ssid = value;
        //Defect-11061642 modify-begin shangpeng.su 2021.04.30
        let operatorWithImei = ['TMO', 'USCC', 'BOOST'];
        if (operator && (operatorWithImei.indexOf(operator) !== -1)) {
        //Defect-11061642 modify-end shangpeng.su 2021.04.30
          let imei = navigator.b2g.mobileConnections[0].getDeviceIdentities().imei;
          console.log('susp_test, customDefaultSsid, imei=' + imei);

          if (imei && imei.length > 4) {
            ssid = ssid + ' ' + imei.substr(imei.length - 4);
          }
        } else if (operator === 'VZW' && navigator.b2g.engmodeManager) {
          let macAddress = navigator.b2g.wifiManager.macAddress;
          console.log('susp_test, customDefaultSsid, macAddress=' + macAddress);
          navigator.b2g.engmodeManager.getPropertyValue('ro.product.model')
            .then(model => {
              if (model && macAddress
                && macAddress !== 'undefined' && macAddress.length > 4) {
                let macOctets = macAddress.split(':');
                macAddress =
                  macOctets[macOctets.length - 2] + macOctets[macOctets.length - 1];
                ssid = ssid + model + "-" + macAddress;
              }
              doSaveDefaultSsid(ssid);
            });
          return;
        //add begin by tailiangchen for jira GF7TF-3361
        } else if (operator === 'TF') {
          //add begin by tailiangchen for jira GF7TF-3822
          let macAddress = navigator.b2g.wifiManager.macAddress;
          ssid = ssid + '-';  //fix by tailiangchen for jira GF7TF-4110
          if (macAddress && macAddress !== 'undefined' && macAddress.length > 4) {
            let macOctets = macAddress.split(':');
            macAddress = macOctets[macOctets.length - 2] + macOctets[macOctets.length - 1];
            ssid = ssid + macAddress;
          } else {
            for (let i = 0; i < 4; i++) {
              ssid += Math.floor(Math.random() * 10);
            }
          }
          console.log('OP:TF customDefaultSsid, macAddress=' + macAddress + ' ssid = ' + ssid);
          //add end by tailiangchen for jira GF7TF-3822
        //[GF7OM-275] add-begin shangpeng.su 2023.12.08
        } else if (operator === 'USOM' || operator === "EE") {  //add by tailiangchen for jira GF7EE-895
          ssid = ssid + ' ' + generateRandomIntForDefaultSsid();  //fixed by tailiangchen for jira GF7OM-844
        }
        //[GF7OM-275] add-end shangpeng.su 2023.12.08
        //add end by tailiangchen for jira GF7TF-3361
        doSaveDefaultSsid(ssid);
      });
      //Defecet-10614629 modify-end shangpeng.su 2021.01.06
    }
    //Task-10228658 add-end shangpeng.su@tclc.om 2020.11.19

    function doSaveDefaultSsid(ssid) {
      const cSet = {};
      cSet[WIFI_SSID_KEY] = ssid;
      SettingsDBCache.saveSettings(cSet);
      console.log('susp_test, new ssid = ' + ssid);
      DeviceFeature.setLocalStorageItem('firstHotspotDefaultSsid', 'false');
    }
    //Defect-10760539 modify-end shangpeng.su 2021.02.23

    //Task-10217007/10217863 add-begin shangpeng.su@tcl.com 2020.11.17
    function initOperator() {
      if (navigator.b2g.engmodeManager) {
        navigator.b2g.engmodeManager.getPropertyValue('ro.tct.curef')
          .then(value => {
            CU = value;
            if (CU != '') {
              console.log('CU = ' + CU);
            }
          });
        navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name')
          .then(value => {
            operator = value;
            initActiveSIMSlot();
            initAutoTimeoutOptions();//Task-10217843 add shangpen.su@tcl.com 2020.11.18
            //Task-10228658 add-begin shangpeng.su@tclc.om 2020.11.19
            if (getStorageBoolean('firstHotspotDefaultSsid')) {
              customDefaultSsid();
            }
            //Task-10228658 add-end shangpeng.su@tclc.om 2020.11.19

            //[GF7TF-3565] add-begin shangpeng.su 2023.10.08
            needVzwProvisioningcheck = operator === 'VZW'
                || (operator === 'TF' && OperatorUtils.isVZWFamily());
            //[GF7TF-3565] add-end shangpeng.su 2023.10.08
            //add begin by tailiangchen for jira GF5GTMO-5751
            if ('TMO' === operator) {
              currentConfig.ignoreMhsCheck = true;
            }
            //add end by tailiangchen for jira GF5GTMO-5751
          });
      }
    }

    function initCurrentConfig() {
      //Defect-10582137 modify-begin shangpeng.su@tcl.com 2020.12.25
      SettingsDBCache.getSettings(
        [HOTSPOT_WIFI_ENABLED, WIFI_KEY,
          HOTSPOT_USB_ENABLED, DATA_KEY,
          TETHERING_MHS_CHECK_INGORE],
        results => {
          currentConfig.isDataEnabled = results[DATA_KEY];
          currentConfig.isWifiEnabled = results[WIFI_KEY];
          currentConfig.wifiHotspotEnabled = results[HOTSPOT_WIFI_ENABLED];
          currentConfig.usbTetheringEnabled = results[HOTSPOT_USB_ENABLED];
          currentConfig.ignoreMhsCheck = results[TETHERING_MHS_CHECK_INGORE];
        });
      //Defect-10582137 modify-end shangpeng.su@tcl.com 2020.12.25
    }

    function updateShowDialog(isUsbTether) {
      showDialog = false;
      let isConnected = wifiManager.connection && wifiManager.connection.network;
      switch (operator) {
        case 'TMO':
        case 'USCC'://Defect-11082549 add shangpeng.su 2021.04.30
          if (isConnected) {
            showDialog = true;
          }
          break;
        default :
          showDialog = true;
          if (isUsbTether) {
            showDialog = false;
          }
          break;
      }
    }
    //Task-10217007/10217863 add-end shangpeng.su@tcl.com 2020.11.17

    //Task-10217843 add-begin shangpen.su@tcl.com 2020.11.18
    function initAutoTimeoutOptions() {
      if (operator === 'TMO') {
        let options = elements.autoTimeoutSelector.options;
        let length = options.length;
        for (let i = 0; i < length; i ++) {
          elements.autoTimeoutSelector.remove(0);
        }
        const timeSeconds = [
          {name:'timeout-never-tmo', value: 0},
          {name:'timeout-five-minutes-tmo', value: 300},
          {name:'timeout-ten-minutes-tmo', value: 600},
          {name:'timeout-twenty-minutes-tmo', value: 1200}
        ];
        timeSeconds.forEach(second => {
          const option = document.createElement('option');
          option.value = second.value;
          option.setAttribute('data-l10n-id', `hotspot-${second.name}`);
          elements.autoTimeoutSelector.appendChild(option);
        });
      }
      //Defect-10880322 add-begin shangpeng.su 2021.03.17
      elements.autoTimeoutSpan.textContent = l10n.get(
        operator === 'VZW' ? 'timeout-settings' : 'auto-turnOff'
      );
      //Defect-10880322 add-end shangpeng.su 2021.03.17
    }
    //Task-10217843 add-end shangpen.su@tcl.com 2020.11.18

    //Task-10464254 add-begin shangpeng.su@tcl.com 2020.12.14
    function enableTethering(type) {
      //add begin by tailiangchen for defect-10950562
      let cSet = {};
      if (currentConfig.isWifiEnabled) {
        cSet[WIFI_SAVED_KEY] = currentConfig.isWifiEnabled;
        SettingsDBCache.saveSettings(cSet);
      }
      //add end by tailiangchen for defect-10950562
      switch (type) {
        case 'hotspot':
          //[GF7TF-3565] modify-begin shangpeng.su 2023.10.09
          //Defecet-11006928 modify-begin shangpeng.su 2021.04.12
          //Defect-10582137 modify-begin shangpeng.su@tcl.com 2020.12.25
          if (!currentConfig.ignoreMhsCheck && needVzwProvisioningcheck) {
            SettingsDBCache.saveSettings({'tethering.enable.type': 'hotspot'});
            new WebActivity('launch-wifihotspot', {
              type: 'vzwhotspotprovisioningcheck'
            }).start();
            //Defect-11050873 modify-begin shangpeng.su 2021.04.29
            elements.wifiHotspotSelect.value = currentConfig.wifiHotspotEnabled;
          } else {
            doEnableHotspot();
          }
          break;
        case 'usb':
          updateUsbItemStatus(true);
          if (!currentConfig.ignoreMhsCheck && needVzwProvisioningcheck) {
          //[GF7TF-3565] modify-end shangpeng.su 2023.10.09
            SettingsDBCache.saveSettings({'tethering.enable.type': 'usb'});
            new WebActivity('launch-wifihotspot', {
              type: 'vzwhotspotprovisioningcheck'
            }).start();
            elements.usbTetheringSelect.value = currentConfig.usbTetheringEnabled;
            //Defect-11050873 modify-end shangpeng.su 2021.04.29
            //Defecet-11006928 modify-end shangpeng.su 2021.04.12
          } else {
            doEnableUsbTethering();
          }
          //Defect-10582137 modify-end shangpeng.su@tcl.com 2020.12.25
          break;
        }
    }

    function checkProvisioning(callback) {
      console.log('begin provisioning check');
      SIMSlotManager.getSlots().forEach(SIMSlot => {
        if (!SIMSlot.isAbsent()) {
          let iccId = SIMSlot.conn.iccId;
          let subSimSerialNumber = iccId && iccId.substring(14);
          let preFix = "6wN6Oh";
          let partialICCID = preFix + subSimSerialNumber;
          let iccInfo = SIMSlot.simCard.iccInfo;
          let mobileNumber = iccInfo && (iccInfo.msisdn || iccInfo.mdn);
          if (!mobileNumber || !subSimSerialNumber) {
            console.log('Provisioning check failed due mobileNumber or subSimSerialNumber');
            callback(false);
            return;
          }
          mobileNumber = mobileNumber.length > 10 ?
            mobileNumber.substring(mobileNumber.length - 10) : mobileNumber;
          let xml = createProvisioningXml(mobileNumber, partialICCID, 'MHF');
          let soapUrl = 'https://quickaccess.verizonwireless.com/ws/device/service';
          let xmlHttp = new XMLHttpRequest({mozSystem: true, mozAnon: true});
          xmlHttp.open('POST', soapUrl, true);
          xmlHttp.timeout = 12000;
          xmlHttp.setRequestHeader(
            'Access-Control-Allow-Origin', '*');
          xmlHttp.setRequestHeader(
            'Host', 'quickaccess.verizonwireless.com');
          xmlHttp.setRequestHeader(
            'Content-Type', 'text/xml');
          xmlHttp.setRequestHeader(
            'Content-Length', (xml.length).toString());
          xmlHttp.setRequestHeader(
            'SOAPAction', '');
          xmlHttp.send(xml);
          xmlHttp.onreadystatechange = () => {
            console.log("Provisioning, state=" + xmlHttp.readyState + ",status=" + xmlHttp.status);
            if (xmlHttp.readyState === XMLHttpRequest.DONE && xmlHttp.status === 200) {
              parseResult(xmlHttp.response, hasTetheringFeature => {
                if (!hasTetheringFeature) {
                  console.log('Provisioning check failed, sim card not support hotspot feature');
                }
                //Defect-10627791 add-begin shangpeng.su@tcl.com 2021.01.12
                SettingsDBCache.saveSettings({
                  'tethering.wifi.provisiong.info' :
                    (hasTetheringFeature ? (mobileNumber + subSimSerialNumber) : '')
                });
                //Defect-10627791 add-end shangpeng.su@tcl.com 2021.01.12
                callback(hasTetheringFeature);
              });
            }
          };
          xmlHttp.timeout = xmlHttp.onerror = () => {
            console.log('Provisioning check failed, timeout or error');
            //Defect-10627791 add-begin shangpeng.su@tcl.com 2021.01.12
            SettingsDBCache.saveSettings({
              'tethering.wifi.provisiong.info' :  ''
            });
            //Defect-10627791 add-end shangpeng.su@tcl.com 2021.01.12
            callback(false);
          };
        }
      });
    }

    function createProvisioningXml(mobileNumber, partialICCID, featureCode) {
      let xml = '<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" ' +
        'xmlns:ser=\"https://quickaccess.verizonwireless.com/ws/device/service\">' +
        '<soapenv:Header/><soapenv:Body><ser:hasFeature>' +
        '<ser:mobileNumber>' + mobileNumber + '</ser:mobileNumber>' +
        '<ser:partialICCID>' + partialICCID + '</ser:partialICCID>' +
        '<ser:featureCode>' + featureCode + '</ser:featureCode>' +
        '</ser:hasFeature></soapenv:Body></soapenv:Envelope>';
      return xml;
    }

    function parseResult(response, callback) {
      console.log('susp_test, response='+response);
      let endIndex = response.indexOf('</java:Status>');
      callback(endIndex ?
        (response.substr(endIndex - 1, 1) === '1' ? true : false) : false);
    }

    function doEnableHotspot() {
      if (currentConfig.isFTUHotspot) {
        DeviceFeature.setLocalStorageItem('firstHotspot', 'false');
        currentConfig.isFTUHotspot = false;
      }
      //Defect-10651366 modify-begin shangpeng.su 2021.01.14
      let cSet = {};
      //Defect-10582137 modify-begin shangpeng.su@tcl.com 2020.12.25
      if (currentConfig.isWifiEnabled) {
        cSet[WIFI_KEY] = false;
        SettingsDBCache.saveSettings(cSet);
        cSet = {};
      }
      //Defect-10651366 modify-end shangpeng.su 2021.01.14
      //Defect-10582137 modify-end shangpeng.su@tcl.com 2020.12.25

      if (currentConfig.usbTetheringEnabled) {
        if (currentConfig.isWifiSavedEnabled) {
          //add begin by tailiangchen for defect-10950562
          cSet[TETHERING_WIFI_USB_CHANGE] = true;
          //add end by tailiangchen for defect-10950562
        }
        cSet[HOTSPOT_USB_ENABLED] = false;
      }

      cSet[HOTSPOT_WIFI_ENABLED] = true;
      needShowHotspotTurnOnDialog = true;
      SettingsDBCache.saveSettings(cSet);
      setWifiTetheringEnabled();

      //Task-10297039-BEGIN ganghong.liu 2020-12-15
      if ( sprOperator === 'SPR' && !apnAvailable ) {
        setProp({'tethering.apn.pam': 'hotspot'});
        return;
      }
      //Task-10297039-END

    }

    function doEnableUsbTethering() {
      if (currentConfig.isFTUTethering) {
        DeviceFeature.setLocalStorageItem('firstTethering', 'false');
        currentConfig.isFTUTethering = false;
      }
      const cSet = {};
      cSet[WIFI_KEY] = false;
      if (currentConfig.isUsbStorageEnabled) {
        cSet[USB_STORAGE_KEY] = false;
      }
      //Task-10232568 add-begin shangpeng.su@tcl.com 2020.11.20
      //add begin by tailiangchen for defect-10950562
      if (currentConfig.wifiHotspotEnabled && currentConfig.isWifiSavedEnabled) {
        cSet[TETHERING_WIFI_USB_CHANGE] = true;
      }
      //add end by tailiangchen for defect-10950562
      //Task-10232568 add-end shangpeng.su@tcl.com 2020.11.20
      if (currentConfig.wifiHotspotEnabled) {
        cSet[HOTSPOT_WIFI_ENABLED] = false;
      }
      cSet[HOTSPOT_USB_ENABLED] = true;
      SettingsDBCache.saveSettings(cSet);

      //Task-10297039-BEGIN ganghong.liu 2020-12-15
      if ( sprOperator === 'SPR' && !apnAvailable ) {
        setProp({'tethering.apn.pam': 'data-tethering'});
        return;
      }
      //Task-10297039-END
    }

    function showNoPremissionDialog(type) {
      let titleId = 'tethering-usb-title-vzw';
      if (type === 'hotspot') {
        titleId = 'wifi-hotspot-title-vzw';
      }
      let confirmCallback = function () {
        const activity = new WebActivity(
          {
            name: 'view',
            data: { type: 'url', url: 'https://mobile.vzw.com/hybridClient/mvm/hotspot ' }
          });
        activity.start();
      };
      let options =
        {
          type: 'confirm',
          titleId: titleId,
          body: { id: 'tethering_no_premission_message-vzw', args: {} },
          cancelId: 'cancel',
          confirmId: 'ok',
          confirmCallback: confirmCallback
        };
      showConfirmDialogCustom(options);
    }
    //Task-10464254 add-end shangpeng.su@tcl.com 2020.12.14

    //Task-10297039-BEGIN ganghong.liu 2020-12-15
    function setProp(key, value) {
      /*window.remoteHelper.setproperty(key,value,(response)=>{
        dump('kaioseiffel remoteHelper success:'+value+', '+JSON.parse(response).value);
      }, ()=>{
        dump('kaioseiffel remoteHelper error ,setpropery' + key);
      });*/
      const cSet = {};
      cSet[key] = value;
      SettingsDBCache.saveSettings(cSet);
      dump('kaioseiffel setProp2 :'+key+', '+value);
    };

    function initOperatorName() {
      if (window.remoteHelper) {
          window.remoteHelper.getproperty('ro.operator.name', (response)=>{
            sprOperator = JSON.parse(response).value;
            dump('kaioseiffel: sprOperator -'+ sprOperator);

            if ( sprOperator === 'SPR' ) {//TMO, test
              SettingsObserver.getValue(APNSETTING).then(function (value) {
                  dump('kaioseiffel currentApns2=' + JSON.stringify(value));
                  //setProp('tethering.apn.pam', 'yes');//test
                  var currentApns = value[0] || {};
                  if (Object.keys(currentApns).length !== 0) {
                    for (var i = 0; i < currentApns.length; i++) {
                      dump('kaioseiffel: currentApns['+i+'].types[0]='+currentApns[i].types[0]+', apn:'+currentApns[i].apn);
                      if (currentApns[i].types[0] === 'pam' || currentApns[i].types[0] === 'dun') {//ref: simba6 na spr TetherSettings.java
                        apnAvailable = true;
                        setProp('tethering.apn.pam', 'yes');
                        break;
                      } else {
                        apnAvailable = false;
                      }
                    }
                  }
              });
            }
          }, ()=>{
        });
      }
    }
    //Task-10297039-END

    function updateActiveSIMSlot() {
      const { cardState } = currentConfig.activeSIMCard.simCard;
      switch (cardState) {
        case null:
        case 'unknown':
          currentConfig.hasSIMCard = false;
          break;
        default:
          currentConfig.hasSIMCard = true;
          break;
      }
    }

    function updateDisplayUI() {
      elements.wifiHotspotH2.setAttribute(
        'data-l10n-id',
        Customization.getWifiCertifiedStrId(
          'internetSharing-wifi',
          'internetSharing-wlan'
        )
      );
      //add begin by tailiangchen for defect-10878572
      if(operator === 'VZW'){
        elements.internetSharingHeader.style.cssText = "overflow:hidden;text-overflow:ellipsis;padding:2rem;white-space:nowrap;";//add begin by tailiangchen for defect-11360073
        elements.wifiHotspotSpan.setAttribute('data-l10n-id','wifi-hotspot-vzw');
        elements.internetSharingHeader.setAttribute(
          'data-l10n-id',
          'mobile_hotspot_usb_tethering_header_vzw'); //fix by tailiangchen for defect-11360073
      } else {
        elements.wifiHotspotSpan.setAttribute(
          'data-l10n-id',
          Customization.getWifiCertifiedStrId('wifi-hotspot', 'wlan-hotspot')
        );
      }
      //add end by tailiangchen for defect-10878572

      elements.internetSharingWifiDesc.setAttribute(
        'data-l10n-id',
        Customization.getWifiCertifiedStrId(
          'internetSharing-wifi-desc',
          'internetSharing-wlan-desc'
        )
      );

      //add begin by tailiangchen for defect-10878572
      if(operator === 'VZW'){
        elements.hotspotSettingsMenuItem.setAttribute('data-l10n-id', 'setup-mobile-hotspot-vzw');//fix by tailiangchen for defect-11226738
        elements.autoTurnOffDesc.setAttribute('data-l10n-id','auto-turnOff-desc-vzw');
      } else {
        elements.autoTurnOffDesc.setAttribute(
          'data-l10n-id',
          Customization.getWifiCertifiedStrId(
            'auto-turnOff-desc',
            'auto-turnOff-desc-wlan'
          )
        );
      }
      //add end by tailiangchen for defect-10878572
    }

    //add begin by tailiangchen for defect-11084703
    function updateSoftkeyshowPassword(evt) {
      const focusElement = document.querySelector('.focus');

      if ((focusElement.id === 'wifi-hotspot-item') && (currentConfig.wifiHotspotEnabled)) {
        if (elements.wifiPasswordDes.textContent === '********') {
          elements.wifiPasswordItem.classList.remove('none-select');
          SettingsSoftkey.init(showpass);
          SettingsSoftkey.show();
        } else {
          elements.wifiPasswordItem.classList.remove('none-select');
          SettingsSoftkey.init(hidepass);
          SettingsSoftkey.show();
        }
      } else {
        elements.wifiPasswordItem.classList.add('none-select');
        SettingsSoftkey.init(SoftParams.defaultSelect);
        const { classList } = evt.currentTarget;
        if (classList && classList.contains('none-select')) {
          SettingsSoftkey.hide();
        } else {
          SettingsSoftkey.show();
        }
      }
    }
    //add end by tailiangchen for defect-11084703

    //[GF7OM-275] add-begin shangpeng.su 2023.12.08
    function generateRandomIntForDefaultSsid() {
      var randomInt = "";
      for (let i = 0; i < 4; i ++) {
        randomInt += Math.floor(Math.random() * 10);
      }
      return randomInt;
    }
    //[GF7OM-275] add-end shangpeng.su 2023.12.08

    return SettingsPanel({
      onInit(panel) {
        listElements = panel.querySelectorAll('li');
        elements = {
          panel,
          items: panel.querySelectorAll('li'),//Defect10562667-bin.shen@tcl.com
          wifiTetheringSection: panel.querySelector('#wifi-tethering-section'),
          usbTetheringSection: panel.querySelector('#usb-tethering-section'),
          hotspotSettingsItem: panel.querySelector('#hotspot-settings-item'),
          hotspotSettingsMenuItem:panel.querySelector('.menu-item'),      //add by tailiangchen for defect-10982756
          wifiHotspotSelect: panel.querySelector('#wifi-hotspot-select'),
          autoTimeoutSelector: panel.querySelector('#auto-timeout-select'),
          autoTimeoutSpan: panel.querySelector('#auto-timeout-span'),
          usbTetheringItem: panel.querySelector('#usb-tethering'),
          usbTetheringSelect: panel.querySelector('#usb-tethering-select'),
          wifiSsidDes: panel.querySelector('#network-name-desc'),
          wifiSecurityTypeDes: panel.querySelector('#wifi-security-desc'),
          wifiBandDes: panel.querySelector('#wifi-band-desc'),
          wifiPasswordItem: panel.querySelector('#wifi-hotspot-item'),
          wifiPasswordDes: panel.querySelector('#wifi-password-desc'),
          hotspotConnDevicesItem: panel.querySelector('#hotspot-connected-devices-item'),
          hotspotBlockDevicesItem: panel.querySelector('#hotspot-blocked-devices-item'),
          wifiHotspotH2: panel.querySelector('#hotspot-wifi-header h2'),
          wifiHotspotSpan: panel.querySelector('#wifi-hotspot span'),
          internetSharingWifiDesc: panel.querySelector(
            '#internet-sharing-wifi-desc span'
          ),
          autoTurnOffDesc: panel.querySelector('#auto-turn-off-desc span'),
          internetSharingHeader: panel.querySelector('h1') //add by tailiangchen for defect-11084730
        };

        currentConfig = {
          activeSIMCard: null,
          hasSIMCard: false,
          isDataEnabled: true,
          isWifiEnabled: false,
          isUsbStorageEnabled: false,
          wifiHotspotEnabled: false,
          usbTetheringEnabled: false,
          isUSBInserted: ApiManager.usbManager.deviceAttached,
          isFTUHotspot: getStorageBoolean('firstHotspot'),
          isFTUTethering: getStorageBoolean('firstTethering')
        };
        updateUsbTetheringStatus(currentConfig.isUSBInserted);
        ApiManager.usbManager.onusbstatuschange = usbInsertChange;
        //Task-10217007/10217863 add-begin shangpeng.su@tcl.com 2020.11.17
        initOperator();
        //Task-10217007/10217863 add-end shangpeng.su@tcl.com 2020.11.17
        initActiveSIMSlot();
        initCurrentConfig();

        //Task-10297039 ganghong.liu 2020-12-15
        initOperatorName();

        elements.wifiHotspotH2.setAttribute(
          'data-l10n-id',
          Customization.getWifiCertifiedStrId(
            'internetSharing-wifi',
            'internetSharing-wlan'
          )
        );

        //add begin by tailiangchen for defect-10878572
        if(operator === 'VZW'){
          elements.wifiHotspotSpan.setAttribute('data-l10n-id','wifi-hotspot-vzw');
        } else {
          elements.wifiHotspotSpan.setAttribute(
            'data-l10n-id',
            Customization.getWifiCertifiedStrId('wifi-hotspot', 'wlan-hotspot')
          );
        }
        //add end by tailiangchen for defect-10878572

        elements.internetSharingWifiDesc.setAttribute(
          'data-l10n-id',
          Customization.getWifiCertifiedStrId(
            'internetSharing-wifi-desc',
            'internetSharing-wlan-desc'
          )
        );

        //add begin by tailiangchen for defect-10878572
        if(operator === 'VZW'){
          elements.autoTurnOffDesc.setAttribute(
            'data-l10n-id',
            Customization.getWifiCertifiedStrId(
              'auto-turnOff-desc-vzw',
              'auto-turnOff-desc-vzw'
            )
          );
        } else {
          elements.autoTurnOffDesc.setAttribute(
            'data-l10n-id',
            Customization.getWifiCertifiedStrId(
              'auto-turnOff-desc',
              'auto-turnOff-desc-wlan'
            )
          );
        }
        //add end by tailiangchen for defect-10878572
        ApiManager.tetheringManager.ontetheringstatuschange = tetheringStatesChange;
        initActiveSIMSlot();
      },

      onBeforeShow(panel) {
        //add begin by tailiangchen for defect-11084703
        if (operator === 'VZW') {
          let item = null;
          item = document.querySelector('.focus');
          if (!(item === null)) {
            if ((item.id === 'wifi-hotspot-item') && (currentConfig.wifiHotspotEnabled)) {
              if(elements.wifiPasswordDes.textContent === '********'){
                SettingsSoftkey.init(showpass);
                SettingsSoftkey.show();
              } else {
                SettingsSoftkey.init(hidepass);
                SettingsSoftkey.show();
              }
            } else {
              SettingsSoftkey.init(SoftParams.defaultSelect);
              ListFocusHelper.updateSoftkey(panel);
            }
          }
        } else {
          SettingsSoftkey.init(SoftParams.defaultSelect);
          ListFocusHelper.updateSoftkey(panel);
        }
        //add end by tailiangchen for defect-11084703

        updateDisplayUI();
        SettingsDBCache.observe(DM_WIFI_UI, '', handleSettingsChange);
        SettingsDBCache.observe(DM_USB_UI, '', handleSettingsChange);
        SettingsDBCache.observe(
          HOTSPOT_WIFI_ENABLED,
          false,
          handleSettingsChange
        );
        SettingsDBCache.observe(
          HOTSPOT_USB_ENABLED,
          false,
          handleSettingsChange
        );

        SettingsDBCache.observe(WIFI_SSID_KEY, '', handleSettingsChange);
        SettingsDBCache.observe(
          WIFI_SECURITY_KEY,
          'wpa-psk',
          handleSettingsChange
        );
        SettingsDBCache.observe(WIFI_PASSWORD_KEY, '', handleSettingsChange);
        SettingsDBCache.observe(WIFI_AP_BAND, '2.4G', handleSettingsChange);
        SettingsDBCache.observe(DATA_KEY, true, handleSettingsChange);
        SettingsDBCache.observe(WIFI_KEY, false, handleSettingsChange);
        SettingsDBCache.observe(WIFI_SAVED_KEY, false, handleSettingsChange);
        SettingsDBCache.observe(USB_STORAGE_KEY, false, handleSettingsChange);
        SettingsDBCache.observe(
          WIFI_BROADCAST_SSID_KEY, true, handleSettingsChange);
        //Defect-10582137 add-begin shangpeng.su@tcl.com 2020.12.25
        SettingsDBCache.observe(
            TETHERING_MHS_CHECK_INGORE, false, handleSettingsChange);
        //Defect-10582137 add-end shangpeng.su@tcl.com 2020.12.25
        //Defect-10648763 add-begin shangpeng.su 2021.01.14
        SettingsDBCache.observe(
          WIFI_SHOW_PASSWORD_KEY, true, handleSettingsChange);
        //Defect-10648763 add-end shangpeng.su 2021.01.14

        elements.wifiHotspotSelect.addEventListener('change', handleChange);
        elements.usbTetheringSelect.addEventListener('change', handleChange);
        elements.hotspotSettingsItem.addEventListener('click', handleEvent);

        //add begin by tailiangchen for defect-11084703
        if (operator === 'VZW') {
          ListFocusHelper.addEventListener(elements.items, updateSoftkeyshowPassword);
        } else {
          ListFocusHelper.addEventListener(elements.items);
        }
        //add end by tailiangchen for defect-11084703

        //ListFocusHelper.addEventListener(listElements);

      },

      onBeforeHide() {
        SettingsSoftkey.hide();
        SettingsDBCache.unobserve(DM_WIFI_UI, handleSettingsChange);
        SettingsDBCache.unobserve(DM_USB_UI, handleSettingsChange);
        SettingsDBCache.unobserve(HOTSPOT_WIFI_ENABLED, handleSettingsChange);
        SettingsDBCache.unobserve(HOTSPOT_USB_ENABLED, handleSettingsChange);

        SettingsDBCache.unobserve(WIFI_SSID_KEY, handleSettingsChange);
        SettingsDBCache.unobserve(WIFI_SECURITY_KEY, handleSettingsChange);
        SettingsDBCache.unobserve(WIFI_PASSWORD_KEY, handleSettingsChange);
        SettingsDBCache.unobserve(DATA_KEY, handleSettingsChange);
        SettingsDBCache.unobserve(WIFI_KEY, handleSettingsChange);
        SettingsDBCache.unobserve(WIFI_SAVED_KEY, false, handleSettingsChange);
        SettingsDBCache.unobserve(USB_STORAGE_KEY, handleSettingsChange);
        SettingsDBCache.unobserve(WIFI_BROADCAST_SSID_KEY, handleSettingsChange);
        //Defect-10582137 add-begin shangpeng.su@tcl.com 2020.12.25
        SettingsDBCache.unobserve(TETHERING_MHS_CHECK_INGORE, handleSettingsChange);
        //Defect-10582137 add-end shangpeng.su@tcl.com 2020.12.25
        //Defect-10648763 add-begin shangpeng.su 2021.01.14
        SettingsDBCache.unobserve(WIFI_SHOW_PASSWORD_KEY, handleSettingsChange);
        //Defect-10648763 add-end shangpeng.su 2021.01.14

        elements.wifiHotspotSelect.removeEventListener('change', handleChange);
        elements.usbTetheringSelect.removeEventListener('change', handleChange);
        elements.hotspotSettingsItem.removeEventListener('click', handleEvent);

        ListFocusHelper.removeEventListener(elements.items);//Defect10562667-bin.shen@tcl.com

        //ListFocusHelper.removeEventListener(listElements);
      },
      onUninit() {
        ApiManager.usbManager.onusbstatuschange = null;
        ApiManager.tetheringManager.ontetheringstatuschange = null;
      }
    });
  };
});
