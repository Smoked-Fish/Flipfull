/* global WifiHelper
* @module modules/wifi/wifi_utils
* Task-10296943 add shangpeng.su
* Defect-10627799 modify shangpeng.su 2021.03.09
*/
'use strict';
// eslint-disable-next-line
define(function(require) {
  const WifiUtils = require('modules/wifi/wifi_utils');
  const WifiContext = require('modules/wifi/wifi_context');
  const wifiManager = WifiHelper.getWifiManager();
  const SettingsPanel = require('modules/settings_panel');

  return function ctorHotspotBlockedDevices() {
    const HOTSPOT_WIFI_ENABLED = 'tethering.wifi.enabled';
    let elements = {};
    let listItems = [];
    let focusIndex = 0;
    let wifiHotspotEnabled = false;

    const onWifiHotspotHandler = function onWifiHotspotHandler(value) {
      if (value) {
        this.getBlockedDevices();
      } else {
        this.showNoBlockDevice();
        window.removeEventListener('keydown', handleKeydown);
      }
      wifiHotspotEnabled = value;
    };

    function onHotspotClientsChanged(event) {
      if (wifiHotspotEnabled) {
        this.getBlockedDevices();
      }
    }

    function refreshFocus(isDown) {
      if (listItems.length > 0) {
        listItems[focusIndex].classList.remove('focus');
        focusIndex = (isDown ? (focusIndex + 1) : (focusIndex  - 1));
        if (focusIndex === listItems.length) {
          focusIndex = 0;
        } else if (focusIndex === -1) {
          focusIndex = listItems.length - 1;
        }
        listItems[focusIndex].classList.add('focus');
        listItems[focusIndex].focus();
        listItems[focusIndex].scrollIntoView(false);
      }
    }

    function handleKeydown(e) {
      switch (e.key) {
        case 'BrowserBack':
        case 'Backspace':
        case 'KanjiMode':
          NavigationMap.navigateBack();
          window.removeEventListener('keydown', handleKeydown);
          break;
        case 'ArrowDown':
          refreshFocus(true);
          break;
        case 'ArrowUp':
          refreshFocus(false);
          break;
      }
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          panel,
          blockedDevicesListWrapper: panel.querySelector(
            '.hotspot-blockedDevices')
        };
        this.wifiHotspotHandler = onWifiHotspotHandler.bind(this);
        this.hotspotClientsChanged = onHotspotClientsChanged.bind(this);
      },

      onBeforeShow() {
        this.getBlockedDevices();
        this.initSoftKey();
        elements.blockedDevicesListWrapper.setAttribute('style','height:100%');    //fix by tailiangchen for defect 11295212
        SettingsDBCache.observe(
          HOTSPOT_WIFI_ENABLED, true, this.wifiHotspotHandler);
        WifiContext.addEventListener(
          'hotspotClientsChanged', this.hotspotClientsChanged);
        window.addEventListener('keydown', handleKeydown);
      },

      onBeforeHide() {
        SettingsDBCache.unobserve(
          HOTSPOT_WIFI_ENABLED, this.wifiHotspotHandler);
        window.removeEventListener('keydown', handleKeydown);
        WifiContext.removeEventListener(
          'hotspotClientsChanged', this.hotspotClientsChanged);
      },

      getBlockedDevices() {
        this.cleanup();
        const req = wifiManager.getBlockDeviceList();
        req.onsuccess = () => {
          const allMacs = req.result;
          if (allMacs.length == 0) {
            //show no blocked device
            this.showNoBlockDevice();
          } else {
            for (var i = 0; i < allMacs.length; i ++) {
              const aItem = WifiUtils.newHotspotListItem({
                client: { macAddress: allMacs[i] },
                showSsidAndIp: false
              });
              elements.blockedDevicesListWrapper.appendChild(aItem);
              listItems[i] = aItem;
            }
            this.initSoftKey();
            listItems[0].classList.add('focus');
            listItems[0].focus();
            listItems[0].scrollIntoView(false);
          }
        };
        req.onerror = () => {
          //show no blocked device
          this.showNoBlockDevice();
        };
      },

      cleanup() {
        const wrapper = elements.blockedDevicesListWrapper;
        while (wrapper.hasChildNodes()) {
          wrapper.removeChild(wrapper.firstChild);
        }
        listItems = [];
        focusIndex = 0;
      },

      showNoBlockDevice() {
        this.cleanup();
        const li = WifiUtils.newExplanationItem('noDeviceBlocked');
        li.classList.add('non-focus');
        elements.blockedDevicesListWrapper.appendChild(li);
        SettingsSoftkey.hide();
      },

      initSoftKey() {
        const softkeyParams = {
          menuClassName: 'menu-button',
          header: {
            l10nId: 'message'
          },
          items: [
            {
              name: 'unBlock',
              l10nId: 'unBlock',
              priority: 3,
              method: () => {
                this.showConfirmDialog();
              }
            }
          ]
        };
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
      },

      showConfirmDialog() {
        let dialog = null;
        let self = this;
        const dialogConfig = {
          title: {id: 'hotspot-block-confirmation-title', args: {}},
          body: {id: 'hotspot-unblock-confirmation-message', args: {}},
          cancel: {
            l10nId: 'cancel',
            priority: 1,
            callback() {
              if (dialog !== null) {
                dialog.destroy();
              }
            }
          },
          confirm: {
            l10nId: 'ok',
            priority: 3,
            callback() {
              const select = elements.panel.querySelector('.hotspot.focus a');
              const macAddress = select.parentNode.dataset.macAddress;
              //do unblock
              const unblock = wifiManager.unblockClient(macAddress);
              unblock.onsuccess = () => {
                self.getBlockedDevices();
              };
            }
          }
        };

        dialog = new ConfirmDialogHelper(dialogConfig);
        dialog.show(document.getElementById('app-confirmation-dialog'));
      }
    });
  };
});
