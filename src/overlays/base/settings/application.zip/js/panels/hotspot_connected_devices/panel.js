/* global WifiHelper
* @module modules/wifi/wifi_utils
* @module modules/wifi/wifi_context
* Task-10296943 add shangpeng.su
*/
'use strict';
// eslint-disable-next-line
define(function(require) {
  const WifiUtils = require('modules/wifi/wifi_utils');
  const wifiManager = WifiHelper.getWifiManager();
  const WifiContext = require('modules/wifi/wifi_context');
  const SettingsPanel = require('modules/settings_panel');

  return function ctorHotspotConnectedDevices() {
    const HOTSPOT_WIFI_ENABLED = 'tethering.wifi.enabled';
    let elements = {};
    let listItems = [];
    let hotspotEnabled = false;
    let focusIndex = 0;

    const onWifiHotspotHandler = function onWifiHotspotHandler(value) {
      hotspotEnabled = value;
      if (value) {
        this.getConnectedDevices();
      } else {
        this.showNoConnDevice();
        window.removeEventListener('keydown', handleKeydown);
      }
    };

    function onHotspotClientsChanged(event) {
      if (hotspotEnabled) {
        this.getConnectedDevices();
      } else {
        this.showNoConnDevice();
      }
    }

    function refreshFocus(isDown) {
      if (listItems.length > 0) {
        listItems[focusIndex].classList.remove('focus');
        focusIndex = (isDown ? (focusIndex + 1) : (focusIndex  - 1));
        if (focusIndex === listItems.length) {
          focusIndex = 0;
        } else if (focusIndex === -1) {
          focusIndex = listItems.length - 1;
        }
        listItems[focusIndex].classList.add('focus');
        listItems[focusIndex].focus();
        listItems[focusIndex].scrollIntoView(false);
      }
    }

    function handleKeydown(e) {
      switch (e.key) {
        case 'BrowserBack':
        case 'Backspace':
        case 'KanjiMode':
          NavigationMap.navigateBack();
          window.removeEventListener('keydown', handleKeydown);
          break;
        case 'ArrowDown':
          refreshFocus(true);
          break;
        case 'ArrowUp':
          refreshFocus(false);
          break;
      }
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          panel,
          connectedDevicesListWrapper: panel.querySelector(
            '.hotspot-connectedDevices')
        };
        this.wifiHotspotHandler = onWifiHotspotHandler.bind(this);
        this.hotspotClientsChanged = onHotspotClientsChanged.bind(this);
      },

      onBeforeShow() {
        this.getConnectedDevices();
        this.initSoftKey();
        elements.connectedDevicesListWrapper.setAttribute('style','height:100%');    //fix by tailiangchen for defect 11295212
        SettingsDBCache.observe(
          HOTSPOT_WIFI_ENABLED, true, this.wifiHotspotHandler);
        WifiContext.addEventListener(
          'hotspotClientsChanged', this.hotspotClientsChanged);
        window.addEventListener('keydown', handleKeydown);
      },

      onBeforeHide() {
        SettingsDBCache.unobserve(
          HOTSPOT_WIFI_ENABLED, this.wifiHotspotHandler);
        WifiContext.removeEventListener(
          'hotspotClientsChanged', this.hotspotClientsChanged);
        window.removeEventListener('keydown', handleKeydown);
      },

      getConnectedDevices() {
        this.cleanup();
        const req = wifiManager.getConnectedDeviceList();
        req.onsuccess = () => {
          const allMacs = req.result;
          if (allMacs.length == 0) {
            //show no connected device
            this.showNoConnDevice();
          } else {
            for (var i = 0; i < allMacs.length; i ++) {
              const aItem = WifiUtils.newHotspotListItem({
                client: { macAddress: allMacs[i] },
                showSsidAndIp: false
              });
              elements.connectedDevicesListWrapper.appendChild(aItem);
              listItems[i] = aItem;
            }
            this.initSoftKey();
            listItems[0].classList.add('focus');
            listItems[0].focus();
            listItems[0].scrollIntoView(false);
          }
        };
        req.onerror = () => {
          //show no connected device
          this.showNoConnDevice();
        };
      },

      cleanup() {
        const wrapper = elements.connectedDevicesListWrapper;
        while (wrapper.hasChildNodes()) {
          wrapper.removeChild(wrapper.firstChild);
        }
        listItems = [];
        focusIndex = 0;
      },

      showNoConnDevice() {
        console.log('showNoConnDevice!!!');
        this.cleanup();
        const li = WifiUtils.newExplanationItem('noDeviceConnected');
        li.classList.add('non-focus');
        elements.connectedDevicesListWrapper.appendChild(li);
        SettingsSoftkey.hide();
      },

      initSoftKey() {
        const softkeyParams = {
          menuClassName: 'menu-button',
          header: {
            l10nId: 'message'
          },
          items: [
            {
              name: 'Block',
              l10nId: 'block-vzw',  //fix by tailiangchen for defect 10627799
              priority: 3,
              method: () => {
                this.showConfirmDialog();
              }
            }
          ]
        };
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
      },

      showConfirmDialog() {
      //let dialog = null;
      let self = this;
      const config = {
        title: {id: 'hotspot-block-confirmation-title', args: {}},
        body: {id: 'hotspot-block-confirmation-message-vzw', args: {}},  //fix by tailiangchen for defect 10627799
        cancel: {
          l10nId: 'cancel',
          priority: 1,
          callback() {
            DialogHelper.destroy();
            //if (dialog !== null) {
            //  dialog.destroy();
            //}
          }
        },
        confirm: {
          l10nId: 'ok',
          priority: 3,
          callback() {
            const select = elements.panel.querySelector('.hotspot.focus a');
            const macAddress = select.parentNode.dataset.macAddress;
            //do block
            const block = wifiManager.blockClient(macAddress);
            block.onsuccess = () => {
              self.getConnectedDevices();
            };
          }
        }
      };

      //dialog = new ConfirmDialogHelper(dialogConfig);

      DialogHelper.show(config);
      //dialog.show(document.getElementById('app-confirmation-dialog'));
    }
    });
  };
});
