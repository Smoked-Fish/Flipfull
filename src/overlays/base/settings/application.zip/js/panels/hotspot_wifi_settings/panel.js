'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createHotspotSettings() {
    const WIFI_SSID_KEY = 'tethering.wifi.ssid';
    const WIFI_SECURITY_KEY = 'tethering.wifi.security.type';
    const WIFI_PASSWORD_KEY = 'tethering.wifi.security.password';
    //Task-10296941 add-begin shangpeng.su@tcl.com 2020.11.27
    const WIFI_MAX_NUM_STA = 'tethering.wifi.maxnumsta';
    //Task-10296941 add-end shangpeng.su@tcl.com 2020.11.27
    //add begin by tailiangchen for defect-10941270
    const WIFI_SHOW_PASSWORD_KEY = 'tethering.wifi.show.password';
    const WIFI_BROADCAST_SSID_KEY = 'tethering.wifi.broadcast.ssid';
    //add end by tailiangchen for defect-10941270
    const  WIFI_HOTSPOT_BAND_KEY = 'tethering.wifi.band';
    let elements = null;
    let hotspotSettings = null;
    let listElements = null;
    let operator = null;//Task-10198064 add shangpeng.su@tcl.com 2020.11.12
    //Defect-11098002 add-begin shangpeng.su 2021.05.12
    let supportShowPwdOperators = ['TMO', 'VZW', 'USCC', 'TF'];  //add by tailiangchen for jira GF7TF-3555
    //Defect-11098002 add-end shangpeng.su 2021.05.12

    // Validate all settings in the dialog box
    function saveHotspotSettings() {
      //Task-10683224 add-begin shangpeng.su 2021.01.26
      if (operator === 'TMO' && hotspotSettings.security === 'wpa2-psk' &&
        !hotspotSettings.password && hotspotSettings.firstSetPwdWithEnable) {
        console.log('susp_test, save the firstSethtospotPwd');
        hotspotSettings.firstSetPwdWithEnable = false;
        DeviceFeature.setLocalStorageItem('firstSetHotspotPwd', 'true');
      }
      //Task-10683224 add-end shangpeng.su 2021.01.26
      const cSet = {};
      cSet[WIFI_SSID_KEY] = elements.hotspotNameInput.value;
      cSet[WIFI_SECURITY_KEY] = elements.hotspotSecuritySelect.value;
      if (elements.hotspotSecuritySelect.value !== 'open') {
        cSet[WIFI_PASSWORD_KEY] = elements.hotspotPasswordInput.value;
      }
      cSet[WIFI_HOTSPOT_BAND_KEY] = elements.hotspotBandSelect.value;
      //add begin by tailiangchen for defect-10941270
      cSet[WIFI_SHOW_PASSWORD_KEY] = (elements.hotspotPasswordInput.type === 'text') ? true : false;
      cSet[WIFI_MAX_NUM_STA] = elements.maxNumStaSelector.value;
      cSet[WIFI_BROADCAST_SSID_KEY] = elements.broadcastSsidInput.checked;
      //add end by tailiangchen for defect-10941270
      //add by tailiangchen for jira GF5GTMO-8604
      cSet['apParamInit'] = true;
      //add end by tailiangchen for jira GF5GTMO-8604
      SettingsDBCache.saveSettings(cSet);
      NavigationMap.navigateBack();
    }

    function updateSoftkey() {
      const softParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [
          {
            name: 'Cancel',
            l10nId: 'cancel',
            priority: 1,
            method() {
              NavigationMap.navigateBack();
            }
          }
        ]
      };

      const focusElement = elements.panel.querySelector('.focus');
      //Defect-10616306 modify-begin shangpeng.su@tcl.com 2021.01.06
      const showSelectElements = [
        'hotspot-broadcast-ssid',
        'hotspot-security',
        'hotspot-max-num-sta',
        'hotspot-band'
      ];
      if (focusElement && showSelectElements.indexOf(focusElement.id) !== -1) {
        softParams.items.push({
          name: 'Select',
          l10nId: 'select',
          priority: 2,
          method() {
            DebugHelper.debug('SettingsSoftkey select');
          }
        });
        if (focusElement.id === 'hotspot-security') {
          if (elements.hotspotSecuritySelect.value !== 'open') {
            elements.hotspotPassword.classList.remove('hidden');
          } else {
            elements.hotspotPassword.classList.add('hidden');
          }
          window.dispatchEvent(new CustomEvent('refresh'));
          //add begin by tailiangchen for defect-10941270
        } else if (focusElement.id === 'hotspot-max-num-sta') {
          console.log("CTL text value slect: " + elements.maxNumStaSelector.value);
          hotspotSettings.maxstaNum = elements.maxNumStaSelector.value;
        } else if (focusElement.id === 'hotspot-band') {
          console.log("CTL test select ap band");
          hotspotSettings.hotspotBand = elements.hotspotBandSelect.value;
          window.dispatchEvent(new CustomEvent('refresh'));
        }
        //add end by tailiangchen for defect-10941270
      }
      //Defect-10616306 modify-end shangpeng.su@tcl.com 2021.01.06
      if (!isNotSubmitable()) {
        softParams.items.push({
          name: 'Save',
          l10nId: 'save',
          priority: 3,
          method() {
            saveHotspotSettings();
          }
        });
      }

      SettingsSoftkey.init(softParams);
      SettingsSoftkey.show();
    }

    //Task-10296941 add-begin shangpeng.su@tcl.com 2020.11.27
    function initMaxNumSta() {
      SettingsDBCache.getSetting(WIFI_MAX_NUM_STA).then(value => {
        let maxNumSta = value > 10 ? 10 : value;
        //Defect-10585653 modify-begin shangpeng.su 2020.12.28
        let needDeleteSelector = maxNumSta > 0 && maxNumSta <= 10;
        if (needDeleteSelector) {
          //Defect-10984738 modify-begin shangpeng.su 2021.04.07
          let defaultMax = localStorage.getItem('tethering.wifi.maxnumsta.default');
          if (defaultMax === 'false' || !defaultMax) {
            console.log('hotspotsettings, setlocalstorageitem defaultMax to ' + maxNumSta);
            defaultMax = maxNumSta;
            localStorage.setItem(
              'tethering.wifi.maxnumsta.default', maxNumSta);
          }
          //Defect-10984738 modify-end shangpeng.su 2021.04.07
          let options = elements.maxNumStaSelector.options;
          let length = options.length - parseInt(defaultMax);
          //Defect-10585653 modify-end shangpeng.su 2020.12.28
          for (let i = 0; i < length; i ++) {
            elements.maxNumStaSelector.remove(options.length - 1);
          }
        }

        SIMSlotManager.getSlots().forEach(SIMSlot => {
          let showMax = needDeleteSelector;
          if (!SIMSlot.isAbsent()) {
            let simCard = SIMSlot.simCard;
            let iccInfo = simCard ? simCard.iccInfo : null;
            if (iccInfo && iccInfo.mcc === '311' && iccInfo.mnc === '480'
                && iccInfo.gid1 === "BAE1000000000000"
                && iccInfo.gid2 === '1A00000000000000') {
              let cset = { WIFI_MAX_NUM_STA: 1 };
              SettingsDBCache.saveSettings(cset);
              showMax= false;
            }
          }
          if (!showMax && elements.maxNumStaSelector) {
            elements.maxNumStaSelector.parentNode.parentNode.remove();
          }
        });
      });
    }
    //Task-10296941 add-end shangpeng.su@tcl.com 2020.11.27

    //Task-10198064 add-begin shangpeng.su@tcl.com 2020.11.12
    function updatePasswordItemVisibilityForCustom(securityType) {
      if (securityType === 'open') {
        window.setTimeout(() => {
          showUnSecuredDialog(operator);
        }, 500);
      }
      //Defect-11098002 modify-begin shangpeng.su 2021.05.12
      //Defect-10879689 modify-begin shangpeng.su 2021.03.17
      //Defect-10651158 add-begin shangpeng.su 2021.01.13
      if (operator && (supportShowPwdOperators.indexOf(operator) !== -1)) {
      //Defect-11098002 modify-end shangpeng.su 2021.05.12
        if (securityType === 'open') {
          elements.showPasswordInput.parentNode.parentNode.classList.add('hidden');
        } else {
          elements.showPasswordInput.parentNode.parentNode.classList.remove('hidden');
          //add begin by tailiangchen for jira GF5GTMO-7417
          if (!hotspotSettings.password) {
            elements.hotspotPasswordInput.value = '';
          }
          //add end by tailiangchen for jira GF5GTMO-7417
          //fix begin by tailiangchen for defect-11216428
          elements.hotspotPasswordInput.type =
            hotspotSettings.showPassword ? 'text' : 'password';
          elements.showPasswordInput.checked = hotspotSettings.showPassword;
          //fix end by tailiangchen for defect-11216428
        }
        window.dispatchEvent(new CustomEvent('refresh'));
      }
      //Defect-10651158 add-end shangpeng.su 2021.01.13
      //Defect-10879689 modify-end shangpeng.su 2021.03.17
    }

    function showUnSecuredDialog(operator) {
      let bodyId = 'mobile_hotspot_unsecured_network_text_tmo';
      if (operator === 'VZW') {
        bodyId= 'mobile_hotspot_unsecured_network_text_vzw';
      }

      const dialogConfig = {
          title: {id: 'mobile_hotspot_unsecured_network_title', args: {}},
          body: {id: bodyId, args: {}},
          accept: {
            l10nId: 'ok',
            priority: 2,
            callback() {
              DialogHelper.destroy();
            }
          }
        };

        DialogHelper.show(dialogConfig);
    }

    //Defect-11103124 add-begin shangpeng.su 2021.05.13
    function showHideSsidWarningDialog() {
      const dialogConfig = {
        title: {id: 'broadcast-network-title-tmo', args: {}},
        body: {id: 'broadcast-network-content-tmo', args: {}},
        accept: {
          l10nId: 'ok',
          priority: 2,
          callback() {
            DialogHelper.destroy();
          }
        }
      }
      DialogHelper.show(dialogConfig);
    }
    //Defect-11103124 add-end shangpeng.su 2021.05.13

    function handleSecurityTypeChanged(evt) {
      updateSoftkey();
      updatePasswordItemVisibilityForCustom(evt.target.value);
    }
    //Task-10198064 add-end shangpeng.su@tcl.com 2020.11.12

    function handleBandChanged(evt){
      updateSoftkey();
    }

    //Defect-10879689 modify-begin shangpeng.su 2021.03.17
    //Task-10231611 add-begin shangpeng.su@tcl.com 2020.11.20
    function initShowPasspowrd(operator) {
      //Defect-11098002 modify-begin shangpeng.su 2021.05.12
      if (operator && (supportShowPwdOperators.indexOf(operator) !== -1)) {
      //Defect-11098002 modify-end shangpeng.su 2021.05.12
        elements.showPasswordInput.parentNode.parentNode.classList.remove('hidden');
        //Defect-10649544 delete-begin shangpeng.su 2021.01.13
        //elements.showPasswordInput.checked = false;
        //elements.hotspotPasswordInput.type = 'password';
        //Defect-10649544 delete-end shangpeng.su 2021.01.13
        elements.showPasswordInput.onchange = function() {
          elements.hotspotPasswordInput.type = this.checked ? 'text' : 'password';
        };
      } else {
        elements.showPasswordInput.parentNode.parentNode.classList.add('hidden');
      }
    }
    //Task-10231611 add-end shangpeng.su@tcl.com 2020.11.20
    //Defect-10879689 modify-end shangpeng.su 2021.03.17

    //Defect-11024565 add-begin shangpeng.su 2021.04.20
    function onSSIDchange(event) {
      /*
       * During composition, we should not change the input
       * value. Otherwise, the input value will be cleared unexpectedly.
       * Besides, it seems unnecessary to change input value before
       * composition is committed.
       */
      if (event.isComposing) {
        return;
      }
      // Make sure ssid length is no more than 32 bytes.
      let str = elements.hotspotNameInput.value;
      /*
       * Non-ASCII chars in SSID will be encoded by UTF-8, and length of
       * each char might be longer than 1 byte.
       * Use encodeURIComponent() to encode ssid, then calculate correct
       * length.
       */
      const encoder = new TextEncoder('utf-8');
      while (encoder.encode(str).length > 32) {
        str = str.substring(0, str.length - 1);
      }
      if (str !== elements.hotspotNameInput.value) {
        elements.hotspotNameInput.value = str;
      }

      updateSoftkey();
    }
    //Defect-11024565 add-end shangpeng.su 2021.04.20


    function isNotSubmitable() {
      const securityType = elements.hotspotSecuritySelect.value;
      const ssidNameLength = elements.hotspotNameInput.value.length;
      const pwdLength = elements.hotspotPasswordInput.value.length;
      return (
        (pwdLength < 8 ||
          pwdLength > 63 ||
          ssidNameLength === 0 ||
          ssidNameLength > 32) &&
        securityType !== 'open'
      );
    }


    function keyDownHandler(evt) {
      switch (evt.key) {
        case 'Enter':
          const focusElement = elements.panel.querySelector('.focus');
          if ((focusElement.id === 'hotspot-name') || (focusElement.id === 'hotspot-password')) {
            evt.preventDefault();
            evt.stopPropagation();
          }
          break;
        default:
          break;
      }
    }
    //add end by tailiangchen for defect-11300129

    /*function handleEvent(evt) {     remove for not abort keyevent
      if (evt.key === 'Enter') {
        const focusElement = elements.panel.querySelector('.focus');
        if (focusElement && (focusElement.id === 'hotspot-security' ||
          focusElement.id === 'hotspot-band')) {
          return;
        }
        evt.stopPropagation();
        evt.preventDefault();
      }
    }*/

    return SettingsPanel({
      onInit(panel) {
        elements = {
          panel,
          hotspotName: panel.querySelector('#hotspot-name'),
          hotspotNameInput: panel.querySelector('#hotspot-name input'),
          hotspotSecurity: panel.querySelector('#hotspot-security'),
          hotspotSecuritySelect: panel.querySelector(
            '#hotspot-security select'
          ),
          hotspotPassword: panel.querySelector('#hotspot-password'),
          hotspotPasswordInput: panel.querySelector('#hotspot-password input'),
          showPasswordInput: panel.querySelector('input[name=show-pwd]'),
          broadcastSsidInput: panel.querySelector('input[name=broadcast-ssid]'),
          maxNumStaSelector: panel.querySelector('#max-num-sta-select'),
          hotspotSettingsHeader: panel.querySelector('h1'), //add begin by tailiangchen for defect-10878572
          hotspotBand: panel.querySelector('#hotspot-band'),
          hotspotBandSelect: panel.querySelector('#hotspot-band-select')
        };

        //add begin by tailiangchen for defect-10941270
        elements.showPasswordInput.setAttribute('data-name','');
        elements.maxNumStaSelector.setAttribute('data-name','');
        elements.broadcastSsidInput.setAttribute('data-name','');
        //add end by tailiangchen for defect-10941270
        listElements = panel.querySelectorAll('li');
        initMaxNumSta();//Task-10296941 add shangpeng.su@tcl.com 2020.11.27

        //Task-10198064 add-begin shangpeng.su@tcl.com 2020.11.12
        if (navigator.b2g.engmodeManager) {
          navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name')
            .then(value => {
              operator = value;
              initShowPasspowrd(operator);//Task-10231611 add shangpeng.su@tcl.com 2020.11.20
            });
        }
        //Task-10198064 add-end shangpeng.su@tcl.com 2020.11.12

        //add end by tailiangchen for defect-10878572
        if(operator === 'VZW'){
          elements.hotspotSettingsHeader.setAttribute('data-l10n-id','hotspotSettings-header-vzw');
        }
        //add end by tailiangchen for defect-10878572
      },

      onBeforeShow(panel, options) {
        hotspotSettings = options.settings || hotspotSettings;
        elements.hotspotNameInput.value = hotspotSettings.ssid;
        elements.hotspotPasswordInput.value = hotspotSettings.password;
        //Defect-10648763 add-begin shangpeng.su 2021.01.14
        elements.showPasswordInput.checked = hotspotSettings.showPassword;
        //Defect-10648763 add-end shangpeng.su 2021.01.14

        //add end by tailiangchen for defect-10878572
        if(operator === 'VZW'){
          elements.hotspotSettingsHeader.setAttribute('data-l10n-id','hotspotSettings-header-vzw');
        }
        //add end by tailiangchen for defect-10878572
        //add begin by tailiangchen for defect-10941270
        SettingsDBCache.getSetting(WIFI_BROADCAST_SSID_KEY).then(value => {
          elements.broadcastSsidInput.checked = value;
        });
        //add end by tailiangchen for defect-10941270
        if (hotspotSettings.security === 'open') {
          elements.hotspotPassword.classList.add('hidden');
          //fix by tailiangchen for defect-11216428
          elements.showPasswordInput.parentNode.parentNode.classList.add('hidden');
        } else {
          //Defect-11098002 modify-begin shangpeng.su 2021.05.13
          //Defect-10665819 add-begin shangpeng.su 2021.01.20
          if (
            (operator === 'TMO' || operator === 'USCC') &&
            hotspotSettings.security === 'wpa2-psk'
          ) {
          //Defect-11098002 modify-end shangpeng.su 2021.05.13
            if (!hotspotSettings.password) {
              elements.hotspotPasswordInput.value = '';
            } else {
              elements.hotspotPasswordInput.type =
                hotspotSettings.showPassword ? 'text' : 'password';
            }
            ListFocusHelper.requestFocus(panel, elements.hotspotPassword);
          }
          //Defect-10665819 add-end shangpeng.su 2021.01.20
          elements.hotspotPassword.classList.remove('hidden');
          //Defect-10879689 add-begin shangpeng.su 2021.03.17
          if (operator === 'VZW' || operator === 'TF') {  //add by tailiangchen for jira GF7TF-3555
            elements.hotspotPasswordInput.type =
              hotspotSettings.showPassword ? 'text' : 'password';
          }
          //Defect-10879689 add-end shangpeng.su 2021.03.17
        }
        const option = `option[value="${hotspotSettings.security}"]`;
        const selectOption = elements.hotspotSecuritySelect.querySelector(
          option
        );
        if (selectOption) {
          selectOption.selected = true;
        }
        //add begin by tailiangchen for defect-10941270
        SettingsDBCache.getSetting(WIFI_MAX_NUM_STA).then(value => {
          hotspotSettings.maxstaNum = value;
          const maxstaoption = `option[value="${hotspotSettings.maxstaNum}"]`;
          const maxstaselectOption = elements.maxNumStaSelector.querySelector(maxstaoption);
          if(maxstaselectOption){
            maxstaselectOption.selected = true;
          }
        });
        //add end by tailiangchen for defect-10941270
          SettingsDBCache.getSetting(WIFI_HOTSPOT_BAND_KEY).then(value => {
            hotspotSettings.hotspotBand = value;
            const apbandoption = `option[value="${hotspotSettings.hotspotBand}"]`;
            const apbandselectopton = elements.hotspotBandSelect.querySelector(apbandoption);
            if (apbandselectopton) {
              apbandselectopton.selected = true;
            }
          })

        elements.hotspotNameInput.addEventListener('input', onSSIDchange);
        elements.hotspotPasswordInput.addEventListener('input', updateSoftkey);
        elements.hotspotSecuritySelect.addEventListener(
          'change',
          handleSecurityTypeChanged
        );
        elements.hotspotBandSelect.addEventListener('change', handleBandChanged);
        window.addEventListener('keydown', keyDownHandler, true);    //add by tailiangchen for defect-11300129
        //Defect-11103124 add-begin shangpeng.su 2021.05.13
        if (operator === 'TMO' || operator === 'USCC') {
          elements.broadcastSsidInput.onchange = function () {
            if (!elements.broadcastSsidInput.checked) {
              showHideSsidWarningDialog();
            }
          };
        }
        //Defect-11103124 add-begin shangpeng.su 2021.05.13
        ListFocusHelper.addEventListener(listElements, updateSoftkey);
        updateSoftkey();
        //window.addEventListener('keydown', handleEvent, true);  remove for not abort keyevent
      },

      onBeforeHide() {
        elements.hotspotNameInput.removeEventListener('input', onSSIDchange);
        elements.hotspotPasswordInput.removeEventListener(
          'input',
          updateSoftkey
        );

        elements.hotspotSecuritySelect.removeEventListener(
          'change',
          handleSecurityTypeChanged
        );
        elements.hotspotBandSelect.removeEventListener('change', handleBandChanged);

        ListFocusHelper.removeEventListener(listElements, updateSoftkey);

        window.removeEventListener('keydown', keyDownHandler, true);    //add by tailiangchen for defect-11300129
        //window.removeEventListener('keydown', handleEvent, true);  remove for not abort keyevent

      }
    });
  };
});
