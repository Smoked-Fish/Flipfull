/* global KeypadHelper */
'use strict';

// eslint-disable-next-line
define(function(require) {
  const SettingsPanel = require('modules/settings_panel');

  return function keypadPanel() {
    const keypadHelper = new KeypadHelper();
    let elements = null;
    let currentLayouts = null;
    let languagesCount = 1;

    // To show current enabled input language's name.
    function updateLanguageState(layouts) {
      const selectedLanguages = [];
      const listFragment = document.createDocumentFragment();
      let number = 0;

      // eslint-disable-next-line
      for (let key in layouts) {
        if (!layouts[key]) {
          continue;
        }
        const languageName = keypadHelper.getDisplayLanguageName(key);
        const li = genIMEItemTemplate({
          name: languageName
        });
        li.onclick = () => {
          Settings.setCurrentPanel('input_method_config', {
            Key: key,
            KeypadHelper: keypadHelper
          });
        };
        listFragment.appendChild(li);
        selectedLanguages.push(languageName);
        number++;
      }
      elements.inputMethodManager.innerHTML = '';
      elements.inputMethodManager.appendChild(listFragment);
      currentLayouts = layouts;

      const selectedLanguagesSmall = document.getElementById(
        'input-languages-desc'
      );
      selectedLanguagesSmall.textContent = '';
      languagesCount = number;
      if (number <= 3) {
        selectedLanguagesSmall.textContent = selectedLanguages.join(', ');
      } else {
        l10n.setAttributes(selectedLanguagesSmall, 'languages-selected', {
          n: number
        });
      }
      if (number > 1) {
        elements.inputLanguagesWarning.classList.remove('hidden');
      } else {
        elements.inputLanguagesWarning.classList.add('hidden');
      }
      window.dispatchEvent(new CustomEvent('refresh'));
    }

    function genIMEItemTemplate(itemData) {
      const item = document.createElement('li');
      const link = document.createElement('a');
      const span = document.createElement('span');
      span.textContent = itemData.name;
      link.classList.add('menu-item');
      link.appendChild(span);
      item.appendChild(link);
      return item;
    }

    return SettingsPanel({
      onInit: function onInit(panel) {
        elements = {
          inputMethodManager: panel.querySelector('.input-methods-manager'),
          inputLanguagesButton: panel.querySelector('#input-languages'),
          inputLanguagesInput: panel.querySelector('#input-languages-input'),
          inputLanguagesWarning: panel.querySelector(
            '#input-languages-warning'
          ),
          howToType: panel.querySelector('#how-to-type'),
          howToTypeInput: panel.querySelector('#how-to-type-input'),
          howToCopyPaste: panel.querySelector('#how-to-copy-paste')
        };

        keypadHelper.start();
        keypadHelper.getLayouts().then(layouts => {
          updateLanguageState(layouts);
          currentLayouts = layouts;

          elements.inputLanguagesButton.onclick = () => {
            Settings.setCurrentPanel('input_languages_selection', {
              KeypadHelper: keypadHelper,
              Layouts: currentLayouts
            });
          };
        });

        elements.howToType.onclick = evt => {
          evt.stopPropagation();
          elements.howToTypeInput.focus();
        };

        elements.howToTypeInput.oninput = evt => {
          const inputString = evt.target.value;
          if (inputString === 'tutorialDone') {
            evt.target.value = '';
            elements.howToType.focus();
          }
        };

        elements.howToCopyPaste.onclick = evt => {
          evt.stopPropagation();
          ActivityHelper.start({ name: 'show-copyPaste-guide' });
        };
      },

      onBeforeShow: function onBeforeShow() {
        keypadHelper.setLayoutsChangedCallback(updateLanguageState);
        SettingsSoftkey.init(SoftParams.defaultSelect);
        SettingsSoftkey.show();
      },

      onShow() {
        if (Settings.isBackHref && languagesCount > 1) {
          const boolValue =
            DeviceFeature.getValue('firstInputTutorial') || 'true';
          if (boolValue === 'true') {
            elements.inputLanguagesInput.focus();
            elements.inputLanguagesInput.oninput = evt => {
              const inputString = evt.target.value;
              if (inputString === 'tutorialDone') {
                elements.inputLanguagesInput.oninput = null;
                DeviceFeature.setLocalStorageItem(
                  'firstInputTutorial',
                  'false'
                );
                elements.inputLanguagesButton.focus();
              }
            };
          }
        }
      }
    });
  };
});
