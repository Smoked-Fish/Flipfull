'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createKaiosAccountAboutPanel() {
    function initSoftKey() {
      const softkeyParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [
          {
            name: 'Ok',
            l10nId: 'ok',
            priority: 2,
            method() {
              NavigationMap.navigateBack();
            }
          }
        ]
      };
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    return SettingsPanel({
      onInit() {
        SettingsDBCache.getSetting('kaiaccount.openflow.default').then(
          result => {
            if (result === 'phone') {
              const description = document.getElementById(
                'account_more_description'
              );
              description.setAttribute('data-l10n-id', 'overview-account');
            }
          }
        );
      },

      onBeforeShow() {
        initSoftKey();
      },

      onBeforeHide() {
        SettingsSoftkey.hide();
      }
    });
  };
});
