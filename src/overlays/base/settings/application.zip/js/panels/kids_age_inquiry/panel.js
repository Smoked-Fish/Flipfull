'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  let elements = null;
  return function kidsAgeInquiryPanel() {
    const softkeyParams = {
      items: [
        {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          method() {
            elements.prompt.classList.add('hidden');
            elements.ageInquiry.classList.remove('hidden');
            elements.overLi.classList.add('focus');
            elements.overLi.focus();
            updateSoftkey();
          }
        }, {
          name: 'Next',
          l10nId: 'next',
          priority: 3,
          method() {
            disableKidsMode();
          }
        }
      ]
    };

    function updateSoftkey() {
      if (elements.prompt.classList.contains('hidden')) {
        SettingsSoftkey.init(SoftParams.defaultSelect);
      } else {
        SettingsSoftkey.init(softkeyParams);
      }
      SettingsSoftkey.show();
    }

    function disableKidsMode() {
      const cSet = {};
      cSet['kids.mode.enabled'] = false;
      SettingsDBCache.saveSettings(cSet);
      if (ActivityHandler.currentActivity) {
        ActivityHandler.postResult();
      }
    }

    function keyDownHandler(evt) {
      if (!elements.prompt.classList.contains('hidden')) {
        if ('Backspace' === evt.key) {
          elements.ageInquiry.classList.remove('hidden');
          elements.prompt.classList.add('hidden');
          elements.overLi.classList.add('focus');
          elements.overLi.focus();
          updateSoftkey();
        }
        if (evt.key !== 'ArrowUp' && evt.key !== 'ArrowDown') {
          evt.preventDefault();
          evt.stopPropagation();
        }
      }
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          over: panel.querySelector('.over'),
          less: panel.querySelector('.less'),
          prompt: panel.querySelector('.prompt'),
          promptContent: panel.querySelector('.prompt-content'),
          ageInquiry: panel.querySelector('#age-inquiry'),
          overLi: panel.querySelector('#li-over')
        };
        elements.over.checked = false;
        elements.less.checked = false;
        elements.over.onclick = () => {
          elements.over.checked = false;
          elements.overLi.classList.remove('focus');
          elements.ageInquiry.classList.add('hidden');
          elements.prompt.classList.remove('hidden');
          updateSoftkey();
          setTimeout(() => {
            elements.promptContent.focus();
          });
        };
        elements.less.onclick = () => {
          elements.less.checked = false;
          Settings.setCurrentPanel('#kids_restrictions');
        };
        SettingsDBCache.getSetting('kids.mode.enabled').then(value => {
          if (!!value && ActivityHandler.currentActivity) {
            ActivityHandler.postResult();
          }
        });
        elements.overLi.onfocus = () => {
          setTimeout(() => {
            elements.overLi.removeAttribute('aria-labelledby');
          });
          elements.overLi.onfocus = null;
        };
      },
      onBeforeShow() {
        updateSoftkey();
        window.addEventListener('keydown', keyDownHandler, true);
      },
      onBeforeHide() {
        window.removeEventListener('keydown', keyDownHandler, true);
        SettingsSoftkey.hide();
      }
    });
  };
});
