'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  let elements = null;
  const PASS_LOCK_CODE = 'kids.passcode-lock.code';
  const KIDS_MODE_KEY = 'kids.mode.enabled';
  return function kidsModePanel() {
    let passcode = '';
    function enableKidsMode(enabled) {
      const cSet = {};
      cSet['kids.mode.enabled'] = enabled;
      SettingsDBCache.saveSettings(cSet);
      ToastHelper.showToast(enabled ? 'kids-mode-activated': 'kids-mode-deactivated');
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          modeOn: panel.querySelector('.mode-on'),
          modeOff: panel.querySelector('.mode-off'),
          changePasscode: panel.querySelector('#change-passcode'),
          description: panel.querySelector('#kids-mode-description')
        };
        elements.modeOn.onclick = () => {
          if (elements.modeOff.checked) {
            if (passcode === '') {
              Settings.setCurrentPanel('#kids_restrictions');
              elements.modeOn.checked = false;
            } else {
              enableKidsMode(true);
            }
          }
        };
        elements.modeOff.onclick = () => {
          if (elements.modeOn.checked) {
            enableKidsMode(false);
          }
        };
        elements.changePasscode.onclick = () => {
          Settings.setCurrentPanel('#kids_passcode', {
            mode: 'new'
          });
        };
        SettingsDBCache.observe(PASS_LOCK_CODE, '', value => {
          passcode = value;
          elements.changePasscode.classList.toggle('hidden', value === '');
        });
        SettingsDBCache.observe(KIDS_MODE_KEY, false, value => {
          elements.modeOff.checked = !value;
          elements.modeOn.checked = value;
          elements.description.classList.toggle('hidden', !value);
        });
      },
      onBeforeShow() {
        SettingsSoftkey.init(SoftParams.defaultSelect);
        SettingsSoftkey.show();
      },
      onBeforeHide() {
        SettingsSoftkey.hide();
      }
    });
  };
});
