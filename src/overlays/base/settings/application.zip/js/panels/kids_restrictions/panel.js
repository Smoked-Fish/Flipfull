'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function kidsRestrictionsPanel() {
    let elements = null;
    let currentStage = 1;
    const ids = [
      {
        header: 'setup-required-header',
        content: 'setup-required-content'
      }, {
        header: 'confirmation-required-header',
        content: 'confirmation-required-content'
      },{
        header: 'not-finished-header',
        content: 'not-finished-content'
      }
    ];
    const softkeyParams = [
      { // For stage 0
        items: [
          {
            name: 'Discard',
            l10nId: 'discard',
            priority: 1,
            method() {
              NavigationMap.navigateBack();
            }
          }, {
            name: 'Continue',
            l10nId: 'continue',
            priority: 3,
            method() {
              updateScreen(++currentStage);
            }
          }
        ]
      }, { // For stage 1
        items: [
          {
            name: 'OK',
            l10nId: 'ok',
            priority: 2,
            method() {
              updateScreen(++currentStage);
            }
          }
        ]
      },  { // For stage 2
        items: [
          {
            name: 'Cancel',
            l10nId: 'cancel',
            priority: 1,
            method() {
              updateScreen(--currentStage);
            }
          }, {
            name: 'Proceed',
            l10nId: 'proceed',
            priority: 3,
            method() {
              updateScreen(++currentStage);
            }
          }
        ]
      }, { // For stage 3
        items: [
          {
            name: 'Cancel',
            l10nId: 'cancel',
            priority: 1,
            method() {
              currentStage = 1;
              updateScreen(currentStage);
            }
          }, {
            name: 'Confirm',
            l10nId: 'confirm',
            priority: 3,
            method() {
              currentStage = 1;
              NavigationMap.isBackHref = true;
              Settings.setCurrentPanel('#kids_passcode', { mode: 'create' });
            }
          }
        ]
      }, { // For stage 1 activity
        items: [
          {
            name: 'Next',
            l10nId: 'next',
            priority: 3,
            method() {
              updateScreen(++currentStage);
            }
          }
        ]
      }
    ];

    function updateScreen(stage) {
      if (stage < 0 || stage > 3) {
        return;
      }
      if (stage === 2 || stage === 3) {
        elements.promptHeader.textContent= l10n.get(ids[stage - 2].header);
        elements.promptContent.textContent = l10n.get(ids[stage - 2].content);
      } else if (stage === 0) {
        elements.promptHeader.textContent = l10n.get(ids[2].header);
        elements.promptContent.textContent = l10n.get(ids[2].content);
      }
      elements.prompt.classList.toggle('hidden', stage === 1);
      if (stage === 1) {
        elements.prompt.classList.add('hidden');
        elements.restrictions.focus();
      } else {
        elements.prompt.classList.remove('hidden');
        elements.promptContent.focus();
      }
      if (stage === 1 && ActivityHandler.currentActivity) {
        SettingsSoftkey.init(softkeyParams[4]);
      } else {
        SettingsSoftkey.init(softkeyParams[stage]);
      }
      SettingsSoftkey.show();
    }

    function keyDownHandler(evt) {
      switch (evt.key) {
        case 'Backspace':
          if (currentStage === 1) {
            if (ActivityHandler.currentActivity) {
              NavigationMap.isBackHref = true;
              Settings.setCurrentPanel('#kids_age_inquiry');
            } else {
              currentStage = 0;
            }
          } else {
            currentStage = 1;
          }
          updateScreen(currentStage);
          evt.preventDefault();
          evt.stopPropagation();
          break;
        default:
          break;
      }
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          prompt: panel.querySelector('.prompt'),
          promptHeader: panel.querySelector('.prompt-header'),
          promptContent: panel.querySelector('.prompt-content'),
          restrictions: panel.querySelector('#restrictions')
        };
        currentStage = 1;
        updateScreen(currentStage);
      },
      onBeforeShow() {
        window.addEventListener('keydown', keyDownHandler, true);
        updateScreen(currentStage);
      },
      onBeforeHide() {
        window.removeEventListener('keydown', keyDownHandler, true);
        SettingsSoftkey.hide();
      }
    });
  };
});
