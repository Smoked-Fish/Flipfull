define(['require','modules/settings_panel','modules/settings_service'],function(require) {
  'use strict';
  var SettingsPanel = require('modules/settings_panel');
  var SettingsService = require('modules/settings_service');

  return function about_source_code_panel() {
    const listElements = document.querySelectorAll('#more_regulatory_safety li');
    // var _iframe;
    var softkeyParams = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [{
        name: 'Select',
        l10nId: 'select',
        priority: 2,
        method: function() {}
      }]
    };

    var softkeyParamsNone = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [{
        name: '',
        l10nId: '',
        priority: 2,
        method: function() {}
      }]
    };

    function initSoftkey() {
      const params = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [
          {
            name: 'Select',
            l10nId: 'select',
            priority: 2
          }
        ]
      };

      SettingsSoftkey.init(params);
      SettingsSoftkey.show();
    }


    function _initAllEventListener() {
      var i = listElements.length - 1;
      for (i; i >= 0; i--) {
        // if(listElements.item(j).className !== "noDisplay"){
        listElements.item(i).addEventListener('focus', _updateSoftKey)
        // }

      }
    }

    function _removeAllEventListener() {
      var j = listElements.length - 1;
      for (j; j >= 0; j--) {
        // if (listElements.item(j).className === "noDisplay") {
        listElements.item(j).removeEventListener('focus', _updateSoftKey)
        // }else {
        //   listElements.item(j).addEventListener('focus', _updateSoftKey)
        // }
      }

    }
    function _updateSoftKey(evt) {
      var position = evt.target.className.indexOf('noDisplay');


      console.log(`chaozhongwang  position:${evt.target.className}`);
      console.log(`chaozhongwang  position:${position}`);
      console.log(`chaozhongwang  //////////////////////////////////////////////////`);
      if (position === -1) {
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
      } else {
        SettingsSoftkey.init(softkeyParamsNone);
        SettingsSoftkey.hide();
      }
    }

    function _initIframe() {
      _iframe.focus();
      _iframe.contentDocument.addEventListener('keydown', evt => {
        switch (evt.key) {
          // case 'Enter':
          case 'Backspace':
            SettingsService.navigate('regulatory_safety');
            evt.preventDefault();
            break;
        }
      });
      _iframe.contentDocument.dir = window.document.dir;
    }

    // function _initSoftKey() {
    //   var focusInput = elements.panel.querySelector('input:focus');
    //   var inputValue = focusInput.value;
    //     var softkeyParams = {
    //         menuClassName: 'menu-button',
    //         header: {
    //             l10nId: 'message'
    //         },
    //         items: [{
    //             name: 'select',
    //             l10nId: 'select',
    //             priority: 2,
    //             method: function() {
    //               // SettingsService.navigate('regulatory_safety');
    //             }
    //         }]
    //     };
    //     SettingsSoftkey.init(softkeyParams);
    //     SettingsSoftkey.show();
    // }

    return SettingsPanel({
      onInit: function(panel) {
        // _iframe = document.getElementById('more_regulatory_safety');

        navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name').then((operatorNameValue) => {
          if(operatorNameValue !== 'EE'){
            console.log(`is EE`);
            document.getElementById('ce_only_icon').style.display = 'none';
            document.getElementById('ce_only_icon').classList.add('hidden')
          }

        });

      },

      onBeforeShow: function() {
        _initAllEventListener();
        initSoftkey()
        ListFocusHelper.addEventListener(listElements);
        // window.addEventListener('panelready', _initIframe);
      },

      onBeforeHide: function() {
        // SettingsSoftkey.hide();
        // ListFocusHelper.removeEventListener(listElements);
        _removeAllEventListener()
        // window.removeEventListener('panelready', _initIframe);
      }
    });
  };
});
