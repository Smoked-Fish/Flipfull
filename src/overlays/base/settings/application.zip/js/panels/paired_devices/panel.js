/* global BTConnectionManager, BluetoothContext */
'use strict';
define(function(require) {  //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createPairedDevicePanel() {
    const DEVICE_TYPES = [
      'audio-card',
      'input-keyboard',
      'audio-input-microphone'
    ];
    let elements = null;
    let connectingEnabled = false;
    const forgetParams = {
      items: [
        {
          l10nId: 'device-option-unpair',
          priority: 3,
          method: () => {
            showUnpairDialog();
          }
        }
      ]
    };

    const selectAndForgetParams = {
      items: [
        {
          name: 'Select',
          l10nId: 'select',
          priority: 2,
          method() {
            if (connectingEnabled) {
              return;
            }
            connectingEnabled = true;
            handleSelect();
          }
        },
        {
          l10nId: 'device-option-unpair',
          priority: 3,
          method() {
            showUnpairDialog();
          }
        }
      ]
    };

    function comfirmToUnpair(deviceItem) {
      BluetoothContext.pairDevice(false, deviceItem.address).then(result => {
        if (result) {
          ToastHelper.showToast('paried-device-forgotten');
        }
      });
    }

    function showUnpairDialog() {
      const deviceItem = elements.panel.querySelector('li.focus').device;
      const title = 'device-option-unpair-confirmation';
      const msg = 'device-option-unpair-device';
      const dialogConfig = {
        title: { id: title, args: {} },
        body: { id: msg, args: { deviceName: deviceItem.name } },
        cancel: {
          l10nId: 'cancel',
          priority: 1,
          callback() {
            // Do nothing
          }
        },
        confirm: {
          l10nId: 'device-option-unpair',
          priority: 3,
          callback: () => {
            comfirmToUnpair(deviceItem);
          }
        }
      };
      DialogHelper.show(dialogConfig);
    }

    function createDeviceItem(device) {
      const nameElement = document.createElement('span');
      nameElement.textContent =
        device.name !== '' ? device.name : device.address;
      nameElement.classList.add('no-wrap');

      const li = document.createElement('li');
      const anchor = document.createElement('a');
      li.classList.add('bluetooth-device');
      const type = device.type === '' ? 'unknown' : `${device.type}`;
      anchor.appendChild(nameElement);
      if (DEVICE_TYPES.indexOf(type) > -1) {
        const descSmall = document.createElement('small');
        if (device.connectionStatus === 'connected') {
          descSmall.setAttribute(
            'data-l10n-id',
            'device-status-tap-disconnect'
          );
        } else {
          descSmall.setAttribute('data-l10n-id', 'device-status-tap-connect');
        }
        descSmall.classList.add('no-wrap');
        anchor.appendChild(descSmall);
      }

      li.classList.add(`bluetooth-type-${type}`);
      li.device = device;
      li.appendChild(anchor);
      return li;
    }

    function updatePairedDesc() {
      const { numberOfPairedDevices } = BluetoothContext.info;
      if (numberOfPairedDevices === 0) {
        SettingsSoftkey.hide();
        elements.noPairedDesc.classList.remove('hidden');
        elements.pairedDevicesList.classList.add('hidden');
      } else {
        elements.pairedDevicesList.innerHTML = '';
        BluetoothContext.getPairedDevices().forEach(device => {
          const li = createDeviceItem(device);
          elements.pairedDevicesList.appendChild(li);
        });
        elements.noPairedDesc.classList.add('hidden');
        elements.pairedDevicesList.classList.remove('hidden');
        window.dispatchEvent(new CustomEvent('refresh'));
      }
    }

    function focusChanged(evt) {
      const focusItem = evt.detail.focusedElement;
      if (!focusItem.classList.contains('bluetooth-device')) {
        SettingsSoftkey.hide();
        return;
      }

      if (DEVICE_TYPES.indexOf(focusItem.device.type) > -1) {
        SettingsSoftkey.init(selectAndForgetParams);
        SettingsSoftkey.show();
      } else {
        SettingsSoftkey.init(forgetParams);
        SettingsSoftkey.show();
      }
    }

    function handleSelect() {
      const focusItem = document.querySelector('.focus');
      const { device } = focusItem;
      const descSmall = focusItem.querySelector('small');
      if (device.connectionStatus === 'connected') {
        BTConnectionManager.connectDevice(false, device).then(result => {
          connectingEnabled = false;
          if (result) {
            focusItem.device.connectionStatus = 'disconnected';
            descSmall.setAttribute('data-l10n-id', 'device-status-tap-connect');
            ToastHelper.showToast('success-disconnected-toast');
          } else {
            ToastHelper.showToast('error-disconnect-toast');
          }
        });
      } else if (device.connectionStatus === 'disconnected') {
        focusItem.setAttribute('aria-disabled', true);
        descSmall.setAttribute('data-l10n-id', 'device-status-connecting');
        BTConnectionManager.connectDevice(true, device).then(result => {
          connectingEnabled = false;
          if (result) {
            focusItem.device.connectionStatus = 'connected';
            descSmall.setAttribute(
              'data-l10n-id',
              'device-status-tap-disconnect'
            );
            focusItem.removeAttribute('aria-disabled');
            ToastHelper.showToast('success-connect-toast', {
              deviceName: device.name
            });
          } else {
            descSmall.setAttribute('data-l10n-id', 'device-status-tap-connect');
            focusItem.removeAttribute('aria-disabled');
            ToastHelper.showToast('error-connect-toast');
          }
        });
      }
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          panel,
          pairedDevicesList: panel.querySelector('#paired-devices'),
          noPairedDesc: panel.querySelector('#no-paired-devices')
        };
      },

      onBeforeShow() {
        window.addEventListener('paired-devices-change', updatePairedDesc);
        updatePairedDesc();
        document.addEventListener('focusChanged', focusChanged);
      },

      onBeforeHide() {
        window.removeEventListener('paired-devices-change', updatePairedDesc);
        document.removeEventListener('focusChanged', focusChanged);
      }
    });
  };
});
