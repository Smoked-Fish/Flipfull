/**
 * Created by gangchen on 14/6/19.
 */
define(['require','modules/settings_panel','modules/settings_service'],function(require) {
  'use strict';
  var SettingsPanel = require('modules/settings_panel');
  var SettingsService = require('modules/settings_service');

  return function about_source_code_panel() {
    var _iframe;
    var previousLanguage = null;
    var currentLanguage = null;

    function _initIframe() {
      _iframe.focus();
    }

    function _initSoftKey() {
      var softkeyParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [{
          name: 'select',
          l10nId: 'ok',
          priority: 2,
          method: function() {}
        }]
      };
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    function checkCurrentLanguage() {
      // Task10114480-tfzhang@tcl.com-modify-begin
      window.SettingsObserver.getValue('language.current').then((value)=>{
        currentLanguage = value;
        if (previousLanguage !== currentLanguage) {
          getLicense();
          previousLanguage = currentLanguage;
        }
      });
      // Task10114480-tfzhang@tcl.com-modify-end
    }

    function keyDownHandler(evt) {
      switch (evt.key) {
        case 'Enter':
        case 'Backspace':
          SettingsService.navigate('about_legal');
          evt.preventDefault();
          break;
      }
    }

    function isExistFile(testURL, callback) {
      let xmlHttp = new XMLHttpRequest();

      xmlHttp.onreadystatechange = () => {
        if (xmlHttp.readyState === 4) {
          if (xmlHttp.status === 200) {
            //file at URL exist
            callback(true);
          } else {
            callback(false);
          }
        }
      };

      xmlHttp.open("GET", testURL);
      try {
        xmlHttp.send();
      } catch(e) {
        callback(false);
      }
    }

    function getLicense() {
      // Task10114480-tfzhang@tcl.com-modify-begin
      window.SettingsObserver.getValue('language.current').then((value)=>{
        let lang = value;
        let licensePath = 'shared/locales/kaios_license/part_fifteen_fcc_rules.' + lang + '.html';
        let defaultLicensePath = 'shared/locales/kaios_license/part_fifteen_fcc_rules.en-US.html';
        isExistFile(licensePath, (isExist) => {
          _iframe.src = isExist ? licensePath : defaultLicensePath;
          _iframe.onload = () => {
            _iframe.contentDocument.body.setAttribute('style','word-wrap : break-word !important');
            _iframe.contentDocument.addEventListener('keydown', keyDownHandler);
          }
        });
      });
      // Task10114480-tfzhang@tcl.com-modify-end
    }

    return SettingsPanel({
      onInit: function (panel) {
        _iframe = document.getElementById('part_fifteen_fcc_rules_iframe');
        checkCurrentLanguage();
      },

      onBeforeShow: function() {
        _initSoftKey();
        window.addEventListener('panelready', _initIframe);
        _iframe.contentDocument.addEventListener('keydown', keyDownHandler);
        _iframe.contentDocument.dir = window.document.dir;
        checkCurrentLanguage();
      },

      onBeforeHide: function () {
        SettingsSoftkey.hide();
        window.removeEventListener('panelready', _initIframe);
        _iframe.contentDocument.removeEventListener('keydown', keyDownHandler);
      }
    });
  };
});
