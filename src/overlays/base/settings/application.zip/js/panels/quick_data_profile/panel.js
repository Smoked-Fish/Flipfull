/**
 * The apn list panel
 */
define(function(require) {
  'use strict';

  var SettingsPanel = require('modules/settings_panel');

  return function ctor_apn_settings_panel() {

    //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-4013,
    //Add quick data profile option
    let elements = null;

    function log(msg) {
      dump('quick_data_profile: ' + msg);
    };

    function getResValue(resName, def) {
      let ret = def;
      let resVal;
      const getRes = window.api.l10n.get;
      if (getRes) {
        resVal = getRes(resName);
        if (resVal && resVal != '') {
          ret = resVal;
        }
      }
      log('getResValue: resName=' + resName + ' resVal=' + resVal + ' resValType=' + (typeof resVal)
          + ' def=' + def + ' ret=' + ret + ' getRes=' + getRes);
      return ret;
    }

    //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/21/2024,GF5GTMO-4304,
    //Restructure quick data profile code and optimize feature
    function disableItem(item, enabled) {
      log('disableItem: enabled=' + enabled + ' item=' + item);
      if (!item) {
        return;
      }

      log('disableItem: toggle none-select=' + !enabled);
      item.classList.toggle('none-select', !enabled);
      if (enabled) {
        log('disableItem: removeAttribute=');
        item.removeAttribute('aria-disabled');
      } else {
        log('disableItem: setAttribute=');
        item.setAttribute('aria-disabled', true);
      }
      //color
      let textColor = enabled ? 'black' : 'gray';
      log('disableItem: textColor=' + textColor);
      log('disableItem: item.style=' + item.style);
      if (item.style) {
        item.style.color = textColor;
      }
    }

    function updateUIBySlot() {
      let isDoubleSimSlot = SimCardHelper.isDoubleSimSlot();
      log('updateUIBySlot: isDoubleSimSlot=' + isDoubleSimSlot);
      if (SimCardHelper.isDoubleSimSlot()) {
        for (let index = 0; index < ApiManager.connections.length; index++) {
          let iccid = ApiManager.connections[index].iccId;
          let apnSettings = index == 0 ? elements.apnSettings1 : elements.apnSettings2;
          let carrierDataSettings = index == 0 ? elements.carrierDataSettings1 : elements.carrierDataSettings2;
          log('updateUIBySlot: index=' + index + ' iccid=' + iccid);
          log('updateUIBySlot: index=' + index + ' apnSettings=' + apnSettings);
          log('updateUIBySlot: index=' + index + ' carrierDataSettings=' + carrierDataSettings);
          if (iccid) {
            //Do Nothing
          } else {
            disableItem(apnSettings, false);
            disableItem(carrierDataSettings, false);
          }
        }
      } else {
        disableItem(elements.apnSettings2, false);
        disableItem(elements.carrierDataSettings2, false);
      }
    }
    //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4304,

    function handleEvent(evt) {
      log('handleEvent: evt=' + JSON.stringify(evt));
      const { target } = evt;
      evt.preventDefault();
      evt.stopPropagation();

      if (target.classList.contains('none-select')) {
        return;
      }

      switch (target.id) {
        case 'apnSettings1':
          Settings.setCurrentPanel('apn_list_tct', { serviceId: 0, editable: true, backPage: '#quick_data_profile' });
          break;
        case 'apnSettings2':
          Settings.setCurrentPanel('apn_list_tct', { serviceId: 1, editable: true, backPage: '#quick_data_profile' });
          break;
        case 'carrierDataSettings1':
          Settings.setCurrentPanel('carrier_data_settings', { serviceId: 0 });
          break;
        case 'carrierDataSettings2':
          Settings.setCurrentPanel('carrier_data_settings', { serviceId: 1 });
          break;
      }
    }
    //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4013,

    function _initSoftKey() {
      var softkeyParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [{
          name: 'Select',
          l10nId: 'select',
          priority: 2,
          method: function () {
          }
        }]
      };
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    return SettingsPanel({
      onInit: function bp_onInit(rootElement) {
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-4013,
        //Add quick data profile option
        let mainHeader = rootElement.querySelector('gaia-header');
        let header = mainHeader.querySelector('h1');
        log('onInit: rootElement=' + rootElement + ' mainHeader=' + mainHeader + ' header=' + header);
        if (header) {
          if (!header.textContent || header.textContent == '') {
            header.textContent = 'Data Profile';
          }
        }
        let panel = rootElement;
        elements = {
          apnSettings1: panel.querySelector('#apnSettings1'),
          apnSettings2: panel.querySelector('#apnSettings2'),
          carrierDataSettings1: panel.querySelector('#carrierDataSettings1'),
          carrierDataSettings2: panel.querySelector('#carrierDataSettings2'),
        };
        //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4013,
      },

      onBeforeShow: function bp_onBeforeShow(rootElement, options) {
        _initSoftKey();
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-4013,GF5GTMO-4304
        //Add quick data profile option
        let apnTitle = getResValue('quick_APN_Settings', 'APN settings');
        let carrierTitle = getResValue('quick_Carrier_Data_Settings', 'Carrier data settings');
        log('onBeforeShow: apnTitle=' + apnTitle + ' carrierTitle=' + carrierTitle);
        elements.apnSettings1.addEventListener('click', handleEvent);
        elements.apnSettings2.addEventListener('click', handleEvent);
        elements.carrierDataSettings1.addEventListener('click', handleEvent);
        elements.carrierDataSettings2.addEventListener('click', handleEvent);
        log('onBeforeShow: elements.apnSettings1=' + JSON.stringify(elements.apnSettings1));
        log('onBeforeShow: span=' + elements.apnSettings1.querySelector('span'));
        elements.apnSettings1.querySelector('span').textContent = apnTitle + ' - SIM1';
        elements.apnSettings2.querySelector('span').textContent = apnTitle + ' - SIM2';
        elements.carrierDataSettings1.querySelector('span').textContent = carrierTitle + ' - SIM1';
        elements.carrierDataSettings2.querySelector('span').textContent = carrierTitle + ' - SIM2';
        updateUIBySlot();
        //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4013,GF5GTMO-4304
      },

      onBeforeHide: function abp_onBeforeHide() {
        SettingsSoftkey.hide();
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,09/02/2024,GF5GTMO-4013,
        //Add quick data profile option
        log('onBeforeHide: removeEventListener');
        elements.apnSettings1.removeEventListener('click', handleEvent);
        elements.apnSettings2.removeEventListener('click', handleEvent);
        elements.carrierDataSettings1.removeEventListener('click', handleEvent);
        elements.carrierDataSettings2.removeEventListener('click', handleEvent);
        //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-4013,
      },

      onShow: function() {
      },

      onHide: function bp_onBeforeHide() {
      }
    });
  };
});
