/**
 * Created by gangchen on 20/5/19.
 */
define(['require','modules/settings_panel'],function(require) {
  'use strict';
  var SettingsPanel = require('modules/settings_panel');

  // Defect10594628-tfzhang@tcl.com-modify-begin
  return function about_source_code_panel() {
    var elements = {};
    var softkeyParams = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [{
        name: 'Select',
        l10nId: 'select',
        priority: 2,
        method: function() {}
      }]
    };

    var softkeyParamsNone = {
      menuClassName: 'menu-button',
      header: {
        l10nId: 'message'
      },
      items: [{
        name: '',
        l10nId: '',
        priority: 2,
        method: function() {}
      }]
    };

    function _initSoftKey() {
      var softkeyParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [{
          name: 'Select',
          l10nId: 'select',
          priority: 2,
          method: function() {}
        }]
      };
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    function _updateSoftKey(evt) {
      var position = evt.target.className.indexOf('need-change');
      if (position === -1) {
        SettingsSoftkey.init(softkeyParamsNone);
        SettingsSoftkey.show();
      } else {
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
      }
    }

    function _initAllEventListener() {
      var i = elements.items.length - 1;
      for (i; i >= 0; i--) {
        elements.items[i].addEventListener('focus', _updateSoftKey);
      }
    }

    function _removeAllEventListener() {
      var i = elements.items.length - 1;
      for (i; i >= 0; i--) {
        elements.items[i].removeEventListener('focus', _updateSoftKey);
      }
    }

    function getImeiCode(simSlotIndex) {
      var dialPromise = navigator.b2g.mobileConnections[simSlotIndex].getDeviceIdentities();
      return dialPromise.then(function(deviceInfo) {
        if (deviceInfo.imei) {
          return deviceInfo.imei;
        } else {
          var errorMsg = 'Could not retrieve the IMEI code for SIM ' + simSlotIndex;
          dump(errorMsg);
          return Promise.reject(
            new Error(errorMsg)
          );
        }
      });
    }

    function cuhexArrayToAsciiStr(arr) {
      //debug('traceData.hexArrayToAsciiStr');
      var ascii = [];
      for (var i in arr) {
        //ASCII character scope
        if (arr[i] >= 32 && arr[i] <= 126) {
          var ss = String.fromCharCode(arr[i]);
            ascii.push(ss);
          }
      }
      var ascii_code = ascii.join('');
      return ascii_code;
    }

    return SettingsPanel({
      onInit: function(panel) {
        elements = {
          items: panel.querySelectorAll('li')
        };
        var product_name = document.getElementById('product_name_id');
        // Defect10687182-tfzhang@tcl.com-modify-begin
        navigator.b2g.engmodeManager.getPropertyValue('ro.product.system.model').then((result)=>{
          if(result && result != ''){
            product_name.innerHTML = result;
          }
        });
        // Defect10687182-tfzhang@tcl.com-modify-end
        navigator.b2g.engmodeManager.getPropertyValue("ro.elabel.manufacturer.name").then((result)=>{
            if(result && result != ''){
                document.getElementById('manufacturer_name_id').innerHTML = result;
            }
        });

		window.remoteHelper.getproperty('ro.vendor.tct.curef', (response) => {
            var cuValue = JSON.parse(response).value
            if(cuValue != null){
                var cu_reference = document.getElementById('cu_reference_id');
                cu_reference.innerHTML = cuValue;
            }
        });

        let conns = [];
        if (navigator.b2g.mobileConnections) {
          conns = navigator.b2g.mobileConnections;
        }
        if (!navigator.b2g.telephony || conns.length === 0) {
          dump('Settings: imei in regulatory safety is null');
          document.getElementById('imei_safety').classList.add('hidden');
        } else {
          let imeiContainer = document.getElementById('imei_safety');
          imeiContainer.innerHTML = ""; 

          conns.forEach((conn, index) => {
            let getDeviceId = conn.getDeviceIdentities();

            if (getDeviceId) {

                if (index == 0) {
                   let imeiTextShow = document.createElement('div');
                   imeiTextShow.innerHTML = `IMEI`;
                   imeiContainer.appendChild(imeiTextShow);
                }
              dump('www index=' + index);
              let imeiElement = document.createElement('div');
              imeiElement.innerHTML = `IMEI ${index + 1}: ${getDeviceId.imei}`;
              imeiContainer.appendChild(imeiElement);
            } else {
              dump(`Could not retrieve the IMEI code for SIM slot ${index + 1}`);
            }
          });
        }

        navigator.b2g.engmodeManager.getPropertyValue("ro.elabel.bluetooth.id").then((result)=>{
            if(result && result != ''){
                document.getElementById('bluetooth_desc_id').innerHTML = result;//Defect10802699-tfzhang@tcl.com
            }
        });

        navigator.b2g.engmodeManager.getPropertyValue("ro.elabel.fcc.id").then((result)=>{
            if(result && result != ''){
                document.getElementById('fcc_id').innerHTML = result;
            }
        });
        navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name').then((operatorNameValue) => {
//          if(nameValue === 'T440W'){
//            console.log(`is GF 5G TMO`);
//            document.getElementById('regulatory_fcc_id_iframe').style.display = 'none';
//            document.getElementById('regulatory_fcc_id_iframe').classList.add('hidden')
//
//            document.getElementById('bluetooth_id_iframe').style.display = 'none';
//            document.getElementById('bluetooth_id_iframe').classList.add('hidden')
//
//            navigator.b2g.engmodeManager.getPropertyValue("ro.elabel.bluetooth.id").then((result)=>{
//              if(result && result != ''){
//                document.getElementById('bluetooth_ee_desc_id').innerHTML = result;
//              }
//            });
//
//          }else {
//            document.getElementById('regulatory_ee_id_iframe').style.display = 'none';
//            document.getElementById('regulatory_ee_id_iframe').classList.add('hidden')
//          }


         document.getElementById('bluetooth_id_iframe').style.display = 'none';
         document.getElementById('bluetooth_id_iframe').classList.add('hidden');

         navigator.b2g.engmodeManager.getPropertyValue("ro.elabel.bluetooth.id").then((result)=>{
               if(result && result != ''){
                 document.getElementById('bluetooth_ee_desc_id').innerHTML = result;
               }
         });

        });

      },
      // Defect10594628-tfzhang@tcl.com-modify-end
      onBeforeShow: function() {
        _initAllEventListener();
        _initSoftKey();
      },

      onBeforeHide: function () {
        _removeAllEventListener();
      }
    });
  };
});
