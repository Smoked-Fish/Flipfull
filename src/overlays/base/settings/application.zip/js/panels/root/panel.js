/* global RootManager SimCardHelper DeviceStorageHelper AccountHelper ConnectionHelper BatteryHelper,
   SimOptionMenuHelper SIMSlotManager WfcSimOptionMenuHelper*/

'use strict';
define(function (require) {//eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function rootPanel() {
    const AIRPLANE_STATUS = 'airplaneMode.status';
    const WIFI_KEY = 'wifi.enabled';
    const BLUETOOTH_KEY = 'bluetooth.enabled';
    const DEVELOPER_KEY = 'developer.menu.enabled';
    const ANTI_THEFT_KEY = 'antitheft.enabled';
    const MEDIA_LOCATION_KEY = 'device.storage.writable.name';
    const KIDS_FEATURE_KEY = 'allow.kids.mode';
    const KIDS_MODE_KEY = 'kids.mode.enabled';
    const PASS_LOCK_CODE = 'kids.passcode-lock.code';
    const ROOT_SETTINGS_UI_LIST = [
      'wifi.settings.ui',
      'dm.wifi.settings.ui',
      'bluetooth.settings.ui',
      'dm.bluetooth.settings.ui',
      'geolocation.settings.ui',
      'dm.geolocation.settings.ui',
      'wifi-hotspot.settings.ui',
      'dm.tethering.wifi.settings.ui',
      'tethering.usb.settings.ui',
      'dm.tethering.usb.settings.ui'
    ];

    const airplaneHelper = {
      status: null
    };

    let elements = null;

    let antiTheftValue = true;
    let otherAccountInfo = [];
    let sdcard1 = null;
    const sizeList = {
      total: null,
      sdcard: null,
      apps: null
    };
    let passcode = '';

    const updateBatteryInfo = function updateBatteryInfo() {
      l10n.setAttributes(
        elements.batteryDesc,
        `batteryLevel-percent-${BatteryHelper.state}`,
        { level: BatteryHelper.level }
      );
    };

    const updateSystemSize = function updateSystemSize() {
      if (sizeList.total && sizeList.sdcard && sizeList.apps) {
        //modify by jiapeng.zhang for GF7TF-3459 on 2023/10/26
        const systemSize = sizeList.total - sizeList.sdcard;
        DeviceStorageHelper.showFormatedSize(
          elements.systemStorageDesc,
          'storageSize',
          parseInt(systemSize, 10)
        );
      }
    };

    const updateStorageSize = function updateStorageSize(
      deviceStorage,
      element,
      type
    ) {
      const results = {};
      const MIN_SIZE =
        type === 'apps' ? Constants.MIN_APP_SIZE : Constants.MIN_MEDIA_SIZE;
      deviceStorage.usedSpace().then(usedSize => {
        results.used = usedSize;
        deviceStorage.freeSpace().then(freeSize => {
          results.free = freeSize;
          results.total = usedSize + freeSize;
          DeviceStorageHelper.showFormatedSizeOfUsedAndTotal(
            element,
            'usedOfTotal',
            results
          );

          if (freeSize <= MIN_SIZE) {
            element.parentNode.setAttribute('data-state', 'no-space');
          } else {
            element.parentNode.removeAttribute('data-state');
          }
          if (type === 'sdcard1') {
            DeviceStorageHelper.showFormatedSize(
              elements.headerSdcardSize,
              'storage-name-external-0-size',
              results.total
            );
          } else {
            sizeList[type] = results.total;
            updateSystemSize();
          }
        });
      });
    };

    const updateMediaLocation = function updateMediaLocation(panel) {
      if (ApiManager.getDeviceStorages('sdcard').length > 1) {
        ApiManager.getDeviceStorages('sdcard')[1]
          .available()
          .then(value => {
            if (value === 'available') {
              elements.mediaSdcardHeader.classList.remove('hidden');
              elements.mediaSdcard.classList.remove('hidden');
              elements.locationItem.classList.remove('none-select');
              elements.locationItem.removeAttribute('aria-disabled');
              updateStorageSize(
                ApiManager.getDeviceStorages('sdcard')[1],
                elements.mediaSdcardDesc,
                'sdcard1'
              );
              window.dispatchEvent(new CustomEvent('refresh'));
            } else {
              elements.locationItem.classList.add('none-select');
              elements.locationItem.setAttribute('aria-disabled', true);
              elements.mediaSdcardHeader.classList.add('hidden');
              elements.mediaSdcard.classList.add('hidden');
            }
            window.dispatchEvent(new CustomEvent('refresh'));
            ListFocusHelper.updateSoftkey(panel);
          });
      } else {
        elements.locationItem.classList.add('none-select');
        elements.locationItem.setAttribute('aria-disabled', true);
        elements.mediaSdcardHeader.classList.add('hidden');
        elements.mediaSdcard.classList.add('hidden');
        window.dispatchEvent(new CustomEvent('refresh'));
        ListFocusHelper.updateSoftkey(panel);
      }
    };

    const updateStorageInfo = function updateStorageInfo(panel) {
      SettingsDBCache.getSetting('ums.enabled').then(value => {
        l10n.setAttributes(
          elements.usbStorageDesc,
          value ? 'enabled' : 'disabled'
        );
      });
      updateStorageSize(
        ApiManager.getDeviceStorages('sdcard')[0],
        elements.mediaInternalDesc,
        'sdcard'
      );
      updateStorageSize(
        ApiManager.getDeviceStorage('apps'),
        elements.appStorageDesc,
        'apps'
      );
      updateMediaLocation(panel);
    };

    function newListItem(account) {
      const name = document.createElement('span');
      name.textContent = account.accountId;
      name.classList.add('full-string');

      const a = document.createElement('a');
      a.appendChild(name);
      a.classList.add('menu-item');

      // Create list item
      const li = document.createElement('li');
      li.appendChild(a);

      // Bind connection callback
      li.onclick = () => {
        Settings.setCurrentPanel('add_account_settings', {
          account
        });
      };
      return li;
    }

    function checkObjectArray(arr1, arr2) {
      if (arr1.length !== arr2.length) {
        return false;
      }
      // eslint-disable-next-line
      for (let i = 0; i < arr1.length; i++) {
        if (typeof arr1[i] !== typeof arr2[i]) {
          return false;
        } else if (JSON.stringify(arr1[i]) !== JSON.stringify(arr2[i])) {
          return false;
        }
      }
      return true;
    }

    const updateAccountInfo = function updateAccountInfo() {
      // This function will update kai account relate UI
      AccountHelper.getAccountInfo(['kaiaccount']).then(result => {
        if (result.length > 0) {
          SettingsDBCache.getSetting('kaiaccount.openflow.default').then(
            value => {
              const kaiInfo = result[0].userData;
              elements.kaiAccountDesc.textContent =
                kaiInfo.phone && 'phone' === value
                  ? kaiInfo.phone
                  : kaiInfo.email;
            }
          );
          elements.antiTheftItem.removeAttribute('aria-disabled');
          elements.antiTheftItem.classList.remove('none-select');
          elements.antiTheftNote1.classList.remove('hidden');
          elements.antiTheftNote2.classList.remove('hidden');
        } else {
          elements.kaiAccountDesc.textContent = l10n.get(
            'kaios-account-not-sign-in'
          );
          elements.antiTheftItem.setAttribute('aria-disabled', true);
          elements.antiTheftItem.classList.add('none-select');
          elements.antiTheftNote1.classList.add('hidden');
          elements.antiTheftNote2.classList.add('hidden');
        }
      });
      AccountHelper.getAccountInfo(['activesync', 'google']).then(result => {
        if (checkObjectArray(otherAccountInfo, result)) {
          return;
        }
        otherAccountInfo = result;
        const list = elements.otherAccounts.querySelectorAll('li');
        const len = list.length;
        // eslint-disable-next-line
        for (let i = len - 2; i >= 0; i--) {
          elements.otherAccounts.removeChild(list[i]);
        }
        for (const account of result) {
          DebugHelper.debug(`getAccounts: ${JSON.stringify(account)}`);
          const listItem = newListItem(account);
          elements.otherAccounts.insertBefore(
            listItem,
            elements.addAccountButton
          );
        }
        window.dispatchEvent(new CustomEvent('refresh'));
      });
    };

    const updateFotaInfo = function updateAccountInfo() {
      window.api.session.has_service('Fota').then(
        value => {
          DebugHelper.log(`Fota Service:${value}`);
          if (value) {
            elements.fotaSettings.classList.remove('hidden');
          } else {
            elements.fotaSettings.classList.add('hidden');
          }
        },
        err => {
          elements.fotaSettings.classList.add('hidden');
          DebugHelper.log(`Can not got service of fota:${err}`);
        }
      );
      elements.fotaSettings.addEventListener('keydown', function(evt) {
        if (evt.key === 'Enter') {
          ActivityHelper.start({
            name: 'settings-fota'
          }).then((result)=>{
            dump('fota App, settings-fota result='+result);
          });
        }
      });
    };

    const updateDesc = function updateDesc(value, key) {
      let l10nValue = null;
      switch (key) {
        case AIRPLANE_STATUS:
          airplaneHelper.status = value;
          if (value === 'disabled' || value === 'enabled') {
            elements.airplaneMenuItem.classList.remove('none-select');
            elements.airplaneMenuItem.removeAttribute('aria-disabled');
          } else {
            elements.airplaneMenuItem.classList.add('none-select');
            elements.airplaneMenuItem.setAttribute('aria-disabled', true);
          }
          updateTelephonyItems();
          Customization.updateUI(['hotspot']);

          break;
        case WIFI_KEY:
          l10nValue = value ? 'on' : 'off';
          elements.wifiDesc.setAttribute('data-l10n-id', l10nValue);
          break;
        case BLUETOOTH_KEY:
          l10nValue = value ? 'on' : 'off';
          elements.bluetoothDesc.setAttribute('data-l10n-id', l10nValue);
          break;
        case DEVELOPER_KEY:
          elements.developerItem.classList.toggle('hidden', !value);
          //Defect11220161-bin.shen@tcl.com-begin
          if(!value) {
            SettingsDBCache.getSetting('show.developer.menu').then(show => {
              if (show) {
                elements.developerItem.classList.remove('hidden');
              }
            });
          }
          //Defect11220161-bin.shen@tcl.com-end
          break;
        default:
          break;
      }
    };

    const updateAirplaneInfo = function updateAirplaneInfo(value, key) {
      updateDesc(value, key);
      if (value === 'disabled' || value === 'enabled') {
        ToastHelper.changeSaved();
      }
    };

    function disableItems(disabled, itemIds) {
      for (let id = 0; id < itemIds.length; id++) {
        const item = document.getElementById(itemIds[id]);
        if (!item) {
          continue;
        }
        if (disabled) {
          item.setAttribute('aria-disabled', true);
          item.classList.add('none-select');
        } else {
          item.removeAttribute('aria-disabled');
          item.classList.remove('none-select');
        }
      }
    }

    function removeItemHref(itemIds) {
      itemIds.forEach(id => {
        const item = document.getElementById(id);
        item.removeAttribute('aria-disabled');
        item.classList.remove('none-select');
      });
    }

    function showICCCardDetails(details) {
      const itemIds = [
        'call-desc',
        'internetSharing-desc',
        'cell-broadcast-desc'
      ];

      for (let id = 0; id < itemIds.length; id++) {
        const desc = document.getElementById(itemIds[id]);
        if (!desc) {
          continue;
        }
        desc.style.fontStyle = 'italic';

        if (details !== '') {
          desc.setAttribute('data-l10n-id', details);
        } else {
          desc.removeAttribute('data-l10n-id');
          desc.textContent = '';
        }
      }
    }

    function updateTelephonyItems() {
      initWFCItems();
      if (typeof SimCardHelper === Constants.UNDEFINED) {
        window.addEventListener(
          'sim-card-ready',
          () => {
            updateTelephonyItems();
          },
          { once: true }
        );
        return;
      }
      if (!SimCardHelper.hasValidCard()) {
        if (window.hasESIM) {
          disableItems(false, ['sim-manager-settings']);
          disableItems(true, [
            'data-connectivity',
            'call-settings',
            'volte-settings',
            'cell-broadcast-entry'
          ]);
        }
        return;
      }
      let itemIds = null;
      let dualCardItemIds = null;
      const airplaneEnabled = airplaneHelper.status !== 'disabled' || false;
      const isSupportDualLte = DeviceFeature.getValue('dualLte') === 'true';
      const currentCapability = SimCardHelper.getImsCapability();
      const capabilityEnabled =
        currentCapability === 'voice-over-wifi' ||
        currentCapability === 'video-over-wifi';

      if (SimCardHelper.hasValidCard()) {
        if (airplaneHelper.status === null) {
          return;
        }

        if (airplaneEnabled) {
          itemIds = ['data-connectivity', 'sim-manager-settings'];
          disableItems(true, itemIds);
          itemIds = [
            'call-settings',
            'wireless-emergency-alert',
            'cell-broadcast-entry'
          ];
          disableItems(!capabilityEnabled, itemIds);

          itemIds = ['volte-settings'];
          if (isSupportDualLte) {
            removeItemHref(itemIds);
          } else {
            disableItems(false, itemIds);
          }
        } else {
          itemIds = ['wireless-emergency-alert'];
          disableItems(false, itemIds);

          if (SimCardHelper.isDoubleSimSlot()) {
            const iccCard1 = SimCardHelper.getIccInfo(0);
            const iccCard2 = SimCardHelper.getIccInfo(1);
            const cardReady =
              (iccCard1 && iccCard1.cardState === 'ready') ||
              (iccCard2 && iccCard2.cardState === 'ready');
            if (!cardReady) {
              itemIds = [
                'sim-manager-settings',
                'data-connectivity',
                'call-settings',
                'cell-broadcast-entry',
                'volte-settings'
              ];
              disableItems(true, itemIds);
              if (window.hasESIM) { // eslint-disable-line
                disableItems(false, ['sim-manager-settings']);
              }
              return;
            }

            if (isSupportDualLte) {
              itemIds = [
                'call-settings',
                'cell-broadcast-entry',
                'volte-settings'
              ];
              dualCardItemIds = ['sim-manager-settings', 'data-connectivity'];
            } else {
              itemIds = ['call-settings', 'cell-broadcast-entry'];
              dualCardItemIds = [
                'sim-manager-settings',
                'data-connectivity',
                'volte-settings'
              ];
            }
            showICCCardDetails('');
            removeItemHref(itemIds);
            disableItems(false, dualCardItemIds);
          } else {
            // Single ICC card device.
            itemIds = [
              'call-settings',
              'data-connectivity',
              'volte-settings',
              'cell-broadcast-entry',
              'sim-manager-settings'
            ];

            const { cardState } = SimCardHelper.getIccInfo(0);
            const cardReady = cardState === 'ready';
            disableItems(!cardReady, itemIds);
            if (cardReady) {
              showICCCardDetails('');
            } else {
              showICCCardDetails(SimCardHelper.getCardDes(cardState));
            }
          }
        }
        if (window.hasESIM) {
          disableItems(false, ['sim-manager-settings']);
        }
      } else {
        itemIds = ['wireless-emergency-alert'];
        disableItems(airplaneEnabled, itemIds);
        showICCCardDetails(SimCardHelper.getCardDes('absent'));
      }
    }

    function updateAntiTheft() {
      const enabled = elements.antiTheftSelect.value === 'true' || false;
      if (!enabled) {
        ActivityHelper.start({
          name: 'account-manager',
          data: {
            authenticatorId: 'kaiaccount',
            action: 'showOtherPage',
            publicKey: AccountHelper.publicKey,
            flow: 'checkPassword',
            args: [AccountHelper.kaiAccountInfo.userData, 'disableAntitheft']
          }
        }).then(
          response => {
            AccountHelper.decryptKey(response).then(result => {
              if (result) {
                if (result.result === 'success') {
                  SettingsDBCache.saveSettings({ [ANTI_THEFT_KEY]: enabled });
                  ToastHelper.showToast('changessaved');
                } else if (result.error === 'ACCOUNT_DELETED') {
                  AccountHelper.refreshAccount();
                  updateAccountInfo();
                } else if (result.error === 'ABORT') {
                  elements.antiTheftSelect.value = true;
                }
              } else {
                elements.antiTheftSelect.value = true;
              }
            });
          },
          err => {
            DebugHelper.log(`disableAntitheft error${JSON.stringify(err)}`);
            elements.antiTheftSelect.value = !enabled;
          }
        );
      } else {
        ToastHelper.showToast('changessaved');
        SettingsDBCache.saveSettings({ [ANTI_THEFT_KEY]: true });
      }
    }

    function handleTelephonyItems(evt) {
      if (
        !evt ||
        !evt.target ||
        !evt.target.id ||
        evt.target.classList.contains('none-select')
      ) {
        return;
      }
      if (evt.target.id === 'call-settings') {
        SimOptionMenuHelper.showSimCardOptionMenu(serviceId => { // Modified by kangkangma for PR GF5GTMO-7002/GF5GTMO-7002 on 2025/04/24
          Settings.setCurrentPanel('#call', {
            serviceId
          });
        });
      } else if (evt.target.id === 'cell-broadcast-entry') {
        SimOptionMenuHelper.show(serviceId => {
          Settings.setCurrentPanel('#cell_broadcast_message', {
            serviceId
          });
        });
      }
    }

    //GF7TF-2149-yanli.zhang@tcl.com-set QD number in settings begin
    function showOrHideAssistanceMenu() {
        navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name').then((value) => {
            let assistance_item = document.getElementById('assistance-item');
            if (value == 'TF') {
                assistance_item.hidden = false;
            }
        });
    }
    //GF7TF-2149-yanli.zhang@tcl.com-set QD number in settings end

    function initWFCItems() {
      const vowifiDisplay = document.getElementById('vowifi-settings');
      const iccManager = navigator.b2g.iccManager;

      // Check if ICC manager exists and if there are ICC IDs
      if (!iccManager || !iccManager.iccIds || iccManager.iccIds.length === 0) {
        console.log('initWFCItems: ccManager.iccIds.length === 0 return');
        vowifiDisplay.classList.add('hidden');
        return;
      }

      const showList = [];

      // Iterate over ICC IDs to build showList
      for (let iccIdIndex = 0; iccIdIndex < iccManager.iccIds.length; iccIdIndex++) {
        const slotIndex = SIMSlotManager.getSlotByIccId(iccManager.iccIds[iccIdIndex]).index;
        const simOperator = OperatorUtils.getSimOperatorNameByIndex(slotIndex);
        console.log('initWFCItems: slotIndex:'+slotIndex+' simOperator:'+simOperator);
        //defect-begin GF5GTMO-5799 [MPCS] There is no wifi calling manu in settingsguanzhong.zhu.cd 2024/12/13
        if (simOperator === 'TMO' || simOperator === 'MetroPCS' || simOperator === 'ASW' || (simOperator === 'VZW' && navigator.b2g.mobileConnections[slotIndex].imsHandler.vowifiOMAEnabled)) {
          showList.push({ simOperator, slotIndex });
        }
      }

      // Check if showList is empty
      if (showList.length === 0) {
        console.log('initWFCItems: showList.length === 0 return');
        return;
      }

      // Define callback function
      const setCallback = (showCard) => {
        if (showCard.simOperator === 'VZW') {
          return () => {
            const activity = new WebActivity("launch-wfc", { type: "vzwsettingsentry", cardIndex: showCard.slotIndex });
            activity.start();
          };
        } else if (showCard.simOperator === 'TMO' || showCard.simOperator === 'MetroPCS' || showCard.simOperator === 'ASW') {
          //defect-end GF5GTMO-5799 [MPCS] There is no wifi calling manu in settingsguanzhong.zhu.cd 2024/12/13
          return () => {
            Settings.setCurrentPanel('vowifi_tmo_settings', { cardIndex: showCard.slotIndex });
          };
        }
      };

      let callback;

      // Set callback based on the length of showList
      if (showList.length === 1) {
        callback = setCallback(showList[0]);
      } else {
        callback = () => {
          WfcSimOptionMenuHelper.show(serviceId => {
            const selectedCard = showList.find(card => card.slotIndex === serviceId);
            if (selectedCard) {
              const action = setCallback(selectedCard);
              action(); // Call the corresponding action
            }
          });
        };
      }
      vowifiDisplay.classList.remove('hidden')
      // Set click event
      const vowifiShow = document.getElementById('menuItem-vowifiShow');
      vowifiShow.onclick = callback;

      NavigationMap.refresh();
    }

    function onVoWiFiStateChange() {
      dump('vowifiOMAEnabledStateChange: ' + this.vowifiOMAEnabled);
      initWFCItems();
    }

    function initOmaEnableVoWiFiListener() {
      const iccManager = navigator.b2g.iccManager;
      if (iccManager?.iccIds?.length > 0) {
        iccManager.iccIds.forEach(iccId => {
          const slotIndex = SIMSlotManager.getSlotByIccId(iccId).index;
          const simOperator = OperatorUtils.getSimOperatorNameByIndex(slotIndex);
          if (simOperator === 'VZW') {
            const _imsHandler = navigator.b2g.mobileConnections[slotIndex].imsHandler;
            _imsHandler?.addEventListener('vowifiOMAEnabledStateChange', onVoWiFiStateChange.bind(_imsHandler));
          }
        });
      }
    }

    function removeOmaEnableVoWiFiListener() {
      const iccManager = navigator.b2g.iccManager;
      if (iccManager?.iccIds?.length > 0) {
        iccManager.iccIds.forEach(iccId => {
          const slotIndex = SIMSlotManager.getSlotByIccId(iccId).index;
          const simOperator = OperatorUtils.getSimOperatorNameByIndex(slotIndex);
          if (simOperator === 'VZW') {
            const _imsHandler = navigator.b2g.mobileConnections[slotIndex].imsHandler;
            _imsHandler?.removeEventListener('vowifiOMAEnabledStateChange', onVoWiFiStateChange.bind(_imsHandler));
          }
        });
      }
    }

    function simSlotCardStateChangeHandler(event) {
      var slot = event.detail;
      var simCard = slot?.simCard;
      var cardState = simCard && simCard.cardState;
      console.log('simSlotCardStateChangeHandler :'+cardState);
      if(cardState === 'ready'){
        initWFCItems();
      }
    }

    function handleIccChange() {
      if (SimOptionMenuHelper.isShown()) {
        SimOptionMenuHelper.hide();
      }
      updateTelephonyItems();
      Customization.updateUI(['hotspot']);
      ListFocusHelper.updateSoftkey();
    }

    function handleCardStatusChange(evt) {
      if(evt && evt.detail && evt.detail.status && evt.detail.status.target &&
        evt.detail.status.target.cardState === 'ready') {
        handleIccChange();
      }
    }

    return SettingsPanel({
      onInit: function onInit(panel) {
        RootManager.init();
        elements = {
          rootTabs: panel.querySelector('#root-tab'),
          airplaneMenuItem: panel.querySelector('#airplane_mode_switch'),
          airplaneSelect: panel.querySelector('#airplane-mode-select'),
          wifiMenuItem: panel.querySelector('#menuItem-wifi'),
          wifiDesc: panel.querySelector('#wifi-desc'),
          bluetoothDesc: panel.querySelector('#bluetooth-desc'),
          nfcItem: panel.querySelector('#nfc-settings'),
          batteryDesc: panel.querySelector('#main-battery-desc'),
          cleanUpButton: panel.querySelector('.clean-up'),
          usbStorageDesc: panel.querySelector('#menu-usb-storage small'),
          locationItem: panel.querySelector('#location-item'),
          locationItemSelect: panel.querySelector('#location-item select'),
          headerInternalSize: panel.querySelector('#header-internal-size'),
          mediaInternal: panel.querySelector('#storage-media-internal'),
          mediaInternalDesc: panel.querySelector('#media-internal-desc'),
          applicationItem: panel.querySelector('#storage-application'),
          appStorageDesc: panel.querySelector('#application-storage-desc'),
          systemStorageDesc: panel.querySelector('#system-storage-desc'),
          mediaSdcardHeader: panel.querySelector('#media-sdcard-header'),
          headerSdcardSize: panel.querySelector('#header-sdcard-size'),
          mediaSdcard: panel.querySelector('#storage-media-sdcard'),
          mediaSdcardDesc: panel.querySelector('#media-sdcard-desc'),
          developerItem: panel.querySelector('#developer-settings'),
          answerModeItem: panel.querySelector('#answer-mode-settings'),
          kaiAccountItem: panel.querySelector('#kai-account-item'),
          kaiAccountDesc: panel.querySelector('#kai-account-item small'),
          antiTheftItem: panel.querySelector('#anti-theft-item'),
          antiTheftSelect: panel.querySelector('#anti-theft-select'),
          antiTheftNote1: panel.querySelector('#anti-theft-note1'),
          antiTheftNote2: panel.querySelector('#anti-theft-note2'),
          otherAccounts: panel.querySelector('#other-accounts'),
          addAccountButton: panel.querySelector('#add-account-button'),
          callSettings: panel.querySelector('#call-settings'),
          cellBroadcast: panel.querySelector('#cell-broadcast-entry'),
          fotaSettings: panel.querySelector('#fota-settings'),
          kidsMode: panel.querySelector('#kids-mode'),
          kidsModeDesc: panel.querySelector('#kids-mode small')
        };

        elements.wifiMenuItem.onclick = evt => {
          if (
            ApiManager.connections &&
            ApiManager.connections[0] &&
            ApiManager.connections[0].isInEmergencyCbMode
          ) {
            DebugHelper.debug('InEmergencyCbMode, do not allow operate wifi');
            evt.preventDefault();
            evt.stopPropagation();
          }
        };

        elements.cleanUpButton.onclick = () => {
          Settings.setCurrentPanel('application_storage', {
            originHref: '#root'
          });
        };
        elements.applicationItem.onclick = () => {
          Settings.setCurrentPanel('application_storage', {
            originHref: '#root'
          });
        };
        elements.locationItem.onclick = evt => {
          const { target } = evt;
          if (
            target.id === 'location-item' &&
            !elements.locationItem.hasAttribute('aria-disabled')
          ) {
            const locationConfig = {
              title: {
                id: 'confirmation',
                args: {}
              },
              body: {
                id: 'change-default-media-location-confirmation',
                args: {}
              },
              cancel: {
                name: 'Cancel',
                l10nId: 'cancel',
                priority: 1
              },
              confirm: {
                name: 'Change',
                l10nId: 'change',
                priority: 3,
                callback() {
                  const select = elements.locationItem.querySelector('select');
                  select.focus();
                }
              }
            };
            DialogHelper.show(locationConfig);
          }
        };
        elements.mediaInternal.onclick = () => {
          Settings.setCurrentPanel('media_storage', {
            originHref: '#root',
            type: 'sdcard'
          });
        };
        elements.mediaSdcard.onclick = () => {
          Settings.setCurrentPanel('media_storage', {
            originHref: '#root',
            type: 'sdcard1'
          });
        };

        //Porting from Defect11278971-modify by yanlizhang for ECMB dialog on 2024/9/2-begin
        elements.airplaneSelect.addEventListener('change', () => {
          let value = elements.airplaneSelect.value === 'true';
          let result = SettingsObserver.getValue('is_in_emergencycallbackmode');
          result.then(function (emcValue) {
            if (emcValue && value) {
              // Should be auto dismiss dialog if ECBM time out.
              const emcCallBack = (value) => {
                if (!value) {
                  DialogHelper.destroy();
                }
              };
              const dialogConfig = {
                title: { id: 'emergency-callback-mode', args: {} },
                body: { id: 'emergency-callback-radio-off-message', args: {} },
                confirm: {
                  name: 'Yes',
                  l10nId: 'yes',
                  priority: 3,
                  callback() {
                    SettingsObserver.unobserve('is_in_emergencycallbackmode', emcCallBack);
                    let conn = navigator.b2g.mobileConnections[0];
                    if (conn) {
                      dump('settings, exit ECBM mode and open air plane.');
                      conn.exitEmergencyCbMode();
                    }
                  }
                },
                cancel: {
                  name: 'No',
                  l10nId: 'no',
                  priority: 1,
                  callback() {
                    SettingsObserver.unobserve('is_in_emergencycallbackmode', emcCallBack);
                  }
                }
              };
              DialogHelper.show(dialogConfig);
              SettingsObserver.observe('is_in_emergencycallbackmode', false, emcCallBack);

              let restoreValue = 'false';
              if (elements.airplaneSelect.value === 'false') {
                restoreValue = 'true';
              }
              elements.airplaneSelect.value = restoreValue;
            } else {
              SettingsObserver.setValue([{
                name: 'airplaneMode.enabled',
                value: value
              }]);
            }
          });
        });
        //Porting from Defect11278971-modify by yanli.zhang for ECMB dialog on 2024/9/2-end

        elements.callSettings.onclick = handleTelephonyItems;
        elements.cellBroadcast.onclick = handleTelephonyItems;

        DeviceFeature.ready(() => {
          const size = DeviceFeature.getValue('totalSize');
          const totalSize = parseInt(size, 10);
          DeviceStorageHelper.showFormatedSize(
            elements.headerInternalSize,
            'storage-name-internal-size',
            totalSize
          );
          sizeList.total = totalSize;
          updateSystemSize();
        });

        Customization.addListener(ROOT_SETTINGS_UI_LIST);

        SettingsSoftkey.init(SoftParams.defaultSelect);
        SettingsDBCache.getSetting(AIRPLANE_STATUS).then(value => {
          updateDesc(value, AIRPLANE_STATUS);
        });
        SettingsDBCache.observe(WIFI_KEY, true, updateDesc);
        SettingsDBCache.observe(BLUETOOTH_KEY, true, updateDesc);
        SettingsDBCache.observe(DEVELOPER_KEY, true, updateDesc);
        if (ApiManager.nfc) {
          elements.nfcItem.classList.remove('hidden');
        }
        DeviceFeature.ready(() => {
          if (DeviceFeature.getValue('flipDevice') === 'true') {
            elements.answerModeItem.classList.remove('hidden');
          } else {
            elements.answerModeItem.classList.add('hidden');
          }
        });
        window.addEventListener('batteryChange', updateBatteryInfo);
        SettingsDBCache.observe(AIRPLANE_STATUS, '', updateAirplaneInfo, true);
        elements.kaiAccountItem.onclick = () => {
          if (ConnectionHelper.isOffline()) {
            ActivityHelper.start({ name: 'offline-dialog' });
          }
          if (AccountHelper.kaiAccountLogin) {
            SettingsDBCache.getSetting('kaiaccount.openflow.default').then(
              result => {
                Settings.setCurrentPanel('kaios_account_login', {
                  configMethod: result
                });
              }
            );
          } else {
            Settings.setCurrentPanel('kaios_account');
          }
        };
        AccountHelper.addObserve();
        SettingsDBCache.observe(ANTI_THEFT_KEY, false, value => {
          antiTheftValue = value || true;
          elements.antiTheftSelect.value = value;
        });
        elements.antiTheftItem.onclick = evt => {
          const { target } = evt;
          if (target.id === 'anti-theft-item') {
            if (!target.hasAttribute('aria-disabled')) {
              if (ConnectionHelper.isOffline()) {
                ActivityHelper.start({ name: 'offline-dialog' });
              } else {
                elements.antiTheftSelect.focus();
              }
            }
          }
        };
        elements.antiTheftSelect.addEventListener('change', () => {
          // eslint-disable-next-line
          if (antiTheftValue == elements.antiTheftSelect.value) {
            return;
          }
          updateAntiTheft();
        });
        elements.addAccountButton.onclick = () => {
          Settings.setCurrentPanel('add_account_list');
        };
        elements.kidsMode.onclick = () => {
          if (passcode === '') {
            Settings.setCurrentPanel('#kids_mode');
          } else {
            Settings.setCurrentPanel('#kids_passcode', {
              mode: 'confirm'
            });
          }
        };
        const listElements = panel.querySelectorAll('.root li');
        ListFocusHelper.addEventListener(listElements);
        if (document.activeElement.tagName === 'BODY') {
          panel.querySelector('.focus').focus();
        }
        showOrHideAssistanceMenu(); //GF7TF-2149-yanli.zhang@tcl.com-set QD number in settings
        if (ApiManager.eUiccManager) {
          ApiManager.eUiccManager.getEid().then(
            () => {
              window.hasESIM = true;
              updateTelephonyItems();
            },
            error => {
              DebugHelper.debug(`getEid error:${error}`);
            }
          );
        }
        SettingsDBCache.getSetting(KIDS_FEATURE_KEY).then(value => {
          elements.kidsMode.classList.toggle('hidden', !value);
        });
        SettingsDBCache.observe(
          MEDIA_LOCATION_KEY,
          '',
          value => {
            elements.locationItemSelect.value = value || 'sdcard';
            updateMediaLocation(panel);
          },
          true
        );
        SettingsDBCache.observe(
          KIDS_MODE_KEY,
          false,
          value => {
            elements.kidsModeDesc.setAttribute('data-l10n-id', value ? 'on' : 'off');
          }
        );
        SettingsDBCache.observe(PASS_LOCK_CODE, '', value => {
          passcode = value;
        });

        if (ApiManager.getDeviceStorages('sdcard').length > 1) {
          sdcard1 = ApiManager.getDeviceStorages('sdcard')[1]; //eslint-disable-line
          sdcard1.addEventListener('storage-state-change', e => {
            if (
              e.reason &&
              (e.reason === 'Unmounting' || e.reason === 'Mounted')
            ) {
              updateMediaLocation(panel);
            }
          });
        }
      },

      onBeforeShow: function onBeforeShow(panel) {
        // Root panel will not call onBeforeHide and onHide
        elements.rootTabs.select(elements.rootTabs.selected);
        DeviceFeature.ready(() => {
          Customization.initUIForItem([
            'airplane',
            'wifi',
            'bluetooth',
            'geolocation',
            'volte',
            'hotspot'
          ]);
        });
        updateTelephonyItems();
        updateBatteryInfo();
        updateStorageInfo(panel);
        updateAccountInfo();
        updateFotaInfo();
        initOmaEnableVoWiFiListener();
        ApiManager.iccManager.addEventListener(
          'iccdetected',
          handleIccChange
        );
        ApiManager.iccManager.addEventListener(
          'iccundetected',
          handleIccChange
        );
        window.addEventListener('simslot-iccinfochange', simSlotCardStateChangeHandler);
        window.addEventListener('SIM-cardstatechange', handleCardStatusChange);
      },

      onShow: function onShow(panel) {
        SettingsSoftkey.init(SoftParams.defaultSelect);
        ListFocusHelper.updateSoftkey(panel);
      },

      onBeforeHide: function onBeforeHide() {
        removeOmaEnableVoWiFiListener();
        ApiManager.iccManager.removeEventListener(
          'iccdetected',
          handleIccChange
        );
        ApiManager.iccManager.removeEventListener(
          'iccundetected',
          handleIccChange
        );
        window.removeEventListener('simslot-iccinfochange', simSlotCardStateChangeHandler);
        window.removeEventListener('SIM-cardstatechange', handleCardStatusChange);
      }
    });
  };
});
