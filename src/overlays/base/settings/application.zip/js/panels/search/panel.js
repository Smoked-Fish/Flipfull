'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');
  const Search = require('panels/search/search');
  return function creatSearchPanel() {
    let currentPanel = null;

    function handleKeyDown(e) {
      switch (e.key) {
        case 'Accept':
        case 'Enter':
          if (currentPanel.querySelector('.focus') !== null) {
            const select = currentPanel.querySelector('.focus select');
            select.focus();
          }
          break;
        default:
          break;
      }
    }
    return SettingsPanel({
      onInit(panel) {
        currentPanel = panel;
        const searchEngineSelect = panel.querySelector(
          '[data-name="search.provider"]'
        );
        const search = Search();
        search.init(searchEngineSelect);
      },
      onBeforeShow() {
        SettingsSoftkey.init(SoftParams.defaultSelect);
        SettingsSoftkey.show();
        window.addEventListener('keydown', handleKeyDown);
      },
      onBeforeHide() {
        SettingsSoftkey.hide();
        window.removeEventListener('keydown', handleKeyDown);
      }
    });
  };
});
