/* global SimCardHelper */
'use strict';
define(function(require) { // eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createSimDialogPanel() {
      let elements = null;

      function updateSoftKeys(enableDone) {
          const params = {
              menuClassName: 'menu-button',
              header: {
                  l10nId: 'message'
              },
              items: [
                  {
                      name: 'Cancel',
                      l10nId: 'cancel',
                      priority: 1,
                      method() {
                          window.close();
                      }
                  }
              ]
          };

          if (enableDone) {
              params.items.push({
                  name: 'Done',
                  l10nId: 'done',
                  priority: 3,
                  method() {
                      setBarometer();
                  }
              });
          }
          SettingsSoftkey.init(params);
          SettingsSoftkey.show();
      }


      function setBarometer() {
          var value = elements.input1Input.value;
          navigator.b2g.engmodeManager.updateAtmPressure(value).then(
              value=>{
                  navigator.b2g.engmodeManager.fileReadLE('atfile').then(
                      value=>{
                          showDoneDialog(value);
                      }
                  )},
              fail=>{
                  if(fail.indexOf('invalid')==-1) {
                  navigator.b2g.engmodeManager.fileReadLE('atfile').then(
                      value=>{
                          showDoneDialog(value)
                      });
                } else {
                  showDoneDialog(fail);
                }
              }
          )
      }

      function showDoneDialog(message) {
          dump('showDoneDialog message ='+message);
          const dialogConfig = {
              title: { id: '', args: {} },
              body: {
                  text: message
              },
              cancel: {
                  l10nId: 'set-again',
                  priority: 1,
                  callback: () => {
                      DialogHelper.destroy();
                      resetFocus();
                  }
              },
              confirm: {
                  l10nId: 'ok',
                  priority: 3,
                  callback: () => {
                      DialogHelper.destroy();
                      window.close();
                  }
              }
          };
          DialogHelper.show(dialogConfig);
      }

      function cleanInputElement() {
          elements.input1Input.value = '';
      }

      function resetFocus() {
          elements.input1Input.value = '';
          const focusedElement = elements.panel.querySelector('.focus');
          if (focusedElement) {
              focusedElement.classList.remove('focus');
              elements.input1Container.classList.add('focus');
              elements.input1Input.focus();
              window.dispatchEvent(new CustomEvent('refresh'));
          }
          updateSoftKeys(false);
      }

      function keydownHandler() {
          const focusedElement = elements.panel.querySelector('.focus');
          if (focusedElement) {
              const input = focusedElement.querySelector('input');
              if (input) {
                  input.focus();
              }
              NavigationMap.scrollToElement(focusedElement);
          }
      }

      function handleEvent(evt) {
          evt.stopPropagation();
          const { target } = evt;
          const input1Value = elements.input1Input.value;
          if (input1Value.length >= 1) {
              updateSoftKeys(true);
          } else {
              updateSoftKeys(false);
          }
      }

      return SettingsPanel({
          onInit(panel) {
              elements = {
                  panel,
                  input1Container: panel.querySelector('#input1-container'),
                  input1Input: panel.querySelector('#input1-input'),
              };
          },

          onBeforeShow(panel, options) {
              updateSoftKeys(false);
              if (!options.visibilityChange) {
                  cleanInputElement();
              }
              elements.panel.addEventListener('input', handleEvent);
              window.addEventListener('keydown', keydownHandler);
          },

          onBeforeHide() {
              elements.panel.removeEventListener('input', handleEvent);
              window.removeEventListener('keydown', keydownHandler);
          }
      });
  };
});
