/* global SimCardHelper DeviceCapabilityManager*/
'use strict';
define(function(require) { //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createSimManagerPanel() {
    let isDialogShow = false;
    let listElements = null;
    const conns = ApiManager.connections;
    const { eUiccManager } = ApiManager;
    let lastFocusElement = null;
    let shown = false;
    let currentPanel = null;
    let elements = null;
    const SimSettingsValue = {
      EMPTY_OPTION_TEXT: '--',
      EMPTY_OPTION_VALUE: -2,
      ALWAYS_ASK_OPTION_VALUE: -1
    };

    function outgoingDataHandleKeyDown(evt) {
      if (evt.key === 'Enter' && isDialogShow) {
        evt.preventDefault();
        evt.stopPropagation();
      }
    }

    function handleConfirmDlgEvents(evt) {
      switch (evt.type) {
        case 'gaia-confirm-open':
          isDialogShow = true;
          break;
        case 'gaia-confirm-close':
          isDialogShow = false;
          break;
        default:
          break;
      }
    }

    function updateSimCardUI(cardIndex) {
      const selectors = ['operator', 'number'];
      const cardSelector = `#sim-card-${cardIndex}`;
      const cardDom = elements.simCardContainer.querySelector(cardSelector);

      selectors.forEach(selector => {
        const targetSelector = `${cardSelector} .sim-card-${selector}`;
        const element = elements.simCardContainer.querySelector(targetSelector);

        // if (selector === 'name') {
        //   l10n.setAttributes(element, 'sim-with-index', {
        //     index: cardIndex + 1
        //   });
        //   return;
        // }

        const conn = conns[cardIndex];
        const icc = SimCardHelper.getIccInfo(cardIndex);

        // [GF5GTMO-7052] begin added by yuwei.fang, 2025-04-06
        if (selector === 'number') {
          SimCardHelper.getPhoneNumber(SimCardHelper.getIccId(cardIndex)).then(number => {
            element.textContent = number;
          });
          return;
        }
        // [GF5GTMO-7052] end added by yuwei.fang, 2025-04-06

        if (!icc) {
          element.textContent = '';
          element.setAttribute(
            'data-l10n-id',
            SimCardHelper.getCardDes('absent')
          );

          cardDom.classList.add('none-select');
          cardDom.setAttribute('aria-disabled', true);
          return;
        }

        const { cardState } = icc;
        if (cardState !== 'ready') {
          element.setAttribute(
            'data-l10n-id',
            SimCardHelper.getCardDes(cardState || 'null')
          );

          cardDom.classList.add('none-select');
          cardDom.setAttribute('aria-disabled', true);
          return;
        }

        SimCardHelper.getOperatorName(conn).then(name => {
          element.textContent = name;
        });
        cardDom.classList.remove('none-select');
        cardDom.setAttribute('aria-disabled', false);

        cardDom.setAttribute('id', `sim-card-${cardIndex}`);
      });
    }

    function updateeSimCardUI() {
      if (!eUiccManager) {
        return;
      }
      updateSimSecurity();
      eUiccManager.queryProfiles().then(
        profiles => {
          removeeSIMs();
          SettingsDBCache.getSetting('esim.test.mode.enabled').then(value => {
            const eSIMVerMode = !!value;
            let i = 0;
            for (let index = 0; index < profiles.length; index++) {
              const profile = profiles[index];
              if (profile.profileClass !== 'operational' && !eSIMVerMode) {
                continue;
              }

              const cardDom = elements.esimTemplate.cloneNode(true);
              // l10n.setAttributes(
              //   cardDom.querySelector('.sim-card-name'),
              //   'esim-with-index',
              //   {
              //     index: i + 1
              //   }
              // );
              cardDom.querySelector('.nick-name').textContent =
                profile.nickName || profile.spName;
              cardDom.setAttribute('id', `esim-card-${i++}`);
              cardDom.classList.add(profile.state);
              // [GF5GTMO-7052] begin added by yuwei.fang, 2025-04-06
              SimCardHelper.getPhoneNumber(profile.iccid).then(number => {
                cardDom.querySelector('.sim-card-number').textContent = number
              });
              // [GF5GTMO-7052] end added by yuwei.fang, 2025-04-06
              cardDom.classList.remove('hidden');
              cardDom.dataset.profileIndex = index;
              elements.esimCardContainer.insertBefore(
                cardDom,
                elements.addeSimButton
              );
            }
            elements.esimCardContainer.classList.remove('hidden');
            if (SimCardHelper.isDoubleSimSlot()) {
              DeviceCapabilityManager.get('device.euicc.slot-config').then(
                result => {
                  const esimIndex = result.split(',').indexOf('esim');
                  if (esimIndex === 0 || esimIndex === 1) {
                    const cardSelector = `#sim-card-${esimIndex}`;
                    const simCardDom = elements.simCardContainer.querySelector(
                      cardSelector
                    );
                    if (simCardDom) {
                      simCardDom.classList.add('hidden');
                      if (shown) {
                        NavigationMap.menuReset(lastFocusElement || null);
                      }
                    }
                  }
                }
              );
            } else {
              elements.simSettingsHeader.classList.remove('hidden');
            }
            updateSimSecurity();
            if (shown) {
              if (lastFocusElement) {
                const { id } = lastFocusElement;
                if (id && id.startsWith('esim-card-')) {
                  lastFocusElement = currentPanel.querySelector(`#${id}`);
                }
              }
              NavigationMap.menuReset(lastFocusElement || null);
            }
          });
        },
        error => {
          DebugHelper.debug(`queryProfiles error:${error}`);
        }
      );
    }

    // [GF5GTMO-7052] begin added by yuwei.fang, 2025-04-24
    function updateeSimPhoneNumber() {
      if (!eUiccManager) {
        return;
      }
      const activeEsimDom = elements.esimCardContainer.querySelector('.active');
      SimCardHelper.getPhoneNumber(SimCardHelper.getIccId(1/*eSIM slot index*/)).then(number => {
        activeEsimDom.querySelector('.sim-card-number').textContent = number
      });
      updateSelectOptionsUI();
    }
    // [GF5GTMO-7052] end added by yuwei.fang, 2025-04-24

    function updateSimSecurity() {
      const valid = SimCardHelper.hasValidCard();
      elements.simSecurity.disabled = !valid;
      if (valid) {
        elements.simSecurity.removeAttribute('aria-disabled');
        elements.simSecurity.classList.remove('none-select');
      } else {
        elements.simSecurity.setAttribute('aria-disabled', true);
        elements.simSecurity.classList.add('none-select');
      }
    }

    function removeeSIMs() {
      const eSims = elements.esimCardContainer.querySelectorAll('.sim-card');
      for (const eSim of eSims) {
        if (eSim.id !== 'esim-template') {
          elements.esimCardContainer.removeChild(eSim);
        }
      }
    }

    function updateSelectOptionsUI() {
      const iccCard1 = SimCardHelper.getIccInfo(0);
      const iccCard2 = SimCardHelper.getIccInfo(1);
      const cardState1 = iccCard1 && iccCard1.cardState;
      const cardState2 = iccCard2 && iccCard2.cardState;
      const isReady =
        (cardState1 === 'ready' && cardState2 === 'ready') || false;

      const list = [
        'limit.ril.data.defaultServiceId',
        'carrier.sim.match.result',
        'ril.telephony.defaultServiceId',
        'ril.sms.defaultServiceId',
        'ril.data.defaultServiceId'
      ];
      SettingsDBCache.getSettings(list, values => {
        const isLimit = values['limit.ril.data.defaultServiceId'] || false;
        const matchResult = values['carrier.sim.match.result'] || [
          false,
          false
        ];
        if (isReady) {
          if (isLimit && !(matchResult[0] && matchResult[1])) {
            disableDataItem(true);
          } else {
            disableDataItem(false);
          }
        } else {
          disableDataItem(true);
        }
        disableOtherItems(!isReady);

        const outgoingCallIndex = values['ril.telephony.defaultServiceId'] || 0;
        const outgoingMessagesIndex = values['ril.sms.defaultServiceId'] || 0;
        const outgoingDataIndex = values['ril.data.defaultServiceId'] || 0;
        updateSelectOptionUI(
          'outgoingCall',
          outgoingCallIndex,
          elements.outgoingCallSelect
        );
        updateSelectOptionUI(
          'outgoingMessages',
          outgoingMessagesIndex,
          elements.outgoingMessagesSelect
        );
        updateSelectOptionUI(
          'outgoingData',
          outgoingDataIndex,
          elements.outgoingDataSelect
        );
      });
    }

    function disableDataItem(enabled) {
      if (
        !(
          enabled === false &&
          !elements.outgoingCallSelect.disabled &&
          elements.outgoingDataSelect.disabled
        )
      ) {
        elements.outgoingDataSelect.disabled = enabled;
        elements.dataContainer.setAttribute('aria-disabled', enabled);
        if (enabled) {
          elements.dataContainer.classList.add('none-select');
        } else {
          elements.dataContainer.classList.remove('none-select');
        }
      }
    }

    function disableOtherItems(enabled) {
      elements.outgoingCallSelect.disabled = enabled;
      elements.callsContainer.setAttribute('aria-disabled', enabled);

      elements.outgoingMessagesSelect.disabled = enabled;
      elements.messagesContainer.setAttribute('aria-disabled', enabled);
      if (enabled) {
        elements.callsContainer.classList.add('none-select');
        elements.messagesContainer.classList.add('none-select');
      } else {
        elements.callsContainer.classList.remove('none-select');
        elements.messagesContainer.classList.remove('none-select');
      }
    }

    function updateSelectOptionUI(storageKey, selectedCardIndex, selectDOM) {
      // We have to remove old options first
      while (selectDOM.firstChild) {
        selectDOM.removeChild(selectDOM.firstChild);
      }

      // Then insert the new ones
      conns.forEach((conn, index) => {
        const option = document.createElement('option');
        option.value = index;
        const iccInfo = SimCardHelper.getIccInfo(index);
        if (
          // [GF5GTMO-7052] modified by yuwei.fang, 2025-05-06
          !iccInfo ||
          isSimCardBlocked(SimCardHelper.getIccInfo(index).cardState)
        ) {
          option.value = SimSettingsValue.EMPTY_OPTION_VALUE;
          option.text = SimSettingsValue.EMPTY_OPTION_TEXT;
        } else {
          // SimCardHelper.getOperatorName(conn).then(name => {
          //   l10n.setAttributes(option, 'sim-with-index-and-carrier', {
          //     carrier: name,
          //     index: index + 1
          //   });
          // });
          // [GF5GTMO-7051] begin added by yuwei.fang, 2025-04-30
          SimCardHelper.getSimCardInfo(conn).then(info => {
            option.text = info;
          });
          // [GF5GTMO-7051] begin added by yuwei.fang, 2025-04-30
        }

        if (index === selectedCardIndex) {
          option.selected = true;
        }
        selectDOM.add(option);
      });

      // We will add `always ask` option these two select
      if (storageKey === 'outgoingCall' || storageKey === 'outgoingMessages') {
        const option = document.createElement('option');
        option.value = SimSettingsValue.ALWAYS_ASK_OPTION_VALUE;
        option.setAttribute('data-l10n-id', 'sim-manager-always-ask');

        if (SimSettingsValue.ALWAYS_ASK_OPTION_VALUE === selectedCardIndex) {
          option.selected = true;
        }
        selectDOM.add(option);
      }
    }

    function isSimCardBlocked(cardState) {
      const uselessState = ['permanentBlocked'];
      return uselessState.indexOf(cardState) !== -1;
    }

    function initSimCardManagerUI() {
      updateSelectOptionsUI();
      for (let cardIndex = 0; cardIndex < conns.length; cardIndex++) {
        updateSimCardUI(cardIndex);
      }
    }

    function updateUI(evt) {
      const { type } = evt;
      const cardIndex = evt.detail.index;
      switch (type) {
        case 'SIM-datachange':
        case 'SIM-voicechange':
          updateSimCardUI(cardIndex);
          // [GF5GTMO-7052] added by yuwei.fang, 2025-04-23
          updateeSimPhoneNumber();
          break;
        case 'SIM-cardstatechange':
          updateSimCardUI(cardIndex);
          updateSelectOptionsUI();
          break;
        default:
          break;
      }
    }

    function handleClick(evt) {
      evt.stopPropagation();
      evt.preventDefault();
      const focusLi = currentPanel.querySelector('.focus');
      if (
        !focusLi.hasAttribute('aria-disabled') ||
        focusLi.getAttribute('aria-disabled') === 'false'
      ) {
        if (focusLi.id === 'sim-card-0') {
          Settings.setCurrentPanel('#simcard_name', {
            serviceId: 0
          });
        } else if (focusLi.id === 'sim-card-1') {
          Settings.setCurrentPanel('#simcard_name', {
            serviceId: 1
          });
        } else if (focusLi.id.startsWith('esim-card-')) {
          const index = parseInt(focusLi.id.replace('esim-card-', ''), 10);
          if (Number.isFinite(index)) {
            const profile = elements.esimCardContainer.querySelector('.active');
            let activeIndex = null;
            if (profile) {
              activeIndex = parseInt(profile.id.replace('esim-card-', ''), 10);
            }
            Settings.setCurrentPanel('#esimcard_manager', {
              index,
              profileIndex: parseInt(focusLi.dataset.profileIndex, 10),
              activeIndex
            });
          }
        } else if (focusLi.id === 'add-esim') {
          Settings.setCurrentPanel('#add_esim');
        }
      }
    }

    function handleEvent(evt) {
      const cardIndex = Number(evt.target.value);
      if (cardIndex === SimSettingsValue.EMPTY_OPTION_VALUE) {
        return;
      }

      switch (evt.target) {
        case elements.outgoingCallSelect:
          {
            const obj = {};
            obj['ril.telephony.defaultServiceId.iccId'] = null;
            obj['ril.voicemail.defaultServiceId.iccId'] = null;
            obj['ril.telephony.defaultServiceId'] = cardIndex;
            obj['ril.voicemail.defaultServiceId'] = cardIndex;
            SettingsDBCache.saveSettings(obj);
          }
          break;
        case elements.outgoingMessagesSelect:
          {
            const obj = {};
            obj['ril.sms.defaultServiceId.iccId'] = null;
            obj['ril.mms.defaultServiceId.iccId'] = null;
            obj['ril.sms.defaultServiceId'] = cardIndex;
            obj['ril.mms.defaultServiceId'] = cardIndex;
            SettingsDBCache.saveSettings(obj);
          }
          break;
        default:
          break;
      }
    }

    function outgoingDataChangeEvent(cardIndex) {
      elements.outgoingDataSelect.value = cardIndex;
    }

    function outgoingDataChangeHdr() {
      const lastChangeValue = elements.outgoingDataSelect.value;

      function onCancel() {
        elements.outgoingDataSelect.blur();
        SettingsDBCache.getSetting('ril.data.defaultServiceId').then(value => {
          const cardIndex = value || 0;
          updateSelectOptionUI(
            'outgoingData',
            cardIndex,
            elements.outgoingDataSelect
          );
        });
      }

      function onContinue() {
        elements.outgoingDataSelect.blur();
        elements.outgoingDataSelect.value = lastChangeValue;

        const newCardIndex = Number(elements.outgoingDataSelect.value);

        const obj = {};
        obj['ril.data.defaultServiceId'] = newCardIndex;
        const conn = conns[newCardIndex];
        const iccId = conn && conn.iccId;
        if (iccId) {
          obj['ril.data.defaultServiceId.iccId'] = iccId;
          SettingsDBCache.saveSettings(obj);
        }
      }

      const dialogConfig = {
        title: {
          id: 'confirmation',
          args: {}
        },
        body: {
          id: 'change-outgoing-data-confirm',
          args: {}
        },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback() {
            onCancel();
          }
        },
        confirm: {
          name: 'Continue',
          l10nId: 'continue',
          priority: 3,
          callback: () => {
            onContinue();
            elements.outgoingDataSelect.disabled = true;
            elements.dataContainer.setAttribute('aria-disabled', true);
            elements.dataContainer.classList.add('none-select');
            setTimeout(() => {
              elements.outgoingDataSelect.disabled = false;
              elements.dataContainer.setAttribute('aria-disabled', false);
              elements.dataContainer.classList.remove('none-select');
              SettingsSoftkey.show();
            }, 10000);
          }
        },

        backcallback: () => {
          onCancel();
        }
      };

      DialogHelper.show(dialogConfig);
    }

    function simcardNameChanged() {
      for (let cardIndex = 0; cardIndex < conns.length; cardIndex++) {
        updateSimCardUI(cardIndex);
      }
    }

    function handleIccChange() {
      // Only index 0 can  be changed
      updateSimCardUI(0);
      updateSelectOptionsUI();
      updateSimSecurity();
      ListFocusHelper.updateSoftkey();
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          simCardContainer: panel.querySelector('.sim-card-container'),
          esimCardContainer: panel.querySelector('.esim-card-container'),
          esimTemplate: panel.querySelector('#esim-template'),
          addeSimButton: panel.querySelector('#add-esim'),
          simSecurity: panel.querySelector('#sim-security'),
          simSettingsHeader: panel.querySelector(
            '.sim-security .sim-manager-settings-header'
          ),
          simSettingsList: panel.querySelector('.sim-manager-select-list'),
          callsContainer: document.getElementById('outgoing-calls-container'),
          outgoingCallSelect: panel.querySelector(
            '.sim-manager-outgoing-call-select'
          ),
          messagesContainer: document.getElementById(
            'outgoing-messages-container'
          ),
          outgoingMessagesSelect: panel.querySelector(
            '.sim-manager-outgoing-messages-select'
          ),
          dataContainer: document.getElementById('outgoing-data-container'),
          outgoingDataSelect: panel.querySelector(
            '.sim-manager-outgoing-data-select'
          ),
          sim1Selector: panel.querySelector('#sim-card-0'),
          sim2Selector: panel.querySelector('#sim-card-1')
        };

        elements.esimCardContainer.classList.add('hidden');
        elements.simSettingsHeader.classList.add('hidden');
        if (SimCardHelper.isDoubleSimSlot()) {
          initSimCardManagerUI();
          SettingsDBCache.observe(
            'custom.simcards.name',
            [],
            simcardNameChanged,
            true
          );
        } else {
          elements.simCardContainer.classList.add('hidden');
          elements.simSettingsList.classList.add('hidden');
        }
      },

      onBeforeShow(panel) {
        if (SimCardHelper.isDoubleSimSlot()) {
          window.addEventListener('SIM-datachange', updateUI);
          window.addEventListener('SIM-voicechange', updateUI);
          window.addEventListener('SIM-cardstatechange', updateUI);

          window.addEventListener('gaia-confirm-open', handleConfirmDlgEvents);
          window.addEventListener('gaia-confirm-close', handleConfirmDlgEvents);
          elements.dataContainer.addEventListener(
            'keydown',
            outgoingDataHandleKeyDown
          );

          elements.outgoingCallSelect.addEventListener('change', handleEvent);
          elements.outgoingMessagesSelect.addEventListener(
            'change',
            handleEvent
          );
          elements.outgoingDataSelect.addEventListener(
            'change',
            outgoingDataChangeHdr
          );

          SettingsDBCache.observe(
            'ril.data.defaultServiceId',
            null,
            outgoingDataChangeEvent
          );
        }
        currentPanel = panel;
        panel.addEventListener('click', handleClick);
        SettingsSoftkey.init(SoftParams.defaultSelect);
        SettingsSoftkey.show();
        listElements = document.querySelectorAll(
          '#simcard_manager li:not(.hidden)'
        );
        ListFocusHelper.addEventListener(listElements);
        if (SimCardHelper.isDoubleSimSlot()) {
          initSimCardManagerUI();
        }
        updateeSimCardUI();
        ListFocusHelper.updateSoftkey(panel);
        ApiManager.iccManager.addEventListener(
          'iccdetected',
          handleIccChange
        );
        ApiManager.iccManager.addEventListener(
          'iccundetected',
          handleIccChange
        );
      },

      onBeforeHide() {
        if (SimCardHelper.isDoubleSimSlot()) {
          window.removeEventListener('SIM-datachange', updateUI);
          window.removeEventListener('SIM-voicechange', updateUI);
          window.removeEventListener('SIM-cardstatechange', updateUI);

          window.removeEventListener(
            'gaia-confirm-open',
            handleConfirmDlgEvents
          );
          window.removeEventListener(
            'gaia-confirm-close',
            handleConfirmDlgEvents
          );
          elements.dataContainer.removeEventListener(
            'keydown',
            outgoingDataHandleKeyDown
          );

          currentPanel.removeEventListener('click', handleClick);
          elements.outgoingCallSelect.removeEventListener(
            'change',
            handleEvent
          );
          elements.outgoingMessagesSelect.removeEventListener(
            'change',
            handleEvent
          );
          elements.outgoingDataSelect.removeEventListener(
            'change',
            outgoingDataChangeHdr
          );
        }
        SettingsSoftkey.hide();
        ListFocusHelper.removeEventListener(listElements);
        lastFocusElement = currentPanel.querySelector('.focus');
        shown = false;
        ApiManager.iccManager.removeEventListener(
          'iccdetected',
          handleIccChange
        );
        ApiManager.iccManager.removeEventListener(
          'iccundetected',
          handleIccChange
        );
      },

      onShow() {
        shown = true;
        if (lastFocusElement) {
          const { id } = lastFocusElement;
          if (id && id.startsWith('esim-card-')) {
            lastFocusElement = currentPanel.querySelector(`#${id}`);
            NavigationMap.menuReset(lastFocusElement || null);
          }
        }
      },

      onUninit() {
        SettingsDBCache.unobserve('custom.simcards.name', simcardNameChanged);
      }
    });
  };
});
