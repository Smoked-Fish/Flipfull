/* GF5GTMO-4660-jianfeng.hao - Add VoNR for 5G TMO project on 2024/10/28 */
/* global SimCardHelper SupportedNetworkTypeHelper */
'use strict';
define(function(require) { //eslint-disable-line
  const SettingsPanel = require('modules/settings_panel');

  return function createVoNRMenuPanel() {
    let currentSettingsValue = false;

    let elements = null;
    let serviceIndex = 0;
    let mobileConnection = null;

    let switchOn = null;
    let switchOff = null;

    let isNrAvailable = true;

    function _enableVoNR() {
      const req = mobileConnection.setVoNrEnabled(true);
         req.onsuccess = () => {
           DebugHelper.log("_enableVoNR setVoNrEnabled success");
         };
         req.onerror = err => {
          DebugHelper.log(`_enableVoNR setVoNrEnabled error -${JSON.stringify(err)}`);
         };

         Settings.setCurrentPanel('#carrier_detail', {
          serviceId: serviceIndex
         });
    }

    function _disableVoNR() {
      const req = mobileConnection.setVoNrEnabled(false);
         req.onsuccess = () => {
           DebugHelper.log("_disableVoNR setVoNrEnabled success");
         };
         req.onerror = err => {
          DebugHelper.log(`_disableVoNR setVoNrEnabled error -${JSON.stringify(err)}`);
         };

         Settings.setCurrentPanel('#carrier_detail', {
          serviceId: serviceIndex
         });
    }

    function eventHandler(evt) {
      const enabled = evt.target.value === '1';
      if (currentSettingsValue === enabled) {
        evt.preventDefault();
        evt.stopPropagation();
        Settings.setCurrentPanel('#carrier_detail', {
          serviceId: serviceIndex
        });
        return;
      }

      const selector = evt.target;

      switch (selector.value) {
        case '1':
          evt.preventDefault();
          evt.stopPropagation();
          _enableVoNR();
          break;
        case '0':
          evt.preventDefault();
          evt.stopPropagation();
          _disableVoNR();
          break;
        default:
          // Do nothing for default case
          break;
      }
    }

    function keyDownHandler(evt) {
       DebugHelper.log('keyDownHandler: ' + evt.key + 'serviceId: ' + serviceIndex);
      switch (evt.key) {
        case 'Backspace':
          evt.preventDefault();
          evt.stopPropagation();
          Settings.setCurrentPanel('#carrier_detail', {
            serviceId: serviceIndex
          });
          break;
        default:
          break;
      }
    }

    return SettingsPanel({
      onInit(panel, options) {
        serviceIndex = options.serviceId;
        DebugHelper.log('vonr serviceIndex: ' + serviceIndex);
        mobileConnection = ApiManager.connections[serviceIndex];

        this.elements = {
          panel,
          params: {
            menuClassName: 'menu-button',
            header: { l10nId: 'message' },
            items: [
              {
                name: 'Cancel',
                l10nId: 'cancel',
                priority: 1,
                method() {
                  Settings.setCurrentPanel('#carrier_detail', {
                    serviceId: serviceIndex
                   });
                }
              },
              {
                name: 'Select',
                l10nId: 'select',
                priority: 2
              }
            ]
          }
        };
        this.initUI();
      },

      setValue(evt) {
        const enabled = evt.target.value === '1' || false;
        if (currentSettingsValue === enabled) {
          evt.preventDefault();
          evt.stopPropagation();
          Settings.setCurrentPanel('#carrier_detail', {
            serviceId: serviceIndex
          });
        }

        const option = {};
        Settings.setCurrentPanel('#carrier_detail');

        switchOn.checked = enabled;
        switchOff.checked = !enabled;
        ToastHelper.showToast('changessaved');
      },

      updateInfo(enabled) {
        currentSettingsValue = enabled;
        switchOn.checked = enabled;
        switchOff.checked = !enabled;
      },

      onBeforeShow(panel, options) {
        serviceIndex = options.serviceId;
        DebugHelper.log('vonr onBeforeShow serviceIndex: ' + serviceIndex);
        mobileConnection = ApiManager.connections[serviceIndex];

        SettingsSoftkey.init(this.elements.params);
        SettingsSoftkey.show();
        switchOn.addEventListener('click', eventHandler, true);
        switchOff.addEventListener('click', eventHandler, true);
        window.addEventListener('keydown', keyDownHandler, true);
      },

      onShow(panel, options) {
        if (!options.visibilityChange) {
          mobileConnection.isVoNrEnabled().then(result => {
            DebugHelper.log("onShow isVoNREnabled:" + result);
            const liItem = panel.querySelectorAll('li');
            if (result) {
              ListFocusHelper.requestFocus(panel, liItem[0]);
            } else {
              ListFocusHelper.requestFocus(panel, liItem[1]);
            }
            this.updateInfo(result);
          });
        }
      },

      onBeforeHide() {
        switchOn.removeEventListener('click', eventHandler, true);
        switchOff.removeEventListener('click', eventHandler, true);
        window.removeEventListener('keydown', keyDownHandler, true);
      },

      initUI() {
        switchOn = this.elements.panel.querySelector("li input[value='1']");
        switchOff = this.elements.panel.querySelector("li input[value='0']");
      }
    });
  };
});
