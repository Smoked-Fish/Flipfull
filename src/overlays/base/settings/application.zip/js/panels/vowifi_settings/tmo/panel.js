/* Task10128185-yanli.zhang@tcl.com-add wfc setting begin
 * Author: yanli.zhang@tcl.com
 * Date: 2020-11 */
'use strict';
define(function (require) {
    const SettingsPanel = require('modules/settings_panel');
    const SettingsService = require('modules/settings_service');

    return function vowifi_settings_panel() {
        var _preferredProfileContainer = document.getElementById('vowifi-preference-container');
        _preferredProfileContainer.classList.remove('hidden');
        var help = document.getElementById('vowifi-help');
        help.classList.remove('hidden');

        var elements = {};
        var translate = window.api.l10n.get;

        var _imsHandler = null;
        var cardIndex = 0;

        var l10n = null;

// Defect 10799804-rongjun.zheng@tcl.com-No error code is displayed in WFC menu.-begin
        var ErrorCodes = [
            {indexx:'2', code: 'ER02', errorMsgL10n: 'MsgDNSError'},   // errorMsg: 'ER02 – DNS Error'
            {indexx:'3', code: 'ER03', errorMsgL10n: 'MsgDNSError'},
            //{code: 'ER04', errorMsgL10n: 'MsgDNSError'}, // PR 7684833
            {indexx:'41', code: 'ER041', errorMsgL10n: 'MsgDNSError'},
            {indexx:'5', code: 'ER05', errorMsgL10n: 'MsgInvalidSIMCard'},
            // {indexx:'7', code: 'ER07', errorMsgL10n: 'MsgUnableToConnect'},//GF7TF-5024
            {indexx:'8', code: 'ER08', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'81', code: 'ER081', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'82', code: 'ER082', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'10', code: 'ER010', errorMsgL10n: 'MsgInvalidCertificate'},
            {indexx:'101', code: 'ER101', errorMsgL10n: 'MsgInvalidCertificate'},
            {indexx:'11', code: 'ER011', errorMsgL10n: 'MsgInvalidCertificate'},
            {indexx:'111', code: 'ER111', errorMsgL10n: 'MsgInvalidCertificate'},

            {indexx:'1701', code: 'REG09', errorMsgL10n: 'MsgMissing911'},
            {indexx:'500', code: 'REG91', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'403', code: 'REG90', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'90', code: 'REG90', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'901', code: 'REG901', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'902', code: 'REG902', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'903', code: 'REG903', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'904', code: 'REG904', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'905', code: 'REG905', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'91', code: 'REG91', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'99', code: 'REG99', errorMsgL10n: 'MsgUnableToConnect'},
            {indexx:'995', code: 'REG09', errorMsgL10n: 'MsgMissing911'}//GF5GTMO-6157 guanzhong.zhu.cd 2025/1/10
        ];
// Defect 10799804-rongjun.zheng@tcl.com-No error code is displayed in WFC menu.-end

        function _changeVowifiStatus(enabled) {
            debug("_changeVowifiStatus enabled:"+enabled);
            SettingsObserver.setValue([{name: 'vowifiUIEnable_'+cardIndex, value: enabled ? '1' : '0'}]);
            if (enabled) {
                //if enable vowifi, open ims as default
                var enableIms = SettingsObserver.setValue([{name: 'ril.ims.enabled', value: enabled}]);
                enableIms.then(
                    enableImsVal => {
                        _updateUI(true, null);
                    },
                    enableImsReject => {
                        debug('enableImsReject');
                    }
                );

            } else {
                var airplaneMode = SettingsObserver.getValue('airplaneMode.status');
                airplaneMode.then(airplaneModeVal => {
                  var ammm = airplaneModeVal;
                  if ((navigator.b2g.mobileConnections[cardIndex].radioState == 'disabled') && ammm == 'disabled') {
                    debug('disable vowifi when radio off and airplane mode off, enable radio');
                    navigator.b2g.mobileConnections[cardIndex].setRadioEnabled(true);
                  }
                });

                //if volte is off, disable ims, else do nothing
                var volteStatus2 = SettingsObserver.getValue('volte_item.ui.status');
                volteStatus2.then(volteStatus2Val => {
                    var volteValue2 = volteStatus2Val;
                    if (!volteValue2) {
                        debug('close ims in vowifi');
                        SettingsObserver.setValue([{name: 'ril.ims.enabled', value: enabled}]);
                    }
                });
                NavigationMap.navigateBack();
            }
            popUpToast();
        }

        function debug(msg) {
          console.log('wfc tmo settings panel,' + msg);
        }

        function _enableVowifi() {
            _changeVowifiStatus(true);
        }

        function _disableVowifi() {
            _changeVowifiStatus(false);
        }

        function _tmoPreferredClick() {
            Settings.setCurrentPanel('vowifi_tmo_preferred',{
              cardIndex: cardIndex
            })
        }
        function _tmoTopQuestionsClick(){
          Settings.setCurrentPanel('vowifi_tmo_top_questions',{
            cardIndex: cardIndex
          })
        }

        function _tmoTutorialClick(){
          Settings.setCurrentPanel('vowifi_tmo_tutorial_first',{
            cardIndex: cardIndex
          })
        }
        function popUpToast() {
            ToastHelper.showToast('changessaved',3000);
        }

        function detectImsStatus() {
            if (!_imsHandler) {
              return null;
            }
            debug('vowifi unregisteredReason:' + _imsHandler.unregisteredReason + '  capability = ' + _imsHandler.capability);

            if (_imsHandler && (!_imsHandler.unregisteredReason) && (!_imsHandler.wfcError)) {
              if (_imsHandler.capability === 'voice-over-wifi' || _imsHandler.capability === 'video-over-wifi') {
                return null; // No error, registration is successful
              }
            } else {
              var code = getErrorCode(_imsHandler.unregisteredReason);
              var errorMsg = getErrorMsg(code);
              if (!errorMsg && _imsHandler.wfcError === "ER082 - Unable to connect") {
                debug("wfcError ER082 - Unable to connect");
                code = getErrorCode('82');
                errorMsg = getErrorMsg(code);
              }
              if (!errorMsg) {
                debug('vowifi error code is not available!');
                return null;
              }
              debug('vowifi error code:' + errorMsg);


              const simOperator = OperatorUtils.getSimOperatorNameByIndex(cardIndex);
              if (simOperator === 'TMO') {
                _disableVowifiForError();
              }
              return errorMsg;
            }
            return null;
        };

        function _disableVowifiForError() {
          debug('_disableVowifiForError');

          SettingsObserver.setValue([{name: 'vowifiUIEnable_'+cardIndex, value: '0'}]);

          var airplaneModeC = SettingsObserver.getValue('airplaneMode.status');
          airplaneModeC.then(airplaneModeC => {
            var ammmC = airplaneModeC.result['airplaneMode.status'];
            if ((navigator.b2g.mobileConnections[cardIndex].radioState == 'disabled') && ammmC == 'disabled') {
              debug('_disableVowifiForError,disable vowifi when radio off and airplane mode off, enable radio');
              navigator.b2g.mobileConnections[cardIndex].setRadioEnabled(true);
            }
          });

          //if volte is off, disable ims, else do nothing
          var volteStatusC = SettingsObserver.getValue('volte_item.ui.status');
          volteStatusC.then(volteStatusCVal => {
              if (!volteValueC) {
                  debug("_disableVowifiForError, close ims in vowifi");
                  SettingsObserver.setValue([{name: 'ril.ims.enabled', value: false}]);
              }
          });
        }

        function getErrorMsg(code) {
          if (!code) {
            return null;
          }

          const upperCaseReason = code.toUpperCase();
          const errorCode = ErrorCodes.find(errorCode => upperCaseReason === errorCode.code);

          if (errorCode) {
            const msg = `${errorCode.code} - ${translate(errorCode.errorMsgL10n)}`;
            debug(`getErrorMsg reason: ${code} errorCode: ${errorCode.code}`);
            return msg;
          }

          return null;
        }

// Defect 10799804-rongjun.zheng@tcl.com-No error code is displayed in WFC menu.-begin
        function getErrorCode(reason) {
          if (!reason || reason === '0' || reason === 'GenericFailure') {
            return null;
          }

          const errorCode = ErrorCodes.find(errorCode => reason === errorCode.indexx);

          if (errorCode) {
            debug('getErrorCode reason:' + reason + ' errorCode:' + errorCode.code);
            return errorCode.code;
          }

          debug('getErrorCode code = null');
          return null;
        }
// Defect 10799804-rongjun.zheng@tcl.com-No error code is displayed in WFC menu.-end

        function _updateUI(clickEnableWfc, errorMsg) {
            SettingsDBCache.getSettings(['vowifiUIEnable_'+cardIndex, 'vowifiPreferred_'+cardIndex, 'ril.ims.enabled'],
                function (results) {
                    var vowifiUIEnabled = results['vowifiUIEnable_'+cardIndex];
                    var imsPrefer = results['vowifiPreferred_'+cardIndex];
                    var imsEnabled = results['ril.ims.enabled'];

                    // Defect 10667062-rongjun.zheng@tcl.com-WFC can register with TMO SIM even though the WFC is Off
                    //var isWFCEnabled = ((vowifiUIEnabled && imsEnabled) || clickEnableWfc) && errorMsg;
                    var isWFCEnabled = ((imsEnabled  && vowifiUIEnabled === '1') || clickEnableWfc) && !errorMsg;
                    debug('clickEnableWfc = ' + clickEnableWfc
                        + ',vowifiUIEnabled = ' + vowifiUIEnabled
                        + ',imsEnable = ' + imsEnabled + ',imsPrefer:' + imsPrefer
                        + ',isWFCEnabled = ' + isWFCEnabled
                        + ',errorMsg:' + errorMsg);

                    elements.vowifiRadioOn.checked = isWFCEnabled;
                    elements.vowifiRadioOff.checked = !isWFCEnabled;
                    var element = document.getElementById('vowifi-preference-container');
                    var hrefItem = element.querySelector('a');

                    if (isWFCEnabled) {
                        hrefItem.disabled = false;
                        element.removeAttribute('aria-disabled');
                        hrefItem.addEventListener('click', _tmoPreferredClick);
                        elements.vowifiUpdateE911Address.removeAttribute('aria-disabled');
                        elements.vowifiUpdateE911Address.addEventListener('click',_updateE911Address);
                    } else {
                        hrefItem.disabled = true;
                        hrefItem.removeEventListener('click',_tmoPreferredClick);
                        element.setAttribute('aria-disabled', true);
                        elements.vowifiUpdateE911Address.setAttribute('aria-disabled', true);
                        elements.vowifiUpdateE911Address.removeEventListener('click',_updateE911Address)
                    }
                    updateWFCSummary(errorMsg);
                    var buildOperatorName = OperatorUtils.getBuildOperatorName();
                    if(buildOperatorName === 'TF'){
                        elements.vowifiUpdateE911Address.classList.add('hidden');
                    }else{
                        elements.vowifiUpdateE911Address.classList.remove('hidden');
                    }
                    window.dispatchEvent(new CustomEvent('refresh'));
                }.bind(this)
            );
        }
        function onevent() {
          debug('unregisteredReason'+_imsHandler.unregisteredReason);
          var errorMsg = detectImsStatus();
          _updateUI(false, errorMsg);
        }

          //TCTTEL-2606-begin Wi-Fi calling status（GID-MTRREQ-5039）guanzhong.zhu.cd 2024/12/3
        function updateWFCSummary(errorMsg){
          if(errorMsg){
            elements.vowifiSummary.textContent = errorMsg;
            return;
          }
          SettingsDBCache.getSettings([ 'vowifiPreferred_'+cardIndex,'wifi.enabled'],
            function (results) {
              var wifiManager = navigator.b2g.wifiManager;
              if(!wifiManager){
                return;
              }
              var vowifiPerferred = results['vowifiPreferred_'+cardIndex];
              var wifiEnable = results['wifi.enabled'];
              if(elements.vowifiRadioOn.checked){
                elements.vowifiSummary.textContent = l10n.get('wfc_status_on');
                if(vowifiPerferred === 'cellular-preferred'){
                  elements.vowifiSummary.textContent = l10n.get('wfc_status_cellular');
                }
                if (_imsHandler.capability === 'voice-over-wifi' ||
                  _imsHandler.capability === 'video-over-wifi') {
                  // register success
                  elements.vowifiSummary.textContent = l10n.get('wfc_status_reg');
                  return;
                }
              }

              if(elements.vowifiRadioOff.checked && !_imsHandler.wfcError && !getErrorCode(_imsHandler.unregisteredReason)){
                elements.vowifiSummary.textContent = l10n.get('wfc_status_off');
                return;
              }
              if(!wifiEnable){
                elements.vowifiSummary.textContent = l10n.get('wfc_status_wifi_off');
                return;
              }
              if(wifiEnable && wifiManager.connection.status !== 'connected'){
                elements.vowifiSummary.textContent = l10n.get('wfc_status_wifi_not_connected');
                return;
              }
              // return Math.floor(
              //   ((strength - WifiConstants.MIN_RSSI) /
              //     (WifiConstants.MAX_RSSI - WifiConstants.MIN_RSSI)) *
              //   100
              // );
              // (（rssi- -100)/(-55- -100))*100 if rssi =-75， relSignalStrength=2500/45
              if(wifiManager.connectionInformation?.relSignalStrength < Math.floor(2500/45)){
                elements.vowifiSummary.textContent = l10n.get('wfc_status_wifi_poor_signal');
              }
            });
        }
        //TCTTEL-2606-end Wi-Fi calling status（GID-MTRREQ-5039）guanzhong.zhu.cd 2024/12/3
        //Defect-begin GF5GTMO-6025 need to support Update E911 Address menu guanzhong.zhu.cd 2024/12/30
        function _updateE911Address(){
            var e911Url = 'https://t-mo.co/2UT2voK';
            var operatorName = OperatorUtils.getSimOperatorNameByIndex(cardIndex);
            if(operatorName === 'TMO' || operatorName === 'ASW'){
              e911Url = 'https://t-mo.co/2UT2voK';
            }else if(operatorName === 'MetroPCS'){
              e911Url = 'https://t-mo.co/2VVEDVL';
            }
            //Defect-begin GF5GTMO-6190 cant open 'https://t-mo.co/2VVEDVL' address when use window.open func
            const activity = new WebActivity('view', { type: 'url', url: e911Url });
            activity.start();
            //Defect-end GF5GTMO-6190 cant open 'https://t-mo.co/2VVEDVL' address when use window.open func
        }
        //Defect-end GF5GTMO-6025 need to support Update E911 Address menu guanzhong.zhu.cd 2024/12/30
        return SettingsPanel({
            onInit: function (panel, options) {
                elements = {
                    vowifiRadioOn: document.getElementById('switch-on-vowifi'),
                    vowifiRadioOff: document.getElementById('switch-off-vowifi'),
                    vowifiUpdateE911Address: document.getElementById('vowifi-update-e911-address'),
                    vowifiContainer: document.getElementById('vowifi-preference-container'),
                    vowifiSelect: document.getElementById('vowifi-preferred-profile'),
                    vowifiSummary: document.getElementById('vowifi-summary'),
                    topQuestions: document.getElementById('vowifi-topquestions'),
                    tutorial: document.getElementById('vowifi-tutorial')
                };

                this.softkeyParams = {
                    menuClassName: 'menu-button',
                    header: {l10nId: 'message'},
                    items: [{
                        name: 'Select',
                        l10nId: 'select',
                        priority: 2,
                        method: function () {
                        }
                    }]
                };
            },

            onBeforeShow: function (panel, options) {
                if(options.cardIndex !== undefined && options.cardIndex !== null){
                  cardIndex = options.cardIndex;
                }
                debug("CardIndex:"+cardIndex);

                l10n = window.api.l10n;
                var errorMsg = detectImsStatus();
                _updateUI(false, errorMsg);

                _imsHandler = navigator.b2g.mobileConnections[cardIndex].imsHandler;
                if (_imsHandler) {
                  _imsHandler.addEventListener('capabilitychange',onevent)
                }
                elements.vowifiRadioOn.addEventListener('click', _enableVowifi);
                elements.vowifiRadioOff.addEventListener('click', _disableVowifi);
                elements.topQuestions.addEventListener('click',_tmoTopQuestionsClick)
                elements.tutorial.addEventListener('click',_tmoTutorialClick)
                SettingsSoftkey.init(this.softkeyParams);
                SettingsSoftkey.show();
                window.addEventListener('wifi-statuschange', onevent);
            },

            onBeforeHide: function () {
                if (_imsHandler) {
                  _imsHandler.removeEventListener('capabilitychange', onevent);
                }
                window.removeEventListener('wifi-statuschange', onevent);
                elements.vowifiRadioOn.removeEventListener('click', _enableVowifi);
                elements.vowifiRadioOff.removeEventListener('click', _disableVowifi);
                elements.topQuestions.removeEventListener('click',_tmoTopQuestionsClick)
                elements.tutorial.removeEventListener('click',_tmoTutorialClick)
                SettingsSoftkey.hide();
            }
        });
    };
});
