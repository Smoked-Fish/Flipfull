/* Task10128185-yanli.zhang@tcl.com-add wfc setting begin
 * Date: 2020-11 */

'use strict';
define(function (require) {
    var SettingsPanel = require('modules/settings_panel');
    var SettingsService = require('modules/settings_service');

    return function vowifi_preferred_panel() {
        var radioList = [];
        var _imsHandler;
        var _data;
        var cardIndex = 0;

        function debug(msg) {
          console.log('wfc tmo preferred panel,' + msg);
        }
        function _updateImsHandler() {
            _imsHandler = navigator.b2g.mobileConnections[cardIndex].imsHandler;
            _data = navigator.b2g.mobileConnections[cardIndex].data;
        }


        function checkWfc() {
            debug('checkWfc');
            SettingsDBCache.getSettings(['ril.ims.enabled', 'airplaneMode.status'],
                function (data) {
                    var imsStatus = data['ril.ims.enabled'];
                    var airplaneMode = data['airplaneMode.status'];

                    var imsPref = SettingsObserver.getValue('vowifiPreferred_'+cardIndex);
                    imsPref.then(imsPrefVal => {
                        if (imsStatus && (imsPrefVal === "wifi-only")) {
                            if (navigator.b2g.mobileConnections[cardIndex].radioState == 'enabled') {
                                debug('disable radio when choose wifi-only');
                                navigator.b2g.mobileConnections[cardIndex].setRadioEnabled(false);
                            }
                        } else {
                            if (airplaneMode === 'disabled' && navigator.b2g.mobileConnections[0].radioState == 'disabled') {
                                debug('enable radio when no airplaneMode and radio is disabled');
                                navigator.b2g.mobileConnections[cardIndex].setRadioEnabled(true);
                            }
                        }

                    });
                }.bind(this)
            );
        }


        function updateUI() {
            debug('updateUI');
            SettingsObserver.getValue(_data.roaming ? 'vowifiPreferredWhenRoaming_'+cardIndex : 'vowifiPreferred_'+cardIndex)
                .then((val) => {
                    for (var input of radioList) {
                        if (input.value != val) {
                            input.checked = false;
                        } else {
                            input.checked = true;
                            input.focus();
                        }
                    }
                });
        }

        function keyDownHandler(e) {
            if (e.key != 'Enter' || e.target.localName.toLowerCase() != 'li') return;
            var radio = e.target.querySelector('input');
            debug('keyDownHandler ' + radio.value);
            SettingsObserver.setValue([{
              name: 'vowifiPreferredWhenRoaming_'+cardIndex,
              value: radio.value
            },{
              name: 'vowifiPreferred_'+cardIndex,
              value: radio.value
            }
            ]).then(
              () => {
                checkWfc();
                updateUI();
                SettingsService.back();
              },
              () => {
                checkWfc();
                updateUI();
                SettingsService.back();
              }
            );
        }

        return SettingsPanel({
            onInit: function (panel,options) {
                radioList = panel.querySelectorAll('input');

                // option_cellular_only = panel.querySelector('#cellular_only');
                // option_cellular_only.hidden = true;
                // option_wifi_only = panel.querySelector('#wifi_only');
                // option_wifi_only.hidden = true;

                this.softkeyParams = {
                    menuClassName: 'menu-button',
                    header: {l10nId: 'message'},
                    items: [{
                        name: 'Select',
                        l10nId: 'select',
                        priority: 2,
                        method: function () {
                        }
                    }]
                };
            },

            onBeforeShow: function (panel,options) {
                if(options.cardIndex !== undefined && options.cardIndex !== null){
                  cardIndex = options.cardIndex;
                }
                debug("CardIndex:"+cardIndex);
                _updateImsHandler();
                updateUI();
                window.addEventListener('keydown', keyDownHandler);
                SettingsSoftkey.init(this.softkeyParams);
                SettingsSoftkey.show();
            },

            onBeforeHide: function () {
                window.removeEventListener('keydown', keyDownHandler);
                SettingsSoftkey.hide();
            }
        });
    };
});
