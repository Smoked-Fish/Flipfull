/* Task10128185-yanli.zhang@tcl.com-add wfc setting begin
 * Date: 2020-11 */
'use strict';

define(function (require) {
    var SettingsPanel = require('modules/settings_panel');
    var SettingsService = require('modules/settings_service');


    return function vowifi_top_questions_panel() {

        function initSoftKey() {
            var softkeyParams = {
                menuClassName: 'menu-button',
                header: {l10nId: 'fxa-options'},
                items: [
                    {
                        name: 'Done',
                        l10nId: 'done',
                        priority: 3,
                        method: function () {
                          SettingsService.back();
                        }
                    }
                ]
            };
            SettingsSoftkey.init(softkeyParams);
            SettingsSoftkey.show();
        }

        function resetSoftkey() {
            var softkeyParams = {
                menuClassName: 'menu-button',
                header: {l10nId: 'fxa-options'},
                items: [
                    {
                        name: 'Select',
                        l10nId: 'select',
                        icon: 'ok',
                        priority: 2,
                        method: function () {
                        }
                    }
                ]
            };
            SettingsSoftkey.init(softkeyParams);
            SettingsSoftkey.show();
        }

        return SettingsPanel({
            onInit: function (panel) {
                var item_wfc_topquestion_p1 = document.getElementById('wfc_topquestion_p1');
                var item_wfc_topquestion_p3 = document.getElementById('wfc_topquestion_p3');
                var item_wfc_topquestion_p4 = document.getElementById('wfc_topquestion_p4');
                if(navigator.b2g.engmodeManager){
                  navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name').then(
                    (operatorNameValue) => {
                      if ('MetroPCS' === operatorNameValue) {
                        item_wfc_topquestion_p1.setAttribute('data-l10n-id', 'wfc_topquestion_metropcs_p1');
                        item_wfc_topquestion_p4.setAttribute('data-l10n-id', 'wfc_topquestion_metropcs_p4');
                        //zhijun.ye@tcl.com for Defect10745364-begin
                      } else if ('TMO' === operatorNameValue) {
                        // Defect 11043431-rongjun.zheng-The string is shown as 'T-Mobile' for MPCS SW in Top questions screen.-begin
                        let connection = navigator.b2g.mobileConnections;
                        let iccInfo ;
                        if (connection[0]) {
                          let iccId = connection[0].iccId;
                          if (iccId) {
                            iccInfo = navigator.b2g.iccManager.getIccById(iccId).iccInfo;
                          }
                          if(!iccInfo){
                            return;
                          }
                          let gid1 = iccInfo.gid1;
                          let isMtroPcs = false;
                          if(gid1=='6D38'||gid1=='6d38'){
                            isMtroPcs = true ;
                          }
                          if(isMtroPcs){
                            item_wfc_topquestion_p1.setAttribute('data-l10n-id', 'wfc_topquestion_metropcs_p1');
                            item_wfc_topquestion_p4.setAttribute('data-l10n-id', 'wfc_topquestion_metropcs_p4');
                          }
                        }
                        // Defect 11043431-rongjun.zheng-The string is shown as 'T-Mobile' for MPCS SW in Top questions screen.-end
                        //zhijun.ye@tcl.com for Defect10745364-end
                      } else {
                        item_wfc_topquestion_p1.setAttribute('data-l10n-id', 'wfc_topquestion_new_p1');
                        //item_wfc_topquestion_p3.setAttribute('data-l10n-id','wfc_topquestion_new_p3');
                        item_wfc_topquestion_p4.setAttribute('data-l10n-id', 'wfc_topquestion_new_p4');
                      }
                    }
                  );
                }
            },

            onBeforeShow: function () {
                initSoftKey();
            },

            onBeforeHide: function () {
                resetSoftkey();
            }
        });
    };
});
