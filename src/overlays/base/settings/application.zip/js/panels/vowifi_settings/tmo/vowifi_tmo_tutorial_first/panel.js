/* Task10128185-yanli.zhang@tcl.com-add wfc setting begin
 * Date: 2020-11 */
'use strict';

define(function (require) {
    var SettingsPanel = require('modules/settings_panel');
    var SettingsService = require('modules/settings_service');

    return function vowifi_tutorial_panel() {
        var firstDiv;
        var cardIndex = 0;

        function debug(msg) {
          console.log('wfc tmo tutorial first panel,' + msg);
        }

        function keyDownHandler(e) {
            if (e.key == 'BrowserBack' || e.key == 'Backspace') {
                e.stopPropagation();
                event.preventDefault();
            }
        }

        function initSoftKey(type) {
            var softkeyParams = {};
            softkeyParams = {
                menuClassName: 'menu-button',
                header: {l10nId: 'fxa-options'},
                items: [
                    {
                        name: 'Back',
                        l10nId: 'back',
                        priority: 1,
                        method: function () {
                          SettingsService.back();
                        }
                    },
                    {
                        name: 'Next',
                        l10nId: 'next',
                        priority: 3,
                        method: function () {
                            Settings.setCurrentPanel('vowifi_tmo_tutorial_next',{
                              cardIndex: cardIndex
                            })
                        }
                    }
                ]
            };
            SettingsSoftkey.init(softkeyParams);
            SettingsSoftkey.show();
        }

        function resetSoftkey() {
            var softkeyParams = {
                menuClassName: 'menu-button',
                header: {l10nId: 'fxa-options'},
                items: [
                    {
                        name: 'Select',
                        l10nId: 'select',
                        icon: 'ok',
                        priority: 2,
                        method: function () {
                        }
                    }
                ]
            };
            SettingsSoftkey.init(softkeyParams);
            SettingsSoftkey.show();
        }

        function updateUI() {
            initSoftKey();
        }

        return SettingsPanel({
            onInit: function (panel,options) {
                firstDiv = document.querySelector('#tutorial_first');

            },

            onBeforeShow: function (panel,options) {
                if(options.cardIndex !== undefined && options.cardIndex !== null) {
                  cardIndex = options.cardIndex;
                }
                debug("CardIndex:"+cardIndex);
                updateUI();
            },

            onBeforeHide: function () {
                resetSoftkey();
            }
        });
    };
});
