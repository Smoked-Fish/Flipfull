/* global SimCardHelper OptionMenu */
'use strict';
// eslint-disable-next-line
window.WfcSimOptionMenuHelper = (function WfcSimOptionMenuHelper() {
  let optionMenu = null;

  const getCarrierInfo = index => {
    const icc = SimCardHelper.getIccInfo(index);
    const info = {};
    if (!icc) {
      info.name = l10n.get('sim-with-index-and-carrier', {
        index: index + 1,
        carrier: l10n.get(SimCardHelper.getCardDes('absent'))
      });
      info.disable = true;
      return info;
    }
    const { cardState } = icc;
    if (cardState !== 'ready') {
      info.name = l10n.get('sim-with-index-and-carrier', {
        index: index + 1,
        carrier: l10n.get(SimCardHelper.getCardDes(cardState || 'null'))
      });
      info.disable = true;
      return info;
    }
    return SimCardHelper.getSimCardInfo(ApiManager.connections[index]).then(
        carrier => {
          // info.name = l10n.get('sim-with-index-and-carrier', {
          //   index: index + 1,
          //   carrier
          // });
          //[GF5GTMO-7051] added by guanzhong.zhu.cd, 2025-04-06
          info.name = carrier
          info.disable = false;
          return info;
        }
    );
  };

  const show = async callback => {
    if (!SimCardHelper.isDoubleSimSlot()) {
      if (typeof callback === 'function') {
        callback();
      }
      return;
    }
    const handleBackKey = (event) => {
      if (event.key === 'Backspace') {
        event.preventDefault();
        hide();
      }
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        hide();
      }
    };

    const params = {
      classes: ['group-menu', 'softkey', 'wfc-sim-menu'],
      header: l10n.get('select') || '',
      items: []
    };
    for (let index = 0; index < ApiManager.connections.length; index++) {
      // eslint-disable-next-line no-await-in-loop
      const item = await getCarrierInfo(index);
      item.method = () => {
        if (!item.disable && typeof callback === 'function') {
          callback(index);
        }
      };
      params.items.push(item);
    }
    optionMenu = new OptionMenu(params);
    optionMenu.show();

    document.addEventListener('keydown', handleBackKey);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    const originalHide = optionMenu.hide.bind(optionMenu);
    optionMenu.hide = () => {
      document.removeEventListener('keydown', handleBackKey);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      originalHide();
    };

    SettingsSoftkey.init(SoftParams.defaultSelect);
    SettingsSoftkey.show();
    secondCall = false;// eslint-disable-line
  };

  const isShown = () => {
    return (
      optionMenu &&
      optionMenu.form &&
      optionMenu.form.classList.contains('visible')
    );
  };

  const hide = () => {
    if (isShown()) {
      optionMenu.hide();
    }
  };

  return {
    show,
    hide,
    isShown
  };
})();
