/* global WifiHelper */

'use strict';
// eslint-disable-next-line
define(function(require) {
  const SettingsPanel = require('modules/settings_panel');
  const WifiWps = require('panels/wifi/wifi_wps');
  const WifiContext = require('modules/wifi/wifi_context');
  const wifiManager = WifiHelper.getWifiManager();
  const WifiUtils = require('modules/wifi/wifi_utils');
  return function ctorWifi() {
    let elements = null;
    let wifiEnabled = true;
    let wpsBackKey = false;
    let changeWifi = false;

    function onWpsStatusReset() {
      elements.wps.wpsPbcLabelBlock.setAttribute('data-l10n-id', 'wpsMessage');
    }

    return SettingsPanel({
      onInit(panel, options) {
        this.networkListPromise = null;
        this.networks = {};
        this.inProgress = false;
        elements = {
          panel,
          options,
          wifi: panel,
          wifiOn: panel.querySelector('.wifi-on'),
          wifiOff: panel.querySelector('.wifi-off'),
          wpsColumn: panel.querySelector('.wps-column'),
          wpsInfoBlock: panel.querySelector('.wps-column small'),
          wpsPbcLabelBlock: panel.querySelector('.wps-column span'),
          wifiBtn: [].slice.apply(
            panel.querySelectorAll('input[name="wifi-enabled"]')
          ),
          wifiAvailableNetworks: panel.querySelector('.availableNetworks'),
          advancedSettings: panel.querySelector('.advancedSettings'),
          items: panel.querySelectorAll('li')
        };

        if (ActivityHandler.currentActivity) {
          if (ActivityHandler.activityPanelId === 'connectivity_settings') {
            const header = panel.querySelector('gaia-header');
            header.setAttribute('data-href', '#connectivity_settings');
          }
        }

        const wpsColumnSmall = panel.querySelector('.wps-column small');
        wpsColumnSmall.setAttribute(
          'data-l10n-id',
          Customization.getWifiCertifiedStrId(
            'wpsDescription2',
            'wlan-wpsDescription2'
          )
        );
        const headerItem = panel.querySelector('gaia-header h1');
        headerItem.setAttribute(
          'data-l10n-id',
          Customization.getWifiCertifiedStrId('wifi-header', 'wlan-header')
        );

        elements.wps = {
          wpsColumn: elements.wpsColumn,
          wpsInfoBlock: elements.wpsInfoBlock,
          wpsPbcLabelBlock: elements.wpsPbcLabelBlock
        };
        elements.wifiOn.classList.remove('hidden');
        elements.wifiOff.classList.remove('hidden');
        SettingsDBCache.getSetting('wifi.enabled').then(value => {
          const enabled = value;
          wifiEnabled = enabled;
          if (enabled) {
            elements.wifiBtn[0].checked = true;
            this.setSettingsEnabled(enabled);
          } else {
            elements.wifiBtn[1].checked = true;
            elements.wpsColumn.classList.add('hidden');
            elements.wifiAvailableNetworks.classList.add('hidden');
            elements.advancedSettings.classList.add('hidden');
          }
          window.dispatchEvent(new CustomEvent('refresh'));
        });

        SettingsDBCache.observe('settings.wlan.enabled', false, enabled => {
          WifiUtils.wlanEnabled = enabled;
        });

        this.wps = WifiWps();
        // Element related events
        elements.wifiBtn.forEach(checkbox => {
          checkbox.onclick = this.saveWifi.bind(this);
        });

        // WifiContext related events
        WifiContext.addEventListener('wifiEnabled', () => {
          elements.wifiBtn.forEach(btn => {
            btn.disabled = false;
          });
          this.setSettingsEnabled(true);
          this.updateNetworkState(null, true);
          window.dispatchEvent(new CustomEvent('refresh'));
        });

        WifiContext.addEventListener('wifiDisabled', () => {
          elements.wifiBtn.forEach(btn => {
            btn.disabled = false;
          });
          window.dispatchEvent(new CustomEvent('refresh'));
        });

        this.boundWifiEnabled = enabled => {
          wifiEnabled = enabled;
          if (wifiEnabled) {
            elements.wifiBtn[0].checked = true;
          } else {
            elements.wifiBtn[1].checked = true;
          }
          if (enabled) {
            this.updateNetworkState(null, true);
          } else {
            this.setSettingsEnabled(enabled);
          }
        };
        this.handleKeydown = this.handleKeydown.bind(this);
        this.updateNetworkState = this.updateNetworkState.bind(this);
        this.handleFocusChanged = this.handleFocusChanged.bind(this);
      },
      onBeforeShow(panel, options) {
        elements.options = options;
        if (elements.options && elements.options.wpsInfoBlock) {
          this.inProgress = elements.options.inProgress;
          elements.wpsInfoBlock.setAttribute(
            'data-l10n-id',
            options.wpsInfoBlock
          );
          if (options.args) {
            elements.wpsInfoBlock.setAttribute(
              'data-l10n-args',
              JSON.stringify(options.args)
            );
          }

          if (options.succ) {
            elements.wifiAvailableNetworks.children[0].removeAttribute('href');
            elements.advancedSettings.children[0].removeAttribute('href');
          }

          this.updateSoftKeyStop.bind(this)();
        } else {
          elements.wpsInfoBlock.setAttribute(
            'data-l10n-id',
            Customization.getWifiCertifiedStrId(
              'wpsDescription2',
              'wlan-wpsDescription2'
            )
          );
          this.initSoftKey();
        }
        SettingsDBCache.observe(
          'wifi.enabled',
          true,
          this.boundWifiEnabled,
          true
        );
      },

      onShow(panel, options) {
        if (!options.visibilityChange) {
          this.updateEnableHigtlight();
        }
        WifiContext.addEventListener(
          'wifiStatusChange',
          this.updateNetworkState
        );
        this.wps.addEventListener('statusreset', onWpsStatusReset);
        window.addEventListener('keydown', this.handleKeydown, true);
        document.addEventListener('focusChanged', this.handleFocusChanged);
      },
      onBeforeHide() {
        SettingsDBCache.unobserve('wifi.enabled', this.boundWifiEnabled);
        window.removeEventListener('keydown', this.handleKeydown, true);
        document.removeEventListener('focusChanged', this.handleFocusChanged);
      },

      onHide() {
        WifiContext.removeEventListener(
          'wifiStatusChange',
          this.updateNetworkState
        );
        this.wps.removeEventListener('statusreset', onWpsStatusReset);
      },

      handleKeydown(e) {
        let btn = null;
        switch (e.key) {
          case 'Enter':
            if (
              this.inProgress &&
              (elements.panel.querySelector('.focus.availableNetworks') ||
                elements.panel.querySelector('.focus.advancedSettings'))
            ) {
              this.wpsConnectingDialog.bind(this)();
              break;
            }

            btn = elements.panel.querySelector('.focus input');
            if (btn) {
              e.preventDefault();
              e.stopPropagation();
              elements.panel.querySelector('.focus').focus();
              const header = document.querySelectorAll('.current [data-href]');
              const currenId = header[0].getAttribute('data-href');
              setTimeout(() => {
                if (btn.value === 'false' && btn.checked) {
                  /*
                   * When other app enter "Settings Configure Activity",
                   * this page can back normal.
                   */
                  if (currenId === '#connectivity_settings') {
                    Settings.setCurrentPanel('connectivity_settings');
                  }
                }
              }, 500);
            } else if (
              elements.panel
                .querySelector('.focus')
                .classList.contains('wps-column')
            ) {
              this.onWpsColumnClick.bind(this)();
            }
            break;
          case 'BrowserBack':
          case 'Backspace':
            if (NavigationMap.currentActivatedLength <= 0) {
              e.preventDefault();
              e.stopPropagation();
              if (this.inProgress) {
                wpsBackKey = true;
                this.wpsConnectingDialog.bind(this)();
              } else {
                NavigationMap.navigateBack();
              }
            }
            break;
          default:
            break;
        }
      },

      handleFocusChanged() {
        if (
          elements.panel.querySelector('.wps-column.focus') &&
          this.inProgress
        ) {
          this.updateSoftKeyStop.bind(this)();
        } else {
          this.initSoftKey();
        }
      },

      updateEnableHigtlight() {
        if (Settings.isBackHref) {
          return;
        }

        SettingsDBCache.getSetting('wifi.enabled').then(value => {
          const liItem = value ? elements.items[0] : elements.items[1];
          ListFocusHelper.requestFocus(elements.panel, liItem);
        });
      },

      initSoftKey() {
        const softkeyParams = {
          menuClassName: 'menu-button',
          header: {
            l10nId: 'message'
          },
          items: [
            {
              name: 'Select',
              l10nId: 'select',
              priority: 2,
              method() {
                if (Settings.getCurrentPanel() === '#wifi') {
                  const checkbox = elements.panel.querySelector(
                    'li.focus input'
                  );
                  if (checkbox) {
                    checkbox.click();
                  }
                }
              }
            }
          ]
        };
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
      },
      updateSoftKeyStop() {
        const softkeyParams = {
          menuClassName: 'menu-button',
          header: {
            l10nId: 'message'
          },
          items: [
            {
              name: 'Stop',
              l10nId: 'stop',
              priority: 3,
              method: () => {
                this.stopWpsConnect.bind(this)();
              }
            }
          ]
        };
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
      },

      wpsFailedDialog() {
        const dialogConfig = {
          title: {
            id: Customization.getWifiCertifiedStrId(
              'wpsFailedDialogTitle',
              'wlan-wpsFailedDialogTitle'
            ),
            args: {}
          },
          body: {
            id: 'wpsFailedDialogBody',
            args: {}
          },
          accept: {
            l10nId: 'ok',
            priority: 2,
            callback() {
              DialogHelper.destroy();
            }
          }
        };

        DialogHelper.show(dialogConfig);
      },

      wpsConnectingDialog() {
        const dialogConfig = {
          title: {
            id: Customization.getWifiCertifiedStrId(
              'wpsConnectingDialogTitle',
              'wlan-wpsConnectingDialogTitle'
            ),
            args: {}
          },
          body: {
            id: 'wpsConnectingDialogBody',
            args: {}
          },
          backcallback() {
            wpsBackKey = false;
            DialogHelper.destroy();
          },
          cancel: {
            name: 'Yes',
            l10nId: 'yes',
            priority: 1,
            callback: () => {
              this.stopWpsConnect.bind(this)();
            }
          },
          confirm: {
            name: 'No',
            l10nId: 'no',
            priority: 3,
            callback() {
              wpsBackKey = false;
              DialogHelper.destroy();
            }
          }
        };

        DialogHelper.show(dialogConfig);
      },

      updateNetworkState(e, isWifiEnable) {
        // Update network state, called only when wifi enabled.
        const networkStatus = wifiManager.connection.status;
        const { network } = wifiManager.connection;
        const { ssid } = elements.wpsInfoBlock.dataset;
        if (isWifiEnable) {
          this.updateWpsItem();
          return;
        }

        if (this.inProgress) {
          if (networkStatus !== 'disconnected') {
            elements.wpsInfoBlock.setAttribute(
              'data-l10n-id',
              WifiContext.wifiStatusText.id
            );
            if (WifiContext.wifiStatusText.args) {
              elements.wpsInfoBlock.setAttribute(
                'data-l10n-args',
                JSON.stringify(WifiContext.wifiStatusText.args)
              );
            } else {
              elements.wpsInfoBlock.removeAttribute('data-l10n-args');
            }
          }
          if (networkStatus === 'connected') {
            elements.wpsInfoBlock.dataset.ssid = network.ssid;
          }
          if (
            networkStatus === 'connected' ||
            networkStatus === 'wps-timedout' ||
            networkStatus === 'wps-failed' ||
            networkStatus === 'wps-overlapped'
          ) {
            this.inProgress = false;
            elements.wifiAvailableNetworks.children[0].setAttribute(
              'href',
              '#wifi_available_networks'
            );
            elements.advancedSettings.children[0].setAttribute(
              'href',
              '#wifi_advanced_settings'
            );
            if (NavigationMap.currentActivatedLength > 0) {
              DialogHelper.destroy();
            }
            this.wps.statusReset();
            this.initSoftKey();
            if (networkStatus === 'wps-failed') {
              this.wpsFailedDialog();
            }
          }
        } else if (
          networkStatus === 'disconnected' ||
          (networkStatus === 'connected' && ssid !== network.ssid)
        ) {
          this.updateWpsItem();
        }
      },

      updateWpsItem() {
        elements.wpsInfoBlock.dataset.ssid = null;
        elements.wpsInfoBlock.removeAttribute('data-l10n-args');
        elements.wpsPbcLabelBlock.setAttribute('data-l10n-id', 'wpsMessage');
        elements.wpsInfoBlock.setAttribute(
          'data-l10n-id',
          Customization.getWifiCertifiedStrId(
            'wpsDescription2',
            'wlan-wpsDescription2'
          )
        );
      },

      setSettingsEnabled(enabled) {
        if (enabled) {
          /**
           * WifiManager may not be ready (enabled) at this moment.
           * To be responsive, show 'initializing' status and 'search...'
           * first. A 'scan' would be called when wifiManager is enabled.
           */
          elements.wpsColumn.classList.remove('hidden');
          elements.wifiAvailableNetworks.classList.remove('hidden');
          elements.advancedSettings.classList.remove('hidden');
        } else {
          if (this.inProgress) {
            elements.wpsInfoBlock.setAttribute(
              'data-l10n-id',
              WifiContext.wifiStatusText.id
            );
            if (WifiContext.wifiStatusText.args) {
              elements.wpsInfoBlock.setAttribute(
                'data-l10n-args',
                JSON.stringify(WifiContext.wifiStatusText.args)
              );
            } else {
              elements.wpsInfoBlock.removeAttribute('data-l10n-args');
            }
          }
          elements.wpsColumn.classList.add('hidden');
          elements.wifiAvailableNetworks.classList.add('hidden');
          elements.advancedSettings.classList.add('hidden');
        }
        window.dispatchEvent(new CustomEvent('refresh'));
      },

      processHotspotAndUsbTethering(ipt, checked) {
        SettingsDBCache.getSettings(
          ['tethering.wifi.enabled', 'tethering.usb.enabled'],
          results => {
            const wifiHotspot = results['tethering.wifi.enabled'];
            const usbTether = results['tethering.usb.enabled'];
            const cancelPro = () => {
              elements.wifiBtn[0].checked = false;
              elements.items[0].classList.remove('focus');
              elements.wifiBtn[1].checked = true;
              elements.items[1].classList.add('focus');
              elements.items[1].focus();
            };

            if (wifiHotspot || usbTether) {
              let bodyL10n = null;
              if (wifiHotspot) {
                bodyL10n = Customization.getWifiCertifiedStrId(
                  'wifi-hotspot-dialog',
                  'wlan-hotspot-dialog'
                );
              } else if (usbTether) {
                bodyL10n = 'wifi-usb-dialog';
                bodyL10n = Customization.getWifiCertifiedStrId(
                  'wifi-usb-dialog',
                  'wlan-usb-dialog'
                );
              }

              const dialogConfig = {
                title: {
                  id: Customization.getWifiCertifiedStrId('wifi', 'wlan'),
                  args: {}
                },
                body: {
                  id: bodyL10n,
                  args: {}
                },
                cancel: {
                  name: 'Cancel',
                  l10nId: 'cancel',
                  priority: 1,
                  callback() {
                    cancelPro();
                  }
                },
                confirm: {
                  name: 'Turn On',
                  l10nId: 'turnOn',
                  priority: 3,
                  callback: () => {
                    if (wifiHotspot) {
                      SettingsDBCache.saveSettings({
                        'tethering.wifi.enabled': false
                      });
                    } else if (usbTether) {
                      SettingsDBCache.saveSettings({
                        'tethering.usb.enabled': false
                      });
                    }
                    this.saveWifiProcess(ipt, checked);
                  }
                },
                backcallback() {
                  cancelPro();
                }
              };

              DialogHelper.show(dialogConfig);
            } else {
              this.saveWifiProcess(ipt, checked);
            }
          }
        );
      },

      saveWifiProcess(ipt, checked) {
        ipt.checked = true;
        SettingsDBCache.saveSettings({
          'wifi.enabled': checked
        });
        ToastHelper.showToast('changessaved');
        elements.wifiBtn.forEach(btn => {
          btn.disabled = true;
        });
      },

      saveWifi(e) {
        // `this` is Wifi Object
        if (changeWifi) {
          return;
        }
        changeWifi = true;

        setTimeout(() => {
          changeWifi = false;
        }, 500);

        const ipt = e.target;
        const checked = ipt.value === 'true';
        if (wifiEnabled === checked) {
          return;
        }

        if (checked) {
          this.processHotspotAndUsbTethering(ipt, checked);
        } else {
          this.saveWifiProcess(ipt, checked);
        }
      },

      wpsPanelNavigate() {
        if (wpsBackKey) {
          wpsBackKey = false;
          if (ActivityHandler.currentActivity) {
            ActivityHandler.postResult();
          } else {
            Settings.setCurrentPanel('root');
          }
        } else if (elements.panel.querySelector('.focus.availableNetworks')) {
          Settings.setCurrentPanel('wifi_available_networks');
        } else if (elements.panel.querySelector('.focus.advancedSettings')) {
          Settings.setCurrentPanel('wifi_advanced_settings');
        }
      },

      stopWpsConnect() {
        if (this.inProgress) {
          this.wps.cancel({
            onSuccess: () => {
              this.inProgress = false;
              elements.wifiAvailableNetworks.children[0].setAttribute(
                'href',
                '#wifi_available_networks'
              );
              elements.advancedSettings.children[0].setAttribute(
                'href',
                '#wifi_advanced_settings'
              );
              this.initSoftKey();
              elements.wpsInfoBlock.setAttribute(
                'data-l10n-id',
                'fullStatus-wps-canceled'
              );
              this.wpsPanelNavigate();
            },
            onError: error => {
              this.inProgress = false;
              this.initSoftKey();
              l10n.setAttributes(
                elements.wpsInfoBlock,
                'wpsCancelFailedMessageError',
                {
                  error: error.name
                }
              );
            }
          });
        }
      },

      onWpsColumnClick() {
        const small = elements.panel.querySelector('.focus small');

        if (
          small &&
          small.textContent === l10n.get('fullStatus-wps-canceled')
        ) {
          elements.wpsInfoBlock.removeAttribute('data-l10n-args');
          elements.wpsPbcLabelBlock.setAttribute('data-l10n-id', 'wpsMessage');
          elements.wpsInfoBlock.setAttribute(
            'data-l10n-id',
            Customization.getWifiCertifiedStrId(
              'wpsDescription2',
              'wlan-wpsDescription2'
            )
          );
        } else if (!this.inProgress) {
          Settings.setCurrentPanel('#wifi_wps');
        }
      },

      _netWorksList() {
        // Stop auto-scanning if wifi disabled or the app is hidden
        if (!wifiManager.enabled || document.hidden) {
          return;
        }
        if (!this.networkListPromise) {
          this.networkListPromise = new Promise(resolve => {
            const req = WifiHelper.getAvailableAndKnownNetworks();

            req.onsuccess = () => {
              const allNetworks = req.result;
              let network = null;

              for (let i = 0; i < allNetworks.length; ++i) {
                network = allNetworks[i];
                const key = WifiUtils.getNetworkKey(network);
                // Keep connected network first, or select the highest strength
                if (!this.networks[key] || network.connected) {
                  this.networks[key] = network;
                } else if (
                  !this.networks[key].connected &&
                  network.relSignalStrength >
                    this.networks[key].relSignalStrength
                ) {
                  this.networks[key] = network;
                }
              }
              resolve();
            };
          });
        }
        // eslint-disable-next-line
        return this.networkListPromise;
      },
      _getWpsAvailableNetworks() {
        // Get WPS available networks
        const ssids = Object.getOwnPropertyNames(this.networks);
        const wpsAvailableNetworks = [];
        for (let i = 0; i < ssids.length; i++) {
          const network = this.networks[ssids[i]];
          if (WifiHelper.isWpsAvailable(network)) {
            wpsAvailableNetworks.push(network);
          }
        }
        return wpsAvailableNetworks;
      }
    });
  };
});
