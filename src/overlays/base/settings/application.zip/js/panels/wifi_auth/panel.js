/* global WifiHelper */
'use strict';
// eslint-disable-next-line
define(function(require) {
  const WifiUtils = require('modules/wifi/wifi_utils');
  const WifiContext = require('modules/wifi/wifi_context');
  const SettingsPanel = require('modules/settings_panel');

  return function ctorWifiAuth() {
    let elements = {};
    let backPrevious = false;
    let self = null;

    function wifiAuthPanelAriaDisable(enabled) {
      const list = elements.panel.querySelectorAll('#wifi_auth li');

      for (let i = 0; i < list.length; i++) {
        if (!list[i].classList.contains('hidden') && enabled) {
          list[i].setAttribute('aria-disabled', true);
        } else if (!list[i].classList.contains('hidden') && !enabled) {
          list[i].removeAttribute('aria-disabled');
        }
      }

      const searchStr = '#wifi_auth li input';
      const listInput = elements.panel.querySelectorAll(searchStr);

      for (let i = 0; i < listInput.length; i++) {
        if (!listInput[i].classList.contains('hidden') && enabled) {
          listInput[i].setAttribute('disabled', 'disabled');
        } else if (!listInput[i].classList.contains('hidden') && !enabled) {
          listInput[i].removeAttribute('disabled', 'disabled');
        }
      }

      if (enabled) {
        NavigationMap.menuReset(elements.panel.querySelector('.focus'), false);
      }
    }

    function connectNetwork() {
      const { network } = elements;
      const key = WifiHelper.getKeyManagement(network);
      const callback = result => {
        if (result && result.message === 'network not found') {
          backPrevious = true;
          NavigationMap.navigateBack();
          self.openBadCredentialsDialog('wifi-association-reject');
        }
      };
      let simCardNum = null;

      switch (key) {
        case 'WEP':
        case 'WPA-PSK':
        case 'WPA-EAP':
        case 'WPA2-PSK':
        case 'WPA/WPA2-PSK':
        case 'SAE':
          if (elements.securityType === 'WPA-EAP') {
            simCardNum = WifiUtils.getSimNum(elements);
          }

          WifiHelper.setPassword({
            network,
            password: elements.password.value,
            identity: elements.identity.value,
            eap: elements.eap.value,
            phase2: elements.authPhase2.value,
            certificate: elements.certificate.value,
            keyIndex: elements.keyIndex.value - 1
          });

          // eslint-disable-next-line
          network.sim_num = simCardNum;
          WifiContext.associateNetwork(network, callback);
          break;
        default:
          WifiContext.associateNetwork(network, callback);
          break;
      }
    }

    function showConfirmDialog() {
      const dialogConfig = {
        title: {
          id: 'forgetNetwork-confirmation',
          args: {}
        },
        body: {
          id: 'forgetNetwork-dialog',
          args: {}
        },
        cancel: {
          l10nId: 'cancel',
          priority: 1,
          callback() {
            DialogHelper.destroy();
            if (backPrevious) {
              NavigationMap.navigateBack();
            }
          }
        },
        confirm: {
          l10nId: 'forget',
          priority: 3,
          callback() {
            DialogHelper.destroy();
            WifiContext.forgetNetwork(elements.network, () => {
              ToastHelper.showToast('networkforget');
            });
            NavigationMap.navigateBack();
          }
        }
      };

      DialogHelper.show(dialogConfig);
    }

    function enableSoftKey(evt) {
      updateSoftKey(evt.detail.enabled);
    }

    function updateSoftKey(doneSoftkeyEnable, showPassword, forgetEnable) {
      const none = {
        name: '',
        l10nId: '',
        priority: 1
      };

      const forget = {
        name: 'Forget',
        l10nId: 'forget',
        priority: 1,
        method: () => {
          showConfirmDialog();
        }
      };

      const select = {
        name: 'Select',
        l10nId: 'select',
        priority: 2
      };

      const connect = {
        name: 'Connect',
        l10nId: 'device-option-connect',
        priority: 3,
        method: () => {
          const itemWifiList = document.querySelector(
            'ul.wifi-availableNetworks'
          );
          if (itemWifiList) {
            itemWifiList.dataset.ssid = elements.ssid.textContent;
          }

          elements.connectFlag = true;
          connectNetwork();
          wifiAuthPanelAriaDisable(true);
          updateSoftKey(false, false, true);
        }
      };

      const params = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: []
      };

      if (forgetEnable) {
        params.items.push(forget);
      } else if (!doneSoftkeyEnable && !showPassword) {
        params.items.push(none);
      }

      if (showPassword) {
        params.items.push(select);
      }

      if (doneSoftkeyEnable) {
        params.items.push(connect);
      }

      SettingsSoftkey.init(params);
      SettingsSoftkey.show();
    }

    function checkConnectSoftkeyState(key) {
      const password = elements.password.value;
      const identity = elements.identity.value;
      const eap = elements.eap.value;

      return WifiHelper.isValidInput(key, password, identity, eap);
    }

    return SettingsPanel({
      onInit(panel, options) {
        elements = {
          network: options.network,//[GF5GTMO-5222] modify shangpeng.su 2024.11.15
          connectFlag: false,
          securityType: '',
          panel,
          ssid: panel.querySelector('[data-ssid]'),
          signal: panel.querySelector('[data-signal]'),
          security: panel.querySelector('[data-security]'),
          identity: panel.querySelector('input[name=identity]'),
          password: panel.querySelector('input[name=password]'),
          showPassword: panel.querySelector('input[name=show-pwd]'),
          eap: panel.querySelector('li.eap select'),
          authPhase2: panel.querySelector('li.auth-phase2 select'),
          keyIndex: panel.querySelector('li.key-index select'),
          certificate: panel.querySelector('li.server-certificate select')
        };
        elements.password.parentNode.onfocus = () => {
          elements.password.focus();
          elements.password.selectionStart = elements.password.value.length;
        };
        elements.identity.parentNode.onfocus = () => {
          elements.identity.focus();
        };
        // eslint-disable-next-line
        self = this;
        this.keydownHandler = this.keydownHandler.bind(this);
        this.onWifiStatusChange = this.onWifiStatusChange.bind(this);
        this.openWrongPasswordDialog = this.openWrongPasswordDialog.bind(this);
        this.openConnetingFailedDialog = this.openConnetingFailedDialog.bind(
          this
        );
        this.openObtainingIPFailedDialog = this.openObtainingIPFailedDialog.bind(
          this
        );
        this.handleFocusChanged = this.handleFocusChanged.bind(this);
      },
      onBeforeShow(panel, options) {
        const network = options.network;//[GF5GTMO-5222] modify shangpeng.su 2024.11.15
        if (!options.visibilityChange) {
          elements.identity.value = '';
          elements.password.value = '';
          elements.showPassword.checked = false;
          elements.network = options.network;//[GF5GTMO-5222] modify shangpeng.su 2024.11.15
          elements.connectFlag = false;
          backPrevious = false;
          elements.authPhase2.querySelectorAll('option')[0].selected = true;
          WifiUtils.initializeAuthFields(panel, network);
          WifiUtils.changeDisplay(panel, options.security);
          wifiAuthPanelAriaDisable(false);

          panel.dataset.security = options.security;
          elements.ssid.textContent = network.ssid;
          elements.signal.setAttribute(
            'data-l10n-id',
            `signalLevel${options.sl}`
          );

          if (options.security) {
            elements.securityType = options.security;
          }
          elements.security.setAttribute(
            'data-l10n-id',
            WifiHelper.getKeyManagement(options.network)//[GF5GTMO-6473] modify shangpeng.su 2025.02.11
          );

          WifiUtils.getCarrierName(elements);

          updateSoftKey(checkConnectSoftkeyState(options.security));
        }

        window.addEventListener('enable-connect-softkey', enableSoftKey);

        window.addEventListener('keydown', this.keydownHandler, true);
        document.addEventListener('focusChanged', this.handleFocusChanged);

        WifiContext.addEventListener(
          'wifiStatusChange',
          this.onWifiStatusChange
        );
        WifiContext.addEventListener(
          'wifiWrongPassword',
          this.openWrongPasswordDialog
        );
        WifiContext.addEventListener(
          'wifiConnectingFailed',
          this.openConnetingFailedDialog
        );
        WifiContext.addEventListener(
          'wifiObtainingIPFailed',
          this.openObtainingIPFailedDialog
        );
      },

      onShow() {
        ListFocusHelper.requestFocus(elements.panel, this.getFocusItem());
      },

      onHide() {
        backPrevious = false;
      },

      onBeforeHide() {
        window.removeEventListener('enable-connect-softkey', enableSoftKey);
        window.removeEventListener('keydown', this.keydownHandler, true);
        document.removeEventListener('focusChanged', this.handleFocusChanged);

        WifiContext.removeEventListener(
          'wifiStatusChange',
          this.onWifiStatusChange
        );
        WifiContext.removeEventListener(
          'wifiWrongPassword',
          this.openWrongPasswordDialog
        );
        WifiContext.removeEventListener(
          'wifiConnectingFailed',
          this.openConnetingFailedDialog
        );
        WifiContext.removeEventListener(
          'wifiObtainingIPFailed',
          this.openObtainingIPFailedDialog
        );
      },

      getFocusItem() {
        let item = null;
        if (!elements.identity.parentNode.classList.contains('hidden')) {
          item = elements.identity.parentNode;
        } else if (!elements.password.parentNode.classList.contains('hidden')) {
          item = elements.password.parentNode;
        } else {
          item = elements.security.parentNode;
        }

        return item;
      },

      handleFocusChanged() {
        if (elements.connectFlag) {
          updateSoftKey(false, false, true);
        } else {
          const { security } = elements.panel.dataset;
          const item =
            elements.panel.querySelector('li.show-password.focus') ||
            elements.panel.querySelector('li.server-certificate.focus') ||
            elements.panel.querySelector('li.auth-phase2.focus') ||
            elements.panel.querySelector('li.eap.focus');
          if (item) {
            updateSoftKey(checkConnectSoftkeyState(security), true);
          } else {
            updateSoftKey(checkConnectSoftkeyState(security), false);
          }
        }
      },

      keydownHandler(e) {
        switch (e.key) {
          case 'Backspace':
            e.preventDefault();
            e.stopPropagation();
            if (!elements.connectFlag) {
              NavigationMap.navigateBack();
            }
            break;
          default:
            break;
        }
      },

      onWifiStatusChange(event) {
        const { status } = event;
        if (event.network.ssid !== elements.network.ssid) {
          return;
        }

        if (status === 'connecting' || status === 'associated') {
          elements.panel
            .querySelector('.wifi-security small')
            .setAttribute('data-l10n-id', `shortStatus-${status}`);
        } else if (status === 'connected') {
          backPrevious = true;
          elements.connectFlag = false;
          wifiAuthPanelAriaDisable(false);
          NavigationMap.navigateBack();
          ToastHelper.showToast(
            Customization.getWifiCertifiedStrId(
              'wifi-connected',
              'wlan-connected'
            )
          );
        }
      },

      openWrongPasswordDialog() {
        let bodyId = 'wifi-authentication-failed';
        if (elements.securityType === 'WPA-EAP') {
          bodyId = 'wifi-eap-authentication-failed';
        }
        this.openBadCredentialsDialog(bodyId);
      },

      openConnetingFailedDialog() {
        this.openBadCredentialsDialog('wifi-association-reject');
      },

      openObtainingIPFailedDialog() {
        this.openBadCredentialsDialog('wifi-DHCP-failed');
        backPrevious = true;
        NavigationMap.navigateBack();
      },

      openBadCredentialsDialog(bodyId) {
        const { network } = elements;

        const dialogConfig = {
          title: {
            id: 'wifi-bad-credentials-title',
            args: {}
          },
          body: {
            id: bodyId,
            args: {
              ssid: network.ssid
            }
          },
          accept: {
            l10nId: 'ok',
            priority: 2,
            callback() {
              DialogHelper.destroy();
            }
          }
        };

        const { security } = elements.panel.dataset;
        const item = elements.panel.querySelector('li.show-password.focus');
        if (item) {
          updateSoftKey(checkConnectSoftkeyState(security), true);
        } else {
          updateSoftKey(checkConnectSoftkeyState(security), false);
        }

        elements.security.textContent = elements.securityType;
        elements.connectFlag = false;
        wifiAuthPanelAriaDisable(false);
        DialogHelper.show(dialogConfig);
      }
    });
  };
});
