/* global WifiHelper */
'use strict';
// eslint-disable-next-line
define(function(require) {
  const WifiUtils = require('modules/wifi/wifi_utils');
  const WifiContext = require('modules/wifi/wifi_context');
  const SettingsPanel = require('modules/settings_panel');
  const wifiManager = WifiHelper.getWifiManager();

  return function ctorJoinHiddenWifi() {
    let elements = {};
    const networkObj = {};
    const certificateFile = {};
    let connectFlag = false;

    function wifiAuthPanelAriaDisable(enabled) {
      const list = elements.panel.querySelectorAll(
        '.wifi-join-hidden-container li'
      );

      for (let i = 0; i < list.length; i++) {
        if (list[i].hidden === false && enabled) {
          list[i].setAttribute('aria-disabled', true);
        } else if (list[i].hidden === false && !enabled) {
          list[i].removeAttribute('aria-disabled');
        }
      }

      const searchStr = '.wifi-join-hidden-container li input';
      const listInput = elements.panel.querySelectorAll(searchStr);

      for (let i = 0; i < listInput.length; i++) {
        if (listInput[i].hidden === false && enabled) {
          listInput[i].setAttribute('disabled', 'disabled');
        } else if (listInput[i].hidden === false && !enabled) {
          listInput[i].removeAttribute('disabled', 'disabled');
        }
      }

      if (enabled) {
        const focusItem = elements.panel.querySelector(
          '.wifi-join-hidden-container .focus'
        );
        // eslint-disable-next-line
        focusItem && focusItem.focus();
      } else {
        const inputItem = elements.panel.querySelector(
          '.wifi-join-hidden-container .focus input'
        );
        // eslint-disable-next-line
        inputItem && inputItem.focus();
      }

      if (enabled) {
        window.dispatchEvent(new CustomEvent('refresh'));
      }
    }

    function showConfirmDialog() {
      const dialogConfig = {
        title: {
          id: 'forgetNetwork-confirmation',
          args: {}
        },
        body: {
          id: 'forgetNetwork-dialog',
          args: {}
        },
        cancel: {
          l10nId: 'cancel',
          priority: 1
        },
        confirm: {
          l10nId: 'forget',
          priority: 3,
          callback: () => {
            WifiContext.forgetNetwork(elements.network);
            NavigationMap.navigateBack();
          }
        }
      };

      DialogHelper.show(dialogConfig);
    }

    function updateForgetSoftkey() {
      const params = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [
          {
            name: 'Forget',
            l10nId: 'forget',
            priority: 1,
            method: () => {
              showConfirmDialog();
            }
          }
        ]
      };

      SettingsSoftkey.init(params);
      SettingsSoftkey.show();
    }

    function softkeyHandle() {
      const input = elements.panel.querySelector('.focus input');
      const enabled = checkConnectSoftkeyState();
      if (input) {
        const cskFlag = input.name === 'show-pwd';
        input.focus();
        updateSoftKey(enabled, cskFlag);
      } else {
        updateSoftKey(enabled, true);
      }
    }

    function enableConnectSoftKey(evt) {
      updateSoftKey(evt.detail.enabled);
    }

    function updateSoftKey(enabled, csk) {
      const connect = {
        name: 'Connect',
        l10nId: 'device-option-connect',
        priority: 3,
        method: () => {
          wifiAuthPanelAriaDisable(true);
          updateForgetSoftkey();
          connectNetwork();
        }
      };

      const select = {
        name: 'Select',
        l10nId: 'select',
        priority: 2
      };

      const softkeyParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: []
      };

      if (csk) {
        softkeyParams.items.push(select);
      }
      if (enabled && elements.ssid.value.length) {
        softkeyParams.items.push(connect);
      }

      if ((enabled || csk) && softkeyParams.items.length) {
        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
      } else {
        SettingsSoftkey.hide();
      }
    }

    function isNetworkMatch(network) {
      const currentNetworkSSID = elements.ssid.value;
      return currentNetworkSSID === network.ssid;
    }

    function isConnectNetwork(network) {
      return (
        wifiManager &&
        wifiManager.connection &&
        'connected' === wifiManager.connection.status &&
        wifiManager.connection.network &&
        WifiHelper.getCompositedKey(network) ===
          WifiHelper.getCompositedKey(wifiManager.connection.network)
      );
    }

    function connectNetwork() {
      if (connectFlag) {
        return;
      }

      connectFlag = true;
      setTimeout(() => {
        connectFlag = false;
      }, 1000);

      // We have to keep these information in network object
      networkObj.ssid = elements.ssid.value;
      networkObj.hidden = true;

      let network = null;
      // eslint-disable-next-line
      if (window.WifiNetwork !== undefined) {
        network = new window.WifiNetwork(networkObj);
      }

      if (elements.security.value === 'WAPI-CERT') {
        network.wapiAsCertificate = certificateFile.fileASU;
        network.wapiUserCertificate = certificateFile.fileUser;
      } else {
        WifiHelper.setPassword({
          network,
          password: elements.password.value,
          identity: elements.identity.value,
          eap: elements.eap.value,
          phase2: elements.authPhase2.value,
          certificate: elements.certificate.value,
          keyIndex: elements.keyIndex.value - 1
        });

        if (elements.security.value === 'WAPI-PSK') {
          network.pskType = elements.hexmode.checked ? 'HEX' : null;
        }

        // eslint-disable-next-line
        network.sim_num = WifiUtils.getSimNum(elements);
      }

      const callback = result => {
        if (result !== null && result.message === 'network not found') {
          openBadCredentialsDialog('hidden-wifi-not-found');
        }
      };

      if (isConnectNetwork(network)) {
        ToastHelper.showToast('wifi-network-connect');
        NavigationMap.navigateBack();
      } else {
        elements.network = network;
        WifiContext.associateNetwork(network, callback);
      }
    }

    function wifiStatusChangeHandler(evt) {
      if (evt.status === 'connected' && isNetworkMatch(evt.network)) {
        wifiAuthPanelAriaDisable(false);
        ToastHelper.showToast('hidden-wifi-connected');
        if (NavigationMap.currentActivatedLength > 0) {
          DialogHelper.destroy();
        }
        NavigationMap.navigateBack();
      }
    }

    function openWrongPasswordDialog() {
      openBadCredentialsDialog('wifi-incorrect-password');
    }

    function openConnetingFailedDialog() {
      openBadCredentialsDialog('wifi-association-reject');
    }

    function openObtainingIPFailedDialog() {
      openBadCredentialsDialog('wifi-DHCP-failed');
    }

    function openBadCredentialsDialog(msgId) {
      const network = WifiContext.currentNetwork;
      const dialogConfig = {
        title: {
          id: 'wifi-bad-credentials-title',
          args: {}
        },
        body: {
          id: msgId,
          args: {
            ssid: !network ? {} : network.ssid
          }
        },
        accept: {
          name: 'OK',
          l10nId: 'ok',
          priority: 2,
          callback: () => {
            DialogHelper.destroy();
          }
        }
      };

      wifiAuthPanelAriaDisable(false);
      softkeyHandle();
      DialogHelper.show(dialogConfig);
    }

    function checkConnectSoftkeyState() {
      const noneString = l10n.get('none');
      const key = elements.security.value;
      const password = elements.password.value;
      const identity = elements.identity.value;
      const eap = elements.eap.value;

      const itemASU = elements.certificateASU.querySelector('small');
      const itemUser = elements.certificateUser.querySelector('small');
      if (elements.security.value === 'WAPI-CERT') {
        if (
          itemASU &&
          itemASU.textContent !== noneString &&
          itemUser &&
          itemUser.textContent !== noneString
        ) {
          return true;
        }
        return false;
      }

      return WifiHelper.isValidInput(key, password, identity, eap);
    }

    function onSecurityChange() {
      const key = elements.security.value
        ? elements.security.value
        : l10n.get('security-none');
      if (key === l10n.get('security-none')) {
        elements.security.querySelectorAll('option')[0].selected = true;
      }

      elements.panel.dataset.security = key;
      WifiHelper.setSecurity(networkObj, key);
      WifiUtils.changeDisplay(elements.panel, key);
      WifiUtils.initializeAuthFields(elements.panel, networkObj);
      updateSoftKey(checkConnectSoftkeyState(), true);
      window.dispatchEvent(new CustomEvent('refresh'));
    }

    function onSSIDchange(event) {
      /*
       * Bug 1082394, during composition, we should not change the input
       * value. Otherwise, the input value will be cleared unexpectedly.
       * Besides, it seems unnecessary to change input value before
       * composition is committed.
       */
      if (event.isComposing) {
        return;
      }
      // Make sure ssid length is no more than 32 bytes.
      let str = elements.ssid.value;
      /*
       * Non-ASCII chars in SSID will be encoded by UTF-8, and length of
       * each char might be longer than 1 byte.
       * Use encodeURIComponent() to encode ssid, then calculate correct
       * length.
       */
      const encoder = new TextEncoder('utf-8');
      while (encoder.encode(str).length > 32) {
        str = str.substring(0, str.length - 1);
      }
      if (str !== elements.ssid.value) {
        elements.ssid.value = str;
      }
      updateSoftKey(checkConnectSoftkeyState());
    }

    function parseFilename(path) {
      return path.slice(path.lastIndexOf('/') + 1, path.lastIndexOf('.'));
    }

    function handleCertificateFile(fileName) {
      if (!fileName) {
        return;
      }
      const item = elements.panel.querySelector('li.focus span');
      if (item) {
        if (item.textContent === l10n.get('ASU-Certificate')) {
          certificateFile.fileASU = fileName;
          elements.certificateASU.querySelector(
            'small'
          ).textContent = parseFilename(fileName);
        } else if (item.textContent === l10n.get('User-Certificate')) {
          certificateFile.fileUser = fileName;
          elements.certificateUser.querySelector(
            'small'
          ).textContent = parseFilename(fileName);
        }
      }

      SettingsDBCache.saveSettings({
        'settings.wifi.certificatefile': null
      });

      const enabled = checkConnectSoftkeyState();
      if (enabled) {
        updateSoftKey(enabled);
      }
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          panel,
          network: null,
          ssid: panel.querySelector('input[name="ssid"]'),
          security: panel.querySelector('select[name="security"]'),
          identity: panel.querySelector('input[name="identity"]'),
          password: panel.querySelector('input[name="password"]'),
          showPassword: panel.querySelector('input[name=show-pwd]'),
          eap: panel.querySelector('select[name="eap"]'),
          keyIndex: panel.querySelector('li.key-index select'),
          authPhase2: panel.querySelector('li.auth-phase2 select'),
          certificate: panel.querySelector('li.server-certificate select'),
          hexmode: panel.querySelector('input[name=hexmode]'),
          certificateASU: panel.querySelector('li.ASU-Certificate'),
          certificateUser: panel.querySelector('li.User-Certificate')
        };
        this.certificateFlag = false;
        this.panelreadyHandler = this.panelreadyHandler.bind(this);
        this.handleFocusChanged = this.proFocusChanged.bind(this);
        this.keydownHandler = this.keydownHandler.bind(this);

        elements.password.parentNode.onfocus = () => {
          const cursorPosForInput = elements.password.value.length;

          elements.password.setSelectionRange(
            cursorPosForInput,
            cursorPosForInput
          );
        };
      },

      onBeforeShow(panel, options) {
        if (!options.visibilityChange) {
          elements.password.value = '';
          elements.identity.value = '';
          elements.showPassword.checked = false;
          wifiAuthPanelAriaDisable(false);
          const input = document.querySelector('li.focus input');
          if (input) {
            input.focus();
          }

          WifiUtils.getCarrierName(elements);

          if (
            NavigationMap.currentSection !==
            '#wifi_select_wlan_certificate_file'
          ) {
            elements.ssid.value = null;
            elements.security.value = l10n.get('security-none');
            onSecurityChange.call(elements.security);
            updateSoftKey(checkConnectSoftkeyState());
          } else {
            updateSoftKey(false, true);
            this.certificateFlag = true;
          }

          if (WifiUtils.wlanEnabled) {
            this.addWAPIOptions();
          } else {
            this.delWAPIOptions();
          }
        }

        window.addEventListener('keydown', this.keydownHandler, true);

        elements.ssid.addEventListener('input', onSSIDchange);

        elements.security.addEventListener('change', onSecurityChange);

        window.addEventListener('panelready', this.panelreadyHandler);

        window.addEventListener('enable-connect-softkey', enableConnectSoftKey);

        WifiContext.addEventListener(
          'wifiStatusChange',
          wifiStatusChangeHandler
        );
        WifiContext.addEventListener(
          'wifiWrongPassword',
          openWrongPasswordDialog
        );
        WifiContext.addEventListener(
          'wifiConnectingFailed',
          openConnetingFailedDialog
        );
        WifiContext.addEventListener(
          'wifiObtainingIPFailed',
          openObtainingIPFailedDialog
        );
        document.addEventListener('focusChanged', this.handleFocusChanged);
      },

      onShow() {
        SettingsDBCache.observe(
          'settings.wifi.certificatefile',
          '',
          handleCertificateFile
        );
      },

      onBeforeHide() {
        window.removeEventListener('keydown', this.keydownHandler, true);

        elements.ssid.removeEventListener('input', onSSIDchange);

        elements.security.removeEventListener('change', onSecurityChange);

        window.removeEventListener('panelready', this.panelreadyHandler);

        window.removeEventListener(
          'enable-connect-softkey',
          enableConnectSoftKey
        );

        WifiContext.removeEventListener(
          'wifiStatusChange',
          wifiStatusChangeHandler
        );
        WifiContext.removeEventListener(
          'wifiWrongPassword',
          openWrongPasswordDialog
        );
        WifiContext.removeEventListener(
          'wifiConnectingFailed',
          openConnetingFailedDialog
        );
        WifiContext.removeEventListener(
          'wifiObtainingIPFailed',
          openObtainingIPFailedDialog
        );
        SettingsDBCache.unobserve(
          'settings.wifi.certificatefile',
          handleCertificateFile
        );
        document.removeEventListener('focusChanged', this.handleFocusChanged);
      },

      keydownHandler(evt) {
        let input = null;
        let enabled = null;
        let cskFlag = null;
        const searchStr = '.wifi-join-hidden-container .wifi-ssid';
        let ssidItem = null;
        switch (evt.key) {
          case 'Enter':
            input = document.querySelector('li.focus input');
            enabled = checkConnectSoftkeyState();
            if (input) {
              cskFlag = input.name === 'show-pwd';

              input.focus();
              updateSoftKey(enabled, cskFlag);
            }
            break;
          case 'Backspace':
            if (NavigationMap.currentActivatedLength <= 0) {
              evt.preventDefault();
              evt.stopPropagation();
              ssidItem = elements.panel.querySelector(searchStr);
              if ('true' !== ssidItem.getAttribute('aria-disabled')) {
                NavigationMap.navigateBack();
              }
            }
            break;
          default:
            break;
        }
      },

      proFocusChanged(event) {
        const input = event.detail.focusedElement.querySelector('input');

        const enabled = checkConnectSoftkeyState();
        if (input) {
          const cskFlag = input.name === 'show-pwd';

          input.focus();
          updateSoftKey(enabled, cskFlag);
        } else {
          updateSoftKey(enabled, true);
        }
      },

      addWAPIOptions() {
        const selectStr = '#wifi_join_hidden .security-type select';
        const selectItem = elements.panel.querySelector(selectStr);

        if (!selectItem) {
          return;
        }

        const wapiPsk = document.createElement('option');
        wapiPsk.value = 'WAPI-PSK';
        wapiPsk.setAttribute('data-l10n-id', 'security-wapi-psk');
        selectItem.add(wapiPsk);

        const wapiCert = document.createElement('option');
        wapiCert.value = 'WAPI-CERT';
        wapiCert.setAttribute('data-l10n-id', 'security-wapi-cert');
        selectItem.add(wapiCert);
      },

      delWAPIOptions() {
        const selectStr = '#wifi_join_hidden .security-type select';
        const selectItem = elements.panel.querySelector(selectStr);

        if (!selectItem) {
          return;
        }

        const optionItem = selectItem.querySelectorAll('option');
        for (let i = 0; i < optionItem.length; i++) {
          if (
            optionItem[i].value === 'WAPI-PSK' ||
            optionItem[i].value === 'WAPI-CERT'
          ) {
            selectItem.removeChild(optionItem[i]);
          }
        }
      },

      panelreadyHandler() {
        if (this.certificateFlag) {
          this.certificateFlag = false;
        } else {
          updateSoftKey(checkConnectSoftkeyState());
          elements.ssid.focus();
        }
      }
    });
  };
});
