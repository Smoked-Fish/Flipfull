/* global WifiHelper  */

'use strict';
// eslint-disable-next-line
define(function(require) {
  const WifiUtils = require('modules/wifi/wifi_utils');
  const SettingsPanel = require('modules/settings_panel');

  return function ctorManageCertificatedWifi() {
    let elements = {};
    const wifiManager = WifiHelper.getWifiManager();

    function initSoftKey(options) {
      const params = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [options]
      };

      SettingsSoftkey.init(params);
      SettingsSoftkey.show();
    }

    function showSelectSoftKey() {
      const items = {
        name: 'Select',
        l10nId: 'select',
        priority: 2
      };

      initSoftKey(items);
    }

    function showDeleteSoftKey(nickname) {
      const items = {
        name: 'Delete',
        l10nId: 'delete',
        priority: 3,
        method() {
          showConfirmDialog(nickname);
        }
      };

      initSoftKey(items);
    }

    function newCertificateItem(nickname) {
      const span = document.createElement('span');
      span.textContent = nickname;
      span.id = nickname;
      span.classList.add('certificate-file');

      const li = document.createElement('li');
      li.setAttribute('role', 'menuitem');
      li.appendChild(span);

      return li;
    }

    function showConfirmDialog(nickname) {
      const dialogConfig = {
        title: { id: 'confirmation', args: {} },
        body: {
          id: 'delete-certificate-confirm-msg',
          args: {
            certificateName: nickname
          }
        },
        cancel: {
          name: 'Cancel',
          l10nId: 'cancel',
          priority: 1,
          callback() {
            DialogHelper.destroy();
          }
        },
        confirm: {
          name: 'Delete',
          l10nId: 'delete',
          priority: 3,
          callback() {
            DialogHelper.destroy();
            deleteCertificate(nickname);
          }
        }
      };
      DialogHelper.show(dialogConfig);
    }

    function deleteCertificate(nickname) {
      const scanWhenDeleteError = () => {
        // Pop out alert message for certificate deletion failed
        const dialogConfig = {
          title: { id: 'certificate-deletion-failed' },
          body: { id: 'certificate-deletion-failed-description', args: {} },
          accept: {
            l10nId: 'ok',
            priority: 2,
            callback() {
              DialogHelper.destroy();
              scan();
            }
          }
        };
        DialogHelper.show(dialogConfig);
      };

      wifiManager.deleteCert(nickname).then(
        () => {
          const item = document.getElementById(nickname).parentNode;
          const itemParent = item.parentNode;
          itemParent.removeChild(item);
          ToastHelper.showToast('certificate-deleted');

          const certificateItems = itemParent.querySelectorAll('li');
          if (certificateItems.length === 0) {
            showNoCertificatesInfo(itemParent);
          }

          NavigationMap.refresh();
        },
        () => {
          scanWhenDeleteError();
        }
      );
    }

    function showNoCertificatesInfo(list) {
      const li = WifiUtils.newExplanationItem('noImportedCertificates');
      li.classList.add('non-focus');
      list.appendChild(li);
    }

    function scan() {
      cleanup();

      wifiManager.getImportedCerts().then(
        result => {
          const certList = result;
          const updateList = (list, certificateList) => {
            // Display certificate list
            if (certificateList && certificateList.length) {
              for (let i = 0; i < certificateList.length; i++) {
                const aItem = newCertificateItem(certificateList[i]);
                list.appendChild(aItem);
              }

              // Add event listener for updating delete cert. soft-key
              const updateSoftKey = evt => {
                const nickname = evt.target.textContent;
                if (nickname === null) {
                  return;
                }

                showDeleteSoftKey(nickname);
              };

              let j = 0;
              const certificateItems = list.querySelectorAll('li');
              const { length } = certificateItems;
              for (j; j < length; j++) {
                certificateItems[j].addEventListener('focus', updateSoftKey);
              }
            } else {
              // Show "no certificates" message
              showNoCertificatesInfo(list);
            }
          };
          updateList(elements.serverCertificateList, certList.ServerCert);
          updateList(elements.userCertificateList, certList.UserCert);
          NavigationMap.refresh();
        },
        () => {
          console.warn('getImportedCerts failed');
        }
      );
    }

    function cleanup() {
      while (elements.serverCertificateList.hasChildNodes()) {
        elements.serverCertificateList.removeChild(
          elements.serverCertificateList.lastChild
        );
      }
      while (elements.userCertificateList.hasChildNodes()) {
        elements.userCertificateList.removeChild(
          elements.userCertificateList.lastChild
        );
      }
    }

    return SettingsPanel({
      onInit(panel) {
        elements = {
          panel,
          serverCertificateList: panel.querySelector('.wifi-serverCertificateList'),
          userCertificateList: panel.querySelector('.wifi-userCertificateList'),
          importCertificate: panel.querySelector('.operate-certificate li')
        };
      },

      onBeforeShow() {
        scan();
        showSelectSoftKey();
      },

      onShow(panel, option) {
        this.handleOption(option);
        elements.importCertificate.addEventListener('focus', showSelectSoftKey);
      },

      onBeforeHide() {
        SettingsSoftkey.hide();
      },

      onHide() {
        elements.importCertificate.removeEventListener(
          'focus',
          showSelectSoftKey
        );
      },

      handleOption(option) {
        if (!option || !option.message) {
          return;
        }

        const dialogConfig = {
          title: { id: 'import-certificate-failed', args: {} },
          body: {},
          accept: {
            l10nId: 'ok',
            priority: 2
          }
        };

        switch (option.message) {
          case 'Import duplicate certificate':
            dialogConfig.body.id = 'duplicate-cert-description';
            break;
          case 'Import damaged certificate':
            dialogConfig.body.id = 'damage-cert-description';
            break;
          default:
            break;
        }

        DialogHelper.show(dialogConfig);
      }
    });
  };
});
