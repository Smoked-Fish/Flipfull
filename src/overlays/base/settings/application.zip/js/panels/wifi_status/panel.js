/* global WifiHelper */
'use strict';
// eslint-disable-next-line
define(function(require) {
  const WifiContext = require('modules/wifi/wifi_context');
  const wifiManager = WifiHelper.getWifiManager();
  const SettingsPanel = require('modules/settings_panel');

  return function ctorStatusWifi() {
    let elements = {};

    return SettingsPanel({
      onInit(panel) {
        elements = {};
        elements.panel = panel;
        elements.ip = panel.querySelector('[data-ip]');
        elements.speed = panel.querySelector('[data-speed]');
        elements.ssid = panel.querySelector('[data-ssid]');
        elements.signal = panel.querySelector('[data-signal]');
        elements.security = panel.querySelector('[data-security]');
        elements.forgetNetworkDialog = panel.querySelector('form');
        elements.softkeyFlag = false;
        this.keydownHandler = this.keydownHandler.bind(this);
        this.onWifiStatusChange = this.onWifiStatusChange.bind(this);
        this.openWrongPasswordDialog = this.openWrongPasswordDialog.bind(this);
        this.openConnetingFailedDialog = this.openConnetingFailedDialog.bind(
          this
        );
        this.openObtainingIPFailedDialog = this.openObtainingIPFailedDialog.bind(
          this
        );
      },
      onBeforeShow(panel, options) {
        this.updateNetworkInfo();
        elements.ssid.textContent = options.network.ssid;
        elements.signal.setAttribute(
          'data-l10n-id',
          `signalLevel${options.sl}`
        );

        const wifiSecurity = elements.panel.querySelector('.wifi-security');
        wifiSecurity.classList.add('hidden');

        const wifiIpAddress = elements.panel.querySelector('.wifi-ip-address');
        const wifiLinkSpeed = elements.panel.querySelector('.wifi-link-speed');
        elements.network = options.network;
        elements.knownNetwork = options.knownNetwork;
        if (options.isConnected) {
          elements.softkeyFlag = false;
          wifiIpAddress.classList.remove('hidden');
          wifiLinkSpeed.classList.remove('hidden');
          this.initSoftKey();
        } else if (options.knownNetwork) {
          elements.softkeyFlag = true;
          wifiIpAddress.classList.add('hidden');
          wifiLinkSpeed.classList.add('hidden');
          wifiSecurity.classList.remove('hidden');
          elements.security.textContent = l10n.get('shortStatus-disconnected');
          this.initSoftKey(true);
        }

        this.wifiStatusPanelAriaDisable(false);
        elements.connectFlag = false;

        wifiManager.onconnectioninfoupdate = this.updateNetworkInfo;

        window.addEventListener('keydown', this.keydownHandler, true);
        WifiContext.addEventListener(
          'wifiStatusChange',
          this.onWifiStatusChange
        );
        WifiContext.addEventListener(
          'wifiWrongPassword',
          this.openWrongPasswordDialog
        );
        WifiContext.addEventListener(
          'wifiConnectingFailed',
          this.openConnetingFailedDialog
        );
        WifiContext.addEventListener(
          'wifiObtainingIPFailed',
          this.openObtainingIPFailedDialog
        );
      },
      onBeforeHide() {
        elements.softkeyFlag = false;
        wifiManager.onconnectioninfoupdate = null;
        window.removeEventListener('keydown', this.keydownHandler, true);
        WifiContext.removeEventListener(
          'wifiStatusChange',
          this.onWifiStatusChange
        );
        WifiContext.removeEventListener(
          'wifiWrongPassword',
          this.openWrongPasswordDialog
        );
        WifiContext.removeEventListener(
          'wifiConnectingFailed',
          this.openConnetingFailedDialog
        );
        WifiContext.removeEventListener(
          'wifiObtainingIPFailed',
          this.openObtainingIPFailedDialog
        );
      },

      onSubmit() {
        return Promise.resolve({
          connectFlag: elements.connectFlag
        });
      },

      keydownHandler(e) {
        switch (e.key) {
          case 'BrowserBack':
          case 'Backspace':
          case 'KanjiMode':
            if (NavigationMap.currentActivatedLength <= 0) {
              e.preventDefault();
              e.stopPropagation();
              if (!elements.connectFlag) {
                NavigationMap.navigateBack();
              }
            }
            break;
          case 'ArrowUp':
          case 'ArrowDown':
            if (elements.connectFlag) {
              this.initSoftKey(false);
            }
            break;
          default:
            break;
        }
      },

      initSoftKey(knownNetwork) {
        const connect = {
          name: 'Connect',
          l10nId: 'device-option-connect',
          priority: 3,
          method: () => {
            elements.connectFlag = true;
            this.initSoftKey(false);
            this.wifiStatusPanelAriaDisable(true);
            this.connectNetwork();
          }
        };

        const forget = {
          name: 'Forget',
          l10nId: 'forget',
          priority: 1,
          method: () => {
            this.showConfirmDialog();
          }
        };

        const softkeyParams = {
          menuClassName: 'menu-button',
          header: {
            l10nId: 'message'
          },
          items: []
        };

        softkeyParams.items.push(forget);
        if (knownNetwork) {
          softkeyParams.items.push(connect);
        }

        SettingsSoftkey.init(softkeyParams);
        SettingsSoftkey.show();
      },

      showNoNetworkDialog() {
        const clearData = () => {
          elements.security.textContent = l10n.get('shortStatus-disconnected');
          elements.connectFlag = false;
          this.initSoftKey(elements.knownNetwork);
          this.wifiStatusPanelAriaDisable(false);
        };

        const dialogConfig = {
          title: {
            id: 'failed-to-connect',
            args: {}
          },
          body: {
            id: 'network-not-found',
            args: {}
          },
          accept: {
            l10nId: 'ok',
            priority: 2,
            callback: () => {
              clearData();
            }
          },
          backcallback: () => {
            clearData();
          }
        };

        DialogHelper.show(dialogConfig);
      },

      connectCallback(error) {
        if (error && error.message === 'network not found') {
          //[GF5GTMO-6042] modify-begin shangpeng.su 2025.01.09
          //WifiContext.forgetNetwork(elements.network);
          this.showNoNetworkDialog();
          //[GF5GTMO-6042] modify-end shangpeng.su 2025.01.09
        }
      },

      connectNetwork() {
        WifiHelper.setPassword({ network: elements.network });
        WifiContext.associateNetwork(
          elements.network,
          this.connectCallback.bind(this)
        );
      },

      showConfirmDialog() {
        const dialogConfig = {
          title: {
            id: 'forgetNetwork-confirmation',
            args: {}
          },
          body: {
            id: 'forgetNetwork-dialog',
            args: {}
          },
          cancel: {
            l10nId: 'cancel',
            priority: 1,
            callback: () => {
              DialogHelper.destroy();
            }
          },
          confirm: {
            l10nId: 'forget',
            priority: 3,
            callback: () => {
              DialogHelper.destroy();
              WifiContext.forgetNetwork(elements.network, () => {
                ToastHelper.showToast('networkforget');
              });
              NavigationMap.navigateBack();
            }
          }
        };
        DialogHelper.show(dialogConfig);
      },
      updateNetworkInfo() {
        const info = wifiManager.connectionInformation || {};
        elements.ip.textContent = info.ipAddress || '';
        l10n.setAttributes(elements.speed, 'linkSpeedMbs', {
          linkSpeed: info.linkSpeed
        });
      },

      wifiStatusPanelAriaDisable(enabled) {
        const list = elements.panel.querySelectorAll('#wifi_status li');

        for (let i = 0; i < list.length; i++) {
          if (list[i].hidden === false && enabled) {
            list[i].setAttribute('aria-disabled', true);
          } else if (list[i].hidden === false && !enabled) {
            list[i].removeAttribute('aria-disabled');
          }
        }

        const searchStr = '#wifi_status li input';
        const listInput = elements.panel.querySelectorAll(searchStr);

        for (let i = 0; i < listInput.length; i++) {
          if (listInput[i].hidden === false && enabled) {
            listInput[i].setAttribute('disabled', 'disabled');
          } else if (listInput[i].hidden === false && !enabled) {
            listInput[i].removeAttribute('disabled', 'disabled');
          }
        }

        if (enabled) {
          NavigationMap.menuReset(
            elements.panel.querySelector('.focus'),
            false
          );
        }
      },

      onWifiStatusChange(event) {
        const { status } = event;
        if (!event.network || event.network.ssid !== elements.network.ssid) {
          return;
        }

        if (status === 'connecting' || status === 'associated') {
          elements.panel
            .querySelector('.wifi-security small')
            .setAttribute('data-l10n-id', `shortStatus-${status}`);
        } else if (status === 'connected') {
          this.wifiStatusPanelAriaDisable(false);
          NavigationMap.navigateBack();
          ToastHelper.showToast(
            Customization.getWifiCertifiedStrId(
              'wifi-connected',
              'wlan-connected'
            )
          );
        }
      },

      openWrongPasswordDialog() {
        this.openBadCredentialsDialog('wifi-authentication-failed');
      },

      openConnetingFailedDialog() {
        this.openBadCredentialsDialog('wifi-association-reject');
      },

      openObtainingIPFailedDialog() {
        this.openBadCredentialsDialog('wifi-DHCP-failed');
      },

      openBadCredentialsDialog(bodyId) {
        const { network } = elements;

        const dialogConfig = {
          title: {
            id: 'wifi-bad-credentials-title',
            args: {}
          },
          body: {
            id: bodyId,
            args: {
              ssid: network.ssid
            }
          },
          accept: {
            l10nId: 'ok',
            priority: 2,
            callback: () => {
              DialogHelper.destroy();
              if ('wifi-authentication-failed' === bodyId) {
                NavigationMap.navigateBack();
              }
            }
          }
        };

        elements.security.textContent = l10n.get('shortStatus-disconnected');
        elements.connectFlag = false;
        this.initSoftKey(elements.knownNetwork);
        this.wifiStatusPanelAriaDisable(false);
        DialogHelper.show(dialogConfig);
      }
    });
  };
});
