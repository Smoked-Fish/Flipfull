/* global WifiHelper */

'use strict';
// eslint-disable-next-line
define(function(require) {
  const WifiUtils = require('modules/wifi/wifi_utils');
  const SettingsPanel = require('modules/settings_panel');
  const wifiManager = WifiHelper.getWifiManager();

  return function ctorWpsWifi() {
    // Const wifiWps = WifiWps();
    let elements = {};

    function initSoftKey() {
      const softkeyParams = {
        menuClassName: 'menu-button',
        header: {
          l10nId: 'message'
        },
        items: [
          {
            name: 'Select',
            l10nId: 'select',
            priority: 2
          },
          {
            name: 'Connect',
            l10nId: 'device-option-connect',
            priority: 3,
            method() {
              connect({
                pin: elements.pinInput.value,
                selectedMethod: elements.panel.querySelector(
                  "input[type='radio']:checked"
                ).value,
                onSuccess() {
                  Settings.isBackHref = true;
                  Settings.setCurrentPanel('#wifi', {
                    inProgress: true,
                    wpsInfoBlock: 'fullStatus-wps-inprogress',
                    succ: true
                  });
                },
                // eslint-disable-next-line
                onError(error) {
                  Settings.isBackHref = true;
                  Settings.setCurrentPanel('#wifi', {
                    inProgress: false,
                    wpsInfoBlock: 'fullStatus-wps-failed-error',
                    args: {
                      Error: error.name
                    }
                  });
                }
              });
            }
          }
        ]
      };
      SettingsSoftkey.init(softkeyParams);
      SettingsSoftkey.show();
    }

    function showAlertDialog(l10n, args, onSuccess) {
      const dialogConfig = {
        title: { id: 'settings', args: {} },
        body: { id: l10n, args },
        accept: {
          l10nId: 'ok',
          priority: 2,
          callback: () => {
            DialogHelper.destroy();
            onSuccess();
          }
        }
      };
      DialogHelper.show(dialogConfig);
    }

    function connect(options) {
      let req = null;
      const emptyFunc = () => {};
      const onSuccess = options.onSuccess || emptyFunc;
      const onError = options.onError || emptyFunc;

      const method = options.selectedMethod;
      const { pin } = options;

      let bssid = null;
      if ('pbc' !== method) {
        const apIndex = elements.apSelect.selectedIndex;
        bssid = elements.apSelect.options[apIndex].value;
      }

      if (method === 'pbc') {
        req = wifiManager.wps({
          method: 'pbc'
        });
      } else if (method === 'myPin') {
        req = wifiManager.wps({
          method: 'display',
          bssid
        });
      } else {
        req = wifiManager.wps({
          method: 'pin',
          bssid,
          pin
        });
      }

      req.onsuccess = () => {
        if (method === 'myPin') {
          showAlertDialog('wpsPinInput', { pin: req.result }, onSuccess);
        } else {
          onSuccess();
        }
      };

      req.onerror = () => {
        onError(req.error);
      };
    }

    return SettingsPanel({
      onInit(panel) {
        this.networks = {};
        elements = {
          panel,
          apSelectionArea: panel.querySelector('.wifi-wps-pin-aps'),
          apSelect: panel.querySelector('.wifi-wps-pin-aps select'),
          pinItem: panel.querySelector('.wifi-wps-pin-area'),
          pinDesc: panel.querySelector('.wifi-wps-pin-area p'),
          pinInput: panel.querySelector('.wifi-wps-pin-area input'),
          wpsMethodRadios: panel.querySelectorAll('input[type=radio]')
        };

        for (let i = 0; i < elements.wpsMethodRadios.length; i++) {
          elements.wpsMethodRadios[i].onchange = this.onWpsMethodChange;
        }
        this.keydownHandler = this.keydownHandler.bind(this);
      },
      onBeforeShow(panel, options) {
        if (!options.visibilityChange) {
          this.cleanupApList();
          this.netWorksList().then(() => {
            this.updateApList(this.getWpsAvailableNetworks());
          });
          this.onWpsMethodChange();
          initSoftKey();
        }

        window.addEventListener('keydown', this.keydownHandler);
      },
      onBeforeHide() {
        window.removeEventListener('keydown', this.keydownHandler);
      },
      keydownHandler(e) {
        let el = null;
        switch (e.key) {
          case 'Enter':
            el = elements.panel.querySelector('li.focus > label');
            if (el) {
              el.click();
            }
            break;
          default:
            break;
        }
      },
      onSubmit() {
        const selectedAp =
          elements.apSelect.options[elements.apSelect.selectedIndex].value;
        const selectedMethod = elements.panel.querySelector(
          "input[type='radio']:checked"
        ).value;
        const pin = elements.pinInput.value;

        return Promise.resolve({
          selectedAp,
          selectedMethod,
          pin
        });
      },
      cleanupApList() {
        const { apSelect } = elements;
        while (apSelect.hasChildNodes()) {
          apSelect.removeChild(apSelect.firstChild);
        }
      },
      updateApList(wpsAvailableNetworks) {
        // Add the first option
        let option = document.createElement('option');
        option.setAttribute('data-l10n-id', 'wpsAnyAp');
        option.value = 'any';
        elements.apSelect.appendChild(option);

        // Add the other networks
        for (let i = 0; i < wpsAvailableNetworks.length; i++) {
          option = document.createElement('option');
          option.textContent = wpsAvailableNetworks[i].ssid;
          option.value = wpsAvailableNetworks[i].bssid;
          elements.apSelect.appendChild(option);
        }
      },
      onWpsMethodChange(e) {
        let method = 'pbc';
        const items = elements.panel.querySelectorAll('.wps-button');
        if (e) {
          method = items[0].checked ? 'pbc' : 'myPin';
        } else {
          items[0].checked = true;
          method = 'pbc';
        }

        elements.apSelectionArea.classList.toggle('hidden', method === 'pbc');
        NavigationMap.refresh();
      },

      netWorksList() {
        return new Promise(resolve => {
          // Stop auto-scanning if wifi disabled or the app is hidden
          if (!wifiManager.enabled || document.hidden) {
            resolve();
            return;
          }
          const req = WifiHelper.getAvailableAndKnownNetworks();

          req.onsuccess = () => {
            const allNetworks = req.result;
            let network = null;

            for (let i = 0; i < allNetworks.length; ++i) {
              network = allNetworks[i];
              const key = WifiUtils.getNetworkKey(network);
              // Keep connected network first, or select the highest strength
              if (!this.networks[key] || network.connected) {
                this.networks[key] = network;
              } else if (
                !this.networks[key].connected &&
                network.relSignalStrength > this.networks[key].relSignalStrength
              ) {
                this.networks[key] = network;
              }
            }
            resolve();
          };
        });
      },

      getWpsAvailableNetworks() {
        // Get WPS available networks
        const ssids = Object.getOwnPropertyNames(this.networks);
        const wpsAvailableNetworks = [];
        for (let i = 0; i < ssids.length; i++) {
          const network = this.networks[ssids[i]];
          if (network.wpsSupported) {
            wpsAvailableNetworks.push(network);
          }
        }
        return wpsAvailableNetworks;
      }
    });
  };
});
