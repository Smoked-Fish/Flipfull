/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  // Talk to engmoded, a http server at 127.0.0.1:1380
  function RemoteHelper() {
    this._engmodeURL = 'http://127.0.0.1:2929'; //Defect9340968-xiaolei.yin@tcl.com-modify for new baseline
  }

  RemoteHelper.prototype = {
    // read some file
    readFile: function _readconf(path, success, failure) {
      var params = this._engmodeURL + 'name=query&api=' + encodeURIComponent('cat ' + path);
      this.runXHRequest(params, success, failure);
    },

    // to get property via engmode
    getproperty: function _getproperty(key, success, failure) {
      var params = this._engmodeURL + 'name=query' + '&api=' +
        'get_sys_property&key=' + key;
      this.runXHRequest(params, success, failure);
    },

    setproperty: function _getproperty(key, value, success, failure) {
      var params = this._engmodeURL + 'name=query' + '&api=' +
        encodeURIComponent('set_sys_property&key= ' + key +'&data='+value);
      this.runXHRequest(params, success, failure);
    },

    /**
     * The inner interface to communicate with Engmode service.
     *
     * @param params  The fully string encoded under different style.
     * @param success  Callback to be called when success.
     * @param failure  Callback to be called when error.
     */
    //Defect9340968-xiaolei.yin@tcl.com-modify for new baseline-begin
    runXHRequest: function _runXHRequest(params, success, failure) {
      var xhr = new XMLHttpRequest();

      xhr.open('POST', this._engmodeURL, true);
      xhr.onload = function() {
        //dump('mmitest-remote_helper.js--xhr onload');
        var response = xhr.response.replace('\n','');
        //dump('system-remote_helper.js--xhr response is ' + response);
        success && success(response);
      };
      xhr.onerror = function(e) {
        //dump('system-remote_helper.js--xhr error: ' + JSON.stringify(e));
        failure && failure();
      };
        xhr.onreadystatechange = function () {
            /*dump('system-remote_helper.js--onreadystatechange--readyState is ' + xhr.readyState
                + ' status is ' + xhr.status);
            dump('system-remote_helper.js--onreadystatechange--xhr.responseText=' + xhr.responseText);*/
        }
      xhr.send(params);
    }
    //Defect9340968-xiaolei.yin@tcl.com-modify for new baseline-end
  };

  exports.RemoteHelper = RemoteHelper;
}(window));
