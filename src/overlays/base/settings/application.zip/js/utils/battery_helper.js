/* globals */
'use strict';
// eslint-disable-next-line
const BatteryHelper = (function BatteryHelper() {
  let batteryLevel = null;
  let batteryState = null;

  function getLevel() {
    return Math.min(100, Math.floor(ApiManager.battery.level * 100));
  }

  function getState() {
    if (ApiManager.battery.charging) {
      return getLevel() === 100 ? 'charged' : 'charging';
    }
    return 'unplugged';
  }

  function handleEvent(evt) {
    switch (evt.type) {
      case 'levelchange':
        batteryLevel = getLevel();
        if (batteryLevel === 100) {
          batteryState = getState();
        }
        break;
      case 'chargingchange':
        batteryState = getState();
        break;
      default:
        break;
    }
    window.dispatchEvent(new CustomEvent('batteryChange'));
  }

  function init() {
    batteryLevel = getLevel();
    batteryState = getState();
    ApiManager.battery.addEventListener('levelchange', handleEvent);
    ApiManager.battery.addEventListener('chargingchange', handleEvent);
  }

  return {
    init,
    get level() {
      return batteryLevel;
    },
    get state() {
      return batteryState;
    }
  };
})();

window.BatteryHelper = BatteryHelper;
if (ApiManager.battery) {
  BatteryHelper.init();
} else {
  window.addEventListener(
    'battery-ready',
    () => {
      BatteryHelper.init();
    },
    { once: true }
  );
}
