/* globals BluetoothHelper */
'use strict';
window.BTConnectionManager = (function BTConnectionManager() {
  const Profiles = {
    hfp: 0x111e, // Handsfree
    a2dp: 0x110d, // Advanced Audio Distribution Devices
    hid: 0x1124 // Keyboard device
  };
  const DEVICE_CONNECTED_KEY = 'bluetooth.device.connected';

  let getConnectedDevicesPromise = null;
  // eslint-disable-next-line
  let connectingAddress = null;
  let manualConnection = false;
  const connectedDevicesInfo = {};

  function updateConnectedDevices(options) {
    return getConnectedDevices().then(() => {
      DebugHelper.log(
        `ConnectedDevices: ${JSON.stringify(connectedDevicesInfo)}`
      );
      return Promise.resolve(getConnectedDevice(options));
    });
  }

  function onProfileStatusChangeHandler(profileID, evt) {
    const options = {
      address: evt.address,
      connected: evt.status,
      profileID
    };
    // Update connection status.
    connectingAddress = null;

    // Update the profile in the cache of connected device info.
    updateConnectedDevices(options).then(() => {
      // Prepare latest data to check connected profile.
      const dataToCheckConnectedProfile = {
        address: options.address,
        connectedDevices: connectedDevicesInfo
      };

      /*
       * Fire 'connected'/'disconnected' event according to
       * the connection profile. Then, record connection.
       */
      if (options.connected) {
        window.dispatchEvent(
          new CustomEvent('connection-info-change', {
            detail: {
              type: 'connected',
              address: options.address
            }
          })
        );
        const obj = {};
        obj[DEVICE_CONNECTED_KEY] = options.address;
        SettingsDBCache.saveSettings(obj);
      } else if (!manualConnection) {
        /*
         * If there is no profile connected,
         * we have to remove the record connection.
         * And fire 'disconnected' event for outer modules.
         */
        if (!hasConnectedProfileByAddress(dataToCheckConnectedProfile)) {
          window.dispatchEvent(
            new CustomEvent('connection-info-change', {
              detail: {
                type: 'disconnected',
                address: options.address
              }
            })
          );
        }
      }

      // Fire 'profileChanged' event.
      let newProfiles = null;
      if (hasConnectedProfileByAddress(dataToCheckConnectedProfile)) {
        newProfiles = connectedDevicesInfo[options.address].connectedProfiles;
      }

      window.dispatchEvent(
        new CustomEvent('connection-info-change', {
          detail: {
            type: 'profileChanged',
            address: options.address,
            profiles: newProfiles
          }
        })
      );
    });
  }

  function init(adapter) {
    let eventName = null;
    // eslint-disable-next-line guard-for-in
    for (const profileID in Profiles) {
      eventName = `on${profileID}statuschanged`;
      adapter[eventName] = evt => {
        onProfileStatusChangeHandler(profileID, evt);
      };
    }
  }

  function getConnectedDevicesByProfile(profileID) {
    return BluetoothHelper.adapter.getConnectedDevices(profileID).then(
      connectedDevice => {
        return Promise.resolve(connectedDevice || []);
      },
      reason => {
        DebugHelper.log(
          `${'getConnectedDevicesByProfile failed reason:'}${reason}`
        );
        return Promise.resolve([]);
      }
    );
  }

  function getConnectedDevicesFromPlatform() {
    // Get connected device via profiles HFP, A2DP
    return new Promise(resolve => {
      Promise.all(
        Object.keys(Profiles).map(profile =>
          getConnectedDevicesByProfile(Profiles[profile])
        )
      ).then(connectedDevices => {
        // Update each connected devices in map.
        const collectedConnectedDevicesByProfile = {};
        Object.keys(Profiles).forEach((profile, index) => {
          collectedConnectedDevicesByProfile[profile] = connectedDevices[index];
        });
        return resolve(collectedConnectedDevicesByProfile);
      });
    });
  }

  function hasConnectedProfileByAddress(options) {
    if (!options.connectedDevices[options.address]) {
      return false;
    }

    let hasConnectedProfile = false;
    // eslint-disable-next-line guard-for-in
    for (const profileID in Profiles) {
      // eslint-disable-next-line prefer-destructuring
      const connectedProfiles =
        options.connectedDevices[options.address].connectedProfiles;
      if (connectedProfiles && connectedProfiles[profileID] === true) {
        hasConnectedProfile = true;
      }
    }
    return hasConnectedProfile;
  }

  function getConnectedDevice(options) {
    // Hash by device address
    let info = connectedDevicesInfo
      ? connectedDevicesInfo[options.address]
      : null;
    if (info) {
      // Already have profiles, update it for other profile.
      info.connectedProfiles[options.profileID] = options.connected;
    } else {
      /*
       * Not have profiles yet, create for it.
       * If options.device is existed, save the connected device.
       * Otherwise, given null in this property.
       */
      const connectedDevice = options.device ? options.device : null;
      info = {
        device: connectedDevice,
        connectedProfiles: {}
      };
      info.connectedProfiles[options.profileID] = options.connected;
    }
    // Save the device/profile in map.
    connectedDevicesInfo[options.address] = info;

    /*
     * If there is no profile connected,
     * remove the device item from cache since it is already disconnected.
     */
    const dataToCheckConnectedProfile = {
      address: options.address,
      connectedDevices: connectedDevicesInfo
    };
    if (!hasConnectedProfileByAddress(dataToCheckConnectedProfile)) {
      delete connectedDevicesInfo[options.address];
    }
    return connectedDevicesInfo;
  }

  function initConnectedDevicesInfo() {
    return getConnectedDevicesFromPlatform().then(connectedDevices => {
      Object.keys(Profiles).map(profileID =>
        connectedDevices[profileID].forEach(connectedDevice => {
          const connectionDeviceInfo = {
            address: connectedDevice.address,
            connected: true,
            profileID,
            device: connectedDevice
          };
          getConnectedDevice(connectionDeviceInfo);
        })
      );
    });
  }

  function getConnectedDevices() {
    if (!getConnectedDevicesPromise) {
      getConnectedDevicesPromise = initConnectedDevicesInfo().then(() => {
        DebugHelper.debug(
          `getConnectedDevices:  ${JSON.stringify(connectedDevicesInfo)}`
        );
        getConnectedDevicesPromise = null;
        return connectedDevicesInfo;
      });
    }
    return getConnectedDevicesPromise;
  }

  function getPairedDeviceByAddress(address) {
    const pairedDevices = BluetoothHelper.adapter.getPairedDevices();
    if (pairedDevices.length === 0) {
      return null;
    }
    for (const i in pairedDevices) {
      if (pairedDevices[i].address === address) {
        return pairedDevices[i];
      }
    }
    return null;
  }

  function connect(device) {
    // Save the connecting address
    connectingAddress = device.address;
    manualConnection = true;

    return new Promise(resolve => {
      /*
       * Note on Bluedroid stack, discovery has to be stopped before connect
       * (i.e., call stopDiscovery() before connect())
       * otherwise stack callbacks with connect failure.
       */
      BluetoothHelper.adapter.stopDiscovery().then(
        () => {
          return BluetoothHelper.adapter.connect(device.data).then(
            () => {
              manualConnection = false;
              return resolve(true);
            },
            () => {
              // No available profiles are connected. Reset connecting address.
              connectingAddress = null;
              manualConnection = false;
              DebugHelper.debug('connectDevice connect failed');
              return resolve(false);
            }
          );
        },
        () => {
          connectingAddress = null;
          manualConnection = false;
          return resolve('connectDevice stopDiscovery failed.');
        }
      );
    });
  }

  function connectDevice(toConnect, device) {
    return new Promise(resolve => {
      if (toConnect) {
        const connectedDevices = [];
        getConnectedDevices().then(() => {
          for (const address in connectedDevicesInfo) {
            if (connectedDevicesInfo[address].device === null) {
              const regetPairedDevice = getPairedDeviceByAddress(address);
              connectedDevices.push(regetPairedDevice);
            } else {
              connectedDevices.push(connectedDevicesInfo[address].device);
            }
          }
          DebugHelper.debug(
            `Will disconnect devices = ${JSON.stringify(connectedDevices)}`
          );
          if (connectedDevices.length > 0) {
            return Promise.all(
              connectedDevices.map(connectedDevice =>
                BluetoothHelper.adapter.disconnect(connectedDevice)
              )
            ).then(() => {
              return connect(device).then(result => {
                resolve(result);
              });
            });
          }
          return connect(device).then(result => {
            resolve(result);
          });
        });
      } else {
        BluetoothHelper.adapter.disconnect(device.data).then(
          () => {
            const obj = {};
            obj[DEVICE_CONNECTED_KEY] = null;
            SettingsDBCache.saveSettings(obj);
            resolve(true);
          },
          reason => {
            DebugHelper.debug(`disconnect failed:${reason}`);
            resolve(false);
          }
        );
      }
    });
  }

  return {
    init,
    getConnectedDevices,
    connectDevice
  };
})();
