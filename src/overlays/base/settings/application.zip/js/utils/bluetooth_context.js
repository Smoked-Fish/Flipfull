/* globals BTConnectionManager, BluetoothHelper */
'use strict';
// eslint-disable-next-line
window.BluetoothContext = (function BluetoothContext() {
  const BLUETOOTH_PBAP = 'bluetooth.pbap';
  const BLUETOOTH_MAP = 'bluetooth.map';
  const SCANTIMEOUT = 40000;

  //* **********Bluetooth Device Start*************************
  const MinorDeviceClasses = {
    Computer: {
      0: 'computer', // Uncategorized, code for device not assigned
      1: 'computer', // Desktop workstation
      2: 'computer', // Server-class computer
      3: 'computer', // Laptop
      4: 'pda', // Handheld PC/PDA (clamshell)
      5: 'pda', // Palm-size PC/PDA
      6: 'computer', // Wearable computer (watch size)
      7: 'computer', // Tablet
      reserved: 'computer' // All other values reserved. Default type
      // 'computer' given for reserved case.
    },

    Phone: {
      0: 'phone', // Uncategorized, code for device not assigned
      1: 'phone', // Cellular
      2: 'phone', // Cordless
      3: 'phone', // Smartphone
      4: 'modem', // Wired modem or voice gateway
      5: 'phone', // Common ISDN access
      reserved: 'phone' // All other values reserved. Default type
      // 'phone' given for reserved case.
    },

    AudioVideo: {
      0: 'audio-card', // Uncategorized, code not assigned
      1: 'audio-card', // Wearable Headset Device
      2: 'audio-card', // Hands-free Device
      4: 'audio-input-microphone', // Microphone
      5: 'audio-card', // Loudspeaker
      6: 'audio-card', // Headphones
      7: 'audio-card', // Portable Audio
      8: 'audio-card', // Car audio
      9: 'audio-card', // Set-top box
      10: 'audio-card', // HiFi Audio Device
      11: 'camera-video', // VCR
      12: 'camera-video', // Video Camera
      13: 'camera-video', // Camcorder
      14: 'video-display', // Video Monitor
      15: 'video-display', // Video Display and Loudspeaker
      16: 'video-display', // Video Conferencing
      18: 'audio-card', // Gameing/Toy
      reserved: 'audio-card' // All other values reserved. Default type
      // 'audio-card' given for reserved case.
    },

    Peripheral: {
      1: 'input-gaming', // Joystick
      2: 'input-gaming', // Gamepad
      16: 'input-keyboard', // Keyboard
      17: 'input-keyboard', // Keyboard
      18: 'input-keyboard', // Keyboard
      19: 'input-keyboard', // Keyboard
      20: 'input-keyboard', // Keyboard
      21: 'input-keyboard', // Keyboard
      22: 'input-keyboard', // Keyboard
      23: 'input-keyboard', // Keyboard
      24: 'input-keyboard', // Keyboard
      25: 'input-keyboard', // Keyboard
      26: 'input-keyboard', // Keyboard
      27: 'input-keyboard', // Keyboard
      28: 'input-keyboard', // Keyboard
      29: 'input-keyboard', // Keyboard
      30: 'input-keyboard', // Keyboard
      31: 'input-keyboard', // Keyboard
      32: 'input-mouse', // Pointing device
      33: 'input-mouse', // Pointing device
      34: 'input-mouse', // Pointing device
      35: 'input-mouse', // Pointing device
      36: 'input-mouse', // Pointing device
      37: 'input-tablet', // Digitizer tablet
      38: 'input-mouse', // Pointing device
      39: 'input-mouse', // Pointing device
      40: 'input-mouse', // Pointing device
      41: 'input-mouse', // Pointing device
      42: 'input-mouse', // Pointing device
      43: 'input-mouse', // Pointing device
      44: 'input-mouse', // Pointing device
      45: 'input-mouse', // Pointing device
      46: 'input-mouse', // Pointing device
      47: 'input-mouse' // Pointing device
    },

    Imaging: {
      4: 'video-display', // Display, bit: XXX1XX
      8: 'camera-photo', // Camera, bit: XX1XXX
      16: 'scanner', // Scanner, bit: X1XXXX
      32: 'printer' // Printer, bit: 1XXXXX
    }
  };

  const MajorDeviceClasses = {
    1: MinorDeviceClasses.Computer,
    2: MinorDeviceClasses.Phone,
    3: 'network-wireless', // LAN/Network Access Point Major Class
    4: MinorDeviceClasses.AudioVideo,
    5: MinorDeviceClasses.Peripheral,
    6: MinorDeviceClasses.Imaging
  };

  const BtClassOfDeviceMapper = {
    hasAudioCard(cod) {
      // eslint-disable-next-line no-bitwise
      return cod.majorServiceClass & 0x100 || cod.majorServiceClass & 0x20;
    },

    getDeviceType(cod) {
      let deviceType = '';
      const majorDeviceClass = MajorDeviceClasses[cod.majorDeviceClass];
      if (typeof majorDeviceClass === 'string') {
        return majorDeviceClass;
      }

      if (typeof majorDeviceClass === 'object') {
        deviceType =
          majorDeviceClass[cod.minorDeviceClass] ||
          majorDeviceClass.reserved ||
          '';

        if (
          deviceType === 'phone' ||
          deviceType === 'computer' ||
          deviceType === 'pda'
        ) {
          return deviceType;
        }
      }

      //Modify by dapeng.wang for GF5GTMO-4523 2024/10/19 begin
      //some device support audio-card and type is 0x80 will be set as computer,
      //Cant auto connect After paired
      // Check whether it has audio card based on major service
      if (BtClassOfDeviceMapper.hasAudioCard(cod)) {
        DebugHelper.debug(
          'return in major service Audio or Rendering, type = audio-card'
        );
        return 'audio-card';
      }

      // eslint-disable-next-line no-bitwise
      if (cod.majorServiceClass & 0x80) {
        DebugHelper.debug(
          'return in major service Object Transfer, type = computer'
        );
        return 'computer';
      }
      //Modify by dapeng.wang for GF5GTMO-4523 2024/10/19 end

      DebugHelper.debug(`return in the rest device types = ${deviceType}`);
      return deviceType;
    }
  };

  const BTDevice = function BTDevice(device) {
    const type = BtClassOfDeviceMapper.getDeviceType(device.cod);
    const hasAudioCard = BtClassOfDeviceMapper.hasAudioCard(device.cod);
    const connectionStatus = device.connectionStatus || 'disconnected';
    const observableDevice = {
      name: device.name,
      paired: device.paired,
      address: device.address,
      type,
      hasAudioCard,
      connectionStatus,
      data: device,
      descriptionText: '',
      updateConnectionInfo,
      updateDescriptionText
    };

    function updateConnectionInfo(options) {
      if (options.connectionStatus) {
        observableDevice.connectionStatus = options.connectionStatus;
        updateDescriptionText();
      }
      if (options.profiles) {
        observableDevice.profiles = Object.create(options.profiles);
        updateDescriptionText();
      }
    }

    function updateDescriptionText() {
      if (observableDevice.paired === false) {
        observableDevice.descriptionText = 'pairFailure';
      } else if (observableDevice.paired === 'pairing') {
        observableDevice.descriptionText = 'pairing';
      } else if (observableDevice.paired === true) {
        observableDevice.descriptionText = 'paired';
        // Define description for paired device.
        if (observableDevice.connectionStatus === 'connecting') {
          observableDevice.descriptionText = 'connecting';
        } else if (observableDevice.connectionStatus === 'connected') {
          if (observableDevice.profiles) {
            const hfpConnected = observableDevice.profiles.hfp;
            const a2dpConnected = observableDevice.profiles.a2dp;
            if (hfpConnected && a2dpConnected) {
              observableDevice.descriptionText = 'connectedWithDeviceMedia';
            } else if (hfpConnected) {
              observableDevice.descriptionText = 'connectedWithDevice';
            } else if (a2dpConnected) {
              observableDevice.descriptionText = 'connectedWithMedia';
            } else {
              observableDevice.descriptionText = 'connectedWithNoProfileInfo';
            }
          } else {
            observableDevice.descriptionText = 'connectedWithNoProfileInfo';
          }
        } else if (observableDevice.connectionStatus === 'disconnected') {
          observableDevice.descriptionText = 'disconnected';
        }
      }
    }

    device.onattributechanged = function onattributechanged(evt) {
      // eslint-disable-next-line guard-for-in
      for (const i in evt.attrs) {
        switch (evt.attrs[i]) {
          case 'name':
            observableDevice.name = device.name;
            break;
          case 'paired':
            observableDevice.paired = device.paired;
            break;
          case 'cod':
            observableDevice.type = BtClassOfDeviceMapper.getDeviceType(
              device.cod
            );
            observableDevice.hasAudioCard = BtClassOfDeviceMapper.hasAudioCard(
              device.cod
            );
            break;
          default:
            break;
        }
      }
    };

    return observableDevice;
  };

  //* **********Bluetooth Device End*************************

  const contextInfo = {
    state: 'disabled',
    enabled: null,
    address: null,
    name: '',
    discoverable: false,
    discovering: false,
    numberOfPairedDevices: 0,
    firstPairedDeviceName: '',
    hasPairedDevice: false,
    hasFoundDevice: false,
    paired: false,
    scanTimeoutId: null,
    remoteDevices: [],
    pairedDevices: [],
    discoveryHandler: null
  };

  function syncWithSettingsKey(enabled) {
    SettingsDBCache.getSetting('bluetooth.enabled').then(value => {
      const btEnabled = value;
      if (btEnabled !== enabled) {
        SettingsDBCache.saveSettings({ 'bluetooth.enabled': enabled });
      }
    });
  }

  function updateStatus(state) {
    // Wrapper state to enabled/disabled toggle state.
    let enabled = null;
    if (state === 'enabled' || state === 'disabling') {
      enabled = true;
    } else if (state === 'disabled' || state === 'enabling') {
      enabled = false;
    }
    contextInfo.state = state;
    contextInfo.enabled = enabled;
    syncWithSettingsKey(enabled);
  }

  function initProperties(adapter) {
    // Init observable properties
    updateStatus(adapter.state);
    contextInfo.address = adapter.address;
    contextInfo.name = adapter.name;
    contextInfo.discoverable = adapter.discoverable;
    contextInfo.discovering = adapter.discovering;
  }

  function onAdapterAttributeChanged(adapter, evt) {
    let isBtChanged = false;
    // eslint-disable-next-line guard-for-in
    for (const i in evt.attrs) {
      switch (evt.attrs[i]) {
        case 'state':
          updateStatus(adapter.state);
          if (adapter.state === 'enabled') {
            // Init paired device information while Bluetooth is enabled.
            refreshPairedDevicesInfo(adapter);
          }
          isBtChanged = true;
          break;
        case 'address':
          contextInfo.address = adapter.address;
          isBtChanged = true;
          break;
        case 'name':
          contextInfo.name = adapter.name;
          isBtChanged = true;
          break;
        case 'discoverable':
          contextInfo.discoverable = adapter.discoverable;
          isBtChanged = true;
          break;
        case 'discovering':
          contextInfo.discovering = adapter.discovering;
          dispatchEventForBT('discovering');
          if (!contextInfo.discovering && contextInfo.scanTimeoutId) {
            clearTimeout(contextInfo.scanTimeoutId);
            contextInfo.scanTimeoutId = null;
          }
          break;
        default:
          break;
      }
    }
    if (isBtChanged) {
      dispatchEventForBT('adapter-info');
    }
  }

  function initConnectingDevices() {
    // Init the paired device connection status for connecting device.
    if (!BTConnectionManager.connectingAddress) {
      return;
    }

    const existedDevice = findDeviceByAddress({
      paired: true,
      address: BTConnectionManager.connectingAddress
    });
    if (existedDevice) {
      // The connecting device is existed. Init connection status for it.
      const options = {
        connectionStatus: 'connecting'
      };
      existedDevice.updateConnectionInfo(options);
    }
  }

  function getPairedDevices() {
    return contextInfo.pairedDevices;
  }

  function getRemoteDevices() {
    return contextInfo.remoteDevices;
  }

  function findDeviceByAddress(options) {
    // Distinguish to find the specific device in remote/paired devices list.
    const operatingDevices = options.paired
      ? getPairedDevices()
      : getRemoteDevices();
    let index = -1;
    for (let i = 0; i < operatingDevices.length; i++) {
      if (options.address === operatingDevices[i].address) {
        index = i;
        break;
      }
    }

    if (index > -1) {
      return operatingDevices[index];
    }
    return null;
  }

  function initConnectedDevices() {
    // Init the connection status of paired device for connected device.
    BTConnectionManager.getConnectedDevices().then(
      connectedDevices => {
        // eslint-disable-next-line guard-for-in
        for (const address in connectedDevices) {
          const existedDevice = findDeviceByAddress({
            paired: true,
            address
          });

          if (existedDevice) {
            /*
             * The connected device is existed.
             * Init connection status/profiles for it.
             */
            const options = {
              connectionStatus: 'connected',
              profiles: connectedDevices[address].connectedProfiles
            };
            existedDevice.updateConnectionInfo(options);
          }
        }
      },
      reason => {
        DebugHelper.debug(
          `${'initConnectedDevices(): getConnectedDevices(): failed, ' +
            'reason = '}${reason}`
        );
      }
    );
  }

  function refreshPairedDevicesInfo(adapter) {
    const pairedDevices = adapter.getPairedDevices();
    DebugHelper.debug(`pairedDevices.length = ${pairedDevices.length}`);

    // Reset paired devices list
    contextInfo.pairedDevices = [];

    // Refresh properties about paired devices
    if (pairedDevices.length === 0) {
      // Reset the name
      contextInfo.firstPairedDeviceName = '';
      // Update property 'hasPairedDevice'
      contextInfo.hasPairedDevice = false;
    } else {
      //Modify by dapeng.wang for defectGF5GTMO-4787 2024/11/20 begin
      //delete sort paired device new pair device put the first position
      // Sort paired devices
      //pairedDevices.sort((a, b) => a.name > b.name);
      // Save paired devices in list
      // eslint-disable-next-line guard-for-in
      for (let i = pairedDevices.length - 1; i >= 0; i--) {
        // Create observable BtDevice
        const observableBtDevice = BTDevice(pairedDevices[i]);
        // Push device in devices list with observable object
        contextInfo.pairedDevices.push(observableBtDevice);
      }
      //Modify by dapeng.wang for defectGF5GTMO-4787 2024/11/20 end
      // Set the name
      contextInfo.firstPairedDeviceName = contextInfo.pairedDevices[0].name;
      // Update property 'hasPairedDevice'
      contextInfo.hasPairedDevice = true;
      // Update connection status and profile for these paired devices.
      initConnectingDevices();
      initConnectedDevices();
    }

    contextInfo.numberOfPairedDevices = pairedDevices.length;
    window.dispatchEvent(new CustomEvent('paired-devices-change'));
  }

  function onAdapterDevicepaired(adapter, evt) {
    contextInfo.paired = true;
    window.dispatchEvent(
      new CustomEvent('paired-change', {
        detail: {
          device: evt.device
        }
      })
    );
    refreshPairedDevicesInfo(adapter);
  }

  function onAdapterDeviceunpaired(adapter) {
    refreshPairedDevicesInfo(adapter);
  }

  function onDefaultAdapterChanged(adapter) {
    initProperties(adapter);
    // eslint-disable-next-line
    adapter.ondevicepaired = onAdapterDevicepaired.bind(this, adapter);
    // eslint-disable-next-line
    adapter.ondeviceunpaired = onAdapterDeviceunpaired.bind(this, adapter);
    // Init paired device information while Bluetooth is enabled
    if (adapter.state === 'enabled') {
      refreshPairedDevicesInfo(adapter);
    }
  }

  function updateDeviceConnectionInfo(event) {
    const eventDetail = event.detail;
    const existedDevice = findDeviceByAddress({
      paired: true,
      address: eventDetail.address
    });
    if (existedDevice) {
      // The device is existed, update device info by event type.
      let options = {};
      switch (eventDetail.type) {
        case 'connecting':
        case 'connected':
        case 'disconnected':
          options = {
            connectionStatus: eventDetail.type
          };
          break;
        case 'profileChanged':
          options = {
            profiles: eventDetail.profiles
          };
          break;
        default:
          break;
      }
      existedDevice.updateConnectionInfo(options);
    } else {
      // If the device is not existed yet, do nothing here.
    }
  }

  function init(defaultAdapter) {
    onDefaultAdapterChanged(defaultAdapter);
    window.addEventListener(
      'connection-info-change',
      updateDeviceConnectionInfo
    );
  }

  function setEnabled(enabled) {
    return new Promise(resolve => {
      if (
        contextInfo.enabled === enabled ||
        contextInfo.state === 'enabling' ||
        contextInfo.state === 'disabling'
      ) {
        DebugHelper.log('setEnabled state transition!!');
        resolve(false);
      }
      if (enabled) {
        BluetoothHelper.adapter.enable().then(
          () => {
            contextInfo.state = 'enabled';
            DebugHelper.debug('set enable successfully.');
            resolve(true);
          },
          reason => {
            DebugHelper.log(`set enable failed: reason = ${reason}`);
            resolve(false);
          }
        );
      } else {
        BluetoothHelper.adapter.disable().then(
          () => {
            contextInfo.state = 'disabled';
            DebugHelper.debug('set disable successfully.');
            resolve(true);
          },
          reason => {
            DebugHelper.log(`set disable failed: reason = ${reason}`);
            resolve(false);
          }
        );
      }
    });
  }

  function setDiscoverable(enabled) {
    return new Promise(resolve => {
      if (
        contextInfo.discoverable === enabled ||
        contextInfo.state !== 'enabled'
      ) {
        DebugHelper.log('same state or Bluetooth is disabled!!');
        resolve(false);
      }
      BluetoothHelper.adapter.setDiscoverable(enabled).then(
        () => {
          resolve(true);
        },
        reason => {
          DebugHelper.log(
            `set discoverable failed: ' +
          'reason = '${reason}`
          );
          resolve(false);
        }
      );
    });
  }

  function stopDiscovery() {
    return new Promise(resolve => {
      if (contextInfo.discovering === false) {
        resolve(true);
      }

      if (contextInfo.scanTimeoutId) {
        clearTimeout(contextInfo.scanTimeoutId);
        contextInfo.scanTimeoutId = null;
      }

      BluetoothHelper.adapter.stopDiscovery().then(
        () => {
          contextInfo.discovering = false;
          dispatchEventForBT('discovering');
          DebugHelper.debug('stopDiscovery successfully.');
          resolve(true);
        },
        reason => {
          contextInfo.discovering = false;
          dispatchEventForBT('discovering');
          DebugHelper.log(`stopDiscovery failed:${reason}`);
          resolve(false);
        }
      );
    });
  }

  function dispatchEventForBT(type) {
    switch (type) {
      case 'discovering':
        window.dispatchEvent(
          new CustomEvent(`${type}-change`, {
            detail: {
              discovering: contextInfo.discovering
            }
          })
        );
        break;
      default:
        window.dispatchEvent(new CustomEvent(`${type}-change`));
        break;
    }
  }

  function resetPbmapSetting(address) {
    SettingsDBCache.getSetting(BLUETOOTH_PBAP).then(value => {
      if (value && value === address) {
        const obj = {};
        obj[BLUETOOTH_PBAP] = null;
        SettingsDBCache.saveSettings(obj);
      }
    });
    SettingsDBCache.getSetting(BLUETOOTH_MAP).then(value => {
      if (value && value === address) {
        const obj = {};
        obj[BLUETOOTH_MAP] = null;
        SettingsDBCache.saveSettings(obj);
      }
    });
  }

  function pairDevice(toPair, address) {
    if (toPair) {
      return new Promise(resolve => {
        stopDiscovery().then(result => {
          if (result) {
            BluetoothHelper.adapter.pair(address).then(
              () => {
                DebugHelper.debug('adapter.pair success');
                resolve(true);
              },
              reason => {
                DebugHelper.log(`adapter.pair failed: ${reason}`);
                resolve(false);
              }
            );
          } else {
            resolve(false);
          }
        });
      });
    }
    return new Promise(resolve => {
      BluetoothHelper.adapter.unpair(address).then(
        () => {
          resetPbmapSetting(address);
          DebugHelper.debug(`unpair success. Address: ${address}`);
          resolve(true);
        },
        reason => {
          DebugHelper.log(`unpair failed. reason:  ${reason}`);
          resolve(false);
        }
      );
    });
  }

  function saveDevice(device) {
    // Find the device is existed in devices list or not.
    const existedDevice = findDeviceByAddress({
      paired: device.paired,
      address: device.address
    });

    /*
     * If the device is not existed yet, create observable object
     * for saving this device.
     */
    if (!existedDevice) {
      // Create observable BtDevice
      const observableBtDevice = BTDevice(device);
      // Push device in devices list with observable object
      if (device.paired) {
        contextInfo.pairedDevices.push(observableBtDevice);
      } else {
        contextInfo.remoteDevices.push(observableBtDevice);
      }
      window.dispatchEvent(
        new CustomEvent('new-device-found', {
          detail: {
            device: observableBtDevice
          }
        })
      );
    }
  }

  function onDeviceFound(evt) {
    // Save device
    contextInfo.hasFoundDevice = true;
    window.dispatchEvent(
      new CustomEvent('hasFoundDevice-change', {
        hasFoundDevice: contextInfo.hasFoundDevice
      })
    );
    saveDevice(evt.device);
  }

  function startDiscovery() {
    if (contextInfo.discovering === true) {
      return Promise.resolve(true);
    }

    contextInfo.scanTimeoutId = setTimeout(() => {
      stopDiscovery();
    }, SCANTIMEOUT);

    return BluetoothHelper.adapter.startDiscovery().then(
      handle => {
        // Clean up found devices list
        contextInfo.remoteDevices = [];
        contextInfo.hasFoundDevice = false;
        contextInfo.discoveryHandler = handle;
        contextInfo.discoveryHandler.ondevicefound = onDeviceFound;
        DebugHelper.debug('startDiscovery successfully.');
        return Promise.resolve(true);
      },
      reason => {
        DebugHelper.log(`startDiscovery failed:${reason}`);
        return Promise.resolve(false);
      }
    );
  }

  function setName(name) {
    return new Promise(resolve => {
      if (name === contextInfo.name) {
        DebugHelper.log(`set name failed: same name`);
        resolve(false);
      }
      BluetoothHelper.adapter.setName(name).then(
        () => {
          resolve(true);
        },
        reason => {
          DebugHelper.log(`setName(): set name failed: reason = ${reason}`);
          resolve(false);
        }
      );
    });
  }

  return {
    init,
    setName,
    onAdapterAttributeChanged,
    get info() {
      return contextInfo;
    },
    setEnabled,
    setDiscoverable,
    getRemoteDevices,
    pairDevice,
    startDiscovery,
    stopDiscovery,
    getPairedDevices
  };
})();
