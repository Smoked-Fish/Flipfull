/* globals BluetoothContext, BTConnectionManager */
'use strict';
// eslint-disable-next-line
window.BluetoothHelper = (function BluetoothHelper() {
  let defaultAdapter = null;

  function attributeChangedHandler(evt) {
    BluetoothContext.onAdapterAttributeChanged(defaultAdapter, evt);
  }

  function watchAttributeChanged(newAdapter, oldAdapter) {
    if (oldAdapter) {
      oldAdapter.removeEventListener(
        'attributechanged',
        attributeChangedHandler
      );
    }
    newAdapter.addEventListener('attributechanged', attributeChangedHandler);
  }

  function init() {
    // eslint-disable-next-line prefer-destructuring
    defaultAdapter = ApiManager.bluetooth.defaultAdapter;
    watchAttributeChanged(defaultAdapter);
    ApiManager.bluetooth.addEventListener('attributechanged', evt => {
      // eslint-disable-next-line guard-for-in
      for (const i in evt.attrs) {
        switch (evt.attrs[i]) {
          case 'defaultAdapter': {
            const oldAdapter = defaultAdapter;
            // eslint-disable-next-line
            defaultAdapter = ApiManager.bluetooth.defaultAdapter;
            watchAttributeChanged(defaultAdapter, oldAdapter);
            break;
          }
          default:
            break;
        }
      }
    });
    const btFiles = [
      'js/utils/bluetooth_connection_manager.js',
      'js/utils/bluetooth_context.js'
    ];
    LazyLoader.load(btFiles, () => {
      BTConnectionManager.init(defaultAdapter);
      BluetoothContext.init(defaultAdapter);
    });
  }

  return {
    init,
    get adapter() {
      return defaultAdapter;
    }
  };
})();
window.BluetoothHelper.init();
