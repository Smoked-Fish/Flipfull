/* globals MobileOperator */
'use strict';
// eslint-disable-next-line
window.SimCardHelper = (function SimCardHelper() {
  // 'ril.data.defaultServiceId'
  const defaultServiceId = 0;
  const simInfos = [
    {
      iccId: null,
      capabilityStatus: '',
      dataStatus: '',
      cardState: ''
    },
    {}
  ];

  function getCardDescription(key) {
    return Constants.CARD_STATE_MAP[key] || key;
  }

  function init() {
    if (!ApiManager.connections) return;
    if (isDoubleSimSlot()) {
      simInfos[0].iccId = ApiManager.connections[0].iccId;
      addListenersForSimCard(0);
      simInfos[1].iccId = ApiManager.connections[1].iccId;
      addListenersForSimCard(1);
    } else {
      simInfos[0].iccId = ApiManager.connections[0].iccId;
      addListenersForSimCard(0);
    }
    ApiManager.telephony.addEventListener('callschanged', () => {
      window.dispatchEvent(new CustomEvent('Telephony-callschanged'));
    });
  }

  function hasValidCard() {
    if (simInfos[0].iccId || simInfos[1].iccId) {
      return true;
    }
    return false;
  }

  function getImsCapability() {
    // Begin added by kangkangma for PR GF5GTMO-7040 on 2025/04/03
    const defaultServiceId0 = 0;
    const defaultServiceId1 = 1;
    const  imsHandler0  = ApiManager.connections[defaultServiceId0].imsHandler;
    const  imsHandler1  = ApiManager.connections[defaultServiceId1].imsHandler;
    if (imsHandler0 && imsHandler0.capability) {
        return imsHandler0.capability;
    }
    if (imsHandler1 && imsHandler1.capability) {
        return imsHandler1.capability;
    }
    // End added by kangkangma for PR GF5GTMO-7040 on 2025/04/03
    return null;
  }

  function isDoubleSimSlot() {
    return ApiManager.connections.length > 1;
  }

  function getIccInfo(cardIndex) {
    const { iccId } = ApiManager.connections[cardIndex];
    return ApiManager.iccManager.getIccById(iccId);
  }
   // Begin added by kangkangma for PR GF5GTMO-7040 on 2025/04/03
   function getSimCardNumber(iccId){
    const ICCManager = navigator.b2g.iccManager;
    let simNumber = '';
    let iccInfoDetail = ICCManager.getIccById(iccId).iccInfo;
    if (iccInfoDetail.msisdn || iccInfoDetail.mdn) {
       simNumber = iccInfoDetail.msisdn || iccInfoDetail.mdn;
    }
    return simNumber;
  }
  function removeCountryCode(phoneNumber, countryCode) {
    if (countryCode === '1') {
        return phoneNumber.replace(/^\+/, '');
    } else {
        const regex = new RegExp(`^\\+${countryCode}(\\s?)`);
        return phoneNumber.replace(regex, '');
    }
  }

  function getSimCardInfo(mobileConnection) {
    return new Promise(resolve => {
        if(!mobileConnection){
          resolve(l10n.get('no-operator'));
        }
        let simNameAndNumber;
        const { iccId } = mobileConnection;
        const icc = ApiManager.iccManager.getIccById(iccId);
        const iccInfo = icc.iccInfo;
        const mcc = iccInfo.mcc;
        let phoneNumber = getSimCardNumber(iccId);
        PhoneNumberUtils.parseWithMCC(phoneNumber, mcc).then( pNumber => {
          SettingsDBCache.getSetting('custom.simcards.name').then(value => {
              const customSimName = value;
              if (customSimName && customSimName[iccId]) {
                 if(!pNumber){
                    resolve(customSimName[iccId]);
                 }
                 pNumber = removeCountryCode(pNumber.internationalFormat,pNumber.regionMetaData.countryCode);
                 simNameAndNumber = customSimName[iccId] + "  " + pNumber.replace(' ','\u00A0');
                resolve(simNameAndNumber);
              }else{
                const operatorInfo = MobileOperator.userFacingInfo(mobileConnection);
                const operatorName = operatorInfo.operator !== null ? operatorInfo.operator : getTmoSimName(icc);
                if (operatorName) {
                  if(!pNumber){
                    resolve(operatorName);
                  }
                  pNumber = removeCountryCode(pNumber.internationalFormat,pNumber.regionMetaData.countryCode);
                  simNameAndNumber = operatorName + "  " + pNumber.replace(' ','\u00A0');
                  resolve(simNameAndNumber);
                } else {
                  resolve(l10n.get('no-operator'));
                }
              }
            });
          });
    });
  }
  // End added by kangkangma for PR GF5GTMO-7002/GF5GTMO-7002 on 2025/04/23

  // [GF5GTMO-7051] added by yuwei.fang, 2025-04-22
  function getIccId(cardIndex) {
    const { iccId } = ApiManager.connections[cardIndex];
    return iccId;
  }

  // [GF5GTMO-7052] begin added by yuwei.fang, 2025-04-30
  function getPhoneNumber(iccId) {
    return new Promise(resolve => {
      SettingsDBCache.getSetting('simcards.phone.number').then(value => {
        if (!iccId) {
          resolve('');
          return;
        }
        // 1.check database phone number
        let dbNumber = '';
        const phoneNumbers = value || {};
        if (phoneNumbers && phoneNumbers[iccId]) {
          dbNumber = phoneNumbers[iccId];
        }
        const icc = ApiManager.iccManager.getIccById(iccId);
        if (!icc) {
          resolve(dbNumber);
          return;
        }
        // 2.get phone number from iccInfo
        let iccNumber = '';
        const iccInfo = icc.iccInfo;
        const mcc = iccInfo.mcc;
        let phoneNumber = getSimCardNumber(iccId);
        PhoneNumberUtils.parseWithMCC(phoneNumber, mcc).then(pNumber => {
          if (pNumber) {
            iccNumber = removeCountryCode(pNumber.internationalFormat, pNumber.regionMetaData.countryCode);
            // 3.if number changed, update database
            if (iccNumber && iccNumber !== dbNumber) {
              phoneNumbers[iccId] = iccNumber
              SettingsDBCache.saveSettings({
                'simcards.phone.number': phoneNumbers
              });
            }
          }
          resolve(iccNumber || dbNumber);
        });
      });
    });
  }
  // [GF5GTMO-7052] end added by yuwei.fang, 2025-04-30

  function getOperatorName(mobileConnection) {
    return new Promise(resolve => {
      SettingsDBCache.getSetting('custom.simcards.name').then(value => {
        const { iccId } = mobileConnection;
        const customSimName = value;
        if (customSimName && customSimName[iccId]) {
          resolve(customSimName[iccId]);
        } else {
          const operatorInfo = MobileOperator.userFacingInfo(mobileConnection);
          if (operatorInfo.operator) {
            resolve(operatorInfo.operator);
          } else {
            // [GF5GTMO-7002] begin modified by yuwei.fang, 2025-04-06
            const icc = ApiManager.iccManager.getIccById(iccId);
            const tmoSimName = getTmoSimName(icc);
            dump("sim_card_helper - tmoSimName: " + tmoSimName);
            resolve(tmoSimName || l10n.get('no-operator'));
            // [GF5GTMO-7002] end modified by yuwei.fang, 2025-04-06
          }
        }
      });
    });
  }

  // [GF5GTMO-7002] begin added by yuwei.fang, 2025-04-06
  function getTmoSimName(icc) {
    if (!icc) {
      return '';
    } else {
      const iccInfo = icc.iccInfo;
      const mccMnc = iccInfo.mcc + iccInfo.mnc;
      const gid1 = iccInfo.gid1;
      if (OperatorUtils.TMO_MCC_MNC.indexOf(mccMnc) > -1) {
        if (gid1 === '6d38') {
          return 'Metro by T-Mobile';
        } else if (gid1 === '1a53') {
          return 'Assurance Wireless';
        } else {
          return 'T-Mobile';
        }
      } else {
        return '';
      }
    }
  }
  // [GF5GTMO-7002] end added by yuwei.fang, 2025-04-06

  function listenIccStatusChange(cardIndex) {
    const iccCard = getIccInfo(cardIndex);
    if (!iccCard) {
      return;
    }
    iccCard.oncardstatechange = status => {
      simInfos[cardIndex].cardState = status;
      window.dispatchEvent(
        new CustomEvent('SIM-cardstatechange', {
          detail: { index: cardIndex, status }
        })
      );
    };
  }

  function addListenersForSimCard(cardIndex) {
    const { imsHandler } = ApiManager.connections[cardIndex];
    if (imsHandler) {
      imsHandler.addEventListener('capabilitychange', status => {
        simInfos[cardIndex].capabilityStatus = status;
        window.dispatchEvent(
          new CustomEvent('SIM-capabilitychange', {
            detail: { index: cardIndex, capabilityStatus: status }
          })
        );
      });
    }
    ApiManager.connections[cardIndex].addEventListener('datachange', status => {
      simInfos[cardIndex].dataStatus = status;
      window.dispatchEvent(
        new CustomEvent('SIM-datachange', {
          detail: { index: cardIndex, status }
        })
      );
    });

    ApiManager.connections[cardIndex].addEventListener(
      'radiostatechange',
      status => {
        simInfos[cardIndex].radiostate = status;
        window.dispatchEvent(
          new CustomEvent('SIM-radiostatechange', {
            detail: { index: cardIndex, status }
          })
        );
      }
    );

    ApiManager.connections[cardIndex].addEventListener(
      'voicechange',
      status => {
        simInfos[cardIndex].dataStatus = status;
        window.dispatchEvent(
          new CustomEvent('SIM-voicechange', {
            detail: { index: cardIndex, status }
          })
        );
      }
    );

    ApiManager.iccManager.addEventListener(
      'iccdetected',
      function iccDetectedHandler(evt) {
        if (ApiManager.connections[cardIndex].iccId === evt.iccId) {
          simInfos[cardIndex].iccId = evt.iccId;
          listenIccStatusChange(cardIndex);
        }
      }
    );
    ApiManager.iccManager.addEventListener(
      'iccundetected',
      function iccUndetectedHandler(evt) {
        if (simInfos[cardIndex].iccId === evt.iccId) {
          simInfos[cardIndex].iccId = null;
        }
      }
    );

    listenIccStatusChange(cardIndex);
  }

  return {
    init,
    getCardDes: getCardDescription,
    defaultServiceId,
    hasValidCard,
    getImsCapability,
    isDoubleSimSlot,
    getIccInfo,
    getIccId,
    getPhoneNumber,
    getOperatorName,
    getSimCardInfo // Modified by kangkangma for PR GF5GTMO-7002/GF5GTMO-7002 on 2025/04/24
  };
})();
