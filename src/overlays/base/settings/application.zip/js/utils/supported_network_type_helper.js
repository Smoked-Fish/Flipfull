/* exported SupportedNetworkTypeHelper */

'use strict';

(function supportedNetworkType(exports) {
  // The network types displayed on the list for user selection
  const NETWORK_TYPES = [
    'wcdma/gsm',
    'gsm',
    'wcdma',
    'wcdma/gsm-auto',
    'cdma/evdo',
    'cdma',
    'evdo',
    'wcdma/gsm/cdma/evdo',
    'lte/cdma/evdo',
    'lte/wcdma/gsm',
    'lte/wcdma/gsm/cdma/evdo',
    'lte',
    'tdscdma',
    'wcdma/tdscdma',
    'lte/tdscdma',
    'tdscdma/gsm',
    'lte/tdscdma/gsm',
    'wcdma/tdscdma/gsm',
    'lte/wcdma/tdscdma',
    'lte/wcdma/tdscdma/gsm',
    'wcdma/tdscdma/gsm/cdma/evdo',
    'lte/wcdma/tdscdma/gsm/cdma/evdo',
    'nr',
    'nr/lte',
    'nr/lte/cdma/evdo',
    'nr/lte/wcdma/gsm',
    'nr/lte/wcdma/gsm/cdma/evdo',
    'nr/lte/wcdma',
    'nr/lte/tdscdma',
    'nr/lte/tdscdma/gsm',
    'nr/lte/wcdma/tdscdma',
    'nr/lte/wcdma/tdscdma/gsm',
    'nr/lte/wcdma/tdscdma/gsm/cdma/evdo'
  ];

  /*
   * The string map from network types to user friendly strings, which is
   * the combination of the three categories: 'GSM', 'CDMA', and 'LTE'.
   * The mapping is determined by the hardware supported types.
   */
  const NETWORK_TYPE_STRING_MAP = {
    CDMA: {
      'cdma/evdo': 'operator-networkType-auto',
      cdma: 'operator-networkType-CDMA',
      evdo: 'operator-networkType-EVDO'
    },
    LTE: {
      lte: 'operator-networkType-LTE'
    },
    NR: {
      nr: 'operator-networkType-NR'
    },
    GSM: {
      'wcdma/gsm': 'operator-networkType-prefer3G',
      gsm: 'operator-networkType-2G',
      wcdma: 'operator-networkType-3G',
      'wcdma/gsm-auto': 'operator-networkType-auto',
      'tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM',
      tdscdma: 'operator-networkType-TDSCDMA-ONLY',
      'wcdma/tdscdma': 'operator-networkType-TDSCDMA-WCDMA',
      'wcdma/tdscdma/gsm': 'operator-networkType-TDSCDMA-WCDMA-GSM'
    },
    'GSM,LTE': {
      'lte/wcdma/gsm': 'operator-networkType-auto',
      gsm: 'operator-networkType-2G',
      wcdma: 'operator-networkType-3G',
      'wcdma/gsm-auto': 'operator-networkType-auto-2G-3G',
      'wcdma/gsm': 'operator-networkType-prefer3G',
      lte: 'operator-networkType-4G',
      tdscdma: 'operator-networkType-TDSCDMA-ONLY',
      'wcdma/tdscdma': 'operator-networkType-TDSCDMA-WCDMA',
      'lte/tdscdma': 'operator-networkType-TDSCDMA-LTE',
      'tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM',
      'lte/tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM-LTE',
      'wcdma/tdscdma/gsm': 'operator-networkType-TDSCDMA-WCDMA-GSM',
      'lte/wcdma/tdscdma': 'operator-networkType-TDSCDMA-WCDMA-LTE',
      'lte/wcdma/tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM-WCDMA-LTE'
    },
    'GSM,LTE,NR': {
      'lte/wcdma/gsm': 'operator-networkType-auto-2G-3G-4G',
      gsm: 'operator-networkType-2G',
      wcdma: 'operator-networkType-3G',
      'wcdma/gsm-auto': 'operator-networkType-auto-2G-3G',
      'wcdma/gsm': 'operator-networkType-prefer3G',
      lte: 'operator-networkType-4G',
      tdscdma: 'operator-networkType-TDSCDMA-ONLY',
      'wcdma/tdscdma': 'operator-networkType-TDSCDMA-WCDMA',
      'lte/tdscdma': 'operator-networkType-TDSCDMA-LTE',
      'tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM',
      'lte/tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM-LTE',
      'wcdma/tdscdma/gsm': 'operator-networkType-TDSCDMA-WCDMA-GSM',
      'lte/wcdma/tdscdma': 'operator-networkType-TDSCDMA-WCDMA-LTE',
      'lte/wcdma/tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM-WCDMA-LTE',
      nr: 'operator-networkType-5G',
      'nr/lte': 'operator-networkType-prefer5G',
      'nr/lte/wcdma/gsm': 'operator-networkType-auto',
      'nr/lte/wcdma': 'operator-networkType-auto-3G-4G-5G',
      'nr/lte/tdscdma': 'operator-networkType-NR-LTE-TDSCDMA',
      'nr/lte/tdscdma/gsm': 'operator-networkType-NR-LTE-TDSCDMA-GSM',
      'nr/lte/wcdma/tdscdma': 'operator-networkType-NR-LTE-TDSCDMA-WCDMA',
      'nr/lte/wcdma/tdscdma/gsm':
        'operator-networkType-NR-LTE-TDSCDMA-GSM-WCDMA'
    },
    'CDMA,LTE': {
      'lte/cdma/evdo': 'operator-networkType-auto',
      'cdma/evdo': 'operator-networkType-auto-CDMA-EVDO',
      cdma: 'operator-networkType-CDMA',
      evdo: 'operator-networkType-EVDO',
      lte: 'operator-networkType-LTE'
    },
    'CDMA,LTE,NR': {
      'lte/cdma/evdo': 'operator-networkType-auto-LTE-CDMA-EVDO',
      'cdma/evdo': 'operator-networkType-auto-CDMA-EVDO',
      cdma: 'operator-networkType-CDMA',
      evdo: 'operator-networkType-EVDO',
      lte: 'operator-networkType-LTE',
      nr: 'operator-networkType-5G',
      'nr/lte': 'operator-networkType-prefer5G',
      'nr/lte/cdma/evdo': 'operator-networkType-auto'
    },
    'GSM,CDMA': {
      'wcdma/gsm': 'operator-networkType-preferWCDMA',
      gsm: 'operator-networkType-GSM',
      wcdma: 'operator-networkType-WCDMA',
      'wcdma/gsm-auto': 'operator-networkType-auto-WCDMA-GSM',
      'cdma/evdo': 'operator-networkType-auto-CDMA-EVDO',
      cdma: 'operator-networkType-CDMA',
      evdo: 'operator-networkType-EVDO',
      'wcdma/gsm/cdma/evdo': 'operator-networkType-auto',
      'tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM',
      tdscdma: 'operator-networkType-TDSCDMA-ONLY',
      'wcdma/tdscdma': 'operator-networkType-TDSCDMA-WCDMA',
      'wcdma/tdscdma/gsm': 'operator-networkType-TDSCDMA-WCDMA-GSM',
      'wcdma/tdscdma/gsm/cdma/evdo':
        'operator-networkType-TDSCDMA-GSM-WCDMA-CDMA-EVDO-AUTO'
    },
    'GSM,CDMA,LTE': {
      'wcdma/gsm': 'operator-networkType-preferWCDMA',
      gsm: 'operator-networkType-GSM',
      wcdma: 'operator-networkType-WCDMA',
      'wcdma/gsm-auto': 'operator-networkType-auto-WCDMA-GSM',
      'cdma/evdo': 'operator-networkType-auto-CDMA-EVDO',
      cdma: 'operator-networkType-CDMA',
      evdo: 'operator-networkType-EVDO',
      'wcdma/gsm/cdma/evdo': 'operator-networkType-auto-WCDMA-GSM-CDMA-EVDO',
      lte: 'operator-networkType-LTE',
      'lte/wcdma/gsm': 'operator-networkType-auto-LTE-WCDMA-GSM',
      'lte/cdma/evdo': 'operator-networkType-auto-LTE-CDMA-EVDO',
      'lte/wcdma/gsm/cdma/evdo': 'operator-networkType-auto',
      tdscdma: 'operator-networkType-TDSCDMA-ONLY',
      'wcdma/tdscdma': 'operator-networkType-TDSCDMA-WCDMA',
      'lte/tdscdma': 'operator-networkType-TDSCDMA-LTE',
      'tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM',
      'lte/tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM-LTE',
      'wcdma/tdscdma/gsm': 'operator-networkType-TDSCDMA-WCDMA-GSM',
      'lte/wcdma/tdscdma': 'operator-networkType-TDSCDMA-WCDMA-LTE',
      'lte/wcdma/tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM-WCDMA-LTE',
      'wcdma/tdscdma/gsm/cdma/evdo':
        'operator-networkType-TDSCDMA-GSM-WCDMA-CDMA-EVDO-AUTO',
      'lte/wcdma/tdscdma/gsm/cdma/evdo':
        'operator-networkType-LTE-TDSCDMA-CDMA-EVDO-GSM-WCDMA'
    },
    'GSM,CDMA,LTE,NR': {
      'wcdma/gsm': 'operator-networkType-preferWCDMA',
      gsm: 'operator-networkType-GSM',
      wcdma: 'operator-networkType-WCDMA',
      'wcdma/gsm-auto': 'operator-networkType-auto-WCDMA-GSM',
      'cdma/evdo': 'operator-networkType-auto-CDMA-EVDO',
      cdma: 'operator-networkType-CDMA',
      evdo: 'operator-networkType-EVDO',
      'wcdma/gsm/cdma/evdo': 'operator-networkType-auto-WCDMA-GSM-CDMA-EVDO',
      lte: 'operator-networkType-LTE',
      'lte/wcdma/gsm': 'operator-networkType-auto-LTE-WCDMA-GSM',
      'lte/cdma/evdo': 'operator-networkType-auto-LTE-CDMA-EVDO',
      'lte/wcdma/gsm/cdma/evdo':
        'operator-networkType-auto-LTE-WCDMA-GSM-CDMA-EVDO',
      tdscdma: 'operator-networkType-TDSCDMA-ONLY',
      'wcdma/tdscdma': 'operator-networkType-TDSCDMA-WCDMA',
      'lte/tdscdma': 'operator-networkType-TDSCDMA-LTE',
      'tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM',
      'lte/tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM-LTE',
      'wcdma/tdscdma/gsm': 'operator-networkType-TDSCDMA-WCDMA-GSM',
      'lte/wcdma/tdscdma': 'operator-networkType-TDSCDMA-WCDMA-LTE',
      'lte/wcdma/tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM-WCDMA-LTE',
      'wcdma/tdscdma/gsm/cdma/evdo':
        'operator-networkType-TDSCDMA-GSM-WCDMA-CDMA-EVDO-AUTO',
      'lte/wcdma/tdscdma/gsm/cdma/evdo':
        'operator-networkType-LTE-TDSCDMA-CDMA-EVDO-GSM-WCDMA',
      nr: 'operator-networkType-5G',
      'nr/lte': 'operator-networkType-prefer5G',
      'nr/lte/cdma/evdo': 'operator-networkType-auto-NR-LTE-CDMA-EVDO',
      'nr/lte/wcdma/gsm': 'operator-networkType--auto-NR-LTE-GSM-WCDMA',
      'nr/lte/wcdma/gsm/cdma/evdo': 'operator-networkType-auto',
      'nr/lte/wcdma': 'operator-networkType-auto-NR-LTE-WCDMA',
      'nr/lte/tdscdma': 'operator-networkType-NR-LTE-TDSCDMA',
      'nr/lte/tdscdma/gsm': 'operator-networkType-NR-LTE-TDSCDMA-GSM',
      'nr/lte/wcdma/tdscdma': 'operator-networkType-NR-LTE-TDSCDMA-WCDMA',
      'nr/lte/wcdma/tdscdma/gsm':
        'operator-networkType-NR-LTE-TDSCDMA-GSM-WCDMA',
      'nr/lte/wcdma/tdscdma/gsm/cdma/evdo':
        'operator-networkType-NR-LTE-TDSCDMA-CDMA-EVDO-GSM-WCDMA'
    },
    // Default value, the same as 'GSM,CDMA'.
    '': {
      'wcdma/gsm': 'operator-networkType-preferWCDMA',
      gsm: 'operator-networkType-GSM',
      wcdma: 'operator-networkType-WCDMA',
      'wcdma/gsm-auto': 'operator-networkType-auto-WCDMA-GSM',
      'cdma/evdo': 'operator-networkType-auto-CDMA-EVDO',
      cdma: 'operator-networkType-CDMA',
      evdo: 'operator-networkType-EVDO',
      'wcdma/gsm/cdma/evdo': 'operator-networkType-auto',
      'tdscdma/gsm': 'operator-networkType-TDSCDMA-GSM',
      tdscdma: 'operator-networkType-TDSCDMA-ONLY',
      'wcdma/tdscdma': 'operator-networkType-TDSCDMA-WCDMA',
      'wcdma/tdscdma/gsm': 'operator-networkType-TDSCDMA-WCDMA-GSM',
      'wcdma/tdscdma/gsm/cdma/evdo':
        'operator-networkType-TDSCDMA-GSM-WCDMA-CDMA-EVDO-AUTO'
    }
  };

  /**
   * SupportedNetworkTypeHelper helps map the supported network types to user
   * friendly strings.
   *
   * @param {Array} hwSupportedTypes Array of hardware supported types. The
   *                                 posssible values of the type are 'gsm',
   *                                 'cdma', 'wcdma', 'evdo', and 'lte'.
   */
  const SupportedNetworkTypeHelper = function SupportedNetworkTypeHelper(
    hwSupportedTypes
  ) {
    const hwSupportedTypeMap = {
      gsm: hwSupportedTypes.indexOf('gsm') !== -1,
      cdma: hwSupportedTypes.indexOf('cdma') !== -1,
      wcdma: hwSupportedTypes.indexOf('wcdma') !== -1,
      evdo: hwSupportedTypes.indexOf('evdo') !== -1,
      lte: hwSupportedTypes.indexOf('lte') !== -1,
      tdscdma: hwSupportedTypes.indexOf('tdscdma') !== -1,
      ecdo: hwSupportedTypes.indexOf('ecdo') !== -1,
      nr: hwSupportedTypes.indexOf('nr') !== -1
    };

    // Get all supported network types based on the hardware supported types.
    const networkTypes = NETWORK_TYPES.filter(type =>
      type
        .split('/')
        .every(subtype => hwSupportedTypeMap[subtype.split('-')[0]])
    );

    // Compose the string for NETWORK_TYPE_STRING_MAP table lookup.
    const stringMap =
      NETWORK_TYPE_STRING_MAP[
        ['GSM', 'CDMA', 'LTE', 'NR']
          .filter(category => {
            switch (category) {
              case 'GSM':
                return (
                  hwSupportedTypeMap.gsm ||
                  hwSupportedTypeMap.wcdma ||
                  hwSupportedTypeMap.tdscdma
                );
              case 'CDMA':
                return (
                  hwSupportedTypeMap.cdma ||
                  hwSupportedTypeMap.evdo ||
                  hwSupportedTypeMap.ecdo
                );
              case 'LTE':
                return hwSupportedTypeMap.lte;
              case 'NR':
                return hwSupportedTypeMap.nr;
              default:
              return; // eslint-disable-line
            }
          })
          .toString()
      ];

    return {
      get gsm() {
        return hwSupportedTypeMap.gsm;
      },
      get cdma() {
        return hwSupportedTypeMap.cdma;
      },
      get wcdma() {
        return hwSupportedTypeMap.wcdma;
      },
      get evdo() {
        return hwSupportedTypeMap.evdo;
      },
      get lte() {
        return hwSupportedTypeMap.lte;
      },
      get tdscdma() {
        return hwSupportedTypeMap.tdscdma;
      },
      get nr() {
        return hwSupportedTypeMap.nr;
      },
      get networkTypes() {
        return networkTypes;
      },
      l10nIdForType(type) {
        return stringMap[type];
      }
    };
  };

  exports.SupportedNetworkTypeHelper = SupportedNetworkTypeHelper;
})(window);
