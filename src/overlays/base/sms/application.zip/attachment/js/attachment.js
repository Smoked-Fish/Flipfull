/* global AttachmentRenderer, MimeMapper, Utils, DialogManager, SoftkeyManager */

(function(exports) {
  'use strict';

  // Download attachment save path.
  const ATTACHMENT_FOLDER_PATH = 'downloads/sms-attachments/';
  // Activity pending.
  let activityPending = false;

  // Get the attachment not extension.
  function getBaseName(filePath) {
    if (!filePath) {
      throw new Error('Filepath is not defined!');
    }
    return filePath.substring(filePath.lastIndexOf('/') + 1);
  }

  function Attachment(blob, options) {
    options = options || {};
    this.blob = blob;
    this.name = blob.name || options.name ||
                Utils.translateString('unnamed-attachment');
    // TaskGF5GTMO-3580-porting from Defect10730943-tingting.chao on 24/08/22-begin
    if(this.blob.type && (this.blob.type.toLowerCase() === 'text/x-vcard'
        || this.blob.type.toLowerCase() === 'text/vcard')){
      let fileReader = new FileReader();
      fileReader.readAsText(this.blob);
      fileReader.onloadend = () => {
        let contactObj = Utils.parseVcardName(fileReader.result);
        if(contactObj){
          let length = contactObj.length;
          let contactName;
          if(length == 1){
            contactName = contactObj[0].name;
          } else if (length > 1){
            for (let i = 0; i < length; i++) {
              if(i == 0){
                contactName = contactObj[i].name + ",";
              } else if(i == length -1){
                contactName += contactObj[i].name;
              } else {
                contactName += contactObj[i].name + ",";
              }
            }
          }
        this.updateVcardName(contactName);
        }
      }
    }
    // TaskGF5GTMO-3580-porting from Defect10730943-tingting.chao on 24/08/22-end
    this.isDraft = !!options.isDraft;
    Object.defineProperty(this, '_renderer', { writable: true });
  }

  Attachment.prototype = {
    _getAttachmentRenderer: function() {
      this._renderer = this._renderer || AttachmentRenderer.for(this);
      return this._renderer;
    },

    get size() {
      return this.blob.size;
    },

    get type() {
      return Utils.typeFromMimeType(this.blob.type);
    },

    render: function(readyCallback) {
      const attachmentRenderer = this._getAttachmentRenderer();
      attachmentRenderer.render().catch((e) => {
        console.error('Error occurred while rendering attachment.', e);
      }).then(readyCallback);
      return attachmentRenderer.getAttachmentContainer();
    },

    updateFileSize: function() {
      const attachmentRenderer = this._getAttachmentRenderer();
      attachmentRenderer.updateFileSize();
    },

    //TaskGF5GTMO-3580-porting from Defect10730943-tingting.chao on 24/08/22-begin
    updateVcardName: function(contactName) {
      let attachmentRenderer = this._getAttachmentRenderer();
      attachmentRenderer.updateFileName(contactName);
    },
    //TaskGF5GTMO-3580-porting from Defect10730943-tingting.chao on 24/08/22-end

    view: function(options) {
      // TODO Because the post result is not good, 
      // not handler activity pending first.
      if (activityPending) {
      //   return;
      }

      dump('View file mimetype,this.name = ' + this.name + " ,this.blob.type == " + this.blob.type.toLowerCase());
      let mimetype = MimeMapper.guessTypeFromFileProperties( //TaskGF5GTMO-3532-porting from Task10628729-tingting.chao on 2024/08/19
        //TaskGF5GTMO-3530-porting from Task10627236-tingting.chao on 2024/08/19-begin
        //this.name,
        this.name.toLowerCase(),
        //TaskGF5GTMO-3530-porting from Task10627236-tingting.chao on 2024/08/19-end
        this.blob.type.toLowerCase()
      );

      //TaskGF5GTMO-3532-porting from Task10628729-tingting.chao on 2024/08/19-begin
      if(this.blob.type.toLowerCase() === "application/ogg" || this.blob.type.toLowerCase() === "application/oct-stream"){
        mimetype = "audio/ogg";
      }
      //TaskGF5GTMO-3532-porting from Task10628729-tingting.chao on 2024/08/19-end
      let filename = MimeMapper.ensureFilenameMatchesType(this.name, mimetype);
      filename = ATTACHMENT_FOLDER_PATH + getBaseName(filename);
      dump('View file mimetype: ' + mimetype + ' ,blobType: ' + this.blob.type.toLowerCase() + ' ,filename = ' + filename)

      let detailName;
      let detailData;
      if ((mimetype === 'text/x-vcard' || mimetype === 'text/vcard' ||
           mimetype === 'text/directory') && (options && options.inComing)) {
        detailName = 'import';
        detailData = {
          type: mimetype,
          filename: filename,
          blob: this.blob
        };
      } else {
        detailName = 'open';
        detailData = {
          type: mimetype,
          filename: filename,
          blob: this.blob,
          allowSave: options && options.allowSave,
          forEditing: options && options.forEditing
        };
      }

      activityPending = true;
      // Record activity draft when page switch.
      Utils.saveActivityDraft();
      Utils.handleActivity(detailName, detailData, () => {
        Utils.discardActivityDraft();
        activityPending = false;
      }, (error) => {
        Utils.discardActivityDraft();
        activityPending = false;
        if (error === 'NO_PROVIDER') {
          DialogManager.alert('attachmentOpenError').then(() => {
            SoftkeyManager.updateLinkSKs();
          });
        }
        console.error('error with open activity', error.name);
      });
    }
  };

  exports.Attachment = Attachment;
}(this));
