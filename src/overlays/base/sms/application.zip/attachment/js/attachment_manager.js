/* global Settings, Attachment, Compose, Utils, OptionManager, 
          NavigationMap, ValueDefault, ThreadUI, AttachmentMessageUI,
          DialogManager, FocusStateManager, NotificationBase */

'use strict';

const attachments = new Map();

const AttachmentManager = {
  isReplaceFlag: false,

  // Attachment request.
  requestAttachment: function() {
    const requestProxy = {};
    const activityData = {
      type: ['image/*', 'audio/*', 'video/*', 'text/vcard']
    };

    if (Settings.mmsSizeLimitation) {
      activityData.maxFileSizeBytes = Settings.mmsSizeLimitation - Compose.size;
    }

    // Record activity draft when page switch.
    Utils.saveActivityDraft();

    Utils.handleActivity('pick', activityData, (result) => {
      Utils.discardActivityDraft();

      if (!Array.isArray(result)) {
        result = [result];
      }

      const attachmentMap = [];

      for (let i = 0; i < result.length; i++) {
        attachmentMap.push(new Attachment(result[i].blob, {
          name: result[i].name,
          isDraft: true
        }));
      }

      // The pick can only get the attachments which have one type.
      const size = attachmentMap.reduce((size, attachment) => {
        if (attachment.type !== 'img') {
          size += attachment.size;
        }

        return size;
      }, 0);

      if (size > Settings.mmsSizeLimitation) {
        if (typeof requestProxy.onerror === 'function') {
          requestProxy.onerror({ name: 'file too large' });
        }
        return;
      }

      if (typeof requestProxy.onsuccess === 'function') {
        requestProxy.onsuccess(attachmentMap);
      }
    }, (error) => {
      Utils.discardActivityDraft();
      if (typeof requestProxy.onerror === 'function') {
        requestProxy.onerror.call(requestProxy, error);
      }
    });

    return requestProxy;
  },

  // Attachment view event handler.
  onAttachClick: function() {
    const request = this.requestAttachment();
    request.onsuccess = this.addAttachments.bind(this);
    request.onerror = this._onAttachmentRequestError.bind(this);
  },

  // Attachment map operate.
  addAttachments: function(blobs, callback) {
    if (!Array.isArray(blobs)) {
      blobs = [blobs];
    }

    const canAddedAttachments = [];
    let allLimit = false;
    for (let i = 0; i < blobs.length; i++) {
      const needLimit = Utils.creationModeCheck(blobs[i], false);
      if (!needLimit) {
        canAddedAttachments.push(blobs[i]);
      }
      allLimit = allLimit || needLimit;
    }

    Utils.operatorCreationMode(allLimit, (isLimit) => {
      if (isLimit) {
        this.addEnabledAttachments(canAddedAttachments, callback);
      } else {
        this.addEnabledAttachments(blobs, callback);
      }
    });
  },

  _onAttachmentRequestError: function(err) {
    const errId = err.name;
    if (errId === 'file too large') {
      OptionManager.hideOptionMenu();
      DialogManager.alertExceedAlert(1, null);
    } else if (errId !== 'ActivityCanceled' && errId !== 'pick cancelled') {
      console.warn('Unhandled error: ', err);
    }
    this.isReplaceFlag = false;
  },

  addEnabledAttachments: function(blobs, callback) {
    if (blobs.length === 0) {
      callback && callback(false);
      return;
    }
    // We need see the blob size after all attachments added.
    for (let i = 0; i < blobs.length; i++) {
      this.addAttachment(blobs[i]);
    }
    this.imageAttachmentsResize((key) => {
      Compose.handlerContentChanged();
      // Attachments are not img type.
      if (key === 'areNoImage') {
        this.checkMessageSize();
      }
      callback && callback(true);
    });
  },

  addAttachment: function(item) {
    const attachmentComposer = document.querySelector('.js-attachment-composer');
    attachmentComposer.classList.remove('hide');
    attachmentComposer.classList.add('navigable');
    attachmentComposer.classList.remove('hasfocused');
    // Need reset the nav id because the map change.
    NavigationMap.reset('thread-messages');
    attachmentComposer.querySelector('.attachment-composer-title').textContent =
      item.name.substr(item.name.lastIndexOf('/') + 1);

    this.appendAttachment(item);
    this.updateAttachmentAbstract();

    if (!ValueDefault.activitymode) {
      ValueDefault.isFromNotification ? NotificationBase.scrollViewToBottom() : 
                                        ThreadUI.scrollViewToBottom();
    }
  },

  appendAttachment: function(item) {
    const fragment = this.insertAttachment(item);

    if (!fragment) {
      return this;
    }

    const attachmentDiv = document.createElement('div');
    attachmentDiv.appendChild(fragment);

    const attachmentList = document.getElementById('attachmentList');
    attachmentList.appendChild(attachmentDiv);

    // Need update the message status when attachment change.
    Compose.updateEmptyState();
    Compose.updateType();

    return this;
  },

  insertAttachment: function(item) {
    const fragment = document.createDocumentFragment();
    // Only one protection design.
    if (!item) {
      return null;
    }

    Compose.setNeedResizeState(true);
    // Adjust whether it is an attachment.
    if (item.render) {
      const node = item.render();
      node.classList.remove('navigable');
      // Save the attachment to backup array.
      attachments.set(node, item);
      fragment.appendChild(node);
    }

    return fragment;
  },

  removeAttachment: function(node, callback) {
    const attachmentList = document.getElementById('attachmentList');
    attachmentList.removeChild(node.parentNode);
    attachments.delete(node);
    Compose.setNeedResizeState(true);
    Compose.handlerContentChanged();
    callback();
  },

  deleteAttachment: function() {
    this.clearAttachment();
    // Need reset the nav id because the map change.
    NavigationMap.reset('thread-messages');

    window.addEventListener('menuEvent', function updateOptions() {
      window.removeEventListener('menuEvent', updateOptions);
      NavigationMap.setFocusToFixedElement('messages-input');
    });
    Compose.setNeedResizeState(true);
    Compose.updateEmptyState();
    Compose.updateType();
  },

  clearAttachment: function() {
    const attachmentComposer = document.querySelector('.js-attachment-composer');
    const attachmentList = document.getElementById('attachmentList');
    attachmentComposer.classList.add('hide');
    attachmentComposer.classList.remove('navigable');
    attachmentComposer.blur();
    attachmentComposer.classList.remove('focus');
    attachmentComposer.querySelector('.attachment-composer-title').textContent = '';
    NavigationMap.clearAttachmentStoreFocus();

    if (attachmentList) {
      attachmentList.innerHTML = '';
    }
    // Clear map object when delete action executed.
    attachments.clear();
    Compose.handlerContentChanged();

    if (!ValueDefault.activitymode) {
      ValueDefault.isFromNotification ? NotificationBase.scrollViewToBottom() : 
                                        ThreadUI.scrollViewToBottom();
    }
  },

  removeAttach: function() {
    const allAttachments = 
      document.getElementById('attachmentList').querySelectorAll('iframe');
    const focusEle = allAttachments[allAttachments.length - 1];

    this.removeAttachment(focusEle, () => {
      AttachmentMessageUI.updateAttachmentList();
      this.updateAttachmentAbstract();
      AttachmentMessageUI.updateOptionsBackUp();
    });

    FocusStateManager.dynamicSK();
  },

  replaceAttachment: function(node) {
    const request = this.requestAttachment();
    this.isReplaceFlag = true;
    request.onsuccess = (item) => {
      if (this.canReplaceAttachment(node, item)) {
        this.addAttachments(item, (canAdd) => {
          if (canAdd) {
            this.removeAttachment(node, () => {
              this.resetAttachmentUI();
              this.isReplaceFlag = false;
            });
          } else {
            this.resetAttachmentUI();
            this.isReplaceFlag = false;
          }
        });
      } else {
        DialogManager.alertExceedAlert(1, null);
        this.isReplaceFlag = false;
      }
    };
    request.onerror = this._onAttachmentRequestError;
  },

  canReplaceAttachment: function(node, item) {
    const replacedBlob = attachments.get(node);
    let replacingSize = 0;
    let isAllImage = true;
    for (let i = 0; i < item.length; i++) {
      replacingSize += item[i].size;
      isAllImage = isAllImage && item[i].type === 'img';
    }

    return isAllImage || (Compose.size - replacedBlob.size +
           replacingSize < Settings.mmsSizeLimitation);
  },

  // Image resize function.
  imageAttachmentsResize: function(callback) {
    const messageSize = Compose.size;

    if (messageSize < Settings.mmsSizeLimitation) {
      callback();
      FocusStateManager.dynamicSK();
      return;
    }

    const imgNodes = [];
    attachments.forEach((attachment, node) => {
      if (attachment.type === 'img') {
        imgNodes.push(node);
      }
    });

    let done = 0;
    const images = imgNodes.length;
    // Only resize the image object.
    if (images === 0) {
      callback('areNoImage');
      return;
    }

    const limit = images > 2 ? Settings.mmsSizeLimitation * 0.2 :
                             Settings.mmsSizeLimitation * 0.4;

    function imageSized() {
      if (++done === images) {
        // All images resize completed.
        Compose.setResizingState(false);
        if (!AttachmentManager.isReplaceFlag) {
          AttachmentManager.checkMessageSize();
        }
        callback();

        // It is a fix method for the special situation
        // that press right key continuously
        if (OptionManager.isOptionMenuShown()) {
          window.addEventListener('menuEvent', function updateOptions() {
            window.removeEventListener('menuEvent', updateOptions);
            FocusStateManager.dynamicSK();
          });
        } else {
          FocusStateManager.dynamicSK();
        }
      } else {
        resizedImg(imgNodes[done]);
      }
    }

    function resizedImg(node) {
      const item = attachments.get(node);
      if (item.blob.size < limit) {
        imageSized();
      } else {
        Utils.getResizedImgBlob(item.blob, limit, (resizedBlob) => {
          Compose.setNeedResizeState(true);
          // Update the resized image to original image.
          item.blob = resizedBlob;
          item.updateFileSize();

          imageSized();
        });
      }
    }

    Compose.setResizingState(true);
    resizedImg(imgNodes[0]);
  },

  // UI init.
  resetAttachmentUI: function() {
    AttachmentMessageUI.updateAttachmentList();
    const list = AttachmentMessageUI.attachmentList;
    AttachmentMessageUI.setFocus(list.length - 1);
    list[list.length - 1].parentNode.scrollIntoView(false);
    AttachmentMessageUI.focusCount = list.length - 1;
    this.updateRealAttachment(list[AttachmentMessageUI.focusCount]);
  },

  // Attachment description action.
  updateAttachmentAbstract: function() {
    const messageCount = this.getMessageCount();
    const attachmentComposer = document.querySelector('.js-attachment-composer');
    const label = attachmentComposer.querySelector('.attachment-composer-title');
    const extraNode = document.createElement('span');
    const deletedNode = attachmentComposer.querySelector('.extra-number');
    if (messageCount > 1) {
      const useLanguage = navigator.language;
      const translateNumber = (messageCount - 1).toLocaleString(useLanguage);
      let preString;
      if (deletedNode) {
        if (Utils.isNormalNumber(translateNumber)) {
          preString = '+' + (messageCount - 1);  
        } else {
          preString = (messageCount - 1) + '+';
        }
        deletedNode.textContent = '(' + preString + ')';
      } else {
        if (Utils.isNormalNumber(translateNumber)) {
          preString = '+' + (messageCount - 1);  
        } else {
          preString = (messageCount - 1) + '+';
        }
        extraNode.textContent = '(' + preString + ')';
        extraNode.classList.add('extra-number');
        attachmentComposer.appendChild(extraNode);
        label.classList.add('attachment-composer-title-with-adding');
      }
    } else {
      if (deletedNode) {
        attachmentComposer.removeChild(deletedNode);
        label.classList.remove('attachment-composer-title-with-adding');
      }
    }
  },

  updateRealAttachment: function(node) {
    const attachmentComposer = document.querySelector('.js-attachment-composer');
    const attachment = attachments.get(node);
    attachmentComposer.querySelector('.attachment-composer-title').textContent =
      attachment.name.substr(attachment.name.lastIndexOf('/') + 1);
    this.updateAttachmentAbstract();
  },

  // View attachment.
  openAttachment: function(element) {
    const attachmentItem = attachments.get(element);
    attachmentItem.view({ allowSave: false });
  },

  // Attachmemt content get.
  getAttachmentMap: function(node) {
    return attachments.get(node);
  },

  getAttachment: function() {
    const attachmentContent = [];
    attachments.forEach((attachment) => {
      attachmentContent.push(attachment);
    });
    return attachmentContent;
  },

  getMessageCount: function() {
    let count = 0;
    attachments.forEach(() => {
      count++;
    });
    return count;
  },

  // Total message size check.
  checkMessageSize: function() {
    if (Compose.isResizing || this.isReplaceFlag) {
      return false;
    }

    if (Settings.mmsSizeLimitation) {
      if (Compose.size > Settings.mmsSizeLimitation) {
        DialogManager.alertExceedAlert(1, this.removeAttach.bind(this));
        return false;
      } else if (Compose.size === Settings.mmsSizeLimitation) {
        Utils.showToaster({ l10nId: 'messages-max-length-text' });
        return true;
      }
    }

    return true;
  }
};
