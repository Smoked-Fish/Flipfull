/* global ValueDefault, SoftkeyManager, FocusStateManager, AttachmentMessageUI, 
          AttachmentManager, NavigationMap, Compose, OptionManager */

(function(exports) {
  'use strict';

  exports.AttachmentMessageUI = {
    // Init attachment page.
    init: function () {
      this.attachmentContainer = document.getElementById('attachmentMessage');
      // Set a array to save the all attachment nodes.
      this.attachmentList = [];
      this.focusCount = -1;
      this.updateOptionsBackUp = this.updateOptions.bind(this);
    },

    // Page enter.
    enterAttachmentPage: function() {
      this.attachmentContainer.classList.remove('hide');
      this.inputBox = document.getElementById('messages-to-field');
      this.attachmentField = document.querySelector('.js-attachment-composer');
      document.activeElement.blur();
      document.activeElement.classList.remove('focus');

      this.focusCount = 0;
      this.updateAttachmentList();
      this.inputBox && this.inputBox.classList.add('hide');

      ValueDefault.isAttachmentPage = true;
      this.attachmentList[this.focusCount].parentNode.scrollIntoView(false);
      setTimeout(() => {
        this.setFocus(this.focusCount);
      });
    },

    // Focus manager.
    setFocus: function(index) {
      const focusElement = this.attachmentList[index];
      focusElement.focus();
      focusElement.classList.add('focus');
      const innerElement = 
        focusElement.contentWindow.document.querySelector('.attachment-draft');
      if (!innerElement) {
        focusElement.addEventListener('load', function loaded() {
          focusElement.removeEventListener('load', loaded);
          const loadedElement = 
            focusElement.contentWindow.document.querySelector('.attachment-draft');
          loadedElement.classList.add('focus-text');
        });
      } else {
        innerElement.classList.add('focus-text');
      }
      SoftkeyManager.updateAttachmentKey();
    },

    removeFocus: function(index) {
      const focusElement = this.attachmentList[index];
      focusElement.blur();
      focusElement.classList.remove('focus');
      const innerElement = 
        focusElement.contentWindow.document.querySelector('.attachment-draft');
      innerElement.classList.remove('focus-text');
    },

    // Event handler.
    upEventHandler: function() {
      if (this.attachmentList.length > 1) {
        if (this.focusCount > 0) {
          this.focusCount--;
          this.removeFocus(this.focusCount + 1);
        } else {
          this.focusCount = this.attachmentList.length - 1;
          this.removeFocus(0);
        }
      }
      this.setFocus(this.focusCount);
      this.attachmentList[this.focusCount].parentNode.scrollIntoView(false);
    },

    downEventHandler: function() {
      if (this.attachmentList.length > 1) {
        if (this.focusCount < (this.attachmentList.length - 1)) {
          this.focusCount++;
          this.removeFocus(this.focusCount - 1);
        } else {
          this.focusCount = 0;
          this.removeFocus(this.attachmentList.length - 1);
        }
      }
      this.setFocus(this.focusCount);
      this.attachmentList[this.focusCount].parentNode.scrollIntoView(false);
    },

    // Page reset.
    resetPageStatus: function() {
      if (OptionManager.isOptionMenuShown()) {
        return;
      }
      if (this.attachmentList.length > 0) {
        this.removeFocus(this.focusCount);
      }
      this.attachmentField.focus();
      this.attachmentField.classList.add('focus');

      this.attachmentList = [];
      this.focusCount = -1;
      ValueDefault.isAttachmentPage = false;
      this.attachmentContainer.classList.add('hide');
      this.inputBox && this.inputBox.classList.remove('hide');
      FocusStateManager.dynamicSK();
    },

    updateAttachmentList: function() {
      this.attachmentList = [];
      const allAttachments =
        document.getElementById('attachmentList').querySelectorAll('iframe');
      for(let i = 0; i < allAttachments.length; i++) {
        this.attachmentList.push(allAttachments[i]);
      }
    },

    updateOptions: function() {
      window.removeEventListener('menuEvent',
        AttachmentMessageUI.updateOptionsBackUp);

      const count = this.focusCount;
      if (this.attachmentList.length > 0) {
        if (count >= 0) {
          const needIndex = count - 1;
          if (needIndex < 0) {
            this.setFocus(0);
          } else {
            this.setFocus(needIndex);
            if (needIndex === this.attachmentList.length - 1) {
              AttachmentManager.updateRealAttachment(
                this.attachmentList[needIndex]);
            }
          }
          this.focusCount = needIndex < 0 ? 0 : needIndex;
        } else {
          const attachmentPage = document.getElementById('attachmentMessage');
          const labelIframeArr = attachmentPage.querySelectorAll('iframe');
          if (labelIframeArr.length > 0) {
            AttachmentManager.updateRealAttachment(
              this.attachmentList[labelIframeArr.length - 1]);
          }
        }
      } else {
        this.resetPageStatus();
        AttachmentManager.clearAttachment();
        NavigationMap.reset('thread-messages');
        NavigationMap.setFocusToFixedElement('messages-input');
        Compose.updateEmptyState();
        Compose.updateType();
      }
    }
  };
}(this));
