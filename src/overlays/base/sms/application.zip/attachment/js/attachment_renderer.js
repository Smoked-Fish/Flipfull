/* global Template, Compose, Utils, ImageUtils */

(function(exports) {
  'use strict';

  // Limit allow preview size.
  const MAX_THUMBNAIL_GENERATION_SIZE = 5 * 1024 * 1024;
  // Preview size.
  const THUMBNAIL_SIZE = 100 * window.devicePixelRatio;
  // Attachment render object.
  const RENDERERS = {
    // Draft module.
    draft: {
      createAttachmentContainer: function() {
        const container = document.createElement('iframe');
        container.setAttribute('sandbox', 'allow-same-origin');
        return container;
      },

      renderTo: function(data, attachmentContainer) {
        attachmentContainer.classList.add(data.cssClass);

        const template = Template('attachment-draft-tmpl');
        const markup = template.interpolate({
          baseURL: location.protocol + '//' + location.host + '/',
          baseHTML: data.markup,
          cssClass: data.cssClass
        }, { safe: ['baseHTML'] });
        const blob = new Blob([markup], { type: 'text/html' });
        const blobUrl = window.URL.createObjectURL(blob);
        attachmentContainer.src = blobUrl;

        return this._whenLoaded(attachmentContainer).then(() => {
          window.URL.revokeObjectURL(blobUrl);
          const contentDocument = attachmentContainer.contentDocument;
          const documentElement = contentDocument.documentElement;
          Utils.translateFragment(documentElement);
          contentDocument.addEventListener('keydown', (evt) => {
            if (evt.key === 'Backspace' || evt.key === 'EndCall') {
              evt.stopPropagation();
              evt.preventDefault();
            }

            const keyEvt = new KeyboardEvent('keydown', {
              key: evt.key,
              charCode: evt.charCode,
              keyCode: evt.keyCode,
              bubbles: true,
              cancelable: true
            });
            attachmentContainer.parentElement.dispatchEvent(keyEvt);
          });

          contentDocument.addEventListener('keyup', (evt) => {
            const keyEvt = new KeyboardEvent('keyup', {
              key: evt.key,
              charCode: evt.charCode,
              keyCode: evt.keyCode,
              bubbles: true,
              cancelable: true
            });
            attachmentContainer.parentElement.dispatchEvent(keyEvt);
          });

          Compose.addEmptyFied(attachmentContainer);

          return contentDocument.body;
        });
      },

      _whenLoaded: function(iframe) {
        const innerDocument = iframe.contentDocument;
        if (innerDocument && innerDocument.body &&
            innerDocument.body.classList.contains('attachment-draft')) {
          return Promise.resolve();
        }

        return new Promise((resolve) => {
          iframe.addEventListener('load', function onload() {
            this.removeEventListener('load', onload);
            resolve();
          });
        });
      },

      getContentNode: function(attachmentContainer) {
        return this._whenLoaded(attachmentContainer).then(
          () => attachmentContainer.contentDocument.documentElement
        );
      },

      setL10nAttributes: function(element, l10nId, l10nArgs) {
        Utils.translateFromAtr(element, l10nId, l10nArgs);
        Utils.translateFragment(element);
      }
    },

    // New module.
    base: {
      createAttachmentContainer: function() {
        return document.createElement('div');
      },

      renderTo: function(data, attachmentContainer) {
        attachmentContainer.classList.add(data.cssClass);
        attachmentContainer.innerHTML = data.markup;
        return Promise.resolve(attachmentContainer);
      },

      getContentNode: function(attachmentContainer) {
        return Promise.resolve(attachmentContainer);
      },

      setL10nAttributes: function(element, l10nId, l10nArgs) {
        Utils.translateFromAtr(element, l10nId, l10nArgs);
      }
    }
  };

  const AttachmentRenderer = function(attachment) {
    this._attachment = attachment;
    this._renderer = attachment.isDraft ? RENDERERS.draft : RENDERERS.base;
    this._attachmentContainer = null;
  };

  AttachmentRenderer.prototype.getAttachmentContainer = function() {
    if (!this._attachmentContainer) {
      this._attachmentContainer = this._createAttachmentContainer();
    }
    return this._attachmentContainer;
  };

  AttachmentRenderer.prototype.render = function() {
    const attachmentContainer = this.getAttachmentContainer();
    const thumbnailPromise = this._attachment.type === 'img' &&
      this._attachment.size < MAX_THUMBNAIL_GENERATION_SIZE ?
        this.getThumbnail() : Promise.reject();

    // Preview attachment and Not preview attachment match function.
    return thumbnailPromise.then((thumbnail) => {
      return {
        markup: this._getBaseMarkup('attachment-preview-tmpl'),
        cssClass: 'preview',
        thumbnail: thumbnail
      };
    }).catch((error) => {
      return {
        markup: this._getBaseMarkup('attachment-nopreview-tmpl', !!error),
        cssClass: 'nopreview'
      };
    }).then((data) => {
      return this._renderer.renderTo(data, attachmentContainer).then((contentContainer) => {
        const thumbnailNode = contentContainer.querySelector('.thumbnail');
        if (thumbnailNode) {
          thumbnailNode.style.backgroundImage =
            'url("' + data.thumbnail.url + data.thumbnail.fragment + '")';
          attachmentContainer.dataset.thumbnail = data.thumbnail.url;
        }
      });
    });
  };

  AttachmentRenderer.prototype.updateFileSize = function() {
    const attachmentContainer = this.getAttachmentContainer();
    return this._renderer.getContentNode(attachmentContainer).then((contentNode) => {
      const sizeIndicator = contentNode.querySelector('.js-size-indicator');
      if (!sizeIndicator) {
        throw new Error('updateFileSize should be called after a render().');
      }

      const sizeL10n = Utils.getSizeForL10n(this._attachment.size);
      this._renderer.setL10nAttributes(
        sizeIndicator, sizeL10n.l10nId, sizeL10n.l10nArgs
      );
    });
  };

  //TaskGF5GTMO-3580-porting from Defect10730943-tingting.chao on 24/08/22-begin
  AttachmentRenderer.prototype.updateFileName = function(fileName) {
    let attachmentContainer = this.getAttachmentContainer();
    return this._renderer.getContentNode(attachmentContainer).then(
        (contentNode) => {
        let fileNode = contentNode.querySelector('.file-name');
        if (!fileNode || !fileName) {
          dump('updateFileName should be called after a render');
          return;
        }
        fileNode.textContent = fileName;
        fileNode.style.display = 'block';
        }
    );
  };
  //TaskGF5GTMO-3580-porting from Defect10730943-tingting.chao on 24/08/22-end

  AttachmentRenderer.prototype.getThumbnail = function() {
    const blob = this._attachment.blob;

    return ImageUtils.getSizeAndType(blob).then((data) => {
      const fragment = ImageUtils.Downsample.sizeNoMoreThan(
        THUMBNAIL_SIZE / Math.min(data.width, data.height)
      );

      return {
        url: window.URL.createObjectURL(blob),
        fragment: fragment
      };
    });
  };

  AttachmentRenderer.prototype._createAttachmentContainer = function() {
    const attachmentContainer = this._renderer.createAttachmentContainer();
    attachmentContainer.classList.add('attachment-container');
    attachmentContainer.classList.add('link-focus');
    if (this._attachment.isDraft) {
      attachmentContainer.classList.add('navigable');
    }
    attachmentContainer.dataset.attachmentType = this._attachment.type;

    return attachmentContainer;
  };

  AttachmentRenderer.prototype._getBaseMarkup = function(templateId, hasError) {
    const isVcard = this._attachment.type === 'vcard';
    const unNamed = Utils.translateString('unnamed-attachment');
    const sizeL10n = Utils.getSizeForL10n(this._attachment.size);
    let name = this._attachment.name.slice(this._attachment.name.lastIndexOf('/') + 1);
    return Template(templateId).interpolate({
      iconType: templateId === 'attachment-nopreview-tmpl' ? this.getIconType() : '',
      type: this._attachment.type,
      errorClass: hasError ? 'corrupted' : '',
      fileName: isVcard ? name === unNamed ? unNamed : name.slice(0, -4) : name,
      unDisplay: isVcard ? 'size-indicator-hide' : '',
      changeToCenterClass: isVcard ? 'file-name-site' : '',
      sizeL10nId: sizeL10n.l10nId,
      sizeL10nArgs: JSON.stringify(sizeL10n.l10nArgs)
    });
  };

  AttachmentRenderer.prototype.getIconType = function() {
    if (this._attachment.type === 'audio') {
      return 'file-audio';
    }
    if (this._attachment.type === 'vcard') {
      return 'contacts';
    }
    if (this._attachment.type === 'video') {
      return 'file-video';
    }
  };

  exports.AttachmentRenderer = {
    for: function(attachment) {
      return new AttachmentRenderer(attachment);
    }
  };
}(this));
