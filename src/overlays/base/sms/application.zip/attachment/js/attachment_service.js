/* eslint-disable no-unused-vars */
/* global Utils */
'use strict';

const attachmentMap = new WeakMap();

const AttachmentService = {
  // Open Attachment.
  mmsAttachmentClick: function(target) {
    const liElement = Utils.getParents(target, 'LI');
    const attachment = this.attachmentMapGet(target);
    let isMT = true;
    if (liElement.classList.contains('outgoing')) {
      isMT = false;
    }
    if (!attachment) {
      return false;
    }

    attachment.view({
      allowSave: isMT,
      forEditing: false,
      inComing: isMT
    });

    return true;
  },

  // Attachment map.
  attachmentMapGet: function(target) {
    return attachmentMap.get(target);
  },

  attachmentMapSet: function(mediaElement, attachment) {
    attachmentMap.set(mediaElement, attachment);
  }
};
