/* eslint-disable optimize-regex/optimize-regex */
/* global Utils, WBMP */

(function() {
  'use strict';

  function SMIL_generateSlides(data, slide, slideIndex) {
    const DURATION = 5000;
    const unsafeFilenamePattern = /[^a-zA-Z0-9_#.()?&%-]/g;

    let id;
    let blobType;
    const encoder = new TextEncoder('UTF-8');
    let media = '';
    let text = '';
    let name = '';
    if (slide.blob) {
      blobType = Utils.typeFromMimeType(slide.blob.type);
      if (blobType) {
        const tagName = tagNameFromBlobType(blobType);
        let region = 'region="Image"';
        if (tagName === 'ref') {
          region = '';
        }
        name = slide.name.substr(slide.name.lastIndexOf('/') + 1);
        name = name.replace(unsafeFilenamePattern, '#');
        name = SMIL_generateUniqueLocation(data, name);
        media = '<' + tagName + ' src="' + name + '" ' + region + '/>';
        data.attachments.push({
          id: '<' + name + '>',
          location: name,
          content: slide.blob
        });
      }
    }
    if (slide.text) {
      id = 'text_' + slideIndex + '.txt';
      text = '<text src="' + id + '" region="Text"/>';

      data.attachments.push({
        id: '<' + id + '>',
        location: id,
        content: new Blob([encoder.encode(slide.text)], { type: 'text/plain' })
      });
    }
    data.parts.push('<par dur="' + DURATION + 'ms">' + media + text + '</par>');
    return data;
  }

  function tagNameFromBlobType(blobType) {
    let out;

    switch(blobType) {
      case 'vcard':
        out = 'ref';
        break;
      default:
        out = blobType;
    }

    return out;
  }

  function SMIL_generateUniqueLocation(data, location) {
    let extension, name, result;
    const FILENAME_LIMIT = 40;
    const index = location.lastIndexOf('.');

    function SMIL_uniqueLocationMatches(attachment) {
      return attachment.location === result;
    }

    if (index === -1) {
      name = location;
      extension = '';
    } else {
      extension = location.slice(index);
      name = location.slice(0, index);
    }

    if (name.length + extension.length > FILENAME_LIMIT) {
      name = name.slice(0, FILENAME_LIMIT - extension.length);
    }
    result = name + extension;

    let duplicateIndex = 2;
    while (data.attachments.some(SMIL_uniqueLocationMatches)) {
      let truncIndex = 0;
      result = name + '_' + duplicateIndex++ + extension;
      while (result.length > FILENAME_LIMIT) {
        duplicateIndex = 2;
        name = name.slice(0, --truncIndex);
        result = name + extension;
      }
    }
    return result;
  }

  window.SMIL = {
    parse: function(message, callback) {
      const smil = message.smil;
      const attachments = message.attachments;
      let slides = [];
      let activeReaders = 0;
      let attachmentsNotFound = false;
      let smilMismatched = false;
      let doc;
      let parTags;

      function readTextBlob(blob, callback) {
        if (!blob) {
          return callback('');
        }

        const textReader = new FileReader();
        textReader.onload = (event) => {
          activeReaders--;
          callback(event, event.target.result);
        };
        textReader.onerror = (event) => {
          console.error('Error reading text blob');
          activeReaders--;
          callback(event, '');
        };
        activeReaders++;

        // The text blob must be encoded as 'utf-8' by Gecko.
        textReader.readAsText(blob, 'UTF-8');
      }

      function exitPoint() {
        if (!activeReaders) {
          setTimeout(callback.bind(null, slides));
        }
      }

      function findAttachment(name) {
        let index = 0;
        let length = attachments.length;

        name = name.replace(/^cid:/, '');

        for (; index < length; index++) {
          if (attachments[index].location === name ||
              attachments[index].id === '<' + name + '>') {
            return attachments[index];
          }
        }
        return null;
      }

      function convertWbmpToPng(slide) {
        let reader;
        slide.name = slide.name.slice(0, -5) + '.png';
        reader = new FileReader();
        reader.onload = function(event) {
          WBMP.decode(event.target.result, function callback(blob) {
            activeReaders--;
            slide.blob = blob;
            exitPoint();
          });
        };
        reader.onerror = function() {
          activeReaders--;
          console.error('Error reading text blob');
          exitPoint();
        };
        activeReaders++;
        reader.readAsArrayBuffer(slide.blob);
      }

      function SMIL_parseWithoutSMIL(attachment, idx) {
        const blob = attachment.content;
        if (!blob) {
          return;
        }
        const type = Utils.typeFromMimeType(blob.type);

        if (type === 'text' && blob.type === 'text/plain') {
          readTextBlob(blob, function SMIL_parseAttachmentRead(event, text) {
            slides[idx] = { text: text };
            exitPoint();
          });
        } else if (type) {
          const slide = { name: attachment.location, blob: attachment.content };
          if (slide.name && slide.name.slice(-5) === '.wbmp') {
            convertWbmpToPng(slide);
          }
          slides[idx] = slide;
        }
      }

      function SMIL_parseHandleParTag(par) {
        if (attachmentsNotFound) {
          return;
        }

        const mediaElements = par.querySelectorAll('img, video, audio, ref');
        const textElement = par.querySelector('text');
        let attachment, src;

        Array.prototype.forEach.call(mediaElements, (element) => {
          let slide = {};
          src = element.getAttribute('src');
          attachment = findAttachment(src);
          if (attachment) {
            // every media attachment starts its own slide in our format
            slide = { name: attachment.location, blob: attachment.content };
            dump("SMIL_parseHandleParTag" + " attachment --> slide --> blob :: " + slide.blob);
            slides.push(slide);
            if (slide.name && slide.name.slice(-5) === '.wbmp') {
              convertWbmpToPng(slide);
            }
          } else {
            attachmentsNotFound = true;
          }
        });

        if (textElement) {
          src = textElement.getAttribute('src');
          attachment = findAttachment(src);

          if (attachment) {
            // TaskGF5GTMO-3533-Porting from Task10629757-tingting.chao on 2024/08/20-begin
            if (src.indexOf(".vcf") !== -1) {
              dump("SMIL_parseHandleParTag contain vcf");
              // every media attachment starts its own slide in our format
              let slide = { name: attachment.location, blob: attachment.content };
              dump("SMIL_parseHandleParTag" + " attachment --> slide --> blob : " + slide.blob);
              slides.push(slide);
              if (slide.name && slide.name.slice(-5) === '.wbmp') {
                convertWbmpToPng(slide);
              }
              // TaskGF5GTMO-3533-Porting from Task10629757-tingting.chao on 2024/08/20-end
            } else {
              let slide = slides[slides.length - 1];

              if (!slide || typeof slide.text !== 'undefined') {
                slide = {};
                slides.push(slide);
              }
              slide.text = '';

              readTextBlob(attachment.content, (event, text) => {
                slide.text = text;
                exitPoint();
              });
            }
          } else {
            attachmentsNotFound = true;
          }
        }
      }

      if (smil) {
        doc = (new DOMParser()).parseFromString(smil, 'application/xml');
        parTags = doc.documentElement.getElementsByTagName('par');

        const elements = Array.prototype.reduce.call(parTags, 
          (count, par) => count + par.childElementCount, 0);

        if (elements !== attachments.length) {
          smilMismatched = true;
        } else {
          Array.prototype.forEach.call(parTags, SMIL_parseHandleParTag);
        }
      }

      if (!smil || attachmentsNotFound || !slides.length || smilMismatched) {
        slides = Array(attachments.length);
        attachments.forEach(SMIL_parseWithoutSMIL);
      }
      exitPoint();
    },

    generate: function(slides) {
      const HEADER = '<head><layout>' +
                     '<root-layout width="320px" height="480px"/>' +
                     '<region id="Image" left="0px" top="0px"' +
                     ' width="320px" height="320px" fit="meet"/>' +
                     '<region id="Text" left="0px" top="320px"' +
                     ' width="320px" height="160px" fit="meet"/>' +
                     '</layout></head>';

      const data = slides.reduce(SMIL_generateSlides, {
        attachments: [],
        parts: []
      });

      data.smil = '<smil>' + HEADER + '<body>' +
                  data.parts.join('') +
                  '</body></smil>';
      delete data.parts;

      return data;
    }
  };
})();
