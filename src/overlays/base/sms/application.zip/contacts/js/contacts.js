/* eslint-disable optimize-regex/optimize-regex */
/* global Utils, Settings, ContactsManager, ValueDefault */

(function(exports) {
  'use strict';
  // Compare function map.
  const filterFns = {
    contains: function(a, b) {
      a = a.toLowerCase();
      b = b.toLowerCase();
      return a.contains(b);
    },
    equality: function(a, b) {
      a = a.toLowerCase();
      b = b.toLowerCase();
      return a === b;
    }
  };

  function isMatch(contact, criteria, filterFn) {
    const found = {};

    outer:
    for (let i = 0, ilen = criteria.terms.length; i < ilen; i++) {
      const term = criteria.terms[i];
      for (let j = 0, jlen = criteria.fields.length; j < jlen; j++) {
        const field = criteria.fields[j];

        if (!contact[field]) {
          continue;
        }

        for (let k = 0, klen = contact[field].length; k < klen; k++) {
          let value = contact[field][k];
          if (typeof value.value !== 'undefined') {
            value = value.value;
          }

          if ((found[term] = filterFn(value.trim(), term))) {
            continue outer;
          }
        }
      }
    }

    return Object.keys(found).every(function(key) {
      return found[key];
    });
  }

  exports.Contacts = {
    findBy: function(filter, callback) {
      const lower = [];
      const filterValue = (filter.filterValue || '').trim();
      let contactArray = [];
      let limitShown;
      let terms;

      if (!filterValue.length) {
        setTimeout(() => {
          callback(
            typeof filter.filterValue === 'undefined' ? null : [], {}
          );
        });
        return;
      }

      const rspaces = /\s+/;
      terms = filterValue.split(rspaces);
      filter.filterValue = terms.length === 1 ?
        terms[0] : terms.reduce((initial, term) => {
          lower.push(term.toLowerCase());
          return term.length > initial.length ? term : initial;
        }, '');
      // Only show 10 contact if input length is less than 3.
      limitShown = filter.filterValue.length < 3;

      lower.splice(lower.indexOf(filter.filterValue.toLowerCase()), 1);
      lower.push.apply(lower, terms);

      // Return one data once is enough.
      ContactsManager.find(filter, 10).then((cursor) => {
        const mapCursor = cursor;

        let circleMap = () => {
          mapCursor.next().then((contacts) => {
            contacts.forEach((contact) => {
              contactArray.push(contact);
            });
            if (limitShown) {
              mapCursor.release();
              this.handleContact(contactArray, lower, terms, callback);
            } else {
              circleMap();
            }
          }).catch(() => {
            mapCursor.release();
            this.handleContact(contactArray, lower, terms, callback);
          });
        };

        circleMap();
      }, () => {
        callback(null);
      });
    },

    handleContact: function(contactArray, lower, terms, callback) {
      const fields = ['tel', 'givenName', 'familyName', 'name'];
      if (Settings.supportEmailRecipient) {
        fields.push('email');
      }
      const criteria = { fields: fields, terms: lower };
      let results = [];
      let eachContact;

      if (terms.length > 1) {
        while ((eachContact = contactArray.pop())) {
          if (isMatch(eachContact, criteria, filterFns.contains)) {
            results.push(eachContact);
          }
        }
      } else {
        results = contactArray;
      }

      callback(results, {
        terms: terms
      });
    },

    findByString: function(filterValue, callback) {
      this.findContactByString(filterValue, callback);
    },

    findContactByString: function(filterValue, callback) {
      const props = [ValueDefault.FilterByOption.NAME, 
                     ValueDefault.FilterByOption.GIVEN_NAME, 
                     ValueDefault.FilterByOption.FAMILY_NAME];
      // For special code, need search tel field if not only contains them.
      // eslint-disable-next-line no-useless-escape
      let pureNumber = filterValue.replace(/[#,;\+\*]/gi, '');
      if (!isNaN(pureNumber) && pureNumber.length > 0) {
        props.push(ValueDefault.FilterByOption.TEL);
      }
      if (Settings.supportEmailRecipient) {
        props.push(ValueDefault.FilterByOption.EMAIL);
      }
      return this.findBy({
        filterBy: props,
        filterOption: ValueDefault.FilterOption.STARTS_WITH,
        filterValue: filterValue
      }, callback);
    },

    findExact: function(filterValue, callback) {
      return this.findBy({
        filterBy: [ValueDefault.FilterByOption.NAME],
        filterOption: ValueDefault.FilterOption.EQUALS,
        filterValue: filterValue
      }, (results) => {
        const contact = results && results.length ? results[0] : null;
        callback([contact]);
      });
    },

    findByPhoneNumber: function(filterValue, callback) {
      return this.findBy({
        filterBy: [ValueDefault.FilterByOption.TEL],
        filterOption: ValueDefault.FilterOption.MATCH,
        filterValue: filterValue.replace(/\s+/g, '')
      }, (results) => {
        if (results && results.length) {
          callback(results);
        } else {
          callback([]);
        }
      });
    },

    findByAddress: function(fValue, callback) {
      if (Settings.supportEmailRecipient && Utils.isEmailAddress(fValue)) {
        this.findExactByEmail(fValue, callback);
      } else {
        this.findByPhoneNumber(fValue, callback);
      }
    },

    findExactByEmail: function(fValue, callback) {
      // Email not distinguish the lower case and upper case.
      fValue = fValue.toLocaleLowerCase();
      return this.findBy({
        filterBy: [ValueDefault.FilterByOption.EMAIL],
        filterOption: ValueDefault.FilterOption.EQUALS,
        filterValue: fValue
      }, callback);
    }
  };
}(this));
