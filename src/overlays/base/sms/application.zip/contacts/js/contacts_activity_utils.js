/* global Recipients, Settings, ContactsServiceManager, RecipientManager, 
          Utils, ValueDefault */

'use strict';

// eslint-disable-next-line no-unused-vars
const ContactsUtils = {
  requestContact: function() {
    Recipients.View.isFocusable = false;

    const contactProperties = ['tel'];
    if (Settings.supportEmailRecipient) {
      contactProperties.push('email');
    }

    // Record activity draft when page switch.
    Utils.saveActivityDraft();

    Utils.handleActivity('pick', {
      type: 'webcontacts/select',
      contactProperties: contactProperties
    }, (result) => {
      Utils.discardActivityDraft();

      if (!result || !result.selectedValues ||
          !result.selectedValues.length || 
          !result.selectedValues[0].value) {
        return;
      }

      Recipients.View.isFocusable = true;

      const data = ContactsServiceManager.basicContact(
        result.selectedValues[0].value, result.contact
      );
      data.source = 'contacts';

      if (RecipientManager.recipients.numbers.indexOf(
        result.selectedValues[0].value) !== -1) {
        Utils.showToaster({ messageL10nId: 'recipient-repeat' });
        return;
      }
      RecipientManager.recipients.add(data);
    }, () => {
      Utils.discardActivityDraft();
      setTimeout(() => {
        Recipients.View.isFocusable = true;
        RecipientManager.recipients.focus();
      }, ValueDefault.COMMONTIMEOUT);
    });
  }
};
