/* global Drafts, Threads, Utils, ThreadListUI, SuggestionManager, Contacts, 
          Settings, RecipientManager, Navigation, SoftkeyManager, OptionManager,
          ThreadUI, FocusManager, ContactsManager, ValueDefault */

'use strict';

// eslint-disable-next-line no-unused-vars
const ContactsServiceManager = {
  threadRecipientsMap: [],
  contactCount: 0,
  contactThreadArray: [],
  // Record first contact render info 
  contactRenderComplete: false,

  AddContactChangeListener: function() {
    ContactsManager.addEventListener(
      ContactsManager.EventMap.CONTACT_CHANGE, 
      this.updateContactsInfo.bind(this)
    );
  },

  setContact: function(node) {
    const threadOrDraft = 
      node.classList.contains('is-draft') ? Drafts.get(node.dataset.threadId) :
                                            Threads.get(node.dataset.threadId);
  
    if (!threadOrDraft) {
      return;
    }
  
    const threadNumbers = threadOrDraft.participants ||
                          threadOrDraft.recipients;
    const titleContainer = node.querySelector('.threadlist-item-title');
    const title = titleContainer.firstElementChild;
  
    if (!threadNumbers || !threadNumbers.length) {
      title.setAttribute('data-l10n-id', 'no-recipient');
      return;
    }

    if (ThreadListUI.threadCount <= 3) {
      this.contactThreadArray.push(node.dataset.threadId);
    }
  
    function* updateThreadNode(number) {
      const contact = yield this.findContact(number);
      node.setAttribute('data-number', number);
      node.setAttribute('data-contact', contact.isContact);
      title.textContent = contact.title || number;
      SoftkeyManager.updateSKs();
      // Set independent event to confirm the list appended after contact read.
      const newEvent = 'contact-update-' + node.dataset.threadId;
      window.dispatchEvent(new CustomEvent(newEvent));
      // Replace cache if contact find is 3.
      if (this.contactThreadArray.indexOf(node.dataset.threadId) !== -1) {
        this.contactCount++;
        if (((this.contactCount < 3) && 
             (this.contactCount === ThreadListUI.threadCount)) || 
            (this.contactCount === 3)) {
          this.contactRenderComplete = true;
          window.dispatchEvent(new CustomEvent('first-contact-list-render'));
        }
      }
    }
  
    function* updateGroupThreadNode(numbers, titleMaxLength) {
      let contactTitle, number;
      let i = 0;
      let threadTitleLength = 0;
  
      const groupTitle = document.createElement('span');
      const separatorNode = document.createElement('span');
      separatorNode.setAttribute('data-l10n-id', 'thread-participant-separator');
      const extraNode = document.createElement('span');
      let contactArray = [];
      let numberArray = [];
  
      while (i < numbers.length) {
        number = numbers[i++];
        const contact = yield this.findContact(number);
  
        numberArray.push(number);
        contactArray.push(contact.isContact);
        contactTitle = contact.title || number;
  
        if (threadTitleLength > 0) {
          groupTitle.appendChild(separatorNode.cloneNode(true));
        }
        groupTitle.appendChild(this.createBdiNode(contactTitle));
  
        threadTitleLength += contactTitle.length;
      }
  
      numberArray = numberArray.join(',');
      contactArray = contactArray.join(',');
      node.setAttribute('data-number', numberArray);
      node.setAttribute('data-contact', contactArray);
      SoftkeyManager.updateSKs();
  
      const existExtra =
        titleContainer.parentNode.querySelector('.thread-header-title');
      if (threadTitleLength > titleMaxLength) {
        titleContainer.classList.remove('width-adjust');
        titleContainer.classList.add('width-has-count');
        if (existExtra) {
          existExtra.textContent = '(' + (numbers.length) + ')';
        } else {
          extraNode.textContent = '(' + (numbers.length) + ')';
          extraNode.classList.add('thread-header-title');
          titleContainer.parentNode.appendChild(extraNode);
        }
      } else {
        if (existExtra) {
          titleContainer.parentNode.removeChild(existExtra);
          titleContainer.classList.add('width-adjust');
          titleContainer.classList.remove('width-has-count');
        }
      }
  
      titleContainer.replaceChild(groupTitle, title);

      // Set independent event to confirm the list appended after contact read.
      const newEvent = 'contact-update-' + node.dataset.threadId;
      window.dispatchEvent(new CustomEvent(newEvent));
      // Replace cache if contact find is 3.
      if (this.contactThreadArray.indexOf(node.dataset.threadId) !== -1) {
        this.contactCount++;
        if (((this.contactCount < 3) && 
             (this.contactCount === ThreadListUI.threadCount)) || 
            (this.contactCount === 3)) {
          this.contactRenderComplete = true;
          window.dispatchEvent(new CustomEvent('first-contact-list-render'));
        }
      }
    }
  
    if (threadNumbers.length === 1) {
      return Utils.Promise.async(updateThreadNode.bind(this))(threadNumbers[0]);
    }
  
    if (ThreadListUI.privateMembersGet <= 0) {
      ThreadListUI.privateMembersSet();
    }
  
    return Utils.Promise.async(updateGroupThreadNode.bind(this))(
      threadNumbers, ThreadListUI.privateMembersGet()
    );
  },

  searchContact: function(fValue, handler) {
    if (!fValue) {
      SuggestionManager.toggleRecipientSuggestions();
      return;
    }

    Contacts.findByString(fValue, handler.bind(null, fValue));
  },

  exactContact: function(fValue, handler) {
    Contacts.findExact(fValue, handler.bind(null, fValue));
  },

  findContact: function(number, options) {
    const defer = Utils.Promise.defer();

    Contacts.findByAddress(number, (contacts) => {
      const details = this.getContactDetails(number, contacts, options);
      defer.resolve(details);
    });

    return defer.promise;
  },

  findBlockNumbers: function(number) {
    let filterType = ValueDefault.FilterOption.FUZZY_MATCH;
    if (Utils.isEmailAddress(number)) {
      filterType = ValueDefault.FilterOption.EQUALS;
    }

    return new Promise((resolve) => {
      ContactsManager.findBlockedNumbers({
        filterOption: filterType,
        filterValue: number
      }).then((result) => {
        resolve(result);
      });
    });
  },

  blockNumbers: function(number, callback) {
    ContactsManager.addBlockedNumber(number).then(() => {
      callback(true);
    }, () => {
      callback(false);
    });
  },

  unblockNumbers: function(number, callback) {
    ContactsManager.removeBlockedNumber(number).then(() => {
      callback(true);
    }, () => {
      callback(false);
    });
  },

  getContactDetails: function(number, contacts) {
    const details = {};
    details.isContact = false;

    function updateDetails(contact) {
      let name, org;
      if (!contact.name) {
        contact.name = '';
      }
      name = contact.name;
      org = contact.org || '';

      // Add data values for contact activity interaction.
      details.isContact = true;

      details.name = name;
      // We pick the first discovered org name as the phone number's detail
      // org information.
      details.org = details.org || org;
    }

    // In no contact or contact with empty information cases, we will leave
    // the title as the empty string and let caller to decide the title.
    if (!contacts || (Array.isArray(contacts) && contacts.length === 0)) {
      details.title = '';
    } else if (!Array.isArray(contacts)) {
      updateDetails(contacts);
      details.title = details.name || details.org;
    } else {
      for (let i = 0, l = contacts.length; i < l; i++) {
        updateDetails(contacts[i]);
        if (details.name) {
          break;
        }
      }
      details.title = details.name || details.org;
    }

    return details;
  },

  getContactDisplayInfo: function(resolver, phoneNumber, callback) {
    resolver(phoneNumber, (contacts) => {
      callback(this.basicContact(phoneNumber, contacts));
    });
  },

  basicContact: function(number, records, callback) {
    let record;
    if (Array.isArray(records)) {
      if (records.length > 0) {
        record = records[0];
      }
    } else if (records !== null) {
      record = records;
    }

    // Only exit when no record and no phone number case.
    if (!record && !number) {
      if (typeof callback === 'function') {
        callback(null);
      }
      return;
    }

    const telLength = (record && record.tel) ? record.tel.length : 0;
    let tel;
    // Look for the right tel. A record can contains more than
    // one record, so we need to identify which one is the right one.
    for (let i = 0; i < telLength; i++) {
      if (record.tel[i].value === number) {
        tel = record.tel[i];
        break;
      }
    }
    // If after looking there is no tel. matching, we apply
    // directly the number.
    if (!tel) {
      tel = { type: [''], value: number, carrier: '' };
    }
    // Get the title in the standard way.
    const details = this.getContactDetails(tel, record);

    return this.getDisplayObject(details.title || null, tel);
  },

  getDisplayObject: function(theTitle, tel) {
    const number = tel.value;
    const type = tel.atype ? tel.atype : '';
    const data = {
      name: theTitle || number,
      number: number,
      type: type,
      carrier: tel.carrier || ''
    };

    if (Settings.supportEmailRecipient) {
      data.email = number;
      data.emailHTML = '';
    }
    return data;
  },

  getThreadContactArray: function(numbers) {
    this.threadRecipientsMap = [];
    numbers.forEach((number) => {
      Contacts.findByAddress(number, (contacts) => {
        if (contacts.length === 0 || !contacts[0].name) {
          this.threadRecipientsMap.push([number, '']);
        } else {
          this.threadRecipientsMap.push([number, contacts[0].name]);
        }
      });
    });
  },

  pickContactFromNumbers: function(sender) {
    for (let i = 0; i < this.threadRecipientsMap.length; i++) {
      if (this.threadRecipientsMap[i][0] === sender &&
          this.threadRecipientsMap[i][1] !== '') {
        return this.threadRecipientsMap[i][1];
      }
    }

    return sender;
  },

  findContactByTarget: function(target) {
    const deferred = Utils.Promise.defer();

    function findAddressCallBack(results) {
      let record, name, contact;

      if (results && results.length) {
        record = results[0];
        if (record.name === null || record.name === undefined) {
          record.name = [];
        }
        name = record.name.length && record.name[0];
        contact = {
          number: target,
          name: name,
          source: 'contacts'
        };

        deferred.resolve(contact);
      } else {
        deferred.reject();
      }
    }

    Contacts.findByAddress(target, findAddressCallBack);

    return deferred.promise;
  },

  validateContact: function(source, fValue, contacts) {
    const last = RecipientManager.recipientsList.lastElementChild;
    const typed = last && last.textContent.trim();
    let isInvalid = true;
    let index = RecipientManager.recipients.length - 1;
    let isContact = false;
    let record, length, number, contact;

    if (index < 0) {
      index = 0;
    }

    const props = ['tel'];
    if (Settings.supportEmailRecipient) {
      props.push('email');
    }

    if (contacts && contacts.length) {
      isInvalid = false;
      record = contacts[0];
      const values = props.reduce((values, prop) => {
        const propValue = record[prop];
        if (propValue && propValue.length) {
          return values.concat(propValue);
        }

        return values;
      }, []);
      length = values.length;

      if (source.isLookupable && !source.isQuestionable && length === 1) {
        if (Utils.probablyMatches(values[0].value, fValue)) {
          isContact = true;
          number = values[0].value;
        }
      } else {
        for (let i = 0; i < length; i++) {
          const propValue = values[i].value;
          if (RecipientManager.recipients.numbers.indexOf(propValue) === -1) {
            number = propValue;
            break;
          }
        }

        if (typeof number !== 'undefined') {
          isContact = true;
        } else {
          isInvalid = true;
        }
      }
    }

    if (isContact) {
      RecipientManager.recipients.remove(index);
      contact = this.basicContact(number, record);
      contact.source = 'contacts';
      RecipientManager.recipients.add(contact).focus();
      return;
    }

    if (isInvalid && contacts.length > 1) {
      this.validateContact(source, fValue, contacts.slice(1));
      return;
    }

    if (!source.isQuestionable && !length) {
      isInvalid = false;
    }

    source.isInvalid = isInvalid;

    if (!typed) {
      RecipientManager.recipients.update(index, source).focus();
    }
  },

  updateContactsInfo: function() {
    if (ThreadListUI.container) {
      const threads = ThreadListUI.container.getElementsByTagName('li');
      [].forEach.call(threads, this.setContact.bind(this));
    }

    if (Navigation.isCurrentPanel('thread-list')) {
      SoftkeyManager.updateSKs();
    } else if (Navigation.isCurrentPanel('thread')) {
      ThreadUI.updateHeaderData();
    }
  },

  handleContactFromList: function(callback) {
    const contactArray = this.judgeContactCount();
    if (contactArray.length === 1) {
      const formatNumber = this.pickNumber(contactArray[0]);
      callback(formatNumber);
    } else {
      OptionManager.selectNumber(contactArray, (recipient) => {
        const formatNumber = this.pickNumber(recipient);
        callback(formatNumber);
      });
    }
  },

  judgeContactCount: function() {
    const resultInfo = [];

    if (!FocusManager.currentThread) {
      return resultInfo;
    }

    let numberInfo = FocusManager.currentThread.getAttribute('data-number');
    numberInfo = numberInfo ? numberInfo.split(',') : [];
    let contactInfo = FocusManager.currentThread.getAttribute('data-contact');
    contactInfo = contactInfo ? contactInfo.split(',') : [];

    for (let i = 0; i < contactInfo.length; i++) {
      if (contactInfo[i] === 'false' && numberInfo[i] !== 'anonymous') {
        resultInfo.push(numberInfo[i]);
      }
    }

    return resultInfo;
  },

  pickNumber: function(recipient) {
    let opt;
    if (Utils.isEmailAddress(recipient)) {
      opt = { email: recipient };
    } else {
      opt = { tel: recipient };
    }

    return opt;
  },

  createBdiNode: function(content) {
    const bdi = document.createElement('bdi');
    bdi.textContent = content;
    return bdi;
  }
};
