/* global Recipients, Settings, ContactsServiceManager, RecipientManager, 
          Utils, ValueDefault, Contacts */

'use strict';

// eslint-disable-next-line no-unused-vars
const ContactsUtils = {
  requestContact: function() {
    Recipients.View.isFocusable = false;
    
    const contactProperties = ['tel'];
    if (Settings.supportEmailRecipient) {
      contactProperties.push('email');
    }

    Utils.handleActivity('pick', {
      type: 'webcontacts/select',
      contactProperties: contactProperties
    }, (result) => {
      if (!result || !result.selectedValues ||
          !result.selectedValues.length ||
          !result.selectedValues[0].value) {
        return;
      }

      Recipients.View.isFocusable = true;

      const data = ContactsServiceManager.basicContact(
        result.selectedValues[0].value, result.contact
      );
      data.source = 'contacts';

      if (RecipientManager.recipients.numbers.indexOf(
        result.selectedValues[0].value) !== -1) {
        Utils.showToaster({ messageL10nId: 'recipient-repeat' });
        return;
      }
      RecipientManager.recipients.add(data);
    }, () => {
      setTimeout(() => {
        RecipientManager.setRecipientFocus();
      }, ValueDefault.COMMONTIMEOUT);
    });
  },

  pickContactsDetail: function() {
    return new Promise((resolve) => {
      const contactList =
        document.getElementById('information-report').querySelector('.contact-list');
      const suggestionList = contactList.querySelectorAll('.suggestion');
      const contact = [];
      const blockContact = [];
      const asyncTask = [];
      for (let i = 0; i < suggestionList.length; i++) {
        const nodeContact = suggestionList[i].getAttribute('data-number');
        const newTask = () => new Promise((resolver) => {
          Contacts.findByAddress(nodeContact, (result) => {
            let detail;
            if (result && result.length !== 0) {
              let addresses = [];

              if (result[0].tel && result[0].tel.length) {
                addresses = addresses.concat(result[0].tel);
              }

              if (Settings.supportEmailRecipient &&
                  result[0].email && result[0].email.length) {
                addresses = addresses.concat(result[0].email);
              }

              const detailList = ContactsServiceManager.getContactDetails(nodeContact, result, null);
              let dataList = null;

              addresses.forEach((current) => {
                if (Utils.probablyMatches(current.value, nodeContact)) {
                  dataList = ContactsServiceManager.getDisplayObject(detailList.title, current);
                }
              });

              // Uppercase the first letter.
              let type = dataList.type;
              type = type.substring(0,1).toUpperCase() + type.substring(1);

              detail = {
                contact: dataList.name,
                type: type,
                number: nodeContact
              };

              // Only contact recipient can be blocked.
              contact.push(detail);
            } else {
              detail = {
                number: nodeContact
              };

              contact.push(detail);
            }

            ContactsServiceManager.findBlockNumbers(nodeContact).then((result) => {
              if (result.length !== 0) {
                blockContact.push(detail.number);
                suggestionList[i].classList.add('suggestion-adjust');
                suggestionList[i].parentNode.classList.add('block-tag');
              } else {
                suggestionList[i].classList.remove('suggestion-adjust');
                suggestionList[i].parentNode.classList.remove('block-tag');
              }

              resolver();
            });
          });
        });
        asyncTask.push(newTask());
      }

      Promise.all(asyncTask).then(() => {
        resolve([contact, blockContact]);
      });
    });
  }
};
