/* global Template, Settings, Utils, ContactsServiceManager, SharedComponents */

(function(exports) {

  'use strict';

  const FLAVORS = {
    suggestion: {
      renderAll: true,
      shouldHighlight: true,
      templates: {
        main: 'contact-suggestion-tmpl'
      }
    },
    prompt: {
      renderAll: false,
      shouldHighlight: false,
      templates: {
        main: 'contact-prompt-tmpl'
      }
    },
    'group-view': {
      renderAll: false,
      shouldHighlight: false,
      templates: {
        main: 'contact-suggestion-tmpl'
      }
    }
  };

  const templates = {};

  function getTemplate(id) {
    if (!templates[id]) {
      templates[id] = Template(id);
    }
    return templates[id];
  }

  const highlightTemplateId = 'contact-highlight-tmpl';

  function highlight(escapedData, regexpArray) {
    let matchFound;
    const template = getTemplate(highlightTemplateId);

    function loopReplaceFn(match) {
      matchFound = true;
      return template.interpolate({
        str: match
      }, {
        safe: ['str']
      });
    }

    const splitData = escapedData.split(/\s+/);

    for (let i = 0; i < splitData.length; i++) {
      matchFound = false;
      for (let k = 0; !matchFound && k < regexpArray.length; k++) {
        splitData[i] = splitData[i].replace(regexpArray[k], loopReplaceFn);
      }
    }
    return splitData.join(' ');
  }

  const ContactRenderer = exports.ContactRenderer = function constructor(opts) {
    if (!opts) {
      throw new Error('ContactRenderer constructor needs an options object');
    }

    this.opts = opts;
    this.templates = {};
    for (const key in opts.templates) {
      const id = opts.templates[key];
      this.templates[key] = Template(id);
    }
  };

  ContactRenderer.prototype = {
    render: function(renderOpts) {
      let contact = renderOpts.contact;
      const shouldHighlight = this.opts.shouldHighlight;
      const renderAll = this.opts.renderAll;
      const skip = renderOpts.skip || [];
      const block = renderOpts.infoBlock;
      const parentSelector = renderOpts.infoBlockParentSelector;
      const target = renderOpts.target;
      let input = renderOpts.input;
      input = input && input.trim();

      if (!contact) {
        return false;
      }

      if (!Array.isArray(contact)) {
        contact = [contact];
      }

      const hasTel = contact[0].tel && contact[0].tel.length;
      const hasEmail = contact[0].email && contact[0].email.length;
      if (!hasTel && !(Settings.supportEmailRecipient && hasEmail)) {
        return false;
      }

      const escaped = Utils.escapeRegex(Template.escape(input));
      const escsubs = escaped.split(/\s+/);
      const regexps = {
        name: escsubs.map((k) => {
          return new RegExp('^' + k, 'gi');
        }),
        number: escsubs.map((k) => {
          return new RegExp('^' + k, 'gi');
        }),
        email: escsubs.map((k) => {
          return new RegExp('^' + k, 'gi');
        })
      };

      let addresses = [];

      if (contact[0].tel && contact[0].tel.length && contact[0].tel[0].value) {
        addresses = addresses.concat(contact[0].tel);
      }
      if (Settings.supportEmailRecipient &&
          contact[0].email && contact[0].email.length && contact[0].email[0].value) {
        addresses = addresses.concat(contact[0].email);
      }
      const details = ContactsServiceManager.getContactDetails(
        addresses[0].value, contact
      );
      const tempDiv = document.createElement('div');

      addresses.forEach((current) => {
        if (!renderAll && !Utils.probablyMatches(current.value, input)) {
          return;
        }

        if (renderAll && skip.indexOf(current.value) > -1) {
          return;
        }

        const data = ContactsServiceManager.getDisplayObject(details.title, current);
        const props = ['name', 'number'];
        if (Settings.supportEmailRecipient) {
          props.push('email');
        }

        props.forEach((key) => {
          let escapedData = Template.escape(data[key]);
          if (shouldHighlight) {
            escapedData = highlight(escapedData, regexps[key]);
          }
          data[key + 'HTML'] = escapedData;
        });

        data.phoneDetailsHTML = SharedComponents.phoneDetails({
          number: data.numberHTML,
          type: data.type,
          carrier: data.carrier
        }, {
          safe: ['number']
        });

        tempDiv.innerHTML = this.templates.main.interpolate(data, {
          safe: ['nameHTML', 'phoneDetailsHTML', 'srcAttr']
        });

        const element = tempDiv.firstElementChild;
        const blockParent = element.querySelector(parentSelector);

        if (blockParent) {
          blockParent.appendChild(block);
        }

        if (renderAll && (current.value.indexOf(input) === -1 &&
            data.name.toLowerCase().indexOf(input.toLowerCase()) === -1)) {
          tempDiv.querySelector('.name').classList.add('grey-text');
          tempDiv.querySelector('.number').classList.add('grey-text');
        }

        if (!data.type) {
          tempDiv.querySelector('.phone-type').classList.add('hide');
          tempDiv.querySelector('.phone-type-separator').classList.add('hide');
        }

        target.appendChild(element);

        tempDiv.textContent = '';
      });

      return true;
    }
  };

  ContactRenderer.flavor = function(flavor) {
    return new ContactRenderer(FLAVORS[flavor]);
  };
})(window);
