/* global AttachmentManager, DraftUtils, FocusStateManager, MessageManager,
          SubjectUtils, Settings, RecipientManager, NavigationMap, Attachment,
          SMIL, ValueDefault, ThreadUI, Threads, Utils, Navigation, EventDispatcher
          OptionManager, DialogManager, NotificationBase */

'use strict';

const Compose = (function() {
  const UPDATE_DELAY = 500;
  const MAX_TEXT_LENGTH_FOR_TMO = 2000;//TaskGF5GTMO-3495-[TMO:GID-MTRREQ-484019]-tingting.chao-on 2024/08/17-add
  const MXA_MMS_CHARACTERS_COUNT_FOR_USCC = 1000;//GF5GTMO-3739 porting from TASK0985676 - [USCC:NW 5.27.7,NW 5.27.6]- tingting.chao on 2024/09/03-add
  const MIN_AVAILABLE_CHARS_COUNT = 20;
  // Beign add for GF5GTMO-8488 by tingting.chao on 2025/10/24
  let maxConcatenatedMsgs =10;
  const vzwMaxConcatenatedMsgs = 7;
  const usccMaxConcatenatedMsgs = 1;
  const attMaxConcatenatedMsgs = 5;
  // End add for GF5GTMO-8488 by tingting.chao on 2025/10/24
  const placeholderClass = 'placeholder';
  // Record DOM.
  const dom = {
    form: null,
    message: null,
    counter: null
  };
  // Record thread action state.
  const state = {
    empty: true,
    maxLength: null,
    size: null,
    lastScrollPosition: 0,
    resizing: false,
    locked: false,
    type: 'sms',
    needResize: false,
    segmentInfo: {
      segments: 0,
      charsAvailableInLastSegment: 0
    },
    lastInputValue: '',//TaskGF5GTMO-3495-[TMO:GID-MTRREQ-484019]-tingting.chao-on 2024/08/17-add
    isTextLong: false
  };

  // Get all contents from input box.
  function getContentFromDOM(domElement) {
    const content = [];
    let node;

    for (node = domElement.firstChild; node; node = node.nextSibling) {
      const attachment = AttachmentManager.getAttachmentMap();
      if (attachment) {
        content.push(attachment);
        continue;
      }

      const last = content.length - 1;
      let text = node.textContent;

      if (text) {
        text = text.replace(/\u00A0/g, ' ');
      }

      if (node.nodeName === 'BR') {
        if (node === domElement.lastChild) {
          continue;
        }
        text = '\n';
      }

      if (text.length) {
        if (typeof content[last] === 'string') {
          content[last] += text;
        } else {
          content.push(text);
        }
      }
    }

    return content;
  }

   // Beign add for GF5GTMO-8488 by tingting.chao on 2025/10/24
  function getSmsMaxConcatenatedMsg() {
    if(OperatorUtils.isVZWFamily()){
      maxConcatenatedMsgs = vzwMaxConcatenatedMsgs;
    } else if(OperatorUtils.isUSCCFamily()){
      maxConcatenatedMsgs = usccMaxConcatenatedMsgs;
    } else if(OperatorUtils.isATTFamily()){
      maxConcatenatedMsgs = attMaxConcatenatedMsgs;
    }
    return maxConcatenatedMsgs;
  }
  // End add for GF5GTMO-8488 by tingting.chao on 2025/10/24

  // Hanlder input event.
  function onContentChanged(duck) {
    if (DraftUtils.draft) {
      if (!(duck && duck.detail === 'back-key')) {
        DraftUtils.draft.isEdited = true;
      }
    }

    const isEmptyMessage = !dom.message.textContent.trim().length && !hasAttachment();
    let needRemovePlacehoder = false;

    if (isEmptyMessage) {
      const brs = dom.message.getElementsByTagName('br');
      // firefox will keep an extra <br> in there
      if (brs.length > 1 || dom.message.textContent.length > 0) {
        needRemovePlacehoder = true;
      }
    }

    // Placeholder management
    const placeholding = dom.message.classList.contains(placeholderClass);
    if (placeholding && (!isEmptyMessage || needRemovePlacehoder)) {
      dom.message.classList.remove(placeholderClass);
    }
    if (!placeholding && (isEmptyMessage && !needRemovePlacehoder)) {
      dom.message.classList.add(placeholderClass);
    }

    state.emptyMessage = isEmptyMessage;

    Compose.updateEmptyState();
    Compose.updateType();
    updateSegmentInfoThrottled();

    Compose.emit('input');

    // Need update the softkey when the string changed.
    if (duck && duck.detail === 'needUpdate') {
      FocusStateManager.dynamicSK();
    }
  }

  function onContentInput() {
    if (state.type === 'mms') {
      state.needResize = true;
    }
    //TaskGF5GTMO-3495-[TMO:GID-MTRREQ-484019]-tingting.chao-on 2024/08/17-begin
    if (OperatorUtils.isTMOFamily()) {
      let inputValue = Compose.getText();
      if (inputValue.length >= MAX_TEXT_LENGTH_FOR_TMO) {
        let recipients = Threads.active ? Threads.active.participants :
          (RecipientManager.recipients && RecipientManager.recipients.numbers);
        if (recipients && recipients.length == 1 && recipients[0] == 911
          && inputValue !== state.lastInputValue) {
          state.lastInputValue = inputValue;
          Utils.showToaster({ messageL10nId: 'message-limit-reached' });
        }
      }
    }
    //TaskGF5GTMO-3495-[TMO:GID-MTRREQ-484019]-tingting.chao-on 2024/08/17-end
    //Porting from PR 11213677-renlongou on 2024/09/04-begin
    if (OperatorUtils.isUSCCFamily()) {
      if(Compose.getText().length > MXA_MMS_CHARACTERS_COUNT_FOR_USCC){
        Utils.showToaster({ messageL10nId: 'message-characters-limit-reached' });
      }
    }
    //Porting from PR 11213677-renlongou on 2024/09/04-end
    onContentChanged({ detail: 'needUpdate' });
  }

  function composeKeyEvents(event) {
    // if locking and no-backspace pressed, cancel
    if (state.locked && event.which !== event.DOM_VK_BACK_SPACE) {
      event.preventDefault();
    } else {
      state.needResize = true;
      compose.unlock();
    }
  }

  // Composer field state change.
  function hasAttachment() {
    return !dom.attachmentComposer.classList.contains('hide');
  }

  // DOM operator function map.
  function insertAfter(newElement, targetElement) {
    const parent = targetElement.parentNode;
    if (parent.lastChild === targetElement) {
      parent.appendChild(newElement);
    } else {
      parent.insertBefore(newElement, targetElement.nextSibling);
    }
  }

  function insert(item) {
    const fragment = document.createDocumentFragment();
    if (!item) {
      return null;
    }

    state.needResize = true;

    if (typeof item === 'string') {
      item.split('\n').forEach((line) => {
        if (line.length) {
          fragment.appendChild(document.createTextNode(line));
        }
        fragment.appendChild(document.createElement('br'));
      });
      fragment.lastElementChild.remove();
    }

    return fragment;
  }

  // Hanlder multiple page message.
  let segmentInfoTimeout = null;
  function updateSegmentInfoThrottled() {
    if (hasAttachment()) {
      return resetSegmentInfo();
    }

    if (segmentInfoTimeout === null) {
      segmentInfoTimeout = setTimeout(updateSegmentInfo, UPDATE_DELAY);
    }
  }

  function updateSegmentInfo() {
    segmentInfoTimeout = null;
    const value = Compose.getText();
    const segmentInfoPromise = value ? MessageManager.getSegmentInfo(value) :
                                       Promise.reject();
    segmentInfoPromise.then((segmentInfo) => {
      state.segmentInfo = segmentInfo;
    }, resetSegmentInfo).then(
      compose.updateType.bind(Compose)).then(
      compose.emit.bind(compose, 'segmentinfochange'));
  }

  function resetSegmentInfo() {
    state.segmentInfo = {
      segments: 0,
      charsAvailableInLastSegment: 0
    };
  }

  const compose = {
    isFirstExceed: false,
    init: function composeInit(formId) {
      // Init base element.
      this.initElement(formId);

      // Only mms enable device has type tag.
      if (Settings.mmsEnable) {
        document.querySelector('.sms-label').setAttribute('data-l10n-id', 'sms-label');
      }

      // Subject init.
      SubjectUtils.init();

      // Composer field init.
      this.offAll();
      this.clear();

      // Listener for each composer changed.
      this.on('type', this._onTypeChangeHandler.bind(this));
      this.on('segmentinfochange', this.updateMessageCounter.bind(this));

      // Handler email address.
      if (!ValueDefault.isFromNotification && Settings.supportEmailRecipient) {
        RecipientManager.on('recipientschange', this.updateType.bind(this));
      }

      // Hander listern map.
      // update the placeholder, send button and Compose.type
      dom.message.addEventListener('input', onContentInput);
      dom.message.addEventListener('keydown', composeKeyEvents);
      dom.message.addEventListener('click', this._onInteracted.bind(this));
      dom.message.addEventListener('focus', this._onFocusHandler.bind(this));
      dom.composerButton.addEventListener('click', this._onInteracted.bind(this));
      dom.attachmentComposer.addEventListener('focus', this.attachmentFocus.bind(this));

      return this;
    },

    initElement: function(formId) {
      dom.form = document.getElementById(formId);
      dom.attachmentComposer = document.querySelector('.js-attachment-composer');
      dom.message = document.getElementById('messages-input');
      dom.counter = document.getElementById('letter-counter');
      dom.messagesAttach = dom.form.querySelector('.messages-attach-container');
      dom.composerButton = dom.form.querySelector('.composer-button-container');
      dom.messageTypeLine = document.querySelector('.message-type-line');
    },

    // DOM element content get.
    getContent: function(onlytext) {
      const allContent = getContentFromDOM(dom.message);
      // Only body.
      if (onlytext) {
        return allContent;
      }

      const attachmentContent = AttachmentManager.getAttachment();
      // Add the attachment field to content field.
      for (let i = 0; i < attachmentContent.length; i++) {
        allContent.push(attachmentContent[i]);
      }

      return allContent;
    },

    getText: function() {
      const out = this.getContent().filter((elem) => {
        return (typeof elem === 'string');
      });
      return out.join('');
    },

    isEmpty: function() {
      return state.empty;
    },

    isFocused: function() {
      return document.activeElement.id === dom.message.id;
    },

    // State set from other modules.
    setNeedResizeState: function(value) {
      state.needResize = value;
    },

    setResizingState: function(value) {
      state.resizing = value;
    },

    // DOM element content set.
    addEmptyFied: function(attachmentContainer) {
      const textNode = document.createTextNode('');
      insertAfter(textNode, attachmentContainer);
      attachmentContainer.textNode = textNode;
    },

    // DOM element action function map.
    append: function(item, options) {
      options = options || {};
      if (Array.isArray(item)) {
        item.forEach((content) => {
          this.append(content, { ignoreChange: true });
        });
        onContentChanged();
      } else {
        const fragment = insert(item);
        if (!fragment) {
          return this;
        }

        if (document.activeElement === dom.message) {
          // insert element at caret position
          const range = window.getSelection().getRangeAt(0);
          const firstNodes = fragment.firstChild;
          range.deleteContents();
          range.insertNode(fragment);
          this.scrollToTarget(range);
          Compose.focus();
          range.setStartAfter(firstNodes);
        } else {
          // insert element at the end of the Compose area
          dom.message.insertBefore(fragment, dom.message.lastChild);
          this.scrollToTarget(dom.message.lastChild);
        }
        if (!options.ignoreChange) {
          onContentChanged({ detail: 'needUpdate' });
        }
      }

      return this;
    },

    clear: function() {
      state.type = 'sms';
      this.onTypeChange();
      this.clearComposeContent();
      AttachmentManager.clearAttachment();
      SubjectUtils.clearSubjectFocusable();
      return this;
    },

    clearComposeContent: function() {
      dom.message.innerHTML = '<br>';
      state.resizing = false;
      state.size = 0;
      state.lastInputValue = '';//TaskGF5GTMO-3495-[TMO:GID-MTRREQ-484019]-tingting.chao-on 2024/08/17-add
      resetSegmentInfo();
      segmentInfoTimeout = null;
      onContentChanged();
    },

    // Dom location function map.
    scrollToTarget: function(target) {
      // target can be an element or a selection range
      const targetRect = target.getBoundingClientRect();
      // put the middle of the target at the middle of the container box
      const containerRect = dom.message.getBoundingClientRect();
      const offset = (targetRect.top + targetRect.height / 2) -
                     (containerRect.top + containerRect.height / 2);
      // we += because the scrollTop that was set is already compensated
      // with the getBoundingClientRect()
      dom.message.scrollTop += offset;
    },

    scrollMessageContent: function() {
      if (document.activeElement === dom.message) {
        // we just got the focus: ensure the caret is visible
        const range = window.getSelection().getRangeAt(0);
        if (range.collapsed) {
          // We can't get the bounding client rect of a collapsed range,
          // so let's insert a temporary node to get the caret position.
          range.insertNode(document.createElement('span'));
          this.scrollToTarget(range);
          range.deleteContents();
        } else {
          this.scrollToTarget(range);
        }
        state.lastScrollPosition = dom.message.scrollTop;
      } else {
        // we just lost the focus: restore the last scroll position
        dom.message.scrollTop = state.lastScrollPosition;
      }
    },

    // Draft create.
    fromDraft: function(draft) {
      // Clear out the composer.
      this.clear();
      // If don't have a draft, return only having cleared the composer.
      if (!draft) {
        return;
      }
      // Add the subject field if have.
      if (draft.subject) {
        SubjectUtils.setSubject(draft.subject);
        SubjectUtils.showSubject(true);
        this.updateType();
      }
      // Add the attachment field if have.
      if (draft.attachment) {
        for(let i = 0; i < draft.attachment.length; i++) {
          if (draft.attachment[i].blob) {
            draft.attachment[i] = new Attachment(draft.attachment[i].blob, {
              name: draft.attachment[i].name,
              isDraft: true
            });
          }
        }
        AttachmentManager.addAttachments(draft.attachment);
      }
      // Add draft to dom.
      draft.content.forEach((fragment) => {
        // Append each fragment in order to the composer
        this.append(fragment);
      });

      // Update softkey after draft added.
      FocusStateManager.dynamicSK();
    },

    // Not draft route content create.
    fromMessage: function(message) {
      this.clear();

      if (message.type === 'mms') {
        if (message.subject) {
          //TaskGF5GTMO-3531-porting from Task10627638-tingting.chao on 2024/08/19-begin
          let mmsSubject = message.subject;
          let isTmoFamily = OperatorUtils.isTMOFamily();
          // TaskGF5GTMO-4035-porting from PRGF7TF-4656-tingting.chao on 24/09/09-begin
          let isVzwFamily = OperatorUtils.isVZWFamily();
          if(isTmoFamily || isVzwFamily){
            let forwardName = window.api.l10n.get('forwardName');
            mmsSubject = forwardName + mmsSubject;
            const subjectMaxlen = SubjectUtils.getSubjectMaxLength();
            dump("FromMessage，getSubjectMaxLength = " + subjectMaxlen);
            let extra = mmsSubject.length - subjectMaxlen;
            if (extra > 0) {
              mmsSubject = mmsSubject.substring(0, subjectMaxlen);
            }
          // TaskGF5GTMO-4035-porting from PRGF7TF-4656-tingting.chao on 24/09/09-end
          }
          //SubjectUtils.setSubject(message.subject);
          SubjectUtils.setSubject(mmsSubject);
          //TaskGF5GTMO-3531-porting from Task10627638-tingting.chao on 2024/08/19-end
          SubjectUtils.showSubject();
        }
        SMIL.parse(message, (elements) => {
          const showAttachments = [];
          for (let i = 0; i < elements.length; i++) {
            if (elements[i].blob) {
              showAttachments.push(new Attachment(elements[i].blob, {
                name: elements[i].name,
                isDraft: true
              }));
            }
            if (elements[i].text) {
              this.append(elements[i].text);
            }
          }
          AttachmentManager.addAttachments(showAttachments);
          this.ignoreEvents = false;
        });
        this.ignoreEvents = true;
      } else {
        this.append(message.body);
      }
    },

    // Lock the DOM if size is exceed.
    lock: function() {
      state.locked = true;
    },

    // Unlock the DOM if size is not exceed.
    unlock: function() {
      state.locked = false;
    },

    // Element change handler function map.
    _onTypeChangeHandler: function() {
      this.onTypeChange();
      this.updateMessageCounter();
    },

    _onInteracted: function() {
      this.emit('interact');
    },

    onTypeChange: function() {
      dom.form.dataset.messageType = this.type;
    },

    // Input box inner focus change action.
    focus: function() {
      if (OptionManager.isOptionMenuShown() || DialogManager.isDialogShown()) {
        return;
      }

      NavigationMap.setFocusToFixedElement('messages-input');
      if (!ValueDefault.activitymode && !ValueDefault.isFromNotification &&
          ThreadUI.notFocus) {
        dom.message.blur();
        ThreadUI.notFocus = false;
      }
      //Put the cursor at the end of the message
      const selection = window.getSelection();
      const range = document.createRange();
      const lastChild = dom.message.lastChild;
      if (lastChild.tagName === 'BR') {
        range.setStartBefore(lastChild);
      } else {
        range.setStartAfter(lastChild);
      }
      selection.removeAllRanges();
      selection.addRange(range);

      return this;
    },

    attachmentFocus: function() {
      if (!ValueDefault.activitymode) {
        ValueDefault.isFromNotification ? NotificationBase.scrollViewToBottom() :
                                          ThreadUI.scrollViewToBottom();
      }
      this._onInteracted();
    },

    handlerContentChanged: function() {
      onContentChanged();
    },

    _onFocusHandler: function() {
      this._onInteracted();
      this.focus();
    },

    // State value updated.
    updateType: function() {
      const recipients = Threads.active ? Threads.active.participants :
                                          (RecipientManager.recipients &&
                                           RecipientManager.recipients.numbers);
      if (Settings.hasGroup && Settings.groupSwitchEnabled &&
          recipients && recipients.length > 1) {
        const newType = 'mms';
        if (newType !== state.type) {
          state.type = newType;
          this.emit('type');
        }
        return;
      }
      // Beign for GF5GTMO-8488 by tingting.chao on 2025/10/24
      //Porting from TASK10115722-[GID-MTRREQ-484018]-tingting.chao on 2024/08/17- begin
      /*const isTextTooLong =
        state.segmentInfo.segments > Settings.maxConcatenatedMessages;
      let isTextTooLong =
        state.segmentInfo.segments > Settings.maxConcatenatedMessages;*/
      let isTextTooLong =
        state.segmentInfo.segments > getSmsMaxConcatenatedMsg();
      // End for GF5GTMO-8488 by tingting.chao on 2025/10/24
      if (OperatorUtils.isTMOFamily() && recipients && recipients.length == 1 && recipients[0] == 911){
        isTextTooLong = false;
        //TaskGF5GTMO-3495-[TMO:GID-MTRREQ-484019]-tingting.chao-on 2024/08/17-begin
        dom.message.setAttribute('maxLength', MAX_TEXT_LENGTH_FOR_TMO);
      } else if (dom.message.hasAttribute('maxLength')) {
        dom.message.removeAttribute('maxLength');
      }
      //TaskGF5GTMO-3495-[TMO:GID-MTRREQ-484019]-tingting.chao-on 2024/08/17-end
      //Porting from TASK10115722-[GID-MTRREQ-484018]-tingting.chao on 2024/08/17- end
      const hasEmailRecipient = recipients ? recipients.some(Utils.isEmailAddress) :
                                             false;
      const newType = (hasAttachment() || SubjectUtils.hasSubject() || hasEmailRecipient ||
                       isTextTooLong) ? 'mms' : 'sms';
      if (newType !== state.type) {
        state.type = newType;
        this.emit('type');
      }
      //GF5GTMO-3739 porting from TASK0985676 - [USCC:NW 5.27.7,NW 5.27.6]- tingting.chao on 2024/09/03-begin
      if(OperatorUtils.isTMOFamily() && state.type == 'mms') {
        dom.message.setAttribute('maxLength', MXA_MMS_CHARACTERS_COUNT_FOR_USCC);
      } else {
        dom.message.removeAttribute('maxLength');
      }
      //GF5GTMO-3739 porting from TASK0985676 - [USCC:NW 5.27.7,NW 5.27.6]- tingting.chao on 2024/09/03-end
    },

    updateEmptyState: function() {
      state.empty = state.emptyMessage && !SubjectUtils.hasSubject() && !hasAttachment();
    },

    updateMessageCounter: function() {
      let counterValue = '';

      if (this.type === 'sms') {
        const segments = state.segmentInfo.segments;
        const availableChars = state.segmentInfo.charsAvailableInLastSegment;

        //GF5GTMO-3739 porting from TASK11008094 - [USCC:NW 4.2.10]- tingting.chao on 2024/09/03 - begin
        if(segments && OperatorUtils.isUSCCFamily()){
          counterValue = availableChars + '/' + 160;
        } else {
        //GF5GTMO-3739 porting from TASK11008094 - [USCC:NW 4.2.10]- tingting.chao on 2024/09/03 - end
          if (segments && (segments > 1 ||
              availableChars <= MIN_AVAILABLE_CHARS_COUNT)) {
            counterValue = availableChars + '/' + segments;
          }
        }
      }

      if (counterValue !== dom.counter.textContent) {
        dom.counter.textContent = counterValue;
      }

      if (this.type === 'sms' && dom.counter.textContent === '' &&
          !Settings.mmsEnable) {
        dom.messageTypeLine.classList.add('message-type-line-empty');
      } else {
        dom.messageTypeLine.classList.remove('message-type-line-empty');
      }
    },

    // Common function map.
    disableSendButton: function() {
      // should disable if we have no message input
      const messageNotLong = compose.size <= Settings.mmsSizeLimitation;
      const recipients = RecipientManager.recipients;
      const recipientsValue = recipients && recipients.inputValue;
      //Porting from Task GF7TF-3039-renlongou on 2024/09/05-begin
      //Add uscc max receipents count check for GF5GTMO-8418 by tingting.chao on 2025/10/18
      const recipientMMSLimit =
        (state.type === 'mms' || OperatorUtils.isVZWFamily() || OperatorUtils.isATTFamily() || OperatorUtils.isUSCCFamily()) &&
        (recipients && recipients.length > ValueDefault.RECIPIENTS_MMS_BOX_LIMIT);
      //Porting from Task GF7TF-3039-renlongou on 2024/09/05-end
      let disableSendMessage = state.empty || state.resizing;
      let hasRecipients = false;

      if (recipientMMSLimit) {
        if (!this.isFirstExceed) {
          Utils.showMMSLimitAlert();
          this.isFirstExceed = true;
        }
      } else {
        this.isFirstExceed = false;
      }

      if (recipients && (recipients.numbers.length ||
          (recipientsValue && isFinite(recipientsValue)))) {
        hasRecipients = true;
      }

      // Should disable if the message is too long
      disableSendMessage = disableSendMessage || !messageNotLong;
      // Should disable if we have no recipients in the "new thread" view or activity mode.
      disableSendMessage = disableSendMessage ||
        ((Navigation.isCurrentPanel('composer') || ValueDefault.activitymode) &&
         !hasRecipients);
      // Should disable if the MMS recipients above 20
      disableSendMessage = disableSendMessage || recipientMMSLimit;
      // Should disable if the recupient is invalid.
      disableSendMessage = disableSendMessage || recipients.isInvalid;

      return disableSendMessage;
    }
  };

  // DefineProperty map.
  Object.defineProperty(compose, 'type', {
    get: function composeGetType() {
      return state.type;
    }
  });

  Object.defineProperty(compose, 'size', {
    get: function composeGetSize() {
      if (state.needResize) {
        state.size = this.getContent().reduce(function(sum, content) {
          if (typeof content === 'string') {
            return sum + content.length;
          } else {
            return sum + content.size;
          }
        }, 0);
        state.needResize = false;
      }

      return state.size;
    }
  });

  Object.defineProperty(compose, 'segmentInfo', {
    get: function composeGetSegmentInfo() {
      return state.segmentInfo;
    }
  });

  Object.defineProperty(compose, 'isResizing', {
    get: function composeGetResizeState() {
      return state.resizing;
    }
  });

  Object.defineProperty(compose, 'ignoreEvents', {
    set: function composeIgnoreEvents(value) {
      dom.message.classList.toggle('ignoreEvents', value);
    }
  });

  // Emit event map.
  return EventDispatcher.mixin(compose, [
    'input',
    'type',
    'segmentinfochange',
    'interact',
    'subject-change'
  ]);
}());
