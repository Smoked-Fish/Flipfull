/* global Compose, RecipientManager, SuggestionManager, Utils, ValueDefault,
          SubjectUtils, Navigation, EventManager, ContactsServiceManager */

'use strict';

// eslint-disable-next-line no-unused-vars
const InputUtils = {
  timeouts: {
    update: null,
    subjectLengthNotice: null
  },
  previousSegment: 0,

  init: function() {
    // Init base element.
    this.initElement();
    // Normal input event listener.
    this.inputField.addEventListener('focus', 
      this._onMessageInputFocusChange.bind(this));
    this.inputField.addEventListener('blur', 
      this._onMessageInputFocusChange.bind(this));
    this.subjectField.addEventListener('focus', 
      this._onMessageSubjectFocusChange.bind(this));
    this.subjectField.addEventListener('blur', 
      this._onMessageSubjectFocusChange.bind(this));
    this.toField.addEventListener('input', 
      this.toFieldInput.bind(this));
    this.toField.addEventListener('focus', 
      this.toFieldInput.bind(this));
    this.recipientSuggestions.addEventListener('click', 
      SuggestionManager._onRecipientSuggestionClick.bind(SuggestionManager));
    // Composer page init and listener.
    Compose.init('messages-compose-form');
    Compose.on('input', this._onMessageComposerInputHandler.bind(this));
    Compose.on('subject-change', this._onSubjectChange.bind(this));
    Compose.on('segmentinfochange', this._onSegmentInfoChange.bind(this));
    Compose.on('interact', RecipientManager.assimilateRecipients.bind(RecipientManager));
  },

  initElement: function() {
    this.subjectField = document.getElementById('subject-composer-input');
    this.inputField = document.getElementById('messages-input');

    ['to-field', 'recipients-list', 'compose-form',
     'recipient-suggestions'].forEach((id) => {
      this[Utils.camelCase(id)] = document.getElementById('messages-' + id);
    });
  },

  // Handler input box changed.
  _onMessageInputFocusChange: function(e) {
    this.composeForm.classList.toggle(
      'item-focus', e.type === 'focus');
  },

  _onMessageSubjectFocusChange: function(e) {
    this.composeForm.classList.toggle(
      'subject-focus', e.type === 'focus');
  },

  // Composer page handler.
  _onMessageComposerInputHandler: function() {
    if (Compose.type === 'sms') {
      this.adjustScrollElement();
      return;
    }

    if (Compose.isResizing) {
      Utils.showToaster({ messageL10nId: 'resize-image' });
    }
  },

  _onSubjectChange: function() {
    if (SubjectUtils.isSubjectVisible() && SubjectUtils.isSubjectMaxLength()) {
      Utils.showToaster({ messageL10nId: 'messages-max-subject-length-text' });
    }
  },

  _onSegmentInfoChange: function() {
    const currentSegment = Compose.segmentInfo.segments;
    const isValidSegment = currentSegment > 0;
    const isSegmentChanged = this.previousSegment !== currentSegment;
    const isStartingFirstSegment = this.previousSegment === 0 &&
                                   currentSegment === 1;

    if (Compose.type === 'sms' && isValidSegment &&
        isSegmentChanged && !isStartingFirstSegment) {
      this.previousSegment = currentSegment;
      Utils.showToaster({
        messageL10nId: 'sms-counter-notice-label',
        messageL10nArgs: { number: currentSegment }
      });
    }
  },

  // Scroll range adjust.
  adjustScrollElement: function() {
    if (Navigation.isCurrentPanel('thread') || Navigation.isCurrentPanel('composer') || 
        ValueDefault.activitymode) {
      const items = Navigation.isCurrentPanel('thread') ?
        document.querySelectorAll('ul.message-list li') :
        document.querySelectorAll('#messages-input br');
      const lastElement = items.item(items.length - 1);
      lastElement.scrollIntoView(false);
    }
  },

  // Input box action.
  toFieldInput: function(event) {
    // For not number input method.
    if (event.isComposing) {
      return;
    }

    let typed;
    this.toField.classList.toggle('recipient-multi-line',
      this.toField.offsetHeight > ValueDefault.RECIPIENTS_INPUT_FIELD_MAX_ONE);

    if (event.target.isPlaceholder) {
      typed = event.target.textContent.trim();
      if (!typed) {
        EventManager.stopContactNavigation();
      }
      ContactsServiceManager.searchContact(
        typed, SuggestionManager.listContacts.bind(SuggestionManager));
    }

    RecipientManager.emitChangeEvent();
  },

  cleanFields: function() {
    this.previousSegment = 0;
    if (RecipientManager.recipients) {
      RecipientManager.recipients.length = 0;
    }
    Compose.clear();
  }
};
