/* global Compose, EventDispatcher, ValueDefault, ThreadUI, NavigationMap, NotificationBase */

(function(exports) {
  'use strict';

  // Subject max input length.
  const MAX_LENGTH = 40;
  // Subject max input length for VZW.
  const MAX_LENGTH_VZW = 80;//Porting from Task10584937-tingting.chao on 2024/08/19-add
  // Subject object.
  const privateMembers = new WeakMap();
  // Input hanlder.
  function onInput(event) {
    privateMembers.get(this).updateValue(event.target.value);
  }

  function updateValue(newValue) {
    const priv = privateMembers.get(this);

    if (newValue) {
      newValue = newValue.replace(/\n\s*|\u00A0/g, ' ');
    }

    if (priv.value !== newValue) {
      priv.value = newValue;
      priv.input.value = newValue;
      this.emit('change');
    }

    return newValue;
  }

  const SubjectComposer = function(node) {
    // Emit event map.
    EventDispatcher.mixin(this, [
      'focus',
      'change',
      'visibility-change'
    ]);

    if (!node) {
      throw new Error('Subject node is required');
    }

    const priv = {
      isHoldingBackspace: false,
      isEmptyOnBackspace: false,
      isVisible: false,
      value: '',
      node: node,
      input: null,
      updateValue: updateValue.bind(this)
    };
    privateMembers.set(this, priv);

    priv.input = priv.node.querySelector('.subject-composer-input');
    // Subject object listener map.
    priv.input.addEventListener('input', onInput.bind(this));
    priv.input.addEventListener('focus', this.emit.bind(this, 'focus'));
    priv.input.addEventListener('focus', this.focus.bind(this));
  };

  SubjectComposer.prototype.show = function(param) {
    this.toggle(true, param);
    Compose.updateEmptyState();
    if (!ValueDefault.activitymode) {
      ValueDefault.isFromNotification ? NotificationBase.scrollViewToBottom() : 
                                        ThreadUI.scrollViewToBottom();
    }
  };

  SubjectComposer.prototype.hide = function() {
    this.toggle(false);
    if (!ValueDefault.activitymode) {
      ValueDefault.isFromNotification ? NotificationBase.scrollViewToBottom() : 
                                        ThreadUI.scrollViewToBottom();
    }
  };

  SubjectComposer.prototype.toggle = function(toggle, param) {
    const priv = privateMembers.get(this);
    priv.node.classList.toggle('hide', !toggle);
    priv.isVisible = toggle;
    if (!param) {
      this.emit('visibility-change');
    }
  };

  SubjectComposer.prototype.isVisible = function() {
    return privateMembers.get(this).isVisible;
  };

  SubjectComposer.prototype.focus = function() {
    const priv = privateMembers.get(this);
    priv.input.focus();
    if (!ValueDefault.activitymode) {
      ValueDefault.isFromNotification ? NotificationBase.scrollViewToBottom() : 
                                        ThreadUI.scrollViewToBottom();
    }
  };

  SubjectComposer.prototype.isFocused = function() {
    return document.activeElement.id === privateMembers.get(this).input.id;
  };

  SubjectComposer.prototype.getMaxLength = function() {
    //Porting from Task10584937-[VZ_tc_MMS_4115]-tingting.chao on 2024/08/19-begin
    if(OperatorUtils.isVZWFamily()){
      return MAX_LENGTH_VZW;
    }
    //Porting from Task10584937-[VZ_tc_MMS_4115]-tingting.chao on 2024/08/19-end
    return MAX_LENGTH;
  };

  SubjectComposer.prototype.getValue = function() {
    return privateMembers.get(this).value;
  };

  SubjectComposer.prototype.setValue = function(value) {
    const priv = privateMembers.get(this);
    if (typeof value !== 'string') {
      throw new Error('Value should be a valid string!');
    }
    priv.input.textContent = priv.updateValue(value);
  };

  SubjectComposer.prototype.reset = function() {
    const priv = privateMembers.get(this);
    priv.updateValue('');
    priv.node.classList.add('hide');
    priv.isVisible = false;
    NavigationMap.clearSubjectStoreFocus();
  };

  exports.SubjectComposer = SubjectComposer;
})(window);
