/* global Compose, ValueDefault, ThreadUI, NavigationMap, SubjectComposer, 
          OptionManager, DraftUtils */

'use strict';

let subject = null;

const SubjectUtils = {
  subjectComposer: null,

  init: function() {
    this.subjectComposer = document.querySelector('.js-subject-composer');
    this.composerSubject = document.querySelector('#subject-composer-input');
    //Porting from Task10584937-tingting.chao on 2024/08/19-begin
    this.composerSubject.setAttribute('maxLength', '40');
    if(OperatorUtils.isVZWFamily()) {
      this.composerSubject.setAttribute('maxLength', '80');
    }
    //Porting from Task10584937-tingting.chao on 2024/08/19-end
    subject = new SubjectComposer(this.subjectComposer);
    subject.on('change', this.onSubjectChanged.bind(this));
    subject.on('visibility-change', this.onSubjectChanged.bind(this));
    subject.on('focus', Compose._onInteracted.bind(Compose));
  },

  // Subject manager.
  subjectPreHandle: function() {
    if (OptionManager.isOptionMenuShown()) {
      document.addEventListener('transitionend', function subjectShow() {
        document.removeEventListener('transitionend', subjectShow);
        SubjectUtils.subjectManagement();  
      });
    } else {
      this.subjectManagement();
    }
  },

  subjectManagement: function() {
    if (this.isSubjectVisible()) {
      this.hideSubject();
    } else {
      this.showSubject();
    }
  },

  showSubject: function(param) {
    subject.show(param);
    this.addSubjectFocusable();
    NavigationMap.navSetup('thread-messages', '.navigable');
    NavigationMap.setFocusToFixedElement('subject-composer-input');
    this.subjectComposer.classList.add('subject-composer-visible');
  },

  hideSubject: function() {
    subject.hide();
    subject.reset();
    this.removeSubjectFocusable();
    NavigationMap.navSetup('thread-messages', '.navigable');
    NavigationMap.setFocusToFixedElement('messages-input');
    this.subjectComposer.classList.remove('subject-composer-visible');
  },

  setSubject: function(value) {
    return subject.setValue(value);
  },

  getSubject: function() {
    return subject.getValue();
  },

  hasSubject: function() {
    return subject.isVisible() && !!subject.getValue();
  },

  isSubjectVisible: function() {
    return subject.isVisible();
  },

  isSubjectFocused: function() {
    return subject.isFocused();
  },

  addSubjectFocusable: function() {
    this.composerSubject.classList.add('navigable');
  },

  removeSubjectFocusable: function() {
    this.composerSubject.classList.remove('navigable');
  },

  clearSubjectFocusable: function() {
    subject.reset();
    this.composerSubject.classList.remove('focus', 'navigable');
  },

  isSubjectMaxLength: function() {
    return subject.getValue().length >= subject.getMaxLength();
  },

  // TaskGF5GTMO-4035-porting from PRGF7TF-4656-tingting.chao on 24/09/09-begin
  getSubjectMaxLength: function() {
    return subject.getMaxLength();
  },
  // TaskGF5GTMO-4035-porting from PRGF7TF-4656-tingting.chao on 24/09/09-begin

  onSubjectChanged: function() {
    if (DraftUtils.draft) {
      DraftUtils.draft.isEdited = true;
    }

    Compose.updateEmptyState();
    Compose.updateType();

    // Not show the subject notice if enter draft thread.
    if (!ValueDefault.activitymode && !ValueDefault.isFromNotification && 
        ThreadUI.isFirstEnterThreadUI) {
      ThreadUI.isFirstEnterThreadUI = false;
      return;
    }

    Compose.emit('subject-change');
  }
};
