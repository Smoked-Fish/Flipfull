/* global RecipientManager, EventManager, ContactRenderer, NavigationMap */

'use strict';

// eslint-disable-next-line no-unused-vars
const SuggestionManager = {
  // List suggestion content.
  listContacts: function(fValue, contacts) {
    if (!RecipientManager.recipients.inputValue) {
      return;
    }
 
    this.toggleRecipientSuggestions();
    if (!contacts || !contacts.length) {
      if (EventManager.listener) {
        EventManager.stopContactNavigation();
      }
      return;
    }
 
    const suggestionList = document.createDocumentFragment();
    const renderer = ContactRenderer.flavor('suggestion');
 
    contacts.forEach((contact) => {
      const rendererArg = {
        contact: contact,
        input: fValue,
        target: suggestionList,
        skip: RecipientManager.recipients.numbers
      };
 
      renderer.render(rendererArg);
    });
 
    if (suggestionList.children.length > 0) {
      this.toggleRecipientSuggestions(suggestionList);
    } else if (EventManager.listener) {
      EventManager.stopContactNavigation();
    }
  },

  // Suggestion list show or not.
  toggleRecipientSuggestions: function(suggestions) {
    const recipientSuggestions = document.getElementById('messages-recipient-suggestions');
    const contactList = recipientSuggestions.querySelector('.contact-list');

    recipientSuggestions.classList.toggle('hide', !suggestions);

    if (!suggestions) {
      contactList.textContent = '';
      EventManager.stopContactNavigation();
    } else {
      contactList.appendChild(suggestions);
      recipientSuggestions.scrollTop = 0;
      if (!EventManager.listener) {
        EventManager.startContactNavigation();
      }
    }
  },

  // Suggestion select.
  _onRecipientSuggestionClick: function(event) {
    event.stopPropagation();
    event.preventDefault();

    RecipientManager.recipients.add(event.target.dataset).focus();
    NavigationMap.setFocusToFixedElement('lastRecipient');
  }
};
