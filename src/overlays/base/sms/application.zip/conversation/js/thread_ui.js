/* global InputUtils, ContactsServiceManager, MessageManager, RecipientManager, 
          ConversationEdit, Utils, Template, Navigation, Compose, ActivityHandler, 
          FocusStateManager, ThreadUI, NavigationMap, Threads, Thread, 
          TimeHeaders, DialogManager, ValueDefault, SwitchHandler, StateManager,
          LinkHelper, Settings, TimeUtils, Attachment, AttachmentService,
          SMIL, ThreadListUI, OptionManager, DraftUtils, SendManager, 
          MessageCache, FocusManager, Recipients, NotiificationManager, 
          EventManager, SubjectUtils, SuggestionManager, Contacts, TaskRunner, 
          Drafts, ContactRenderer, RetrieveManager, SoftkeyManager */

(function(exports) {
  'use strict';

  exports.ThreadUI = {
    // Flag mark the next page is new or exist page.
    shouldChangePanelNextEvent: false,
    // store the item when change focus or open option
    _storeFocused: null,
    // Mark the page type.
    currentMode: '',
    // Record the current thread id value.
    currentThreadId: null,
    // Speed operate record value.
    notFocus: false,
    // Hidden chunk track value.
    isDownScroll: false,
    // Switch case id backup value.
    threadIdBackUp: null,
    // Decide whether the recipient be input manually.
    isManualInput: false,
    // Link can not use GVA, it is the record value.
    isLinkMode: false,
    // Record the back from report view.
    isBackToThreadUI: false,
    // First enter message draft, not show the MMS covert alert.
    isFirstEnterThreadUI: false,
    // Because the find contact .etc action need time, 
    // so it well cause the recipients still be null when enter composer,
    // in this case, we need force the focus at input box.
    forceFocusInput: false,
    // Because option animation is slow, need record forward mode.
    isForwardMode: false,

    init: function() {
      // Init base element.
      this.initElement();

      // Element listener module.
      InputUtils.init();
      this.container.addEventListener('scroll', this.manageScroll.bind(this));
      this.container.addEventListener('click', this.clickHandler.bind(this));

      // Interface listener module.
      ContactsServiceManager.AddContactChangeListener();

      // Protocol listener module.
      MessageManager.on('message-sending', this._onMessageSending.bind(this));
      MessageManager.on('message-sent', this._onMessageSent.bind(this));
      MessageManager.on('message-received', this._onMessageReceived.bind(this));
      MessageManager.on('message-failed-to-send', this._onMessageFailed.bind(this));
      MessageManager.on('message-delivered', this._onDeliverySuccess.bind(this));
      MessageManager.on('message-read', this._onReadSuccess.bind(this));

      // Init sub feature module.
      RecipientManager.init();
      ConversationEdit.init();

      this.shouldChangePanelNextEvent = false;

      // Bound methods to be detachables
      this._onMessageTypeChange = this._onMessageTypeChange.bind(this);
    },

    initElement: function() {
      this.selector = {
        recipient: document.querySelector('#messages-recipients-list'),
        textField: document.querySelector('#messages-input')
      };

      this.threadMessages = document.getElementById('thread-messages');
      this.composerContainer = document.getElementById('composer-container');

      ['container', 'header-text'].forEach((id) => {
        this[Utils.camelCase(id)] = document.getElementById('messages-' + id);
      });

      this.selector.textField.dataset.placeholder = Utils.translateString(
        Utils.camelCase(this.selector.textField.id) + '_placeholder'
      );

      const templateIds = [
        'message',
        'message-sim-information',
        'message-status',
        'not-downloaded',
        'date-group',
        'header',
        'group-header'
      ];

      this.tmpl = templateIds.reduce((tmpls, name) => {
        tmpls[Utils.camelCase(name)] =
          Template('messages-' + name + '-tmpl');
        return tmpls;
      }, {});
    },

    // Protocol handle function.
    _onMessageSending: function(event) {
      const message = event.message;
      if (this.isCurrentThread(message.threadId)) {
        this._onMessage(message);
        this.scrollViewToBottom();
      } else {
        if (this.shouldChangePanelNextEvent) {
          Navigation.toPanel('thread', { id: message.threadId });
          this.shouldChangePanelNextEvent = false;
        }
      }

      if (OptionManager.isOptionMenuShown()) {
        document.addEventListener('transitionend', function optionMenu() {
          document.removeEventListener('transitionend', optionMenu);
          Compose.focus();
        });
      } else {
        Compose.focus();
      }

      FocusStateManager.dynamicSK();
    },

    _onMessageSent: function(event) {
      const message = event.message;
      const sentDOM = document.getElementById('message-' + message.id);

      function messageDOMCreated() {
        window.removeEventListener('message-dom-created', messageDOMCreated);
        ThreadUI.messageSentAction(message);
      }

      if (!sentDOM) {
        window.addEventListener('message-dom-created', messageDOMCreated);
      } else {
        this.messageSentAction(message);
      }
    },

    _onMessageReceived: function(event) {
      const message = event.message;

      if (!this.isCurrentThread(message.threadId)) {
        setTimeout(() => {
          if (this.container.childNodes.length === 0 &&
              Navigation.isCurrentPanel('thread') && message.isGroup) {
            Navigation.toPanel('thread-list');
          }
        });
        return;
      }

      MessageManager.markMessagesRead([message.id]);

      this._onMessage(message);
      if (!ConversationEdit.isInEditMode()) {
        this.scrollViewToBottom();
        NavigationMap.setFocusToFixedElement('messages-input');
      } else {
        NavigationMap.reset('thread-list');
      }
    },

    _onMessageFailed: function(event) {
      const message = event.message;
      const messageDOM = document.getElementById('message-' + message.id);
      
      function messageDOMCreated() {
        window.removeEventListener('message-dom-created', messageDOMCreated);
        ThreadUI.setMessageStatus(message.id, 'error');
        ThreadUI.scrollViewToBottom();
      }

      if (!messageDOM) {
        window.addEventListener('message-dom-created', messageDOMCreated);
      } else {
        this.setMessageStatus(message.id, 'error');
        this.scrollViewToBottom();
      }
    },

    _onDeliverySuccess: function(event) {
      const message = event.message;

      if (!this.shouldShowDeliveryStatus(message)) {
        return;
      }

      this.setMessageStatus(message.id, 'delivered');
      this.scrollViewToBottom();
    },

    _onReadSuccess: function(event) {
      const message = event.message;
      if (!this.shouldShowReadStatus(message)) {
        return;
      }

      this.setMessageStatus(message.id, 'read');
    },

    // Dom action function map.
    _onMessage: function(message) {
      Threads.set(message.threadId, Thread.create(message));

      this.appendMessage(message);
      TimeHeaders.updateAll('header[data-time-update]');
    },

    _onMessageTypeChange: function() {
      const messageUpperType = Compose.type + '-label';
      const tranlationType = Utils.translateString(messageUpperType);
      Utils.showToaster({
        messageL10nId: 'message-converted-to-toast',
        messageL10nArgs: { type: tranlationType },
      });
    },

    showFirstChunk: function() {
      this.showChunkOfMessages(ValueDefault.CHUNK_SIZE);
      TimeHeaders.updateAll('header[data-time-update]');
      // Go to bottom for first page.
      this.scrollViewToBottom();

      NavigationMap.reset('thread-messages');
      let focusId = null;

      if (SwitchHandler.isSwitchCase) {
        const lastNodes = document.querySelectorAll('.message');
        if (lastNodes.length !== 0) {
          const lastId = lastNodes[lastNodes.length - 1].id;
          this.messageIdFromSwitch = lastId.replace('message-', '');
          SwitchHandler.isSwitchCase = false;
        }
      }

      // Form notice focus the related message bubble.
      if (this.messageIdFromSwitch) {
        focusId = 'message-' + this.messageIdFromSwitch;
        NavigationMap.setFocusToFixedElement(focusId);
      }
    },

    showChunkOfMessages: function(number, position) {
      let elements = this.container.querySelectorAll('.hidden');

      if (position === 'ArrowDown') {
        elements = Array.prototype.slice.call(elements, 0);
        elements = elements.slice(0, number);
        this.isDownScroll = true;
      } else {
        elements = Array.prototype.slice.call(elements, -number);
      }

      elements.forEach((element) => {
        element.classList.remove('hidden');
        if (element.tagName === 'HEADER') {
          TimeHeaders.update(element);
        }
      });
    },

    appendMessage: function(message, hidden) {
      const timestamp = +message.timestamp;
      const messageDOM = document.getElementById('message-' + message.id);

      if (messageDOM) {
        this.removeMessageDOM(messageDOM);
      }

      return this.buildMessageDOM(message, hidden).then((messageDOM) => {
        if (this._stopRenderingNextStep) {
          return;
        }

        messageDOM.dataset.timestamp = timestamp;

        const messageContainer = this.getMessageContainer(timestamp, hidden);
        this.insertTimestampedNodeToContainer(messageDOM, messageContainer);

        if (ConversationEdit.isInEditMode()) {
          ConversationEdit.checkInputs();
          ConversationEdit.updateSKs();
        }

        if (!hidden && !ConversationEdit.isInEditMode()) {
          this.scrollViewToBottom();
        }

        window.dispatchEvent(new CustomEvent('message-dom-created'));
      });
    },

    buildMessageDOM: function(message, hidden) {
      const messageDOM = document.createElement('li');
      let bodyHTML = '';
      let messageStatus = message.delivery;
      const isNotDownloaded = messageStatus === 'not-downloaded';
      const isIncoming = messageStatus === 'received' || isNotDownloaded;
      const noAttachment = (message.type === 'mms' && !isNotDownloaded &&
                           (message.attachments === null ||
                            message.attachments.length === 0));
      const invalidEmptyContent = (noAttachment && !message.subject);

      if (this.shouldShowReadStatus(message)) {
        messageStatus = 'read';
      } else if (this.shouldShowDeliveryStatus(message)) {
        messageStatus = 'delivered';
      }

      let classNames = [
        'navigable', 'message', message.type, messageStatus,
        isIncoming ? 'incoming' : 'outgoing'
      ];

      if (hidden) {
        classNames.push('hidden');
      }

      if (message.type && message.type === 'mms' && message.subject) {
        classNames.push('has-subject');
      }

      if (message.type && message.type === 'sms') {
        const escapedBody = Template.escape(message.body || '');
        bodyHTML = LinkHelper.searchAndLinkClickableData(escapedBody);
      }

      if (isNotDownloaded) {
        bodyHTML = this.createNotDownloadedHTML(message, classNames);
      }

      if (invalidEmptyContent) {
        classNames = classNames.concat(['error', 'invalid-empty-content']);
      } else if (noAttachment) {
        classNames.push('no-attachment');
      }

      if (classNames.indexOf('error') >= 0) {
        messageStatus = 'error';
      } else if (classNames.indexOf('pending') >= 0) {
        messageStatus = 'pending';
      }

      messageDOM.className = classNames.join(' ');
      messageDOM.id = 'message-' + message.id;
      messageDOM.dataset.messageId = message.id;
      messageDOM.dataset.iccId = message.iccId;
      messageDOM.setAttribute('role', 'menuitem');
      const simServiceId = Settings.getServiceIdByIccId(message.iccId);
      const showSimInformation =
        Settings.hasSeveralSim() && simServiceId !== null;
      let simInformationHTML = '';
      if (showSimInformation) {
        simInformationHTML = this.tmpl.messageSimInformation.interpolate({
          simNumberL10nArgs: JSON.stringify({ id: simServiceId + 1 })
        });
      }

      let contactSender = message.sender;

      if (message.isGroup) {
        messageDOM.classList.add('isGroup');
        contactSender = ContactsServiceManager.pickContactFromNumbers(message.sender);
        if (isIncoming) {
          const threadReceivers = Threads.active.participants;
          const sortReceivers = threadReceivers.sort();
          const threadIndex = sortReceivers.indexOf(message.sender);
          if (threadIndex !== -1) {
            const colorClassName = ValueDefault.COLORMAP[threadIndex];
            messageDOM.classList.add(colorClassName);
          }
        }
      }

      messageDOM.innerHTML = this.tmpl.message.interpolate({
        id: String(message.id),
        bodyHTML: bodyHTML,
        timestamp: String(message.timestamp),
        sender: String(contactSender) + Utils.translateString('colon'),
        subject: String(message.subject),
        simInformationHTML: simInformationHTML,
        messageStatusHTML: this.getMessageStatusMarkup(messageStatus).toString()
      }, {
        safe: ['bodyHTML', 'simInformationHTML', 'messageStatusHTML']
      });

      TimeHeaders.update(messageDOM.querySelector('time'));

      messageDOM.querySelector('.deliver-mark').classList
        .toggle('hide', messageStatus !== 'delivered');

      const pElement = messageDOM.querySelector('p');
      if (invalidEmptyContent) {
        pElement.setAttribute('data-l10n-id', 'no-attachment-text');
      }

      if (message.type === 'mms' && !isNotDownloaded && !noAttachment) {
        return this.mmsContentParser(message).then((mmsContent) => {
          pElement.appendChild(mmsContent);
          return messageDOM;
        });
      }

      return Promise.resolve(messageDOM);
    },

    createNotDownloadedHTML: function(message, classNames) {
      let messageL10nId = 'tobedownloaded-attachment';
      let downloadL10nId = '';
      const status = message.deliveryInfo[0].deliveryStatus;
      const expireFormatted = TimeUtils.date.format.localeFormat(
        new Date(+message.expiryDate), Utils.translateString('expiry-date-format')
      );
      const expired = +message.expiryDate < Date.now();

      if (expired) {
        classNames.push('expired');
        messageL10nId = 'expired-attachment';
      }

      if (status === 'error') {
        classNames.push('error');
      }

      if (status === 'pending') {
        downloadL10nId = 'downloading-attachment';
        classNames.push('pending');
      }

      return this.tmpl.notDownloaded.interpolate({
        messageL10nId: messageL10nId,
        messageL10nArgs: JSON.stringify({ date: expireFormatted }),
        messageL10nDate: message.expiryDate.toString(),
        messageL10nDateFormat: 'expiry-date-format',
        downloadL10nId: downloadL10nId
      });
    },

    createMmsContent: function(dataArray) {
      const container = document.createDocumentFragment();
      const textArray = [];
      const blobArray = [];

      dataArray.forEach((messageData) => {
        if (messageData.text) {
          textArray.push(messageData);
        }
        if (messageData.blob) {
          blobArray.push(messageData);
        }
      });

      textArray.forEach((textData) => {
        const textElement = document.createElement('span');
        let text = Template.escape(textData.text);
        text = LinkHelper.searchAndLinkClickableData(text);
        textElement.innerHTML = text;
        container.appendChild(textElement);
      });

      blobArray.forEach((blobData) => {
        const attachment = new Attachment(blobData.blob, {
          name: blobData.name
        });
        const mediaElement = attachment.render();
        container.appendChild(mediaElement);
        AttachmentService.attachmentMapSet(mediaElement, attachment);
      });
      return container;
    },

    mmsContentParser: function(message) {
      return new Promise((resolver) => {
        SMIL.parse(message, (slideArray) => {
          resolver(this.createMmsContent(slideArray));
        });
      });
    },

    removeMessageDOM: function(messageDOM) {
      if (!messageDOM) {
        return;
      }
      const messagesContainer = messageDOM.parentNode;
      messageDOM.remove();

      if (messagesContainer &&!messagesContainer.firstElementChild) {
        messagesContainer.parentNode.remove();
      }
    },

    deleteUIMessages: function(list, callback) {
      if (!Array.isArray(list)) {
        list = [list];
      }
      for (let i = 0, l = list.length; i < l; i++) {
        const deletedElement = document.getElementById('message-' + list[i]);
        this.removeMessageDOM(deletedElement);
      }
  
      callback = typeof callback === 'function' ? callback : function() {};
  
      if (!this.container.firstElementChild) {
        ThreadListUI.removeThread(Threads.currentId);
        callback();
        this.back();
      } else {
        const lastMessage = 
          this.container.lastElementChild.querySelector('li:last-child');
        const request = MessageManager.getMessage(+lastMessage.dataset.messageId);
        request.onsuccess = () => {
          ThreadListUI.updateThread(request.result, { deleted: true });
          callback();
        };
        request.onerror = () => {
          callback();
        };
      }
    },

    getMessageContainer: function(messageTimestamp, hidden) {
      const startOfDayTimestamp = TimeUtils.getDayDate(messageTimestamp);
      let messageDateGroup =
        document.getElementById('mc_' + startOfDayTimestamp);
      let header, messageContainer;

      if (messageDateGroup) {
        header = messageDateGroup.firstElementChild;
        messageContainer = messageDateGroup.lastElementChild;

        if (messageTimestamp < header.dataset.time) {
          header.dataset.time = messageTimestamp;
        }
        return messageContainer;
      }

      const dateGroupTmpl = this.tmpl.dateGroup.interpolate({
        id: 'mc_' + startOfDayTimestamp,
        timestamp: startOfDayTimestamp.toString(),
        headerTimeUpdate: 'repeat',
        headerTime: messageTimestamp.toString(),
        headerDateOnly: 'true'
      });
      const template = document.createElement('template');
      template.innerHTML = dateGroupTmpl;
      const dateGroupNode =  template.content.cloneNode(true);
      messageDateGroup = dateGroupNode.firstElementChild;

      header = messageDateGroup.firstElementChild;
      messageContainer = messageDateGroup.lastElementChild;

      if (hidden) {
        header.classList.add('hidden');
      } else {
        TimeHeaders.update(header);
      }

      this.insertTimestampedNodeToContainer(messageDateGroup, this.container);

      return messageContainer;
    },

    insertTimestampedNodeToContainer: function(nodeToInsert, container) {
      let currentNode = container.firstElementChild;
      const nodeTimestamp = nodeToInsert.dataset.timestamp;
      while (currentNode && nodeTimestamp > +currentNode.dataset.timestamp) {
        currentNode = currentNode.nextElementSibling;
      }
      container.insertBefore(nodeToInsert, currentNode || null);
    },

    // Common function map.
    isCurrentThread: function(threadId) {
      return Navigation.isCurrentPanel('thread', { id: threadId }) ||
             Navigation.isCurrentPanel('report-view', { threadId: threadId });
    },

    scrollViewToBottom: function() {
      if (this.container.lastElementChild &&
          Navigation.isCurrentPanel('thread')) {
        this.container.lastElementChild.scrollIntoView(false);
      }
    },

    getMessageStatusMarkup: function(status) {
      return ['read', 'sending', 'error'].indexOf(status) >= 0 ?
        this.tmpl.messageStatus.interpolate({
          statusL10nId: 'message-delivery-status-' + status
        }) : '';
    },

    shouldShowDeliveryStatus: function(message) {
      if (message.delivery !== 'sent') {
        return false;
      }

      if (message.type === 'mms') {
        return message.deliveryInfo.every((info) => {
          return info.deliveryStatus === 'success';
        });
      } else {
        return message.deliveryStatus === 'success';
      }
    },

    shouldShowReadStatus: function(message) {
      if (message.delivery !== 'sent' || message.type === 'sms' ||
          !message.deliveryInfo) {
        return false;
      }

      return message.deliveryInfo.every((info) => {
        return info.readStatus === 'success';
      });
    },

    enableConvertNoticeBanners: function() {
      Compose.on('type', this._onMessageTypeChange);
    },

    disableConvertNoticeBanners: function() {
      Compose.off('type', this._onMessageTypeChange);
    },

    manageScroll: function() {
      if (this.isDownScroll) {
        this.isDownScroll = false;
        return;
      }

      const scrollTop = this.container.scrollTop;
      const scrollHeight = this.container.scrollHeight;
      const kEdge = 30;

      if (scrollTop < kEdge) {
        this.showChunkOfMessages(ValueDefault.CHUNK_SIZE);
        this.container.scrollTop =
          (this.container.scrollHeight - scrollHeight) + scrollTop;
      }
    },

    getFocusedMessageId: function(forcusedItem) {
      if (forcusedItem.tagName !== 'LI') {
        const item = Utils.getParents(forcusedItem, 'LI');
        return item.dataset.messageId;
      } else {
        return forcusedItem.dataset.messageId;
      }
    },

    showToaster: function(mode, count) {
      const param = {};
      if (mode === 'messageMode') {
        param.messageL10nId = 'delete-message';
      }
      else if (mode === 'threadMode') {
        param.messageL10nId = 'deleted-threads';
      }
      else if (mode === 'editMode') {
        param.messageL10nId = 'deleted-message';
        param.messageL10nArgs = { n: count };
      }
      Utils.showToaster(param);
    },

    listenLinkElement: function(node) {
      const isAttachment = AttachmentService.attachmentMapGet(node);
      if (isAttachment) {
        return 'attachment';
      } else {
        return node.getAttribute('data-action');
      }
    },

    // Protocol action next handler.
    messageSentAction: function(message) {
      this.setMessageStatus(message.id, 'sent');
      this.scrollViewToBottom();
      Utils.showToaster({ messageL10nId: 'message-sent-toast' });
    },

    setMessageStatus: function(id, status) {
      const messageDOM = document.getElementById('message-' + id);

      if (!messageDOM || messageDOM.classList.contains(status)) {
        return;
      }

      const newStatusMarkup = this.getMessageStatusMarkup(status);
      const oldStatusNode = messageDOM.querySelector('.message-status');

      messageDOM.classList.remove(
        'sending', 'pending', 'sent', 'received', 'delivered', 'read', 'error'
      );
      messageDOM.classList.add(status);
      messageDOM.querySelector('.deliver-mark').classList
        .toggle('hide', status !== 'delivered');

      if (oldStatusNode) {
        oldStatusNode.remove();
      }

      if (newStatusMarkup) {
        const template = document.createElement('template');
        template.innerHTML = newStatusMarkup;
        messageDOM.querySelector('.message-content-body-container').appendChild(
          template.content.cloneNode(true)
        );
      }
    },

    // Hardware event handler.
    back: function(close) {
      if (ValueDefault.isAttachmentPage) {
        return;
      }
      // Not list message bubble after back.
      this.stopRendering();
      // Judge whether alert draft dialog.
      return DraftUtils._onNavigatingBack(close).then(() => {
        if (close) {
          MessageCache.clear('threads-container');
          // Set thread id at settings value to judge notification shown logic.
          Utils.setSettingsValue([{ 
            name: 'message.thread.id', 
            value: null 
          }]);
          ActivityHandler.lastMessage ? ActivityHandler.leaveActivity({ data: null }) :
                                        window.close();
        } else {
          const focus = document.querySelector('.focus');
          focus && focus.classList.remove('focus');
          Settings.isGroup = false;
          Navigation.toPanel('thread-list');
          this.composerContainer.classList.remove('next-focus');
          if (Threads.currentId) {
            NavigationMap.updateCurIndex('thread-list',
                                         'thread-' + Threads.currentId);
          } else {
            if (FocusManager.currentThread) {
              NavigationMap.updateCurIndex('thread-list', FocusManager.currentThread.id);
            }
          }
        }
      }).catch((e) => {
        FocusStateManager.dynamicSK();
        return Promise.reject(e);
      });
    },

    clickHandler: function(event) {
      if (ConversationEdit.isInEditMode()) {
        return;
      }

      if (!AttachmentService.attachmentMapGet(event.target)) {
        this.handleMessageClick(event);
      }
    },

    handleMessageClick: function(event) {
      const elems = {};
      let currentNode = event.target;

      while (currentNode && currentNode.classList) {
        if (currentNode.classList.contains('bubble')) {
          elems.bubble = currentNode;
        } else if (currentNode.classList.contains('message')) {
          elems.message = currentNode;
        } else if (currentNode.classList.contains('message-status')) {
          elems.messageStatus = currentNode;
        }
        currentNode = currentNode.parentNode;
      }

      if (!(elems.message && elems.bubble)) {
        return;
      }

      if (elems.message.classList.contains('not-downloaded')) {
        if (elems.message.classList.contains('expired') ||
            elems.message.classList.contains('pending')) {
          return;
        }

        if (StateManager.isDiskFull) {
          DialogManager.alertFreeSpace('download');
        } else {
          RetrieveManager.retrieveMMS(elems.message);
        }
      }
    },

    // Handle the route event.
    beforeEnter: function(args) {
      // Reset the recipient field.
      Recipients.View.isFocusable = true;
      SendManager.initSentAudio();

      // Show the input field.
      this.selector.textField.classList.remove('hide');

      this.currentMode = args.meta.next.panel;
      if (OptionManager.isOptionMenuShown()) {
        OptionManager.hideOptionMenu();
      }
      switch (this.currentMode) {
        case 'composer':
          return this.beforeEnterComposer(args);
        case 'thread':
          return this.beforeEnterThread(args);
        default:
          return Promise.reject();
      }
    },

    beforeEnterComposer: function(args) {
      Threads.currentId = (args.id && args.keyword !== 'forward') ? args.id : null;
      if (args.keyword) {
        Threads.keyword = args.keyword;
      }
      InputUtils.cleanFields();
      const childElement = this.selector.recipient.lastChild;
      if (childElement.tagName) {
        childElement.classList.add('navigable');
      }
      RecipientManager.initRecipients();
      this.updateComposerHeader();
      this.container.textContent = '';
      this.threadMessages.classList.add('new');

      return Promise.resolve();
    },

    beforeEnterThread: function(args) {
      Threads.currentId = args.id;
      // Set thread id at settings value to judge notification shown logic.
      Utils.setSettingsValue([{ 
        name: 'message.thread.id', 
        value: Threads.currentId 
      }]);

      // Init the message thread page.
      const prevPanel = args.meta.prev && args.meta.prev.panel;
      if (prevPanel !== 'report-view') {
        this.initializeRendering();
      }

      if (prevPanel === 'thread-list' && Threads.active.lastMessageType === 'sms') {
        Utils.sendEventLogs(Threads.active.participants, 'sms_open');
      }

      // Reset the recipient field.
      const recipientsNode = this.selector.recipient.querySelector('.navigable');
      if (recipientsNode) {
        recipientsNode.classList.remove('navigable');
      }

      return this.updateHeaderData();
    },

    afterEnter: function(args) {
      const next = args.meta.next.panel;
      this.isManualInput = false;
      switch (next) {
        case 'composer':
          return this.afterEnterComposer(args);
        // eslint-disable-next-line no-case-declarations
        case 'thread':
          const prevPanel = args.meta.prev && args.meta.prev.panel;
          if (prevPanel === 'report-view') {
            FocusStateManager.dynamicSK();
          }
          return this.afterEnterThread(args);
        default:
          return Promise.reject();
      }
    },

    afterEnterComposer: function(args) {
      this.isManualInput = true;
      if (args.activity) {
        this.handleActivity(args.activity);
      } else if (args.forward) {
        this.handleForward(args.forward);
      } else if (args.draftId || Threads.currentId) {
        this.handleDraft(+args.draftId);
      }
      NavigationMap.reset('thread-messages');

      this.enableConvertNoticeBanners();
      // not strictly necessary but better for consistency
      return Promise.resolve();
    },

    afterEnterThread: function(args) {
      const threadId = +args.id;
      const prevPanel = args.meta.prev && args.meta.prev.panel;
      this.currentThreadId = threadId;

      if (args.body) {
        this.selector.textField.textContent = args.body;
        this.selector.textField.setAttribute('data-placeholder', '');
        Compose.handlerContentChanged();
      }

      if (prevPanel !== 'report-view') {
        NavigationMap.reset('thread-messages');
        this.renderMessages(threadId);

        if (!ActivityHandler.lastMessage) {
          DraftUtils.draftRequest(threadId).then(() => {
            this.enableConvertNoticeBanners();
          });
        }
      }

      ThreadListUI.whenReady().then(() => {
        ThreadListUI.mark(threadId, 'read');
        const threadData = Threads.get(threadId);
        if (threadData) {
          threadData.unreadCount = 0;
          Threads.set(threadId, threadData);
        }

        setTimeout(() => MessageManager.markThreadRead(threadId));
      });

      return NotiificationManager.closeNotificationsForThread(threadId);
    },

    beforeLeave: function(args) {
      EventManager.stopContactNavigation();
      this.disableConvertNoticeBanners();

      const nextPanel = args.meta.next && args.meta.next.panel;

      if (Navigation.isCurrentPanel('thread')) {
        ConversationEdit.cancelEdit();
        const nodes = this.container.querySelectorAll(
          '.attachment-container[data-thumbnail]'
        );
        Array.from(nodes).forEach((node) => {
          window.URL.revokeObjectURL(node.dataset.thumbnail);
        });
      }

      if (nextPanel !== 'report-view') {
        InputUtils.cleanFields();
        OptionManager.hideOptionMenu();
      }

      // Set thread id at settings value to judge notification shown logic.
      Utils.setSettingsValue([{ 
        name: 'message.thread.id', 
        value: null 
      }]);
    },

    afterLeave: function() {
      SubjectUtils.removeSubjectFocusable();
      if (Navigation.isCurrentPanel('thread-list')) {
        this.container.textContent = '';
        InputUtils.cleanFields();
        Threads.currentId = null;
      }
      if (!Navigation.isCurrentPanel('composer')) {
        this.threadMessages.classList.remove('new');

        if (RecipientManager.recipients) {
          RecipientManager.recipients.length = 0;
        }

        SuggestionManager.toggleRecipientSuggestions();
      }
    },

    // Header action function map.
    updateComposerHeader: function() {
      this.setHeaderContent('newMessage');
    },

    setHeaderContent: function(contentL10n) {
      if (typeof contentL10n === 'string') {
        contentL10n = { id: contentL10n };
      }

      if (contentL10n.id) {
        this.headerText.firstElementChild && (this.headerText.textContent = '');
        Utils.translateFromAtr(
          this.headerText, contentL10n.id, contentL10n.args
        );
        return;
      }

      if (contentL10n.html) {
        this.headerText.removeAttribute('data-l10n-id');
        this.headerText.innerHTML = contentL10n.html;
      }
    },

    updateHeaderData: function() {
      let thread, number;

      thread = Threads.active;

      if (!thread) {
        return Promise.resolve();
      }

      if (thread.isGroup) {
        ContactsServiceManager.getThreadContactArray(thread.participants);
      }

      number = thread.participants[0];

      this.headerText.dataset.number = number;

      return new Promise((resolve) => {
        Contacts.findByAddress(number, (contacts) => {
          const details = ContactsServiceManager.getContactDetails(number, contacts);
          let contactName = details.title || number;
          this.headerText.dataset.isContact = !!details.isContact;
          this.headerText.dataset.title = contactName;

          if (thread.participants.length > 1) {
            contactName = contactName + Utils.translateString('multiple-recipients-flag');
          }

          const headerContentTemplate = thread.participants.length > 1 ?
            this.tmpl.groupHeader : this.tmpl.header;
          this.setHeaderContent({
            html: headerContentTemplate.interpolate({
              name: contactName,
              participantCount: (thread.participants.length).toString()
            })
          });
          resolve();
        });
      });
    },

    // Message data rendering function map.
    initializeRendering: function() {
      // Clean fields
      InputUtils.cleanFields();
      // Clean list of messages
      this.container.innerHTML = '';
      // Initialize infinite scroll params
      this.messageIndex = 0;
      // reset stopRendering boolean
      this._stopRenderingNextStep = false;
      this._renderingMessage = true;
    },

    stopRendering: function() {
      this._stopRenderingNextStep = true;
      this._renderingMessage = false;
    },

    renderMessages: function(threadId, callback) {
      let taskQueue = new TaskRunner();
      this.threadIdBackUp = threadId;

      const onMessagesRendered = (() => {
        if (this.messageIndex < ValueDefault.CHUNK_SIZE) {
          taskQueue.push(this.showFirstChunk.bind(this));
        }

        if (callback) {
          callback();
        }
        this._renderingMessage = false;
        window.dispatchEvent(new CustomEvent('messages-render-complete'));
      });

      const onRenderMessage = ((message) => {
        if (this.threadIdBackUp && (this.threadIdBackUp !== message.threadId)) {
          return false;
        }

        if (this._stopRenderingNextStep) {
          taskQueue = null;
          return false;
        }
        taskQueue.push(() => {
          if (!this._stopRenderingNextStep) {
            return this.appendMessage(message, true);
          }
          return false;
        });
        this.messageIndex++;
        if (this.messageIndex === ValueDefault.CHUNK_SIZE) {
          taskQueue.push(this.showFirstChunk.bind(this));
        }
        return true;
      });

      if (this._stopRenderingNextStep) {
        return;
      }

      const filter = { threadId: threadId };
      const renderingOptions = {
        each: onRenderMessage,
        filter: filter,
        invert: false,
        end: onMessagesRendered,
        chunkSize: ValueDefault.CHUNK_SIZE
      };

      MessageManager.getMessages(renderingOptions);
    },

    // Route event handler function.
    handleActivity: function(activity) {
      let findByAddress = Contacts.findByAddress.bind(Contacts);
      let number = activity.number;
      if (activity.contact && !number) {
        findByAddress = (contact, cb) => {
          cb(activity.contact);
        };
        number = activity.contact.number || activity.contact.tel[0].value;
      }

      if (activity.contact && number) {
        ContactsServiceManager.getContactDisplayInfo(findByAddress, number, (data) => {
          data.source = 'contacts';
          RecipientManager.recipients.add(data);
          Compose.fromMessage(activity);
          NavigationMap.setFocusToFixedElement('messages-input');
        });
      } else {
        if (number) {
          RecipientManager.recipients.add({
            number: number,
            source: 'manual'
          });
        }
        Compose.fromMessage(activity);
      }
    },

    handleForward: function(forward) {
      const request = MessageManager.getMessage(+forward.messageId);
      request.onsuccess = () => {
        Compose.fromMessage(request.result);
        RecipientManager.setRecipientFocus();
        ThreadUI.isForwardMode = true;
      };
      request.onerror = () => {
        console.error('Error while forwarding:', this.error.name);
      };
    },

    handleDraft: function(threadId) {
      DraftUtils.draft = Drafts.get(threadId || Threads.currentId) || null;

      if (DraftUtils.draft) {
        DraftUtils.draft.recipients.forEach((number) => {
          Contacts.findByAddress(number, (records) => {
            if (records && records.length) {
              RecipientManager.recipients.add(
                ContactsServiceManager.basicContact(number, records[0]), true
              );
            } else {
              RecipientManager.recipients.add({
                number: number
              }, true);
            }
            NavigationMap.setFocusToFixedElement('messages-input');
            DraftUtils.draft.isEdited = false;
          });
        });

        if (DraftUtils.draft.recipients.length === 0) {
          RecipientManager.setRecipientFocus();
        }

        Compose.fromDraft(DraftUtils.draft);

        if (DraftUtils.draft.isGroup) {
          Settings.isGroup = true;
          Compose.updateType();
        }
      }
    },

    // Link action bar map.
    openLinkFocus: function (type) {
      const focusEle = document.querySelector('.focus');
      switch (type) {
        case 'dial':
          this.promptContact({
            number: focusEle.dataset.dial,
            inMessage: true
          });
          break;
        case 'email':
          this.promptContact({
            email: focusEle.dataset.email,
            inMessage: true
          });
          break;
      }
    },

    // Contact alert.
    promptContact: function(opts) {
      opts = opts || {};

      const inMessage = opts.inMessage || false;
      const number = opts.number || opts.email || '';
      let tel, email;

      if (Settings.supportEmailRecipient && Utils.isEmailAddress(number)) {
        email = number || '';
      } else {
        tel = number || '';
      }

      Contacts.findByAddress(number, (results) => {
        const isContact = results && results.length;
        const contact = results[0];
        let id;
        let fragment;

        if (isContact) {
          id = contact.id;
          fragment = document.createDocumentFragment();
          ContactRenderer.flavor('prompt').render({
            contact: contact,
            input: number,
            target: fragment
          });
        }

        OptionManager.prompt({
          number: tel,
          email: email,
          header: fragment,
          contactId: id,
          contact: contact,
          isContact: isContact,
          inMessage: inMessage
        });
      });
    },

    _onCreateContact: function() {
      ContactsServiceManager.updateContactsInfo();
      if (Navigation.isCurrentPanel('thread')) {
        ThreadUI.updateHeaderData();
        SoftkeyManager.updateLinkSKs();
      }
    },

    // Forward action.
    forwardMessage: function (messageId) {
      document.dispatchEvent(new CustomEvent('stop-getMessages'));
      Utils.findBodyContent(messageId, (needLimit) => {
        Utils.operatorCreationMode(needLimit, (isLimit) => {
          if (isLimit) {
            return;
          }

          Navigation.toPanel('composer', {
            id: Threads.currentId,
            keyword: 'forward',
            forward: {
              messageId: messageId
            }
          });
        });
      });
    }
  };
}(this));
