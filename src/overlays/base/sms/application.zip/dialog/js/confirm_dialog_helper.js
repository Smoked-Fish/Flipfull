/* global LazyLoader, Utils, NavigationMap, SoftkeyManager, Navigation, ValueDefault */

(function(window) {
  'use strict';

  const WAITTIMEOUT = 600;
  const resources = [
    'http://shared.localhost/js/utils/components/component_utils.js',
    'http://shared.localhost/elements/gaia_confirm/gaia_confirm.js'
  ];

  function ConfirmDialogHelper(config) {
    this.config = config;
    this.dialogShown = false;
  }

  ConfirmDialogHelper.prototype = {
    activeElement: null,
    deltaTop: 100,
    Softkey: window.option,
    isShown: false,
    isGroup: false,
    show: function(parent) {
      LazyLoader.load(resources, this._show.bind(this, parent));
    },

    // Show dialog.
    _show: function(parent) {
      const config = this.config;
      const confirmClass = config.system ? 'insystem' : '';
      const wrapper = document.createElement('div');
      this.parent = parent;
      this.activeElement = document.querySelector('.focus');

      wrapper.innerHTML =
        '<gaia-confirm id="gaia-confirm" role="menuitem" tabindex="1" class=' +
        confirmClass + '>' +
        '<h1 slot="title" style="text-align:center; height:3rem; padding-top:0.5rem;"></h1>' +
        '<div slot="content" class="content height-adjust"><div>' +
        '<p style="font-weight: normal;word-wrap: break-word;margin: 0;padding: 1rem;line-height: 2.4rem;color: var(--color-gs90);background: var(--color-gs00);"></p>' +
        '<p class="noborder" style="font-weight: normal;word-wrap: break-word;margin: 0;padding: 1rem;line-height: 2.4rem;color: var(--color-gs90);background: var(--color-gs00);margin-top: -1.5rem;" hidden></p>' +
        '</div></div>' +
        '</gaia-confirm>';

      let element = wrapper.firstElementChild;
      this.element = element;
      element.dataset.type = config.type;
      // Event listener.
      element.addEventListener('confirm', this);
      element.addEventListener('cancel', this);
      element.addEventListener('accept', this);
      window.addEventListener('hashchange', this);

      const plist = element.querySelectorAll('p');
      const title = element.querySelector('h1');
      const body = plist[0];
      const desc = plist[1];
      title.style.textAlign = 'center';

      const setL10nAttributes = (element, options) => {
        if ('string' === typeof options) {
          Utils.translateFromAtr(element, options);
        }

        if (options.id) {
          Utils.translateFromAtr(element, options.id, options.args);
        } else if (options.text) {
          element.textContent = options.text;
        }
      };

      if (config.isGroupMessage) {
        this.isGroup = true;
      }
      setL10nAttributes(title, config.title);
      setL10nAttributes(body, config.body);

      if (config.desc && (config.desc.id || config.desc.text)) {
        desc.hidden = false;
        setL10nAttributes(desc, config.desc);
      } else {
        desc.hidden = true;
      }

      if (NavigationMap && NavigationMap.currentActivatedLength > -1) {
        if (NavigationMap.currentActivatedLength === 0) {
          NavigationMap.currentActivatedLength = 1;
        } else {
          setTimeout(() => {
            this.show(parent);
          }, WAITTIMEOUT);
          return;
        }
      }

      element.setAttribute('hidden', '');
      parent.appendChild(element);
      window.addEventListener('keydown', this, true);
      this.dialogShown = true;
      this.activeElement && this.activeElement.blur();

      element.removeAttribute('hidden');
      this.isShown = true;
      window.dispatchEvent(new CustomEvent('gaia-confirm-open'));

      // Init softkey.
      let softkeyParams = [];
      if (config.cancel) {
        softkeyParams.push({
          name: '',
          priority: 1,
          l10nId: config.cancel.l10nId,
          method: function() {
          }
        });
      }
      if (config.accept) {
        softkeyParams.push({
          name: '',
          priority: 2,
          l10nId: config.accept.l10nId,
          method: function() {
          }
        });
      }
      if (config.confirm) {
        softkeyParams.push({
          name: '',
          priority: 3,
          l10nId: config.confirm.l10nId,
          method: function() {
          }
        });
      }

      SoftkeyManager.show(softkeyParams);
      element.focus();
    },

    // Hide dialog.
    destroy: function() {
      if (!this.element) {
        return;
      }
      
      if (NavigationMap && NavigationMap.currentActivatedLength > -1) {
        NavigationMap.currentActivatedLength = 0;
      }

      window.removeEventListener('hashchange', this);
      window.removeEventListener('keydown', this);
      this.dialogShown = false;
      this.element.setAttribute('hidden', '');
      this.element.parentNode.removeChild(this.element);
      this.element = null;
      this.isShown = false;
      window.dispatchEvent(new CustomEvent('gaia-confirm-close'));
      // TODO Set time out to prevent extra keydown event received.
      setTimeout(() => {
        this.recoveryFocus();
      });
    },

    // Recovery the old focus.
    recoveryFocus: function() {
      if (ValueDefault.isFromNotification || 
          !Navigation.isCurrentPanel('report-view')) {
        if (this.activeElement.id) {
          NavigationMap.setFocusToFixedElement(this.activeElement.id);
        //TaskGF5GTMO-3568-porting from Defecct10676918-tingting.chao on 24/08/21-begin
        } else if(this.activeElement.textContent === "Call"){
          NavigationMap.setFocusToFixedElement("messages-input");
        //TaskGF5GTMO-3568-porting from Defecct10676918-tingting.chao on 24/08/21-end
        } else {
          NavigationMap.setFocusToKnownElement(this.activeElement);
        }
      } else {
        SoftkeyManager.updateInformationSks();
      }
    },

    // Scroll to up/down.
    scrollContext: function(key) {
      const dialogContainer = this.parent.querySelector('div.content');
      const headerHeight = this.parent.querySelector('h1').clientHeight;
      const listHeaderHeight = document.getElementById('messages-header').clientHeight;
      const containerHeight = document.body.clientHeight -
                              this.getSoftkeyHeight() - headerHeight - listHeaderHeight;
      // If dialog shows all texts , no need to scroll it.
      if (dialogContainer.clientHeight < containerHeight) {
        this.scroll = false;
        return;
      }
      dialogContainer.style.setProperty('height', containerHeight.toString() + 'px');
      dialogContainer.scrollTop = 
        key === 'ArrowUp' ? (dialogContainer.scrollTop - this.deltaTop) : 
                            (dialogContainer.scrollTop + this.deltaTop);
    },

    getSoftkeyHeight: function() {
      let height = 0;
      // eslint-disable-next-line no-undef
      const softkeyPanel = document.querySelector('#' + FORM_ID);
      if (softkeyPanel && softkeyPanel.classList.contains('visible')) {
        height = softkeyPanel.clientHeight;
      }
      return height;
    },

    // Handle event.
    handleEvent: function(event) {
      // Ensure we hide the dialog in the face of other errors.
      if (!this.isShown) {
        return;
      }

      switch (event.type) {
        case 'hashchange': {
          // Hashchange is only here to trigger this to call destroy.
          break;
        }
        case 'confirm': {
          this.destroy();
          const confirm = this.config.confirm.callback;
          confirm && confirm();
          break;
        }
        case 'cancel': {
          this.destroy();
          const cancel = this.config.cancel.callback;
          cancel && cancel();
          break;
        }
        case 'accept': {
          this.destroy();
          const accept = this.config.accept.callback;
          accept && accept();
          break;
        }
        default:
          break;
      }

      let keyHandled = true;
      switch (event.key) {
        case 'Backspace': {
          // Dialog destory is quicker than event module listener, so need set time out.
          setTimeout(() => {
            this.destroy();
          });
          const back = this.config.backcallback;
          back && back();
          break;
        }
        case 'EndCall': {
          this.destroy();
          const close = this.config.closecallback;
          close && close();
          break;
        }
        case 'Enter':
        case 'Accept': {
          if (this.config.accept && this.config.accept.l10nId && this.dialogShown) {
            this.element.dispatchEvent(new CustomEvent('accept'));
          }
          break;
        }
        case 'ArrowUp':
        case 'ArrowDown': {
          this.scrollContext(event.key);
          break;
        }
        case 'SoftLeft': {
          if (this.config.cancel && this.config.cancel.l10nId && this.isShown) {
            this.element.dispatchEvent(new CustomEvent('cancel'));
          }
          break;
        }
        case 'SoftRight': {
          if (this.config.confirm && this.config.confirm.l10nId && this.isShown) {
            this.element.dispatchEvent(new CustomEvent('confirm'));
          }
          break;
        }
        default: {
          if (!this.isGroup) {
            keyHandled = false;
          }
          break;
        }
      }

      if (keyHandled) {
        event.preventDefault();
        event.stopPropagation();
      }
    }
  };

  // This name is intentionally verbose.
  window.ConfirmDialogHelper = ConfirmDialogHelper;
}(window));
