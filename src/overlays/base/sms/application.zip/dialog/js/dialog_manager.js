/* global OptionManager, ErrorDialog, Errors, Utils, ConfirmDialogHelper, Settings,
          InputDialogHelper, ValueDefault, ActivityModule, ThreadUI, NotificationBase */

'use strict';

// eslint-disable-next-line no-unused-vars
let DialogManager = {
  init: function() {
    window.addEventListener('gaia-confirm-close', this._onDialogBeginClose.bind(this));
  },

  _onDialogBeginClose: function() {
    // Option close before dialog close.
    if (OptionManager.isOptionMenuShown()) {
      OptionManager.hideOptionMenu();
    }
  },

  isDialogShown: function() {
    return document.getElementById('gaia-confirm');
  },

  // Error dialog handle.
  showMessageError: function(errorCode, opts, isRetrieve) {
    if (this.isDialogShown()) {
      return;
    }

    // Hide all option menus before dialog show.
    if (OptionManager.contactPromptOptionMenuShown) {
      OptionManager.hideOptionMenu();
    }

    ErrorDialog.showErrorDialog(Errors.get(errorCode, isRetrieve), opts);
  },

  // One button alert dialog.
  alert: function(message, title) {
    if (this.isDialogShown()) {
      return;
    }

    const deferred = Utils.Promise.defer();
    const dialogConfig = {
      title: title || 'modal-dialog-default-title',
      body: message,
      desc: { id: '', args: {} },
      accept: {
        l10nId: 'modal-dialog-ok-button',
        priority: 2,
        callback: function() {
          deferred.resolve();
        }
      },
      backcallback: function() {
        deferred.resolve();
      },
      closecallback: function() {
        ValueDefault.activitymode ? ActivityModule.back() : 
                                    ValueDefault.isFromNotification ? 
                                    NotificationBase.back(true) : 
                                    ThreadUI.back(true);
      }
    };
    this.createDialogFrame('confirmDialog', dialogConfig);
    return deferred.promise;
  },

  // Multiple buttons confirm dialog.
  confirmAlert: function(titleId, bodyId, cancelId, cancelCallback,
                         acceptId, acceptCallback, confirmId,
                         confirmCallback, backspaceCallback, closeCallback) {
    this.waitOptionEnd(() => {
      if (this.isDialogShown()) {
        return;
      }
        
      const dialogConfig = {
        title: titleId,
        body: bodyId,
        desc: { id: '', args: {} },
        cancel: {
          l10nId: cancelId,
          priority: 1,
          callback: function() {
            if (cancelCallback) {
              cancelCallback();
            }
          }
        },
        accept: {
          l10nId: acceptId,
          priority: 2,
          callback: function() {
            if (acceptCallback) {
              acceptCallback();
            }
          }
        },
        confirm: {
          l10nId: confirmId,
          priority: 3,
          callback: function() {
            if (confirmCallback) {
              confirmCallback();
            }
          }
        },
        backcallback: function() {
          if (backspaceCallback) {
            backspaceCallback();
          }
        },
        closecallback: function() {
          if (closeCallback) {
            closeCallback();
          } else {
            ValueDefault.activitymode ? ActivityModule.back() : 
                                        ValueDefault.isFromNotification ? 
                                        NotificationBase.back(true) : 
                                        ThreadUI.back(true);
          }
        }
      };
      this.createDialogFrame('confirmDialog', dialogConfig);
    });                     
  },

  // Special dialog - limit size dialog.
  alertExceedAlert: function(length, callback) {
    if (this.isDialogShown()) {
      return;
    }

    const dialogConfig = {
      title: { id: 'attention', args: {} },
      body: {
        id: 'attached-files-too-large',
        args: {
          n: length,
          mmsSize: (Settings.mmsSizeLimitation / 1024 / 1024).toFixed(2)
        }
      },
      desc: { id: '', args: {} },
      accept: {
        l10nId: 'confirm-dialog-ok',
        priority: 2,
        callback: function() {
          if (callback) {
            callback();
          }
        },
      },
      backcallback: function() {
        if (callback) {
          callback();
        }
      },
      closecallback: function() {
        ValueDefault.activitymode ? ActivityModule.back() : 
                                    ValueDefault.isFromNotification ? 
                                    NotificationBase.back(true) : 
                                    ThreadUI.back(true);
      }
    };
    this.createDialogFrame('confirmDialog', dialogConfig);
  },

  // Special dialog - input box dialog.
  inputDialogShow: function(title, body, alertText, simInfo,
                            confirmCallback, cancelCallback,
                            backCallback) {
    const dialogConfig = {
      title: title,
      body: { 'text': body },
      alertText: alertText,
      simFlag: simInfo,
      cancel: {
        l10nId: 'cancel',
        priority: 1,
        callback: function () {
          cancelCallback && cancelCallback();
        }
      },
      confirm: {
        l10nId: 'save-number',
        priority: 3,
        callback: function (number) {
          confirmCallback && confirmCallback(number);
        }
      },
      backcallback: function() {
        backCallback && backCallback();
      },
      closecallback: function() {
        ValueDefault.activitymode ? ActivityModule.back() : 
                                    ValueDefault.isFromNotification ? 
                                    NotificationBase.back(true) : 
                                    ThreadUI.back(true);
      }
    };

    this.createDialogFrame('inputDialog', dialogConfig);
  },

  // Function dialog map.
  alertDataOffStatus: function() {
    function settingsCallback() {
      Utils.handleActivity('configure', {
        target: 'device',
        section: 'connectivity-settings'
      });
    }

    this.confirmAlert('withoutDataTitle', 'withoutDataBody', null, null,
                      'withoutDataBtnOk', null,
                      'withoutDataBtnSettings', settingsCallback, null);
  },

  alertFreeSpace: function(tag) {
    function confirmCallback() {
      Utils.handleActivity('configure-window', {
        target: 'device',
        section: 'mediaStorage'
      });
    }

    let limitBody;
    if (tag === 'send') {
      limitBody = 'data-storage-limit-send-body';
    } else if (tag === 'download') {
      limitBody = 'data-storage-limit-download-body';
    } else {
      limitBody = 'data-storage-limit-attachment-body';
    }

    this.confirmAlert('data-storage-limit-alert-title',
                      limitBody,
                      'data-storage-limit-alert-cancel',
                      null, null, null,
                      'data-storage-limit-alert-setting',
                      confirmCallback, null);
  },

  // Dialog is quicker than option, so focus need wait.
  waitOptionEnd: function(callback) {
    if (OptionManager.isOptionMenuShown()) {
      document.addEventListener('transitionend', function optionMenu() {
        document.removeEventListener('transitionend', optionMenu);
        callback();
      });
    } else {
      callback();
    }
  },

  createDialogFrame: function(tag, dialogConfig) {
    let dialog;
    if (tag === 'confirmDialog') {
      dialog = new ConfirmDialogHelper(dialogConfig);
    } else if (tag === 'inputDialog') {
      dialog = new InputDialogHelper(dialogConfig);
    }
    if (OptionManager.isOptionMenuShown()) {
      document.addEventListener('transitionend', function optionMenu() {
        document.removeEventListener('transitionend', optionMenu);
        setTimeout(() => {
          dialog.show(document.getElementById('file-large-confirmation-dialog'));
        });
      });
    } else {
      dialog.show(document.getElementById('file-large-confirmation-dialog'));
    }
  }
};
