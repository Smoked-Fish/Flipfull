/* global LazyLoader, Utils, NavigationMap, SoftkeyManager, Settings, ValueDefault */

(function(window) {
  'use strict';

  const SHOWINGTIME = 600;
  const resources = [
    'http://shared.localhost/js/utils/components/component_utils.js',
    'http://shared.localhost/elements/gaia_confirm/gaia_confirm.js'
  ];

  function InputDialogHelper(config) {
    this.config = config;
  }

  InputDialogHelper.prototype = {
    activeElement: null,
    deltaTop: 100,
    Softkey: window.option,
    isShown: false,
    inputElements: [],
    indexValue: 0,
    showSoft: false,

    show: function(parent) {
      LazyLoader.load(resources, this._show.bind(this, parent));
    },

    // Show dialog.
    _show: function(parent) {
      const config = this.config;
      const confirmClass = config.system ? 'insystem' : '';
      const wrapper = document.createElement('div');
      this.parent = parent;
      this.activeElement = document.querySelector('.focus');

      wrapper.innerHTML =
          '<gaia-confirm id="gaia-confirm" role="menuitem" tabindex="1" class=' +
          confirmClass + '>' +
          '<h1 slot="title" class="h1-dialog" style="text-align:center; height:3rem; padding-top:0.5rem;"></h1>' +
          '<div slot="content" class="div-dialog">' +
          '<p class="p-dialog"></p>' +
          '<div class="span-dialog dialog-hide"></div>' +
          '<input class="input-dialog dialog-hide" type="tel" />' +
          '<div class="span-dialog dialog-hide"></div>' +
          '<input class="input-dialog dialog-hide" type="tel" />' +
          '</div>' +
          '</gaia-confirm>';

      let element = wrapper.firstElementChild;
      this.element = element;
      element.dataset.type = config.type;
      // Event listener.
      element.addEventListener('confirm', this);
      element.addEventListener('cancel', this);
      window.addEventListener('keydown', this, true);

      const inputElements = element.querySelectorAll('input');
      const spanElements = element.querySelectorAll('.span-dialog');
      this.inputElements = [];
      this.indexValue = 0;

      for(let i = 0; i <= inputElements.length; i++) {
        this.inputElements.push(inputElements[i]);
      }
      const setL10nAttributes = function(element, options) {
        if ('string' === typeof options) {
          Utils.translateFromAtr(element, options);
        }

        if (options.id) {
          Utils.translateFromAtr(element, options.id, options.args);
        } else if (options.text) {
          element.textContent = element.value = options.text;
        }
      };

      // Check use whith SIM mode.
      let plist;
      switch(config.simFlag) {
        case 'sim1': {
          this.inputElements[0].classList.remove('dialog-hide');
          spanElements[0].classList.remove('dialog-hide');
          if (!Settings.hasSeveralSim()) {
            setL10nAttributes(spanElements[0], 'myNumber');
          } else {
            setL10nAttributes(spanElements[0], 'myNumber-SIM1');
          }
          plist = this.inputElements[0];
          break;
        }
        case 'sim2': {
          this.inputElements[1].classList.remove('dialog-hide');
          spanElements[1].classList.remove('dialog-hide');
          if (!Settings.hasSeveralSim()) {
            setL10nAttributes(spanElements[1], 'myNumber');
          } else {
            setL10nAttributes(spanElements[1], 'myNumber-SIM2');
          }
          plist = this.inputElements[1];
          break;
        }
        case 'sim1sim2': {
          this.inputElements[0].classList.remove('dialog-hide');
          spanElements[0].classList.remove('dialog-hide');
          setL10nAttributes(spanElements[0], 'myNumber-SIM1');
          this.inputElements[1].classList.remove('dialog-hide');
          spanElements[1].classList.remove('dialog-hide');
          setL10nAttributes(spanElements[1], 'myNumber-SIM2');
          plist = this.inputElements[0];
          break;
        }
        default:
          break;
      }

      this.inputElements[0].addEventListener('input', this);
      this.inputElements[1].addEventListener('input', this);

      const title = element.querySelector('h1');
      const body = plist;
      const alertContent = element.querySelector('p');

      setL10nAttributes(title, config.title);
      setL10nAttributes(alertContent, config.alertText);
      if (!config.alertText) {
        alertContent.classList.add('alert-body');
      }

      if (NavigationMap && NavigationMap.currentActivatedLength > -1) {
        if (NavigationMap.currentActivatedLength === 0) {
          NavigationMap.currentActivatedLength = 1;
        } else {
          setTimeout(() => {
            this.show(parent);
          }, SHOWINGTIME);
          return;
        }
      }
      element.setAttribute('hidden', '');
      parent.appendChild(element);
      this.activeElement.blur();
      this.activeElement.classList.remove('focus');

      element.removeAttribute('hidden');
      this.isShown = true;
      window.dispatchEvent(new CustomEvent('gaia-confirm-open'));

      this.updateSoftKeyPanel(config);

      element.focus();
      plist.focus();
      setL10nAttributes(body, config.body);
    },

    updateSoftKeyPanel: function(config) {
      if (config.body) {
        this.showSoft = config.body.text.length;
      }
      // Init softkey.
      let softkeyParams = [];
      if (config.cancel) {
        softkeyParams.push({
          name: '',
          priority: 1,
          l10nId: config.cancel.l10nId,
          method: function() {
          }
        });
      }
      if (config.confirm && this.showSoft) {
        softkeyParams.push({
          name: '',
          priority: 3,
          l10nId: config.confirm.l10nId,
          method: function() {
          }
        });
      }
      SoftkeyManager.show(softkeyParams);
    },

    // Hide dialog.
    destroy: function() {
      if (!this.element) {
        return;
      }

      if (NavigationMap && NavigationMap.currentActivatedLength > -1) {
        NavigationMap.currentActivatedLength = 0;
      }

      this.activeElement.focus();
      this.activeElement.classList.add('focus');
      //SoftkeyManager.updateSettingsSks();
      !ValueDefault.isFromNotification && SoftkeyManager.updateSettingsSks();
      // Ensure cleanup of our hacks!
      window.removeEventListener('keydown', this);
      this.inputElements[0].removeEventListener('input', this);
      this.inputElements[1].removeEventListener('input', this);
      this.element.setAttribute('hidden', '');
      this.element.parentNode.removeChild(this.element);
      this.element = null;
      this.isShown = false;
      window.dispatchEvent(new CustomEvent('gaia-confirm-close'));
    },

    handleEvent: function(event) {
      if (!this.isShown) {
        return;
      }

      switch (event.type) {
        case 'confirm': {
          this.destroy();
          let inputNumber;
          if (this.config.simFlag === 'sim1') {
            inputNumber = this.inputElements[0].value;
          }
          if (this.config.simFlag === 'sim2') {
            inputNumber = this.inputElements[1].value;
          }
          if (this.config.simFlag === 'sim1sim2') {
            inputNumber = [this.inputElements[0].value,
                           this.inputElements[1].value];
          }
          const confirm = this.config.confirm.callback;
          confirm && confirm(inputNumber);
          break;
        }
        case 'cancel': {
          this.destroy();
          const cancel = this.config.cancel.callback;
          cancel && cancel();
          break;
        }
        case 'input': {
          if (this.config.simFlag === 'sim1') {
            this.showSoft = this.inputElements[0].value.length;
          }
          if (this.config.simFlag === 'sim2') {
            this.showSoft = this.inputElements[1].value.length;
          }
          if (this.config.simFlag === 'sim1sim2') {
            this.showSoft = this.inputElements[0].value.length &&
                            this.inputElements[1].value.length;
          }
          if (this.showSoft) {
            this.updateSoftKeyPanel({
              cancel: {
                l10nId: this.config.cancel ? this.config.cancel.l10nId : ''
              },
              confirm: {
                l10nId: this.config.confirm ? this.config.confirm.l10nId : ''
              }
            });
          } else {
            this.updateSoftKeyPanel({
              cancel: {
                l10nId: this.config.cancel ? this.config.cancel.l10nId : ''
              }
            });
          }
          break;
        }
        default:
          break;
      }

      let keyHandled = true;
      switch (event.key) {
        case 'Backspace': {
          this.destroy();
          const back = this.config.backcallback;
          back && back();
          break;
        }
        case 'EndCall': {
          this.destroy();
          const close = this.config.closecallback;
          close && close();
          break;
        }
        case 'ArrowUp':
        case 'ArrowDown': {
          if (!this.inputElements[0].classList.contains('dialog-hide') &&
              !this.inputElements[1].classList.contains('dialog-hide')) {
            this.inputElements[this.indexValue].blur();
            this.indexValue = 1 - this.indexValue;
            this.inputElements[this.indexValue].focus();
          }
          break;
        }
        case 'SoftLeft': {
          if (this.config.cancel && this.isShown) {
            this.element.dispatchEvent(new CustomEvent('cancel'));
          }
          break;
        }
        case 'SoftRight': {
          if (this.config.confirm && this.isShown && this.showSoft) {
            this.element.dispatchEvent(new CustomEvent('confirm'));
          }
          break;
        }
        default: {
          keyHandled = false;
          break;
        }
      }

      if (keyHandled) {
        event.preventDefault();
        event.stopPropagation();
      }
    }
  };

  // This name is intentionally verbose.
  window.InputDialogHelper = InputDialogHelper;
}(window));
