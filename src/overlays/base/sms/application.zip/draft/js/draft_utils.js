/* global Drafts, Threads, ThreadUI, Compose, SubjectUtils, AttachmentManager,
          RecipientManager, StateManager, Utils, MessageManager, Draft, Settings,
          ThreadListUI, NavigationMap, OptionManager, DialogManager, ValueDefault,
          SwitchHandler */

'use strict';

// eslint-disable-next-line no-unused-vars
const DraftUtils = {
  draft: null,
  activityDraft: null,

  // Request get draft info.
  draftRequest: function(threadId) {
    return new Promise((resolver) => {
      Drafts.request(true).then(() => {
        const thread = Threads.get(threadId);
        if (thread.hasDrafts) {
          // TODO Maybe need judge the activity mode.
          ThreadUI.isFirstEnterThreadUI = true;
          this.draft = thread.drafts.latest;
          Compose.fromDraft(this.draft);
          document.activeElement.blur();
          if (!SwitchHandler.isSwitchCase) {
            NavigationMap.setFocusToFixedElement('messages-input');
          }
          this.draft.isEdited = false;
        } else {
          this.draft = null;
        }
        resolver();
      });
    });
  },

  // Save draft function map.
  backUpDraftData: function() {
    let content, recipients, subject, attachment, threadId, type;
    content = Compose.getContent(true);
    subject = SubjectUtils.getSubject();
    attachment = AttachmentManager.getAttachment();
    type = Compose.type;

    if (Threads.active) {
      recipients = Threads.active.participants;
      threadId = Threads.currentId;
    } else {
      recipients = RecipientManager.recipients.numbers;
    }

    if (Threads.keyword) {
      Threads.currentId = null;
      Threads.keyword = null;
    }

    const draftId = this.draft ? this.draft.id : null;

    return {
      content: content,
      recipients: recipients,
      subject: subject,
      attachment: attachment,
      threadId: threadId,
      type: type,
      draftId: draftId
    };
  },

  saveDraft: function(opts, callback) {
    const backData = this.backUpDraftData();

    if (callback) {
      if (!opts || (opts && opts.keyFlag !== 'saveDraft')) {
        callback();
      }
    }
    if (StateManager.isDiskFull) {
      if (opts && !opts.autoSave) {
        Utils.showLowSpaceAlert();
      }
    } else {
      this.realSaveDraft(opts, backData, callback);
    }
  },

  realSaveDraft: function(opts, backData, callback) {
    let content, draft, recipients, subject, attachment, thread, threadId, type, draftId;
    content = backData.content;
    recipients = backData.recipients;
    subject = backData.subject;
    attachment = backData.attachment;
    threadId = backData.threadId;
    type = backData.type;
    draftId = backData.draftId;

    MessageManager.findThreadFromNumber(recipients).then((Id) => {
      return new Promise((resolve) => {
        resolve(Id);
      });
    }, () => {
      return new Promise((resolve) => {
        resolve(null);
      });
    }).then((messageThreadId) => {
      if (!threadId) {
        threadId = messageThreadId;
      }

      draft = new Draft({
        recipients: recipients,
        content: content,
        subject: subject,
        threadId: threadId,
        type: type,
        attachment: attachment,
        id: draftId,
        isGroup: Settings.isGroup
      });

      if (threadId) {
        this.discardDraft(true);
      }

      Drafts.add(draft);

      if (ValueDefault.activitymode) {
        this.onDraftSaved();
        callback && callback(draft);
        return;
      }

      if (threadId) {
        thread = Threads.get(threadId) || Threads.active;
        ThreadListUI.updateThread(thread, {timestamp: draft.timestamp});
      } else {
        ThreadListUI.updateThread(draft);
      }

      if (!document.hidden && !(opts && opts.keyFlag === 'saveDraft')) {
        const backId = threadId || draft.id;
        NavigationMap.updateCurIndex('thread-list', 'thread-' + backId);
      }

      if (!opts || (opts && !opts.preserve)) {
        this.draft = null;
      }

      if (!this.draft && (opts && opts.preserve)) {
        this.draft = draft;
      }

      if (!opts || (opts && !opts.autoSave)) {
        this.onDraftSaved();
      }

      Settings.isGroup = false;
      if (opts && opts.keyFlag === 'saveDraft') {
        callback && callback(draft);
      }
    });
  },

  saveActivityDraft: function(callback) {
    const backData = this.backUpDraftData();
    MessageManager.findThreadFromNumber(backData.recipients).then((Id) => {
      return new Promise((resolve) => {
        resolve(Id);
      });
    }, () => {
      return new Promise((resolve) => {
        resolve(null);
      });
    }).then((messageThreadId) => {
      if (!backData.threadId) {
        backData.threadId = messageThreadId;
      }

      const draft = new Draft({
        recipients: backData.recipients,
        content: backData.content,
        subject: backData.subject,
        threadId: backData.threadId,
        type: backData.type,
        attachment: backData.attachment,
        id: backData.draftId,
        isGroup: Settings.isGroup
      });

      Drafts.add(draft);
      this.activityDraft = draft;
      callback();
    });
  },

  // Remove draft function map.
  discardDraft: function(update) {
    if (this.draft) {
      Drafts.delete(this.draft).store();
      if (Threads.active) {
        ThreadListUI.updateThread(Threads.active);
      } else {
        ThreadListUI.removeThread(this.draft.id);
      }
      this.draft = null;
    }
    if ((!Compose.isEmpty() || (RecipientManager.recipients && 
         RecipientManager.recipients.length)) && !update) {
      this.onDraftDiscarded();
    }
    if (Threads.keyword) {
      Threads.keyword = null;
    }
  },

  discardActivityDraft: function() {
    if (this.activityDraft) {
      Drafts.delete(this.activityDraft).store();
    }
    this.activityDraft = null;
  },

  // Draft hanlde module.
  onDraftSaved: function() {
    Utils.showToaster({ messageL10nId: 'message-draft-saved' });
  },

  onDraftDiscarded: function() {
    Utils.showToaster({ messageL10nId: 'draft-discard-content' });
  },

  // Draft back function map.
  _onNavigatingBack: function(close) {
    return Promise.resolve().then(() => {
      RecipientManager.assimilateRecipients('true');
      if (Threads.active) {
        Threads.active.unreadCount = 0;
      }
      if (Compose.isEmpty()) {
        this.discardDraft(true);
        const node = document.querySelector('#messages-recipients-list').lastChild;
        node.textContent = '';
        if (node.classList && node.classList.contains('focus')) {
          node.classList.remove('focus');
        }
        return;
      }

      if (this.draft && !this.draft.isEdited) {
        if (!Threads.currentId) {
          this.saveDraft({ autoSave: true });
        } else {
          this.draft = null;
        }
        return;
      }

      return this.showMessageSaveOrDiscardPrompt(close);
    });
  },

  showMessageSaveOrDiscardPrompt: function(close) {
    if (OptionManager.isOptionMenuShown() && close) {
      OptionManager.hideOptionMenu();
    }

    return new Promise((resolve, reject) => {
      function cancelCallback() {
        reject();
      }
      function acceptCallback() {
        DraftUtils.saveDraft({ keyFlag: 'saveDraft', keyPress: 'back' }, (draft) => {
          resolve(draft);
        });
      }
      function confirmCallback() {
        RecipientManager.assimilateRecipients('false');
        DraftUtils.discardDraft();
        resolve();
      }
      function closeCallback() {
        resolve();
      }
      DialogManager.confirmAlert('confirmation-title', 'draft-save-content', 'cancel',
                                 cancelCallback, 'save-as-draft', acceptCallback,
                                 'discard-message', confirmCallback, cancelCallback, closeCallback);
    });
  }
};
