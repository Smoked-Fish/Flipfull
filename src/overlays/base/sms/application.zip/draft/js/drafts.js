/* global asyncStorage, Utils, Drafts */

(function(exports) {
  'use strict';

  exports.Drafts = {
    List: DraftList,
    draftIndex: new Map(),
    deferredDraftRequest: null,
    
    get size() {
      return this.draftIndex.size;
    },
    
    // DB action map.
    add: function(draft) {
      let threadId;
      let thread;
      let stored;

      if (draft) {
        if (!(draft instanceof Draft)) {
          draft = new Draft(draft);
        }

        threadId = draft.threadId || null;
        thread = this.draftIndex.get(threadId) || [];
        stored = thread[thread.length - 1];

        if (threadId !== null && thread.length) {
          this.delete(stored);
        }

        if (threadId === null && thread.length) {
          thread.some((d) => {
            if (d.id === draft.id) {
              this.delete(d);
              stored = null;
              return true;
            }
          });
        }

        thread.push(draft);
        this.draftIndex.set(threadId, thread);
        this.store();
      }
      return this;
    },

    delete: function(draft) {
      let thread;
      let index;

      if (draft) {
        thread = this.draftIndex.get(draft.threadId);
        if (!thread) {
          return this;
        }
        index = thread.indexOf(draft);

        if (index === -1) {
          if (thread && typeof draft.id === 'undefined') {
            thread.length = 0;
          } else {
            if (thread) {
              thread.some((stored, i) => {
                if (stored.id === draft.id) {
                  index = i;
                  return true;
                }
              });
            }
          }
        }

        if (index > -1) {
          thread.splice(index, 1);
        }
      }
      return this;
    },

    clear: function() {
      this.draftIndex = new Map();
      this.deferredDraftRequest = null;
      return this;
    },

    store: function() {
      const entries = [];
      this.draftIndex.forEach((v, k) => {
        entries.push([k, v]);
      });
      asyncStorage.setItem('draft index', entries, () => {
        window.dispatchEvent(new CustomEvent('drafts-changed'));
      });
    },

    request: function(force) {
      if (this.deferredDraftRequest && !force) {
        return this.deferredDraftRequest.promise;
      }

      this.deferredDraftRequest = Utils.Promise.defer();

      asyncStorage.getItem('draft index', (records) => {
        records && records.forEach((record) => {
          record[1] = record[1].map((draft) => new Draft(draft));
        });
        this.draftIndex = new Map(records || []);
        this.deferredDraftRequest.resolve(Drafts.byThreadId(null));
      });

      return this.deferredDraftRequest.promise;
    },

    byThreadId: function(id) {
      return new Drafts.List(Drafts.draftIndex.get(id));
    },

    get: function(id) {
      let draft;

      this.draftIndex.forEach((records) => {
        if (!draft) {
          draft = records.find((record) => {
            return record.threadId === +id || record.id === +id;
          });
        }
      });

      return draft;
    },

    forEach: function(callback, thisArg) {
      if (thisArg) {
        callback = callback.bind(thisArg);
      }
      this.draftIndex.forEach((drafts, threadId) => {
        if (threadId) {
          const latest = drafts[drafts.length - 1];
          callback(latest, threadId);
        } else {
          drafts.forEach((draft) => {
            callback(draft, null);
          });
        }
      });
    }
  };

  const priv = new WeakMap();
  function DraftList(initializer) {
    priv.set(this, initializer || []);
  }

  // Draft map action map.
  DraftList.prototype = {
    get length() {
      return priv.get(this).length;
    },

    get latest() {
      const list = priv.get(this);
      return list.length ? list[list.length - 1] : null;
    },

    forEach: function(callback, thisArg) {
      const drafts = priv.get(this);

      if (thisArg) {
        callback = callback.bind(thisArg);
      }

      for (let i = 0; i < drafts.length; i++) {
        callback(drafts[i]);
      }
    }
  };

  // Draft object.
  function Draft(opts) {
    const draft = opts || {};

    if (draft.id && typeof draft.id !== 'number') {
      throw new Error('Draft id must be a number');
    }

    this.id = draft.id || guid();
    this.recipients = draft.recipients || [];
    this.content = draft.content || [];
    this.subject = draft.subject || '';
    this.timestamp = +draft.timestamp || Date.now();
    this.threadId = draft.threadId || null;
    this.type = draft.type;
    this.attachment = draft.attachment || [];
    this.isEdited = false;
    this.isGroup = draft.isGroup || false;
  }

  function guid() {
    return +(Date.now() + '' + (Math.random() * 1000 | 0));
  }

  exports.Draft = Draft;
}(this));
