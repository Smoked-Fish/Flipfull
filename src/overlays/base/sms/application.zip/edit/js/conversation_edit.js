/* global Utils, OptionManager, NavigationMap, ThreadUI, LazyLoader, SelectionHandler,
          SoftkeyManager */

'use strict';

let ConversationEdit = {
  selectionHandler: null,
  inEditMode: false,

  // Init base element.
  init: function() {
    ['container', 'edit-mode'].forEach((id) => {
      this[Utils.camelCase(id)] = document.getElementById('messages-' + id);
    });
    this.mainWrapper = document.getElementById('main-wrapper');
  },

  // Edit mode start function.
  selectMessages: function() {
    function startEditMode() {
      if (!OptionManager.isOptionMenuShown()) {
        document.removeEventListener('transitionend', startEditMode);
      }
      const items =
        document.querySelectorAll('#messages-container li.navigable');
      NavigationMap.setFocusToFixedElement(items[items.length - 1].id);
    }

    function updateSoftkey() {
      window.removeEventListener('messages-render-complete', updateSoftkey);
      ConversationEdit.updateSKs();
    }

    this.startEdit();
    NavigationMap.reset('messages-container');
    if (ThreadUI._renderingMessage) {
      window.addEventListener('messages-render-complete', updateSoftkey);
    }

    document.addEventListener('transitionend', startEditMode);
  },

  startEdit: function() {
    if (!this.selectionHandler) {
      LazyLoader.load('edit/js/selection_handler.js', () => {
        this.selectionHandler = new SelectionHandler({
          container: this.container,
          checkInputs: this.checkInputs.bind(this),
          getAllInputs: this.getAllInputs.bind(this),
          isInEditMode: this.isInEditMode.bind(this),
          updateSKs: this.updateSKs.bind(this)
        });
        this.editModeSetup();
      });
    } else {
      this.editModeSetup();
    }
  },

  checkInputs: function() {
    const selected = this.selectionHandler.selectedCount;
    const isAnySelected = selected > 0;

    if (isAnySelected) {
      Utils.translateFromAtr(this.editMode, 'selected-messages',
                             {n: selected});
    } else {
      Utils.translateFromAtr(this.editMode, 'deleteMessages-title');
    }
  },

  getAllInputs: function() {
    if (this.container) {
      return Array.prototype.slice.call(
        this.container.querySelectorAll('input[type=checkbox]')
      );
    } else {
      return [];
    }
  },

  allActionHandle: function() {
    this.selectionHandler.toggleCheckedAll();
  },

  isInEditMode: function() {
    return this.inEditMode;
  },

  // Exit edit mode.
  cancelEdit: function() {
    if (this.inEditMode) {
      this.inEditMode = false;
      this.mainWrapper.classList.remove('edit');
      const items =
        document.querySelectorAll('#messages-container li.navigable');
      if (items.length > 0) {
        items[items.length - 1].scrollIntoView(true);
      }
    }
  },
  
  editModeSetup: function() {
    this.inEditMode = true;
    this.selectionHandler.cleanForm();
    this.mainWrapper.classList.toggle('edit');
  },

  // Handler softkey changed.
  updateSKs: function() {
    const selected = this.selectionHandler.selectedCount;
    let skparam = null;

    if (selected === this.getAllInputs().length) {
      if (ThreadUI._renderingMessage) {
        skparam = [SoftkeyManager.skWaitFormThread, SoftkeyManager.skDeSelect, 
                   SoftkeyManager.skSelectDelete];
      } else {
        skparam = [SoftkeyManager.skDeselectAllFromThread, SoftkeyManager.skDeSelect, 
                   SoftkeyManager.skSelectDelete];
      }
    } else if (selected > 0) {
      if (document.activeElement.querySelectorAll('.thread-checked').length !== 0 ||
          document.activeElement.classList.contains('thread-checked')) {
        if (ThreadUI._renderingMessage) {
          skparam = [SoftkeyManager.skWaitFormThread, SoftkeyManager.skDeSelect, 
                     SoftkeyManager.skSelectDelete];
        } else {
          skparam = [SoftkeyManager.skSelectAllFormThread, SoftkeyManager.skDeSelect, 
                     SoftkeyManager.skSelectDelete];
        }
      } else {
        if (ThreadUI._renderingMessage) {
          skparam = [SoftkeyManager.skWaitFormThread, SoftkeyManager.skSelect, 
                     SoftkeyManager.skSelectDelete];
        } else {
          skparam = [SoftkeyManager.skSelectAllFormThread, SoftkeyManager.skSelect, 
                     SoftkeyManager.skSelectDelete];
        }
      }
    } else {
      if (ThreadUI._renderingMessage) {
        skparam = [SoftkeyManager.skWaitFormThread, SoftkeyManager.skSelect];
      } else {
        skparam = [SoftkeyManager.skSelectAllFormThread, SoftkeyManager.skSelect];
      }
    }

    SoftkeyManager.show(skparam);
  }
};
