/* global Utils, LazyLoader, SelectionHandler, SoftkeyManager */

'use strict';

// eslint-disable-next-line no-unused-vars
let InboxEdit = {
  selectionHandler: null,
  inEditMode: false,

  // Init base element.
  init: function() {
    const elementArray = ['edit-mode'];
    elementArray.forEach((id) => {
      this[Utils.camelCase(id)] = document.getElementById('threads-' + id);
    });
    this.mainWrapper = document.getElementById('main-wrapper');
    this.container = document.getElementById('normal-list').querySelector('#threads-container');
  },

  // Edit mode start function.
  startEdit: function() {
    if (!this.selectionHandler) {
      LazyLoader.load('edit/js/selection_handler.js', () => {
        this.selectionHandler = new SelectionHandler({
          container: this.container,
          checkInputs: this.checkInputs.bind(this),
          getAllInputs: this.getAllInputs.bind(this),
          isInEditMode: this.isInEditMode.bind(this),
          updateSKs: this.updateSKs.bind(this)
        });
        this.editModeSetup();
      });
    } else {
      this.editModeSetup();
    }
  },

  checkInputs: function() {
    const selected = this.selectionHandler.selectedCount;

    if (selected) {
      Utils.translateFromAtr(this.editMode, 'selected-threads', { n: selected });
    } else {
      Utils.translateFromAtr(this.editMode, 'selected-threads', { n: 0 });
    }
  },

  getAllInputs: function() {
    if (this.container) {
      return Array.prototype.slice.call(
        this.container.querySelectorAll('input[type=checkbox]')
      );
    } else {
      return [];
    }
  },

  isInEditMode: function() {
    return this.inEditMode;
  },

  allActionHandle: function() {
    this.selectionHandler.toggleCheckedAll();
  },

  addElementFromSelectList: function(id) {
    this.selectionHandler.unselect(id);
    this.checkInputs();
  },

  // Exit edit mode.
  cancelEdit: function() {
    this.inEditMode = false;
    this.mainWrapper.classList.remove('edit');
  },

  editModeSetup: function() {
    this.inEditMode = true;
    this.selectionHandler.cleanForm();
    this.mainWrapper.classList.toggle('edit');
  },

  // Handler softkey changed.
  updateSKs: function() {
    const selected = this.selectionHandler.selectedCount;
    if (selected === this.getAllInputs().length) {
      SoftkeyManager.show([SoftkeyManager.skDeselectAll, SoftkeyManager.skDeSelect, 
                           SoftkeyManager.skDelete]);
    } else if (selected > 0) {
      if (document.activeElement.querySelectorAll('.thread-checked').length !== 0 ||
          document.activeElement.classList.contains('thread-checked')) {
        SoftkeyManager.show([SoftkeyManager.skSelectAll, SoftkeyManager.skDeSelect, 
                             SoftkeyManager.skDelete]);
      } else {
        SoftkeyManager.show([SoftkeyManager.skSelectAll, SoftkeyManager.skSelect, 
                             SoftkeyManager.skDelete]);
      }
    } else {
      SoftkeyManager.show([SoftkeyManager.skSelectAll, SoftkeyManager.skSelect]);
    }
  }
};
