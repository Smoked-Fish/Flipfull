(function(exports) {
  'use strict';

  const REQUIRED_KEYS = [
    // elements
    'container',
    // methods
    'checkInputs',
    'getAllInputs',
    'isInEditMode',
    'updateSKs'
  ];

  let SelectionHandler = function(options) {
    if (typeof options !== 'object') {
      throw new Error('options should be a valid object');
    }

    REQUIRED_KEYS.forEach((key) => {
      if (options[key] === undefined) {
        throw new Error('Selection options does not provide required key ' + key);
      }

      this[key] = options[key];
    });

    this.selected = new Set();

    this.container.addEventListener('click', this.onSelected.bind(this));
  };

  SelectionHandler.prototype = {
    get selectedCount() {
      return this.selected.size;
    },

    get selectedList() {
      return Array.from(this.selected);
    },

    onSelected: function(event) {
      if (!this.isInEditMode()) {
        return;
      }

      const target = event.target;
      const value = target.value;
      const existed = this.selected.has(value);

      if (target.checked && !existed) {
        this.selected.add(value);
        target.classList.add('thread-checked');
      } else if (!target.checked && existed) {
        this.selected.delete(value);
        target.classList.remove('thread-checked');
      } else {
        // Don't emit event if no selection change
        return;
      }

      this.checkInputs();
      this.updateSKs();
    },

    select: function(id) {
      this.selected.add('' + id);
    },

    unselect: function(id) {
      this.selected.delete('' + id);
    },

    // Update check status of input elements in the container.
    updateCheckboxes: function() {
      const inputs = this.container.querySelectorAll('input[type=checkbox]');
      const length = inputs.length;

      for (let i = 0; i < length; i++) {
        inputs[i].checked = this.selected.has(inputs[i].value);
        if (inputs[i].checked) {
          inputs[i].classList.add('thread-checked');
        } else {
          inputs[i].classList.remove('thread-checked');
        }
      }
    },

    // If no message or few are checked : select all the messages
    // and if all messages are checked : deselect them all.
    toggleCheckedAll: function() {
      const selected = this.selected.size;
      const allInputs = this.getAllInputs();
      const allSelected = (selected === allInputs.length);

      if (allSelected) {
        this.selected.clear();
      } else {
        Array.prototype.forEach.call(allInputs, (data) => {
          this.selected.add(data.value);
        });
      }

      this.updateCheckboxes();
      this.checkInputs();
      this.updateSKs();
    },

    cleanForm: function() {
      // Reset all inputs.
      this.selected.clear();

      this.updateCheckboxes();

      // Reset for deleting methods.
      this.checkInputs();
      this.updateSKs();
    }
  };

  exports.SelectionHandler = SelectionHandler;
}(this));
