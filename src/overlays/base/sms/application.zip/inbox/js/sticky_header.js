// eslint-disable-next-line no-unused-vars
function StickyHeader(scrollable, sticky) {
  'use strict';

  const headers = scrollable.getElementsByTagName('header');
  const stickyStyle = sticky.style;
  let stickyPosition;

  this._throttledRefresh = () => {
    let display = false;
    if (stickyPosition === undefined) {
      stickyPosition = sticky.offsetHeight + sticky.offsetTop;
    }
    for (let i = 1, length = headers.length; i <= length; i++) {
      if (!headers[i]) {
        continue;
      }
      const visableHeight = headers[i].offsetTop - scrollable.scrollTop;
      if (i === length || 
          (visableHeight > (scrollable.stickyHiddenGap || stickyPosition))) {
        // While reflecting a header, make sure to not reflect a header
        // that is not displayed.
        let lookupIndex = 1;
        let header = headers[i - lookupIndex];
        while (header && header.offsetHeight === 0) {
          lookupIndex++;
          header = headers[i - lookupIndex];
        }
        if (header) {
          stickyStyle.backgroundImage = '-moz-element(#' + header.id + ')';
          display = true;
        }
        break;
      } else if (headers[i].offsetTop - scrollable.scrollTop > 0) {
        break;
      }
    }

    sticky.classList.toggle('has-content', display);
    this.throttle = null;
  };

  this.refresh = () => {
    if (!this.throttle) {
      this.throttle = setTimeout(this._throttledRefresh, 0);
    }
  };

  scrollable.addEventListener('scroll', this.refresh);
}
