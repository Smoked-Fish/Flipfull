/* global Utils, StateManager, SoftkeyManager, Template, ContactsServiceManager, Drafts,
          MessageManager, InboxEdit, StickyHeader, FocusManager, Navigation,
          MessageCache, Threads, Thread, TimeUtils, Startup, TimeHeaders,
          ValueDefault, Settings, PerformanceTestingHelper, ThreadUI,
          NotiificationManager, DeleteManager, NavigationMap, OptionManager,
          ActivityHandler */

(function(exports) {
  'use strict';

  const privateMembers = new WeakMap();

  let ThreadListUI = {
    // Promise defer.
    readyDeferred: Utils.Promise.defer(),
    // Sent flag.
    messagesSent: false,
    // Draft save link.
    draftLinks: null,
    // Draft register info.
    draftRegistry: null,
    // Default thread count.
    threadCount: 0,

    // Init module.
    init: function() {
      // Init element.
      this.tmpl = {
        thread: Template('messages-thread-tmpl')
      };

      this.draftLinks = new Map();
      this.draftRegistry = {};
      this.sticky = null;

      this.initElement();
      StateManager.addDiskListener();
      SoftkeyManager.initSks();

      privateMembers.set(this, {
        groupThreadTitleMaxLength: (window.innerWidth - 100) / 10,
        threadSwitchId: 1
      });

      // Interface listener.
      ContactsServiceManager.AddContactChangeListener();
      window.addEventListener('drafts-changed', this.renderDrafts.bind(this, true));
      // Update the list sks after option menu shown.
      document.addEventListener('transitionend', SoftkeyManager.updateSKs.bind(SoftkeyManager));

      // Init draft update value.
      Utils.setSettingsValue([{ name: 'draft.update', value: 'false' }]);

      // Settings listener.
      Utils.observerSettingsValue('time.timezone', this.timeZoneHandle.bind(this));
      Utils.observerSettingsValue('draft.update', (value) => {
        if (value === 'true') {
          this.renderDrafts(true);
        }
      });

      // Time limit for launch app situation.
      this.timeLimitHandle();

      // Protocol listenter.
      MessageManager.on('message-sending', this._onMessageSending.bind(this));
      MessageManager.on('message-received', this._onMessageReceived.bind(this));
      MessageManager.on('threads-deleted', this._onThreadsDeleted.bind(this));
      MessageManager.on('message-list-sent', this._onShowTost.bind(this));

      // Other module init.
      InboxEdit.init();
    },

    // Init base element.
    initElement: function() {
      const elementArray = ['no-messages'];
      elementArray.forEach((id) => {
        this[Utils.camelCase(id)] = document.getElementById('threads-' + id);
      });

      this.container = document.getElementById('normal-list').querySelector('#threads-container');
      this.noResultMessage = document.getElementById('no-result-message');
    },

    initStickyHeader: function() {
      if (!this.sticky) {
        this.sticky =
          new StickyHeader(this.container, document.getElementById('sticky'));
      }
    },

    // Handle the route event.
    afterEnter: function() {
      if (this.noMessages && !this.noMessages.classList.contains('hide')) {
        FocusManager.focusNoMessage();
      }
      if (ValueDefault.draftSaveId) {
        if (OptionManager.isOptionMenuShown()) {
          // Need wait for option animation end.
          document.addEventListener('transitionend', function optionMenu() {
            document.removeEventListener('transitionend', optionMenu);
            NavigationMap.resetListFocus();
          });
        } else {
          NavigationMap.resetListFocus();
        }
      }
    },

    beforeLeave: function thlui_beforeLeave() {
      InboxEdit.cancelEdit();
    },

    // Normal action function.
    timeZoneHandle: function() {
      const threads = this.container.getElementsByTagName('li');
      [].forEach.call(threads, (thread) => {
        let threadObject = {
          'id': thread.dataset.threadId,
          'timestamp': thread.dataset.time
        };
        const timeZoneWait = 50;
        setTimeout(() => {
          this.updateContainerId(threadObject);
        }, timeZoneWait);
      });
    },

    updateContainerId: function(thread) {
      let timestamp = +thread.timestamp;
      const drafts = Drafts.byThreadId(thread.id);
      if (drafts.length) {
        timestamp = Math.max(drafts.latest.timestamp, timestamp);
      }
      const threadNode = document.getElementById('thread-' + thread.id);
      const dayDate = TimeUtils.getDayDate(timestamp);
      if (threadNode) {
        threadNode.parentNode.id = 'threadsContainer_' + dayDate;
      }
    },

    timeLimitHandle: function() {
      Utils.getSettingsValue('sms.draft.save.time').then((result) => {
        // No save activity draft, the time is null.
        if (!result) {
          return;
        }
        // Reset activity draft save time.
        Utils.setSettingsValue([{
          name: 'sms.draft.save.time',
          value: null
        }]);
        // Count time diff.
        const saveTime = +result;
        const currentTime = Date.now();
        const timeDiff = currentTime - saveTime;
        const TIMELIMIT = 24 * 60 * 60 * 1000;
        if (timeDiff < TIMELIMIT) {
          Utils.showToaster({ messageL10nId: 'save-within-time' });
        }
      });
    },

    privateMembersGet: function() {
      return privateMembers.get(this).groupThreadTitleMaxLength;
    },

    privateMembersSwitch: function() {
      return privateMembers.get(this).threadSwitchId;
    },

    privateMembersSet: function() {
      privateMembers.set(this,
        { groupThreadTitleMaxLength: (window.innerWidth - 100) / 10 });
    },

    setEmpty: function(empty) {
      const addWhenEmpty = empty ? 'add' : 'remove';
      const removeWhenEmpty = empty ? 'remove' : 'add';

      this.noMessages.classList[removeWhenEmpty]('hide');
      this.container.classList[addWhenEmpty]('hide');

      if (empty && Navigation.isCurrentPanel('thread-list')) {
        FocusManager.focusNoMessage();
      }
    },

    mark: function(id, current) {
      const li = document.getElementById('thread-' + id);
      let remove = 'read';

      if (current === 'read') {
        remove = 'unread';
      }

      if (li) {
        li.classList.remove(remove);
        li.classList.add(current);
      }
    },
    //Porting from PR-11492884-[ATT:CDR-MSG-1160]-renlongou on 2024/09/07-begin
    markAllMessageAsRead: function () {
      const iterable = navigator.b2g.mobileMessageManager.getThreads().values();
      circleMap();
      function circleMap() {
        iterable.next().then((result) => {
          if (!result.done) {
            dump("result.value" + result.value + "result.value.unreadCount" + result.value.unreadCount);
            if (result.value.unreadCount > 0){
              ThreadListUI.mark(result.value.id, 'read');
              MessageManager.markThreadRead(result.value.id);
              NotiificationManager.closeNotificationsForThread(result.value.id);
            }
            circleMap();
          } else {
            dump("thread iterable end");
          }
        });
      }
    },
    //Porting from PR-11492884-[ATT:CDR-MSG-1160]-renlongou on 2024/09/07-end



    refreshUnreadState: function() {
      function onRenderThread(thread) {
        const threadElement = document.getElementById('thread-' + thread.id);
        if (threadElement && thread.unreadCount === 0) {
          this.mark(thread.id, 'read');
        }
      }

      MessageManager.getThreads({
        each: onRenderThread.bind(this)
      });
    },

    whenReady: function() {
      return this.readyDeferred.promise;
    },

    // Cache operator module.
    cacheAction: function() {
      // Delete cache when we save the new cache.
      MessageCache.clear('threads-container');
      // We do not need cache the no message page.
      // Can not save cache when the FTU is enabled,
      // the page will not be prepared at this situation.
      if (this.noMessages.classList.contains('hide')) {
        this.saveCache();
      }
    },

    saveCache: function() {
      let cacheHtml = document.getElementById('threads-container');
      let codeNode = MessageCache
        .cloneAsInertNodeAvoidingCustomElementHorrors(cacheHtml);
      MessageCache.saveFromNode('threads-container', codeNode);
    },

    showRealCache: function() {
      ContactsServiceManager.contactRenderComplete = false;
      setTimeout(() => {
        document.getElementById('cache-list').classList.add('hide');
        document.getElementById('normal-list').classList.remove('hide');
        document.getElementById('cache-list').innerHTML = '';

        if (Navigation.isCurrentPanel('thread-list')) {
          NavigationMap.reset('thread-list');
          NavigationMap.setFocus('first');
          FocusManager.setListFocusElement();
          this.cacheAction();
        }
      });
    },

    // Thread action function.
    prepareRendering: function() {
      if (!ActivityHandler.lastMessage) {
        const draftPages = document.querySelectorAll('.is-draft');
        draftPages.forEach((draftElement) => {
          draftElement.classList.remove('hide');
        });
        NavigationMap.reset('thread-list');
      }
      this.container.innerHTML = '';
      this.renderDrafts();
    },

    startRendering: function() {
      this.setEmpty(false);
    },

    finalizeRendering: function(empty) {
      if (empty || Startup.firstDraftCheck) {
        Startup.firstDraftCheck = false;
        this.setEmpty(true);
      }

      if (!empty) {
        TimeHeaders.updateAll('header[data-time-update]');
      }

      this.sticky && this.sticky.refresh();

      if (Navigation.isCurrentPanel('thread-list')) {
        SoftkeyManager.updateSKs();
      }
    },

    ensureReadAheadSetting: function() {
      Settings.setReadAheadThreadRetrieval(ValueDefault.FIRST_PANEL_THREAD_COUNT);
    },

    renderThreads: function(firstViewDoneCb) {
      window.performance.mark('willRenderThreads');
      PerformanceTestingHelper.dispatch('will-render-threads');

      let hasThreads = false;
      let firstPanelCount = ValueDefault.FIRST_PANEL_THREAD_COUNT;
      let firstCacheCount = ValueDefault.FIRST_SHOW_THREAD_COUNT;
      // Default contact conut is 0.
      ContactsServiceManager.contactCount = 0;
      // Default contact first shown id array is null.
      ContactsServiceManager.contactThreadArray = [];
      // Default thread count is 0.
      ThreadListUI.threadCount = 0;

      let softkeyCache = document.querySelector('#cachedSoftkeyPanel');
      if (!softkeyCache || (softkeyCache &&
          !softkeyCache.classList.contains('visible'))) {
        let parentElement = document.querySelector('#main-wrapper');
        let softkeyBar = document.createElement('div');
        softkeyBar.classList.add(
          'skbar', 'no-padding', 'visible', 'fake-skbar-height'
        );
        parentElement.appendChild(softkeyBar);
      }
      this.prepareRendering();

      let firstViewDone = () => {
        this.initStickyHeader();

        if (typeof firstViewDoneCb === 'function') {
          firstViewDoneCb();
        }
      };

      let firstCacheDone = () => {
        // If no message, only hide cache list.
        if (!this.noMessages.classList.contains('hide')) {
          document.getElementById('cache-list').classList.add('hide');
          document.getElementById('normal-list').classList.remove('hide');
          document.getElementById('cache-list').innerHTML = '';
        } else {
          if (ContactsServiceManager.contactRenderComplete) {
            this.showRealCache();
          } else {
            window.addEventListener('first-contact-list-render', () => {
              this.showRealCache();
            });
          }
        }
      };

      function onRenderThread(thread) {
        Threads.set(thread.id, thread);

        if (Navigation.isCurrentPanel('thread', { id: thread.id })) {
          ThreadUI.updateHeaderData();
        }

        if (!hasThreads) {
          hasThreads = true;
          this.startRendering();
        }

        // Record the thread count.
        ThreadListUI.threadCount++;

        this.appendThread(thread);

        if (--firstPanelCount === 0) {
          firstViewDone();
        }

        if (--firstCacheCount === 0) {
          firstCacheDone();
        }
      }

      function onThreadsRendered() {
        if (hasThreads) {
          Startup.firstDraftCheck = false;
        }
        this.finalizeRendering(!(hasThreads || Drafts.size));

        if (firstPanelCount > 0) {
          firstViewDone();
        }

        if (firstCacheCount > 0) {
          firstCacheDone();
        }
      }

      function onDone() {
        this.readyDeferred.resolve();
        this.ensureReadAheadSetting();
        Startup.useCache = false;
      }

      MessageManager.getThreads({
        each: onRenderThread.bind(this),
        end: onThreadsRendered.bind(this),
        done: onDone.bind(this)
      });

      return this.readyDeferred.promise;
    },

    // Draft action function.
    renderDrafts: function(force) {
      return Drafts.request(force).then(() => {
        if (ActivityHandler.lastMessage) {
          return;
        }
        Drafts.forEach((draft, threadId) => {
          if (threadId) {
            const el = document.getElementById('thread-' + threadId);
            if (el) {
              this.updateThread(Threads.get(threadId));
            }
          } else {
            this.setEmpty(false);

            if (!this.draftRegistry[draft.id]) {
              this.appendThread(Thread.create(draft));
            }
          }
        });
        // Reset route node.
        if (Navigation.isCurrentPanel('thread-list')) {
          NavigationMap.reset('thread-list');
          NavigationMap.setFocus('first');
        }
        this.sticky && this.sticky.refresh();
        window.dispatchEvent(new CustomEvent('draft-render-completed'));
      });
    },

    // Thread DOM change.
    appendThread: function(thread) {
      if (Utils.getL10nState() !== 'complete') {
        Utils.waitL10nState(() => {
          this.appendThread(thread);
        });
        return;
      }

      const drafts = Drafts.byThreadId(thread.id);
      let timestamp = +thread.timestamp;
      let firstThreadInContainer = false;

      if (drafts.length) {
        timestamp = Math.max(drafts.latest.timestamp, timestamp);
      }

      const node = this.createThread(thread);
      ContactsServiceManager.setContact(node);

      const threadsContainerID = '#threadsContainer_' + TimeUtils.getDayDate(timestamp);
      const threadsListContainer = document.getElementById('normal-list');
      let threadsContainer = threadsListContainer.querySelector(threadsContainerID);
      if (!threadsContainer) {
        const threadsContainerWrapper = this.createThreadContainer(timestamp);
        threadsContainer = threadsContainerWrapper.childNodes[1];
        this.insertThreadContainer(threadsContainerWrapper, timestamp);
        firstThreadInContainer = true;
      }

      const threads = threadsContainer.getElementsByTagName('li');
      let threadFound = false;
      for (let i = 0, l = threads.length; i < l; i++) {
        if (timestamp > threads[i].dataset.time) {
          threadFound = true;
          threadsContainer.insertBefore(node, threads[i]);
          break;
        }
      }

      if (!threadFound) {
        threadsContainer.appendChild(node);
      }

      if (InboxEdit.isInEditMode()) {
        InboxEdit.addElementFromSelectList(thread.id);
      }

      return firstThreadInContainer;
    },

    createThread: function(record) {
      let li = document.createElement('li');
      let [timestamp, type, participants, id, bodyHTML] = [
        +record.timestamp, record.lastMessageType, record.participants,
        record.id, record.body
      ];

      const number = participants[0];
      const thread = Threads.get(id);
      const isDraft = typeof thread === 'undefined';
      const hasDrafts = isDraft ? false : thread.hasDrafts;

      let draft, draftId;
      let iconLabel = '';
      let isGroup = record.isGroup || false;

      if (!Settings.hasGroup) {
        isGroup = false;
      }

      if (hasDrafts) {
        draft = Drafts.byThreadId(thread.id).latest;
        timestamp = Math.max(draft.timestamp, timestamp);
        if (draft.timestamp >= record.timestamp) {
          bodyHTML = draft.content.find((content) => {
            if (typeof content === 'string') {
              return true;
            }
          });
          type = draft.type;
        }
      }

      bodyHTML = Template.escape(bodyHTML || '');

      li.id = 'thread-' + id;
      li.dataset.threadId = id;
      li.dataset.time = timestamp;
      li.dataset.lastMessageType = type;
      li.classList.add('threadlist-item');
      li.classList.add('navigable');

      if (record.lastMessageSubject) {
        li.classList.add('list-subject');
      }

      if (hasDrafts || isDraft) {
        li.classList.add('draft');

        if (hasDrafts) {
          li.classList.add('has-draft');
          iconLabel = 'has-draft';
        } else {
          li.classList.add('is-draft');
          iconLabel = 'is-draft';
        }

        draftId = hasDrafts ? draft.id : record.id;

        this.draftRegistry[draftId] = true;
      }

      if (record.unreadCount > 0) {
        li.classList.add('unread');
        iconLabel = 'unread-thread';
      }

      li.innerHTML = this.tmpl.thread.interpolate({
        hash: isDraft ? '#composer' : '#thread=' + id,
        mode: isDraft ? 'drafts' : 'threads',
        id: isDraft ? draftId : id,
        number: number,
        bodyHTML: bodyHTML,
        timestamp: String(timestamp),
        iconLabel: iconLabel
      }, {
        safe: ['id', 'bodyHTML']
      });

      TimeHeaders.update(li.querySelector('time'));

      if (draftId) {
        this.draftLinks.set(li.querySelector('a'), draftId);
      }

      if (isGroup) {
        li.querySelector('.group-icon').classList.remove('dialog-hide');
        li.classList.add('group-list');
        li.querySelector('.group-icon').setAttribute('data-icon', 'group-contacts');
      }

      if (draft && draft.timestamp >= record.timestamp) {
        this.updateMMSPreview('draft', li, draft);
      } else {
        this.updateMMSPreview('thread', li, record);
      }

      return li;
    },

    createThreadContainer: function(timestamp) {
      const threadContainer = document.createElement('div');
      const headerDOM = document.createElement('header');
      const headerFlag = document.createElement('span');

      headerDOM.id = 'header_' + timestamp;
      headerDOM.className = 'h3';

      headerDOM.dataset.timeUpdate = 'repeat';
      headerDOM.dataset.time = timestamp;
      headerDOM.dataset.dateOnly = true;

      let threadsContainerDOM = document.createElement('ul');
      threadsContainerDOM.id = 'threadsContainer_' +
                               TimeUtils.getDayDate(timestamp);
      headerDOM.innerHTML = TimeUtils.getHeaderDate(timestamp);

      headerFlag.className = 'time-header-flag';

      headerDOM.appendChild(headerFlag);
      threadContainer.appendChild(headerDOM);
      threadContainer.appendChild(threadsContainerDOM);
      return threadContainer;
    },

    insertThreadContainer: function(group, timestamp) {
      const headers = this.container.getElementsByTagName('header');
      let groupFound = false;
      for (let i = 0; i < headers.length; i++) {
        if (timestamp >= headers[i].dataset.time) {
          groupFound = true;
          this.container.insertBefore(group, headers[i].parentNode);
          break;
        }
      }
      if (!groupFound) {
        this.container.appendChild(group);
      }
    },

    removeThread: function(threadId) {
      const li = this.container.querySelector('#thread-' + threadId);
      let parent, draftId;

      if (li) {
        parent = li.parentNode;
        li.remove();
      }

      if ((draftId = this.draftLinks.get(li))) {
        this.draftLinks.delete(li);
        delete this.draftRegistry[draftId];
      }

      if (parent && !parent.firstElementChild) {
        parent.previousSibling.remove();
        parent.remove();

        this.sticky && this.sticky.refresh();

        if (!this.container.querySelector('li')) {
          this.setEmpty(true);
        }
      }
    },

    deleteThread: function(threadId) {
      Threads.delete(threadId);
      this.removeThread(threadId);
      NotiificationManager.closeNotificationsForThread(threadId);
    },

    updateThread: function(record, options) {
      if (!record) {
        return;
      }

      const thread = Thread.create(record, options);
      const threadUINode = document.getElementById('thread-' + thread.id);
      const threadUITime = threadUINode ? +threadUINode.dataset.time : NaN;
      const newMessageReceived = options && options.unread;
      const messagesDeleted = options && options.deleted;
      let recordTime = +thread.timestamp;

      if (options && options.timestamp) {
        recordTime = options.timestamp;
      }
      if (Threads.has(thread.id)) {
        Threads.set(thread.id, thread);
      }
      if (newMessageReceived && threadUITime > recordTime) {
        this.mark(thread.id, 'unread');
        this.cacheAction();
        return;
      }
      if (messagesDeleted && threadUITime === recordTime) {
        return;
      }

      MessageCache.clear('threads-container');

      if (threadUINode) {
        this.removeThread(thread.id);
      }

      this.setEmpty(false);
      if (this.appendThread(thread)) {
        this.sticky && this.sticky.refresh();
      }

      if (Navigation.isCurrentPanel('thread-list') &&
          this.noMessages.classList.contains('hide')) {
        this.saveCache();
      }
    },

    // MMS preview module.
    getMMSPreview: function(record) {
      // Not download should be shown first anyWhere.
      if (record.lastMessageAttachmentStatus &&
          record.lastMessageAttachmentStatus === 'not-downloaded') {
        return 'not-download-label';
      }

      // show logic: Attachment -> subject -> mms.
      if (record.lastMessageAttachmentStatus &&
          record.lastMessageAttachmentStatus === 'downloaded') {
        return 'attachment-label';
      }

      if (record.lastMessageSubject) {
        return 'subject-label';
      }

      return 'mms-label';
    },

    getDraftPreview: function(draft) {
      if (draft.attachment.length !== 0) {
        return 'attachment-label';
      }

      if (draft.subject) {
        return 'subject-label';
      }

      return 'mms-label';
    },

    updateMMSPreview: function(tag, node, record) {
      let mmsPreview = node.querySelector('.mms-icon');

      if (!mmsPreview) {
        return;
      }

      let mmsPreviewStatus;
      if (tag === 'thread') {
        mmsPreviewStatus = this.getMMSPreview(record);
      } else {
        mmsPreviewStatus = this.getDraftPreview(record);
      }

      mmsPreview.textContent = '';
      if (mmsPreviewStatus === 'subject-label') {
        mmsPreview.removeAttribute('data-l10n-id');
        mmsPreview.textContent = record.lastMessageSubject || record.subject;
      } else {
        mmsPreview.setAttribute('data-l10n-id', mmsPreviewStatus);
      }
    },

    // Protocol handler module.
    _onMessageSending: function(event) {
      this.updateThread(event.message);
    },

    _onMessageReceived: function(event) {
      // If user currently in the same thread, then mark thread as read
      const markAsRead = Navigation.isCurrentPanel('thread', {
        id: event.message.threadId
      });

      this.updateThread(event.message, { unread: !markAsRead });
    },

    _onThreadsDeleted: function(event) {
      event.ids.forEach((threadId) => {
        if (Threads.has(threadId)) {
          this.deleteThread(threadId);
        }
      });

      let count = event.ids.length;
      if (count && DeleteManager.manualDeleted) {
        DeleteManager.manualDeleted = false;
        // The count needs include the draft.
        count = count + DeleteManager.draftToDelete;
        Utils.showToaster({
          messageL10nId: 'deleted-threads',
          messageL10nArgs: { n: count }
        });
      }
    },

    _onShowTost: function() {
      Utils.showToaster({ messageL10nId: 'message-sent-toast' });
      this.messagesSent = false;
    }
  };

  exports.ThreadListUI = ThreadListUI;
}(this));
