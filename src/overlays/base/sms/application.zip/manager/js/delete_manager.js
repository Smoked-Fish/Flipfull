/* global FocusManager, DialogManager, MessageManager, ThreadListUI, WaitingScreen,
          OptionManager, Threads, Drafts, InboxEdit, SoftkeyManager, ThreadUI,
          NavigationMap, ConversationEdit, Compose, Utils */

'use strict';

let DeleteManager = {
  manualDeleted: false,
  draftToDelete: 0,

  // List delete map.
  deleteSelectedList: function() {
    function deleteCallback() {
      DeleteManager.performListDeletion();
    }

    function cancelCallback() {
      FocusManager.resetListFocusElement();
    }

    DialogManager.confirmAlert('confirmation-title',
                               { id: 'deleteThreads-confirmation2',
                                 args: { n: InboxEdit.selectionHandler.selectedCount } },
                               'cancel', cancelCallback, null, null, 
                               'delete', deleteCallback, cancelCallback);
  },

  performListDeletion: function() {
    let threadIdsToDelete = [],
        messageIdsToDelete = [],
        threadCountToDelete = 0;
    this.draftToDelete = 0;
    const selected = InboxEdit.selectionHandler.selectedList;

    function onAllThreadMessagesRetrieved() {
      if (!--threadCountToDelete) {
        MessageManager.deleteMessages(messageIdsToDelete);

        threadIdsToDelete.forEach((threadId) => {
          ThreadListUI.deleteThread(threadId);
        });

        messageIdsToDelete = threadIdsToDelete = null;

        DeleteManager.exitEditMode();
      }
    }

    function onThreadMessageRetrieved(message) {
      messageIdsToDelete.push(message.id);
      return true;
    }

    WaitingScreen.show();
    SoftkeyManager.show([SoftkeyManager.skWait]);
    if (OptionManager.isOptionMenuShown()) {
      OptionManager.hideOptionMenu();
    }

    threadIdsToDelete = selected.reduce((list, value) => {
      const threadId = +value;
      const isDraft = typeof Threads.get(threadId) === 'undefined';

      if (isDraft) {
        Drafts.delete(Drafts.get(threadId));
        ThreadListUI.removeThread(threadId);
      } else {
        list.push(threadId);
      }

      return list;
    }, []);

    if (threadIdsToDelete.length !== selected.length) {
      Drafts.store();
    }

    if (!threadIdsToDelete.length) {
      // Draft needs be picked when delete.
      Utils.showToaster({
        messageL10nId: 'deleted-threads',
        messageL10nArgs: { n: selected.length }
      });
      this.exitEditMode();
      return;
    } else {
      this.draftToDelete = selected.length - threadIdsToDelete.length;
    }

    threadCountToDelete = threadIdsToDelete.length;

    DeleteManager.manualDeleted = true;
    threadIdsToDelete.forEach((threadId) => {
      MessageManager.getMessages({
        filter: { threadId: threadId },
        each: onThreadMessageRetrieved,
        end: onAllThreadMessagesRetrieved
      });
    });
  },

  deleteCurrentThread: function() {
    function deleteCallback() {
      DeleteManager.performCurrentDeletion();
    }

    function cancelCallback() {
      FocusManager.resetListFocusElement();
    }

    DialogManager.confirmAlert('confirmation-title', 'delete-current-thread?',
                               'cancel', cancelCallback, null, null,
                               'delete', deleteCallback, cancelCallback);
  },

  performCurrentDeletion: function() {
    let messageIdsToDelete = [];
    let threadId = null;
    if (FocusManager.currentThread) {
      threadId = FocusManager.currentThread.dataset.threadId;
    }

    function onAllThreadMessagesRetrieved() {
      MessageManager.deleteMessages(messageIdsToDelete);
      ThreadListUI.deleteThread(threadId);
      messageIdsToDelete = null;
      FocusManager.currentThread = null;
      WaitingScreen.hide();
      SoftkeyManager.updateSKs();
    }

    function onThreadMessageRetrieved(message) {
      messageIdsToDelete.push(message.id);
      return true;
    }

    WaitingScreen.show();
    SoftkeyManager.show([SoftkeyManager.skWait]);
    if (OptionManager.isOptionMenuShown()) {
      OptionManager.hideOptionMenu();
    }

    const isDraft = typeof Threads.get(threadId) === 'undefined';
    if (isDraft) {
      Drafts.delete(Drafts.get(threadId));
      ThreadListUI.removeThread(threadId);
      Drafts.store();
      WaitingScreen.hide();
      SoftkeyManager.updateSKs();
      FocusManager.currentThread = null;
      Utils.showToaster({
        messageL10nId: 'deleted-threads',
        messageL10nArgs: { n: 1 }
      });
    } else {
      DeleteManager.manualDeleted = true;
      MessageManager.getMessages({
        filter: { threadId: threadId },
        each: onThreadMessageRetrieved,
        end: onAllThreadMessagesRetrieved
      });
    }
  },

  exitEditMode: function() {
    InboxEdit.cancelEdit();
    WaitingScreen.hide();
    SoftkeyManager.updateSKs();
  },

  // Thread delete map.
  deleteSingleMessage: function() {
    const messageId = ThreadUI.getFocusedMessageId(ThreadUI._storeFocused);
    function confirmCallback() {
      WaitingScreen.show();
      if (OptionManager.isOptionMenuShown()) {
        OptionManager.hideOptionMenu();
      }
      MessageManager.deleteMessages(messageId, () => {
        ThreadUI.deleteUIMessages(messageId);
      });
      ThreadUI.showToaster('messageMode');
      NavigationMap.reset('thread-messages');
      WaitingScreen.hide();
    }
    DialogManager.confirmAlert('confirmation-title', 'deleteMessage-confirmation',
                               'cancel', null, null, null, 'delete', confirmCallback);
  },

  delete: function() {
    function deleteCallback() {
      DeleteManager.performCommonDeletion();
    }

    function cancelCallback() {
      ConversationEdit.updateSKs();
    }

    DialogManager.confirmAlert('confirmation-title', 'deleteMessages-confirmation',
                               'cancel', cancelCallback, null, null, 
                               'delete', deleteCallback);
  },

  performCommonDeletion: function() {
    WaitingScreen.show();
    SoftkeyManager.show([SoftkeyManager.skWait]);
    if (OptionManager.isOptionMenuShown()) {
      OptionManager.hideOptionMenu();
    }
    const items = ConversationEdit.selectionHandler.selectedList;
    const delNumList = items.map(item => +item);

    MessageManager.deleteMessages(delNumList, () => {
      ThreadUI.deleteUIMessages(delNumList, () => {
        ConversationEdit.cancelEdit();
        WaitingScreen.hide();
        ThreadUI.showToaster('editMode', delNumList.length);
        NavigationMap.reset('thread-messages');
        NavigationMap.setFocusToFixedElement('messages-input');
      });
    });
  },

  deleteCurrentThreadFromThread: function(mode, messageId) {
    const threadId = ThreadUI.currentThreadId;

    function confirmCallback() {
      DeleteManager.performThreadDeletion(threadId, messageId);
    }

    function cancelCallback() {
      ConversationEdit.updateSKs();
    }

    if (threadId) {
      let confirmation;
      if (mode === 'messageMode') {
        confirmation = 'deleteMessage-confirmation';
      }
      else if (mode === 'editMode') {
        confirmation = 'deleteMessages-confirmation';
      } else {
        confirmation = 'deleteMessage-confirmation2';
      }
      DialogManager.confirmAlert('confirmation-title', confirmation,
                                 'cancel', cancelCallback, null, null,
                                 'delete', confirmCallback, null);
    }
  },

  performThreadDeletion: function(threadId, messageId) {
    let messageIdsToDelete = [];

    function deleteRelatedThread(id) {
      MessageManager.deleteMessages(id);
      ThreadListUI.deleteThread(threadId);
      WaitingScreen.hide();
      Compose.clear();
      ThreadUI.back();
      // Reset list to update the node.
      NavigationMap.reset('thread-list');
      messageIdsToDelete = null;
    }

    function onAllThreadMessagesRetrieved() {
      deleteRelatedThread(messageIdsToDelete);
    }

    function onThreadMessageRetrieved(message) {
      messageIdsToDelete.push(message.id);
      return true;
    }

    WaitingScreen.show();
    SoftkeyManager.show([SoftkeyManager.skWait]);
    if (OptionManager.isOptionMenuShown()) {
      OptionManager.hideOptionMenu();
    }
    DeleteManager.manualDeleted = true;
    if (messageId) {
      deleteRelatedThread(messageId);
    } else {
      MessageManager.getMessages({
        filter: { threadId: threadId },
        each: onThreadMessageRetrieved,
        end: onAllThreadMessagesRetrieved
      });
    }
  }
};
