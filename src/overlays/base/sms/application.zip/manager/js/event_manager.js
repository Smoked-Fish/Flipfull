/* global FocusManager, DialogManager, ThreadListUI, OptionManager, Threads,
          Drafts, InboxEdit, SoftkeyManager, ThreadUI, NavigationMap,
          ConversationEdit, Compose, Utils, Settings, Navigation, DraftUtils,
          SearchMessageUI, SettingsUI, ValueDefault, SwitchHandler, WaitingScreen,
          AttachmentMessageUI, ActivityHandler, Startup, ActivityModule,
          NotiificationManager, TimeHeaders, FocusStateManager */

'use strict';

// eslint-disable-next-line no-unused-vars
let EventManager = {
  listener: false,
  scrollIndex: 0,

  init: function() {
    // Window listener.
    window.addEventListener('index-changed', this);
    window.addEventListener('message-focusChanged', this);
    window.addEventListener('input', this);
    window.addEventListener('keydown', this);
    window.addEventListener('change', this);

    // Input need be handler specially.
    document.querySelector('#messages-input').addEventListener(
      'keydown', this.handleInputEvent.bind(this));

    // Backgroud listener.
    document.addEventListener('visibilitychange', this.visibilityHandle);

    // Init base element.
    this.recipientsField = document.querySelector('#messages-recipients-list');
  },

  // Common event listener handler.
  handleEvent: function(event) {
    const focusEle = document.querySelector('.focus');

    // Option/Dialog need do some actions if press back key.
    if ((OptionManager.isOptionMenuShown() || DialogManager.isDialogShown()) &&
        (event.key !== 'Backspace' && event.key !== 'BrowserBack' &&
         event.key !== 'EndCall')) {
      return;
    }

    switch (event.type) {
      case 'index-changed': {
        if (event.detail.panel === 'thread-list') {
          FocusManager.currentThread = event.detail.focusedItem;
          SoftkeyManager.updateSKs();
        }
        break;
      }
      case 'message-focusChanged': {
        FocusManager._onFocusChanged();
        break;
      }
      case 'input': {
        if (focusEle.id === 'subject-composer-input') {
          FocusManager._onFocusChanged();
        }
        break;
      }
      case 'change': {
        const selectValue = event.target.value;
        let flag;
        switch (selectValue) {
          case 'deliverySMSOn':
          case 'deliverySMSOff':
            flag = selectValue === 'deliverySMSOn' ? true : false;
            Utils.setSettingsValue([{
              name: 'ril.sms.requestStatusReport.enabled',
              value: flag
            }]);
            break;
          case 'deliveryMMSOn':
          case 'deliveryMMSOff':
            flag = selectValue === 'deliveryMMSOn' ? true : false;
            Utils.setSettingsValue([{
              name: 'ril.mms.requestStatusReport.enabled',
              value: flag
            }]);
            break;
          case 'manual':
          case 'automatic':
          case 'automatic-home':
            flag = selectValue;
            Utils.setSettingsValue([{
              name: 'ril.mms.retrieval_mode',
              value: flag
            }]);
            break;
          case 'restricted':
          case 'warning':
          case 'free':
            flag = selectValue;
            Utils.setSettingsValue([{
              name: 'ril.mms.creation_mode',
              value: flag
            }]);
            break;
          case 'sim1On':
          case 'sim1Off':
            flag = selectValue === 'sim1On' ? true : false;
            Utils.setSettingsValue([{
              name: 'wap.push.enabled.sim1',
              value: flag
            }]);
            break;
          case 'sim2On':
          case 'sim2Off':
            flag = selectValue === 'sim2On' ? true : false;
            Utils.setSettingsValue([{
              name: 'wap.push.enabled.sim2',
              value: flag
            }]);
            break;
          case 'groupSwitchOn':
          case 'groupSwitchOff':
            flag = selectValue === 'groupSwitchOn' ? true : false;
            Settings.groupSwitchEnabled = flag;
            Utils.setSettingsValue([{
              name: 'ril.mms.groupSwitch.enabled',
              value: flag
            }]);
            break;
          default:
            break;
        }
        break;
      }
      case 'keydown': {
        switch (event.key) {
          case 'Enter': {
            // List handler.
            if (Navigation.isCurrentPanel('thread-list')) {
              // Edit mode has module handler.
              if (InboxEdit.isInEditMode()) {
                return;
              }
              // Route next page.
              const parent = event.target;
              const parentThreadId = parent.dataset.threadId;
              if (parentThreadId) {
                event.preventDefault();
                if (parent.classList.contains('is-draft')) {
                  Navigation.toPanel('composer', { draftId: +parentThreadId });
                } else {
                  Navigation.toPanel('thread', { id: +parentThreadId });
                }
              }
            }
            // Main input handler.
            else if (focusEle.id === 'messages-input') {
              event.preventDefault();
            }
            // Subject handler.
            else if (focusEle.id === 'subject-composer-input') {
              event.preventDefault();
            }
            // Search moduel hander.
            else if (Navigation.isCurrentPanel('search-message-view')) {
              event.preventDefault();
              if (focusEle.classList.contains('threadlist-item')) {
                const threadId = focusEle.id;
                // Change id type from string to number.
                const id = +threadId.replace('thread-', '');
                DraftUtils.draft = Drafts.get(id) || null;
                if (focusEle.classList.contains('is-draft')) {
                  Navigation.toPanel('composer', { draftId: id });
                } else {
                  Navigation.toPanel('thread', { id: id });
                }
                SearchMessageUI.searchList.innerHTML = '';
                SearchMessageUI.searchInput.value = '';
              }
            }
            // Settings module handler.
            else if (Navigation.isCurrentPanel('settings-view')) {
              SettingsUI.openSelectItem();
            }
            break;
          }
          case 'Left':
          case 'ArrowLeft': {
            // Switch action.
            if (Navigation.isCurrentPanel('thread')) {
              if (SwitchHandler.canSwitchBetweenThreads()) {
                if (Compose.isEmpty()) {
                  SwitchHandler.switchPreviousThread();
                } else {
                  SwitchHandler.switchThreadSelection(() => {
                    SwitchHandler.switchPreviousThread();
                  });
                }
              }
            }
            break;
          }
          case 'Right':
          case 'ArrowRight': {
            // Switch action.
            if (Navigation.isCurrentPanel('thread')) {
              if (SwitchHandler.canSwitchBetweenThreads()) {
                if (Compose.isEmpty()) {
                  SwitchHandler.switchNextThread();
                } else {
                  SwitchHandler.switchThreadSelection(() => {
                    SwitchHandler.switchNextThread();
                  });
                }
              }
            }
            break;
          }
          case 'ArrowUp':
          case 'ArrowDown': {
            // Attachment mode handler.
            if (ValueDefault.isAttachmentPage) {
              event.preventDefault();
              event.key === 'ArrowUp' ? AttachmentMessageUI.upEventHandler() :
                                        AttachmentMessageUI.downEventHandler();
            }
            // Thread page handler.
            else if (Navigation.isCurrentPanel('thread')) {
              if ((focusEle.tagName === 'A' || focusEle.tagName === 'DIV') &&
                  Utils.getParents(focusEle, 'LI').classList.contains('message')) {
                event.preventDefault();
                event.stopPropagation();
                this.scrollLinkElement(focusEle, event.key);
                SoftkeyManager.updateLinkSKs();
              }
            }
            // Search page handler.
            else if (Navigation.isCurrentPanel('search-message-view')) {
              focusEle.scrollIntoView(false);
            }
            // Settings page handler.
            else if (Navigation.isCurrentPanel('settings-view') &&
                       event.key === 'ArrowUp') {
              const firstLiElement = document.querySelector('#deliveryReport-SMS-item'),
                    firstLiElementHeader = firstLiElement.parentElement.previousElementSibling;
              if (firstLiElement.classList.contains('focus')) {
                firstLiElementHeader.scrollIntoView();
              }
            }
            break;
          }
          case 'Backspace':
          case 'BrowserBack': {
            // Activity page handler.
            if (ValueDefault.activitymode) {
              event.stopPropagation();
              event.preventDefault();
              // Prompt select option menu handler.
              if (OptionManager.contactPromptOptionMenuShown) {
                OptionManager.hideOptionMenu();
                window.addEventListener('transitionend', function optionMenu() {
                  window.removeEventListener('transitionend', optionMenu);
                  FocusStateManager.dynamicSK();
                });
                return;
              }
              // Option menu or dialog handler.
              if (OptionManager.isOptionMenuShown() || DialogManager.isDialogShown()) {
                return;
              }
              // Attachment page at activity mode.
              if (ValueDefault.isAttachmentPage) {
                AttachmentMessageUI.resetPageStatus();
                return;
              }
              // Waitting page handler.
              if (WaitingScreen.loading.classList.contains('show-loading')) {
                ActivityHandler.leaveActivity({ data: null });
                return;
              }
              // Last handler.
              if (document.activeElement.parentNode !== this.recipientsField) {
                ActivityModule.back();
              }
            }
            // List page handler.
            else if (Navigation.isCurrentPanel('thread-list')) {
              if (InboxEdit.isInEditMode()) {
                event.preventDefault();
                InboxEdit.cancelEdit();
                SoftkeyManager.updateSKs();
              } else if (OptionManager.isOptionMenuShown()) {
                event.stopPropagation();
                event.preventDefault();
                OptionManager.hideOptionMenu();
                // Option menu has animation.
                window.addEventListener('transitionend', function transition() {
                  window.removeEventListener('transitionend', transition);
                  SoftkeyManager.updateSKs();
                });
              } else if (DialogManager.isDialogShown()) {
                event.stopPropagation();
                event.preventDefault();
              } else {
                ThreadListUI.cacheAction();
              }
              // Last activity handler.
              if (ActivityHandler.lastMessage) {
                ActivityHandler.leaveActivity({ data: null });
              }
            }
            // Attachment page handler.
            else if (ValueDefault.isAttachmentPage) {
              event.preventDefault();
              AttachmentMessageUI.resetPageStatus();
            }
            // Detail page handler.
            else if (Navigation.isCurrentPanel('report-view')) {
              event.preventDefault();
              ThreadUI.isBackToThreadUI = true;
              ThreadUI.updateHeaderData();
              Navigation.toPanel('thread', { id: Threads.currentId });
            }
            // Thread page handler.
            else if (Navigation.isCurrentPanel('thread')) {
              event.stopPropagation();
              event.preventDefault();
              // Prompt select option menu handler.
              if (OptionManager.contactPromptOptionMenuShown) {
                OptionManager.hideOptionMenu();
                window.addEventListener('transitionend', function optionMenu() {
                  window.removeEventListener('transitionend', optionMenu);
                  FocusStateManager.dynamicSK();
                });
                const OPTIONMENUTIMEOUT = 300;
                setTimeout(() => {
                  // Need get current focus element not use the old one.
                  const currentFocusElement = document.querySelector('.focus');
                  if (currentFocusElement.tagName === 'A') {
                    SoftkeyManager.updateLinkSKs();
                  }
                }, OPTIONMENUTIMEOUT);
                return;
              }
              // Option menu or dialog handler.
              if (OptionManager.isOptionMenuShown() || DialogManager.isDialogShown()) {
                return;
              }
              // Edit mode hander.
              if (ConversationEdit.isInEditMode()) {
                ConversationEdit.cancelEdit();
                // TODO prevent the input box receive event again.
                setTimeout(() => {
                  NavigationMap.reset('thread-messages');
                  NavigationMap.setFocusToFixedElement('messages-input');
                });
              } else if (Utils.getParents(document.activeElement, 'LI').classList.contains('current-focus')) {
                ThreadUI.isLinkMode = false;
                ThreadUI.composerContainer.classList.remove('next-focus');
                const bubbleLi = document.querySelector('.current-focus');
                bubbleLi.classList.remove('bubble-link-focus');
                bubbleLi.classList.remove('current-focus');
                EventManager.cancelToThread();
              } else {
                ThreadUI.back();
              }
            }
            // New page handler.
            else if (Navigation.isCurrentPanel('composer')) {
              event.stopPropagation();
              event.preventDefault();
              // Prompt select option menu handler.
              if (OptionManager.contactPromptOptionMenuShown) {
                OptionManager.hideOptionMenu();
                window.addEventListener('transitionend', function optionMenu() {
                  window.removeEventListener('transitionend', optionMenu);
                  FocusStateManager.dynamicSK();
                });
                return;
              }
              // Option menu or dialog handler.
              if (OptionManager.isOptionMenuShown() || DialogManager.isDialogShown()) {
                return;
              }
              // Last handler.
              if (document.activeElement.parentNode !== this.recipientsField) {
                ThreadUI.back();
              }
            }
            // Search page handler.
            else if (Navigation.isCurrentPanel('search-message-view')) {
              if (event.key !== 'EndCall') {
                event.preventDefault();
                SearchMessageUI.searchList.innerHTML = '';
                SearchMessageUI.searchInput.value = '';
                Navigation.toPanel('thread-list');
              }
            }
            // Settings page handler.
            else if (Navigation.isCurrentPanel('settings-view')) {
              if (event.key !== 'EndCall') {
                event.preventDefault();
                SettingsUI.back();
              }
            }
            break;
          }
          case 'EndCall': {
            if (ValueDefault.isAttachmentPage) {
              event.stopPropagation();
              event.preventDefault();
              if (OptionManager.isOptionMenuShown()) {
                OptionManager.hideOptionMenu();
                window.addEventListener('transitionend', function optionMenu() {
                  window.removeEventListener('transitionend', optionMenu);
                  AttachmentMessageUI.resetPageStatus();
                  ValueDefault.activitymode ? ActivityModule.back() :
                                              ThreadUI.back(true);
                });
              } else {
                AttachmentMessageUI.resetPageStatus();
                ValueDefault.activitymode ? ActivityModule.back() :
                                            ThreadUI.back(true);
              }
            } else if (ValueDefault.activitymode) {
              event.stopPropagation();
              event.preventDefault();
              //Porting from PR 11051520-renlongou on 2024/09/04-begin
              // Waitting page handler.
              if (WaitingScreen.loading.classList.contains('show-loading')) {
                ActivityHandler.leaveActivity({ data: null }); //modified by tingting.chao for GF5GTMO-7177 on 2025/05/06
                return;
              }
              //Porting from PR 11051520-renlongou on 2024/09/04-end
              ActivityModule.back();
            } else if (Navigation.isCurrentPanel('thread') ||
                       Navigation.isCurrentPanel('composer')) {
              event.stopPropagation();
              event.preventDefault();
              // Close app manually if it is at thread or composer.
              if (Compose.isEmpty()) {
                if (OptionManager.isOptionMenuShown() || DialogManager.isDialogShown()) {
                  window.close();
                  return;
                }
              } else {
                if (OptionManager.isOptionMenuShown()) {
                  OptionManager.hideOptionMenu();
                }
              }

              ThreadUI.back(true);
            } else if (Navigation.isCurrentPanel('thread-list')) {
              if (ActivityHandler.lastMessage) {
                ActivityHandler.leaveActivity({ data: null });
              }
            }
            break;
          }
          case 'MicrophoneToggle': {
            if (!ValueDefault.activitymode && ThreadUI.isLinkMode) {
              event.preventDefault();
              event.stopPropagation();
            }
            break;
          }
          default:
            break;
        }
        break;
      }
      default:
        break;
    }
  },

  // Input box event handler.
  handleInputEvent: function(event) {
    const range = window.getSelection().getRangeAt(0);
    const currentCursor = range.startContainer;

    switch (event.key) {
      case 'ArrowUp': {
        if ((currentCursor === document.activeElement ||
             currentCursor === document.activeElement.firstChild) &&
            range.startOffset === 0) {
          break;
        }
        event.stopPropagation();
        break;
      }
      case 'ArrowDown': {
        const currentFocus = document.activeElement;
        const currentChildLength = document.activeElement.childNodes.length;
        if ((currentCursor === currentFocus ||
             currentCursor === currentFocus.childNodes[currentChildLength - 2]) &&
            Utils.isLastLine(range)) {
          break;
        }
        event.stopPropagation();
        break;
      }
      case 'Backspace': {
        event.stopPropagation();
        event.preventDefault();
        if (ValueDefault.activitymode) {
          ActivityModule.back();
        } else {
          ThreadUI.back();
        }
        break;
      }
      default:
        break;
    }
  },

  // Visibility event handler.
  visibilityHandle: function() {
    let value = null;
    // List case.
    if (ValueDefault.activitymode && !ValueDefault.manualLeave) {
      if (!Compose.isEmpty() && !ValueDefault.activitySending) {
        if (!document.hidden) {
          Utils.discardActivityDraft();
        } else {
          Utils.saveActivityDraft();
        }
      }
    } else if (Navigation.isCurrentPanel('thread-list')) {
      if (!document.hidden) {
        if (!ThreadListUI.container.querySelector('.focus')) {
          Startup.messageReceive = false;
          FocusManager.resetListFocus();
        }
        // Time limit for background app situation.
        ThreadListUI.timeLimitHandle();
        // Refresh unread count for background app situation.
        ThreadListUI.refreshUnreadState();
      }
    } else if (Navigation.isCurrentPanel('composer') ||
               Navigation.isCurrentPanel('thread')) {
      if (document.hidden) {
        let isAutoSaveRequired = false;

        if (Navigation.isCurrentPanel('thread') && !ValueDefault.isCall) {
          isAutoSaveRequired = !Compose.isEmpty();
        }

        if (isAutoSaveRequired) {
          DraftUtils.saveDraft({ preserve: true, autoSave: true });
        }
      } else {
        if (!DialogManager.isDialogShown()) {
          NavigationMap.recoveryFocus();
        }
        if (Navigation.isCurrentPanel('thread')) {
          value = Threads.currentId;
          NotiificationManager.closeNotificationsForThread(value);
        }
        // Time limit for background app situation.
        ThreadListUI.timeLimitHandle();
      }
    }
    Utils.setSettingsValue([{
      name: 'message.thread.id',
      value
    }]);
    TimeHeaders.visibilityHandle();
  },

  // Suggestion list listener module.
  startContactNavigation: function() {
    FocusManager.removeAllFocusable();
    NavigationMap.reset('thread-messages');
    window.addEventListener('keydown', this.handleContactList);
    this.listener = true;
  },

  stopContactNavigation: function() {
    FocusManager.recoverAllFocusable();
    NavigationMap.reset('thread-messages');
    window.removeEventListener('keydown', this.handleContactList);
    this.listener = false;
  },

  handleContactList: function(event) {
    const suggestionList =
      document.querySelectorAll('#messages-recipient-suggestions li');
    const selected =
      document.querySelector('#messages-recipient-suggestions li.selected');
    switch (event.key) {
      case 'ArrowUp': {
        if (selected) {
          if (selected.previousSibling) {
            selected.classList.remove('selected');
            selected.previousSibling.classList.add('selected');
            document.querySelector('.selected').scrollIntoView(true);
            SoftkeyManager.show([SoftkeyManager.skAddSuggestion]);
          } else {
            selected.classList.remove('selected');
            SoftkeyManager.show([SoftkeyManager.skEnter, SoftkeyManager.skAddContact]);
          }
        } else {
          suggestionList[suggestionList.length - 1].classList.add('selected');
          suggestionList[suggestionList.length - 1].scrollIntoView(true);
          SoftkeyManager.show([SoftkeyManager.skAddSuggestion]);
        }
        event.preventDefault();
        break;
      }
      case 'ArrowDown': {
        if (selected) {
          if (selected.nextSibling) {
            selected.classList.remove('selected');
            selected.nextSibling.classList.add('selected');
            document.querySelector('.selected').scrollIntoView(false);
            SoftkeyManager.show([SoftkeyManager.skAddSuggestion]);
          } else {
            selected.classList.remove('selected');
            SoftkeyManager.show([SoftkeyManager.skEnter, SoftkeyManager.skAddContact]);
          }
        } else {
          suggestionList[0].classList.add('selected');
          suggestionList[0].scrollIntoView(true);
          SoftkeyManager.show([SoftkeyManager.skAddSuggestion]);
        }
        event.preventDefault();
        break;
      }
    }
  },

  // Link handler.
  scrollLinkElement: function(node, direction) {
    const sourceElement = Utils.getParents(node, 'LI');
    const secondNode =
      sourceElement.getElementsByClassName('message-content-body')[0];
    const secondElement = secondNode.querySelectorAll('.link-focus');
    const elementLength = secondElement.length;
    let nextFocusNode;
    if (direction === 'ArrowDown') {
      this.scrollIndex += 1;
    } else {
      this.scrollIndex -= 1;
    }
    if (this.scrollIndex < 0) {
      this.scrollIndex = elementLength - 1;
    }
    if (this.scrollIndex > elementLength - 1) {
      this.scrollIndex = 0;
    }

    nextFocusNode = secondElement[this.scrollIndex];
    if (nextFocusNode.tagName === 'A' || nextFocusNode.tagName === 'DIV') {
      node.blur();
      node.classList.remove('focus');
      nextFocusNode.focus();
      nextFocusNode.classList.add('focus');
      nextFocusNode.scrollIntoView(true);
      if (node.tagName === 'A') {
        Utils.getParents(node, 'LI').classList.remove('bubble-link-focus');
      }
      if (nextFocusNode.tagName === 'A') {
        Utils.getParents(nextFocusNode, 'LI').classList.add('bubble-link-focus');
      }
    }
  },

  cancelToThread: function() {
    const currentFocus = document.querySelector('.focus');
    const nextFocus = Utils.getParents(currentFocus, 'LI');
    currentFocus.blur();
    currentFocus.classList.remove('focus');
    NavigationMap.setFocusToFixedElement(nextFocus.id);
    this.scrollIndex = 0;
  }
};
