/* global ThreadListUI, SoftkeyManager, AttachmentService, ActivityPicker, Utils,
          OptionManager, Navigation, NavigationMap, FocusStateManager, InboxEdit */

'use strict';

// eslint-disable-next-line no-unused-vars
let FocusManager = {
  currentThread: null,
  focusableElement: null,
  scrollIndex: 0,

  // Empty page focus.
  focusNoMessage: function() {
    ThreadListUI.noResultMessage.focus();
    SoftkeyManager.show([SoftkeyManager.skNewMessage, SoftkeyManager.skSettings]);
  },

  // List focus backup.
  setListFocusElement: function() {
    const focusElement = document.querySelector('.focus');
    this.currentThread = focusElement;
  },

  // Link focus module.
  findLinkFocus: function() {
    const parentNode = document.activeElement;
    this.scrollIndex = 0;
    const secondNode = parentNode.getElementsByClassName(
      'message-content-body')[0].querySelectorAll('.link-focus');
    parentNode.blur();
    parentNode.classList.remove('focus');
    secondNode[this.scrollIndex].focus();
    secondNode[this.scrollIndex].classList.add('focus');
    if (secondNode[this.scrollIndex].tagName === 'A') {
      Utils.getParents(secondNode[this.scrollIndex], 'LI').classList.add('bubble-link-focus');
    }
    SoftkeyManager.updateLinkSKs();
  },

  doLinkAction: function(type) {
    const focusEle = document.querySelector('.focus');
    switch (type) {
      case 'attachment':
        AttachmentService.mmsAttachmentClick(focusEle);
        break;
      case 'dial':
        ActivityPicker.dial(focusEle.dataset.dial, true, false);
        break;
      case 'rtt-dial':
        ActivityPicker.dial(focusEle.dataset.dial, true, true);
        break;
      case 'select-dial':
        OptionManager.switchCallOption('call', 'rtt-call', (rttEnable) => {
          if (rttEnable) {
            ActivityPicker.dial(focusEle.dataset.dial, true, true);
          } else {
            ActivityPicker.dial(focusEle.dataset.dial, true, false);
          }
        });
        break;
      case 'email':
        ActivityPicker.email(focusEle.dataset.email, () => {}, () => {});
        break;
      case 'url':
        //Porting from PRGF7TF-4730-tingting.chao on 24/09/09-begin
        //ActivityPicker[type](focusEle.dataset[type]);
        let url = focusEle.dataset[type];
        let e911URL = 'e911-reg.tracfone.com';
        if(url.substring(7 ,e911URL.length+7) == e911URL) {
          ActivityPicker.url('https://e911-reg.tracfone.com');
          dump('open url https://e911-reg.tracfone.com');
        } else{
          dump('open url ' + url);
        }
        ActivityPicker[type](url);
        //Porting from PRGF7TF-4730-tingting.chao on 24/09/09-end
        break;
        break;
    }
  },

  // List focus reset.
  resetListFocusElement: function() {
    this.removeAllFocus();
    this.currentThread.focus();
    this.currentThread.classList.add('focus');
    InboxEdit.updateSKs();
  },

  resetListFocus: function() {
    const FOCUSTIMEOUT = 100;
    setTimeout(() => {
      this.recoveryThreadFocus();
      this.setListFocusElement();
      SoftkeyManager.updateSKs();
    }, FOCUSTIMEOUT);
  },

  // Recovery common focus.
  recoverAllFocusable: function() {
    if (this.focusableElement) {
      const elements = Array.prototype.slice.call(this.focusableElement);
      elements.forEach((element) => {
        if (!element.classList.contains('recipient')) {
          element.classList.add('navigable');
        }
      });
      this.focusableElement = null;
    }
  },

  // Recovery thread focus.
  recoveryThreadFocus: function() {
    if (Navigation.isCurrentPanel('thread-list')) {
      const threadPage = document.querySelector('.threadlist-item');
      if (threadPage) {
        NavigationMap.setFocusToFixedElement(threadPage.id);
      }
    }
  },

  // Recovery draft focus.
  recoveryDraftFocus: function(toId) {
    const threadPage = document.getElementById('thread-' + toId);
    const ANIMATIONTIME = 300;
    NavigationMap.toDraft = true;
    if (threadPage) {
      // The animation need 300ms time out.
      setTimeout(() => {
        NavigationMap.setFocusToFixedElement(threadPage.id);
        this.setListFocusElement();
        SoftkeyManager.updateSKs();
      }, ANIMATIONTIME);
    } else {
      NavigationMap.toDraft = false;
    }
  },

  // Clear focus.
  removeAllFocus: function() {
    const focusArray = document.querySelectorAll('.focus');
    focusArray.forEach((element) => {
      element.classList.remove('focus');
      element.blur();
    });
  },

  removeAllFocusable: function() {
    this.focusableElement =
      document.querySelector('#thread-messages').querySelectorAll('.navigable');
    const elements = Array.prototype.slice.call(this.focusableElement);
    elements.forEach((element) => {
      if (!element.classList.contains('recipient')) {
        element.classList.remove('navigable');
      }
    });
  },

  // Focus listener create.
  _onFocusChanged: function() {
    if (document.activeElement.tagName === 'BODY') {
      document.querySelector('.focus').focus();
    }

    if (Navigation.isCurrentPanel('thread-list')) {
      SoftkeyManager.updateSKs();
    } else {
      FocusStateManager.dynamicSK();
    }
  }
};
