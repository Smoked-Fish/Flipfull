/* global AttachmentManager, SendService, SoftkeyManager, Compose, SubjectUtils, 
          AttachmentMessageUI, ActivityModule, Settings */

'use strict';

// eslint-disable-next-line no-unused-vars
let FocusStateManager = {
  FOCUS_INVALID: 0,
  FOCUS_ON_RECIPIENTS: 1,
  FOCUS_ON_SUBJECT: 2,
  FOCUS_ON_MESSAGE_INPUT: 3,
  FOCUS_ON_ATTACHMENT: 4,

  // Softkey update according to state.
  dynamicSK: function() {
    // Porting from PRGF7VZW-7124-tingting.chao on 24/09/09-Click Options, but Discard is triggered-begin
    if (DialogManager.isDialogShown()) {
      return;
    }
    // Porting from PRGF7VZW-7124-tingting.chao on 24/09/09-Click Options, but Discard is triggered-end
    const currentFocus = document.querySelector('.focus');
    if (!currentFocus) {
      return;
    }

    const focusState = this.getFocusState(currentFocus);
    this.dynamicComposerSK(focusState);
  },

  dynamicComposerSK: function(focusState) {
    let skParam;
    const hasAttachment = (AttachmentManager.getMessageCount() !== 0);
    const SIMCardParam = SendService.selectSIMSend();

    switch (focusState) {
      case this.FOCUS_INVALID:
        return;
      case this.FOCUS_ON_RECIPIENTS: {
        if (ActivityModule.selector.recipient.lastChild.textContent.length !== 0) {
          skParam = [SoftkeyManager.skEnter, SoftkeyManager.skAddContact];
        } else {
          skParam = [SoftkeyManager.skAddContact];
          if (!Compose.disableSendButton() && SIMCardParam) {        
            skParam = [SIMCardParam].concat(skParam);
          }
        }
        break;
      }
      case this.FOCUS_ON_SUBJECT: {
        skParam = [SoftkeyManager.skRemoveSubject, SoftkeyManager.skAddAttachment];
        if (!Compose.disableSendButton() && SIMCardParam) {
          skParam = [SIMCardParam].concat(skParam);
        }
        if (!Compose.isEmpty()) {
          if (hasAttachment) {
            skParam = skParam.concat([SoftkeyManager.skRemoveAttachment]);
          }
          skParam = skParam.concat([SoftkeyManager.skSaveAsDraft, 
                                    SoftkeyManager.skCancelFromThread]);
        }
        break;
      }
      case this.FOCUS_ON_MESSAGE_INPUT: {
        if (!Compose.disableSendButton()) {
          if (SubjectUtils.isSubjectVisible()) {
            skParam = [SoftkeyManager.skRemoveSubject, SoftkeyManager.skAddAttachment];
          } else {
            if (Settings.mmsEnable) {
              skParam = [SoftkeyManager.skAddSubject, SoftkeyManager.skAddAttachment];
            } else {
              skParam = [];
            }
          }
          if (SIMCardParam) {
            skParam = [SIMCardParam].concat(skParam);
          }
        } else if (SubjectUtils.isSubjectVisible()) {
          skParam = [SoftkeyManager.skRemoveSubject, 
                     SoftkeyManager.skAddAttachment];
        } else {
          if (Settings.mmsEnable) {
            skParam = [SoftkeyManager.skAddSubject, 
                       SoftkeyManager.skAddAttachment];
          } else {
            skParam = [];
          }
        }
        if (!Compose.isEmpty()) {
          if (hasAttachment) {
            skParam = skParam.concat([SoftkeyManager.skRemoveAttachment]);
          }
          skParam = skParam.concat([SoftkeyManager.skSaveAsDraft, 
                                    SoftkeyManager.skCancelFromThread]);
        }
        break;
      }
      case this.FOCUS_ON_ATTACHMENT: {
        const attachmentMessage = document.getElementById('attachmentMessage');
        if (attachmentMessage.getAttribute('aria-hidden') === 'false') {
          AttachmentMessageUI.updateSKs();
          return;
        }

        if (SubjectUtils.isSubjectVisible()) {
          skParam = [SoftkeyManager.skAttachmentEnter, SoftkeyManager.skRemoveSubject, 
                     SoftkeyManager.skAddAttachment, SoftkeyManager.skRemoveAttachment];
        } else {
          skParam = [SoftkeyManager.skAttachmentEnter, SoftkeyManager.skAddSubject, 
                     SoftkeyManager.skAddAttachment, SoftkeyManager.skRemoveAttachment];
        }
        if (!Compose.disableSendButton() && SIMCardParam) {
          skParam = [SIMCardParam].concat(skParam);
        }
        skParam = skParam.concat([SoftkeyManager.skSaveAsDraft, 
                                  SoftkeyManager.skCancelFromThread]);
        break;
      }
      default:
        break;
    }

    SoftkeyManager.show(skParam);
  },

  getFocusState: function(focusEl) {
    const recipientList = document.getElementById('messages-recipients-list');
    const subjectField = document.getElementById('subject-composer-input');
    const inputField = document.getElementById('messages-input');
    let focusState = this.FOCUS_INVALID;

    if (focusEl.parentNode === recipientList) {
      focusState = this.FOCUS_ON_RECIPIENTS;
    } else if (focusEl === subjectField) {
      focusState = this.FOCUS_ON_SUBJECT;
    } else if (focusEl === inputField) {
      focusState = this.FOCUS_ON_MESSAGE_INPUT;
    } else if (focusEl.classList.contains('attachment-composer')) {
      focusState = this.FOCUS_ON_ATTACHMENT;
    }
    return focusState;
  },
};
