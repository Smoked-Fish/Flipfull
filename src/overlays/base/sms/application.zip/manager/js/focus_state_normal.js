/* global AttachmentManager, SendService, SoftkeyManager, Compose, SubjectUtils, 
          AttachmentMessageUI, OptionManager, DialogManager, Navigation, 
          ConversationEdit, ThreadUI, ActivityHandler, Settings, Utils */

'use strict';

// eslint-disable-next-line no-unused-vars
let FocusStateManager = {
  FOCUS_INVALID: 0,
  FOCUS_ON_RECIPIENTS: 1,
  FOCUS_ON_SUBJECT: 2,
  FOCUS_ON_MESSAGE_INPUT: 3,
  FOCUS_ON_MESSAGE_THREAD: 4,
  FOCUS_ON_ATTACHMENT: 5,

  // Softkey update according to state.
  dynamicSK: function() {
    if (OptionManager.isOptionMenuShown() || DialogManager.isDialogShown()) {
      // Because switch page speed is quicker than option shown, so need set forward mode.
      if (ThreadUI.isForwardMode) {
        ThreadUI.isForwardMode = false;
      } else {
        return;
      }
    }
    const currentFocus = document.querySelector('.focus');
    if (!currentFocus) {
      return;
    }
    if (document.activeElement.id !== currentFocus.id) {
      currentFocus.focus();
    }
    const focusState = this.getFocusState(currentFocus);
    if (Navigation.isCurrentPanel('composer')) {
      this.dynamicComposerSK(focusState);
    } else if (Navigation.isCurrentPanel('thread') && 
               !ConversationEdit.isInEditMode()) {
      this.dynamicThreadSK(focusState, currentFocus);
    } else if (Navigation.isCurrentPanel('settings-view')) {
      SoftkeyManager.updateSettingsSks();
    }
  },

  // New page situation.
  dynamicComposerSK: function(focusState) {
    let skParam;
    const hasAttachment = (AttachmentManager.getMessageCount() !== 0);
    const SIMCardParam = SendService.selectSIMSend();

    switch (focusState) {
      case this.FOCUS_INVALID:
        return;
      case this.FOCUS_ON_RECIPIENTS: {
        if (ThreadUI.selector.recipient.lastChild.textContent.length !== 0) {
          skParam = [SoftkeyManager.skEnter, SoftkeyManager.skAddContact];
        } else {
          skParam = [SoftkeyManager.skAddContact];
          if (!Compose.disableSendButton() && SIMCardParam) {
            skParam = [SIMCardParam].concat(skParam);
          }
        }
        break;
      }
      case this.FOCUS_ON_SUBJECT: {
        skParam = [SoftkeyManager.skRemoveSubject, SoftkeyManager.skAddAttachment];
        if (ActivityHandler.lastMessage) {
          skParam = [SoftkeyManager.skLastMessage];
        }
        if (!Compose.disableSendButton() && SIMCardParam) {
          skParam = [SIMCardParam].concat(skParam);
        }
        if (!Compose.isEmpty() && !ActivityHandler.lastMessage) {
          if (hasAttachment) {
            skParam = skParam.concat([SoftkeyManager.skRemoveAttachment]);
          }
          skParam = skParam.concat([SoftkeyManager.skSaveAsDraft, 
                                    SoftkeyManager.skCancelFromThread]);
        }
        break;
      }
      case this.FOCUS_ON_MESSAGE_INPUT: {
        if (!Compose.disableSendButton()) {
          if (SubjectUtils.isSubjectVisible()) {
            skParam = [SoftkeyManager.skRemoveSubject, SoftkeyManager.skAddAttachment];
          } else {
            if (Settings.mmsEnable) {
              skParam = [SoftkeyManager.skAddSubject, SoftkeyManager.skAddAttachment];
            } else {
              skParam = [];
            }
          }
          if (ActivityHandler.lastMessage) {
            skParam = [];
          }
          if (SIMCardParam) {
            skParam = [SIMCardParam].concat(skParam);
          }
        } else if (SubjectUtils.isSubjectVisible()) {
          skParam = [SoftkeyManager.skRemoveSubject, SoftkeyManager.skAddAttachment];
          if (ActivityHandler.lastMessage) {
            skParam = [];
          }           
        } else {
          if (Settings.mmsEnable) {
            skParam = [SoftkeyManager.skAddSubject, SoftkeyManager.skAddAttachment];
          } else {
            skParam = [];
          }
          if (ActivityHandler.lastMessage) {
            skParam = [];
          }
        }
        if (!Compose.isEmpty() && !ActivityHandler.lastMessage) {
          if (hasAttachment) {
            skParam = skParam.concat([SoftkeyManager.skRemoveAttachment]);
          }
          skParam = skParam.concat([SoftkeyManager.skSaveAsDraft, 
                                    SoftkeyManager.skCancelFromThread]);
        }
        break;
      }
      case this.FOCUS_ON_ATTACHMENT: {
        const attachmentMessage = document.getElementById('attachmentMessage');
        if (attachmentMessage.getAttribute('aria-hidden') === 'false') {
          AttachmentMessageUI.updateSKs();
          return;
        }
        if (SubjectUtils.isSubjectVisible()) {
          skParam = [SoftkeyManager.skAttachmentEnter, SoftkeyManager.skRemoveSubject, 
                     SoftkeyManager.skAddAttachment, SoftkeyManager.skRemoveAttachment];
        } else {
          skParam = [SoftkeyManager.skAttachmentEnter, SoftkeyManager.skAddSubject, 
                     SoftkeyManager.skAddAttachment, SoftkeyManager.skRemoveAttachment];
        }
        if (ActivityHandler.lastMessage) {
          skParam = [SoftkeyManager.skAttachmentEnter];
        }
        if (!Compose.disableSendButton() && SIMCardParam) {
          skParam = [SIMCardParam].concat(skParam);
        }
        if (!ActivityHandler.lastMessage) {
          skParam = skParam.concat([SoftkeyManager.skSaveAsDraft, 
                                    SoftkeyManager.skCancelFromThread]);
        }
        break;
      }
      default:
        break;
    }

    SoftkeyManager.show(skParam); 
  },

  // Bubble page situation.
  dynamicThreadSK: function(focusState, focusEl) {
    if (OptionManager.contactPromptOptionMenuShown) {
      return;
    }

    let skParam;
    const hasAttachment = (AttachmentManager.getMessageCount() !== 0);
    const SIMCardParam = SendService.selectSIMSend();
    const callOrEmailKey = 
      SoftkeyManager.updateCallOrEmail().concat([SoftkeyManager.skDeleteThreadFormThread]);

    switch (focusState) {
      case this.FOCUS_INVALID:
        return;
      case this.FOCUS_ON_SUBJECT: {
        skParam = [SoftkeyManager.skRemoveSubject, SoftkeyManager.skAddAttachment,
                   SoftkeyManager.skSelectMessages].concat(callOrEmailKey);
        if (!Compose.isEmpty()) {
          if (hasAttachment) {
            skParam = [SoftkeyManager.skRemoveSubject, SoftkeyManager.skAddAttachment,
                       SoftkeyManager.skRemoveAttachment, 
                       SoftkeyManager.skSelectMessages].concat(callOrEmailKey);
          }
          if (SIMCardParam) {
            skParam = [SIMCardParam].concat(skParam);
          }
          skParam = skParam.concat([SoftkeyManager.skSaveAsDraft, 
                                    SoftkeyManager.skCancelFromThread]);
        }
        break;
      }
      case this.FOCUS_ON_MESSAGE_INPUT: {
        if (SubjectUtils.isSubjectVisible()) {
          skParam = [SoftkeyManager.skRemoveSubject, SoftkeyManager.skAddAttachment, 
                     SoftkeyManager.skSelectMessages].concat(callOrEmailKey);
          if (hasAttachment) {
            skParam = [SoftkeyManager.skRemoveSubject, SoftkeyManager.skAddAttachment, 
                       SoftkeyManager.skRemoveAttachment, 
                       SoftkeyManager.skSelectMessages].concat(callOrEmailKey);
          }
        } else {
          if (Settings.mmsEnable) {
            skParam = [SoftkeyManager.skAddSubject, SoftkeyManager.skAddAttachment, 
                       SoftkeyManager.skSelectMessages].concat(callOrEmailKey);
            if (hasAttachment) {
              skParam = [SoftkeyManager.skAddSubject, SoftkeyManager.skAddAttachment, 
                         SoftkeyManager.skRemoveAttachment, 
                         SoftkeyManager.skSelectMessages].concat(callOrEmailKey);
            }
          } else {
            skParam = [SoftkeyManager.skSelectMessages].concat(callOrEmailKey);
          }
        }
        if (ActivityHandler.lastMessage) {
          skParam = [SoftkeyManager.skLastMessage];
        }
        if (!Compose.isEmpty()) {
          if (SIMCardParam) {
            skParam = [SIMCardParam].concat(skParam);
          }
          if (!ActivityHandler.lastMessage) {
            skParam = skParam.concat([SoftkeyManager.skSaveAsDraft, 
                                      SoftkeyManager.skCancelFromThread]);
          }
        }
        break;
      }
      case this.FOCUS_ON_MESSAGE_THREAD: {
        ThreadUI._storeFocused = focusEl;
        skParam = [];
        // TaskGF5GDISH-2159-tingting.chao-on 2025/01/07-begin
        if(OperatorUtils.isATTFamily() && focusEl.classList.contains('received')){
          let messageId = ThreadUI.getFocusedMessageId(ThreadUI._storeFocused);
          let request = MessageManager.getMessage(messageId);
          request.onsuccess = (function() {
            let messageType = request.result.type;
            dump("Request sucess messageType= " + messageType);
            if (focusEl.tagName === 'LI' && focusEl.classList.contains('message') &&
            !focusEl.classList.contains('not-downloaded')) {
              if (Utils.getAChildFromMessage(focusEl)) {
                skParam = skParam.concat([SoftkeyManager.skLinkSelect]);
              }
            }
            if (focusEl.classList.contains('not-downloaded') &&
              !focusEl.classList.contains('expired')) {
              skParam = skParam.concat([SoftkeyManager.skDownload]);
              if (focusEl.classList.contains('pending')) {
                skParam = [SoftkeyManager.skNullSoft];
                return;
              }
            }
            if (focusEl.classList.contains('error') &&
              focusEl.classList.contains('outgoing')) {
              skParam = skParam.concat([SoftkeyManager.skResendThisMessage]);
            }
            if (!focusEl.classList.contains('not-downloaded')) {
              skParam = skParam.concat([SoftkeyManager.skForward]);
            }
            if (messageType == 'sms'){
              skParam = skParam.concat([SoftkeyManager.skSpamReport]);
            }
            skParam = skParam.concat([SoftkeyManager.skDeleteFromThread,
                                  SoftkeyManager.skViewMessageReport]);
            if (focusEl.classList.contains('pending')) {
              skParam = [SoftkeyManager.skNullSoft];
            }
            if (ActivityHandler.lastMessage) {
              skParam = [SoftkeyManager.skLastMessage];
            }
            SoftkeyManager.show(skParam);
          });
        } else {
          if (focusEl.tagName === 'LI' && focusEl.classList.contains('message') &&
            !focusEl.classList.contains('not-downloaded')) {
            if (Utils.getAChildFromMessage(focusEl)) {
              skParam = skParam.concat([SoftkeyManager.skLinkSelect]);
            }
          }
          if (focusEl.classList.contains('not-downloaded') &&
            !focusEl.classList.contains('expired')) {
            skParam = skParam.concat([SoftkeyManager.skDownload]);
            if (focusEl.classList.contains('pending')) {
              skParam = [SoftkeyManager.skNullSoft];
              break;
            }
          }
          if (focusEl.classList.contains('error') &&
              focusEl.classList.contains('outgoing')) {
            skParam = skParam.concat([SoftkeyManager.skResendThisMessage]);
          }
          if (!focusEl.classList.contains('not-downloaded')) {
            skParam = skParam.concat([SoftkeyManager.skForward]);
          }
          skParam = skParam.concat([SoftkeyManager.skDeleteFromThread,
                                  SoftkeyManager.skViewMessageReport]);
          if (focusEl.classList.contains('pending')) {
            skParam = [SoftkeyManager.skNullSoft];
          }
          if (ActivityHandler.lastMessage) {
            skParam = [SoftkeyManager.skLastMessage];
          }
        }
        break;
      }
      // TaskGF5GDISH-2159-tingting.chao-on 2025/01/07-end
      case this.FOCUS_ON_ATTACHMENT: {
        const attachmentMessage = document.getElementById('attachmentMessage');
        if (attachmentMessage.getAttribute('aria-hidden') === 'false') {
          AttachmentMessageUI.updateSKs();
          return;
        }
        if (SubjectUtils.isSubjectVisible()) {
          skParam = [SoftkeyManager.skAttachmentEnter, SoftkeyManager.skRemoveSubject, 
                     SoftkeyManager.skAddAttachment, SoftkeyManager.skRemoveAttachment,
                     SoftkeyManager.skSelectMessages].concat(callOrEmailKey);
        } else {
          skParam = [SoftkeyManager.skAttachmentEnter, SoftkeyManager.skAddSubject, 
                     SoftkeyManager.skAddAttachment, SoftkeyManager.skRemoveAttachment,
                     SoftkeyManager.skSelectMessages].concat(callOrEmailKey);
        }
        if (ActivityHandler.lastMessage) {
          skParam = [SoftkeyManager.skAttachmentEnter];
        }
        if (SIMCardParam) {
          skParam = [SIMCardParam].concat(skParam);
        }
        if (!ActivityHandler.lastMessage) {
          skParam = skParam.concat([SoftkeyManager.skSaveAsDraft, 
                                    SoftkeyManager.skCancelFromThread]);
        }
        break;
      }
      default:
        break;
    }

    SoftkeyManager.show(skParam);
  },

  getFocusState: function(focusEl) {
    const recipientList = document.getElementById('messages-recipients-list');
    const subjectField = document.getElementById('subject-composer-input');
    const inputField = document.getElementById('messages-input');
    let focusState = this.FOCUS_INVALID;

    if (focusEl.parentNode === recipientList) {
      focusState = this.FOCUS_ON_RECIPIENTS;
    } else if (focusEl === subjectField) {
      focusState = this.FOCUS_ON_SUBJECT;
    } else if (focusEl === inputField) {
      focusState = this.FOCUS_ON_MESSAGE_INPUT;
    } else if (Utils.getParents(focusEl, 'UL').classList.contains('message-list')) {
      focusState = this.FOCUS_ON_MESSAGE_THREAD;
    } else if (focusEl.classList.contains('attachment-composer')) {
      focusState = this.FOCUS_ON_ATTACHMENT;
     }
    return focusState;
  }
};
