/* global Utils, OptionMenu, SoftkeyManager, StateManager, Settings, ThreadUI,
   Contacts, ActivityPicker, Navigation, Threads, ValueDefault, NotificationBase,
   SendService */

'use strict';

let OptionManager = {
  optionMenu: null,
  contactPromptOptionMenuShown: false,

  isOptionMenuShown: function() {
    const optionMenuElement = document.getElementById('option-menu');
    // The reason for window.option.menuVisible is the option menu from softkey 
    // handle speed is quicker than message app handler.
    return (optionMenuElement && optionMenuElement.classList.contains('visible')) || 
           (window.option && window.option.menuVisible);
  },

  hideOptionMenu: function() {
    // Select option close.
    this.optionMenu && this.optionMenu.hide();
    // Softkey option close.
    window.option && window.option.hideMenu();
    this.contactPromptOptionMenuShown = false;
  },

  // Number select option menu.
  selectNumber: function(recipients, callback) {
    let params = {
      classes: ['group-menu', 'softkey'],
      header: Utils.translateString('select') || '',
      items: [],
      menuClassName: 'menu-button'
    };
    for (let recip of recipients) {
      if (recip) {
        params.items.push({
          name: recip,
          method: function() {
            callback(document.activeElement.textContent);
          },
        });
      }
    }
    this.optionMenu = new OptionMenu(params);
    this.optionMenu.show();
    SoftkeyManager.show([SoftkeyManager.skSelect]);
  },

  // SIM select option menu.
  simSelectOptions: function thui_simSelect(callback) {
    // If there is option menu, not create it again.
    if (this.isOptionMenuShown()) {
      return;
    }

    const conns = StateManager.getConnectionInterface();
    let items = [];
    let params = {
      classes: ['group-menu', 'softkey','message-sim-menu'],// Add "message-sim-menu" style by tingting.chao for GF5GTMO-7172 on 2025/04/30
      header: Utils.translateString('select') || '',
      items: null,
      menuClassName: 'menu-button'
    };

    // Begin by tingting.chao for GF5GTMO-7172 on 2025/04/30
    //SIM1 information
    const carrier0 = Settings.getOperatorByIccId(conns[0].iccId);
    const tmoOperatorName0 = Settings.getTmoSimName(conns[0].iccId); // Added by tingting.chao for GF5GTMO-7103 on 2025/04/15
    const phoneNumber0 = Settings.getPhoneNumber(conns[0].iccId);
    const carrierName0 = carrier0 ? carrier0 : tmoOperatorName0;
    const mcc0 = Settings.getMcc(conns[0].iccId);

    //SIM2 information
    const carrier1 = Settings.getOperatorByIccId(conns[1].iccId);
    const tmoOperatorName1 = Settings.getTmoSimName(conns[1].iccId); // Added by tingting.chao for GF5GTMO-7103 on 2025/04/15
    // Begin by tingting.chao for GF5GTMO-7172 on 2025/04/24
    const phoneNumber1 = Settings.getPhoneNumber(conns[1].iccId);
    const carrierName1 = carrier1 ? carrier1 : tmoOperatorName1;
    const mcc1 = Settings.getMcc(conns[1].iccId);
    Promise.all([
      PhoneNumberUtils.parseWithMCC(phoneNumber0, mcc0),
      PhoneNumberUtils.parseWithMCC(phoneNumber1, mcc1)]).then(([pNumber0, pNumber1]) => {
        let number0 = "";
        let nameAndNumber0 = carrierName0;
        if ( pNumber0 && pNumber0.internationalFormat && pNumber0.regionMetaData.countryCode){
          number0 = Settings.removeCountryCode(pNumber0.internationalFormat,pNumber0.regionMetaData.countryCode);
        }
        nameAndNumber0 = number0 ? carrierName0 + "  " + number0.replace(' ','\u00A0') : carrierName0;
        items.push({
          name: nameAndNumber0, // Modified by tingting.chao for GF5GTMO-7103,GF5GTMO-7172 on 2025/04/15
          method: function() {
            OptionManager.contactPromptOptionMenuShown = false;
            if (conns[0]) {
              if (callback) {
                callback(0);
              } else {
                SendService.simSelectedCallback(0);
              }
            }
          },
          disable: conns[0] ? false : true
        });

        let number1 = "";
        let nameAndNumber1 = carrierName1;
        if ( pNumber1 && pNumber1.internationalFormat && pNumber1.regionMetaData.countryCode){
          number1 = Settings.removeCountryCode(pNumber1.internationalFormat,pNumber1.regionMetaData.countryCode);
          nameAndNumber1 = number1 ? carrierName1 + "  " + number1.replace(' ','\u00A0') : carrierName1;
        }
        items.push({
          name: nameAndNumber1, // Modified by tingting.chao for GF5GTMO-7103,GF5GTMO-7172 on 2025/04/15
          method: function() {
            OptionManager.contactPromptOptionMenuShown = false;
            if (conns[1]) {
              if (callback) {
                callback(1);
              } else {
                SendService.simSelectedCallback(1);
              }
            }
          },
          disable: conns[1] ? false : true
        });
        params.items = items;

        this.optionMenu = new OptionMenu(params);
        this.optionMenu.show();
        this.contactPromptOptionMenuShown = true;
        setTimeout(() => {
          SoftkeyManager.show([SoftkeyManager.skSelect]);
        });
	});
    // End by tingting.chao for GF5GTMO-7172 on 2025/04/30

  },

  // Call select option menu.
  switchCallOption: function(keyOne, keyTwo, callback) {
    let items = [];
    let params = {
      classes: ['group-menu', 'softkey'],
      header: Utils.translateString('select') || '',
      items: null,
      menuClassName: 'menu-button'
    };

    items.push({
      l10nId: keyOne,
      method: function() {
        OptionManager.contactPromptOptionMenuShown = false;
        callback(false);
      }
    });

    items.push({
      l10nId: keyTwo,
      method: function() {
        OptionManager.contactPromptOptionMenuShown = false;
        callback(true);
      }
    });

    params.items = items;

    this.optionMenu = new OptionMenu(params);
    this.optionMenu.show();
    this.contactPromptOptionMenuShown = true;
    SoftkeyManager.show([SoftkeyManager.skSelect]);
  },

  // Recipients select option menu.
  recipientsSelectOption: function(data, tag, isRTT) {
    let items = [];
    let params = {
      classes: ['group-menu', 'softkey'],
      header: Utils.translateString('select') || '',
      items: null,
      menuClassName: 'menu-button'
    };

    let asyncTask = [];
    for (let i = 0; i < data.length; i++) {
      let newTask = () => new Promise((resolve) => {
        Contacts.findByAddress(data[i], (result) => {
          let recipient;
          if (result.length && result[0].name && result[0].name[0]) {
            // DefectGF5GTMO-4996-tingting.chao-begin
            //recipient = result[0].name[0];
            recipient = result[0].name;
            // DefectGF5GTMO-4996-tingting.chao-end
          } else {
            recipient = data[i];
          }

          items.push({
            name: recipient,
            method: function() {
              if (tag === 'call') {
                ActivityPicker.dial(data[i], false, isRTT);
              } else if (tag === 'email') {
                ActivityPicker.email(data[i]);
              }

              OptionManager.contactPromptOptionMenuShown = false;
            }
          });

          resolve();
        });
      });

      asyncTask.push(newTask());
    }

    Promise.all(asyncTask).then(() => {
      params.items = items;
      this.optionMenu = new OptionMenu(params);
      this.optionMenu.show();
      OptionManager.contactPromptOptionMenuShown = true;
      tag === 'call' ? SoftkeyManager.show([SoftkeyManager.skCallAction]) :
                       SoftkeyManager.show([SoftkeyManager.skEmailAction]);
    });
  },

  // Select option.
  prompt: function(opt) {
    if (OptionManager.isOptionMenuShown()) {
      return;
    }

    const complete = (() => {
      if (ValueDefault.isFromNotification) {
        return;
      }
      if (!Navigation.isCurrentPanel('thread')) {
        Navigation.toPanel('thread', { id: Threads.currentId });
      }
    });

    const thread = Threads.get(Threads.currentId);
    const number = opt.number || '';
    const email = opt.email || '';
    const isContact = opt.isContact || false;
    const inMessage = opt.inMessage || false;
    const contact = opt.contact;
    const focusElement = document.activeElement;
    let header = opt.header;
    let items = [];
    let params, props;

    if (!header && (number || email)) {
      header = document.createElement('bdi');
      header.className = 'unknown-contact-header';
      header.textContent = number || email;
    }

    params = {
      classes: ['group-menu', 'softkey'],
      complete: complete,
      header: header || '',
      items: null,
      menuClassName: 'menu-button'
    };

    if (!email && !ValueDefault.isFromNotification) {
      if ((thread && thread.participants.length > 1) || inMessage) {
        items.push({
          l10nId: 'sendMessage',
          method: function oMessage(number, contact) {
            ThreadUI.composerContainer.classList.remove('next-focus');
            document.querySelector('.current-focus').classList.remove('current-focus');
            ActivityPicker.sendMessage(number, contact);
            OptionManager.contactPromptOptionMenuShown = false;
          },
          params: [number, contact],
          incomplete: true
        });
      }
    }
    params.items = items;

    if (!isContact) {
      props = [ number ? { tel: number } : { email: email } ];
      params.items.push({
        l10nId: 'createNewContact',
        method: function oCreate(param) {
          ActivityPicker.createNewContact(
            param, () => {
              ValueDefault.isFromNotification ? NotificationBase._onCreateContact() : 
                                                ThreadUI._onCreateContact();
              focusElement.focus();
            }
          );
          OptionManager.contactPromptOptionMenuShown = false;
        },
        params: props
      }, {
        l10nId: 'addToExistingContact',
        method: function oAdd(param) {
          ActivityPicker.addToExistingContact(
            param, () => {
              ValueDefault.isFromNotification ? NotificationBase._onCreateContact() : 
                                                ThreadUI._onCreateContact();
              focusElement.focus();
            }
          );
          OptionManager.contactPromptOptionMenuShown = false;
        },
        params: props
      });
    }

    if (opt.contactId) {
      props = [{ id: opt.contactId }];
      params.items.push({
        l10nId: 'viewContact',
        method: function oView(param) {
          ActivityPicker.viewContact(param, () => {
            (ValueDefault.isFromNotification || Navigation.isCurrentPanel('thread')) && 
            SoftkeyManager.updateLinkSKs();
            focusElement.focus();
          });
          OptionManager.contactPromptOptionMenuShown = false;
        },
        params: props
      });
    }

    if (params.items.length === 0) {
      return;
    }

    this.optionMenu = new OptionMenu(params);
    this.optionMenu.show();
    OptionManager.contactPromptOptionMenuShown = true;
    SoftkeyManager.show([SoftkeyManager.skSelect]);
  }
};
