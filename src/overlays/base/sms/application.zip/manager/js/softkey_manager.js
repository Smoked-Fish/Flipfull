/* global Navigation, Utils, DeleteManager, ContactsServiceManager, ActivityPicker,
          InboxEdit, ThreadListUI, ActivityHandler, SendService, ThreadUI, FocusManager,
          ConversationEdit, AttachmentMessageUI, ContactsUtils, RecipientUtils,
          Recipients, SubjectUtils, StateManager, DialogManager, ValueDefault,
          AttachmentManager, CallManager, Threads, OptionManager, DraftUtils,
          Compose, RecipientManager, ReportView, SendManager, EventManager,
          NavigationMap, SearchMessageUI, SoftkeyPanel, Startup, Settings, ActivityModule */

'use strict';

let SoftkeyManager = {
  init: function() {
    // thread list softkey map.
    this.skNewMessage = {
      l10nId: 'new-message',
      priority: 1,
      method: function() {
        Navigation.toPanel('composer');
      }
    };

    this.skDeleteThread = {
      l10nId: 'delete-thread',
      priority: 5,
      method: function() {
        Utils.speedPressPrevent(() => {
          DeleteManager.deleteCurrentThread();
        });
      }
    };

    this.skCreateNewContact = {
      l10nId: 'create-new-contact',
      priority: 5,
      method: function() {
        ContactsServiceManager.handleContactFromList((formatNumber) => {
          ActivityPicker.createNewContact(formatNumber, () => {
            SoftkeyManager.updateSKs();
          });
        });
      }
    };

    this.skAddToContact = {
      l10nId: 'add-to-contact',
      priority: 5,
      method: function() {
        ContactsServiceManager.handleContactFromList((formatNumber) => {
          ActivityPicker.addToExistingContact(formatNumber, () => {
            SoftkeyManager.updateSKs();
          });
        });
      }
    };

    this.skSelectThread = {
      l10nId: 'select-thread',
      priority: 5,
      method: function() {
        InboxEdit.startEdit();
      }
    };

    this.skSettings = {
      l10nId: 'settings',
      priority: 5,
      method: function() {
        Navigation.toPanel('settings-view');
      }
    };


    //Porting from PR-11492884-[ATT:CDR-MSG-1160]-renlongou on 2024/09/07-begin
    this.skAllMessageRead = {
      l10nId: 'mark-all-message-as-read',
      priority: 5,
      method: function() {
        ThreadListUI.markAllMessageAsRead();
      }
    };
    //Porting from PR-11492884-[ATT:CDR-MSG-1160]-renlongou on 2024/09/07-end

    this.skSearch = {
      l10nId: 'search',
      priority: 5,
      method: function() {
        Navigation.toPanel('search-message-view');
      }
    };

    // Thread list edit mode softkey map.
    this.skSelectAll = {
      l10nId: 'select-all',
      priority: 1,
      method: function() {
        InboxEdit.allActionHandle();
      }
    };

    this.skDeselectAll = {
      l10nId: 'deselect-all',
      priority: 1,
      method: function() {
        InboxEdit.allActionHandle();
      }
    };

    this.skDeSelect = {
      l10nId: 'deselect',
      priority: 2
    };

    this.skDelete = {
      l10nId: 'delete',
      priority: 3,
      method: function() {
        DeleteManager.deleteSelectedList();
      }
    };

    // Activity softkey map.
    this.skLastMessage = {
      l10nId: 'last-message',
      priority: 2
    };

    this.skCancel = {
      l10nId: 'cancel',
      priority: 1,
      method: function() {
        ThreadListUI.cacheAction();
        ActivityHandler.leaveActivity({ data: null });
      }
    };

    this.skWait = {
      l10nId: 'wait',
      priority: 2
    };

    // Thread message softkey map.
    this.skSend = {
      l10nId: 'send',
      priority: 2,
      method: function() {
        SendService.startSendMessage();
      }
    };

    this.skSendSIM1 = {
      l10nId: 'send',
      icon: 'sim-1',
      iconMixedText: true,
      priority: 2,
      method: function () {
        SendService.startSendMessage();
      }
    };

    this.skSendSIM2 = {
      l10nId: 'send',
      icon: 'sim-2',
      iconMixedText: true,
      priority: 2,
      method: function () {
        SendService.startSendMessage();
      }
    };

    this.skLinkSelect = {
      l10nId: 'select',
      priority: 2,
      method: function () {
        ThreadUI.isLinkMode = true;
        FocusManager.findLinkFocus();
      }
    };

    this.skSelectMessages = {
      l10nId: 'select-messages',
      priority: 5,
      method: function() {
        ConversationEdit.selectMessages();
      }
    };

    this.skAttachmentEnter = {
      l10nId: 'view',
      priority: 1,
      method: function () {
        AttachmentMessageUI.enterAttachmentPage();
      }
    };

    this.skAttachmentOpen = {
      l10nId: 'open',
      priority: 2,
      method: function () {
        FocusManager.doLinkAction('attachment');
      }
    };

    this.skDialOpen = {
      l10nId: 'call',
      priority: 2,
      method: function () {
        FocusManager.doLinkAction('dial');
      }
    };

    this.skRTTDialOpen = {
      l10nId: 'rtt-call',
      priority: 2,
      method: function () {
        FocusManager.doLinkAction('rtt-dial');
      }
    };

    this.skSelectDialOpen = {
      l10nId: 'call',
      priority: 2,
      method: function () {
        FocusManager.doLinkAction('select-dial');
      }
    };

    this.skEmailOpen = {
      l10nId: 'email',
      priority: 2,
      method: function () {
        FocusManager.doLinkAction('email');
      }
    };

    this.skUrlOpen = {
      l10nId: 'open',
      priority: 2,
      method: function () {
        FocusManager.doLinkAction('url');
      }
    };

    this.skCallAction = {
      l10nId: 'call',
      priority: 2,
      method: function () {
        // eslint-disable-next-line no-undef
        secondCall = false;
      }
    };

    this.skEmailAction = {
      l10nId: 'email',
      priority: 2,
      method: function () {
        // eslint-disable-next-line no-undef
        secondCall = false;
      }
    };

    this.skOption = {
      l10nId: 'options',
      priority: 3,
      method: function () {
        let focused = document.querySelector('.focus');
        let linkType = ThreadUI.listenLinkElement(focused);
        ThreadUI.openLinkFocus(linkType.replace('-link', ''));
      }
    };

    this.skAddContact = {
      l10nId: 'add-contact',
      icon: 'add-contact',
      iconMixedText: true,
      iconReverse: true,
      priority: 1,
      method: function() {
        ContactsUtils.requestContact();
      }
    };

    this.skAddSuggestion = {
      l10nId: 'add-suggestion',
      priority: 2,
      method: function() {
        RecipientUtils.selectRecipientSuggestion();
        Recipients.View.suggest = true;
      }
    };

    this.skDownload = {
      l10nId: 'download-attachment',
      priority: 2
    };

    this.skAddSubject = {
      l10nId: 'add-subject',
      priority: 5,
      method: function() {
        SubjectUtils.subjectPreHandle();
      }
    };

    this.skRemoveSubject = {
      l10nId: 'remove-subject',
      priority: 5,
      method: function() {
        SubjectUtils.subjectPreHandle();
      }
    };

    this.skAddAttachment = {
      l10nId: 'add-attachment',
      priority: 5,
      method: function() {
        // To confirm read out normal, need make the focus in order.
        document.addEventListener('transitionend', function optionMenu() {
          document.removeEventListener('transitionend', optionMenu);
          if (StateManager.isDiskFull) {
            DialogManager.alertFreeSpace('attachment');
          } else {
            AttachmentManager.onAttachClick();
          }
        });
      }
    };

    this.skRemoveAttachment = {
      l10nId: 'remove-all-attachments',
      priority: 5,
      method: function() {
        AttachmentManager.deleteAttachment();
      }
    };

    this.skCall = {
      l10nId: 'call',
      priority: 5,
      method: function() {
        CallManager.majorCall(false);
      }
    };

    this.skRTTCall = {
      l10nId: 'rtt-call',
      priority: 5,
      method: function() {
        CallManager.majorCall(true);
      }
    };

    this.skEmail = {
      l10nId: 'email',
      priority: 5,
      method: function() {
        let mailElement = [];
        for (let i = 0; i < Threads.active.participants.length; i++) {
          if (Utils.isEmailAddress(Threads.active.participants[i])) {
            mailElement.push(Threads.active.participants[i]);
          }
        }

        // If only one recipient, email directly, else show select dialog.
        if (mailElement.length > 1) {
          OptionManager.recipientsSelectOption(mailElement, 'email');
        } else {
          ActivityPicker.email(mailElement[0]);
        }
      }
    };

    this.skDeleteThreadFormThread = {
      l10nId: 'delete-thread',
      priority: 5,
      method: function() {
        Utils.speedPressPrevent(() => {
          ThreadUI.notFocus = true;
          DeleteManager.deleteCurrentThreadFromThread('threadMode');
          ThreadUI.disableConvertNoticeBanners();
        });
      }
    };

    this.skSaveAsDraft = {
      l10nId: 'sk-save-as-draft',
      priority: 5,
      method: function() {
        DraftUtils.saveDraft({ keyFlag: 'saveDraft' }, (draft) => {
          if (ValueDefault.activitymode) {
            ActivityHandler.leaveActivity({ data: draft });
          } else {
            ValueDefault.draftSaveId = Threads.currentId || draft.id;
            Navigation.toPanel('thread-list');
          }
        });
      }
    };

    this.skCancelFromThread = {
      l10nId: 'cancel',
      priority: 5,
      method: function() {
        if (ValueDefault.activitymode) {
          ActivityModule.back();
        } else {
          ThreadUI.back();
        }
      }
    };

    this.skForward = {
      l10nId: 'forward',
      priority: 5,
      method: function() {
        const targetItem = ThreadUI._storeFocused;
        const messageId = ThreadUI.getFocusedMessageId(targetItem);
        if (Compose.isEmpty()) {
          ThreadUI.forwardMessage(messageId);
        } else {
          if (DraftUtils.draft && !DraftUtils.draft.isEdited) {
            if (!Threads.currentId) {
              DraftUtils.saveDraft({ autoSave: true });
            } else {
              DraftUtils.draft = null;
            }
            ThreadUI.forwardMessage(messageId);
          } else {
            DialogManager.confirmAlert('confirmation-title', 'draft-save-content',
                                       'cancel', null, 'save-as-draft', () => {
              DraftUtils.saveDraft({ keyFlag: 'saveDraft' }, () => {
                ThreadUI.forwardMessage(messageId);
              });
            }, 'discard-message', () => {
              RecipientManager.assimilateRecipients('false');
              DraftUtils.discardDraft();
              ThreadUI.forwardMessage(messageId);
            });
          }
        }
      }
    };

    // TaskGF5GDISH-2159-tingting.chao-on 2025/01/07-begin
    this.skSpamReport = {
      l10nId: 'spam-report',
      priority: 5,
      method: function() {
      DialogManager.confirmAlert('confirmation-title', 'spam-confirm-content',
                                   'cancel', null, null, null, 'spam-confirm', () => {
          let targetItem = ThreadUI._storeFocused;
          let messageId = ThreadUI.getFocusedMessageId(targetItem);
          ThreadUI.forwardMessage(messageId);
          setTimeout(function() {
            RecipientManager.recipients.add({
                              number: '7726',
                              source: 'manual'
            });
          },500);
        });
      }
    };
    // TaskGF5GDISH-2159-tingting.chao-on 2025/01/07-end

    this.skViewMessageReport = {
      l10nId: 'view-message-report',
      priority: 5,
      method: function() {
        const targetItem = ThreadUI._storeFocused;
        const messageId = ThreadUI.getFocusedMessageId(targetItem);
        window.addEventListener('participants-done', function updateInformation() {
          window.removeEventListener('participants-done', updateInformation);
          ReportView.container.focus();
          SoftkeyManager.updateInformationSks();
        });
        Navigation.toPanel('report-view', {
          id: messageId,
          threadId: Threads.currentId
        });
      }
    };

    this.skDeleteFromThread = {
      l10nId: 'delete',
      priority: 5,
      method: function() {
        Utils.speedPressPrevent(() => {
          if (1 === ConversationEdit.getAllInputs().length) {
            const messageId = ThreadUI.getFocusedMessageId(ThreadUI._storeFocused);
            DeleteManager.deleteCurrentThreadFromThread('messageMode', messageId);
          } else {
            DeleteManager.deleteSingleMessage();
          }
        });
      }
    };

    this.skResendThisMessage = {
      l10nId: 'resend-message',
      priority: 5,
      method: function() {
        const targetItem = ThreadUI._storeFocused;
        const messageId = ThreadUI.getFocusedMessageId(targetItem);
        SendManager.resendMessage(messageId);
      }
    };

    this.skCancelToThread = {
      l10nId: 'cancel',
      priority: 1,
      method: function() {
        ThreadUI.isLinkMode = false;
        ThreadUI.composerContainer.classList.remove('next-focus');
        const bubbleLi = document.querySelector('.current-focus');
        bubbleLi.classList.remove('bubble-link-focus');
        bubbleLi.classList.remove('current-focus');
        EventManager.cancelToThread();
      }
    };

    // Conversation edit map.
    this.skSelectAllFormThread = {
      l10nId: 'select-all',
      priority: 1,
      method: function() {
        ConversationEdit.allActionHandle();
      }
    };

    this.skDeselectAllFromThread = {
      l10nId: 'deselect-all',
      priority: 1,
      method: function() {
        ConversationEdit.allActionHandle();
      }
    };

    this.skSelectDelete = {
      l10nId: 'delete',
      priority: 3,
      method: function() {
        if (ConversationEdit.isInEditMode()) {
          let selected = ConversationEdit.selectionHandler.selectedCount;
          if (selected === ConversationEdit.getAllInputs().length) {
            DeleteManager.deleteCurrentThreadFromThread('editMode');
          } else {
            DeleteManager.delete();
          }
        }
      }
    };

    this.skWaitFormThread = {
      l10nId: 'wait',
      priority: 1
    };

    // Information view map.
    this.skCancelViewReport = {
      l10nId: 'cancel-view-report',
      priority: 1,
      method: function() {
        ThreadUI.isBackToThreadUI = true;
        Navigation.toPanel('thread', { id: Threads.currentId });
        NavigationMap.disableNav = false;
      }
    };

    this.skBlockContacts = {
      l10nId: 'blocked',
      priority: 3,
      method: function() {
        const contactList =
          document.getElementById('information-report').querySelector('.contact-list');
        const suggestionList = contactList.querySelectorAll('.suggestion');
        DialogManager.confirmAlert('confirmation-title', 'block-confirmation', 'cancel', () => {
          ReportView.container.focus();
        }, null, null, 'blocked', () => {
          for (let i = 0; i < suggestionList.length; i++) {
            const nodeContact = suggestionList[i].getAttribute('data-number');
            ContactsServiceManager.blockNumbers(nodeContact, (value) => {
              if (value) {
                suggestionList[i].classList.add('suggestion-adjust');
                suggestionList[i].parentNode.classList.add('block-tag');
              }
            });
          }
          ReportView.container.focus();
          SoftkeyManager.show([SoftkeyManager.skCancelViewReport,
                               SoftkeyManager.skUnblockContacts]);
        }, () => {
          ReportView.container.focus();
        });
      }
    };

    this.skUnblockContacts = {
      l10nId: 'unblocked',
      priority: 3,
      method: function() {
        const contactList =
          document.getElementById('information-report').querySelector('.contact-list');
        const suggestionList = contactList.querySelectorAll('.suggestion');
        for (let i = 0; i < suggestionList.length; i++) {
          const nodeContact = suggestionList[i].getAttribute('data-number');
          ContactsServiceManager.unblockNumbers(nodeContact, (value) => {
            if (value) {
              suggestionList[i].classList.remove('suggestion-adjust');
              suggestionList[i].parentNode.classList.remove('block-tag');
            }
          });
        }
        SoftkeyManager.show([SoftkeyManager.skCancelViewReport,
                             SoftkeyManager.skBlockContacts]);
      }
    };

    // Attachment softkey map.
    this.skCancelFromAttachment = {
      l10nId: 'cancel',
      priority: 1,
      method: function() {
        AttachmentMessageUI.resetPageStatus();
      }
    };

    this.skOpenFromAttachment = {
      l10nId: 'open',
      priority: 2,
      method: function() {
        const focusEle =
          AttachmentMessageUI.attachmentContainer.querySelector('.focus');
        AttachmentManager.openAttachment(focusEle);
      }
    };

    this.skAddAttachmentFromAttachment = {
      l10nId: 'add-attachment',
      priority: 5,
      method: function() {
        const req = AttachmentManager.requestAttachment();
        req.onsuccess = (item) => {
          AttachmentManager.addAttachments(item, () => {
            // Need update the attachment list to sync the latest attachment count number.
            AttachmentMessageUI.updateAttachmentList();
            AttachmentMessageUI.removeFocus(AttachmentMessageUI.focusCount);
            AttachmentMessageUI.focusCount =
              AttachmentMessageUI.attachmentList.length - 1;
            AttachmentMessageUI.setFocus(AttachmentMessageUI.focusCount);
            AttachmentMessageUI.attachmentList[AttachmentMessageUI.focusCount].
              parentNode.scrollIntoView(false);
          });
        };
        req.onerror = (err) => {
          AttachmentManager._onAttachmentRequestError(err);
          AttachmentMessageUI.setFocus(AttachmentMessageUI.focusCount);
        };
      }
    };

    this.skRemoveAttachmentFromAttachment = {
      l10nId: 'remove-attachment',
      priority: 5,
      method: function() {
        const count = AttachmentMessageUI.focusCount;
        const attachmentList = AttachmentMessageUI.attachmentList;
        const focusEle = attachmentList[count];

        AttachmentManager.removeAttachment(focusEle, () => {
          AttachmentMessageUI.updateAttachmentList();
          AttachmentManager.updateAttachmentAbstract();
          window.addEventListener('menuEvent',
            AttachmentMessageUI.updateOptionsBackUp);
        });
      }
    };

    this.skReplaceAttachmentFromAttachment = {
      l10nId: 'replace-attachment',
      priority: 5,
      method: function() {
        const count = AttachmentMessageUI.focusCount;
        const attachmentList = AttachmentMessageUI.attachmentList;
        const focusEle = attachmentList[count];
        AttachmentManager.replaceAttachment(focusEle);
      }
    };

    // Search field.
    this.skCancelFormSearch = {
      l10nId: 'cancel',
      priority: 1,
      method: function() {
        SearchMessageUI.searchList.innerHTML = '';
        SearchMessageUI.searchInput.value = '';
        Navigation.toPanel('thread-list');
      }
    };

    // Settings field.
    this.skSettingsOK = {
      l10nId: 'select',
      priority: 2
    };

    // Common softkey map.
    this.skSelect = {
      l10nId: 'select',
      priority: 2,
      method: function() {
        // eslint-disable-next-line no-undef
        secondCall = false;
      }
    };

    this.skEnter = {
      l10nId: 'enter',
      priority: 2,
      method: function() {
        // eslint-disable-next-line no-undef
        secondCall = false;
      }
    };

    this.skNullSoft = {
      l10nId: 'null',
      priority: 2
    };
  },

  // Create softkey panel.
  show: function(keys) {
    const softkeyParams = {
      header: { l10nId: 'options' },
      items: keys
    };

    if (window.option) {
      window.option.initSoftKeyPanel(softkeyParams);
    } else {
      window.option = new SoftkeyPanel(softkeyParams);
    }

    window.option.show();

    this.removeSoftKeyCache();
  },

  // Init softkey from normal launch.
  initSks: function() {
    if (!Startup.useCache && Navigation.isCurrentPanel('thread-list')) {
      this.show([this.skNewMessage, this.skSettings]);
    } else {
      this.updateSKs();
    }
  },

  // Common softkey update.
  updateSKs: function() {
    let threadid = null;

    if (!Navigation.isCurrentPanel('thread-list')) {
      return;
    }
    if (document.getElementById('loading').classList.contains('show-loading')) {
      return;
    }
    if (OptionManager.isOptionMenuShown()) {
      return;
    }
    if (DialogManager.isDialogShown()) {
      return;
    }
    if (InboxEdit.isInEditMode()) {
      return;
    }

    if (FocusManager.currentThread) {
      threadid = FocusManager.currentThread.dataset.threadId;
    }

    if (ActivityHandler.lastMessage && Navigation.isCurrentPanel('thread-list')) {
      if (ThreadListUI.noMessages.classList.contains('hide')) {
        this.show([this.skCancel, this.skSelect]);
      } else {
        ThreadListUI.noResultMessage.querySelector('p').classList.add('hide');
        this.show([this.skCancel]);
      }
      return;
    }

    if (ThreadListUI.noMessages.classList.contains('hide')) {
      if (threadid) {
        const contactArray = ContactsServiceManager.judgeContactCount();
        if (contactArray.length === 0) {
          //Porting from PR-11492884-[ATT:CDR-MSG-1160]-renlongou on 2024/09/07-begin
          if(OperatorUtils.isATTFamily()){
            this.show([this.skNewMessage, this.skSelect, this.skDeleteThread,
              this.skSelectThread, this.skSearch, this.skSettings,this.skAllMessageRead]);
          } else {
            this.show([this.skNewMessage, this.skSelect, this.skDeleteThread,
              this.skSelectThread, this.skSearch, this.skSettings]);
          }
        } else {
          if(OperatorUtils.isATTFamily()){
            this.show([this.skNewMessage, this.skSelect, this.skDeleteThread,
              this.skCreateNewContact, this.skAddToContact,
              this.skSelectThread, this.skSearch, this.skSettings,this.skAllMessageRead]);
          } else {
            this.show([this.skNewMessage, this.skSelect, this.skDeleteThread,
              this.skCreateNewContact, this.skAddToContact,
              this.skSelectThread, this.skSearch, this.skSettings]);
          }
          //Porting from PR-11492884-[ATT:CDR-MSG-1160]-renlongou on 2024/09/07-end
        }
      }
    } else {
      this.show([this.skNewMessage, this.skSettings]);
    }
  },

  // Link sofykey update.
  updateLinkSKs: function() {
    let focused = document.querySelector('.focus');
    let skparam = null;
    if (!focused) {
      return;
    }
    if ((focused.tagName === 'A' || focused.tagName === 'DIV') &&
         Utils.getParents(focused, 'LI').classList.contains('message')) {
      ThreadUI.composerContainer.classList.add('next-focus');
      Utils.getParents(focused, 'LI').classList.add('current-focus');
      skparam = [this.skCancelToThread];
      const linkType = ThreadUI.listenLinkElement(focused);
      switch (linkType) {
        case 'attachment':
          skparam = skparam.concat([this.skAttachmentOpen]);
          break;
        case 'dial-link':
          if (Settings.RTTEnable) {
            if (Settings.RTTPreferred === 'always-visible-automatic') {
              skparam = skparam.concat([this.skRTTDialOpen]);
            } else if (Settings.RTTPreferred === 'always-visible-manual') {
              skparam = skparam.concat([this.skSelectDialOpen]);
            } else {
              skparam = skparam.concat([this.skDialOpen]);
            }
          } else {
            skparam = skparam.concat([this.skDialOpen]);
          }
          skparam = skparam.concat([this.skOption]);
          break;
        case 'url-link':
          skparam = skparam.concat([this.skUrlOpen]);
          break;
        case 'email-link':
          if (Settings.emailAppInstalled) {
            skparam = skparam.concat([this.skEmailOpen]);
          }
          skparam = skparam.concat([this.skOption]);
          break;
      }
      this.show(skparam);
    }
  },

  // Call or email softkey update.
  updateCallOrEmail: function() {
    // Need consider three situations.
    // 1. Only email address -> only email option.
    // 2. Only phone address -> only phone option.
    // 3. Both of email and phone exist -> email and phone option.
    let hasEmail = false;
    let hasPhone = false;
    let lastSoftKey = [];
    for (let i = 0; i < Threads.active.participants.length; i++) {
      if (Utils.isEmailAddress(Threads.active.participants[i])) {
        if (Settings.emailAppInstalled) {
          hasEmail = true;
        }
      } else {
        hasPhone = true;
      }
    }

    if (hasPhone) {
      if (!Settings.RTTEnable) {
        lastSoftKey = [SoftkeyManager.skCall];
      } else {
        switch (Settings.RTTPreferred) {
          case 'visible-during-calls':
            lastSoftKey = [SoftkeyManager.skCall];
            break;
          case 'always-visible-automatic':
            lastSoftKey = [SoftkeyManager.skRTTCall];
            break;
          case 'always-visible-manual':
            lastSoftKey = [SoftkeyManager.skCall, SoftkeyManager.skRTTCall];
            break;
        }
      }
    }

    if (hasEmail) {
      lastSoftKey = [SoftkeyManager.skEmail].concat(lastSoftKey);
    }

    return lastSoftKey;
  },

  // Call select softkey update.
  updateCallKey: function () {
    if (Settings.RTTEnable) {
      if (Settings.RTTPreferred === 'always-visible-automatic') {
        this.show([this.skCancelToThread, this.skRTTDialOpen, this.skOption]);
        return;
      } else if (Settings.RTTPreferred === 'always-visible-manual') {
        this.show([this.skCancelToThread, this.skSelectDialOpen, this.skOption]);
        return;
      }
    }
    this.show([this.skCancelToThread, this.skDialOpen, this.skOption]);
  },

  // Recipients softkey update.
  updateSksOnRecipientChanged: function(lenght) {
    if (lenght === 0) {
      this.show([this.skAddContact]);
    } else {
      this.show([this.skEnter, this.skAddContact]);
    }
  },

  // Attachment softkey update.
  updateAttachmentKey: function() {
    this.show([this.skCancelFromAttachment, this.skOpenFromAttachment,
               this.skAddAttachmentFromAttachment, this.skRemoveAttachmentFromAttachment,
               this.skReplaceAttachmentFromAttachment]);
  },

  // Detail softkey update.
  updateInformationSks: function() {
    ContactsUtils.pickContactsDetail().then((contacts) => {
      if (contacts[0].length === contacts[1].length) {
        this.show([this.skCancelViewReport, this.skUnblockContacts]);
      } else {
        this.show([this.skCancelViewReport, this.skBlockContacts]);
      }
    });
  },

  // Search softkey update.
  updateSearchSks: function(isFocus) {
    isFocus ? this.show([this.skCancelFormSearch]) :
              this.show([this.skCancelFormSearch, this.skSelect]);
  },

  // Settings softkey update.
  updateSettingsSks: function() {
    const activeElement = document.querySelector('.focus');
    if (activeElement.classList.contains('disable-item') ||
        activeElement.classList.contains('disable-click-item') ||
        activeElement.id === 'group-message-number-description' ||
        activeElement.id === 'group-switch-item-description') {
      this.show([this.skNullSoft]);
    } else {
      this.show([this.skSettingsOK]);
    }
  },

  // Clear cahce softkey.
  removeSoftKeyCache: function() {
    const softKeyCache = document.getElementById('cachedSoftkeyPanel');
    if (softKeyCache) {
      const softKeyCacheNodes = softKeyCache.children;
      for(let i = 0; i < softKeyCacheNodes.length; i++) {
        softKeyCacheNodes[i].querySelector('.sk-button').innerHTML = '';
      }
    }
  }
};
