/* global Utils, CallManager */

(function(exports) {
  'use strict';

  exports.ActivityPicker = {
    dial: function(number, isDirect, isRTT) {
      CallManager.callFromMessage(number, isDirect, isRTT);
    },
    email: function(email, onsuccess, onerror) {
      Utils.handleActivity('new', { 
        type: 'mail', 
        URI: 'mailto:' + email 
      }, onsuccess, onerror);
    },
    url: function(url) {
      window.open(url);
    },
    createNewContact: function(contactProps, onsuccess, onerror) {
      Utils.handleActivity('new', { 
        type: 'webcontacts/contact',
        caller: 'SMS',
        params: contactProps
      }, onsuccess, onerror);
    },
    addToExistingContact: function(contactProps, onsuccess, onerror) {
      Utils.handleActivity('update', {
        type: 'webcontacts/contact',
        params: contactProps
      }, onsuccess, onerror);
    },
    viewContact: function(contactProps, onsuccess, onerror) {
      Utils.handleActivity('open', {
        type: 'webcontacts/contact',
        params: contactProps
      }, onsuccess, onerror);
    }
  };
}(this));
