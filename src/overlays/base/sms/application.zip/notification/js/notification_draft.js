/* global Drafts, Threads, Compose, SubjectUtils, AttachmentManager, 
          StateManager, Utils, MessageManager, Draft, Settings, NavigationMap, 
          OptionManager, DialogManager */

'use strict';

// eslint-disable-next-line no-unused-vars
const DraftUtils = {
  draft: null,

  // Request get draft info.
  draftRequest: function(threadId) {
    return new Promise((resolver) => {
      Drafts.request(true).then(() => {
        const thread = Threads.get(threadId);
        if (thread.hasDrafts) {
          this.draft = thread.drafts.latest;
          Compose.fromDraft(this.draft);
          NavigationMap.setFocusToFixedElement('messages-input');
          this.draft.isEdited = false;
        } else {
          this.draft = null;
        }
        resolver();
      });
    });
  },

  // Save draft function map.
  backUpDraftData: function() {
    let content, recipients, subject, attachment, threadId, type;
    content = Compose.getContent(true);
    subject = SubjectUtils.getSubject();
    attachment = AttachmentManager.getAttachment();
    type = Compose.type;

    if (Threads.active) {
      recipients = Threads.active.participants;
      threadId = Threads.currentId;
    }

    if (Threads.keyword) {
      Threads.currentId = null;
      Threads.keyword = null;
    }

    const draftId = this.draft ? this.draft.id : null;

    return {
      content: content,
      recipients: recipients,
      subject: subject,
      attachment: attachment,
      threadId: threadId,
      type: type,
      draftId: draftId
    };
  },

  saveDraft: function(opts, callback) {
    const backData = this.backUpDraftData();

    if (callback) {
      if (!opts || (opts && opts.keyFlag !== 'saveDraft')) {
        callback();
      }
    }
    if (StateManager.isDiskFull) {
      if (opts && !opts.autoSave) {
        Utils.showLowSpaceAlert();
      }
    } else {
      this.realSaveDraft(opts, backData, callback);
    }
  },

  realSaveDraft: function(opts, backData, callback) {
    let content, draft, recipients, subject, attachment, 
        threadId, type, draftId;
    content = backData.content;
    recipients = backData.recipients;
    subject = backData.subject;
    attachment = backData.attachment;
    threadId = backData.threadId;
    type = backData.type;
    draftId = backData.draftId;

    MessageManager.findThreadFromNumber(recipients).then((Id) => {
      return new Promise((resolve) => {
        resolve(Id);
      });
    }, () => {
      return new Promise((resolve) => {
        resolve(null);
      });
    }).then((messageThreadId) => {
      if (!threadId) {
        threadId = messageThreadId;
      }

      draft = new Draft({
        recipients: recipients,
        content: content,
        subject: subject,
        threadId: threadId,
        type: type,
        attachment: attachment,
        id: draftId,
        isGroup: Settings.isGroup
      });

      if (threadId) {
        this.discardDraft(true);
      }

      Drafts.add(draft);

      if (!opts.autoSave) {
        this.onDraftSaved();
      }
      callback && callback(draft); 
    });
  },

  // Remove draft function map.
  discardDraft: function(update) {
    if (this.draft) {
      Drafts.delete(this.draft).store();
      this.draft = null;
    }
    if (!update) {
      this.onDraftDiscarded();
    }
    if (Threads.keyword) {
      Threads.keyword = null;
    }
  },

  // Draft hanlde module.
  onDraftSaved: function() {
    Utils.showToaster({ messageL10nId: 'message-draft-saved' });
  },

  onDraftDiscarded: function() {
    Utils.showToaster({ messageL10nId: 'draft-discard-content' });
  },

  // Draft back function map.
  _onNavigatingBack: function(close) {
    return Promise.resolve().then(() => {
      if (Threads.active) {
        Threads.active.unreadCount = 0;
      }
      if (Compose.isEmpty()) {
        this.discardDraft(true);
        return;
      }

      if (this.draft && !this.draft.isEdited) {
        if (!Threads.currentId) {
          this.saveDraft({ autoSave: true });
        } else {
          this.draft = null;
        }
        return;
      }

      return this.showMessageSaveOrDiscardPrompt(close);
    });
  },

  showMessageSaveOrDiscardPrompt: function(close) {
    if (OptionManager.isOptionMenuShown() && close) {
      OptionManager.hideOptionMenu();
    }

    return new Promise((resolve, reject) => {
      function cancelCallback() {
        reject();
      }
      function acceptCallback() {
        DraftUtils.saveDraft({ keyFlag: 'saveDraft', keyPress: 'back' }, 
                             (draft) => {
          Utils.setSettingsValue([{
            name: 'draft.update',
            value: 'true'
          }]);
          resolve(draft);
        });
      }
      function confirmCallback() {
        DraftUtils.discardDraft();
        resolve();
      }
      DialogManager.confirmAlert('confirmation-title', 'draft-save-content', 
                                 'cancel', cancelCallback, 'save-as-draft', 
                                 acceptCallback, 'discard-message', 
                                 confirmCallback, cancelCallback);
    });
  }
};
