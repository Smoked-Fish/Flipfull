/* global Utils,  OptionManager, DialogManager, FocusStateManager, ValueDefault,
          AttachmentMessageUI, SoftkeyManager, Information, Compose, 
          NavigationMap, NotificationBase, Threads */

'use strict';

const EventManager = {
  scrollIndex: 0,
  
  // Init listener.
  init: function() {
    // Window listener.
    window.addEventListener('message-focusChanged', this);
    window.addEventListener('input', this);
    window.addEventListener('keydown', this);
  
    // Input need be handler specially.
    document.querySelector('#messages-input').addEventListener(
      'keydown', this.handleInputEvent.bind(this));

    // Backgroud listener.
    document.addEventListener('visibilitychange', this.visibilityHandle);
  },
  
  // Common event listener handler.
  handleEvent: function(event) {
    const focusEle = document.querySelector('.focus');
  
    // Option/Dialog need do some actions if press back key. 
    if ((OptionManager.isOptionMenuShown() || DialogManager.isDialogShown()) && 
        (event.key !== 'Backspace' && event.key !== 'BrowserBack' && 
         event.key !== 'EndCall')) {
      return;
    }
  
    switch (event.type) {
      case 'message-focusChanged': {
        FocusStateManager._onFocusChanged();
        break;
      }
      case 'input': {
        if (focusEle.id === 'subject-composer-input') {
          FocusStateManager._onFocusChanged();
        }
        break;
      }
      case 'keydown': {
        switch (event.key) {
          case 'Enter': {
            if (focusEle.id === 'messages-input' || 
                focusEle.id === 'subject-composer-input') {
              event.preventDefault();
            }
            break;
          }
          case 'ArrowUp':
          case 'ArrowDown': {
            // Attachment mode handler.
            if (ValueDefault.isAttachmentPage) {
              event.preventDefault();
              event.key === 'ArrowUp' ? AttachmentMessageUI.upEventHandler() :
                                        AttachmentMessageUI.downEventHandler();
            } 
            // Thread page handler.
            else {
              const parentLi = Utils.getParents(focusEle, 'LI');
              if ((focusEle.tagName === 'A' || focusEle.tagName === 'DIV') &&
                   parentLi.classList.contains('message')) {
                event.preventDefault();
                event.stopPropagation();
                this.scrollLinkElement(focusEle, event.key);
                SoftkeyManager.updateLinkSKs();
              }
            } 
            break;
          }
          case 'Backspace':
          case 'BrowserBack': {
            // Attachment page handler.
            if (ValueDefault.isAttachmentPage) {
              event.preventDefault();
              AttachmentMessageUI.resetPageStatus();
            } else if (ValueDefault.isInformation) {
              event.preventDefault();
              Information.hideReport();
            }
            // Thread page handler.
            else {
              event.stopPropagation();
              event.preventDefault();
              // Prompt select option menu handler.
              if (OptionManager.contactPromptOptionMenuShown) {
                OptionManager.hideOptionMenu();
                window.addEventListener('transitionend', function optionMenu() {
                  window.removeEventListener('transitionend', optionMenu);
                  FocusStateManager.dynamicSK();
                });
                const OPTIONMENUTIMEOUT = 300;
                setTimeout(() => {
                  // Need get current focus element not use the old one.
                  const currentFocusElement = document.querySelector('.focus');
                  if (currentFocusElement.tagName === 'A') {
                    SoftkeyManager.updateLinkSKs();
                  }
                }, OPTIONMENUTIMEOUT);
                return;
              }
              // Option menu or dialog handler.
              if (OptionManager.isOptionMenuShown() || 
                  DialogManager.isDialogShown()) {
                return;
              }
              const parentLi = Utils.getParents(document.activeElement, 'LI');
              if (parentLi.classList.contains('current-focus')) {
                NotificationBase.isLinkMode = false;
                NotificationBase.composerContainer.classList.remove('next-focus');
                const bubbleLi = document.querySelector('.current-focus');
                bubbleLi.classList.remove('bubble-link-focus');
                bubbleLi.classList.remove('current-focus');
                EventManager.cancelToThread();
              } else {
                NotificationBase.back();
              }
            } 
            break;
          }
          case 'EndCall': {
            if (ValueDefault.isAttachmentPage) {
              event.stopPropagation();
              event.preventDefault();
              if (OptionManager.isOptionMenuShown()) {
                OptionManager.hideOptionMenu();
                window.addEventListener('transitionend', function optionMenu() {
                  window.removeEventListener('transitionend', optionMenu);
                  AttachmentMessageUI.resetPageStatus();
                  NotificationBase.back(true);
                });
              } else {
                AttachmentMessageUI.resetPageStatus();
                NotificationBase.back(true);
              }
            } else {
              event.stopPropagation();
              event.preventDefault();
              // Close app manually if it is at thread or composer.
              if (Compose.isEmpty()) {
                if (OptionManager.isOptionMenuShown() || 
                    DialogManager.isDialogShown()) {
                  window.close();
                  return;
                }
              } else {
                if (OptionManager.isOptionMenuShown()) {
                  OptionManager.hideOptionMenu();
                }
              }
  
              NotificationBase.back(true);
            } 
            break;
          }
          case 'MicrophoneToggle': {
            if (NotificationBase.isLinkMode) {
              event.preventDefault();
              event.stopPropagation();
            }
            break;
          }
          default:
            break;
        }
        break;
      }
      default:
        break;
    }
  },

  // Visibility event handler.
  visibilityHandle: function() {
    if (!ValueDefault.manualLeave && !Compose.isEmpty()) {
      if (!document.hidden) {
        Utils.discardActivityDraft();
      } else {
        Utils.saveActivityDraft();
      }
    }
    // Set thread id at settings value to judge notification shown logic.
    const threadId = document.hidden ? null : Threads.currentId;
    Utils.setSettingsValue([{
      name: 'message.thread.id', 
      value: threadId 
    }]);
  },

  // Input box event handler.
  handleInputEvent: function(event) {
    const range = window.getSelection().getRangeAt(0);
    const currentCursor = range.startContainer;
  
    switch (event.key) {
      case 'ArrowUp': {
        if ((currentCursor === document.activeElement ||
             currentCursor === document.activeElement.firstChild) &&
          range.startOffset === 0) {
          break;
        }
        event.stopPropagation();
        break;
      }
      case 'ArrowDown': {
        const currentFocus = document.activeElement;
        const currentChildLength = document.activeElement.childNodes.length;
        if ((
          currentCursor === currentFocus ||
          currentCursor === currentFocus.childNodes[currentChildLength - 2]) &&
          Utils.isLastLine(range)) {
          break;
        }
        event.stopPropagation();
        break;
      }
      case 'Backspace': {
        event.stopPropagation();
        event.preventDefault();
        NotificationBase.back();
        break;
      }
      default:
        break;
    }
  },
  
  // Link handler.
  scrollLinkElement: function(node, direction) {
    const sourceElement = Utils.getParents(node, 'LI');
    const secondNode = 
      sourceElement.getElementsByClassName('message-content-body')[0];
    const secondElement = secondNode.querySelectorAll('.link-focus');
    const elementLength = secondElement.length;
    let nextFocusNode;
    if (direction === 'ArrowDown') {
      this.scrollIndex += 1;
    } else {
      this.scrollIndex -= 1;
    }
    if (this.scrollIndex < 0) {
      this.scrollIndex = elementLength - 1;
    }
    if (this.scrollIndex > elementLength - 1) {
      this.scrollIndex = 0;
    }
  
    nextFocusNode = secondElement[this.scrollIndex];
    if (nextFocusNode.tagName === 'A' || nextFocusNode.tagName === 'DIV') {
      node.blur();
      node.classList.remove('focus');
      nextFocusNode.focus();
      nextFocusNode.classList.add('focus');
      nextFocusNode.scrollIntoView(true);
      if (node.tagName === 'A') {
        Utils.getParents(node, 'LI').classList.remove('bubble-link-focus');
      }
      if (nextFocusNode.tagName === 'A') {
        Utils.getParents(nextFocusNode, 'LI').classList.add(
          'bubble-link-focus');
      }
    }
  },
  
  // Exit link mode.
  cancelToThread: function() {
    const currentFocus = document.querySelector('.focus');
    const nextFocus = Utils.getParents(currentFocus, 'LI');
    currentFocus.blur();
    currentFocus.classList.remove('focus');
    NavigationMap.setFocusToFixedElement(nextFocus.id);
    this.scrollIndex = 0;
  }
};
