/* global Utils, AttachmentManager, SoftkeyManager, Compose, SubjectUtils, 
          Settings, AttachmentMessageUI, AttachmentService, ActivityPicker,
          OptionManager, ValueDefault, NotificationBase */

'use strict';

// eslint-disable-next-line no-unused-vars
const FocusStateManager = {
  // Focus index status.
  FOCUS_INVALID: 0,
  FOCUS_ON_SUBJECT: 1,
  FOCUS_ON_MESSAGE_INPUT: 2,
  FOCUS_ON_MESSAGE_THREAD: 3,
  FOCUS_ON_ATTACHMENT: 4,

  // Scroll index.
  scrollIndex: 0,

  // Softkey update according to state.
  dynamicSK: function() {
    const currentFocus = document.querySelector('.focus');
    const focusState = this.getFocusState(currentFocus);
    
    let skParam;
    const hasAttachment = (AttachmentManager.getMessageCount() !== 0);
    const callOrEmailKey = SoftkeyManager.updateCallOrEmail();

    switch (focusState) {
      case this.FOCUS_INVALID:
        return;
      case this.FOCUS_ON_SUBJECT: {
        skParam = [SoftkeyManager.skRemoveSubject, 
                   SoftkeyManager.skAddAttachment].concat(callOrEmailKey);
        if (!Compose.isEmpty()) {
          if (hasAttachment) {
            skParam = [SoftkeyManager.skRemoveSubject, SoftkeyManager.skAddAttachment,
                       SoftkeyManager.skRemoveAttachment].concat(callOrEmailKey);
          }
          skParam = [SoftkeyManager.skSend].concat(skParam);
          skParam = skParam.concat([SoftkeyManager.skSaveAsDraft, 
                                    SoftkeyManager.skCancelFromThread]);
        }
        break;
      }
      case this.FOCUS_ON_MESSAGE_INPUT: {
        if (SubjectUtils.isSubjectVisible()) {
          skParam = [SoftkeyManager.skRemoveSubject, 
                     SoftkeyManager.skAddAttachment].concat(callOrEmailKey);
          if (hasAttachment) {
            skParam = [SoftkeyManager.skRemoveSubject, 
                       SoftkeyManager.skAddAttachment, 
                       SoftkeyManager.skRemoveAttachment].concat(callOrEmailKey);
          }
        } else {
          if (Settings.mmsEnable) {
            skParam = [SoftkeyManager.skAddSubject, 
                       SoftkeyManager.skAddAttachment].concat(callOrEmailKey);
            if (hasAttachment) {
              skParam = [SoftkeyManager.skAddSubject, 
                         SoftkeyManager.skAddAttachment, 
                         SoftkeyManager.skRemoveAttachment].concat(callOrEmailKey);
            }
          } else {
            skParam = callOrEmailKey;
          }
        }
        if (!Compose.isEmpty()) {
          skParam = [SoftkeyManager.skSend].concat(skParam);
          skParam = skParam.concat([SoftkeyManager.skSaveAsDraft, 
                                    SoftkeyManager.skCancelFromThread]);
        }
        break;
      }
      case this.FOCUS_ON_MESSAGE_THREAD: {
        NotificationBase._storeFocused = currentFocus;
        skParam = [];
        if (currentFocus.tagName === 'LI' && 
            currentFocus.classList.contains('message') &&
            !currentFocus.classList.contains('not-downloaded')) {
          if (Utils.getAChildFromMessage(currentFocus)) {
            skParam = skParam.concat([SoftkeyManager.skLinkSelect]);
          }
        }
        if (currentFocus.classList.contains('not-downloaded') &&
            !currentFocus.classList.contains('expired')) {
          skParam = skParam.concat([SoftkeyManager.skDownload]);
          if (currentFocus.classList.contains('pending')) {
            skParam = [SoftkeyManager.skNullSoft];
            break;
          }
        }
        if (currentFocus.classList.contains('error') &&
            currentFocus.classList.contains('outgoing')) {
          skParam = skParam.concat([SoftkeyManager.skResendThisMessage]);
        }
        skParam = skParam.concat([SoftkeyManager.skViewMessageReport]);
        if (currentFocus.classList.contains('pending')) {
          skParam = [SoftkeyManager.skNullSoft];
        }
        break;
      }
      case this.FOCUS_ON_ATTACHMENT: {
        const attachmentMessage = document.getElementById('attachmentMessage');
        if (attachmentMessage.getAttribute('aria-hidden') === 'false') {
          AttachmentMessageUI.updateSKs();
          return;
        }
        if (SubjectUtils.isSubjectVisible()) {
          skParam = [SoftkeyManager.skAttachmentEnter, SoftkeyManager.skRemoveSubject, 
                     SoftkeyManager.skAddAttachment, 
                     SoftkeyManager.skRemoveAttachment].concat(callOrEmailKey);
        } else {
          skParam = [SoftkeyManager.skAttachmentEnter, SoftkeyManager.skAddSubject, 
                     SoftkeyManager.skAddAttachment, 
                     SoftkeyManager.skRemoveAttachment].concat(callOrEmailKey);
        }
        skParam = [SoftkeyManager.skSend].concat(skParam);
        skParam = skParam.concat([SoftkeyManager.skSaveAsDraft, 
                                  SoftkeyManager.skCancelFromThread]);
        break;
      }
      default:
        break;
    }
  
    SoftkeyManager.show(skParam);
  },

  // Confirm focus position.
  getFocusState: function(focusEl) {
    const subjectField = document.getElementById('subject-composer-input');
    const inputField = document.getElementById('messages-input');
    const parentUl = Utils.getParents(focusEl, 'UL');
    let focusState = this.FOCUS_INVALID;

    if (focusEl === subjectField) {
      focusState = this.FOCUS_ON_SUBJECT;
    } else if (focusEl === inputField) {
      focusState = this.FOCUS_ON_MESSAGE_INPUT;
    } else if (parentUl.classList.contains('message-list')) {
      focusState = this.FOCUS_ON_MESSAGE_THREAD;
    } else if (focusEl.classList.contains('attachment-composer')) {
      focusState = this.FOCUS_ON_ATTACHMENT;
     }
    return focusState;
  },

  // Link focus module.
  findLinkFocus: function() {
    const parentNode = document.activeElement;
    this.scrollIndex = 0;
    const secondNode = parentNode.getElementsByClassName(
      'message-content-body')[0].querySelectorAll('.link-focus');
    parentNode.blur();
    parentNode.classList.remove('focus');
    secondNode[this.scrollIndex].focus();
    secondNode[this.scrollIndex].classList.add('focus');
    SoftkeyManager.updateLinkSKs();
    const parentLi = Utils.getParents(secondNode[this.scrollIndex], 'LI');
    if (secondNode[this.scrollIndex].tagName === 'A') {
      parentLi.classList.add('bubble-link-focus');
    }
  },

  // Execute link action.
  doLinkAction: function(type) {
    const focusEle = document.querySelector('.focus');
    switch (type) {
      case 'attachment':
        AttachmentService.mmsAttachmentClick(focusEle);
        break;
      case 'dial':
        ActivityPicker.dial(focusEle.dataset.dial, true, false);
        break;
      case 'rtt-dial':
        ActivityPicker.dial(focusEle.dataset.dial, true, true);
        break;
      case 'select-dial':
        OptionManager.switchCallOption('call', 'rtt-call', (rttEnable) => {
          if (rttEnable) {
            ActivityPicker.dial(focusEle.dataset.dial, true, true);
          } else {
            ActivityPicker.dial(focusEle.dataset.dial, true, false);
          }
        });
        break;
      case 'email':
        ActivityPicker.email(focusEle.dataset.email, () => {}, () => {});
        break;
      case 'url':
        ActivityPicker[type](focusEle.dataset[type]);
        break;
    }
  },

  // Focus listener create.
  _onFocusChanged: function() {
    if (ValueDefault.isInformation) {
      return;
    }

    if (document.activeElement.tagName === 'BODY') {
      document.querySelector('.focus').focus();
    }

    this.dynamicSK();
  }
};
