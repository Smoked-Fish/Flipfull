/* global Threads */

'use strict';

// eslint-disable-next-line no-unused-vars
const NotiificationManager = {
  // Close notification from app side.
  closeNotificationsForThread: function(tid) {
    const threadId = tid ? tid : Threads.currentId;
    if (!threadId) {
      return;
    }

    const targetData = 'threadId:' + threadId;

    // Remove notification from service worker.
    navigator.serviceWorker.controller.postMessage({
      tag: targetData
    });
  }
};
