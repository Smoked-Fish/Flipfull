/* global Utils, Template, TimeUtils, NavigationMap, MessageManager, 
          ValueDefault, FocusStateManager, ICCUtils, ContactRenderer,
          Contacts */

'use strict';

// Init template module.
let TMPL = function createTemplate(tmpls) {
  for (let key in tmpls) {
    tmpls[key] = Template(tmpls[key]);
  }
  return tmpls;
}({
  number: 'messages-number-tmpl',
  report: 'information-report-tmpl'
});

const REPORT_MAP = {
  'not-applicable': {
    'not-applicable': 'not-applicable',
    'pending' : 'pending',
    'success' : 'read',
    'error' : 'error'
  },
  'pending' : {
    'not-applicable': 'pending',
    'pending': 'pending',
    'success' : 'read',
    'error' : 'error'
  },
  'success' : {
    'not-applicable': 'delivered',
    'pending': 'delivered',
    'success' : 'read',
    'error' : 'error'
  },
  'error' : {
    'not-applicable': 'error',
    'pending': 'error',
    'success' : 'error',
    'error' : 'error'
  }
};

const MESSAGE_EVENTS = [
  'message-failed-to-send',
  'message-delivered',
  'message-read',
  'message-sent',
  'message-sending'
];

// Translate module.
function completeLocaleFormat(timestamp) {
  TimeUtils.initDateTime(timestamp);
  return TimeUtils.getInformationDate();
}

function l10nContainsDateSetup(element, timestamp) {
  element.textContent = completeLocaleFormat(timestamp);
}

// Create information detail.
function createReportDiv(reports) {
  let reportDiv = document.createElement('div');
  let data = {
    titleL10n: '',
    reportDateL10n: '',
    timestamp: ''
  };
  let status;
  const deliveryStatus = reports.deliveryStatus;
  const readStatus = reports.readStatus;

  if (!readStatus) {
    status = deliveryStatus === 'success' ? 'delivered' : deliveryStatus;
  } else if (deliveryStatus === 'rejected') {
    status = 'rejected';
  } else if (deliveryStatus in REPORT_MAP) {
    status = REPORT_MAP[deliveryStatus][readStatus];
  } else {
    console.error('Invalid message report status: ' + deliveryStatus);
    return reportDiv;
  }
  reportDiv.dataset.deliveryStatus = status;

  switch (status) {
    case 'not-applicable':
      return reportDiv;
    case 'delivered':
      data.timestamp = '' + reports.deliveryTimestamp;
      data.reportDateL10n = completeLocaleFormat(reports.deliveryTimestamp);
      break;
    case 'read':
      data.timestamp = '' + reports.readTimestamp;
      data.reportDateL10n = completeLocaleFormat(reports.readTimestamp);
      break;
  }
  data.titleL10n = 'report-status-' + status;
  reportDiv.innerHTML = TMPL.report.interpolate(data);

  return reportDiv;
}

function createListWithMsgInfo(message) {
  let list = [];
  if (message.delivery === 'received' ||
      message.delivery === 'not-downloaded') {
    list.push(message.sender);
    if (message.isGroup) {
      let receiverArray = Array.isArray(message.receivers) ?
                          message.receivers : [message.receivers];
      receiverArray.forEach((receiver) => {
        list.push(receiver);
      });
    }
  } else if (message.type === 'mms') {
    message.deliveryInfo.forEach((info) => {
      list.push({ number: info.receiver, infoBlock: createReportDiv(info) });
    });
  } else {
    let info = {};
    info.deliveryStatus = message.deliveryStatus;
    info.deliveryTimestamp = message.deliveryTimestamp;
    list.push({ number: message.receiver, infoBlock: createReportDiv(info) });
  }
  return list;
}

// eslint-disable-next-line no-unused-vars
const Information = {
  messageResending: false,
  name: 'report',
  renderingId: 0,
  elements: ['contact-list', 'size', 'size-block', 'type', 'sent-title',
             'sent-timestamp', 'sent-failed-info', 'received-timestamp',
             'subject', 'sim-info', 'contact-title'],

  // Init information page.
  init: function() {
    const prefix = 'information-' + this.name;
    this.container = document.getElementById(prefix);
    this.parent = document.getElementById('thread-messages');
    this.elements.forEach((name) => {
      this[Utils.camelCase(name)] = this.container.querySelector('.' + name);
    });
    this.onStatusChanged = this.onStatusChanged.bind(this);
    this.reset();
  },

  // Reset page.
  reset: function() {
    this.container.classList.add('hide');
    if (this.contactList) {
      this.contactList.textContent = '';
    }
    if (this.sentTimestamp) {
      this.sentTimestamp.textContent = '';
    }
    if (this.receivedTimestamp) {
      this.receivedTimestamp.textContent = '';
    }
    this.parent.classList.remove(this.name + '-information');
  },

  // Handle information page.
  showReport: function(id) {
    NavigationMap.disableNav = true;
    MESSAGE_EVENTS.forEach((event) => {
      MessageManager.on(event, this.onStatusChanged);
    });
    this.id = id;
    this.parent.classList.add(this.name + '-information');
    this.renderReport();
    this.container.classList.remove('hide');
    ValueDefault.isInformation = true;
  },

  hideReport: function() {
    NavigationMap.disableNav = false;
    ValueDefault.isInformation = false;
    this.parent.classList.remove(this.name + '-information');
    this.container.classList.add('hide');
    MESSAGE_EVENTS.forEach((event) => {
      MessageManager.off(event, this.onStatusChanged);
    });
    FocusStateManager._onFocusChanged();
  },

  onStatusChanged: function(event) {
    if (event.message.delivery === 'sending' && this.messageResending) {
      this.id = event.message.id;
      this.messageResending = false;
    }

    this.isReportForMessage(event.message.id) && this.refresh();
  },

  renderReport: function() {
    const request = MessageManager.getMessage(this.id);
    this.subject.classList.add('hide');
    this.sizeBlock.classList.add('hide');

    request.onsuccess = () => {
      const message = request.result;
      const type = message.type;
      const delivery = message.delivery;
      const isIncoming = delivery === 'received' ||
                         delivery === 'not-downloaded';

      if (type === 'sms') {
        Utils.translateFromAtr(this.type, 'message-type-sms');
      } else {
        Utils.translateFromAtr(this.type, 'message-type-mms');
        // Subject field.
        const subject = message.subject;
        this.subject.classList.toggle('hide', !subject);
        if (subject) {
          this.subject.querySelector('.detail').textContent = subject;
        }
        // Attachment field.
        if (message.attachments && message.attachments.length > 0) {
          const size = message.attachments.reduce((size, attachment) => {
            return (size += attachment.content.size);
          }, 0);
          const params = Utils.getSizeForL10n(size);
          Utils.translateFromAtr(this.size, params.l10nId, params.l10nArgs);
          this.sizeBlock.classList.remove('hide');
        }
      }
      this.container.dataset.delivery = delivery;
      this.container.classList.toggle(
        'no-valid-sent-timestamp', isIncoming && !message.sentTimestamp
      );

      const markTitle = isIncoming ? 'report-from-title' : 
                                     'report-to-title';
      this.contactTitle.textContent = Utils.translateString(markTitle);

      const markFlag = document.createElement('span');
      markFlag.classList.add('time-header-flag');
      this.contactTitle.appendChild(markFlag);

      if (isIncoming) {
        l10nContainsDateSetup(this.receivedTimestamp, message.timestamp);
        l10nContainsDateSetup(this.sentTimestamp, message.sentTimestamp);
        Utils.translateFromAtr(this.sentTitle, 'message-sent');
      } else {
        if (delivery === 'sending' || delivery === 'sent') {
          Utils.translateFromAtr(this.sentTitle, 'message-' + delivery);
        }
        if (delivery === 'error' || delivery === 'sent') {
          l10nContainsDateSetup(this.sentTimestamp, message.timestamp);
        }
      }

      if (!isIncoming && delivery === 'error') {
        this.sentTimestamp.classList.add('hide');
        this.sentFailedInfo.classList.remove('hide');
      } else {
        this.sentTimestamp.classList.remove('hide');
        this.sentFailedInfo.classList.add('hide');
      }

      // Show sim information for dual sim device.
      ICCUtils.showSimInfo(this.simInfo, message.iccId);

      this.renderContactList(createListWithMsgInfo(message));
    };
  },

  renderContactList: function(participants) {
    const renderer = ContactRenderer.flavor('group-view');
    const currentRenderingId = ++this.renderingId;
    let ul = this.contactList;
    let numberCount = 0;

    ul.textContent = '';
    participants.forEach((participant) => {
      let number, infoBlock, selector;

      if (typeof participant === 'object') {
        number = participant.number;
        infoBlock = participant.infoBlock;
        selector = '.suggestion';
      } else {
        number = participant;
      }

      Contacts.findByAddress(number, (results) => {
        numberCount++;
        if (currentRenderingId !== this.renderingId) {
          return;
        }

        const isContact = results !== null && !!results.length;
        if (isContact) {
          renderer.render({
            contact: results[0],
            input: number,
            infoBlock: infoBlock,
            infoBlockParentSelector: selector,
            target: ul
          });
        } else {
          let li = document.createElement('li');
          li.role = 'presentation';
          li.innerHTML = TMPL.number.interpolate({
            number: number
          });

          let parentBlock = li.querySelector(selector);
          if (parentBlock && infoBlock) {
            parentBlock.appendChild(infoBlock);
          }

          ul.appendChild(li);
        }

        if (numberCount === participants.length) {
          window.dispatchEvent(new CustomEvent('participants-done'));
        }
      });
    });
  }
};
