/* global Utils, Compose, SubjectUtils */

'use strict';

// eslint-disable-next-line no-unused-vars
const InputUtils = {
  timeouts: {
    update: null,
    subjectLengthNotice: null
  },
  previousSegment: 0,

  // Init Input elemnet and listener.
  init: function() {
    // Init base element.
    this.initElement();
    // Normal input event listener.
    this.inputField.addEventListener('focus', 
      this._onMessageInputFocusChange.bind(this));
    this.inputField.addEventListener('blur', 
      this._onMessageInputFocusChange.bind(this));
    this.subjectField.addEventListener('focus', 
      this._onMessageSubjectFocusChange.bind(this));
    this.subjectField.addEventListener('blur', 
      this._onMessageSubjectFocusChange.bind(this));
    
    // Composer page init and listener.
    Compose.init('messages-compose-form');
    Compose.on('input', this._onMessageComposerInputHandler.bind(this));
    Compose.on('subject-change', this._onSubjectChange.bind(this));
    Compose.on('segmentinfochange', this._onSegmentInfoChange.bind(this));
  },
          
  initElement: function() {
    this.subjectField = document.getElementById('subject-composer-input');
    this.inputField = document.getElementById('messages-input');
          
    ['compose-form'].forEach((id) => {
      this[Utils.camelCase(id)] = document.getElementById('messages-' + id);
    });
  },

  // Handler input box changed.
  _onMessageInputFocusChange: function(e) {
    this.composeForm.classList.toggle('item-focus', e.type === 'focus');
  },
          
  _onMessageSubjectFocusChange: function(e) {
    this.composeForm.classList.toggle('subject-focus', e.type === 'focus');
  },

  _onSubjectChange: function() {
    if (SubjectUtils.isSubjectVisible() && SubjectUtils.isSubjectMaxLength()) {
      Utils.showToaster({ messageL10nId: 'messages-max-subject-length-text' });
    }
  },
          
  // Composer page handler.
  _onMessageComposerInputHandler: function() {
    if (Compose.type === 'sms') {
      this.adjustScrollElement();
      return;
    }
          
    if (Compose.isResizing) {
      Utils.showToaster({ messageL10nId: 'resize-image' });
    }
  },
          
  _onSegmentInfoChange: function() {
    const currentSegment = Compose.segmentInfo.segments;
    const isValidSegment = currentSegment > 0;
    const isSegmentChanged = this.previousSegment !== currentSegment;
    const isStartingFirstSegment = this.previousSegment === 0 &&
                                   currentSegment === 1;
          
    if (Compose.type === 'sms' && isValidSegment &&
        isSegmentChanged && !isStartingFirstSegment) {
      this.previousSegment = currentSegment;
      Utils.showToaster({
        messageL10nId: 'sms-counter-notice-label',
        messageL10nArgs: { number: currentSegment }
      });
    }
  },
          
  // Scroll range adjust.
  adjustScrollElement: function() {
    const items = document.querySelectorAll('ul.message-list li');
    const lastElement = items.item(items.length - 1);
    lastElement && lastElement.scrollIntoView(false);
  },

  // Clear input field.
  cleanFields: function() {
    this.previousSegment = 0;
    Compose.clear();
  }
};
