/* global Navigation, Utils, Compose, DialogManager, DraftUtils */

'use strict';

const NotificationRoute = {
  // View related page from main page.
  toView: function(message) {
    Utils.waitL10nState(() => {
      if (!document.hidden) {
        this.navigateToView(message);
        return;
      }

      document.addEventListener('visibilitychange', function waitVisibility() {
        document.removeEventListener('visibilitychange', waitVisibility);
        NotificationRoute.navigateToView(message);
      });
    });
  },

  navigateToView: function(message) {
    if (!message.threadId) {
      this.triggerNewMessage(
        message.body, message.number, message.contact
      );
      return;
    }
    Navigation.toPanel('thread', { 
      id: message.threadId, messageId: message.id 
    });
  },

  triggerNewMessage: function(body, number, contact) {
    const activity = {
      body: body || null,
      number: number || null,
      contact: contact || null
    };

    if (Compose.isEmpty()) {
      this.launchComposer(activity);
    } else {
      // Ask user how should we do.
      this.displayUnsentConfirmation(activity);
    }
  },

  launchComposer: function(activity) {
    Navigation.toPanel('composer', { activity: activity });
  },

  displayUnsentConfirmation: function(activity) {
    function deleteCallback() {
      DraftUtils.discardDraft();
      NotificationRoute.launchComposer(activity);
    }

    DialogManager.confirmAlert('unsent-message-title', 
                               'unsent-message-description',
                               'unsent-message-option-edit', 
                               null, null, null,
                               'discard-message', deleteCallback);
  }
};
