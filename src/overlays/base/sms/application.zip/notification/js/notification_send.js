/* global Utils, Compose, SubjectUtils, Threads, StateManager, Settings, 
          FocusStateManager, DialogManager, InputUtils, DraftUtils, 
          Drafts, MessageManager, NotificationBase */

'use strict';

const SendManager = {
  showErrorInFailedEvent: '',

  // Send module.
  sendMessage: function(opts) {
    const content = Compose.getContent(),
          subject = SubjectUtils.getSubject(),
          messageType = Compose.type,
          serviceId = opts.serviceId === undefined ? null : opts.serviceId;

    let recipients = Threads.active.participants;

    if (content.length === 0 && !subject) {
      return;
    }

    if (messageType === 'mms' && !StateManager.isMMSAbleToSend(serviceId)) {
      return;
    }

    Utils.canSendWhenParentControl(recipients).then((canSend) => {
      if (canSend) {
        if (Settings.hasGroup && Settings.groupSwitchEnabled && recipients.length > 1) {
          Utils.judgeNumberSituation(serviceId, () => {
            Settings.isGroup = true;
            this.realSendMessage(messageType, recipients, content,
                                 serviceId, subject);
          }, () => {
            // Confirm the cursor is at the end of string.
            if (document.activeElement.id === 'messages-input') {
              Compose.focus();
            }
            FocusStateManager.dynamicSK();
          });
        } else {
          this.realSendMessage(messageType, recipients, content,
                               serviceId, subject);
        }
      } else {
        DialogManager.confirmAlert('confirmation-title', 'parent-control-text',
                                   null, null, 'ok', null, null, null);
      }
    });
  },

  realSendMessage: function(messageType, recipients, 
                            content, serviceId, subject) {
    NotificationBase.disableConvertNoticeBanners();
    InputUtils.cleanFields();
    NotificationBase.enableConvertNoticeBanners();

    if (DraftUtils.draft) {
      Drafts.delete(DraftUtils.draft).store();
      DraftUtils.draft = null;
    }

    NotificationBase.updateHeaderData();

    // Send the Message
    if (messageType === 'sms') {
      MessageManager.sendSMS({
        recipients: recipients,
        content: content[0],
        serviceId: serviceId,
        oncomplete: (requestResult) => {
          if (!requestResult.hasError) {
            this.onMessageSendRequestCompleted();
            return;
          }

          const errors = {};
          requestResult.return.forEach((result) => {
            if (result.success) {
              return;
            }

            if (errors[result.code.message] === undefined) {
              errors[result.code.message] = [result.recipient];
            } else {
              errors[result.code.message].push(result.recipient);
            }
          });

          for (const key in errors) {
            this.showMessageSendingError(key, { recipients: errors[key] });
          }
        }
      });

      if (recipients.length > 1) {
        // TODO single page can not handler mutiple recipients send.
      }
    } else {
      if (Settings.dataServiceId === -1) {
        this.showMessageSendingError('NoSignalError');
        return;
      }

      const smilSlides = content.reduce(Utils.generateSmilSlides, []);
      const mmsOpts = {
        recipients: recipients,
        subject: subject,
        content: smilSlides,
        serviceId: serviceId,
        onsuccess: function() {
          this.onMessageSendRequestCompleted();
        }.bind(this),
        onerror: function onError(error) {
          const errorName = error.message;
          this.showMessageSendingError(errorName);
        }.bind(this)
      };

      MessageManager.sendMMS(mmsOpts);
    }
  },

  resendMessage: function(id) {
    id = +id;
    const request = MessageManager.getMessage(id);
    request.onsuccess = () => {
      const message = request.result;
      let serviceId = Settings.getServiceIdByIccId(message.iccId);
      serviceId = serviceId === null ? 0 : serviceId;

      // According to the discussion, the alert order should be
      // storage full > airplane mode > no SIM > no data.
      if (Compose.type === 'mms' && StateManager.isDiskFull) {
        DialogManager.alertFreeSpace('send');
        return;
      }
      // VoWifi use data SIM card default.
      if (message.type === 'sms' && StateManager.isAirplaneState() &&
          !StateManager.isVoWifiStatus(Settings.dataServiceId)) {
        DialogManager.showMessageError('RadioDisabledError');
        return;
      }

      if (StateManager.isNoSIMStatus()) {
        DialogManager.showMessageError('NoSimCardError');
        return;
      }

      // VoWifi use data SIM card default.
      // Porting from PRGF7TF-4419 - tingting.chao on 24/09/09 add VoWifi check
      if (message.type === 'mms' && !Settings.dataEnable &&
          Settings.whiteListOff && !StateManager.isVoWifiStatus(Settings.dataServiceId)) {
        // we need reject send/download MMS if data is OFF,
        // please check bug 56531 for detail.
        if (StateManager.isAirplaneState()) {
          DialogManager.showMessageError('RadioDisabledError');
        } else {
          DialogManager.alertDataOffStatus();
        }
        return;
      }

      if (message.type === 'mms' && !StateManager.isMMSAbleToSend(serviceId)) {
        return;
      }

      const messageDOM = document.getElementById('message-' + id);
      if (message.type === 'mms' && Settings.hasGroup &&
          message.isGroup) {
        Utils.judgeNumberSituation(serviceId, () => {
          this.realResendMessage(message, messageDOM);
        }, () => {
          FocusStateManager.dynamicSK();
        });
      } else {
        this.realResendMessage(message, messageDOM);
      }
    };
  },

  realResendMessage: function(message, messageDOM) {
    const resendOpts = {
      message: message,
      onerror: function onError(error) {
        const errorName = error.message;
        SendManager.showMessageSendingError(errorName, { 
          recipients: [message.receiver] 
        });
      }.bind(this),
      onsuccess: function() {
        SendManager.onMessageSendRequestCompleted();
      }.bind(this)
    };
    NotificationBase.removeMessageDOM(messageDOM);
    MessageManager.resendMessage(resendOpts);
  },

  // Send handler module.
  initSentAudio: function() {
    if (this.sentAudio) {
      return;
    }

    this.sentAudio = new Audio();
    this.sentAudio.preload = 'none';
    this.sentAudio.src = '/sounds/SMS Message sent_MA.ogg';
    this.sentAudio.mozAudioChannelType = 'notification';
    this.sentAudioKey = 'message.sent-sound.enabled';
    this.sentAudioEnabled = false;

    try {
      Utils.getSettingsValue(this.sentAudioKey).then((value) => {
        this.sentAudioEnabled = value;
      });

      Utils.observerSettingsValue(this.sentAudioKey, (value) => {
        this.sentAudioEnabled = value;
      });
    } catch (e) {
      this.sentAudioEnabled = false;
    }
  },

  // Sent action handler.
  onMessageSendRequestCompleted: function() {
    // Play the audio notification
    if (this.sentAudioEnabled) {
      this.sentAudio.play();
    }
  },

  // Error handler.
  showMessageSendingError: function(errorName, opts) {
    if (errorName === 'NonActiveSimCardError') {
      this.showErrorInFailedEvent = errorName;
      return;
    }
    if (errorName === 'NotFoundError') {
      return;
    }
    DialogManager.showMessageError(errorName, opts);
  }
};
