/* global Utils, CallManager, SendService, FocusStateManager, SoftkeyPanel,
          AttachmentMessageUI, SubjectUtils, StateManager, Settings,
          DialogManager, AttachmentManager, Threads, OptionManager, 
          ActivityPicker, DraftUtils, EventManager, Information, SendManager, 
          ContactsServiceManager, ContactsUtils, NotificationBase */

'use strict';

const SoftkeyManager = {
  // Init all softkey value.
  init: function() {
    // Thread message softkey map.
    this.skSend = {
      l10nId: 'send',
      priority: 2,
      method: function() {
        SendService.startSendMessage();
      }
    };

    this.skLinkSelect = {
      l10nId: 'select',
      priority: 2,
      method: function () {
        NotificationBase.isLinkMode = true;
        FocusStateManager.findLinkFocus();
      }
    };

    this.skAttachmentEnter = {
      l10nId: 'view',
      priority: 1,
      method: function () {
        AttachmentMessageUI.enterAttachmentPage();
      }
    };

    this.skAttachmentOpen = {
      l10nId: 'open',
      priority: 2,
      method: function () {
        FocusStateManager.doLinkAction('attachment');
      }
    };
          
    this.skDialOpen = {
      l10nId: 'call',
      priority: 2,
      method: function () {
        FocusStateManager.doLinkAction('dial');
      }
    };
            
    this.skRTTDialOpen = {
      l10nId: 'rtt-call',
      priority: 2,
      method: function () {
        FocusStateManager.doLinkAction('rtt-dial');
      }
    };
            
    this.skSelectDialOpen = {
      l10nId: 'call',
      priority: 2,
      method: function () {
        FocusStateManager.doLinkAction('select-dial');
      }
    };
            
    this.skEmailOpen = {
      l10nId: 'email',
      priority: 2,
      method: function () {
        FocusStateManager.doLinkAction('email');
      }
    };
            
    this.skUrlOpen = {
      l10nId: 'open',
      priority: 2,
      method: function () {
        FocusStateManager.doLinkAction('url');
      }
    };
          
    this.skCallAction = {
      l10nId: 'call',
      priority: 2,
      method: function () {
        // eslint-disable-next-line no-undef
        secondCall = false;
      }
    };
          
    this.skEmailAction = {
      l10nId: 'email',
      priority: 2,
      method: function () {
        // eslint-disable-next-line no-undef
        secondCall = false;
      }
    };
            
    this.skOption = {
      l10nId: 'options',
      priority: 3,
      method: function () {
        const focused = document.querySelector('.focus');
        const linkType = NotificationBase.listenLinkElement(focused);
        NotificationBase.openLinkFocus(linkType.replace('-link', ''));
      }
    };
          
    this.skDownload = {
      l10nId: 'download-attachment',
      priority: 2
    };
          
    this.skAddSubject = {
      l10nId: 'add-subject',
      priority: 5,
      method: function() {
        SubjectUtils.subjectPreHandle();
      }
    };
          
    this.skRemoveSubject = {
      l10nId: 'remove-subject',
      priority: 5,
      method: function() {
        SubjectUtils.subjectPreHandle();
      }
    };
          
    this.skAddAttachment = {
      l10nId: 'add-attachment',
      priority: 5,
      method: function() {
        // To confirm read out normal, need make the focus in order.
        document.addEventListener('transitionend', function optionMenu() {
          document.removeEventListener('transitionend', optionMenu);
          if (StateManager.isDiskFull) {
            DialogManager.alertFreeSpace('attachment');
          } else {
            AttachmentManager.onAttachClick();
          }
        });
      }
    };
          
    this.skRemoveAttachment = {
      l10nId: 'remove-all-attachments',
      priority: 5,
      method: function() {
        AttachmentManager.deleteAttachment();
      }
    };
          
    this.skCall = {
      l10nId: 'call',
      priority: 5,
      method: function() {
        CallManager.majorCall(false);
      }
    };
            
    this.skRTTCall = {
      l10nId: 'rtt-call',
      priority: 5,
      method: function() {
        CallManager.majorCall(true);
      }
    };
            
    this.skEmail = {
      l10nId: 'email',
      priority: 5,
      method: function() {
        let mailElement = [];
        for (let i = 0; i < Threads.active.participants.length; i++) {
          if (Utils.isEmailAddress(Threads.active.participants[i])) {
            mailElement.push(Threads.active.participants[i]);
          }
        }
            
        // If only one recipient, email directly, else show select dialog.
        if (mailElement.length > 1) {
          OptionManager.recipientsSelectOption(mailElement, 'email');
        } else {
          ActivityPicker.email(mailElement[0]);
        }
      }
    };
      
    this.skSaveAsDraft = {
      l10nId: 'sk-save-as-draft',
      priority: 5,
      method: function() {
        DraftUtils.saveDraft({ keyFlag: 'saveDraft' }, () => {
          Utils.setSettingsValue([{
            name: 'draft.update',
            value: 'true'
          }]);
          window.close();
        });
      }
    };

    this.skCancelFromThread = {
      l10nId: 'cancel',
      priority: 5,
      method: function() {
        NotificationBase.back();
      }
    };

    this.skCancelToThread = {
      l10nId: 'cancel',
      priority: 1,
      method: function() {
        NotificationBase.isLinkMode = false;
        NotificationBase.composerContainer.classList.remove('next-focus');
        const bubbleLi = document.querySelector('.current-focus');
        bubbleLi.classList.remove('bubble-link-focus');
        bubbleLi.classList.remove('current-focus');
        EventManager.cancelToThread();
      }
    };

    this.skViewMessageReport = {
      l10nId: 'view-message-report',
      priority: 5,
      method: function() {
        const targetItem = NotificationBase._storeFocused;
        const messageId = Utils.getFocusedMessageId(targetItem);
        window.addEventListener('participants-done', 
          function updateInformation() {
          window.removeEventListener('participants-done', updateInformation);
          Information.container.focus();
          SoftkeyManager.updateInformationSks();
        });
        Information.showReport(messageId);
      }
    };
          
    this.skResendThisMessage = {
      l10nId: 'resend-message',
      priority: 5,
      method: function() {
        const targetItem = NotificationBase._storeFocused;
        const messageId = NotificationBase.getFocusedMessageId(targetItem);
        SendManager.resendMessage(messageId);
      }
    };

    this.skNullSoft = {
      l10nId: 'null',
      priority: 2
    };
          
    // Information view map.
    this.skCancelViewReport = {
      l10nId: 'cancel-view-report',
      priority: 1,
      method: function() {
        Information.hideReport();
      }
    };
          
    this.skBlockContacts = {
      l10nId: 'blocked',
      priority: 3,
      method: function() {
        const contactList =
          document.getElementById('information-report').
          querySelector('.contact-list');
        const suggestionList = contactList.querySelectorAll('.suggestion');
        DialogManager.confirmAlert('confirmation-title', 
                                   'block-confirmation', 
                                   'cancel', 
                                   () => {
          Information.container.focus();
          SoftkeyManager.show([SoftkeyManager.skCancelViewReport, 
                               SoftkeyManager.skBlockContacts]);
        }, null, null, 'blocked', () => {
          for (let i = 0; i < suggestionList.length; i++) {
            const nodeContact = suggestionList[i].getAttribute('data-number');
            ContactsServiceManager.blockNumbers(nodeContact, (value) => {
              if (value) {
                suggestionList[i].classList.add('suggestion-adjust');
                suggestionList[i].parentNode.classList.add('block-tag');
              }
            });
          }
          Information.container.focus();
          SoftkeyManager.show([SoftkeyManager.skCancelViewReport, 
                               SoftkeyManager.skUnblockContacts]);
        }, () => {
          Information.container.focus();
        });
      }
    };
          
    this.skUnblockContacts = {
      l10nId: 'unblocked',
      priority: 3,
      method: function() {
        const contactList =
          document.getElementById('information-report').
          querySelector('.contact-list');
        const suggestionList = contactList.querySelectorAll('.suggestion');
        for (let i = 0; i < suggestionList.length; i++) {
          const nodeContact = suggestionList[i].getAttribute('data-number');
          ContactsServiceManager.unblockNumbers(nodeContact, (value) => {
            if (value) {
              suggestionList[i].classList.remove('suggestion-adjust');
              suggestionList[i].parentNode.classList.remove('block-tag');
            }
          });
        }
        SoftkeyManager.show([SoftkeyManager.skCancelViewReport, 
                             SoftkeyManager.skBlockContacts]);
      }
    };
          
    // Attachment softkey map.
    this.skCancelFromAttachment = {
      l10nId: 'cancel',
      priority: 1,
      method: function() {
        AttachmentMessageUI.resetPageStatus();
      }
    };
          
    this.skOpenFromAttachment = {
      l10nId: 'open',
      priority: 2,
      method: function() {
        const focusEle =
          AttachmentMessageUI.attachmentContainer.querySelector('.focus');
        AttachmentManager.openAttachment(focusEle);
      }
    };
          
    this.skAddAttachmentFromAttachment = {
      l10nId: 'add-attachment',
      priority: 5,
      method: function() {
        const req = AttachmentManager.requestAttachment();
        req.onsuccess = (item) => {
          AttachmentManager.addAttachments(item, () => {
            // Need update the attachment list to sync 
            // the latest attachment count number.
            AttachmentMessageUI.updateAttachmentList();
            AttachmentMessageUI.removeFocus(AttachmentMessageUI.focusCount);
            AttachmentMessageUI.focusCount =
              AttachmentMessageUI.attachmentList.length - 1;
            AttachmentMessageUI.setFocus(AttachmentMessageUI.focusCount);
            AttachmentMessageUI.attachmentList[AttachmentMessageUI.focusCount].
            parentNode.scrollIntoView(false);
          });
        };
        req.onerror = (err) => {
          AttachmentManager._onAttachmentRequestError(err);
          AttachmentMessageUI.setFocus(AttachmentMessageUI.focusCount);
        };
      }
    };
          
    this.skRemoveAttachmentFromAttachment = {
      l10nId: 'remove-attachment',
      priority: 5,
      method: function() {
        const count = AttachmentMessageUI.focusCount;
        const attachmentList = AttachmentMessageUI.attachmentList;
        const focusEle = attachmentList[count];
          
        AttachmentManager.removeAttachment(focusEle, () => {
          AttachmentMessageUI.updateAttachmentList();
          AttachmentManager.updateAttachmentAbstract();
          window.addEventListener('menuEvent', 
                                  AttachmentMessageUI.updateOptionsBackUp);
        });
      }
    };

    this.skReplaceAttachmentFromAttachment = {
      l10nId: 'replace-attachment',
      priority: 5,
      method: function() {
        const count = AttachmentMessageUI.focusCount;
        const attachmentList = AttachmentMessageUI.attachmentList;
        const focusEle = attachmentList[count];
        AttachmentManager.replaceAttachment(focusEle);
      }
    };
          
    // Common softkey map.
    this.skSelect = {
      l10nId: 'select',
      priority: 2,
      method: function() {
        // eslint-disable-next-line no-undef
        secondCall = false;
      }
    };
  },
          
  // Create softkey panel.
  show: function(keys) {
    const softkeyParams = {
      header: { l10nId: 'options' },
      items: keys
    };
          
    if (window.option) {
      window.option.initSoftKeyPanel(softkeyParams);
    } else {
      window.option = new SoftkeyPanel(softkeyParams);
    }
          
    window.option.show();
  },
          
  // Link sofykey update.
  updateLinkSKs: function() {
    const focused = document.querySelector('.focus');
    let skparam = null;
    if (!focused) {
      return;
    }
    if ((focused.tagName === 'A' || focused.tagName === 'DIV') &&
        Utils.getParents(focused, 'LI').classList.contains('message')) {
      NotificationBase.composerContainer.classList.add('next-focus');
      Utils.getParents(focused, 'LI').classList.add('current-focus');
      skparam = [this.skCancelToThread];
      const linkType = NotificationBase.listenLinkElement(focused);
      switch (linkType) {
        case 'attachment':
          skparam = skparam.concat([this.skAttachmentOpen]);
          break;
        case 'dial-link':
          if (Settings.RTTEnable) {
            if (Settings.RTTPreferred === 'always-visible-automatic') {
              skparam = skparam.concat([this.skRTTDialOpen]);      
            } else if (Settings.RTTPreferred === 'always-visible-manual') {
              skparam = skparam.concat([this.skSelectDialOpen]);
            } else {
              skparam = skparam.concat([this.skDialOpen]);
            }
          } else {
            skparam = skparam.concat([this.skDialOpen]);
          }
          skparam = skparam.concat([this.skOption]);
          break;
        case 'url-link':
          skparam = skparam.concat([this.skUrlOpen]);
          break;
        case 'email-link':
          if (Settings.emailAppInstalled) {
            skparam = skparam.concat([this.skEmailOpen]);
          }
          skparam = skparam.concat([this.skOption]);
          break;
      }
      this.show(skparam);
    }
  },
          
  // Call or email softkey update.
  updateCallOrEmail: function() {
    // Need consider three situations.
    // 1. Only email address -> only email option.
    // 2. Only phone address -> only phone option.
    // 3. Both of email and phone exist -> email and phone option.
    let hasEmail = false;
    let hasPhone = false;
    let lastSoftKey = [];
    for (let i = 0; i < Threads.active.participants.length; i++) {
      if (Utils.isEmailAddress(Threads.active.participants[i])) {
        if (Settings.emailAppInstalled) {
          hasEmail = true;
        }
      } else {
        hasPhone = true;
      }
    }
          
    if (hasPhone) {
      if (!Settings.RTTEnable) {
        lastSoftKey = [SoftkeyManager.skCall];
      } else {
        switch (Settings.RTTPreferred) {
          case 'visible-during-calls':
            lastSoftKey = [SoftkeyManager.skCall];
            break;
          case 'always-visible-automatic':
            lastSoftKey = [SoftkeyManager.skRTTCall];
            break;
          case 'always-visible-manual':
            lastSoftKey = [SoftkeyManager.skCall, SoftkeyManager.skRTTCall];
            break;
        }
      }
    }
          
    if (hasEmail) {
      lastSoftKey = [SoftkeyManager.skEmail].concat(lastSoftKey);
    }
          
    return lastSoftKey;
  },
          
  // Call select softkey update.
  updateCallKey: function () {
    if (Settings.RTTEnable) {
      if (Settings.RTTPreferred === 'always-visible-automatic') {
        this.show([this.skCancelToThread, this.skRTTDialOpen, this.skOption]);
        return;
      } else if (Settings.RTTPreferred === 'always-visible-manual') {
        this.show([
          this.skCancelToThread, 
          this.skSelectDialOpen, 
          this.skOption
        ]);
        return;
      }
    }
    this.show([this.skCancelToThread, this.skDialOpen, this.skOption]);
  },
          
  // Attachment softkey update.
  updateAttachmentKey: function() {
    this.show([
      this.skCancelFromAttachment, 
      this.skOpenFromAttachment, 
      this.skAddAttachmentFromAttachment, 
      this.skRemoveAttachmentFromAttachment, 
      this.skReplaceAttachmentFromAttachment
    ]);
  },

  // Detail softkey update.
  updateInformationSks: function() {
    ContactsUtils.pickContactsDetail().then((contacts) => {
      if (contacts[0].length === contacts[1].length) {
        this.show([this.skCancelViewReport, this.skUnblockContacts]);
      } else {
        this.show([this.skCancelViewReport, this.skBlockContacts]);
      }
    });
  }
};
          