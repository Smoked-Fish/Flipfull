/* eslint-disable optimize-regex/optimize-regex */
/* global SettingsObserver, Toaster, DeviceCapabilityManager, Contacts,
          ContactsServiceManager, DialogManager, Settings, WebActivity,
          DraftUtils, NotificationBase */

'use strict';

const l10nInterface = window.api.l10n;

// eslint-disable-next-line no-unused-vars
const Utils = {
  // Replace extra string.
  escapeRegex: function(str) {
    const rescape = /[.?*+^$[\]\\(){}|-]/g;
    if (typeof str !== 'string') {
      return '';
    }
    return str.replace(rescape, '\\$&');
  },

  // Remove not need string for phone number.
  removeNonDialables: function(input) {
    // eslint-disable-next-line no-useless-escape
    const rnondialablechars = /[^,#+\*\d]/g;
    return input.replace(rnondialablechars, '');
  },

  // L10n action map.
  translateString: function(id) {
    return l10nInterface.get(id);
  },

  translateFragment: function(doc) {
    l10nInterface.translateFragment(doc);
  },

  translateFromAtr: function(element, string, args) {
    l10nInterface.setAttributes(element, string, args);
  },

  // Attachment limit size exceed select.
  getSizeForL10n: function(size) {
    // Blob size with unit (B or KB or MB).
    const sizeKB = size / 1024;
    const sizeMB = sizeKB / 1024;
    if (size < 1000) {
      return {
        l10nId: 'attachmentSizeB',
        l10nArgs: { n: size }
      };
    } else if (sizeKB < 1000) {
      return {
        l10nId: 'attachmentSizeKB',
        l10nArgs: { n: sizeKB.toFixed(1) }
      };
    }
    return {
      l10nId: 'attachmentSizeMB',
      l10nArgs: { n: sizeMB.toFixed(1) }
    };
  },

  // Replace Upper string.
  camelCase: function(str) {
    const rdashes = /-(.)/g;
    return str.replace(rdashes, (str, p1) => {
      return p1.toUpperCase();
    });
  },

  // Parent node get.
  getParents: function(node, tagName) {
    // It is impossible to transfer body elemet here,
    // so need change the node to focus node.
    if (node.tagName === 'BODY') {
      node = document.querySelector('.focus');
    }
    const parent = node.parentNode;
    const tag = tagName.toUpperCase();
    if (parent.tagName === tag) {
      return parent;
    } else if (parent.tagName === 'BODY') {
      return document.body;
    } else {
      return this.getParents(parent, tag);
    }
  },

  // Child node get.
  getAChildFromMessage: function(node) {
    const secondFocusElement =
      node.getElementsByClassName('message-content-body')[0];
    return (secondFocusElement.querySelectorAll('.link-focus').length !== 0);
  },

  // Node index get.
  getItemIndex: function(elements, id) {
    let index;
    const length = elements.length;
    for (let i = 0; i < length; i++) {
      if (elements[i].id === id) {
        index = i;
        break;
      }
    }
    return index;
  },

  // Get the mine type from attachment.
  typeFromMimeType: function(mime) {
    const MAX_MIME_TYPE_LENGTH = 256;
    if (typeof mime !== 'string' || mime.length > MAX_MIME_TYPE_LENGTH) {
      return null;
    }

    const index = mime.indexOf('/');
    if (index === -1) {
      return null;
    }
    const mainPart = mime.slice(0, index);
    const secondPart = mime.substr(index + 1).toLowerCase();

    switch (mainPart) {
      case 'image':
        return 'img';
      case 'text':
        if(secondPart.indexOf('vcard') !== -1) {
          return 'vcard';
        }
        if (secondPart !== 'plain') {
          return 'ref';
        }
        return mainPart;
      case 'video':
      case 'audio':
      case 'application':
        return mainPart;
      default:
        return null;
    }
  },

  // Settings value common module.
  setSettingsValue: function(settingsGroup) {
    SettingsObserver.setValue(settingsGroup);
  },

  getSettingsValue: function(settingsValue) {
    return new Promise(function(resolver) {
      SettingsObserver.getValue(settingsValue).then((result) => {
        const settingsResult = result || null;
        resolver(settingsResult);
      });
    });
  },

  observerSettingsValue: function(settingsValue, callback) {
    SettingsObserver.observe(settingsValue, null, (value, name) => {
      if (name === settingsValue) {
        callback(value);
      }
    });
  },

  // Email check.
  isEmailAddress: function(email) {
    // eslint-disable-next-line no-useless-escape
    const rmail = /[\w-]+@[\w\-]/;
    const extraEmail = email.indexOf(' ') === -1;
    return rmail.test(email) && extraEmail;
  },

  // Toaster shown.
  showToaster: function(args) {
    Toaster.showToast(args);
  },

  // Parent control module.
  canSendWhenParentControl: function(numbers) {
    return new Promise((resolveAll) => {
      DeviceCapabilityManager.get('device.parental-control').then(
        (controlEnabled) => {
        if (controlEnabled) {
          let asyncTask = [];
          for (let i = 0; i < numbers.length; i++) {
            let newTask = () => new Promise((resolve) => {
              Contacts.findByPhoneNumber(numbers[i], (result) => {
                if (result) {
                  ContactsServiceManager.findBlockNumbers(numbers[i]).then(
                    (blockList) => {
                    // If support parent control feature and contact number
                    // in block list, should prevent send action.
                    if (blockList && blockList.length !== 0) {
                      resolve(false);
                    } else {
                      resolve(true);
                    }
                  });
                } else {
                  // If support parent control feature and number not contact,
                  // should prevent send action.
                  resolve(false);
                }
              });
            });
            asyncTask.push(newTask());
          }

          Promise.all(asyncTask).then((values) => {
            let lastValue = true;
            for (let i = 0; i < values.length; i++) {
              lastValue = lastValue && values[i];
            }
            resolveAll(lastValue);
          });
        } else {
          // If not support parent control feature, we must send message.
          resolveAll(true);
        }
      });
    });
  },

  // Group SIM card judge (for DSDS) function map.
  judgeNumberSituation: function(serviceId, callback, cancelCallBack) {
    // Protection code to prevent error.
    if (!serviceId) {
      serviceId = 0;
    }

    const needShow = this.needShowInputNumber(serviceId);
    let simFlag;

    if (needShow) {
      simFlag = serviceId === 0 ? 'sim1' : 'sim2';
      DialogManager.inputDialogShow('group-message', '', 'input-alert-reInput',
                                    simFlag, (number) => {
        // Only consider two SIM at base now.
        if (serviceId === 0) {
          this.setSettingsValue([{
            name: 'ril.mms.phoneNumber.sim1',
            value: number
          }]);
          Settings.fakeSIMNumberArray[0] = number;
        } else {
          this.setSettingsValue([{
            name: 'ril.mms.phoneNumber.sim2',
            value: number
          }]);
          Settings.fakeSIMNumberArray[1] = number;
        }

        // After number inputted, send message immediately.
        callback();
      }, () => {
        cancelCallBack && cancelCallBack();
      }, () => {
        cancelCallBack && cancelCallBack();
      });
    } else {
      callback();
    }
  },

  needShowInputNumber: function(serviceId) {
    // Only when have SIM && SIM number not read && fake number is null,
    // show input box.
    return (Settings.originalSIMInfoArray[serviceId] &&
            !Settings.originalSIMNumberArray[serviceId] &&
            !Settings.fakeSIMNumberArray[serviceId]);
  },

  /* Send the event to the event_logger_module, the caught events are:
   * 1. When send a SMS, need save log.
   * 2. When open a SMS, need save log.
   */
  sendEventLogs: function(numbers, type) {
    const DATASTORE_NAME = 'eventlogger-event';
    let is_psms = 0;

    this.findContactInArray(numbers).then((param) => {
      let options = {};
      if (type === 'sms_send') {
        options = {
          event_type: type,
          data: {
            is_contact: param[0],
            is_dial: param[1],
            is_psms: is_psms
          }
        };
      }

      if (type === 'sms_open') {
        options = {
          event_type: type,
          data: {
            is_contact: param[0]
          }
        };
      }

      return new Promise((resolve) => {
        this.handleActivity(DATASTORE_NAME, options, () => {
          resolve();
        }, (err) => {
          console.error(`Send event log with error: ${err}`);
        });
      });
    });
  },

  findContactInArray: function(numbers) {
    let is_contact = 0;
    let is_dial = 0;
    let count = 0;

    if (!Array.isArray(numbers)) {
      numbers = [numbers];
    }

    return new Promise((resolve) => {
      numbers.forEach((number) => {
        Contacts.findByAddress(number, (result) => {
          count++;
          // There is one situation we can not get,
          // if the user input a contact number, it is difficult to confirm
          // the number is manually input or not, so we only use a sample
          // logic here.
          // The contact number or email is not input manually.
          if (result && result.length > 0) {
            is_contact = 1;
          } else {
            // TODO the thread UI is not defined at activity.
            if (NotificationBase.isManualInput) {
              is_dial = 1;
            }
          }

          if (count === numbers.length) {
            resolve([is_contact, is_dial]);
          }
        });
      });
    });
  },

  // Extra function map (now is not available)
  creationModeCheck: function(file, isForward) {
    const blob = file.blob;
    // Please refer to
    // MMS protocol OMA-MMS-CONF-V1_2-20050301-A Chapter 7 table 1.
    // The useful format is as followed:
    // - format      -  size -   text  - image   -  audio  -  video   -  Pim  -
    // -  text       -  30KB - US-ASCII   N/A       N/A       N/A        N/A
    //                         UTF-8,
    //                         UTF-16
    //
    // - image basic -  30KB - same as -  JPEG   - AMR-NB  - N/A      -  vCard
    //                          text     GIF87a      13K               vCalendar
    //                                   GIF89a
    //                                    WBMP
    // - image rich  - 100KB - same as - same as - AMR-NB  -  N/A     -  same as
    //                          text      basic      13K                  basic
    //                                             SP-MIDI
    // - video basic - 100KB - same as - same as - same as -  3GPP    -  same as
    //                          text      basic     rich      3GPP2       basic
    // - video rich  - 300KB - same as - same as - same as - same as  -  same as
    //                          text      basic     rich      basic       basic
    const limitSizeMap = {
      text: 30 * 1024,
      imgBasic: 30 * 1024,
      imgRich: 100 * 1024,
      videoBasic: 100 * 1024,
      videoRich: 300 * 1024
    };
    const limitTypeMap = {
      text: ['text/vcard', 'text/x-vcard'],
      image: ['image/jpeg', 'image/gif', 'image/wbmp'],
      audio: ['audio/amr', 'audio/x-midi'],
      video: ['video/3gpp', 'video/3gpp2']
    };

    const blobTypeArray = blob.type.split('/');
    let needLimit = limitTypeMap[blobTypeArray[0]].indexOf(blob.type) === -1;
    if (blobTypeArray[0] === 'text' && blob.size > limitSizeMap.text) {
      needLimit = true;
    } else if ((blobTypeArray[0] === 'audio' || blobTypeArray[0] === 'video') &&
               blob.size > limitSizeMap.videoRich) {
      needLimit = true;
    } else if (isForward && blobTypeArray[0] === 'image' &&
               blob.size > limitSizeMap.imgRich) {
      needLimit = true;
    }

    return needLimit;
  },

  operatorCreationMode: function(needLimit, callback) {
    // Please refer the MMS protocol OMA-MMS-CONF-V1_2-20050301-A Chapter 12.
    //  - Creation mode RESTRICTED.
    //      In this mode, a terminal SHALL only create and submit MMs belonging
    //    to the Core MM Content Domain.
    //  - Creation mode WARNING.
    //      In this mode, a terminal SHALL guide the user to create and submit
    //    only MMs belonging to the Core MM Content Domain. This guidance may,
    //    for instance, be implemented as warnings to the user. If the user
    //    chooses to create and submit an MM that is conformant with the
    //    Core MM Content Domain, the MM shall be conformant with the
    //    Core MM Content Domain. The form of the guidance
    //    and choice is not specified.
    //  - Creation mode FREE.
    //      In this mode, a terminal MAY allow the user to
    //    add any content to the MM.
    const creationMode = Settings.creationMode;
    switch (creationMode) {
      case 'restricted':
        if (needLimit) {
          DialogManager.confirmAlert('creationMode_restricted_title',
                                     'creationMode_restricted_alert',
                                     null, null, 'ok', null, null, null, null);
          callback(true);
        } else {
          callback(false);
        }
        break;
      case 'warning':
        if (needLimit) {
          DialogManager.confirmAlert('creationMode_warning_title',
                                     'creationMode_warning_alert',
                                     'cancel', () => {
            callback(true);
          }, null, null, 'confirm-dialog-ok', () => {
            callback(false);
          }, () => {
            callback(true);
          });
        } else {
          callback(false);
        }
        break;
      case 'free':
        callback(false);
        break;
      default:
        callback(false);
        break;
    }
  },

  // Activity handler.
  handleActivity: function(detailName, detailData, onsuccess, onerror) {
    new WebActivity(detailName, detailData).start().then((result) => {
      console.log('activity added successfully, data is :: ' +
                  JSON.stringify(result));
      onsuccess && onsuccess(result);
    }).catch((error) => {
      console.warn('Unhandled error spawning activity; ' + error.message);
      onerror && onerror(error);
    });
  },

  // Smil created.
  generateSmilSlides: function(slides, content) {
    const length = slides.length;
    if (typeof content === 'string') {
      if (!length || slides[length - 1].text) {
        slides.push({ text: content });
      } else {
        slides[length - 1].text = content;
      }
    } else {
      slides.push({ blob: content.blob, name: content.name });
    }
    return slides;
  },

  // Focused message bubble get.
  getFocusedMessageId: function(forcusedItem) {
    if (forcusedItem.tagName !== 'LI') {
      const item = this.getParents(forcusedItem, 'LI');
      return item.dataset.messageId;
    } else {
      return forcusedItem.dataset.messageId;
    }
  },

  // Compare recipients numbers.
  probablyMatches: function(a, b) {
    // String comparison starts here.
    if (typeof a !== 'string' || typeof b !== 'string') {
      return false;
    }

    if (Settings.supportEmailRecipient &&
        this.isEmailAddress(a) &&
        this.isEmailAddress(b)) {
      return a === b;
    }

    a = this.removeNonDialables(a);
    b = this.removeNonDialables(b);

    return a === b || a.slice(-7) === b.slice(-7);
  },

  // Activity auto draft module.
  saveActivityDraft: function() {
    DraftUtils.saveDraft({ autoSave: true }, () => {
      const saveTime = Date.now();
      Utils.setSettingsValue([{
        name: 'sms.draft.save.time',
        value: saveTime
      }]);
    });
  },

  discardActivityDraft: function() {
    DraftUtils.discardDraft(true);
    Utils.setSettingsValue([{
      name: 'sms.draft.save.time',
      value: null
    }]);
  },

  // Promise related utilities.
  Promise: {
    defer: function() {
      let deferred = {};

      deferred.promise = new Promise(function(resolve, reject) {
        deferred.resolve = resolve;
        deferred.reject = reject;
      });

      return deferred;
    },

    async: function(generatorFunction) {
      return function asyncGenerator() {
        const generator = generatorFunction.apply(this, arguments);

        function handle(result) {
          if (result.done) {
            return Promise.resolve(result.value);
          }

          return Promise.resolve(result.value).then(
            (result) => handle(generator.next(result)),
            (error) => handle(generator.throw(error))
          );
        }

        try {
          return handle(generator.next());
        } catch (error) {
          return Promise.reject(error);
        }
      };
    }
  }
};
