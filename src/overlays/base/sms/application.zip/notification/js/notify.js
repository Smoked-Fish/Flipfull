/* global SettingsURL, Utils, ValueDefault */

(function(exports) {
  'use strict';

  const SETTINGS = {
    vibration: 'vibration.enabled',
    ringtone: 'notification.ringtone'
  };

  // Notification related element get.
  function entry(key, value) {
    if (urls[key]) {
      return new SettingsURL().set(value);
    }
    return value;
  }

  let urls = {};
  urls[SETTINGS.ringtone] = 1;

  function getSetting(key) {
    return new Promise(function(resolve) {
      Utils.getSettingsValue(key).then((value) => {
        resolve(entry(key, value));
      });
    });
  }

  function getSettings(settings) {
    return Promise.all(
      settings.map(getSetting)
    ).catch(() => {
      return settings.map(() => null);
    }).then((results) => {
      return settings.reduce((result, setting, i) => {
        result[setting] = results[i];
        return result;
      }, {});
    });
  }

  // Ringtone action function.
  function ringtone(ringtoneFile) {
    const ringtonePlayer = new Audio();
    const AUDIOTIMEOUT = 2000;
    ringtonePlayer.src = ringtoneFile;
    ringtonePlayer.mozAudioChannelType = 'notification';
    ringtonePlayer.play();
    // The audio only play 2 seconds.
    setTimeout(() => {
      ringtonePlayer.pause();
      ringtonePlayer.removeAttribute('src');
      ringtonePlayer.load();
    }, AUDIOTIMEOUT);
  }

  // Vibrate action function.
  function vibrate() {
    navigator.vibrate([200, 200, 200, 200]);
  }

  exports.Notify = {
    ringtone: function() {
      const ringtoneFile = 'app://sms.gaiamobile.org' + ValueDefault.NOTIFYAUDIO;
      ringtone(ringtoneFile);
    },

    vibrate: function() {
      return getSettings([SETTINGS.vibration]).then((settings) => {
        if (settings[SETTINGS.vibration]) {
          vibrate();
        }
      });
    }
  };
}(this));
