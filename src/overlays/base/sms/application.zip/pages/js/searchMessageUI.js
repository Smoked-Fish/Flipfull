/* global Template, SoftkeyManager, MessageManager, Drafts, Contacts, 
          ThreadListUI, ContactsServiceManager, SearchMessageUI */

(function(exports) {
  'use strict';

  exports.SearchMessageUI = {
    init: function () {
      const searchMessage = document.getElementById('searchMessage');
      if (searchMessage.innerHTML.length === 0) {
        const template = Template('searchMessageViewTmpl');
        searchMessage.innerHTML = template.toString();
      }

      this.searchInput = document.getElementById('search-input');
      this.searchBox = document.getElementById('messages-search-form');
      this.searchList = document.getElementById('search-thread-list');
      this.searchInput.addEventListener('focus',
        this._onSearchInputChange.bind(this));
      this.searchInput.addEventListener('blur',
        this._onSearchInputChange.bind(this));
      this.searchInput.addEventListener('input',
        this._onSearchInputContentChange.bind(this));
    },

    // Handler event action map.
    _onSearchInputChange: function(event) {
      this.searchBox.classList.toggle('search-focus', event.type === 'focus');
      SoftkeyManager.updateSearchSks(this.searchBox.classList.contains('search-focus'));
    },

    _onSearchInputContentChange: function(event) {
      if (!event.isComposing) {
        this.searchList.innerHTML = '';
        this.searchItem(this.searchInput.value);
      }
    },

    // Search main function.
    searchItem: function(searchInput) {
      if (searchInput.length === 0) {
        return;
      }

      function onRenderThread(thread) {
        for (let i = 0; i < thread.participants.length; i++) {
          if (thread.participants[i].indexOf(searchInput) >= 0) {
            const node = this.createNodes(thread);
            const newEvent = 'contact-update-' + node.dataset.threadId;
            window.addEventListener(newEvent, function updateList() {
              window.removeEventListener(newEvent, updateList);
              SearchMessageUI.updateContacts(thread.participants[i], node);
            });
          } else {
            this.searchContacts(thread.participants[i], thread, searchInput);
          }
        }
      }

      MessageManager.getThreads({
        each: onRenderThread.bind(this)
      });

      Drafts.request(true).then(() => {
        Drafts.forEach((draft, threadId) => {
          if (!threadId) {
            for (let i = 0; i < draft.recipients.length; i++) {
              Contacts.findByAddress(draft.recipients[i], (contacts) => {
                if (contacts.length !== 0) {
                  if (contacts[0].name.toLowerCase().indexOf(
                      searchInput.toLowerCase()) >= 0) {
                    this.realSearchAction(draft, i, true, searchInput);
                  } else {
                    this.realSearchAction(draft, i, false, searchInput);
                  }
                } else {
                  this.realSearchAction(draft, i, false, searchInput);
                }
              });
            }
          }
        });
      });
    },

    createNodes: function(thread) {
      const node = ThreadListUI.createThread(thread);
      ContactsServiceManager.setContact(node);
      const checkBox = node.querySelector('.pack-checkbox-large');
      checkBox.classList.add('hide');
      return node;
    },

    updateContacts: function(threadNumber, threadNode) {
      Contacts.findByAddress(threadNumber, (contacts) => {
        if (contacts.length !== 0 && contacts[0].name) {
          threadNode.querySelector('.threadlist-item-title').
            querySelector('bdi').textContent = contacts[0].name;
        }
        this.searchList.appendChild(threadNode);
      });
    },

    searchContacts: function(threadNumber, thread, searchInput) {
      Contacts.findByAddress(threadNumber, (contacts) => {
        if (contacts.length !== 0) {
         if (contacts[0].name.toLowerCase().indexOf(
           searchInput.toLowerCase()) >= 0) {
            let node = this.createNodes(thread);
            node.querySelector('.threadlist-item-title').
              querySelector('bdi').textContent = contacts[0].name;
            const newEvent = 'contact-update-' + node.dataset.threadId;
            window.addEventListener(newEvent, function updateList() {
              window.removeEventListener(newEvent, updateList);
              SearchMessageUI.searchList.appendChild(node);
            });
          }
        }
      });
    },

    realSearchAction: function(draft, count, isContactSearched, searchInput) {
      if (draft.recipients[count].indexOf(searchInput) >= 0 || isContactSearched) {
        const body = draft.content && draft.content.length ?
          draft.content.find((content) => {
            if (typeof content === 'string') {
              return true;
            }
          }) : '';
        const newDraft = {
          id: draft.id,
          participants: draft.recipients && draft.recipients.length ?
                        draft.recipients : [''],
          body: body,
          timestamp: new Date(draft.timestamp),
          unreadCount: 0,
          lastMessageType: draft.type || 'sms',
          isGroup: draft.isGroup || false
        };
        const node = this.createNodes(newDraft);
        const newEvent = 'contact-update-' + node.dataset.threadId;
        window.addEventListener(newEvent, function updateList() {
          window.removeEventListener(newEvent, updateList);
          SearchMessageUI.searchList.appendChild(node);
        });
      }
    },

    // Route event handler.
    afterEnter: function() {
      SoftkeyManager.updateSearchSks(true);
    }
  };
}(this));
