/* global Template, SoftkeyManager, Settings, SettingsUI, Navigation,
          DialogManager, Utils, StateManager */

(function(exports) {
  'use strict';

  exports.SettingsUI = {
    initialized: false,

    init: function() {
      let settings = document.getElementById('messaging-settings');
      // Select the UI is has MMS or has no MMS.
      if (settings.innerHTML.length === 0) {
        let template;
        if (Settings.mmsEnable) {
          template = Template('messaging-settings-view-tmpl');
        } else {
          template = Template('messaging-settings-view-tmpl-noMMS');
        }
        settings.innerHTML = template.toString();
      }

      // Some production does not need group feature.
      if (!Settings.hasGroup && Settings.mmsEnable) {
        const groupSettings =
          document.getElementById('group-message-number-set-sim1').parentNode;
        const groupHeader = document.getElementById('group-message-header');
        groupSettings.classList.add('hide');
        const groupNodes = groupSettings.querySelectorAll('.navigable');
        for (let i = 0; i < groupNodes.length; i++) {
          groupNodes[i].classList.remove('navigable');
        }
        groupHeader.classList.add('hide');
      }

      //Porting from Task-11444817,11459086.11494986-renlongou on 2024/09/07-begin
      if (OperatorUtils.isATTFamily()) {
        document.getElementById('autoRetrieve-message-item').classList.add('hide');
        document.getElementById('autoRetrieve-message-item').classList.remove('navigable');
        document.getElementById('deliveryReport-SMS-item').classList.add('hide');
        document.getElementById('deliveryReport-SMS-item').classList.remove('navigable');
      }
      //Porting from Task-11444817,11459086.11494986-renlongou on 2024/09/07-end

      this.selectDualorSingleDisplay();

      window.addEventListener('sim-card-changed', this.handleSIMChanged.bind(this));
    },

    // SIM hot swap handler.
    handleSIMChanged: function(evt) {
      const wapNode1 = document.getElementById('wapPush-message-item-sim1');
      const wapNode2 = document.getElementById('wapPush-message-item-sim2');
      const wapSelect1 = document.getElementsByName('wap.push.enabled.sim1')[0];
      const wapSelect2 = document.getElementsByName('wap.push.enabled.sim2')[0]; 
      const inputSim1 = document.getElementById('group-message-number-set-sim1');
      const inputSim2 = document.getElementById('group-message-number-set-sim2');
      const inputContext1 = document.getElementsByName('ril.mms.phoneNumber.sim1')[0];
      const inputContext2 = document.getElementsByName('ril.mms.phoneNumber.sim2')[0];
      // Init the wap push setting value after unplug.
      if (evt.detail && evt.detail.type === 'unplug') {
        if (!Settings._serviceIds[0]) {
          Utils.setSettingsValue([{ 
            name: 'wap.push.enabled.sim1',
            value: true 
          }]);
          wapSelect1.value = 'sim1On';
        }
        if (!Settings._serviceIds[1]) {
          Utils.setSettingsValue([{ 
            name: 'wap.push.enabled.sim2',
            value: true 
          }]);
          wapSelect2.value = 'sim2On';
        }
      }
      // Handle UI.
      if (Settings.isDualSimDevice()) {
        this.controlWapNode(wapNode1, !Settings._serviceIds[0]);
        this.controlWapNode(wapNode2, !Settings._serviceIds[1]);
        this.controlGroupNode(inputSim1, inputContext1, !Settings._serviceIds[0], 
                              Settings.originalSIMInfoArray[0], Settings.originalSIMNumberArray[0]);
        this.controlGroupNode(inputSim2, inputContext2, !Settings._serviceIds[1], 
                              Settings.originalSIMInfoArray[1], Settings.originalSIMNumberArray[1]);
      } else {
        this.controlWapNode(wapNode1, StateManager.isNoSIMStatus());
        this.controlGroupNode(inputSim1, inputContext1, !Settings._serviceIds[0], 
                              Settings.originalSIMInfoArray[0], Settings.originalSIMNumberArray[0]);
      }
    },

    // Wap push node control.
    controlWapNode: function(wapNode, hide) {
      if (hide) {
        wapNode.querySelector('small').classList.remove('hide');
        wapNode.querySelector('select').classList.add('hide');
        wapNode.classList.add('disable-item');
      } else {
        wapNode.querySelector('small').classList.add('hide');
        wapNode.querySelector('select').classList.remove('hide');
        wapNode.classList.remove('disable-item');
      }
    },

    // Group message node control.
    controlGroupNode: function(inputNode, inputContext, hide, originSIM, originNum) {
      if (hide) {
        inputNode.classList.add('disable-item');
        Utils.translateFromAtr(inputContext, 'not-assigned');
      } else {
        if (originSIM && originNum) {
          inputNode.classList.remove('disable-item');
          inputNode.classList.add('disable-click-item');
          inputContext.textContent = originNum;
        } else {
          inputNode.classList.remove('disable-item');
          Utils.translateFromAtr(inputContext, 'not-assigned');
        }
      }
    },

    // Hanlder the route event.
    afterEnter: function() {
      SoftkeyManager.updateSettingsSks();
      SettingsUI.render();
    },

    back: function() {
      Navigation.toPanel('thread-list');
    },

    // Open the settings menu.
    openSelectItem: function() {
      const focusedItems = document.querySelectorAll('.focus');
      if (focusedItems.length > 0) {
        const focusItem = focusedItems[0];
        const viewPanel = SettingsUI.getViewPanel(focusItem);

        if (focusItem.classList.contains('disable-item') ||
            focusItem.classList.contains('disable-click-item')) {
          return;
        }

        if (focusItem.id === 'emergency-alert-item') {
          Utils.handleActivity('configure', {
            section: 'emergency-alert'
          });
          return;
        }

        // Allow the user inputs themselves phone number.
        if (viewPanel === 'group-number-set-sim1' ||
            viewPanel === 'group-number-set-sim2') {
          // Pick sim card information to make the operator easy.
          const simFlag = viewPanel.substr(-4);
          let defaultNumber;
          let defaultSettings;
          if (simFlag === 'sim1') {
            defaultNumber = Settings.fakeSIMNumberArray[0];
            defaultSettings = 'ril.mms.phoneNumber.sim1';
          } else {
            defaultNumber = Settings.fakeSIMNumberArray[1];
            defaultSettings = 'ril.mms.phoneNumber.sim2';
          }

          // Confirm the body is not null/undefined.
          if (!defaultNumber) {
            defaultNumber = '';
          }

          DialogManager.inputDialogShow('group-message', defaultNumber,
                                        '', simFlag, (number) => {
            const elem = document.getElementsByName(defaultSettings)[0];
            if (simFlag === 'sim1') {
              Utils.setSettingsValue([{
                name: 'ril.mms.phoneNumber.sim1',
                value: number
              }]);
              Settings.fakeSIMNumberArray[0] = number;
            } else {
              Utils.setSettingsValue([{
                name: 'ril.mms.phoneNumber.sim2',
                value: number
              }]);
              Settings.fakeSIMNumberArray[1] = number;
            }
            defaultNumber = number;
            if (number) {
              elem.textContent = number;
            } else {
              Utils.translateFromAtr(elem, 'not-assigned');
            }
          });
        } else {
          const selectItems = focusedItems[0].querySelector('select');
          selectItems && selectItems.focus();
        }
      }
    },

    getViewPanel: function(target) {
      return target.getAttribute('name');
    },

    // The Single and DSDS shown is different.
    selectDualorSingleDisplay: function () {
      const isDualSim = Settings.isDualSimDevice();
      const viewSim1 = document.getElementsByName('wap-push-view-sim1')[0];
      const viewSim2 = document.getElementsByName('wap-push-view-sim2')[0];
      const viewSim1Span = viewSim1.getElementsByTagName('span')[0];
      const viewSim2Span = viewSim2.getElementsByTagName('span')[0];
      const inputSim1 = document.getElementById('group-message-number-set-sim1');
      const inputSim2 = document.getElementById('group-message-number-set-sim2');
      const inputSim1Span = inputSim1.getElementsByTagName('span')[0];
      const inputSim2Span = inputSim2.getElementsByTagName('span')[0];
      if (isDualSim) {
        viewSim1Span.setAttribute('data-l10n-id', 'wappushSIM1');
        viewSim2Span.setAttribute('data-l10n-id', 'wappushSIM2');
        inputSim1Span.setAttribute('data-l10n-id', 'myNumber-SIM1');
        inputSim2Span.setAttribute('data-l10n-id', 'myNumber-SIM2');
      } else {
        viewSim1Span.setAttribute('data-l10n-id', 'wappushNormal');
        viewSim2.classList.add('hide');
        viewSim2.classList.remove('navigable');
        inputSim1Span.setAttribute('data-l10n-id', 'myNumber');
        inputSim2 && inputSim2.classList.add('hide');
        inputSim2 && inputSim2.classList.remove('navigable');
      }
    },

    countNotAssignedSIM: function() {
      let count = 0;
      for (let i = 0; i < Settings._serviceIds.length; i++) {
        if (Settings._serviceIds[i] === null) {
          count++;
        }
      }
      return count;
    },

    // Init the settings list.
    render: function() {
      ['ril.sms.requestStatusReport.enabled', 'ril.mms.requestStatusReport.enabled',
       'ril.mms.retrieval_mode', 'ril.mms.creation_mode', 'wap.push.enabled.sim1',
       'wap.push.enabled.sim2', 'ril.mms.phoneNumber.sim1', 'ril.mms.phoneNumber.sim2',
       'airplaneMode.status', 'ril.mms.groupSwitch.enabled'].forEach((item) => {
        Utils.getSettingsValue(item).then((value) => {
          const elem = document.getElementsByName(item)[0];
          switch (item) {
            case 'ril.mms.retrieval_mode': {
              if (Settings.mmsEnable) {
                elem.value = value;
              }
              break;
            }
            case 'ril.mms.creation_mode': {
              if (Settings.mmsEnable) {
                elem.value = value ? value : 'free';
              }
              break;
            }
            case 'ril.sms.requestStatusReport.enabled':
            case 'ril.mms.requestStatusReport.enabled': {
              if (!Settings.mmsEnable && item === 'ril.mms.requestStatusReport.enabled') {
                break;
              }
              // Get the keyword SMS or MMS to build the delivery enable value.
              const typeFlag = item.substr(4, 3).toUpperCase();
              const deliveryEnable = value === true ? 'delivery' + typeFlag + 'On' :
                                                      'delivery' + typeFlag + 'Off';
              elem.value = deliveryEnable;
              break;
            }
            case 'wap.push.enabled.sim1':
            case 'wap.push.enabled.sim2': {
              // Pick sim card information to make the operator easy.
              const simFlag = item.substr(-4);
              const wappushEnable = value === true ? simFlag + 'On' : simFlag + 'Off';

              elem.value = wappushEnable;

              const wapNode1 = document.getElementById('wapPush-message-item-sim1');
              const wapNode2 = document.getElementById('wapPush-message-item-sim2');
              if (Settings.isDualSimDevice()) {
                if (item === 'wap.push.enabled.sim1') {
                  this.controlWapNode(wapNode1, !Settings._serviceIds[0]);
                } else {
                  this.controlWapNode(wapNode2, !Settings._serviceIds[1]);
                }
              } else {
                this.controlWapNode(wapNode1, StateManager.isNoSIMStatus());
              }
              break;
            }
            case 'ril.mms.phoneNumber.sim1':
            case 'ril.mms.phoneNumber.sim2': {
              // No group supported device not handle it.
              if (!Settings.hasGroup) {
                break;
              }

              // Pick sim card information to make the operator easy.
              const simSelect = item.substr(-4);
              const inputLiSim1 = document.getElementById('group-message-number-set-sim1');
              const inputLiSim2 = document.getElementById('group-message-number-set-sim2');
              const originalSIMInfo = Settings.originalSIMInfoArray;
              const originalNumberInfo = Settings.originalSIMNumberArray;
              if (simSelect === 'sim1') {
                // No SIM status.
                if (!originalSIMInfo[0]) {
                  inputLiSim1.classList.add('disable-item');
                  Utils.translateFromAtr(elem, 'not-assigned');
                }
                // Have original number status.
                else if (originalSIMInfo[0] && originalNumberInfo[0]) {
                  inputLiSim1.classList.add('disable-click-item');
                  elem.textContent = originalNumberInfo[0];
                }
                // Not have original number status.
                else {
                  Settings.fakeSIMNumberArray[0] = value;
                  if (value) {
                    elem.textContent = value;
                  } else {
                    Utils.translateFromAtr(elem, 'not-assigned');
                  }
                }
              } else {
                // No SIM status.
                if (!originalSIMInfo[1]) {
                  inputLiSim2.classList.add('disable-item');
                  Utils.translateFromAtr(elem, 'not-assigned');
                }
                // Have original number status.
                else if (originalSIMInfo[1] && originalNumberInfo[1]) {
                  inputLiSim2.classList.add('disable-click-item');
                  elem.textContent = originalNumberInfo[1];
                }
                // Not have original number status.
                else {
                  Settings.fakeSIMNumberArray[1] = value;
                  if (value) {
                    elem.textContent = value;
                  } else {
                    Utils.translateFromAtr(elem, 'not-assigned');
                  }
                }
              }
              break;
            }
            case 'airplaneMode.status': {
              const CMASEmergencyItem = document.getElementById('emergency-alert-item');
              CMASEmergencyItem.classList.toggle('disable-item', (value === 'enabled'));
              break;
            }
            case 'ril.mms.groupSwitch.enabled': {
              // No group supported device not handle it.
              if (!Settings.hasGroup) {
                break;
              }

              const groupEnable = value === true ? 'groupSwitchOn' : 'groupSwitchOff';
              elem.value = groupEnable;
              Settings.groupSwitchEnabled = value;
              break;
            }
          }
        });
      });
    }
  };
}(this));
