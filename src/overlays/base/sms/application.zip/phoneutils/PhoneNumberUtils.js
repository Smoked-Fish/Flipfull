/* -*- indent-tabs-mode: nil; js-indent-level: 2 -*- */
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

"use strict";
(function (exports) {
  const DEBUG = false;
  function debug(s) { if(DEBUG) console.log("-*- PhoneNumberutils: " + s + "\n"); }

  var PhoneNumberUtils = {
    parse: function(aNumber) {
      return new Promise((resolve, reject) => {
          if (DEBUG) debug("parseWithMCC " + aNumber);
          PhoneNumber.loadData(MCC_PHONE_NUMBER_FORMAT);
          let pNum = PhoneNumber.Parse(aNumber);
          PhoneNumber.unloadData();
          resolve(pNum);
      });
    },

    parseWithMCC: function(aNumber, aMCC) {
      return new Promise((resolve, reject) => {
          let countryName = MCC_ISO3166_TABLE[aMCC];
          PhoneNumber.loadData(MCC_PHONE_NUMBER_FORMAT);
          let pNum = PhoneNumber.Parse(aNumber, countryName);
          PhoneNumber.unloadData();
          return resolve(pNum);
        })
    },
  };
  exports.PhoneNumberUtils = PhoneNumberUtils;
}(window));
