/* global ActivityHandler, Settings, Utils, ValueDefault, NavigationMap, 
          FocusStateManager, Navigation, InputUtils, ActivityModule,
          ThreadUI, SoftkeyManager, RecipientManager */

(function(exports) {
  'use strict';
  
  let view = new WeakMap();
  let priv = new WeakMap();
  let data = new WeakMap();
  let events = new WeakMap();
  let relation = new WeakMap();
  //GF5GTMO-3550-porting from Task10626134-tingting.chao on 2024/08/19-begin
  //const rdigit = /^\d+$/;
  const rdigit = /^\+?([0-9]+[- .]*)?(\([0-9]+\)[- .]*)?[0-9][0-9- .]+[0-9]$/;
  //GF5GTMO-3550-porting from Task10626134-tingting.chao on 2024/08/19-end

  let removeIndex = 0;

  function Recipient(opts) {
    let number;

    opts = opts || {};
    this.name = opts.name || opts.number || '';
    this.number = (opts.number || '') + '';
    this.email = opts.email || '';
    this.editable = opts.editable || 'true';
    this.role = this.editable ? 'textbox' : 'button';
    this.source = opts.source || 'manual';
    this.type = opts.type || '';
    this.carrier = opts.carrier || '';
    this.className = ActivityHandler._isCustomMessage ? 'recipient' :
                                                        'recipient navigable';
    this.isEmail = Settings.supportEmailRecipient &&
                   Utils.isEmailAddress(this.number);
    this.isLookupable = opts.isLookupable || false;
    this.isInvalid = opts.isInvalid || false;
    this.isQuestionable = opts.isQuestionable || false;

    number = this.number[0] === '+' ? this.number.slice(1) : this.number;

    if (this.isEmail) {
      this.className += ' email';
    } else if (this.source === 'manual' && !rdigit.test(number)) {
      this.isQuestionable = true;
    } else if (this.source === 'contacts' && !this.isEmail && !rdigit.test(number)) {
      this.isInvalid = true;
    }

    if (this.isQuestionable || this.isInvalid) {
      this.className += ' invalid';
    }
  }

  Recipient.prototype.set = function(dict) {
    const length = Recipient.FIELDS.length;
    let key;

    for (let i = 0; i < length; i++) {
      key = Recipient.FIELDS[i];
      this[key] = dict[key];
    }
    return this;
  };

  Recipient.prototype.clone = function() {
    return new Recipient(this);
  };

  Recipient.FIELDS = [
    'name', 'number', 'email', 'editable', 'source',
    'type', 'carrier', 'isQuestionable', 'isInvalid', 'isLookupable'
  ];

  function Recipients(setup) {
    if (!setup) {
      throw new Error('`setup` missing');
    }

    if (!setup.template) {
      throw new Error('`setup.template` missing');
    }

    if (!setup.outer) {
      throw new Error('`setup.outer` missing');
    }

    if (!setup.inner) {
      throw new Error('`setup.inner` missing');
    }

    let list = [];

    Object.defineProperties(this, {
      length: {
        get: function() {
          return list.length;
        },
        set: function(value) {
          const oldLength = list.length;
          list.length = value;
          if (value < oldLength) {
            this.render();
          }
          return value;
        }
      },
      list: {
        get: function() {
          return list.slice();
        }
      },
      numbers: {
        get: function() {
          return list.reduce(function(unique, recipient) {
            const value = recipient.number || recipient.email;
            if (!recipient.isInvalid && unique.indexOf(value) === -1) {
              unique.push(value);
            }
            return unique;
          }, []);
        }
      },
      inputValue: {
        get: function() {
          const node = document.getElementById(setup.inner).lastElementChild;
          return (node && node.isPlaceholder) ?
            node.textContent.trim() : '';
        }
      },
      isInvalid: {
        get: function() {
          return list.reduce(function(isInvalid, recipient) {
            if (recipient.isQuestionable || recipient.isInvalid) {
              return true;
            }
            return false;
          }, false);
        }
      }
    });

    data.set(this, list);
    events.set(this, { add: [], remove: [], modechange: [] });
    view.set(this, new Recipients.View(this, setup));
  }

  Recipients.prototype.on = function(type, handler) {
    let handlers = events.get(this);

    if (!handlers[type]) {
      throw new Error('Invalid event type: ' + type);
    }

    handlers[type].push(handler);

    return this;
  };

  Recipients.prototype.off = function(type, handler) {
    let handlers = events.get(this);

    if (!handlers[type]) {
      throw new Error('Invalid event type: ' + type);
    }

    if (!handler) {
      handlers[type].length = 0;
    } else {
      handlers[type].splice(handlers[type].indexOf(handler), 1);
    }

    return this;
  };

  Recipients.prototype.emit = function(type) {
    let handlers = events.get(this);
    let handler, stack;
    const args = [].slice.call(arguments, 1);

    if (!handlers[type]) {
      throw new Error('Invalid event type: ' + type);
    }

    stack = handlers[type].slice();

    if (stack.length) {
      while ((handler = stack.pop())) {
        handler.apply(null, args);
      }
    }

    return this;
  };

  Recipients.prototype.add = function(entry) {
    let list = data.get(this);
    let added;

    if (entry.number === undefined) {
      throw new Error('recipient entry missing number');
    }

    entry.editable = entry.editable || 'false';

    ['name', 'number', 'email'].forEach((field) => {
      if (entry[field]) {
        entry[field] = (entry[field] + '').trim();
      }
    });

    list.push(added = new Recipient(entry));

    this.emit('add', list.length, added.clone());
    this.render();

    return this;
  };

  Recipients.prototype.update = function(recipOrIndex, entry) {
    let list = data.get(this);
    const index = typeof recipOrIndex === 'number' ? recipOrIndex : 
                                                     list.indexOf(recipOrIndex);

    if (index > -1) {
      list[index].set(new Recipient(entry));
    }

    return this.render();
  };

  Recipients.prototype.remove = function(recipOrIndex) {
    let list = data.get(this);
    const index = typeof recipOrIndex === 'number' ? recipOrIndex : 
                                                     list.indexOf(recipOrIndex);

    if (index === -1) {
      return this;
    }

    list.splice(index, 1);
    this.emit('remove', list.length);
    removeIndex = index;

    return this.render(index);
  };

  Recipients.prototype.render = function() {
    view.get(this).reset();
    if (ValueDefault.firstEnter) {
      ValueDefault.firstEnter = false;
    } else {
      view.get(this).focus();
    }

    const RENDERTIMEOUT = 200;
    setTimeout( () => {
      NavigationMap.updateFocus();
      FocusStateManager.dynamicSK();
    }, RENDERTIMEOUT);
    return this;
  };

  Recipients.prototype.focus = function() {
    view.get(this).focus();
    return this;
  };

  Recipients.prototype.visible = function(type, opts) {
    view.get(this).visible(type, opts || {});
    return this;
  };

  Recipients.prototype.isFocused = function() {
    return view.get(this).isFocused();
  };

  Recipients.prototype.deleteAll = function() {
    let recipientList = data.get(this);
    recipientList.splice(0, recipientList.length);
    this.emit('remove', recipientList.length);
    return this.render();
  };

  Recipients.View = function(owner, setup) {
    const inner = document.getElementById(setup.inner);
    const outer = document.getElementById(setup.outer);
    const outerCss = window.getComputedStyle(outer);
    const template = setup.template;
    let nodes = [];
    let clone;

    priv.set(this, {
      owner: owner,
      inner: inner,
      outer: outer,
      template: template,
      active: null,
      nodes: nodes,
      state: {
        isTransitioning: false,
        visible: 'singleline'
      },
      minHeight: parseInt(outerCss.getPropertyValue('min-height'), 10),
      mode: 'singleline-mode'
    });

    clone = inner.cloneNode(true);
    clone.innerHTML = template.interpolate(new Recipient());
    clone.firstElementChild.innerHTML = '';

    Object.defineProperties(this, {
      last: {
        get: function() {
          return nodes[nodes.length - 1];
        }
      },
      placeholder: {
        get: function() {
          let node = clone.firstElementChild.cloneNode(true);
          node.isPlaceholder = true;
          return node;
        }
      }
    });

    this.updateMode = Utils.debounce(this.updateMode, 100);

    ['keydown', 'input'].forEach((type) => {
      outer.addEventListener(type, this, false);
    });

    // Set focus on the last "placeholder" element.
    this.reset().focus();
  };

  Recipients.View.isFocusable = true;

  Recipients.View.suggest = false;

  Recipients.View.prototype.reset = function() {
    this.clear().render();
    return this;
  };

  Recipients.View.prototype.clear = function() {
    priv.get(this).inner.textContent = '';
    return this;
  };

  Recipients.View.prototype.render = function(opts) {
    const view = priv.get(this);
    const template = view.template, 
          list = view.owner.list,
          length = list.length;
    const nodes = view.nodes, 
          inner = view.inner;     
    let html = '';

    opts = opts || {};

    opts.addPlaceholder = opts.addPlaceholder === undefined ?
      true : opts.addPlaceholder;

    if (inner.textContent) {
      this.clear();
    }

    for (let i = 0; i < length; i++) {
      html += template.interpolate(list[i]);
    }

    if (opts.editable) {
      opts.addPlaceholder = false;
      html += template.interpolate(opts.editable);
    }

    if (html) {
      inner.innerHTML = html;
    }

    if (opts.addPlaceholder) {
      inner.appendChild(this.placeholder);
    }

    nodes.length = 0;

    if (!list.length) {
      nodes.push.apply(nodes, inner.children[0]);
    } else {
      nodes.push.apply(nodes, inner.children);
    }

    nodes.forEach((node, i) => {
      node.isPlaceholder = false;
      node.contentEditable = false;
      node.setAttribute('role', 'button');

      if (i === nodes.length - 1) {
        node.isPlaceholder = true;
        node.contentEditable = true;
        node.setAttribute('role', 'textbox');
        node.id = 'lastRecipient';
      } else {
        relation.set(node, list[i]);
      }
    });

    if (view.state.visible === 'singleline' && nodes.length) {
      inner.querySelector(':last-child').scrollIntoView(false);
    }

    this.updateMode();
    NavigationMap.reset('thread-messages');

    if (nodes[nodes.length - 1] &&
        document.activeElement.tagName === 'BODY') {
      nodes[nodes.length - 1].focus();
    }
    return this;
  };

  Recipients.View.prototype.isFocused = function() {
    const activeId = document.activeElement.parentNode.id;
    const recipientId = priv.get(this).inner.id;
    return activeId === recipientId;
  };

  Recipients.View.prototype.focus = function(node) {
    const view = priv.get(this);
    const range = document.createRange();
    const selection = window.getSelection();

    if (Recipients.View.isFocusable) {
      if (!node) {
        node = view.inner.lastElementChild;
        if (!node.isPlaceholder) {
          node = view.inner.appendChild(this.placeholder);
        }
      }

      if (node && node.isPlaceholder) {
        node.contentEditable = true;
        node.focus();
        node.classList.add('focus');
      }

      range.selectNodeContents(node);
      range.collapse(false);
      selection.removeAllRanges();
      selection.addRange(range);

      // Scroll to the bottom of the inner view.
      view.inner.scrollTop = view.inner.scrollHeight;
    }

    this.updateMode();

    return this;
  };

  Recipients.View.prototype.updateMode = function() {
    const view = priv.get(this);
    const mode = view.inner.scrollHeight > view.minHeight ?
      'multiline-mode' : 'singleline-mode';

    if (view.mode !== mode) {
      view.mode = mode;
      if (mode === 'singleline-mode' && view.state.visible === 'multiline') {
        this.visible('singleline', {
          refocus: this
        });
      }

      view.owner.emit('modechange', mode);
    }
  };

  const rtype = /^(multi|single)line$/;

  Recipients.View.prototype.visible = function(type, opts) {
    const view = priv.get(this);
    const state = view.state;
    const error = 'visible "type" (multiline or singleline)';

    opts = opts || {};

    if (!type) {
      throw new Error('Missing ' + error);
    }
    if (!rtype.test(type)) {
      throw new Error('Invalid ' + error);
    }
    if (state.visible !== type) {
      state.isTransitioning = false;
    }
    if (state.isTransitioning) {
      return this;
    }
    if (state.visible === type) {
      return this;
    }

    view.outer.addEventListener('transitionend', function transitionHandler() {
      let last = view.inner.lastElementChild;
      let previous;

      if (Navigation.isCurrentPanel('composer') &&
          state.visible === 'singleline') {
        while (last !== null && last.isPlaceholder) {
          previous = last.previousElementSibling;
          if (!last.textContent) {
            last.parentNode.removeChild(last);
          }
          last = previous;
        }

        if (opts.refocus) {
          opts.refocus.focus();
        }
      } else if (state.visible === 'multiline' && last !== null) {
        last.scrollIntoView(true);
      }

      state.isTransitioning = false;
      this.removeEventListener('transitionend', transitionHandler, false);
    });

    state.visible = type;
    state.isTransitioning = true;
    view.outer.className = type;
    view.inner.className = type;

    return this;
  };

  Recipients.View.prototype.handleEvent = function(event) {
    if (event.key === 'Enter' && document.activeElement.textContent === '') {
      event.preventDefault();
      event.stopPropagation();
      return;
    }

    let [isPreventingDefault, isAcceptedRecipient, 
         isDeletingRecipient, isDuplicateRecipient] =
        [false, false, false, false];
    let editable = 'false';
    let typed, recipient, length, toDelete, totalLength, lastString;
    const view = priv.get(this);
    const target = event.target;
    const keyCode = event.keyCode;

    Recipients.View.isFocusable = true;

    if (event.type === 'input' || event.type === 'keydown') {
      typed = target.textContent.trim();
      length = typed.length;
      totalLength = target.textContent.length;
      lastString = target.textContent.charCodeAt(totalLength - 1);
    }

    switch (event.type) {
      case 'keydown': {
        if (!event.target.classList.contains('focus')) {
          return;
        }

        if (typed) {
          this.ignore = true;
        }

        editable = event.target.getAttribute('contentEditable') === 'true' ?
          true : false;

        if (typed && keyCode === event.DOM_VK_RETURN) {
          if (Recipients.View.suggest) {
            Recipients.View.suggest = false;
          } else if (editable) {
            isAcceptedRecipient = true;
          }
          isPreventingDefault = true;
        }

        if (typed && editable &&
            InputUtils.recipientSuggestions.classList.contains('hide') &&
            (keyCode === event.DOM_VK_DOWN || keyCode === event.DOM_VK_UP)) {
          isAcceptedRecipient = true;
        }

        if (keyCode === event.DOM_VK_BACK_SPACE ) {
          if (typed && !target.isPlaceholder) {
            toDelete = target;
          } else if (!typed) {
            toDelete = target.previousSibling;
          }

          if (toDelete && !toDelete.isPlaceholder) {
            recipient = relation.get(toDelete);
            view.owner.remove(recipient);
            isDeletingRecipient = isPreventingDefault = true;
          } else {
            if (length === 0) {
              if (ValueDefault.activitymode) {
                event.preventDefault();
                ActivityModule.back();
              } else {
                event.preventDefault();
                ThreadUI.back();
              }
            }
          }
        }
        break;
      }
      case 'input': {
        // Input rules:
        // 1. First input space, not input successfully.
        // 2. last input space, create recipients.
        const DOM_VK_SPACE = 32;
        // Present the beginning flag of Chinese characters.
        const DOM_VK_CIRCUMFLEX = 160;
        if ((lastString === DOM_VK_SPACE || lastString === DOM_VK_CIRCUMFLEX) && 
            !event.isComposing) {
          if (length === 0) {
            target.textContent = '';
          } else {
            isAcceptedRecipient = true;
          }
        }

        if (!isAcceptedRecipient && (typed && typed.length >= 1)) {
          this.visible('singleline', { refocus: target });
        }
        SoftkeyManager.updateSksOnRecipientChanged(typed.length);
        this.updateMode();

        // Delete the extra br tag if div tag is deleted to null body.
        const recipientNode = document.getElementById('messages-recipients-list');
        const recipientDivs = recipientNode.querySelectorAll('div');
        const lastRecipientDiv = recipientDivs[recipientDivs.length - 1];
        const brNode = lastRecipientDiv.querySelector('br');
        if (target.textContent.length === 0 && brNode) {
          lastRecipientDiv.innerHTML = '';
        }

        break;
      }
    }

    if (isAcceptedRecipient) {
      if (typed) {
        const recipientsNumber = RecipientManager.recipients;
        if (recipientsNumber.numbers.includes(typed)) {
          isPreventingDefault = true;
          isDuplicateRecipient = true;
          Utils.showToaster({ messageL10nId: 'recipient-repeat' });
        } else {
          view.owner.add({
            name: typed,
            number: typed,
            editable: editable,
            source: 'manual',
            role: editable ? 'textbox' : 'button',
            isLookupable: false
          });
        }

        this.render().focus();
      }
    } else {
      if (length === 0 && event.type === 'keydown' && (keyCode === event.DOM_VK_UP ||
          keyCode === event.DOM_VK_DOWN || keyCode === event.DOM_VK_RETURN)) {
        target.textContent = '';
      }
    }

    if (isDeletingRecipient) {
      let parentNode = document.activeElement.parentNode;
      parentNode.childNodes[removeIndex].focus();
      document.querySelector('#lastRecipient').classList.remove('focus');
    }

    isDuplicateRecipient &&
      document.querySelector('#lastRecipient').classList.add('focus');

    if (isPreventingDefault) {
      event.preventDefault();
    }
  };

  exports.Recipients = Recipients;
}(this));
