/* global Template, SuggestionManager, DraftUtils, ContactsServiceManager, Recipients, 
          ValueDefault, ThreadUI, Navigation, FocusStateManager, EventDispatcher */

'use strict';

let RecipientManager = {
  recipients: null,

  init: function() {
    this.recipientsList = document.querySelector('#messages-recipients-list');
    this.tmpl = Template('messages-recipient-tmpl');
  },

  // Recipients field init.
  initRecipients: function() {
    if (this.recipients) {
      this.recipients.length = 0;
      this.recipients.visible('singleline');
    } else {
      this.recipients = new Recipients({
        outer: 'messages-to-field',
        inner: 'messages-recipients-list',
        template: this.tmpl
      });

      this.recipients.on('add', this.recipientsChanged.bind(this));
      this.recipients.on('remove', this.recipientsChanged.bind(this));
      this.recipients.on('modechange', this.recipientsModeChange.bind(this));
    }
    SuggestionManager.toggleRecipientSuggestions();
  },

  // Recipients changed handler.
  recipientsChanged: function(length, record) {
    // TaskGF5GTMO-3591-porting from Defect10748265-tingting.chao-on 24/08/23-begin
    // TaskGF5GDISH-2157-tingting.chao-add ATT
    if ((OperatorUtils.isTMOFamily() || OperatorUtils.isATTFamily() || (OperatorUtils.isVZWFamily() && Compose.type === 'sms'))
      && this.recipients.length > ValueDefault.RECIPIENTS_MMS_BOX_LIMIT) {
      Toaster.showToast({ messageL10nId: 'recipients-limit-vzw' });
      this.recipientsList.lastChild.textContent = '';
      SuggestionManager.toggleRecipientSuggestions();
      this.recipients.remove(length - 1);
      return;
    }
    //TaskGF5GTMO-3591-porting from Defect10748265-tingting.chao-on 24/08/23-begin-end
    if (DraftUtils.draft) {
      DraftUtils.draft.isEdited = true;
    }
    let isOk = true;
    let strategy;

    if (record && (record.isQuestionable || record.isLookupable)) {
      if (record.isQuestionable) {
        isOk = false;
      }

      strategy = record.isLookupable ? 'searchContact' : 'exactContact';

      ContactsServiceManager[strategy](
        record.number, 
        ContactsServiceManager.validateContact.bind(ContactsServiceManager, record)
      );
    }

    SuggestionManager.toggleRecipientSuggestions();

    if (isOk) {
      if (!ValueDefault.activitymode) {
        ThreadUI.updateComposerHeader();
      }

      this.emitChangeEvent();
    }
  },

  emitChangeEvent: function() {
    this.emit('recipientschange');
  },

  recipientsModeChange: function(mode) {
    const threadMessages = document.getElementById('thread-messages');
    threadMessages.classList.toggle('multiline-recipients-mode',
                                     mode === 'multiline-mode');
  },

  // Create recipients form edit mode.
  assimilateRecipients: function(args) {
    const isNew = Navigation.isCurrentPanel('composer') || 
                  ValueDefault.activitymode;
    let node = this.recipientsList.lastChild;
    let typed;

    if (!isNew || node === null) {
      return;
    }

    Recipients.View.isFocusable = false;
    this.recipients.visible('singleline');

    do {
      if (node.isPlaceholder) {
        typed = node.textContent.trim();

        if (typed === ';') {
          node.textContent = '';
          break;
        }

        if (typeof args === 'string') {
          if (args === 'false') {
            node.textContent = '';
          }
          break;
        }
        if (typed) {
          this.recipients.add({
            name: typed,
            number: typed,
            source: 'manual'
          });
          break;
        }
      }
    } while ((node = node.previousSibling));
  },

  // Recipients focus.
  setRecipientFocus: function() {
    Recipients.View.isFocusable = true;
    this.recipients.focus();
    setTimeout(() => {
      FocusStateManager.dynamicSK();
    });
  }
};

EventDispatcher.mixin(RecipientManager, ['recipientschange']);
