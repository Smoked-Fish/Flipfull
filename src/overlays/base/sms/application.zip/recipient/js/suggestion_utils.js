/* global EventManager, SoftkeyManager */

'use strict';

// eslint-disable-next-line no-unused-vars
let RecipientUtils = {
  selectRecipientSuggestion: function() {
    const selected =
      document.querySelector('#messages-recipient-suggestions li.selected a');
    if (selected) {
      new Promise((resolve) => {
        selected.click();
        resolve();
      }).then(() => {
        EventManager.stopContactNavigation();
        const recipient_focus = document.getElementById('messages-to-field');
        recipient_focus.lastChild && recipient_focus.lastChild.focus();
        SoftkeyManager.show([SoftkeyManager.skAddContact]);
      });
    }
  }
};
