/* global Startup, NavigationMap, EventDispatcher */

(function(window) {

  'use strict';

  function catchError(e) {
    if (e) {
      console.error(
        'Navigation.toPanel: got an exception: (%s) %s',
        e, e.stack && e.stack.replace(/\n/g, '|')
      );
    } else {
      console.log('Navigation.toPanel: got a rejected promise');
    }
  }

  let queuedPanel;

  function nextQueuedPanel() {
    if (queuedPanel) {
      let next = queuedPanel;
      queuedPanel = null;
      Navigation.toPanel(next.panel, next.args)
        .then(next.defer.resolve, next.defer.reject);
    }
  }

  let Navigation = {
    isReady: false,
    panelObjects: window,

    defaultPanel: 'thread-list',
    activityHash: 'activity-latest-message',
    currentPanel: null,

    panels: {
      'thread': {
        behaviour: 'ThreadUI',
        wrapperPosition: 'left',
        container: 'thread-messages'
      },
      'thread-list': {
        behaviour: 'ThreadListUI',
        wrapperPosition: 'right',
        container: 'thread-list'
      },
      'composer': {
        behaviour: 'ThreadUI',
        wrapperPosition: 'left',
        container: 'thread-messages'
      },
      'report-view': {
        behaviour: 'ReportView',
        wrapperPosition: 'left',
        container: 'thread-messages'
      },
      'settings-view': {
        behaviour: 'SettingsUI',
        wrapperPosition: 'right',
        container: 'messaging-settings'
      },
      'search-message-view': {
        behaviour: 'SearchMessageUI',
        wrapperPosition: 'right',
        container: 'searchMessage'
      }
    },

    init: function() {
      this.mainWrapper = document.getElementById('main-wrapper');
      this.transitionPromise = null;

      Startup.on('post-initialize', () => {
        this.isReady = true;
        nextQueuedPanel();
      });
    },

    // Judege whether it is the current panel.
    isCurrentPanel: function(panel, args) {
      if (!this.currentPanel || !panel) {
        return false;
      }

      if (panel !== this.currentPanel.panel) {
        return false;
      }

      if (!args) {
        return true;
      }

      const currentArgs = this.currentPanel.args || {};

      for (let arg in args) {
        if (args[arg] !== currentArgs[arg]) {
          return false;
        }
      }

      return true;
    },

    // Default panel judge.
    isDefaultPanel: function() {
      const panelName = this.getPanelName();
      return !panelName || panelName === this.defaultPanel || 
             panelName === this.activityHash;
    },

    ensureCurrentPanel: function() {
      if (this.transitionPromise) {
        return this.transitionPromise;
      }

      if (!this.currentPanel) {
        return this.toPanel(this.defaultPanel);
      }

      return Promise.resolve();
    },

    // Route key function.
    toPanel: function(panel, args) {
      if (!(panel in this.panels)) {
        return Promise.reject(new Error('Panel ' + panel + ' is unknown.'));
      }

      const notReadyNavigate = (panel !== this.defaultPanel && !this.isReady);
      if (this.transitionPromise || notReadyNavigate) {
        queuedPanel = {
          panel: panel,
          args: args
        };

        return new Promise(function(resolve, reject) {
          queuedPanel.defer = {
            resolve: resolve,
            reject: reject
          };
        });
      }

      if (this.isCurrentPanel(panel, args)) {
        return Promise.resolve();
      }

      let transitionArgs = args || {};

      document.activeElement.blur();

      transitionArgs.meta = {
        next: {
          panel: panel,
          args: args
        },
        prev: this.currentPanel
      };

      let nextPanelInfo = this.panels[panel];
      const nextPanelContainer = document.getElementById(nextPanelInfo.container);
      const nextPanelObject = this.panelObjects[nextPanelInfo.behaviour];

      if (!nextPanelObject) {
        const error = new Error(
          'Navigation.toPanel: no behaviour found for panel ' + panel
        );
        return Promise.reject(error);
      }

      let currentPanelObject;
      let currentPanelContainer;
      if (this.currentPanel) {
        const currentPanelInfo = this.panels[this.currentPanel.panel];
        currentPanelObject = this.panelObjects[currentPanelInfo.behaviour];
        currentPanelContainer = 
          document.getElementById(currentPanelInfo.container);
      }

      let promise = Promise.resolve();

      if (currentPanelObject && currentPanelObject.beforeLeave) {
        promise = promise.then(
          currentPanelObject.beforeLeave.bind(currentPanelObject, transitionArgs)
        );
      }

      if (nextPanelObject.beforeEnter) {
        promise = promise.then(
          nextPanelObject.beforeEnter.bind(nextPanelObject, transitionArgs)
        );
      }

      const prevPanel = this.currentPanel;
      promise = promise.then(() => {
        this.currentPanel = null;
      });

      promise = promise.then(
        this.slide.bind(this, nextPanelInfo.wrapperPosition)
      ).then(() => {
        if (NavigationMap.onPanelChanged) {
          NavigationMap.onPanelChanged(
            (prevPanel ? prevPanel.panel : null), panel, args);
        }

        this.currentPanel = {
          panel: panel,
          args: args
        };
      });

      promise = promise.then(() => {
        let promise = Promise.resolve();
        if (currentPanelObject && currentPanelObject.afterLeave) {
          promise = promise.then(
            currentPanelObject.afterLeave.bind(currentPanelObject, transitionArgs)
          ).catch(catchError);
        }

        if (nextPanelObject.afterEnter) {
          promise = promise.then(
            nextPanelObject.afterEnter.bind(nextPanelObject, transitionArgs)
          ).catch(catchError);
        }

        return promise;
      });

      promise = promise.then(() => {
        this.transitionPromise = null;
        if (nextPanelContainer === currentPanelContainer) {
          return;
        }
        nextPanelContainer.setAttribute('aria-hidden', false);
        if (currentPanelContainer) {
          currentPanelContainer.setAttribute('aria-hidden', true);
        }
      }, (e) => {
        catchError(e);
        this.transitionPromise = null;
        return Promise.reject(new Error('Error while transitioning'));
      });

      promise.then(() => 
        this.emit('navigated', { panel: panel, args: args })).
        then(nextQueuedPanel, nextQueuedPanel);

      return (this.transitionPromise = promise);
    },

    toDefaultPanel: function(args) {
      return this.toPanel(this.defaultPanel, args);
    },

    slide: function(position) {
      const wrapper = this.mainWrapper;

      if (wrapper.dataset.position === position) {
        return Promise.resolve();
      }

      wrapper.dataset.position = position;

      return Promise.resolve();
    },

    // Panel name get.
    getPanelName: function() {
      let hash = window.location.hash;
      if (hash.length && hash.startsWith('#')) {
        hash = hash.slice(1);
      }

      let index;
      if ((index = hash.indexOf('&')) !== -1) {
        hash = hash.slice(0, index);
      }

      return hash;
    }
  };

  window.Navigation = EventDispatcher.mixin(Navigation, ['navigated']);
})(window);
