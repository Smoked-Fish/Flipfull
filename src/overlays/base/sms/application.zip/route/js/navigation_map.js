/* global ValueDefault, ThreadUI, InputUtils, OptionManager, Navigation, Startup, 
          Utils, SoftkeyManager, RecipientManager, SwitchHandler, ConversationEdit,
          FocusStateManager, DialogManager, NotificationBase */

(function(exports) {
  'use strict';

  //container id
  const THREAD_CONTAINER = 'thread-list';
  const MESSAGE_CONTAINER = 'thread-messages';
  const SETTINGS_CONTAINER = 'messaging-settings';
  const MESSAGES_INPUT = 'messages-input';
  const SEARCH_CONTAINER = 'searchMessage';
  //panel id
  const PANEL_THREAD_LIST = 'thread-list';
  const PANEL_SETTINGS = 'settings-view';
  const PANEL_COMPOSER = 'composer';
  const PANEL_THREAD = 'thread';
  //option menu is not a panel, but still keep it's elements
  const OPTION_MENU = 'option-menu';
  const PANEL_SEARCH_MESSAGE = 'search-message-view';
  const CHANGE_MODE = {
    none: 'none',
    added: 'added',
    removed: 'removed',
  };
  const TimeOut = 500;
  const OPTION_MENU_CLASSES = ['group-menu', 'contact-prompt'];

  let controls = {};
  let curPanel = null;
  let nav_id = 0;
  let _storeFocused = null;
  let _savedId = null;

  function navUpdate(elements) {
    let id = nav_id;
    let element = null;
    const len = elements.length;

    for (let i = 0; i < len; i++) {
      element = elements[i];
      element.setAttribute('data-nav-id', id);

      element.style.setProperty('--nav-left', -1);
      element.style.setProperty('--nav-right', -1);
      element.style.setProperty('--nav-down', id + 1);
      element.style.setProperty('--nav-up', id - 1);
      element.setAttribute('tabindex', 0);
      id++;
    }

    elements[0].style.setProperty('--nav-up', id - 1);
    elements[len - 1].style.setProperty('--nav-down', nav_id);
    nav_id = id;
  }

  function navUpdateHorizontal(elements) {
    let id = 0;
    let element = null;
    const len = elements.length;
    const first = elements[0].getAttribute('data-nav-id');
    const last = elements[len - 1].getAttribute('data-nav-id');
    const up = elements[0].style.getPropertyValue('--nav-up');
    const down = elements[len - 1].style.getPropertyValue('--nav-down');

    for (let i = 0; i < len; i++) {
      element = elements[i];
      id = parseInt(element.getAttribute('data-nav-id'));
      if (down === first && up === last) {
        element.style.setProperty('--nav-left', id);
        element.style.setProperty('--nav-right', id);
        element.style.setProperty('--nav-down', id);
        element.style.setProperty('--nav-up', id);
      } else {
        element.style.setProperty('--nav-left', id - 1);
        element.style.setProperty('--nav-right', id + 1);
        element.style.setProperty('--nav-down', down);
        element.style.setProperty('--nav-up', up);
      }
    }

    elements[0].style.setProperty('--nav-left', last);
    elements[len - 1].style.setProperty('--nav-right', first);
  }

  function getCurContainerId() {
    let id;
    id = (ValueDefault.activitymode || ValueDefault.isFromNotification) ?
         'thread-messages' : Navigation.panels[curPanel].container;
    if (_savedId === 'messages-container') {
      id = _savedId;
    }
    return id;
  }

  function getCurControl() {
    let control = null;
    let id = getCurContainerId();

    if (id) {
      control = controls[id];
    }
    return control;
  }

  function getCurItem() {
    let item = null;
    const curControl = getCurControl();

    if (curControl) {
      if (curControl.index >= 0 &&
          curControl.index < curControl.elements.length) {
        item = curControl.elements[curControl.index];
      }
    }
    return item;
  }

  function sendIndexEvent(panel, index, item) {
    const event = new CustomEvent('index-changed', {
      detail: {
        panel: panel,
        index: index,
        focusedItem: item
      },
      bubbles: true,
      cancelable: false
    });

    window.dispatchEvent(event);
  }

  function setCurIndex(index) {
    let curControl = getCurControl();

    if (curControl) {
      if (index >= -1 && index < curControl.elements.length) {
        curControl.index = index;

        /*broadcoast change event*/
        sendIndexEvent(curPanel, index, (index === -1) ? null : 
                                                         curControl.elements[index]);
      }
    }
  }

  function observeChange(id) {
    const config = {
      childList: true,
      subtree: true,
      attributes: true,
    };

    const observer = new MutationObserver((mutations) => {
      let changed = CHANGE_MODE.none;
      let nodes = [];

      mutations.forEach((mutation) => {
        if (changed === true) {
          return;
        }

        if (mutation.type === 'childList') {
          if (mutation.addedNodes.length > 0) {
            nodes = Array.prototype.slice.call(mutation.addedNodes);
            nodes.forEach((node) => {
              if (node.classList && node.classList.length > 0 && node.nodeName === 'LI') {
                changed = CHANGE_MODE.added;
              }
            });
          } else if (mutation.removedNodes.length > 0) {
            nodes = Array.prototype.slice.call(mutation.removedNodes);
            nodes.forEach((node) => {
              if (node.classList && node.classList.length > 0 && node.nodeName === 'LI') {
                changed = CHANGE_MODE.removed;
              }
            });
          }
        }
      });

      if (changed !== CHANGE_MODE.none) {
        // If edit mode, need reset special container page.
        if (typeof ConversationEdit !== 'undefined' && ConversationEdit.isInEditMode()) { // TaskGF5GTMO-3552-Porting from defect10669883-tingting.chao on 24//08/20-modified
          NavigationMap.reset('messages-container');
        } else {
          NavigationMap.reset(id);
        }

        if (changed === CHANGE_MODE.added) {
          onNodesAdded(id);
        }
        else if (changed === CHANGE_MODE.removed) {
          onNodesRemoved(id);
        }
      }
    });

    observer.observe(document.getElementById(id), config);
  }

  function onNodesAdded(containerId) {
    if (curPanel === PANEL_THREAD_LIST && containerId === THREAD_CONTAINER) {
      if (window.option.menuVisible === false) {
        NavigationMap.setFocus('first');
      }
      else {
        const control = controls[containerId];
        if (control && control.elements.length > 0) {
          if (_storeFocused) {
            _storeFocused.classList.remove('hasfocused');
          }
          _storeFocused = control.elements[0];
          _storeFocused.classList.add('hasfocused');
        }
        setCurIndex(0);
      }
    }
  }

  function onNodesRemoved(containerId) {
    let control = controls[containerId];
    let index = 0;

    if (!control) {
      return;
    }

    const container = document.getElementById(containerId);
    const focused = container ? container.querySelector('.focus') : null;

    if (focused) {
      const elements = Array.prototype.slice.call(control.elements);
      index = elements.indexOf(focused);
      if (control.index !== -1) {
        setCurIndex(index); 
      }
    } else {
      if (control.index >= 0 && control.index < control.elements.length) {
        index = control.index;
      } else if (control.index >= control.elements.length) {
        index = control.elements.length - 1;
      }

      if (getCurContainerId() === containerId) {
        NavigationMap.setFocus(index);
      } else {
        control.index = index;
      }
    }
  }

  function optionMenu() {
    _storeFocused = document.querySelector('.focus');
    if (_storeFocused && _storeFocused.tagName !== 'INPUT') {
      _storeFocused.classList.add('hasfocused');
    }
    NavigationMap.optionReset();
    document.removeEventListener('transitionend', optionMenu);
  }

  function recoverFocus() {
    if (_storeFocused) {
      _storeFocused.classList.remove('hasfocused');
      _storeFocused.classList.add('focus');
      _storeFocused.focus();
    }

    document.removeEventListener('transitionend', recoverFocus);
  }

  // Option menu listener.
  function observeOption() {
    const config = {
      attributes: true,
      chatacterData: true,
      subtree: true,
    };

    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.attributeName === 'class') {
          let contained = false;
          OPTION_MENU_CLASSES.forEach((optClass) => {
            if (mutation.target.classList.contains(optClass)) {
              contained = true;
            }
          });

          if (!contained) {
            return;
          }

          if (mutation.target.classList.contains('visible')) {
            mutation.target.id = OPTION_MENU;
            document.addEventListener('transitionend', optionMenu);
          } else {
            document.addEventListener('transitionend', recoverFocus);
          }
        }
      });
    });

    observer.observe(document.body, config);
  }

  let NavigationMap = {
    toDraft: false,

    init: function() {
      window.addEventListener('moz-app-loaded', () => {
        NavigationMap.reset(THREAD_CONTAINER);

        observeChange(THREAD_CONTAINER);
        observeChange(MESSAGE_CONTAINER);
        observeChange(SEARCH_CONTAINER);
      });

      window.addEventListener('moz-app-cache-complete', () => {
        NavigationMap.reset(THREAD_CONTAINER);

        // Focus always to first element at first enter list.
        if (curPanel === PANEL_THREAD_LIST) {
          NavigationMap.setFocus('first');
        }
      });

      document.addEventListener('focusChanged', (e) => {
        const focusedItem = e.detail.focusedElement;
        const curControl = getCurControl();
        if (curControl && curControl.elements) {
          // Convert to an array.
          const elements = Array.prototype.slice.call(curControl.elements);
          // Find the index of focused item in current control.
          const index = elements.indexOf(focusedItem);
          if (index >= 0) {
            // Update index.
            setCurIndex(index);
          }
        }

        window.dispatchEvent(new CustomEvent('message-focusChanged', {
          bubbles: true,
          cancelable: false
        }));
      });

      observeOption();
    },

    // Focus element set main function.
    setFocus: function(id) {
      // If there is option menu exist, we should not reset the focus.
      // Page switch speed is quicker than option menu close, so need use flag to judge it.
      if (OptionManager.isOptionMenuShown() || DialogManager.isDialogShown()) {
        return;
      }

      const curControl = getCurControl();
      if (!curControl || curControl.elements.length === 0) {
        return;
      }

      id = id || 0;
      id = (id === 'first') ? 
        0 : ((id === 'last') ? curControl.elements.length - 1 : id);

      if (id >= 0 && id < curControl.elements.length) {
        // Remove current focus, only one element has focus.
        const focused = document.querySelectorAll('.focus');
        for (let i = 0; i < focused.length; i++) {
          focused[i].classList.remove('focus');
        }

        // If the app is background, not focus immediately.
        if (ValueDefault.activitymode || ValueDefault.isFromNotification || 
            !Startup.messageReceive || !document.hidden || 
            !Navigation.isCurrentPanel('thread-list')) {
          const toFocused = curControl.elements[id];
          toFocused.setAttribute('tabindex', 1);
          toFocused.classList.add('focus');
          toFocused.focus();
          toFocused.scrollIntoView(false);
        }
      } else if (id >= curControl.elements.length) {
        this.setFocus('first');
        return;
      }

      // id may be -1.
      setCurIndex(id);
      window.dispatchEvent(new CustomEvent('message-focusChanged'));
    },

    updateFocus: function() {
      if (DialogManager.isDialogShown()) {
        return;
      }
      
      // Do not should add focus class to body element.
      if (!document.activeElement.classList.contains('focus') &&
          document.activeElement.tagName !== 'BODY' && 
          document.activeElement.id !== 'no-result-message') {
        document.activeElement.classList.add('focus');
      }
    },

    setFocusToFixedElement: function(tag) {
      const index =  
        Utils.getItemIndex(NavigationMap.getCurrentControl().elements, tag);
      NavigationMap.setFocus(index);
    },

    setFocusToKnownElement: function(element) {
      element.focus();
      element.classList.add('focus');
      if (element.tagName === 'A') {
        SoftkeyManager.updateLinkSKs();
      } else if (element.tagName === 'IFRAME') {
        SoftkeyManager.updateAttachmentKey();
      } else if (element.tagName === 'DIV' && element.classList.contains('recipient')) {
        SoftkeyManager.updateSksOnRecipientChanged(0);
      } else if (element.tagName === 'SECTION' && element.classList.contains('attachment-composer')) {
        FocusStateManager.dynamicSK();
      }
    },

    // Recovery the focus when the page switch or node change.
    recoveryFocus: function() {
      const toFocus = document.querySelector('.focus');
      if (toFocus) {
        toFocus.focus();
      }
    },

    // Recovery the focus when the page switch to list.
    resetListFocus: function() {
      setTimeout(() => {
        const threadId = 'thread-' + ValueDefault.draftSaveId;
        NavigationMap.setFocusToFixedElement(threadId);
        SoftkeyManager.updateSKs();
        ValueDefault.draftSaveId = null;
      });
    },

    // Index update function map.
    updateCurIndex: function(id, containerId) {
      let control = controls[id];
      const node = document.getElementById(containerId);
      const nodeArray = Array.prototype.slice.call(control.elements);
      control.index = nodeArray.indexOf(node);
    },

    reset: function(id) {
      let query = id === 'thread-list' ? '.navigable:not(.hide)' :
                                         '.navigable:not([hidden])';
      if (id === 'messages-container') {
        query = 'li' + query;
      }
      this.navSetup(id, query);
    },

    // Route focus params set.
    navSetup: function(containerId, query) {
      _savedId = containerId;
      let elements = [];
      let container = (containerId === undefined) ?
        document.body : (document.getElementById(containerId) ||
                         document.querySelector(containerId));

      if (containerId === OPTION_MENU) {
        const MAIN_MENU = 'menu#mainmenu';
        container = document.querySelector(MAIN_MENU);
      }

      if (container && query) {
        elements = container.querySelectorAll(query);
        if (elements.length > 0) {
          navUpdate(elements);
        }

        const recipients = container.querySelectorAll(query + '.recipient');
        if (recipients.length > 0) {
          navUpdateHorizontal(recipients, true);
        }
      }

      if (containerId && elements) {
        if (!controls[containerId]) {
          controls[containerId] = {};
          controls[containerId].index = (elements.length > 0) ? 0 : -1;
        }
        controls[containerId].elements = elements;
      }
    },

    lockNav: function(event) {
      if (this.currentActivatedLength > 0 || this.lockNavigation) {
        return true;
      }

      if (document.activeElement.type === 'select-one') {
        return true;
      }

      return (this.inMessageElement(event.key));
    },

    inMessageElement: function(key) {
      const MIN_HEIGHT_PORTRAIT = 200;
      const MIN_HEIGHT_LANDSCAPE = 102;
      const MIN_IN_ELEMNT_HEIGHT = screen.orientation.type.startsWith('portrait') ?
            MIN_HEIGHT_PORTRAIT : MIN_HEIGHT_LANDSCAPE;
      const MAX_BOTTOM_HEIGHT = 100;
      let current = document.activeElement;

      // Not a message li.
      if (current.tagName !== 'LI' || !current.classList.contains('message')) {
        return false;
      }

      const currentOffsetHeight = current.offsetHeight;
      const currentOffsetTop = current.offsetTop;
      const container = document.getElementById('messages-container');
      const containerTop = container.scrollTop;
      const containerClientHeight = container.clientHeight;
      const containerScrollHeight = container.scrollHeight;

      if (currentOffsetHeight > MIN_IN_ELEMNT_HEIGHT) {
        if (key === 'ArrowDown') {
          if ((containerTop < (currentOffsetHeight +
               currentOffsetTop - MAX_BOTTOM_HEIGHT)) &&
              (containerTop + containerClientHeight < containerScrollHeight)) {
            return true;
          }
        } else if (key === 'ArrowUp') {
          if (containerTop > currentOffsetTop) {
            return true;
          }
        }
      }
      return false;
    },

    // Option menu focus param set.
    optionReset: function() {
      const SUB_MENU = 'menu[data-subtype="submenu"]';
      const MENU_BUTTON = '.menu-button';
      let i;

      this.navSetup(OPTION_MENU, MENU_BUTTON);

      // Set navigation for submenu.
      const submenu = document.querySelectorAll(SUB_MENU);
      for (i = 0; i < submenu.length; i++) {
        NavigationMap.navSetup('#' + submenu[i].id, MENU_BUTTON);
      }

      // Remove current focus, only one element has focus.
      const focused = document.querySelectorAll('.focus');
      for (i = 0; i < focused.length; i++) {
        focused[i].classList.remove('focus');
      }

      const toFocused = controls[OPTION_MENU].elements[0];
      if (toFocused) {
        toFocused.setAttribute('tabindex', 1);
        toFocused.classList.add('focus');
        toFocused.focus();
      }
    },

    // get index element.
    getCurrentItem: function() {
      return getCurItem();
    },

    getCurrentControl: function() {
      return getCurControl();
    },

    // Route page focus handler.
    // eslint-disable-next-line no-unused-vars
    onPanelChanged: function(from, to, args) {
      curPanel = to;

      switch (to) {
        case PANEL_SETTINGS:
          if (from === PANEL_THREAD_LIST) {
            if (OptionManager.isOptionMenuShown()) {
              document.addEventListener('transitionend', function optionMenu() {
                document.removeEventListener('transitionend', optionMenu);
                NavigationMap.reset(SETTINGS_CONTAINER);
                NavigationMap.setFocus(0);
              });
            } else {
              setTimeout(() => {
                this.reset(SETTINGS_CONTAINER);
                this.setFocus(0);
              }, TimeOut);
            }
          } else {
            setTimeout(() => {
              this.reset(SETTINGS_CONTAINER);
              const control = getCurControl();
              this.setFocus(control ? control.index : 0);
            }, TimeOut);
          }
          break;
        case PANEL_SEARCH_MESSAGE:
          this.reset(SEARCH_CONTAINER);
          if (from === PANEL_THREAD_LIST) {
            setTimeout(() => {
              this.setFocus(0);
            }, TimeOut);
          } else {
            setTimeout(() => {
              const control = getCurControl();
              this.setFocus(control ? control.index : 0);
            }, TimeOut);
          }
          break;
        case PANEL_COMPOSER:
          setTimeout(() => {
            const control = getCurControl();
            if (control) {
              // Composer Focus Rules 
              // 1. Have recipients, focus on input box.
              // 2. Not have recipients, focus on recipient field.
              if (ThreadUI.forceFocusInput || RecipientManager.recipients.length !== 0) {
                ThreadUI.forceFocusInput = false;
                NavigationMap.setFocusToFixedElement('messages-input');
              } else {
                NavigationMap.setFocus(0);
              }
            }
          });
          break;
        case PANEL_THREAD:
          if (ThreadUI.isBackToThreadUI) {
            ThreadUI.isBackToThreadUI = false;
            break;
          }
          setTimeout(() => {
            const control = getCurControl();
            if (control && !SwitchHandler.isSwitchCase) {
              NavigationMap.setFocusToFixedElement('messages-input');
            }
          });
          break;
        default:
          setTimeout(() => {
            const control = getCurControl();
            if (!this.toDraft) {
              if (control && control.elements.length > 0) {
                this.setFocus((control.index === -1) ? 0 : control.index);
              }
            } else {
              this.toDraft = false;
            }
          });
          break;
      }
    },

    // Confirm element is always visible.
    scrollToElement: function(element, evt) {
      const SUB_HEADER_HEIGHT = 24;
      const threadsContainer = document.getElementById('threads-container');

      if (evt.key === 'ArrowDown' && element.classList.contains('hidden') &&
          element.parentElement.classList.contains('message-list')) {
        ValueDefault.isFromNotification ? 
          NotificationBase.showChunkOfMessages(ValueDefault.CHUNK_SIZE, evt.key) : 
          ThreadUI.showChunkOfMessages(ValueDefault.CHUNK_SIZE, evt.key);  
      }

      const checkEdge = this.checkElement(element);
      if (checkEdge.match) {
        if (checkEdge.top && !ValueDefault.isFromNotification && 
            !Navigation.isCurrentPanel('thread')) {
          element.scrollIntoView(false);
        } else {
          element.scrollIntoView(true);
        }
      } else {
        if (!this.isVisible(element)) {
          if (evt.key === 'ArrowUp' || ((ValueDefault.isFromNotification || 
              Navigation.isCurrentPanel('thread')) && !window.option.menuVisible)) {
            element.scrollIntoView(true);
          } else {
            element.scrollIntoView(false);
          }
        }
      }

      if (element.id && element.id === MESSAGES_INPUT) {
        InputUtils.adjustScrollElement();
      }

      if (evt.key === 'ArrowUp' &&
          element.classList.contains('threadlist-item')) {
        if (element.offsetTop <=
            (threadsContainer.scrollTop + element.offsetHeight / 2)) {
          threadsContainer.scrollTop -= SUB_HEADER_HEIGHT;
        }
      }
    },

    isVisible: function(element) {
      if (element.offsetWidth === 0 || element.offsetHeight === 0) {
        return false;
      }

      const HEADERHEIGHT = document.querySelector('.view-header').clientHeight;
      const SOFTHEIGHT = document.getElementById('softkeyPanel').clientHeight;
      const deltaHeight = { header: HEADERHEIGHT, softkey: SOFTHEIGHT };
      if ((ValueDefault.isFromNotification || Navigation.isCurrentPanel('thread')) && 
          !window.option.menuVisible) {
        deltaHeight.softkey += document.getElementById('messages-compose-form').clientHeight;
      }
      const height = document.documentElement.clientHeight - deltaHeight.softkey;
      const rects = element.getClientRects();

      if (window.option.menuVisible) {
        deltaHeight.header +=
          document.getElementById('option-menu').querySelector('h1').clientHeight;
      }

      for (let i = 0, l = rects.length; i < l; i++) {
        const r = rects[i];
        let inView = false;
        if ((r.bottom >= deltaHeight.header && r.bottom <= height) &&
            (r.top >= deltaHeight.header)) {
          inView = true;
        }
        if (r.top < r.height) {
          inView = false;
        }
        if (inView) {
          return true;
        }
      }
      return false;
    },

    checkElement: function(element) {
      let match = false;
      let top = false;
      const elmStyle = element.style;
      const navId = parseInt(element.dataset.navId);
      const navUpId = parseInt(elmStyle.getPropertyValue('--nav-up'));
      const navDownId = parseInt(elmStyle.getPropertyValue('--nav-down'));
      if (navId <= navUpId) {
        match = true;
        top = true;
      } else if (navId >= navDownId) {
        match = true;
        top = false;
      }
      return {
        match: match,
        top: top
      };
    },

    // Need clear store focus when the subject/attachment field is hidden.
    clearSubjectStoreFocus: function() {
      if (_storeFocused && _storeFocused.id === 'subject-composer-input') {
        _storeFocused = null;
      }
    },

    clearAttachmentStoreFocus: function() {
      if (_storeFocused && _storeFocused.classList.contains('attachment-composer')) {
        _storeFocused = null;
      }
    },

    // Click event hankder.
    handleClick: function(event) {
      if (event.target.id === 'messages-input') {
        const currentFocus = document.querySelector('.focus');
        if (currentFocus.nodeName === 'IFRAME') {
          currentFocus.click();
        }
        return;
      }
      event.target.click();
      for (let i = 0; i < event.target.children.length; i++) {
        event.target.children[i].click();
      }
    }
  };

  exports.NavigationMap = NavigationMap;
})(window);
