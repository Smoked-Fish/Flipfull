(function(exports) {
  'use strict';

  const ERRORS = new Map();

  function initErrorsMap() {
    ERRORS.set('NoSimCardError', {
      prefix: 'sendMissingSimCard'
    });

    ERRORS.set('RadioDisabledError', {
      prefix: 'sendFlightMode'
    });

    ERRORS.set('FdnCheckError',{
      prefix: 'fdnError',
      showRecipient: true
    });

    ERRORS.set('NonActiveSimCardError', {
      prefix: 'switchSIMDataReceiveAlert',
      showDsdsStatus: true,
      executeHandler: true
    });

    ERRORS.set('NoSignalError', {
      prefix: 'sendNoSignalError'
    });

    ERRORS.set('NotFoundError', {
      prefix: 'sendNotFoundError'
    });

    ERRORS.set('InvalidAddressError', {
      prefix: 'sendInvalidAddressError'
    });

    ERRORS.set('SimNotMatchedError', {
      prefix: 'simNotMatchedError'
    });

    ERRORS.set('NonActiveSimCardToSendError', {
      prefix: 'switchSIMDataSendAlert',
      showDsdsStatus: true,
      executeHandler: true
    });

    ERRORS.set('RadioDisabledToDownloadError', {
      prefix: 'radioDisabledToDownload'
    });

    ERRORS.set('UnknownDownloadError', {
      prefix: 'downloadDefaultError'
    });

    ERRORS.set('UnknownError', {
      prefix: 'sendDefaultError'
    });

    ERRORS.set('NetworkProblemsError', {
      prefix: 'netWorkError'
    });

    ERRORS.set('NeedConnectWifiError', {
      prefix: 'needConnectWifi',
      selectWlanValue: true
    });

    ERRORS.set('MMSChanelUsedError', {
      prefix: 'mmsChanelUsed'
    });
  }

  exports.Errors = {
    get: function(errorCode, isRetrieve) {
      if (!ERRORS.size) {
        initErrorsMap();
      }

      return ERRORS.get(errorCode) ||
             (isRetrieve ? ERRORS.get('UnknownDownloadError') : ERRORS.get('UnknownError'));
    }
  };
})(window);
