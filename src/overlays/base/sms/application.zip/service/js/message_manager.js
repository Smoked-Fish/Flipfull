/* global Threads, Navigation, ThreadListUI, ActivityHandler, Settings, AML,
          Utils, SMIL, EventDispatcher, ValueDefault */

(function(exports) {
  'use strict';

  const MessageManager = {
    init: function() {
      this._mozMobileMessage = navigator.b2g.mobileMessageManager;

      this._mozMobileMessage.addEventListener(
        'received', this.onMessageReceived.bind(this)
      );
      this._mozMobileMessage.addEventListener(
        'sending', this.onMessageSending.bind(this)
      );
      this._mozMobileMessage.addEventListener(
        'sent', this.onMessageSent.bind(this)
      );
      this._mozMobileMessage.addEventListener(
        'failed', this.onMessageFailed.bind(this)
      );
      this._mozMobileMessage.addEventListener(
        'readsuccess', this.onReadSuccess.bind(this)
      );
      this._mozMobileMessage.addEventListener(
        'deliverysuccess', this.onDeliverySuccess.bind(this)
      );
      this._mozMobileMessage.addEventListener(
        'deleted', this.onDeleted.bind(this)
      );
    },

    onMessageSending: function(event) {
      Threads.registerMessage(event.message);
      this.emit('message-sending', { message: event.message });
    },

    onMessageFailed: function(event) {
      this.emit('message-failed-to-send', { message: event.message });
    },

    onDeliverySuccess: function(event) {
      this.emit('message-delivered', { message: event.message });
    },

    onReadSuccess: function(event) {
      this.emit('message-read', { message: event.message });
    },

    onMessageSent: function(event) {
      if (ValueDefault.isFromNotification) {
        this.emit('message-sent', { message: event.message });
      } else if (Navigation.isCurrentPanel('thread-list')) {
        if (ThreadListUI.messagesSent) {
          this.emit('message-list-sent');
        } else if (ActivityHandler._isCustomMessage) {
          this.emit('custom-message', { message: event.message });
        }
      } else {
        if (ActivityHandler._isCustomMessage) {
          this.emit('custom-message', { message: event.message });
        } else {
          this.emit('message-sent', { message: event.message });
        }
      }
    },

    onMessageReceived: function(event) {
      const message = event.message;

      if (message.messageClass && message.messageClass === 'class-0') {
        return;
      }

      // Not need update the UI if retrieve mode is auto mode.
      // DefectGCSMSG-5122-tingting.chao@tcl.com-begin
      if (message.deliveryInfo) {
        dump('onMessageReceived'+ ' ,message.delivery :: '+ message.deliveryInfo[0].deliveryStatus);
        if (message.delivery === 'not-downloaded' &&
            message.deliveryInfo[0].deliveryStatus === 'pending') {
          return;
        }
      }
      // DefectGCSMSG-5122-tingting.chao@tcl.com-end

      Threads.registerMessage(message);
      this.emit('message-received', { message: message });
    },

    onDeleted: function(event) {
      if (event.deletedThreadIds && event.deletedThreadIds.length) {
        this.emit('threads-deleted', {
          ids: event.deletedThreadIds
        });
      }
    },

    getThreads: function(options) {
      const each = options.each;
      const end = options.end;
      const done = options.done;
      const iterable = this._mozMobileMessage.getThreads().values();
      circleMap();

      function circleMap() {
        iterable.next().then((result) => {
          if (!result.done) {
            each && each(result.value);
            circleMap();
          } else {
            end && end();
            done && done();
          }
        });
      }
    },

    getMessage: function(id) {
      return this._mozMobileMessage.getMessage(id);
    },

    getMessages: function(options) {
      const each = options.each;
      const invert = options.invert;
      const end = options.end;
      const endArgs = options.endArgs;
      const done = options.done;
      const filter = options.filter;
      const chunkSize = options.chunkSize;
      let index = 0;
      let isContinue = true;

      const iterable = this._mozMobileMessage.getMessages(filter, !invert).values();

      const removeTextContent = () => {
        document.removeEventListener('stop-getMessages', removeTextContent);
        isContinue = false;
      };

      document.addEventListener('stop-getMessages', removeTextContent);
      circleMap();

      function circleMap() {
        index++;
        iterable.next().then((result) => {
          if (!result.done && isContinue) {
            let shouldContinue = true;
            if (each) {
              shouldContinue = each(result.value);
            }

            if (shouldContinue !== false) {
              if (!chunkSize || index <= chunkSize) {
                circleMap();
              } else {
                // set delay for performance
                setTimeout(() => {
                  circleMap();
                }, 300);
              }
            } else {
              done && done();
            }
          } else {
            end && end(endArgs);
            done && done();
          }
        });
      }
    },

    _sanitizeServiceId: function(serviceId) {
      if (serviceId === null || isNaN(+serviceId)) {
        serviceId = null;
      } else {
        serviceId = +serviceId;
      }

      return serviceId;
    },

    _getSendOptionsFromServiceId: function(serviceId) {
      let sendOpts;
      if (serviceId !== null && Settings.isDualSimDevice()) {
        sendOpts = { serviceId: serviceId };
      }

      return sendOpts;
    },

    // Message recipient special code only support '+', '*', '#', ',', ';', 
    // other special codes such as '()' should be removed.
    preprocessRecipients: function(recipients) {
      const preRecipients = recipients.map((recipient) => {
        return recipient.replace(/[()]/g, '');
      });
      return preRecipients;
    },

    sendSMS: function(opts) {
      let recipients = opts.recipients || [];
      const content = opts.content;
      const serviceId = this._sanitizeServiceId(opts.serviceId);
      const oncomplete = opts.oncomplete;

      if (!Array.isArray(recipients)) {
        recipients = [recipients];
      }

      let i = 0;
      const requestResult = { hasError: false, return: [] };
      const sendOpts = this._getSendOptionsFromServiceId(serviceId);
      const numberOfRequests = recipients.length;
      const amlNumber = '112';

      if (recipients.indexOf(amlNumber) !== -1) {
        AML && AML.triggerBySMS(serviceId);
      }

      recipients.forEach((recipient) => {
        this._mozMobileMessage.send(recipient, content, sendOpts).then(() => {
          requestResult.return.push({
            success: true,
            recipient: recipient
          });

          if (i === numberOfRequests - 1) {
            oncomplete && oncomplete(requestResult);
          }
          i++;
        }, (error) => {
          requestResult.hasError = true;
          requestResult.return.push({
            success: false,
            code: error,
            recipient: recipient
          });

          if (i === numberOfRequests - 1) {
            oncomplete && oncomplete(requestResult);
          }
          i++;
        });
      });

      // Need provide the send event data to event_log_data module.
      Utils.sendEventLogs(recipients, 'sms_send');
    },

    sendMMS: function(opts) {
      let recipients = opts.recipients;
      const serviceId = opts.serviceId = this._sanitizeServiceId(opts.serviceId);
      const subject = opts.subject;
      const content = opts.content;
      const onsuccess = opts.onsuccess;
      const onerror = opts.onerror;

      if (!Array.isArray(recipients)) {
        recipients = [recipients];
      }

      // Only MMS pdu encoder not recognize special code '()'.
      recipients = this.preprocessRecipients(recipients);

      const message = SMIL.generate(content);
      const sendOpts = this._getSendOptionsFromServiceId(serviceId);

      this._mozMobileMessage.sendMMS({
        receivers: recipients, 
        subject: subject,
        smil: message.smil,
        attachments: message.attachments,
        isGroup: Settings.isGroup
      }, sendOpts).then(() => {
        onsuccess && onsuccess();
      }, (error) => {
        onerror && onerror(error);
      });

      // Set isGroup flag after send MMS action.
      Settings.isGroup = false;

      // Need provide the no event data to event_log_data module.
      Utils.sendEventLogs(recipients);
    },

    retrieveMMS: function(id) {
      return this._mozMobileMessage.retrieveMMS(id);
    },

    resendMessage: function(opts) {
      const message = opts.message;

      if (!message) {
        throw new Error('Message to resend is not defined.');
      }

      const serviceId = Settings.getServiceIdByIccId(message.iccId);
      const sendOpts = this._getSendOptionsFromServiceId(serviceId);
      const onsuccess = opts.onsuccess;
      const onerror = opts.onerror;
      let request;

      if (message.type === 'sms') {
        request = this._mozMobileMessage.send(
          message.receiver, message.body, sendOpts);
        // Need provide the send event data to event_log_data module.
        Utils.sendEventLogs(message.receiver, 'sms_send');
      }
      if (message.type === 'mms') {
        request = this._mozMobileMessage.sendMMS({
          receivers: message.receivers,
          subject: message.subject,
          smil: message.smil,
          attachments: message.attachments,
          isGroup: message.isGroup
        }, sendOpts);
        // Need provide the no event data to event_log_data module.
        Utils.sendEventLogs(message.receivers);
      }

      request.onsuccess = (event) => {
        MessageManager.deleteMessages(message.id);
        onsuccess && onsuccess(event.target.result);
      };

      request.onerror = (event) => {
        MessageManager.deleteMessages(message.id);
        onerror && onerror(event.target.error);
      };
    },

    deleteMessages: function(id, callback) {
      this._mozMobileMessage.delete(id).then((result) => {
        callback && callback(result);
      }, (error) => {
        const msg = 'Deleting in the database. Error: ' + error.name;
        console.log(msg);
        callback && callback(null);
      });
    },

    markThreadRead: function(threadId) {
      const filter = {
        threadId: threadId,
        read: false
      };

      const messagesUnreadIDs = [];
      const changeStatusOptions = {
        each: function(message) {
          messagesUnreadIDs.push(message.id);
          return true;
        },
        filter: filter,
        invert: true,
        end: function() {
          MessageManager.markMessagesRead(messagesUnreadIDs);
        },
        done: function() {
          // TODO Related with IAC, delete first.
        }
      };
      MessageManager.getMessages(changeStatusOptions);
    },

    markMessagesRead: function(list) {
      if (!this._mozMobileMessage || !list.length) {
        return;
      }

      const id = list.pop();
      const request = this._mozMobileMessage.markMessageRead(id, true, true);

      request.onsuccess = () => {
        if (!list.length) {
          return;
        }

        this.markMessagesRead(list);
      };

      request.onerror = () => {
        console.error(
          'Error while marking message %d as read: %s', id, request.error.name
        );
      };
    },

    getSegmentInfo: function(text) {
      if (!(this._mozMobileMessage &&
            this._mozMobileMessage.getSegmentInfoForText)) {
        return Promise.reject(new Error('mozMobileMessage is unavailable.'));
      }

      const defer = Utils.Promise.defer();
      const request = this._mozMobileMessage.getSegmentInfoForText(text);
      request.onsuccess = (event) => {
        defer.resolve(event.target.result);
      };

      request.onerror = (event) => {
        defer.reject(event.target.error);
      };

      return defer.promise;
    },

    _isMessageBelongTo1to1Conversation: function(number, message) {
      const isIncoming = message.delivery === 'received' ||
                         message.delivery === 'not-downloaded';
      if (isIncoming) {
        return Utils.probablyMatches(message.sender, number);
      } else {
        switch (message.type) {
          case 'sms':
            return Utils.probablyMatches(message.receiver, number);
          case 'mms':
            return message.receivers.length === 1 &&
                   Utils.probablyMatches(message.receivers[0], number);
          default:
            console.error('Got an unknown message type: ' + message.type);
            return false;
        }
      }
    },

    findThreadFromNumber: function(number) {
      if (!Array.isArray(number)) {
        number = [number];
      }

      function checkCandidate(message) {
        let isMessageInThread = true;
        if (number.length > 1) {
          if (message.type === 'mms') {
            if (number.length === message.receivers.length) {
              isMessageInThread = !number.some((key) => {
                return message.receivers.indexOf(key) === -1;
              });
            } else {
              isMessageInThread = false;
            }
          } else {
            isMessageInThread = false;
          }
        } else {
          isMessageInThread = 
            MessageManager._isMessageBelongTo1to1Conversation(number[0], message);
        }
        if (isMessageInThread) {
          threadId = message.threadId;
          Threads.registerMessage(message);
          return false;
        }
      }

      let threadId = null;
      const deferred = Utils.Promise.defer();

      if (number.length === 0) {
        deferred.reject(new Error('The number is null'));
        return deferred.promise;
      }

      MessageManager.getMessages({
        filter: { numbers: number },
        each: checkCandidate,
        done: function() {
          if (threadId === null) {
            deferred.reject(new Error('No thread found for number: ' + number));
          } else {
            deferred.resolve(threadId);
          }
        }
      });

      return deferred.promise;
    }
  };

  Object.defineProperty(exports, 'MessageManager', {
    get: function () {
      delete exports.MessageManager;

      exports.MessageManager = EventDispatcher.mixin(MessageManager, [
        'message-sending', 'message-failed-to-send', 'message-delivered',
        'message-read', 'message-sent', 'message-received', 'threads-deleted',
        'threads-download', 'message-retrieving', 'message-list-sent',
        'custom-message'
      ]);

      return exports.MessageManager;
    },
    configurable: true,
    enumerable: true
  });
})(window);
