/* global Settings, Utils, StateManager, DialogManager, ThreadUI, 
          MessageManager, OptionManager, FocusStateManager */

'use strict';

// eslint-disable-next-line no-unused-vars
const RetrieveManager = {
  // Retrieve module.
  retrieveMMS: function(messageDOM) {
    if (!Settings.dataEnable && Settings.whiteListOff) {
      if (StateManager.isAirplaneState()) {
        DialogManager.showMessageError('RadioDisabledError');
      } else {
        DialogManager.alertDataOffStatus();
      }
      return;
    }

    if (Settings.hasGroup) {
      let serviceId = Settings.getServiceIdByIccId(messageDOM.dataset.iccId);
      serviceId = serviceId === null ? 0 : serviceId;
      Utils.judgeNumberSituation(serviceId, () => {
        this.realRetrieveMMS(messageDOM);
      }, () => {
        FocusStateManager.dynamicSK();
      });
    } else {
      this.realRetrieveMMS(messageDOM);
    }
  },

  realRetrieveMMS: function(messageDOM) {
    const id = +messageDOM.dataset.messageId;
    const iccId = messageDOM.dataset.iccId;
    const request = MessageManager.retrieveMMS(id);
    const button = messageDOM.querySelector('button');

    ThreadUI.setMessageStatus(id, 'pending');
    button.setAttribute('data-l10n-id', 'downloading-attachment');
    OptionManager.hideOptionMenu();
    FocusStateManager.dynamicSK();

    request.onsuccess = (() => {
      ThreadUI.removeMessageDOM(messageDOM);
      Utils.showToaster({
        messageL10nId: 'download-complete',
        latency: 3000
      });
    });

    request.onerror = (() => {
      ThreadUI.setMessageStatus(id, 'error');
      button.setAttribute('data-l10n-id', '');
      button.textContent = '';
      // Begin added by tingting.chao for DefectGF5GTMO-6832 on 2025/03/20
      /*let errorCode = (request.error && request.error.name) ?
                       request.error.name : null;*/
      let errorCode = (request.error && request.error.message) ?
                          request.error.message : null;
      // End added by tingting.chao for DefectGF5GTMO-6832 on 2025/03/20
      if (errorCode === 'RadioDisabledError') {
        errorCode = 'RadioDisabledToDownloadError';
      }

      const serviceId = Settings.getServiceIdByIccId(iccId);
      if (errorCode === 'NonActiveSimCardError') {
        DialogManager.showMessageError('NonActiveSimCardError');
        return;
      }
      if (errorCode === 'UnknownError') {
        errorCode = 'UnknownDownloadError';
      }
      if (errorCode) {
        DialogManager.showMessageError(errorCode, {
          confirmHandler: function stateResetAndRetry() {
            if (serviceId === null) {
              DialogManager.showMessageError('NoSimCardError');
            }
          }.bind(this)
        }, true);
      }
    });
  }
};
