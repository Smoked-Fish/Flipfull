/* global Settings, Compose, SubjectUtils, Utils, StateManager, DialogManager,
          MessageManager, RecipientManager, WaitingScreen, ValueDefault,
          SoftkeyManager, FocusManager, FocusStateManager */

'use strict';

// eslint-disable-next-line no-unused-vars
const SendManager = {
  sendMessage: function(opts) {
    const content = Compose.getContent(),
          subject = SubjectUtils.getSubject(),
          messageType = Compose.type,
          serviceId = opts.serviceId === undefined ? null : opts.serviceId;

    let recipients;

    if (content.length === 0 && !subject) {
      return;
    }

    recipients = RecipientManager.recipients.numbers;

    if (messageType === 'mms' && !StateManager.isMMSAbleToSend(serviceId)) {
      return;
    }

    Utils.canSendWhenParentControl(recipients).then((canSend) => {
      if (canSend) {
        if (Settings.hasGroup && Settings.groupSwitchEnabled && recipients.length > 1) {
          Utils.judgeNumberSituation(serviceId, () => {
            Settings.isGroup = true;
            this.realSendMessage(messageType, recipients, content,
                                 serviceId, subject);
          }, () => {
            // Confirm the cursor is at the end of string.
            if (document.activeElement.id === 'messages-input') {
              Compose.focus();
            }
            FocusStateManager.dynamicSK();
          });
        } else {
          this.realSendMessage(messageType, recipients, content,
                               serviceId, subject);
        }
      } else {
        DialogManager.confirmAlert('confirmation-title', 'parent-control-text',
                                   null, null, 'ok', null, null, null);
      }
    });
  },

  realSendMessage: function (messageType, recipients, content, 
                             serviceId, subject) {
    this.activityWaitShow();
    // Send the Message
    if (messageType === 'sms') {
      MessageManager.sendSMS({
        recipients: recipients,
        content: content[0],
        serviceId: serviceId
      });
    } else {
      const smilSlides = content.reduce(Utils.generateSmilSlides, []);
      const mmsOpts = {
        recipients: recipients,
        subject: subject,
        content: smilSlides,
        serviceId: serviceId
      };

      MessageManager.sendMMS(mmsOpts);
    }
  },

  activityWaitShow: function() {
    WaitingScreen.show();
    SoftkeyManager.show([SoftkeyManager.skNullSoft]);
    FocusManager.removeAllFocusable();
    FocusManager.removeAllFocus();
    ValueDefault.activitySending = true;
  }
};
