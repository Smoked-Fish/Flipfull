/* global Threads, Navigation, ThreadListUI, Settings, Compose, SubjectUtils,
          Utils, RecipientManager, StateManager, DialogManager, ThreadUI,
          DraftUtils, Drafts, MessageManager, InputUtils, FocusStateManager */

'use strict';

const SendManager = {
  showErrorInFailedEvent: '',

  // Send module.
  sendMessage: function(opts) {
    const content = Compose.getContent(),
          subject = SubjectUtils.getSubject(),
          messageType = Compose.type,
          serviceId = opts.serviceId === undefined ? null : opts.serviceId,
          inComposer = Navigation.isCurrentPanel('composer');

    let recipients;

    if (content.length === 0 && !subject) {
      return;
    }

    if (inComposer) {
      if (!RecipientManager.recipients.length) {
        return;
      }
      recipients = RecipientManager.recipients.numbers;
    } else {
      recipients = Threads.active.participants;
    }

    if (messageType === 'mms' && !StateManager.isMMSAbleToSend(serviceId)) {
      return;
    }

    Utils.canSendWhenParentControl(recipients).then((canSend) => {
      if (canSend) {
        if (Settings.hasGroup && Settings.groupSwitchEnabled && recipients.length > 1) {
          Utils.judgeNumberSituation(serviceId, () => {
            Settings.isGroup = true;
            this.realSendMessage(inComposer, messageType, recipients, content,
                                 serviceId, subject);
          }, () => {
            // Confirm the cursor is at the end of string.
            if (document.activeElement.id === 'messages-input') {
              Compose.focus();
            }
            FocusStateManager.dynamicSK();
          });
        } else {
          this.realSendMessage(inComposer, messageType, recipients, content,
                               serviceId, subject);
        }
      } else {
        DialogManager.confirmAlert('confirmation-title', 'parent-control-text',
                                   null, null, 'ok', null, null, null);
      }
    });
  },

  realSendMessage: function(inComposer, messageType, recipients,
                            content, serviceId, subject) {
    ThreadUI.disableConvertNoticeBanners();
    InputUtils.cleanFields();
    ThreadUI.enableConvertNoticeBanners();

    if (DraftUtils.draft) {
      ThreadListUI.removeThread(DraftUtils.draft.id);
      Drafts.delete(DraftUtils.draft).store();
      DraftUtils.draft = null;
    }

    ThreadUI.updateHeaderData();

    ThreadUI.shouldChangePanelNextEvent = inComposer;

    // TaskGF5GTMO-3489-[TMO:GID-MTRREQ-484020]-tingting.chao-on 2024/08/15 -begin
    if (OperatorUtils.isTMOFamily() && (recipients.length > 1) && (recipients.indexOf('911')!= -1)) {
      let index = recipients.indexOf('911');
      recipients.splice(index, 1);
      dump(" recipients = " + recipients);
      ThreadListUI.messagesSent = true;
      // Sent 911 as sms
      MessageManager.sendSMS({
            recipients: '911',
            content: content[0],
            serviceId: serviceId,
            oncomplete: (requestResult) => {
            if (!requestResult.hasError) {
              this.onMessageSendRequestCompleted();
              return;
            }
            const errors = {};
            requestResult.return.forEach((result) => {
              if (result.success) {
                return;
              }

            if (errors[result.code.name] === undefined) {
              errors[result.code.name] = [result.recipient];
            } else {
              errors[result.code.name].push(result.recipient);
            }
            });

            for (const key in errors) {
              this.showMessageSendingError(key, { recipients: errors[key] });
            }
          }
      });

      //sent other recipients as mms
      const mmsSmilSlides = content.reduce(Utils.generateSmilSlides, []);
      const mmsParameters = {
        recipients: recipients,
        subject: subject,
        content: mmsSmilSlides,
        serviceId: serviceId,
        onsuccess: function() {
          this.onMessageSendRequestCompleted();
        }.bind(this),
        onerror: function onError(error) {
          const errorName = error.name;
          this.showMessageSendingError(errorName);
        }.bind(this)
      };

      MessageManager.sendMMS(mmsParameters);
      return;
    }
    // TaskGF5GTMO-3489-[TMO:GID-MTRREQ-484020]-tingting.chao-on 2024/08/15 -end

    // Send the Message
    if (messageType === 'sms') {
      ThreadListUI.messagesSent = true;
      MessageManager.sendSMS({
        recipients: recipients,
        content: content[0],
        serviceId: serviceId,
        oncomplete: (requestResult) => {
          if (!requestResult.hasError) {
            this.onMessageSendRequestCompleted();
            return;
          }

          const errors = {};
          requestResult.return.forEach((result) => {
            if (result.success) {
              return;
            }

            if (errors[result.code.message] === undefined) {
              errors[result.code.message] = [result.recipient];
            } else {
              errors[result.code.message].push(result.recipient);
            }
          });

          for (const key in errors) {
            this.showMessageSendingError(key, { recipients: errors[key] });
          }
        }
      });

      if (recipients.length > 1) {
        ThreadUI.shouldChangePanelNextEvent = false;
        Navigation.toPanel('thread-list');
        ThreadListUI.updateThread(Threads.active);
      }
    } else {
      if (Settings.dataServiceId === -1) {
        this.showMessageSendingError('NoSignalError');
        return;
      }

      //Porting from TASK10115722-[GID-MTRREQ-484018]-tingting.chao on 2024/08/17- begin
      //Porting from PRGF7TF-5033 [TMO:TC-15051]- tingtning.chao on 24/09/09-add test 922
      let textContent;
      if(OperatorUtils.isTMOFamily() && recipients.length == 1 && (recipients[0] == '911' || recipients[0] == '922')
          && typeof content[0] === 'string'){
        textContent = content.shift();
        dump("separate textContent from MMS, contentLength: " + content.length);
      }
      //Porting from TASK10115722-[GID-MTRREQ-484018]-tingting.chao on 2024/08/17-end
      const smilSlides = content.reduce(Utils.generateSmilSlides, []);
      const mmsOpts = {
        recipients: recipients,
        subject: subject,
        content: smilSlides,
        serviceId: serviceId,
        onsuccess: function() {
          this.onMessageSendRequestCompleted();
        }.bind(this),
        onerror: function onError(error) {
          const errorName = error.message;
          this.showMessageSendingError(errorName);
        }.bind(this)
      };

      MessageManager.sendMMS(mmsOpts);
      //Porting from TASK10115722-[GID-MTRREQ-484018]-tingting.chao on 2024/08/17- begin
      if(textContent){
        MessageManager.sendSMS({
            recipients: recipients,
            content: textContent,
            serviceId: serviceId,
            oncomplete: (requestResult) => {
              if (!requestResult.hasError) {
                this.onMessageSendRequestCompleted();
                return;
              }

              const errors = {};
              requestResult.return.forEach((result) => {
                if (result.success) {
                  return;
                }

                if (errors[result.code.name] === undefined) {
                  errors[result.code.name] = [result.recipient];
                } else {
                  errors[result.code.name].push(result.recipient);
                }
              });

              for (const key in errors) {
                this.showMessageSendingError(key, { recipients: errors[key] });
              }
            }
          });
      }
      //Porting from TASK10115722-[GID-MTRREQ-484018]-tingting.chao on 2024/08/17- end
    }
  },

  resendMessage: function(id) {
    id = +id;
    const request = MessageManager.getMessage(id);
    request.onsuccess = () => {
      const message = request.result;
      let serviceId = Settings.getServiceIdByIccId(message.iccId);
      serviceId = serviceId === null ? 0 : serviceId;

      // According to the discussion, the alert order should be
      // storage full > airplane mode > no SIM > no data.
      if (Compose.type === 'mms' && StateManager.isDiskFull) {
        DialogManager.alertFreeSpace('send');
        return;
      }
      // VoWifi use data SIM card default.
      if (message.type === 'sms' && StateManager.isAirplaneState() &&
          !StateManager.isVoWifiStatus(Settings.dataServiceId)) {
        DialogManager.showMessageError('RadioDisabledError');
        return;
      }

      if (StateManager.isNoSIMStatus()) {
        DialogManager.showMessageError('NoSimCardError');
        return;
      }
      //Porting from PR 11652482-renlongou on 2024/09/07-begin
      // VoWifi use data SIM card default.
      /*if (message.type === 'mms' && !Settings.dataEnable &&
          Settings.whiteListOff) {
        // we need reject send/download MMS if data is OFF,
        // please check bug 56531 for detail.
        if (StateManager.isAirplaneState()) {
          DialogManager.showMessageError('RadioDisabledError');
        } else {
          DialogManager.alertDataOffStatus();
        }
        return;
      }*/

      if (Compose.type === 'mms'){
        if (OperatorUtils.isATTFamily()) {
          if (StateManager.isAirplaneState()) {
            DialogManager.showMessageError('RadioDisabledError');
            return;
          }
        } else if (!Settings.dataEnable &&
          Settings.whiteListOff && !StateManager.isVoWifiStatus(Settings.dataServiceId)){
          if (StateManager.isAirplaneState()) {
            DialogManager.showMessageError('RadioDisabledError');
          } else {
            DialogManager.alertDataOffStatus();
          }
          return;
        }
      }
      //Porting from PR 11652482-renlongou on 2024/09/07-end

      if (message.type === 'mms' && !StateManager.isMMSAbleToSend(serviceId)) {
        return;
      }

      const messageDOM = document.getElementById('message-' + id);
      if (message.type === 'mms' && Settings.hasGroup &&
          message.isGroup) {
        Utils.judgeNumberSituation(serviceId, () => {
          this.realResendMessage(message, messageDOM);
        }, () => {
          FocusStateManager.dynamicSK();
        });
      } else {
        this.realResendMessage(message, messageDOM);
      }
    };
  },

  realResendMessage: function(message, messageDOM) {
    const resendOpts = {
      message: message,
      onerror: function onError(error) {
        const errorName = error.message;
        SendManager.showMessageSendingError(errorName, { recipients: [message.receiver] });
      }.bind(this),
      onsuccess: function() {
        SendManager.onMessageSendRequestCompleted();
      }.bind(this)
    };
    ThreadUI.removeMessageDOM(messageDOM);
    MessageManager.resendMessage(resendOpts);
  },

  // Send handler module.
  initSentAudio: function() {
    if (this.sentAudio) {
      return;
    }

    this.sentAudio = new Audio();
    this.sentAudio.preload = 'none';
    this.sentAudio.src = '/sounds/SMS Message sent_MA.ogg';
    this.sentAudio.mozAudioChannelType = 'notification';
    this.sentAudioKey = 'message.sent-sound.enabled';
    this.sentAudioEnabled = false;

    try {
      Utils.getSettingsValue(this.sentAudioKey).then((value) => {
        this.sentAudioEnabled = value;
      });

      Utils.observerSettingsValue(this.sentAudioKey, (value) => {
        this.sentAudioEnabled = value;
      });
    } catch (e) {
      this.sentAudioEnabled = false;
    }
  },

  onMessageSendRequestCompleted: function() {
    // Play the audio notification
    if (this.sentAudioEnabled) {
      this.sentAudio.play();
    }
  },

  showMessageSendingError: function(errorName, opts) {
    if (errorName === 'NonActiveSimCardError') {
      this.showErrorInFailedEvent = errorName;
      return;
    }
    if (errorName === 'NotFoundError') {
      return;
    }
    DialogManager.showMessageError(errorName, opts);
  }
};
