/* global Settings, Compose, StateManager, OptionManager,
          SendManager, SoftkeyManager */

'use strict';

// eslint-disable-next-line no-unused-vars
const SendService = {
  startSendMessage: function () {
    let serviceId = Settings.smsServiceId;
    if (serviceId === null) {
      serviceId = 0;
    }

    if (serviceId !== -1 && !StateManager.preSendCondition(serviceId)) {
      return;
    }

    if (serviceId === -1) {
      if (Settings.hasSeveralSim()) {
        OptionManager.simSelectOptions();
      } else {
        const simServiceId = this.selectSIMCard();
        if (!StateManager.preSendCondition(simServiceId)) {
          return;
        }
        SendManager.sendMessage({serviceId: simServiceId});
      }
    } else if (serviceId === 0 || serviceId === 1) {
      SendManager.sendMessage({serviceId: serviceId});
    } else {
      console.log('Not handle serviceId = ' + serviceId);
    }
  },

  // DSDS case.
  selectSIMCard: function () {
    for (let i = 0; i < Settings._serviceIds.length; i++) {
      if (Settings._serviceIds[i] !== null &&
          Settings._serviceIds[i].iccId !== null) {
        return i;
      }
    }
  },

  selectSIMSend: function () {
    if (Compose.isEmpty() || (Settings.mmsEnable &&
        (Compose.size > Settings.mmsSizeLimitation)) ||
        (!Settings.mmsEnable &&
         (Compose.segmentInfo.segments > Settings.maxConcatenatedMessages))) {
      return null;
    }

    if (Settings.isDualSimDevice() && Settings.hasSeveralSim()) {
      switch (Settings.smsServiceId) {
        case 0:
          return SoftkeyManager.skSendSIM1;
        case 1:
          return SoftkeyManager.skSendSIM2;
        case -1:
          return SoftkeyManager.skSend;
        default:
          return null;
      }
    } else {
      return SoftkeyManager.skSend;
    }
  },

  simSelectedCallback: function(cardIndex) {
    if (!StateManager.preSendCondition(cardIndex)) {
      return;
    }

    if (Compose.isEmpty()) {
      return;
    }

    cardIndex = +cardIndex;
    if (isNaN(cardIndex)) {
      cardIndex = 0;
    }

    // Beign by tingting.chao for GCSDIAL-4844 on 2025/05/19
    //SendManager.sendMessage({ serviceId: cardIndex });
    document.addEventListener('transitionend', function optionMenu() {
      document.removeEventListener('transitionend', optionMenu);
      SendManager.sendMessage({ serviceId: cardIndex });
    });
    // End by tingting.chao for GCSDIAL-4844 on 2025/05/19
  }
};
