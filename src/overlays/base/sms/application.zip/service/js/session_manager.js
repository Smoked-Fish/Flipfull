/* global AppsManager, SettingsObserver */
'use strict';

// eslint-disable-next-line no-unused-vars
const SessionManager = {
  servicesArray: [
    'settingsService',
    'appsService',
    'devicecapabilityService',
    'contactsService'
  ],
  
  initSession: function() {
    return new Promise((resolver) => {
      window.libSession.initService(this.servicesArray).then(()=>{
        SettingsObserver.init();
        AppsManager.init();
        resolver();
      });
    });
  }
};
