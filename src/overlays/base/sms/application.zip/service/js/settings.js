/* global AppsManager, StateManager, Utils, DeviceCapabilityManager, ICCUtils,
          SettingsUI, MobileOperator, ValueDefault */

'use strict';

const Settings = {
  // Settings value needed.
  SERVICE_ID_KEYS: {
    smsServiceId: 'ril.sms.defaultServiceId',
    telephonyServiceId: 'ril.telephony.defaultServiceId',
    dataServiceId: 'ril.data.defaultServiceId'
  },
  READ_AHEAD_THREADS_KEY: 'ril.sms.maxReadAheadEntries',
  // We evaluate to 5KB the size overhead of wrapping a payload in a MMS.
  MMS_SIZE_OVERHEAD: 5 * 1024,
  // Default service id for DSDS.
  _serviceIds: null,
  // We need to remove this when email functionality is ready.
  supportEmailRecipient: true,
  // We set the default maximum concatenated number of our SMS app to 10.
  maxConcatenatedMessages: 10,
  //TaskGF5GDISH-2156-tingting.chao-begin
  vzwMaxConcatenatedMessages: 7,
  usccMaxConcatenatedMessages: 1,
  attMaxConcatenatedMessages: 5,
  //TaskGF5GDISH-2156-tingting.chao-end
  // Default mms message size limitation is 295K.
  //TaskGF5GTMO-3463-[GID-MTRREQ-5218]-tingting.chao on 2024/08/15-begin
  //mmsSizeLimitation: 295 * 1024,
  mmsSizeLimitation: 1019 * 1024,
  //TaskGF5GTMO-3463-[GID-MTRREQ-5218]-tingting.chao on 2024/08/15-end
  sprintMmsSizeLimitation : 2048 * 1024,//TaskGF5GTMO-3529-porting from Task10624992-[TMO:TXT-00090]-tingting.chao on 2024/08/19-add
  // Default sms service SIM ID.
  smsServiceId: null,
  // Default telephone service SIM ID.
  telephonyServiceId: null,
  // Default data service SIM ID.
  dataServiceId: null,
  // TODO default set email installed for notification page quick launch.
  // Email app installed situation.
  emailAppInstalled: true,
  // Default the data switch is on.
  dataEnable: true,
  // Default the MMS is enable.
  mmsEnable: true,
  // Default Retrieve mode is auto.
  retrieveAutoMode: true,
  // Default RTT is disable.
  RTTEnable: false,
  // RTT default config value.
  RTTPreferred: 'visible-during-calls',
  // Default group is disable.
  isGroup: false,
  // Group device support.
  hasGroup: false,
  // If has group, default the feature is enable.
  groupSwitchEnabled: true,
  // Group alert default always shown.
  notShownGroup: false,
  // White list enable.
  whiteListOff: false,
  // Wifi string change.
  useWifi: false,
  // Fake sim number or ICC ID record.
  fakeSIMNumberArray: [null, null],
  originalSIMNumberArray: [],
  originalSIMInfoArray: [],
  // Default creation mode is free.
  creationMode: 'free',
  eeMmsSizeLimitation :300 * 1024,//Porting from PR GF7EE-1344-renlongou on 2024/09/09-add

  init: function() {
    // Init the settings value, include mms limit, sms max length,
    // group enbable, group alert shown.
    let keyHandlerSet = {
      'dom.mms.operatorSizeLimitation': this.initMmsSizeLimitation.bind(this),
      'operatorResource.sms.maxConcat': this.initSmsMaxConcatenatedMsg.bind(this),
      'ril.mms.groupSwitch.enabled': this.initGroupEnableValue.bind(this),
      'ril.data.mobileWhiteList': this.initWhiteList.bind(this),
      'ril.mms.retrieval_mode': this.initRetrieveMode.bind(this)
    };
    const conns = StateManager.getConnectionInterface();

    //Porting from PR GF7EE-1344-renlongou on 2024/09/09-begin
    let isEEOperator = OperatorUtils.isEE();
    if(isEEOperator){
      this.mmsSizeLimitation = this.eeMmsSizeLimitation - this.MMS_SIZE_OVERHEAD;
    }
    //Porting from PR GF7EE-1344-renlongou on 2024/09/09-end

    function setHandlerMap(key) {
      Utils.getSettingsValue(key).then((value) => {
        const handler = keyHandlerSet[key];
        handler(value);

        // Some value in these can be controlled by the operator.
        Utils.observerSettingsValue(key, (value) => {
          handler(value);
        });
      });
    }

    this._serviceIds = [];

    // For 256mb device, default use the manual retrieve.
    DeviceCapabilityManager.get('hardware.memory').then((value) => {
      // Only set the value when first launch message.
      Utils.getSettingsValue('message.not.first.launch').then((notFirst) => {
        if (!notFirst && value <= 256) {
          Utils.setSettingsValue([{
            name: 'ril.mms.retrieval_mode',
            value: 'manual'
          }, {
            name: 'message.not.first.launch',
            value: true
          }]);
        }
        // [TMO:GID-MTRREQ-5193]Task11729995 -tingting.chao@tcl.com-default MMS retrieve mode for TMO
        //Porting from Task-11729995-renlongou on 2024/09/07-begin
        if (!notFirst && OperatorUtils.isBOOSTFamily()) {
          Utils.setSettingsValue([{
            name: 'ril.mms.retrieval_mode',
            value: 'automatic'
          }, {
            name: 'message.not.first.launch',
            value: true
          }]);
        }
        //Porting from Task-11729995-renlongou on 2024/09/07-end
      });
    });
    //Porting from Task-11444817,11459086.11494986-renlongou on 2024/09/07-begin
    Utils.getSettingsValue('message.not.my.first.launch').then((notFirstLaunch) => {
      if (OperatorUtils.isATTFamily() && notFirstLaunch == null) {
        Utils.setSettingsValue([{
          name: 'ril.sms.strict7BitEncoding.enabled',
          value: true
        }, {
          name: 'ril.mms.retrieval_mode',
          value: 'automatic'

        },{
          name:'ril.sms.requestStatusReport.enabled',
          value:false
        },{
          name: 'message.not.my.first.launch',
          value: true
        }]);
      }
    });
    //Porting from Task-11444817,11459086.11494986-renlongou on 2024/09/07-end

    // For group support device, enable the group feature.
    DeviceCapabilityManager.get('device.group-message').then((hasGroup) => {
      this.hasGroup = hasGroup;

      if (this.hasGroup) {
        // Set the default value and judge the SIM switch situation.
        ICCUtils.judgeSwitchSIMSituation();
      }
    });

    DeviceCapabilityManager.get('device.wifi.certified').then((useWifi) => {
      this.useWifi = useWifi;
    });

    // Need record the settings value, we reject send/download MMS if data is OFF.
    Utils.getSettingsValue('ril.data.enabled').then((value) => {
      if (value !== null) {
        Settings.dataEnable = value;
      }

      Utils.observerSettingsValue('ril.data.enabled', (value) => {
        Settings.dataEnable = value;
      });
    });

    // If MMS is not supported, switch to no MMS mode.
    Utils.getSettingsValue('mms.enable').then((value) => {
      if (value !== null) {
        Settings.mmsEnable = value;
      }

      if (!Settings.mmsEnable) {
        Settings.supportEmailRecipient = false;
      }

      // Only normal enter need init settings UI.
      if (!ValueDefault.activitymode && !ValueDefault.isFromNotification) {
        SettingsUI.init();
      }
    });

    // RTT settings, there are two value to decide the RTT feature.
    Utils.getSettingsValue('ril.rtt.enabled').then((value) => {
      if (value !== null) {
        Settings.RTTEnable = value;
      }

      Utils.observerSettingsValue('ril.rtt.enabled', (value) => {
        Settings.RTTEnable = value;
      });
    });

    Utils.getSettingsValue('ril.rtt.preferredSettings').then((value) => {
      if (value !== null) {
        Settings.RTTPreferred = value;
      }

      Utils.observerSettingsValue('ril.rtt.preferredSettings', (value) => {
        Settings.RTTPreferred = value;
      });
    });

    // Greation mode feature, it should be supported by MMS 1.2.
    Utils.getSettingsValue('ril.mms.creation_mode').then((value) => {
      if (value !== null) {
        Settings.creationMode = value;
      }

      Utils.observerSettingsValue('ril.mms.creation_mode', (value) => {
        Settings.creationMode = value;
      });
    });

    // Only DSDS will need to handle mmsServiceId
    if (conns && conns.length > 1) {
      for (const prop in this.SERVICE_ID_KEYS) {
        const setting = this.SERVICE_ID_KEYS[prop];
        keyHandlerSet[setting] =
          this.initServiceId.bind(this, setting, prop);
      }

      // Cache all existing serviceIds
      for (let i = 0, l = conns.length; i < l; i++) {
        this._serviceIds.push(conns[i].iccId);
      }
    }

    for (const key in keyHandlerSet) {
      setHandlerMap(key);
    }

    this.checkEmailInstalled();
  },

  // Update DSDS service Id value.
  updateServiceIds: function() {
    const conns = StateManager.getConnectionInterface();
    if (conns && conns.length > 1) {
      this._serviceIds = [];
      for (let i = 0, l = conns.length; i < l; i++) {
        this._serviceIds.push(conns[i].iccId);
      }
    }
  },

  // Set Maximum concatenated number of our SMS.
  initSmsMaxConcatenatedMsg: function(num) {
    //GF5GTMO-3578-porting from 10731053&11391369-tingting.chao on 24/08/22-begin
    if(OperatorUtils.isVZWFamily()){
      this.maxConcatenatedMessages = vzwMaxConcatenatedMessages;
    //Porting from Task11008108-[USCC:NW 4.2.12]-tingting.chao on 24/08/23-begin
    } else if(OperatorUtils.isUSCCFamily()){
      this.maxConcatenatedMessages = usccMaxConcatenatedMessages;
    //Porting from Task11008108-[USCC:NW 4.2.12]-tingting.chao on 24/08/23-end
    // TaskGF5GDISH-2156-tingting.chao-begin
    } else if(OperatorUtils.isATTFamily()){
      this.maxConcatenatedMessages = attMaxConcatenatedMessages;
    // TaskGF5GDISH-2156-tingting.chao-end
    } else if (num && !isNaN(num)) {
      this.maxConcatenatedMessages = num;
    }
    //GF5GTMO-3578-porting from 10731053&11391369-tingting.chao on 24/08/22-end
  },

  // Set MMS size limitation:
  // If operator does not specify MMS message size, we leave the decision to
  // MessageManager and return nothing if we can't get size limitation from db.
  initMmsSizeLimitation: function(size) {
    //TaskGF5GTMO-3463-[GID-MTRREQ-5218]-tingting.chao on 2024/08/15-begin
    /*if (size && !isNaN(size)) {
      this.mmsSizeLimitation = size - this.MMS_SIZE_OVERHEAD;
    }*/
    //TaskGF5GTMO-3463-[GID-MTRREQ-5218]-tingting.chao on 2024/08/15-end
    //TaskGF5GTMO-3529-porting from Task10624992-[TMO:TXT-00090]-tingting.chao on 2024/08/19-begin
    let isSprintOperator = OperatorUtils.isSPRINTFamily();
    if(isSprintOperator){
      this.mmsSizeLimitation = this.sprintMmsSizeLimitation - this.MMS_SIZE_OVERHEAD;
    }
    //TaskGF5GTMO-3529-porting from Task10624992-[TMO:TXT-00090]-tingting.chao on 2024/08/19-end
    //Porting from PR GF7EE-1344-renlongou on 2024/09/09-begin
    let isEEOperator = OperatorUtils.isEE();
    if(isEEOperator){
      this.mmsSizeLimitation = this.eeMmsSizeLimitation - this.MMS_SIZE_OVERHEAD;
    }
    //Porting from PR GF7EE-1344-renlongou on 2024/09/09-end

    if (ValueDefault.activitymode && !ValueDefault.isSizeRead) {
      ValueDefault.isSizeRead = true;
      window.dispatchEvent(new CustomEvent('mms-size-read'));
    }
  },

  // Set the group suppor value.
  initGroupEnableValue: function(enabled) {
    this.groupSwitchEnabled = enabled;
  },

  // Set white list value.
  initWhiteList: function(list) {
    this.whiteListOff = true;
    if (list && list.length) {
      this.whiteListOff = list.indexOf('mms') === -1;
    }
  },

  // Set retrieve mode value.
  initRetrieveMode: function(mode) {
    this.retrieveAutoMode = mode !== 'manual';
  },

  // Set default mms service SIM ID and add observer:
  // In DSDS scenario, if we notify user to switch to subscription to retrieve
  // the MMS from non-active subscription, we'll need current mmsServiceId
  // information to tell user the active/non-active subscription.
  initServiceId: function(settingName, propName, id) {
    if (id !== undefined) {
      Settings[propName] = id;
    }
  },

  // Judge whether the device support DSDS.
  isDualSimDevice: function() {
    return this._serviceIds && this._serviceIds.length > 1;
  },

  // Judge whether the device insert two SIM card.
  hasSeveralSim: function() {
    if (!this.isDualSimDevice()) {
      return false;
    }

    const simCount = this._serviceIds.reduce((simCount, iccId) => {
      return iccId === null ? simCount : simCount + 1;
    }, 0);

    return simCount > 1;
  },

  // Get the service ID by ICC ID.
  getServiceIdByIccId: function(iccId) {
    if (!this._serviceIds) {
      return null;
    }

    const index = this._serviceIds.indexOf(iccId);
    return index > -1 ? index : null;
  },

  // Begin added by tingting.chao for GF5GTMO-7103 on 2025/04/15
  getTmoSimName(iccId) {
    const iccManager = navigator.b2g.iccManager;
    const iccObject = iccManager ? iccManager.getIccById(iccId): null;
    if (iccObject == null) {
      return '';
    } else {
      const iccInfo = iccObject.iccInfo;
      const mccMnc = iccInfo.mcc + iccInfo.mnc;
      const gid1 = iccInfo.gid1;
      if (OperatorUtils.TMO_MCC_MNC.indexOf(mccMnc) > -1) {
        if (gid1 === '6d38') {
          return 'Metro by T-Mobile';
        } else if (gid1 === '1a53') {
          return 'Assurance Wireless';
        } else {
          return 'T-Mobile';
        }
      } else {
        return '';
      }
    }
  },
  // End added by tingting.chao for GF5GTMO-7103 on 2025/04/15

  // Get the operator name by ICC ID.
  getOperatorByIccId: function(iccId) {
    const index = this.getServiceIdByIccId(iccId);
    if (index === null) {
      return '';
    }

    const conns = StateManager.getConnectionInterface();
    const conn = conns[index];
    return MobileOperator.userFacingInfo(conn).operator;
  },

  // Begin by tingting.chao for GF5GTMO-7172 on 2025/04/24
  getPhoneNumber(iccId){
    let simNumber = '';
    const iccManager = navigator.b2g.iccManager;
    const iccObject = iccManager ? iccManager.getIccById(iccId): null;
    if(iccObject === null){
      return simNumber;
    }
    let iccInfoDetail = iccObject.iccInfo;
    if (iccInfoDetail.msisdn || iccInfoDetail.mdn) {
      simNumber = iccInfoDetail.msisdn || iccInfoDetail.mdn;
    }
    dump("The simNumber = " + simNumber);
    return simNumber;
  },
  // End by tingting.chao for GF5GTMO-7172 on 2025/04/24

  // Begin by tingting.chao for GF5GTMO-7172 on 2025/04/24
  getMcc(iccId) {
    let mcc = "";
    const iccManager = navigator.b2g.iccManager;
    const iccObject = iccManager ? iccManager.getIccById(iccId): null;
    if (iccObject !== null) {
      const iccInfo = iccObject.iccInfo;
      mcc = iccInfo.mcc;
    }
     return mcc;
  },

  removeCountryCode(phoneNumber, countryCode) {
    if (countryCode === '1') {
      return phoneNumber.replace(/^\+/, '');
    } else {
      const regex = new RegExp(`^\\+${countryCode}(\\s?)`);
      return phoneNumber.replace(regex, '');
    }
  },
  // End by tingting.chao for GF5GTMO-7172 on 2025/04/24

  // Set maxReadAheadEntries value.
  setReadAheadThreadRetrieval: function(value) {
    Utils.setSettingsValue([{
      name: this.READ_AHEAD_THREADS_KEY,
      value: value
    }]);
  },

  // Check whether the email app is installed.
  checkEmailInstalled: function() {
    AppsManager.getAll().then((installedApps) => {
      Settings.emailAppInstalled = installedApps.some((app) => {
        // TODO Can not use window.AppOrigin at inline activity.
        return (app.manifestUrl === 'http://email.localhost/manifest.webmanifest');
      });
    }, (error) => {
      console.log('get all installed apps error: ' + error.name);
    });
  }
};
