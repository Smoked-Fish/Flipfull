/* global TaskRunner, asyncStorage */

'use strict';

const SilentSms = (function() {
  const NO_ALARM_ID = -1;
  const SERVICE_TIMEOUT = 5 * 60 * 1000;
  const alarmInterface = navigator.mozAlarms;
  let taskQueue;

  function init() {
    taskQueue = new TaskRunner();
    if (!window.navigator.mozSetMessageHandler) {
      return;
    }

    window.navigator.mozSetMessageHandler('connection', (request) => {
      if (request.keyword === 'costcontrolSmsQuery') {
        const port = request.port;
        port.onmessage = (evt) => {
          const data = evt.data;
          switch (data.action) {
            case 'enable':
              taskQueue.push(function() {
                return SilentSms.enableSilentModeFor(data.smsNumbers, data.type)
                      .then(updateUsageSilentSms)
                      .then(port.postMessage.bind(port, 'silentSMSEnabled'));
              });
              break;
            case 'disable':
              taskQueue.push(function() {
                return SilentSms.disableSilentModeFor(data.type)
                      .then(updateUsageSilentSms)
                      .then(port.postMessage.bind(port, 'silentSMSDisabled'));
              });
              break;
          }
        };
      }
    });

    window.navigator.mozSetMessageHandler('alarm', (alarm) => {
      if (alarm.data.alarmType === 'silentSmsTimeout') {
        SilentSms.disableSilentModeFor(alarm.data.type).then(updateUsageSilentSms);
      }
    });
  }

  function getUsageSilentSms() {
    return new Promise(function(resolve) {
      asyncStorage.getItem('usageSilentSms', (usageSilentSms) => {
        resolve(usageSilentSms || {});
      });
    });
  }

  function removeAlarmTimeout(alarmId) {
    if (alarmId && alarmId !== NO_ALARM_ID) {
      alarmInterface.remove(alarmId);
    }
  }

  function addAlarmTimeout(type, delay) {
    return new Promise((resolve, reject) => {
      const date = new Date();
      date.setTime(date.getTime() + delay);
      const request = alarmInterface.add(date, 'ignoreTimezone',
                                         { alarmType: 'silentSmsTimeout',
                                           type: type });
      request.onsuccess = (event) => {
        const alarmId = event.target.result;
        resolve(alarmId);
      };
      request.onerror = () => {
        const errorMsg = 'Failed to set timeout for ' + type + 'request';
        reject(new Error(errorMsg));
      };
    });
  }

  function enableSilentModeFor(smsNumbers, type) {
    function _removeAlarmTimeout(usageSilentSms) {
      if (usageSilentSms && usageSilentSms[type] &&
          usageSilentSms[type].alarmId !== NO_ALARM_ID) {
        removeAlarmTimeout(usageSilentSms[type].alarmId);
      }
    }

    function handleErrorAddingAlarm(error) {
      console.error(error.toString());
      return NO_ALARM_ID;
    }

    return getUsageSilentSms().then(function(usageSilentSms) {
      function refreshUsageSilentSms(alarmId) {
        usageSilentSms[type] = {
          smsNumbers: smsNumbers,
          alarmId: alarmId
        };
        return usageSilentSms;
      }
      _removeAlarmTimeout(usageSilentSms);
      return addAlarmTimeout(type, SERVICE_TIMEOUT)
        .catch(handleErrorAddingAlarm)
        .then(refreshUsageSilentSms);
    });
  }

  function disableSilentModeFor(type) {
    return getUsageSilentSms().then((usageSilentSms) => {
      if (usageSilentSms && usageSilentSms[type] &&
          usageSilentSms[type].alarmId !== NO_ALARM_ID) {
        removeAlarmTimeout(usageSilentSms[type].alarmId);
      }
      usageSilentSms[type] = null;
      return usageSilentSms;
    });
  }

  function updateUsageSilentSms(usageSilentSms) {
    usageSilentSms.smsIndex = getIndex(usageSilentSms);
    asyncStorage.setItem('usageSilentSms', usageSilentSms);
  }

  function getIndex(usageSilentSms) {
    let newIndex = [];
    Object.keys(usageSilentSms).forEach((silentRequest) => {
      const silentSmsRequest = usageSilentSms[silentRequest];
      if (silentSmsRequest && silentSmsRequest.hasOwnProperty('smsNumbers')) {
        newIndex = newIndex.concat(silentSmsRequest.smsNumbers);
      }
    });
    return newIndex;
  }

  function checkSilentModeFor(smsNumber) {
    return taskQueue.push(function() {
      function checkSilentMode(usageSilentSms) {
        return usageSilentSms && usageSilentSms.smsIndex &&
               usageSilentSms.smsIndex.indexOf(smsNumber) !== -1;
      }
      return getUsageSilentSms().then(checkSilentMode);
    });
  }

  return {
    init: init,
    enableSilentModeFor: enableSilentModeFor,
    disableSilentModeFor: disableSilentModeFor,
    checkSilentModeFor: checkSilentModeFor
  };
}());
