/* global DialogManager, Settings, SendService, Compose */
'use strict';

const appStorage = navigator.b2g.getDeviceStorage('apps');
const connections = navigator.b2g.mobileConnections;

// eslint-disable-next-line no-unused-vars
const StateManager = {
  isDiskFull: false,

  getConnectionInterface: function() {
    return connections;
  },

  // Disk state listener.
  exceedLimitSpace: function() {
    return new Promise((resolve) => {
      appStorage.isDiskFull().then((result) => {
        resolve(result);
      });
    });
  },

  addDiskListener: function() {
    // Add disk full listener.
    this.exceedLimitSpace().then((isFull) => {
      this.isDiskFull = isFull;

      navigator.b2g.onstoragefree = () => {
        this.isDiskFull = false;
      };
      navigator.b2g.onstoragefull = () => {
        this.isDiskFull = true;
      };
    });
  },

  // Get emergency callback mode.
  isEmergencyCbMode: function(serviceId) {
    if (!serviceId) {
      serviceId = 0;
    }

    const conns = this.getConnectionInterface();
    const conn = conns[serviceId];
    return conn.isInEmergencyCbMode;
  },

  // Exit emergency callback mode.
  exitEmergencyCbMode: function(serviceId) {
    if (!serviceId) {
      serviceId = 0;
    }

    const conns = this.getConnectionInterface();
    const conn = conns[serviceId];
    conn.exitEmergencyCbMode();
  },

  // Protocol state listener.
  isNoSIMStatus: function() {
    const conn = connections;
    for (let i = 0; i < conn.length; i++) {
      if (conn[i].iccId) {
        return false;
      }
    }
    return true;
  },

  isAirplaneState: function() {
    const conn = connections && connections[0];
    return conn && conn.radioState === 'disabled';
  },

  // TaskGF5GTMO-4010 porting from PRGF7VZW-6924-tingting.chao on 24/09/09 Can recieve sms but cannot send sms in airplane mode with wifi on but wfc off-begin
  isWifiConnected: function() {
    const wifiManager = navigator.b2g.wifiManager;
    if (wifiManager) {dump('The Wifi Status is' + wifiManager.connection.status);}
    return wifiManager && wifiManager.connection.status === 'connected';
  },
  // TaskGF5GTMO-4010 porting from PRGF7VZW-6924-tingting.chao on 24/09/09 Can recieve sms but cannot send sms in airplane mode with wifi on but wfc off-end

  isVoWifiStatus: function(serviceId) {
    if (!serviceId) {
      serviceId = 0;
    }

    const conn = connections && connections[serviceId];
    const imsHandler = conn && conn.imsHandler;
    return (imsHandler && (imsHandler.capability === 'voice-over-wifi' ||
                           imsHandler.capability === 'video-over-wifi'));
  },

  isSMSAbleToSend: function(serviceId) {
    const conn = connections && connections[serviceId];
    const voice = conn && conn.voice;
    const data = conn && conn.data;// TaskGF5GTMO-4029 porting from PRGF7TF-4331-tingting.chao-add
    const imsHandler = conn && conn.imsHandler;
    // Check 4G LTE or VoWifi fist
    if (imsHandler && imsHandler.capability) {
      // can send
      return true;
    }
    // Check voice state next
    else if (voice && voice.state === 'registered') {
      // can send
      return true;
    }
    // TaskGF5GTMO-4029 porting from PRGF7TF-4331-tingting.chao-begin
    else if(OperatorUtils.isVZWFamily()) {
      if(data && data.state === 'registered') {
        return true;
      }
    }
    // TaskGF5GTMO-4029 porting from PRGF7TF-4331-tingting.chao-end
    // Data is not good
    else {
      // Not air plane mode && has SIM card
      if (conn && conn.radioState === 'enabled' && conn.iccId !== null) {
        DialogManager.showMessageError('NoSignalError');
        return false;
      }

      // Handle other situations by message sending process.
      return true;
    }
  },

  isMMSAbleToSend: function(serviceId) {
    const conn = connections && connections[serviceId];
    const data = conn && conn.data;
    const imsHandler = conn && conn.imsHandler;
    // Check whether the data is active SIM card first.
    if (Settings.hasSeveralSim() && Settings.dataServiceId !== serviceId) {
      DialogManager.showMessageError('NonActiveSimCardToSendError');
      return false;
    }

    // Check 4G LTE or VoWifi.
    if (imsHandler && imsHandler.capability) {
      // can send
      return true;
    }
    // Check data state last, registered for major card.
    else if (data && data.state === 'registered') {
      // can send
      return true;
    }
    // Data is not good
    else {
      // Not air plane mode && has SIM card
      if (conn && conn.radioState === 'enabled' && conn.iccId !== null) {
        DialogManager.showMessageError('NoSignalError');
        return false;
      }

      // Handle other situations by message sending process.
      return true;
    }
  },

  preSendCondition: function(serviceId) {
    // ECBM mode handler.
    if (this.isEmergencyCbMode(serviceId)) {
      DialogManager.confirmAlert('emergency-cb-mode-title', 'emergency-cb-mode-body',
                                 'no', null, null, null, 'yes', () => {
                                   this.exitEmergencyCbMode(serviceId);
                                   SendService.startSendMessage();
                                 });
      return false;
    }

    // According to the discussion, the alert order should be
    // storage full > no SIM > airplane mode > no data.
    if (this.isDiskFull) {
      DialogManager.alertFreeSpace('send');
      return false;
    }

    if (this.isNoSIMStatus()) {
      DialogManager.showMessageError('NoSimCardError');
      return false;
    }

    // VoWifi use data SIM card default.
    if (this.isAirplaneState() && 
        !this.isVoWifiStatus(Settings.dataServiceId)) {
      DialogManager.showMessageError('RadioDisabledError');
      return false;
    }

    // VoWifi use data SIM card default.
    // Porting from PRGF7TF-4419 - tingting.chao on 24/09/09 add VoWifi check
    if (Compose.type === 'mms' && !Settings.dataEnable &&
        Settings.whiteListOff && !StateManager.isVoWifiStatus(Settings.dataServiceId)) {
      if (this.isAirplaneState()) {
        DialogManager.showMessageError('RadioDisabledError');
      } else {
        DialogManager.alertDataOffStatus();
      }
      return false;
    }

    return true;
  }
};
