/* global clients, NotiificationManager, l10n, Utils */
'use strict';

let activityHandler = null;
let resolveIdleTimeExtension = null;

self.importScripts('http://shared.localhost/js/session/lib_session.js');
self.importScripts('http://shared.localhost/js/session/task_scheduler.js');
self.importScripts('http://shared.localhost/js/session/settings/settings_observer.js');
self.importScripts('http://shared.localhost/js/session/contacts_manager/contacts_manager.js');
self.importScripts('http://shared.localhost/js/utils/l10n/l10n_sw.js');
self.importScripts('./sw/js/utils.js');
self.importScripts('./sw/js/notification_handler.js');

Utils.initSession();

self.addEventListener('install', (event) => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

self.onsystemmessage = (event) => {
  console.log('service start at message app, event is :: '+event.name);
  switch(event.name) {
    case 'activity': {
      activityHandler = event.data.webActivityRequestHandler();
      const aData = activityHandler.source.data;
      const aName = activityHandler.source.name;
      const data = { source: activityHandler.source };

      switch(aName) {
        // DefectGF5GTMO-4531-tingting.chao@tcl.com-begin
        case 'main_sms': {
          event.waitUntil(
            clients.openWindow('/index.html', {disposition: 'inline'}).then((windowClient) => {
              console.log('service worker open window successfully, data is ' + aData);
              windowClient && windowClient.postMessage(data);
              }, (err) => {
                console.error('service worker open window fail, reason is ' + err);
              })
            );
          break;
        }
        // DefectGF5GTMO-4531-tingting.chao@tcl.com-end
        case 'new': {
          event.waitUntil(clients.matchAll({
            type: 'window'
          }).then(() => {
            clients.openWindow('/index_open.html', { disposition: 'inline' }).then((windowClient) => {
              console.log('service worker open window successfully, data is ' + aData);
              windowClient && windowClient.postMessage(data);
            }, (err) => {
              console.error('service worker open window fail, reason is ' + err);
            });
          }));
          break;
        }
        case 'share': {
          event.waitUntil(clients.matchAll({
            type: 'window'
          }).then(() => {
            clients.openWindow('/index_open.html', { disposition: 'inline' }).then((windowClient) => {
              console.log('service worker open window successfully, data is ' + aData);
              windowClient && windowClient.postMessage(data);
            }, (err) => {
              console.error('service worker open window fail, reason is ' + err);
            });
          }));
          break;
        }
        case 'latest-message': {
          event.waitUntil(clients.matchAll({
            type: 'window'
          }).then(() => {
            clients.openWindow('/index.html#activity-latest-message', { disposition: 'inline' }).then((windowClient) => {
              console.log('service worker open window successfully, data is ' + aData);
              windowClient && windowClient.postMessage(data);
            }, (err) => {
              console.error('service worker open window fail, reason is ' + err);
            });
          }));
          break;
        }
        default:
          break;
      }
      // IdleTimeExtension to make service worker timeout longer
      const idleTimeExtension = new Promise((resolve) => {
        resolveIdleTimeExtension = resolve;
      });
      event.waitUntil(idleTimeExtension);
      break;
    }
    case 'sms-received': {
      l10n.once(() => {
        const messageData = event.data.json();

        // Not show notification if class 0 message received.
        if (messageData.messageClass === 'class-0') {
          return;
        }

        // Create event logger.
        if (messageData.type === 'sms') {
          Utils.sendEventLogs(messageData.sender, 'sms_receive');
        }

        Utils.getSettingsValue('message.thread.id').then((value) => {
          const appThreadId = value ? +value : value;
          if (appThreadId === messageData.threadId) {
            return;
          }

          NotiificationManager._onSmsReceived(messageData,
            (sender, message, iconURL, needManualRetrieve) => {
            let notificationOptions;
            if (message.type === 'sms') {
              notificationOptions = {
                icon: iconURL,
                body: message.body === null ? '' : message.body,
                tag: 'messageId:' + message.id,
                data: 'threadId:' + message.threadId
              };
            } else {
              let notificationBody;
              if (needManualRetrieve) {
                notificationBody = l10n.get('notDownloaded-title');
              } else if (message.subject) {
                notificationBody = message.subject;
              } else {
                notificationBody = l10n.get('mms-message');
              }
              notificationOptions = {
                icon: iconURL,
                body: notificationBody,
                tag: 'messageId:' + message.id,
                data: 'threadId:' + message.threadId
              };
            }
            self.registration.showNotification(sender, notificationOptions);
          });
        });
      });
      break;
    }
    case 'sms-delivery-success': {
      l10n.once(() => {
        const deliveryData = event.data.json();
        NotiificationManager.checkNotificationMode(deliveryData,
          (sender, message, iconURL) => {
          const deliveryTitle = l10n.get('messages');
          const deliveryBody = l10n.get('delivery-notification');
          const deliveryOptions = {
            icon: iconURL,
            body: deliveryBody,
            tag: 'messageId:' + message.id,
            data: 'threadId:' + message.threadId
          };
          self.registration.showNotification(deliveryTitle, deliveryOptions);
        });
      });
      break;
    }
    // Porting from PR 11726098-renlongou on 2024/09/07-begin
    case 'sim-sms-storage-full': {
      l10n.once(() => {
        const deliveryTitle = l10n.get('sim_full_title');
        const deliveryBody = l10n.get('sim_full_body');
        const deliveryOptions = {
          body: deliveryBody,
        };
        self.registration.showNotification(deliveryTitle, deliveryOptions);
      });
      break;
    }
    // Porting from PR 11726098-renlongou on 2024/09/07-end

  }
};

self.onmessage = (event) => {
  // Message received from clients
  const { data } = event;
  // Remove notification from service worker if notification created by service worker.
  if (data.tag) {
    self.registration.getNotifications().then((notifications) => {
      for (let i = 0; i < notifications.length; i++) {
        if (notifications[i].data === data.tag) {
          notifications[i].close();
        }
      }
    });
    return;
  }
  if (!activityHandler || data.isDummy) {
    return;
  }
  if (data.error) {
    activityHandler.postError(data.error);
  } else {
    activityHandler.postResult(data.result);
  }
  activityHandler = null;
  if (resolveIdleTimeExtension) {
    resolveIdleTimeExtension();
    resolveIdleTimeExtension = null;
  }
  // Post save draft message to confirm background app update normally.
  if (data.result && data.result.data) {
    event.waitUntil(clients.matchAll({
      type: 'window'
    }).then((clients) => {
      for (let i = 0; i < clients.length; i++) {
        if (clients[i].url === 'http://sms.localhost/index.html') {
          clients[i].postMessage({ action: 'save-draft', data: data.result.data });
        }
      }
    }));
  }
};

self.onnotificationclick = (event) => {
  console.log('service worker notification listener well');
  let notificationData = {
    tag: event.notification.tag,
    data: event.notification.data
  };

  // Porting from PR 11726098-renlongou on 2024/09/07-begin
  if(event.notification.data == null){
    event.waitUntil(
      clients.openWindow('/index.html', {disposition: 'inline'}).then((windowClient) => {
        console.log('service worker open window successfully, data is ' + event.notification.data);
        windowClient && windowClient.postMessage(event.notification.data);
      }, (err) => {
        console.error('service worker open window fail, reason is ' + err);
      })
    );
    event.notification.close();
    return;
  }
  // Porting from PR 11726098-renlongou on 2024/09/07-end

  notificationData = JSON.parse(JSON.stringify(notificationData));

  event.waitUntil(clients.matchAll({
    type: 'window'
  }).then(() => {
    // Close other notifications.
    self.registration.getNotifications().then((notifications) => {
      for (let i = 0; i < notifications.length; i++) {
        if (event.notification.data === notifications[i].data) {
          notifications[i].close();
        }
      }
    });
    clients.openWindow('/index_bubble.html', { disposition: 'inline' }).then((windowClient) => {
      windowClient && windowClient.postMessage(notificationData);
    }, (err) => {
      console.error('service worker open window fail, reason is ' + err);
    });
  }));
};
