/* global Utils */
'use strict';

// eslint-disable-next-line no-unused-vars
const NotiificationManager = {
  _onSmsReceived: function(message, callback) {
    this.smsRealReceived(message, callback);
  },

  smsRealReceived: function(message, callback) {
    // TODO silent sms need be handled here.
    this.handleNotification(message, callback);
  },

  handleNotification: function(message, callback) {
    if (message.type === 'sms') {
      this.dispatchNotification(message, callback);
    } else {
      const status = message.deliveryInfo[0].deliveryStatus;
      if (status === 'pending') {
        return;
      }
      this.dispatchNotification(message, callback, status !== 'success');
    }
  },

  dispatchNotification: function(message, callback, needManualRetrieve) {
    this.checkNotificationMode(message, callback, needManualRetrieve);
  },

  checkNotificationMode: function(message, callback, needManualRetrieve) {
    const number = message.sender;
    let iconURL;

    Utils.getSettingsValue('operatorvariant.iccIds').then((iccidArr) => {
      const newArray = iccidArr.filter((iccValue) => iccValue !== null);
      if (newArray.length > 1) {
        const index = iccidArr.indexOf(message.iccId);
        iconURL = `sim-${index + 1}`;
      }

      if (number) {
        Utils.findByAddress(message.sender, (contacts) => {
          let sender = message.sender;
          if (contacts.length && contacts[0].name) {
            sender = contacts[0].name;
          }
          callback(sender, message, iconURL, needManualRetrieve);
        });
      } else {
        callback(number, message, iconURL, needManualRetrieve);
      }
    });
  }
};
