/* eslint-disable no-useless-escape */
/* eslint-disable optimize-regex/optimize-regex */
/* global SettingsObserver, ContactsManager, WebActivity */
'use strict';

const filterFns = {
  contains: function(a, b) {
    a = a.toLowerCase();
    b = b.toLowerCase();
    return a.contains(b);
  },
  equality: function(a, b) {
    a = a.toLowerCase();
    b = b.toLowerCase();
    return a === b;
  }
};

function isMatch(contact, criteria, filterFn) {
  const found = {};

  outer:
    for (let i = 0, ilen = criteria.terms.length; i < ilen; i++) {
      const term = criteria.terms[i];
      for (let j = 0, jlen = criteria.fields.length; j < jlen; j++) {
        const field = criteria.fields[j];

        if (!contact[field]) {
          continue;
        }

        for (let k = 0, klen = contact[field].length; k < klen; k++) {
          let value = contact[field][k];
          if (typeof value.value !== 'undefined') {
            value = value.value;
          }

          if ((found[term] = filterFn(value.trim(), term))) {
            continue outer;
          }
        }
      }
    }

  return Object.keys(found).every(function(key) {
    return found[key];
  });
}

// eslint-disable-next-line no-unused-vars
const Utils = {
  servicesArray: [
    'settingsService',
    'contactsService'
  ],

  initSession: function() {
    return new Promise((resolver) => {
      window.libSession.initService(this.servicesArray).then(() => {
        SettingsObserver.init();
        resolver();
      });
    });
  },

  isEmailAddress: function(email) {
    const rmail = /[\w-]+@[\w\-]/;
    const extraEmail = email.indexOf(' ') === -1;
    return rmail.test(email) && extraEmail;
  },

  findExactByEmail: function(fValue, callback) {
    // Email not distinguish the lower case and upper case.
    fValue = fValue.toLocaleLowerCase();
    const emailPara = 4;
    const equalsPara = 0;
    return this.findBy({
      filterBy: [emailPara],
      filterOption: equalsPara,
      filterValue: fValue
    }, callback);
  },

  findByPhoneNumber: function(filterValue, callback) {
    const telPara = 3;
    const matchPara = 2;
    return this.findBy({
      filterBy: [telPara],
      filterOption: matchPara,
      filterValue: filterValue.replace(/\s+/g, '')
    }, (results) => {
      if (results && results.length) {
        callback(results);
      } else {
        callback([]);
      }
    });
  },

  findByAddress: function(fValue, callback) {
    if (this.isEmailAddress(fValue)) {
      this.findExactByEmail(fValue, callback);
    } else {
      this.findByPhoneNumber(fValue, callback);
    }
  },

  findBy: function(filter, callback) {
    const lower = [];
    const filterValue = (filter.filterValue || '').trim();
    let contactArray = [];
    let terms;

    if (!filterValue.length) {
      setTimeout(() => {
        callback(
          typeof filter.filterValue === 'undefined' ? null : [], {}
        );
      });
      return;
    }

    const rspaces = /\s+/;
    terms = filterValue.split(rspaces);
    filter.filterValue = terms.length === 1 ?
      terms[0] : terms.reduce((initial, term) => {
        lower.push(term.toLowerCase());
        return term.length > initial.length ? term : initial;
      }, '');

    // Set the filter count limit.
    if (filter.filterValue.length < 3) {
      filter.filterLimit = 10;
    }

    lower.splice(lower.indexOf(filter.filterValue.toLowerCase()), 1);
    lower.push.apply(lower, terms);

    // Return one data once is enough.
    ContactsManager.find(filter, 1).then((cursor) => {
      const mapCursor = cursor;
      circleMap();

      function circleMap() {
        mapCursor.next().then((contact) => {
          contactArray.push(contact[0]);
          circleMap();
        }).catch(() => {
          mapCursor.release();

          const fields = ['tel', 'givenName', 'familyName', 'name', 'email'];
          const criteria = { fields: fields, terms: lower };
          let results = [];
          let eachContact;

          if (terms.length > 1) {
            while ((eachContact = contactArray.pop())) {
              if (isMatch(eachContact, criteria, filterFns.contains)) {
                results.push(eachContact);
              }
            }
          } else {
            results = contactArray;
          }

          callback(results, {
            terms: terms
          });
        });
      }
    }, () => {
      callback(null);
    });
  },

  getSettingsValue: function(settingsValue) {
    return new Promise((resolver) => {
      SettingsObserver.getValue(settingsValue).then((result) => {
        const settingsResult = result || null;
        resolver(settingsResult);
      });
    });
  },

  /*
   * Send the event to the event_logger_module, the caught events are:
   * When receive a SMS, need save log.
   */
  sendEventLogs: function(numbers, type) {
    const DATASTORE_NAME = 'eventlogger-event';

    this.findContactInArray(numbers).then((param) => {
      let options = {};
      if (type === 'sms_receive') {
        options = {
          event_type: type,
          data: {
            is_contact: param[0]
          }
        };
      }

      return new Promise((resolve) => {
        const activity = new WebActivity(DATASTORE_NAME, options);
        activity.start().then(() => {
          resolve();
        }).catch((err) => {
          console.error(`Send event log with error: ${err}`);
        });
      });
    });
  },

  findContactInArray: function(numbers) {
    let is_contact = 0;
    let is_dial = 0;
    let count = 0;

    if (!Array.isArray(numbers)) {
      numbers = [numbers];
    }

    return new Promise((resolve) => {
      numbers.forEach((number) => {
        this.findByAddress(number, (result) => {
          count++;
          // There is one situation we can not get,
          // if the user input a contact number, it is difficult to confirm
          // the number is manually input or not, so we only use a sample
          // logic here.
          // The contact number or email is not input manually.
          if (result && result.length > 0) {
            is_contact = 1;
          } else {
            is_dial = 1;
          }

          if (count === numbers.length) {
            resolve([is_contact, is_dial]);
          }
        });
      });
    });
  }
};
