/* global Threads, Utils, OptionManager, ActivityPicker, ValueDefault,
          DeviceCapabilityManager, Settings, SendService, SoftkeyManager, 
          TelephonyHelper, StateManager, DialogManager */

'use strict';

// eslint-disable-next-line no-unused-vars
const CallManager = {
  majorCall: function(isRTT) {
    const callElement = [];
    for (let i = 0; i < Threads.active.participants.length; i++) {
      if (!Utils.isEmailAddress(Threads.active.participants[i])) {
        callElement.push(Threads.active.participants[i]);
      }
    }

    // If only one recipient, call directly, else show select dialog.
    if (callElement.length > 1) {
      OptionManager.recipientsSelectOption(callElement, 'call', isRTT);
    } else {
      ActivityPicker.dial(callElement[0], false, isRTT);
    }
  },

  callFromMessage: function(number, isDirect, isRTT) {
    DeviceCapabilityManager.get('device.vilte').then((hasVT) => {
      // If RTT is enabled, not call video call.
      if (isRTT) {
        hasVT = false;
      }

      if (hasVT) {
        OptionManager.switchCallOption('normal-call', 'video-call', (VTEnable) => {
          this.simSelectCallback(isDirect, number, VTEnable, isRTT);
        });
      } else {
        this.simSelectCallback(isDirect, number, false, isRTT);        
      }
    });
  },

  simSelectCallback: function(isDirect, number, VTEnable, isRTT) {
    let telServiceId;
    if (Settings.telephonyServiceId === -1) {
      if (Settings.hasSeveralSim()) {
        // If there is option menu, not create it again.
        if (OptionManager.isOptionMenuShown()) {
          return;
        }
        this.startSIMCall(isDirect, number, VTEnable, isRTT);
      } else {
        telServiceId = SendService.selectSIMCard();
        this.telephonyCall(isDirect, number, telServiceId, VTEnable, isRTT);
      }
    } else {
      // If there is only one sim card slot, we use sim1 to call number.
      telServiceId = Settings.telephonyServiceId;
      if (telServiceId === null) {
        telServiceId = 0;
      }
      this.telephonyCall(isDirect, number, telServiceId, VTEnable, isRTT);
    }
  },

  telephonyCall: function(isDirect, number, serviceID, VTEnable, isRTT) {
    // ECBM mode handler.
    if (StateManager.isEmergencyCbMode(serviceID)) {
      DialogManager.confirmAlert('emergency-cb-mode-title', 'emergency-cb-mode-call-body',
                                 'no', null, null, null, 'yes', () => {
                                   StateManager.exitEmergencyCbMode(serviceID);
                                   CallManager.telephonyCall(isDirect, number, serviceID, VTEnable, isRTT);
                                 });
      return;
    }

    function callAndback() {
      if (isDirect) {
        SoftkeyManager.updateCallKey();
      }
    }

    function callDisconnectOrError() {
      ValueDefault.isCall = false;
      if (isDirect) {
        SoftkeyManager.updateCallKey();
      }
    }

    ValueDefault.isCall = true;
    TelephonyHelper.call(number, serviceID, VTEnable, isRTT,
      callAndback, callAndback, callDisconnectOrError, callDisconnectOrError);
  },

  startSIMCall: function(isDirect, number, VTEnable, isRTT) {
    OptionManager.simSelectOptions((serviceID) => {
      this.telephonyCall(isDirect, number, serviceID, VTEnable, isRTT);
    });
  }
};
