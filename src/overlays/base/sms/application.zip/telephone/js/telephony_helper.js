/* eslint-disable optimize-regex/optimize-regex */
/* global LazyLoader, ICCUtils, MmiManager, TelephonyCall,
          TelephonyMessages, StateManager */

'use strict';

window.TelephonyHelper = (function() {
  const DTMF_SEPARATOR_PAUSE_DURATION = 3000;
  const CALL_TYPE_VOICE_N_VIDEO = 1;
  const CALL_TYPE_VT = 4;
  const telephoneInterfance = navigator.b2g.telephony;

  const loadTelephonyMessages = function(callback) {
    LazyLoader.load(['/telephone/js/telephony_messages.js'], callback);
  };

  const call = function(number, cardIndex, isVideo, isRTT, oncall, 
                        onconnected, ondisconnected, onerror) {
    const sanitizedNumber = number.replace(/(\s|-|\.|\(|\))/g, '');
    if (!isValid(sanitizedNumber)) {
      loadTelephonyMessages(() => {
        TelephonyMessages.displayMessage('BadNumber');
      });
      return;
    }

    let conn = StateManager.getConnectionInterface();
    conn = conn[cardIndex];
    //TaskGF5GTMO-3568-porting from Defecct10676918-tingting.chao on 24/08/21-begin
    dump("Telephony helper ,isNoSIMStatus = " + StateManager.isNoSIMStatus());
    if (StateManager.isNoSIMStatus()) {
      loadTelephonyMessages(() => {
        TelephonyMessages.displayMessage('NoNetwork');
      });
      return;
     }
     //TaskGF5GTMO-3568-porting from Defecct10676918-tingting.chao on 24/08/21-end

    //TaskGF5GTMO-3589-porting from Defect10795501-tingting.chao on 24/08/23-begin
    let isWfcEnable = StateManager.isVoWifiStatus(cardIndex);

    //if (!conn || !conn.voice.connected) {
    if ((!conn || !conn.voice.connected) && !isWfcEnable) {
    //TaskGF5GTMO-3589-porting from Defect10795501-tingting.chao on 24/08/23-end
      // No voice connection, the call won't make it
      loadTelephonyMessages(() => {
        if (conn && conn.radioState === 'disabled') {
          TelephonyMessages.displayMessage('FlightMode');
        } else {
          TelephonyMessages.displayMessage('NoNetwork');
        }
      });
      return;
    }

    startDial(cardIndex, conn, sanitizedNumber, !!isVideo, !!isRTT,
              oncall, onconnected, ondisconnected, onerror);
  };

  function getNumberAsDtmfToneGroups(number) {
    return number.split(',');
  }

  function playDtmfToneGroups(dtmfToneGroups, cardIndex) {
    let length;
    // Remove the dialed number from the beginning of the array.
    dtmfToneGroups = dtmfToneGroups.slice(1);
    length = dtmfToneGroups.length;
    // Remove the latest entries from dtmfToneGroups corresponding to ','
    // characters not to play those pauses.
    let lastCommaIndex = length - 1;
    while (dtmfToneGroups[lastCommaIndex] === '') {
      lastCommaIndex--;
    }
    dtmfToneGroups = dtmfToneGroups.slice(0, ++lastCommaIndex);
    length = dtmfToneGroups.length;

    let promise = Promise.resolve(),
        counter = 0,
        pauses;
    // Traverse the dtmfToneGroups array.
    while (counter < length) {
      // Reset the number of pauses before each group of tones.
      pauses = 1;
      while (dtmfToneGroups[counter] === '') {
        // Add a new pause for each '' in the dtmfToneGroups array.
        pauses++;
        counter++;
      }
      // Send a new group of tones as well as the pauses to play before it.
      promise = promise.then(playDtmfToneGroup.bind(null,
        dtmfToneGroups[counter++], pauses, cardIndex));
    }
    return promise;
  }

  function playDtmfToneGroup(toneGroup, pauses, cardIndex) {
    return telephoneInterfance.sendTones(
      toneGroup,
      DTMF_SEPARATOR_PAUSE_DURATION * pauses,
      null,
      cardIndex
    );
  }

  function startDial(cardIndex, conn, sanitizedNumber, isVideo, isRTT, oncall,
                     onconnected, ondisconnected, onerror) {
    if (!telephoneInterfance) {
      return;
    }

    const cardState = ICCUtils.getSIMCardState(cardIndex);
    const imsCapability = conn.imsHandler && conn.imsHandler.capability;
    const emergencyOnly = !imsCapability && conn.voice.emergencyCallsOnly;
    const hasCard = (conn.iccId !== null);
    const baseNumber = getNumberAsDtmfToneGroups(sanitizedNumber)[0];
    let callPromise;

    // Note: no need to check for cardState null. While airplane mode is on
    // cardState is null and we handle that situation in call() above.
    if (((cardState === 'unknown') || (cardState === 'illegal')) &&
        (emergencyOnly === false)) {
      if (onerror) {
        console.log('Tried to make a call with a card state of: ', cardState);
        onerror();
      }
      return;
    } else if (emergencyOnly) {
      // If the mobileConnection has a sim card we let gecko take the
      // default service, otherwise we force the first slot.
      cardIndex = hasCard ? undefined : 0;
      callPromise = telephoneInterfance.dialEmergency(baseNumber, isRTT);
    } else if (isVideo) {
      callPromise = telephoneInterfance.dial(baseNumber, CALL_TYPE_VT, isRTT, cardIndex);
    } else {
      callPromise = telephoneInterfance.dial(baseNumber, CALL_TYPE_VOICE_N_VIDEO,
                                             isRTT, cardIndex);
    }

    callPromise.then((obj) => {
      if (obj instanceof TelephonyCall) {
        installHandlers(obj, sanitizedNumber, emergencyOnly, cardIndex,
                        oncall, onconnected, ondisconnected, onerror);
      } else {
        /* This is an MMICall object, manually invoke the handlers to provide
         * feedback to the user, the rest of the UX will be dealt with by the
         * MMI manager. */
        oncall();
        onconnected();
        MmiManager.handleDialing(conn, sanitizedNumber, obj.result);
      }
    }).catch((errorName) => {
      try {
        if (onerror) {
          onerror();
        }
      } catch (err) {
        console.log(err);
      }

      loadTelephonyMessages(() => {
        const messageType = emergencyOnly ? TelephonyMessages.NO_NETWORK :
                                            TelephonyMessages.REGULAR_CALL;
        TelephonyMessages.handleError(errorName, sanitizedNumber, messageType);
      });
    });
  }

  function installHandlers(call, number, emergencyOnly, cardIndex,
                           oncall, onconnected, ondisconnected, onerror) {
    if (oncall) {
      oncall();
    }
    const dtmfToneGroups = getNumberAsDtmfToneGroups(number);
    if (dtmfToneGroups.length > 1) {
      call.addEventListener('connected', function dtmfToneGroupPlayer() {
        call.removeEventListener('connected', dtmfToneGroupPlayer);
        playDtmfToneGroups(dtmfToneGroups, cardIndex);
      });
    }
    call.addEventListener('connected', onconnected);
    call.ondisconnected = ondisconnected;
    call.onerror = onerror;
  }

  const isValid = function(sanitizedNumber) {
    const validExp = /^(?!,)([0-9#+*,]){1,50}$/;
    return validExp.test(sanitizedNumber);
  };

  const getInUseSim = function() {
    if (telephoneInterfance) {
      const isInCall = !!telephoneInterfance.calls.length;
      const isInConference = !!telephoneInterfance.conferenceGroup &&
                             !!telephoneInterfance.conferenceGroup.calls.length;

      if (isInCall || isInConference) {
        return isInCall ? telephoneInterfance.calls[0].serviceId :
                          telephoneInterfance.conferenceGroup.calls[0].serviceId;
      }
    }

    return null;
  };

  return {
    call: call,
    getInUseSim: getInUseSim
  };
})();
