/* globals ErrorDialog */

'use strict';

// eslint-disable-next-line no-unused-vars
const TelephonyMessages = {
  // Display the regular "invalid number" message, as this is a regular call.
  REGULAR_CALL: 0,
  // We have no network and/or no SIM, so we can only make emergency calls.
  // Display the "no network" message.
  NO_NETWORK: 1,
  // We are making a call from an emergency call view, so calls can only be
  // placed to emergency and ICE numbers. Display the "not an emergency number"
  // message.
  EMERGENCY_ONLY: 2,

  displayMessage: function(message, number) {
    let dialogTitle, dialogBody;

    switch (message) {
      case 'BadNumber':
        dialogTitle = 'invalidNumberToDialTitle';
        dialogBody = 'invalidNumberToDialMessage';
        break;
      case 'FlightMode':
        dialogTitle = 'callAirplaneModeTitle';
        dialogBody = 'callAirplaneModeMessage';
        break;
      case 'NoNetwork':
        dialogTitle = 'emergencyDialogTitle';
        dialogBody = 'emergencyDialogBodyBadNumber';
        break;
      case 'DeviceNotAccepted':
        dialogTitle = 'emergencyDialogTitle';
        dialogBody = 'emergencyDialogBodyDeviceNotAccepted';
        break;
      case 'UnableToCall':
        dialogTitle = 'unableToCallTitle';
        dialogBody = 'unableToCallMessage';
        break;
      case 'NumberIsBusy':
        dialogTitle = 'numberIsBusyTitle';
        dialogBody = 'numberIsBusyMessage';
        break;
      case 'FixedDialingNumbers':
        dialogTitle = 'fdnIsActiveTitle';
        dialogBody = 'fdnIsActiveMessage';
        break;
      case 'OtherConnectionInUse':
        dialogTitle = 'otherConnectionInUseTitle';
        dialogBody = 'otherConnectionInUseMessage';
        break;
      case 'EmergencyCallOnly':
        dialogTitle = 'emergency-call-only';
        dialogBody = 'emergency-call-error';
        break;
      default:
        console.error('Invalid message argument'); // Should never happen
        return;
    }
    ErrorDialog.showTelephonyErrorDialog('cd-type-msg-call-only',
                                         dialogTitle,
                                         dialogBody,
                                         { number: number },
                                         { accept: 'ok' });
  },

  handleError: function(errorName, number, emergencyOptions) {
    switch(errorName) {
      case 'ModifiedDial': {
        // We ignore this error because some networks generate this with
        // STK CallControl when calling Voicemail pilots (e.g. TMobile).
        console.log('ModifiedDialError');
        return;  
      }
      case 'BadNumber': {
        if (emergencyOptions === this.NO_NETWORK) {
          this.displayMessage('NoNetwork');
        } else if (emergencyOptions === this.EMERGENCY_ONLY) {
          this.displayMessage('EmergencyCallOnly', number);
        } else {
          console.error('Unexpected emergency options: ' + emergencyOptions);
        }
        break;
      }
      case 'DeviceNotAccepted': {
        this.displayMessage('DeviceNotAccepted');
        break;
      }
      case 'RadioNotAvailable': {
        this.displayMessage('FlightMode');
        break;
      }
      case 'Busy': {
        this.displayMessage('NumberIsBusy');
        break;
      }
      case 'FDNBlocked':
      case 'FdnCheckFailure': {
        this.displayMessage('FixedDialingNumbers', number);
        break;
      }
      case 'OtherConnectionInUse': {
        this.displayMessage('OtherConnectionInUse');
        break;
      }
      default: {
        // If the call failed for some other reason we should still
        // display something to the user.
        console.error('Unexpected error: ', errorName);
        this.displayMessage('UnableToCall');
      }
    }
  }
};
