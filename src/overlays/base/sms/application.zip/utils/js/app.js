(function(exports) {
  'use strict';

  const APPLICATION_READY_CLASS_NAME = 'js-app-ready';

  exports.App  = {
    // Judge ready state.
    isReady: function() {
      return document.body.classList.contains(APPLICATION_READY_CLASS_NAME);
    },

    // Set ready state.
    setReady: function() {
      if (this.isReady()) {
        throw new Error('Application should be marked as ready only once!');
      }
      document.body.classList.add(APPLICATION_READY_CLASS_NAME);
      // Set audio channel.
      if (navigator.mozAudioChannelManager) {
        navigator.mozAudioChannelManager.volumeControlChannel = 'notification';
      }
    },

    // Listen ready state.
    whenReady: function() {
      if (this.isReady()) {
        return Promise.resolve();
      }
      return new Promise((resolve, reject) => {
        let bodyClassObserver = new MutationObserver(() => {
          try {
            if (this.isReady()) {
              bodyClassObserver.disconnect();
              resolve();
            }
          } catch(err) {
            reject(err);
          }
        });

        bodyClassObserver.observe(document.body, {
          attributes: true,
          attributeFilter: ['class']
        });
      });
    }
  };
})(this);
