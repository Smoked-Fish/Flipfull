/* global StateManager, MessageCacheRestore */

(function(exports) {
  'use strict';

  exports.MessageCache = {
    // Save node as cache.
    saveFromNode: function(moduleId, node) {
      const html = node.outerHTML;
      // Should not cache anything if the data space exceed.
      if (!StateManager.isDiskFull) {
        this.save(moduleId, html);
      }
    },

    save: function(moduleId, html) {
      const id = moduleId;
      const langDir = document.querySelector('html').getAttribute('dir');
      const lang = navigator.language;
      // TODO Need find a way to know whether is from activity first by the web activity.
      const isActivityPage = false;
      let cachedSoftkeyHtml;

      if (!isActivityPage) {
        const softkey = document.getElementById('softkeyPanel');
        let cachedSoftkeyNode = null;
        if (softkey) {
          cachedSoftkeyNode = this.cloneAsInertNodeAvoidingCustomElementHorrors(softkey);
        }
        if (cachedSoftkeyNode) {
          cachedSoftkeyNode.setAttribute('id', 'cachedSoftkeyPanel');
          cachedSoftkeyHtml = cachedSoftkeyNode.outerHTML;
        }
      } else {
        cachedSoftkeyHtml = MessageCacheRestore.softkeyCacheBackup;
      }

      html = window.HTML_CACHE_VERSION + (langDir ? ',' + langDir : '') +
             (lang ? ',' + lang : '' ) + ',' + cachedSoftkeyHtml + ':' + html;
      localStorage.setItem('html_cache_' + id, html);
    },

    // Clear all caches.
    clear: function(moduleId) {
      localStorage.removeItem('html_cache_' + moduleId);
    },

    cloneAsInertNodeAvoidingCustomElementHorrors: function(node) {
      const templateNode = document.createElement('template');
      const cacheDoc = templateNode.content.ownerDocument;
      const cacheNode = cacheDoc.importNode(node, true);
      return cacheNode ? cacheNode : null;
    }
  };
})(this);
