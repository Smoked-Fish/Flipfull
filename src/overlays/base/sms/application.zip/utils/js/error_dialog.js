/* global Settings, DialogManager, Utils, FocusStateManager, ValueDefault, 
          ActivityModule, ThreadUI */

(function(exports) {
  'use strict';

  exports.ErrorDialog = {
    showErrorDialog: function(errorDescription, options) {
      const prefix = errorDescription.prefix;
      let isSwitchSimData = false;
        
      if (!prefix) {
        throw new Error('Prefix is required!');
      }
    
      const dialogOptions = {
        cancel: {
          text: prefix + 'BtnOk'
        }
      };
    
      if (options && options.confirmHandler && errorDescription.executeHandler) {
        dialogOptions.confirm = {
          text: prefix + 'Confirm',
          method: options.confirmHandler
        };
      }
    
      const bodyL10nId = prefix + 'Body';
      let body = null;
      let messageBodyParams = null;
    
      if (errorDescription.showRecipient) {
        messageBodyParams = {
          n: options.recipients.length
        };
    
        body = {
          id: bodyL10nId,
          args: messageBodyParams
        };
      } else if (errorDescription.showDsdsStatus) {
        // Use the data serviceId to define which data MMS will use.
        const mmsServiceId = Settings.dataServiceId;
        if (mmsServiceId !== null) {
          switch (mmsServiceId) {
            case 0:
              messageBodyParams = {
                activeSimId: '1',
                nonActiveSimId: '2'
              };
              break;
            case 1:
              messageBodyParams = {
                activeSimId: '2',
                nonActiveSimId: '1'
              };
              break;
            default:
              console.error('MMS ServiceId(' + mmsServiceId + ') is not matched!');
          }
        } else {
          console.error('Settings unavailable');
        }
    
        body = {
          id: bodyL10nId,
          args: messageBodyParams
        };
      } else if (errorDescription.selectWlanValue) {
        messageBodyParams = Settings.useWifi ? { wlan: Utils.translateString('wifi') } : 
                                               { wlan: Utils.translateString('wlan') };
        body = {
          id:bodyL10nId,
          args: messageBodyParams
        };
      }

      let desc = {
        id: prefix + 'Desc'
      };
    
      if (!Utils.translateString(desc.id)) {
        desc = null;
      }
      if (prefix === 'switchSIMDataReceiveAlert' || prefix === 'switchSIMDataSendAlert') {
        isSwitchSimData = true;
      }

      const dialogConfig = {
        title: prefix + 'Title',
        body: body || bodyL10nId,
        desc: desc,
        accept: {
          l10nId: 'confirm-dialog-ok',
          priority: 2,
          callback: function() {
            if (dialogOptions && dialogOptions.confirm &&
                dialogOptions.confirm.method) {
              dialogOptions.confirm.method();
            }
          }
        },
        closecallback: function() {
          ValueDefault.activitymode ? ActivityModule.back() : 
                                      ThreadUI.back(true);
        }
      };

      if (isSwitchSimData) {
        dialogConfig.confirm = {
          l10nId: 'settings',
          priority: 3,
          callback: function() {
            Utils.handleActivity('configure', {
              target: 'device',
              section: 'sim-manager'
            });
          }
        };
      }

      DialogManager.createDialogFrame('confirmDialog', dialogConfig);
    },

    showTelephonyErrorDialog: function(dialogType, dialogTitle, dialogBody, 
                                       dialogArgs, softkeysL10nIds) {
      const backupFocus = document.activeElement;
      const dialogConfig = {
        type: dialogType,
        title: { id: dialogTitle },
        body: { id: dialogBody, args: dialogArgs },
        accept: {
          l10nId: softkeysL10nIds.accept,
          priority: 2,
          callback: function() {
            backupFocus.focus();
            FocusStateManager.dynamicSK();
          }
        },
        backcallback: function() {
          setTimeout(() => {
            backupFocus.focus();
            FocusStateManager.dynamicSK();
          });
        }
      };

      DialogManager.createDialogFrame('confirmDialog', dialogConfig);
    }
  };
}(this));
