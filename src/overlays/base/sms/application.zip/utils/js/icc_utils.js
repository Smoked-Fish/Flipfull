/* global Settings, Utils, StateManager */

'use strict';

const ICCManager = navigator.b2g.iccManager;

// eslint-disable-next-line no-unused-vars
let ICCUtils = {
  init: function() {
    let timer1 = null;
    let timer2 = null;
    // TODO: Can not get the MSISDN immediately, so set the wait time to prevent program died.
    const waitTime = 5000;
    ICCManager.addEventListener('iccdetected', (evt) => {
      const iccInfo = ICCManager.getIccById(evt.iccId);
      if (iccInfo) {
        Settings.updateServiceIds();
        const serviceId = Settings.getServiceIdByIccId(evt.iccId);
        if (Settings.hasGroup) {
          let numberFlag = false;
          iccInfo.oniccinfochange = () => {
            if (iccInfo.iccInfo.msisdn || iccInfo.iccInfo.mdn) {
              if (!numberFlag) {
                numberFlag = true;
                this.handleSIMChange(serviceId);
                window.dispatchEvent(new CustomEvent('sim-card-changed'));
              }
            }
          };
          if (serviceId === 0) {
            timer1 = setTimeout(() => {
              if (!numberFlag) {
                this.handleSIMChange(serviceId);
                window.dispatchEvent(new CustomEvent('sim-card-changed'));
              }
            }, waitTime);
          } else {
            timer2 = setTimeout(() => {
              if (!numberFlag) {
                this.handleSIMChange(serviceId);
                window.dispatchEvent(new CustomEvent('sim-card-changed'));
              }
            }, waitTime);
          }
        } else {
          window.dispatchEvent(new CustomEvent('sim-card-changed'));
        }
      }
    });
    ICCManager.addEventListener('iccundetected', (evt) => {
      const serviceId = Settings.getServiceIdByIccId(evt.iccId);
      Settings.updateServiceIds();
      if (Settings.hasGroup) {
        this.handleSIMChange(serviceId);
        if (serviceId === 0) {
          clearTimeout(timer1);
        } else {
          clearTimeout(timer2);
        }
        window.dispatchEvent(new CustomEvent('sim-card-changed', {
          detail: { type: 'unplug' }
        }));
      } else {
        window.dispatchEvent(new CustomEvent('sim-card-changed', {
          detail: { type: 'unplug' }
        }));
      }
    });
  },

  showSimInfo: function(element, iccId) {
    if (!(Settings.hasSeveralSim() && iccId && ICCManager)) {
      return;
    }

    const simId = Settings.getServiceIdByIccId(iccId);
    const serviceId = Settings.getServiceIdByIccId(iccId);
    const iccObject = ICCManager.getIccById(iccId);
    let operator = '';
    if (serviceId !== null) {
      operator = Settings.getOperatorByIccId(iccId);
    }
    let number = '';
    if (iccObject) {
      number = ICCManager.getIccById(iccId).iccInfo.msisdn;
    }
    let data = {};
    let l10nId;
    let info = [operator, number].filter(function(value) {
      return value;
    });
    const detailString = info.join(', ');

    if (simId !== null) {
      l10nId = info.length ?  'sim-detail' : 'sim-id-label';
      data = { id: simId + 1, detailString: detailString };
      Utils.translateFromAtr(element.querySelector('.sim-detail'),
                             l10nId, data);
    } else {
      element.querySelector('.sim-detail').textContent = detailString;
    }

    if (simId !== null || number !== '' || operator !== '') {
      element.classList.remove('hide');
    } else {
      element.classList.add('hide');
    }
  },

  // Group SIM select function map.
  getOldSIMInfo: function() {
    return new Promise((resolve) => {
      Utils.getSettingsValue('ril.mms.group.oldSIM').then((value) => {
        resolve(value);
      });
    });
  },

  getNewSIMInfo: function() {
    const mozConnections = StateManager.getConnectionInterface();
    let iccManager = ICCManager;
    let newSIMInfo = [];
    let newSIMNumber = [];
    for (let i = 0; i < mozConnections.length; i++) {
      newSIMInfo.push(mozConnections[i].iccId);
      let simNumber = null;
      if (mozConnections[i].iccId) {
        let iccInfoDetail = iccManager.getIccById(mozConnections[i].iccId).iccInfo;
        if (iccInfoDetail.msisdn || iccInfoDetail.mdn) {
          simNumber = iccInfoDetail.msisdn || iccInfoDetail.mdn;
        }
      }

      newSIMNumber.push(simNumber);
    }

    // Backup original SIM number for speed use later.
    Settings.originalSIMNumberArray = newSIMNumber;
    Settings.originalSIMInfoArray = newSIMInfo;
    return newSIMInfo;
  },

  saveOldSimInfo: function(simInfo) {
    Utils.setSettingsValue([{ 
      name: 'ril.mms.group.oldSIM', 
      value: simInfo 
    }]);
  },

  backupFakeNumber: function() {
    const settingsArray = ['ril.mms.phoneNumber.sim1', 'ril.mms.phoneNumber.sim2'];
    for (let i = 0; i < settingsArray.length; i++) {
      Utils.getSettingsValue(settingsArray[i]).then((value) => {
        if (!value) {
          value = null;
        }

        Settings.fakeSIMNumberArray[i] = value;
      });
    }
  },

  judgeSwitchSIMSituation: function() {
    this.getOldSIMInfo().then((value) => {
      if (!Array.isArray(value)) {
        value = [];
      }

      let oldSIMInfo = value;
      let newSIMInfo = this.getNewSIMInfo();
      let isSwitch = false;
      // Only do 2 SIM, not consider 3 and more SIM now.
      // I think the situation that single SIM device
      // change to dual SIM device does not exist.
      if (oldSIMInfo.length === newSIMInfo.length) {
        for (let i = 0; i < oldSIMInfo.length; i++) {
          if (oldSIMInfo[i] !== newSIMInfo[i]) {
            // When SIM card switch, reset changed SIM number backup.
            if (i === 0) {
              Utils.setSettingsValue([{ 
                name: 'ril.mms.phoneNumber.sim1', 
                value: null 
              }]);
            } else {
              Utils.setSettingsValue([{ 
                name: 'ril.mms.phoneNumber.sim2', 
                value: null 
              }]);
            }
            isSwitch = true;
          }
        }
      } else {
        // Reset all number when confused appear.
        Utils.setSettingsValue([{ 
          name: 'ril.mms.phoneNumber.sim1', 
          value: null 
        }, { 
          name: 'ril.mms.phoneNumber.sim2', 
          value: null 
        }]);
        isSwitch = true;
      }

      // If SIM card changed, update the SIM info.
      if (isSwitch) {
        this.saveOldSimInfo(newSIMInfo);
      }

      this.backupFakeNumber();
    });
  },

  handleSIMChange: function(serviceId) {
    if (serviceId === 0) {
      Utils.setSettingsValue([{ 
        name: 'ril.mms.phoneNumber.sim1', 
        value: null 
      }]);
      Settings.fakeSIMNumberArray[0] = null;
    } else {
      Utils.setSettingsValue([{ 
        name: 'ril.mms.phoneNumber.sim2', 
        value: null 
      }]);
      Settings.fakeSIMNumberArray[1] = null;
    }
    const newSIMInfo = this.getNewSIMInfo();
    this.saveOldSimInfo(newSIMInfo);
  },

  getSIMCardState: function(serviceId) {
    const conn = StateManager.getConnectionInterface();
    const iccId = conn[serviceId].iccId;
    const iccInfo = ICCManager.getIccById(iccId);
    return iccInfo.cardState;
  }
};
