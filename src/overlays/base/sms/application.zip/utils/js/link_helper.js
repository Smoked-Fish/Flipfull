/* eslint-disable optimize-regex/optimize-regex */
/* global Utils, Settings */

(function() {
  'use strict';

  const KNOWN_TLDS = [
    'aero', 'asia', 'biz', 'cat', 'com', 'coop', 'info',
    'int', 'jobs', 'mobi', 'museum', 'name', 'net', 'org', 'post', 'pro',
    'tel', 'travel', 'xxx', 'edu', 'gov', 'mil', 'nyc', 'ac',
    'ad', 'ae', 'af', 'ag', 'ai', 'al', 'am', 'an', 'ao', 'aq', 'ar',
    'as', 'at', 'au', 'aw', 'ax', 'az', 'ba', 'bb', 'bd', 'be', 'bf',
    'bg', 'bh', 'bi', 'bj', 'bm', 'bn', 'bo', 'br', 'bs', 'bt', 'bv',
    'no', 'bw', 'by', 'bz', 'ca', 'cc', 'cd', 'cf', 'cg', 'ch', 'ci',
    'ck', 'cl', 'cm', 'cn', 'co', 'cr', 'cs', 'cu', 'cv', 'cx', 'cy',
    'cz', 'dd', 'de', 'dj', 'dk', 'dm', 'do', 'dz', 'ec', 'ee', 'eg',
    'eh', 'er', 'es', 'et', 'eu', 'fi', 'fj', 'fk', 'fm', 'fo', 'fr',
    'ga', 'gb', 'gd', 'ge', 'gf', 'gg', 'gh', 'gi', 'gl', 'gm', 'gn',
    'gp', 'gq', 'gr', 'gs', 'gt', 'gu', 'gw', 'gy', 'hk', 'hm', 'hn',
    'hr', 'ht', 'hu', 'id', 'ie', 'il', 'im', 'in', 'io', 'iq', 'ir',
    'is', 'it', 'je', 'jm', 'jo', 'jp', 'ke', 'kg', 'kh', 'ki', 'km',
    'kn', 'kp', 'kr', 'kw', 'ky', 'kz', 'la', 'lb', 'lc', 'li', 'lk',
    'lr', 'ls', 'lt', 'lu', 'lv', 'ly', 'ma', 'mc', 'md', 'me', 'mg',
    'mh', 'mk', 'ml', 'mm', 'mn', 'mn', 'mo', 'mp', 'mq', 'mr', 'ms',
    'mt', 'mu', 'mv', 'mw', 'mx', 'my', 'mz', 'na', 'nc', 'ne', 'nf',
    'ng', 'ni', 'nl', 'no', 'np', 'nr', 'nu', 'nz', 'om', 'pa', 'pe',
    'pf', 'pg', 'ph', 'pk', 'pl', 'pm', 'pn', 'pr', 'ps', 'pt', 'pw',
    'py', 'qa', 're', 'ro', 'rs', 'ru', 'su', 'рф', 'rw', 'sa', 'sb',
    'sc', 'sd', 'se', 'sg', 'sh', 'si', 'sj', 'no', 'sk', 'sl', 'sm',
    'sn', 'so', 'sr', 'ss', 'st', 'su', 'sv', 'sx', 'sy', 'sz', 'tc',
    'td', 'tf', 'tg', 'th', 'tj', 'tk', 'tl', 'tp', 'tm', 'tn', 'to',
    'tp', 'tl', 'tr', 'tt', 'tv', 'tw', 'tz', 'ua', 'ug', 'uk', 'us',
    'gov', 'uy', 'uz', 'va', 'vc', 've', 'vg', 'vi', 'vn', 'vu', 'wf',
    'ws', 'ye', 'yt', 'yu', 'za', 'zm', 'zw'
  ];

  const ipv4part = '(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)';
  const leadingDigitsRegExp = /^[+0-9]+/;

  function checkDomain(domain) {
    const ipv4RegExp = new RegExp('^(?:' + ipv4part + '\\.){3}' + ipv4part + '$');
    if (ipv4RegExp.test(domain)) {
      return true;
    } else {
      const parts = domain.split('.');
      const lastPart = parts[parts.length - 1];
      return lastPart.length > 1 && !isFinite(lastPart);
    }
  }

  // eslint-disable-next-line no-useless-escape
  const safeStart = /[\s,:;\(>\u0080-\uFFFF]/;
  const notRadioCallChar = /^[+0-9]/;
  const regexpForLink = /[0-9]+\D+[0-9]+/;
  const MINIMUM_DIGITS_IN_PHONE_NUMBER = 5;
  const LEADING_DIGIT_BREAKPOINT = 7;

  let LINK_TYPES = {
    phone: {
      regexp: new RegExp([
        // sddp: space, dot, dash or parens
        '(?:\\+\\d{1,4}[ \\t.()-]{0,3}|\\()?' +     // (\+<digits><sddp>|\()?
        '(?:\\d{1,4}[ \\t.()-]{0,3})?' +            // <digits><sdd>*
        '(?:\\d[\\d \\t.()-]{0,12}\\d)' +           // <digit><digit|sddp>*<digit>
        '\\b'                                       // must end on a word boundary
      ].join(''), 'g'),
      matchFilter: function(phone, link) {
        const onlyDigits = Utils.removeNonDialables(phone);

        if (onlyDigits.length < MINIMUM_DIGITS_IN_PHONE_NUMBER) {
          return false;
        }
        if (onlyDigits.length === MINIMUM_DIGITS_IN_PHONE_NUMBER &&
            phone.length !== onlyDigits.length) {
          return false;
        }

        const leadingDigits = leadingDigitsRegExp.exec(phone);
        if (leadingDigits &&
            leadingDigits[0].length >= LEADING_DIGIT_BREAKPOINT) {
          link.end = link.start + leadingDigits[0].length;
        }
        return link;
      },
      transform: function(phone) {
        return '<a dir="ltr" data-dial="' + phone +
               '" data-action="dial-link" class="link-focus">' + phone + '</a>';
      }
    },

    url: {
      regexp: new RegExp([
        // must begin at start of string, after whitespace,
        // {1} match the protocol https?:// or rtsp:// (optional)
        '(https?://|rtsp://)?',
        // {2} match "server name": . must be followed by at least one letter
        '((?:\\.?[-\\w]){1,256})',
        // {3} match a . followed by one or more domain valid chars
        '(\\.\\w{1,10})',
        // optional :port
        '(?::[0-9]{1,5})?',
        // start the "query" capture group by matching an optional dot then /
        '(?:\\.?/',
          // anything other than a sentence ender
          // a sentence ender not followed by whitespace
          // match 0 - 2048 characters in the url
          '(?:[^\\s.,?:;!]|[.,?:;!](?!\\s|$)){0,2048}',
        // end the "query" capture group (optional)
        ')?'
      ].join(''), 'mgi'),
      matchFilter: function(url, linkSpec) {
        const match = linkSpec.match;
        let scheme, tld;

        if (!checkDomain(match[2] + match[3])) {
          return false;
        }

        scheme = match[1];
        tld = match[3] && match[3].slice(1).toLowerCase();

        if (!scheme && (!isFinite(tld) && KNOWN_TLDS.indexOf(tld) === -1)) {
          return false;
        }

        if (url.slice(-1) === ')' && url.indexOf('(') === -1) {
          linkSpec.end--;
        }
        return linkSpec;
      },
      transform: function(url, linkSpec) {
        let href = url;
        if (!linkSpec.match[1]) {
          href = 'http://' + href;
        }
        return '<a data-url="' + href +
               '" data-action="url-link" class="link-focus">' + url +
               '</a>';
      }
    },

    email: {
      regexp: /[\w.+-]+@[\w.-]+\.[a-z]{2,6}/mgi,
      transform: function(email) {
        return [
          '<a data-email="',
          '" data-action="email-link" class="link-focus">',
          '</a>'
        ].join(email);
      }
    }
  };

  let LINK_TYPES_KEYS = Object.keys(LINK_TYPES);

  function searchForLinks(type, string) {
    let linkSpecs = [];
    const spec = LINK_TYPES[type];

    if (!spec) {
      return linkSpecs;
    }

    let regexp = spec.regexp;
    let matchFilter = spec.matchFilter;
    let match, linkSpec;

    // while we match stuff...
    // eslint-disable-next-line no-cond-assign
    while (match = regexp.exec(string)) {
      // if the match isn't at the begining of the string, check for a safe
      // character before the match
      let rest = string.slice(match.index - 1);
      if (match.index && !safeStart.test(rest.charAt(0))) {
        // we should only advance the regexp to the next safeStart
        const nextSafe = safeStart.exec(rest);
        if (nextSafe && (match[0].length > nextSafe.index)) {
          regexp.lastIndex = match.index + nextSafe.index;
          continue;
        }
      }

      // According to the International numbering plan, the number max length is 15.
      // Please refer to https://en.wikipedia.org/wiki/Telephone_numbering_plan.
      if (type === 'phone' && match[0].length > 15) {
        continue;
      }

      // We need delete the not dial front char to make the phone more clear.
      if (type === 'phone' && !notRadioCallChar.test(match[0])) {
        if (!regexpForLink.test(match[0])) {
          match.index ++;
          match[0] = match[0].substring(1);
        }
      }

      linkSpec = {
        type: type,
        start: match.index,
        length: match[0].length,
        end: match.index + match[0].length,
        match: match
      };

      if (matchFilter) {
        linkSpec = matchFilter(match[0], linkSpec);
      }

      if (linkSpec) {
        linkSpecs.push(linkSpec);
        regexp.lastIndex = linkSpec.end;
      }
    }

    return linkSpecs;
  }

  function linkSort(a, b) {
    return (a.start - b.start) ||
           (b.end - a.end) ||
           (LINK_TYPES_KEYS.indexOf(a.type) - LINK_TYPES_KEYS.indexOf(b.type));
  }

  function removeOverlapping(linkSpecs) {
    linkSpecs.sort(linkSort);
    for (let index = 0; index < linkSpecs.length - 1; index++) {
      const end = linkSpecs[index].end;
      while (linkSpecs[index + 1] && linkSpecs[index + 1].start < end) {
        linkSpecs.splice(index + 1, 1);
      }
    }
  }

  let LinkHelper = window.LinkHelper = {
    searchAndLinkUrl: function(inputText) {
      return LinkHelper.searchAndLinkClickableData(inputText, { url: true });
    },
    searchAndLinkEmail: function(inputText) {
      return LinkHelper.searchAndLinkClickableData(inputText, { email: true });
    },
    searchAndLinkPhone: function(inputText) {
      return LinkHelper.searchAndLinkClickableData(inputText, { phone: true });
    },
    searchAndLinkClickableData: function(inputText, mode) {
      mode = mode || LINK_TYPES;
      let linkSpecs = [];
      let type;

      for (type in mode) {
        if (mode[type] && LINK_TYPES[type]) {
          linkSpecs = linkSpecs.concat(searchForLinks(type, inputText));
        }
      }

      removeOverlapping(linkSpecs);

      let result = '';
      let lastEnd = 0;
      if (mode.hasOwnProperty('email') && !Settings.emailAppInstalled) {
        linkSpecs.forEach((value, index) => {
          value['type'] === 'email' && linkSpecs.splice(index, 1);
        });
      }

      linkSpecs.forEach((link) => {
        result += inputText.slice(lastEnd, link.start);
        const replacing = inputText.slice(link.start, link.end);
        result += LINK_TYPES[link.type].transform(replacing, link);
        lastEnd = link.end;
      });

      result += inputText.slice(lastEnd);

      return result;
    }
  };
})();
