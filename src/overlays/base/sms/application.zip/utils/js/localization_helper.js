/* global Utils, TimeUtils */

(function(exports) {
  'use strict';

  function localizeIFrames() {
    const arrayElement = document.querySelectorAll('iframe');
    arrayElement.forEach((iframe) => {
      Utils.setIfreamsTranslateFragment(iframe);
    });
  }

  function localizeDateTime(isTimeFormatChanged) {
    const dateTimeElements = document.querySelectorAll(isTimeFormatChanged ?
      '.l10n-contains-date[data-l10n-date-format12][data-l10n-date-format24]' :
      '.l10n-contains-date'
    );
    dateTimeElements.forEach((element) => {
      if (!element.dataset.l10nDate) {
        return;
      }

      let formatL10nId = element.dataset.l10nDateFormat;
      if (element.dataset.l10nDateFormat12 && element.dataset.l10nDateFormat24) {
        formatL10nId = window.api.hour12 ? element.dataset.l10nDateFormat12 : 
                                           element.dataset.l10nDateFormat24;
      }

      if (!formatL10nId) {
        return;
      }

      const localeData = TimeUtils.date.format.localeFormat(
        new Date(+element.dataset.l10nDate), Utils.translateString(formatL10nId)
      );

      if (element.hasAttribute('data-l10n-id') && element.hasAttribute('data-l10n-args')) {
        let l10nAttrs = Utils.getTranslationFromAtr(element);
        l10nAttrs.args.date = localeData;
        Utils.translateFromAtr(element, l10nAttrs.id, l10nAttrs.args);
      } else {
        element.textContent = localeData;
      }
    });
  }

  function localizePlaceholders() {
    const placeholderElements = document.querySelectorAll('.js-l10n-placeholder');
    placeholderElements.forEach((element) => {
      if (element.tagName === 'INPUT') {
        element.setAttribute('placeholder',
          Utils.translateString(Utils.camelCase(element.id) + '_placeholder'));
      } else {
        element.dataset.placeholder = Utils.translateString(
          Utils.camelCase(element.id) + '_placeholder'
        );
      }
    });
  }

  exports.LocalizationHelper = {
    init: function () {
      Utils.waitL10nState(() => {
        localizeIFrames();
        localizeDateTime();
        localizePlaceholders();
      });

      window.addEventListener('localized', () => {
        localizeIFrames();
        localizeDateTime();
        localizePlaceholders();
      });

      window.addEventListener('timeformatchange', localizeDateTime.bind(null, true));
    }
  };
})(window);
