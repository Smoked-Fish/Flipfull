/* global LazyLoader, LocalizationHelper, SilentSms, ActivityHandler,
          TimeHeaders, ThreadUI, Information, Settings, SearchMessageUI, AttachmentMessageUI, 
          PerformanceTestingHelper, Navigation, SoftkeyManager, ThreadListUI, EventManager,
          App, MessageManager, DialogManager, MessageCacheRestore, EventDispatcher, 
          SessionManager, DeviceCapabilityManager, ICCUtils */
'use strict';

let Startup = {
  // Load these js after render first page.
  _lazyLoadScripts: [
    'http://shared.localhost/js/helper/notification/notification_helper.js',
    'http://shared.localhost/js/utils/blob/settings_url.js',
    'http://shared.localhost/js/utils/common/mime_mapper.js',
    'http://shared.localhost/js/utils/phone/mobile_operator.js',
    'http://shared.localhost/js/utils/media/image_utils.js',
    'http://shared.localhost/js/helper/option_menu/option_menu.js',
    'telephone/js/telephony_helper.js',
    'telephone/js/call_manager.js',
    'utils/js/waiting_screen.js',
    'utils/js/error_dialog.js',
    'utils/js/link_helper.js',
    'utils/js/shared_components.js',
    'utils/js/task_runner.js',
    'utils/js/swich_handler.js',
    'utils/js/wbmp.js',
    'utils/js/localization_helper.js',
    'service/js/errors.js',
    'service/js/silent_sms.js',
    'service/js/send_service.js',
    'service/js/send_normal_manager.js',
    'service/js/retrieve.js',
    'contacts/js/contacts_renderer.js',
    'contacts/js/contacts_normal_utils.js',
    'recipient/js/recipients.js',
    'recipient/js/recipients_manager.js',
    'recipient/js/suggestion_utils.js',
    'attachment/js/attachment.js',
    'attachment/js/attachment_renderer.js',
    'attachment/js/attachment_service.js',
    'attachment/js/attachment_message_ui.js',
    'attachment/js/attachment_manager.js',
    'attachment/js/smil.js',
    'draft/js/draft_utils.js',
    'edit/js/conversation_edit.js',
    'conversation/js/input_utils.js',
    'conversation/js/subject_composer.js',
    'conversation/js/subject_utils.js',
    'conversation/js/suggestion_normal.js',
    'conversation/js/thread_ui.js',
    'conversation/js/compose.js',
    'pages/js/information.js',
    'pages/js/settingsUI.js',
    'pages/js/searchMessageUI.js',
    'activity/js/activity_picker.js',
    'notification/js/notify.js',
    'notification/js/notification_handler.js',
    'notification/js/notification_route.js',
    // Begin by tingting.chao for GF5GTMO-7172 on 2025/04/30
    'dialog/js/input_dialog_helper.js',
    'phoneutils/data.js',
    'phoneutils/mcc_iso3166_table.js',
    'phoneutils/PhoneNumber.js',
    'phoneutils/PhoneNumberNormalizer.js',
    'phoneutils/PhoneNumberUtils.js'
    // End by tingting.chao for GF5GTMO-7172 on 2025/04/30
  ],
  // Load these js after DOM load.
  _cacheLazyLoadScripts: [
    'http://shared.localhost/js/helper/date_time/date_time_helper.js',
    'http://shared.localhost/js/utils/common/template.js',
    'http://shared.localhost/js/helper/common/performance_testing_helper.js',
    'http://shared.localhost/js/utils/storage/async_storage.js',
    'http://shared.localhost/js/helper/dialog/custom_dialog.js',
    'http://shared.localhost/js/utils/toaster/toaster.js',
    'http://shared.localhost/js/utils/common/app_origin.js',
    'utils/js/time_headers.js',
    'utils/js/value_default.js',
    'utils/js/utils.js',
    'utils/js/time_utils.js',
    'utils/js/icc_utils.js',
    'utils/js/app.js',
    'utils/js/cache.js',
    'manager/js/softkey_manager.js',
    'manager/js/focus_state_normal.js',
    'manager/js/focus_manager.js',
    'manager/js/option_manager.js',
    'manager/js/event_manager.js',
    'manager/js/delete_manager.js',
    'contacts/js/contacts.js',
    'contacts/js/contacts_manager.js',
    'draft/js/drafts.js',
    'dialog/js/confirm_dialog_helper.js',
    'dialog/js/dialog_manager.js',
    'edit/js/inbox_edit.js',
    'inbox/js/sticky_header.js',
    'inbox/js/thread_list_ui.js',
    'service/js/state_manager.js',
    'service/js/threads.js',
    'service/js/settings.js',
    'service/js/message_manager.js',
    'route/js/navigation.js',
    'route/js/navigation_handler.js'
  ],
  // API Daemon need be lazy loaded.
  _sessionLazyLoadScripts: [
    'http://shared.localhost/js/session/task_scheduler.js',
    'http://shared.localhost/js/session/lib_session.js',
    'http://shared.localhost/js/session/settings/settings_observer.js',
    'http://shared.localhost/js/session/apps_manager/apps_manager.js',
    'http://shared.localhost/js/session/device_capability/device_capability.js',
    'http://shared.localhost/js/session/contacts_manager/contacts_manager.js',
    'service/js/session_manager.js'
  ],

  // Cache use case.
  useCache: false,
  // Message receive case.
  messageReceive: false,
  // Null Cache case.
  firstDraftCheck: false,
  // Due to service worker time, need record the js loaded event.
  jsAllLoaded: false, 
  // Judge whether it is notification mode.
  isFromNotification: false,

  // Lazy load next level jave script file.
  _lazyLoadInit: function() {
    let lazyLoadPromise = LazyLoader.load(Startup._lazyLoadScripts).then(() => {
      // Translation module init.
      LocalizationHelper.init();
      // Silent service init.
      SilentSms.init();
      // Time format init.
      TimeHeaders.init();
      // Conversation page init. 
      ThreadUI.init();
      // Information page init.
      Information.initDefaultViews();
      // Dispatch post-initialize event for continuing the pending action.
      Startup.emit('post-initialize');
      // Performance mark - contentInteractive. 
      window.performance.mark('contentInteractive');
      window.dispatchEvent(new CustomEvent('moz-content-interactive'));
      // Settings value init.
      Settings.init();
      // Icc card state init.
      ICCUtils.init();
      // Search page init.
      SearchMessageUI.init();
      // Attachment page init.
      AttachmentMessageUI.init();
      // Performance mark - objectsInitEnd.
      window.performance.mark('objectsInitEnd');
      PerformanceTestingHelper.dispatch('objects-init-finished');
    });
    Startup.initHeaders();
    return lazyLoadPromise;
  },

  // Reset the header format.
  initHeaders: function() {
    const headers = document.querySelectorAll('.view-header');
    for (let i = 0, l = headers.length; i < l; i++) {
      headers[i].removeAttribute('no-font-fit');
    }
  },

  // Base init.
  init: function() {
    function initializeDefaultPanel(firstPageLoadedCallback) {
      Navigation.off('navigated', initializeDefaultPanel);
      window.dispatchEvent(new CustomEvent('moz-app-cache-complete'));
      // Softkey module init.
      SoftkeyManager.init();
      // List page module init.
      ThreadListUI.init();
      // Get group capability value first.
      DeviceCapabilityManager.get('device.group-message').then((hasGroup) => {
        Settings.hasGroup = hasGroup;
        // Render list completely.
        ThreadListUI.renderThreads(firstPageLoadedCallback).then(() => {
          // All list load flag.
          window.performance.mark('fullyLoaded');
          window.dispatchEvent(new CustomEvent('moz-app-loaded'));
          App.setReady();
          Startup.useCache = false;
        });
      });
    }

    function cacheLazyload(callback) {
      LazyLoader.load(Startup._cacheLazyLoadScripts).then(() => {
        callback();
      });
    }

    function sessionLazyload(callback) {
      LazyLoader.load(Startup._sessionLazyLoadScripts).then(() => {
        callback();
      });
    }

    let loaded = function() {
      window.removeEventListener('DOMContentLoaded', loaded);
      window.performance.mark('navigationLoaded');
      window.dispatchEvent(new CustomEvent('moz-chrome-dom-loaded'));
      // Reset div input box logic to firfox version below gecko 60.
      document.execCommand('defaultParagraphSeparator', false, 'br');
      window.performance.mark('visuallyLoaded');

      const launchTimeOut = 200;
      setTimeout(() => {
        sessionLazyload(() => {
          SessionManager.initSession().then(() => {
            window.dispatchEvent(new CustomEvent('moz-app-visually-complete'));
            cacheLazyload(() => {
              window.addEventListener('mapLoaded', function navigationMapLoaded() {
                window.removeEventListener('mapLoaded', navigationMapLoaded);
                // Event handler init.
                EventManager.init();
                // Protocol manager module init.
                MessageManager.init();
                // Route module init.
                Navigation.init();
                // Dialog module init.
                DialogManager.init();
                // All js loaded.
                Startup.jsAllLoaded = true;
                window.dispatchEvent(new CustomEvent('js-all-loaded'));
                if (Navigation.isDefaultPanel()) {
                  Navigation.toDefaultPanel();
                  initializeDefaultPanel(Startup._lazyLoadInit);
                }

                window.performance.mark('navigationInteractive');
                window.dispatchEvent(new CustomEvent('moz-chrome-interactive'));
              });
            });
          });
        });
      }, launchTimeOut);
    }.bind(this);

    // Add cache page.
    MessageCacheRestore.hydrateHtml('threads-container');
    window.addEventListener('DOMContentLoaded', loaded);
  }
};

// Activity module init
ActivityHandler.init();

EventDispatcher.mixin(Startup).init();
