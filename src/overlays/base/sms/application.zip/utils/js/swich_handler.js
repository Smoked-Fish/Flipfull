/* global ThreadListUI, Compose, ThreadUI, Threads, Navigation, DraftUtils, 
          DialogManager, ConversationEdit, ValueDefault, SubjectUtils,
          OptionManager, RecipientManager */

'use strict';

// eslint-disable-next-line no-unused-vars
let SwitchHandler = {
  isSwitchCase: false,

  switchPreviousThread: function() {
    const priviousElement = ThreadListUI.privateMembersSwitch();
    this._switchPrevNextThread(-priviousElement);
  },

  switchNextThread: function() {
    const priviousElement = ThreadListUI.privateMembersSwitch();
    this._switchPrevNextThread(+priviousElement);
  },

  _switchPrevNextThread: function(shift) {
    if (!Compose.isEmpty() ||
        (!!RecipientManager.recipients && RecipientManager.recipients.length !== 0)) {
      if (DraftUtils.draft && !DraftUtils.draft.isEdited) {
        DraftUtils.saveDraft({ keyFlag: 'saveDraft', autoSave: true }, () => {
          this.switchThreadPage(shift);
        });
      } else {
        DraftUtils.saveDraft({ keyFlag: 'saveDraft' }, () => {
          this.switchThreadPage(shift);
        });
      }
    } else {
      DraftUtils.discardDraft();
      this.switchThreadPage(shift);
    }
  },

  switchThreadPage: function(shift) {
    const currentId = Threads.currentId;
    let threads = [];
    let threadsTime = [];

    Threads.forEach((v, k) => {
      threadsTime.push(v.timestamp);
      threads.push(k);
    });
    
    if (threadsTime.length > 1 && threadsTime[0] - threadsTime[1] < 0) {
      threads = threads.reverse();
    }
    this.isSwitchCase = true;
    const destId = threads[ (threads.indexOf( currentId ) + shift +
                            threads.length) % threads.length ];
    ThreadUI.threadIdBackUp = destId;
    Navigation.toPanel('thread', { id: destId });
  },

  switchThreadSelection: function(callback) {
    if (DraftUtils.draft && !DraftUtils.draft.isEdited) {
      callback();
      return;
    }
    function acceptCallback() {
      callback();
    }
    function confirmCallback() {
      DraftUtils.discardDraft();
      Compose.clear();
      callback();
    }
    DialogManager.confirmAlert('confirmation-title', 'draft-save-content',
                               'cancel', null, 'save-as-draft', acceptCallback,
                               'discard-message', confirmCallback);
  },

  canSwitchBetweenThreads: function() {
    return (
      // Only thread page can switch.
      Navigation.isCurrentPanel('thread') &&
      // Edit mode can not switch.
      !ConversationEdit.isInEditMode() && 
      // Attachment mode can not switch.
      !ValueDefault.isAttachmentPage && (
        // Focus must be at bubble.
        (!Compose.isFocused() && !SubjectUtils.isSubjectFocused() && 
         document.activeElement.tagName === 'LI') &&
        // Not have dialog or option menu.
        !window.option.menuVisible && !DialogManager.isDialogShown() && 
        !OptionManager.contactPromptOptionMenuShown && 
        // Thread page count is over one page.
        (Threads.size > 1)));
  }
};
