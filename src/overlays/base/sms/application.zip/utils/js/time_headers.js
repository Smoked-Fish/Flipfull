/* global TimeUtils */

(function(exports) {
  'use strict';

  exports.TimeHeaders = {
    updateTimer: null,
    // Init time header change.
    init: function() {
      this.visibilityHandle();
    },

    startScheduler: function() {
      const now = Date.now();
      // Set next timer time.
      let nextTimeout = new Date(now + 60000);
      nextTimeout.setSeconds(0);
      nextTimeout.setMilliseconds(0);
      // stop updateTimer first
      this.stopScheduler();
      // then register a new one
      this.updateTimer = setTimeout(() => {
        this.updateAll('header[data-time-update=repeat]');
        this.startScheduler();
      }, nextTimeout.getTime() - now);
    },

    stopScheduler: function() {
      clearTimeout(this.updateTimer);
    },

    updateAll: function(selector) {
      selector = selector || '[data-time-update]';
      const elements = document.querySelectorAll(selector),
            length = elements.length;
      let i;
      for (i = 0; i < length; i++) {
        this.update(elements[i]);
      }
    },

    update: function(element) {
      const ts = element.dataset.time;
      if (!ts) {
        return;
      }

      TimeUtils.initDateTime(ts);

      let newElement;
      // only date
      if (element.dataset.dateOnly === 'true') {
        newElement = TimeUtils.getHeaderDate();
      // only time
      } else if (element.dataset.timeOnly === 'true') {
        newElement = TimeUtils.getFormattedHour();
      // date + time
      } else {
        newElement = TimeUtils.getCompleteHeaderDate();
      }
      if (newElement !== element.textContent) {
        element.textContent = newElement;
      }
    },

    visibilityHandle: function() {
      if (document.hidden) {
        this.stopScheduler();
      }
      else {
        this.updateAll();
        this.startScheduler();
      }
    }
  };
}(this));
