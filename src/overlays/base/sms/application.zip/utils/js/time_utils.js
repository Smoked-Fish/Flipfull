/* global Utils */

'use strict';

let TimeUtils = {
  // Each time format.
  date: {
    shared: new Date(),
    get format() {
      delete TimeUtils.date.format;
      return (TimeUtils.date.format = new window.api.l10n.DateTimeFormat());
    }
  },

  // Get current time element.
  initDateTime: function(time) {
    const unitConvert = 86400000;
    const today = TimeUtils.getDayDate(Date.now());
    const otherDay = TimeUtils.getDayDate(time);
    this.dayDiff = (today - otherDay) / unitConvert;
    this.yearDiff = TimeUtils.getDayYearDiff(time, Date.now());
    this.date.shared.setTime(+time);
    this.dateLanguage = navigator.language;
  },

  // List header time show rules.
  getHeaderDate: function() {
    const weekLength = 7;
    // List header time show map.
    // Rules example:
    // Today - Sat, August 10 - Wed, Dec 25, 2015 - Thu, Nov 4, 2014.
    const timeHeaderOption = {
      'thisWeek': { weekday: 'long' },
      'lastWeek': { weekday: 'short', month: 'long', day: 'numeric' },
      'lastYear': { weekday: 'short', year: 'numeric', month: 'short',
                    day: 'numeric' },
      'beforeYear': { weekday: 'short', year: 'numeric', month: 'short',
                      day: 'numeric' }
    };
    const date = this.date.shared;
    // No day diff, show error time description.
    if (isNaN(this.dayDiff)) {
      return Utils.translateString('incorrectDate');
    }
    // Future time.
    if (this.dayDiff < 0) {
      return date.toLocaleString(this.dateLanguage, timeHeaderOption.lastYear);
    }
    // return time format by daydiff and yeardiff.
    if (this.dayDiff === 0) {
      return Utils.translateString('today');
    } else if (this.dayDiff === 1) {
      return Utils.translateString('yesterday');
    } else if (this.dayDiff < weekLength) {
      return date.toLocaleString(this.dateLanguage, timeHeaderOption.thisWeek);
    } else if (this.yearDiff < 1) {
      return date.toLocaleString(this.dateLanguage, timeHeaderOption.lastWeek);
    } else if (this.yearDiff === 1) {
      return date.toLocaleString(this.dateLanguage, timeHeaderOption.lastYear);
    } else {
      return date.toLocaleString(this.dateLanguage, timeHeaderOption.beforeYear);
    }
  },

  // Bubble header time show rules.
  getCompleteHeaderDate: function() {
    const weekLength = 7;
    // Bubble header time show map.
    // Rules example:
    // 5:30 PM - Monday 10:30 AM - Sat, August 10, 2:00 PM - 
    // Wed, Dec 25, 2015, 2:00 PM - Thu, Nov 4, 2014, 2:00 PM.
    const timeStampOption = {
      'thisWeek': { weekday: 'long', hour: 'numeric', minute: 'numeric' },
      'lastWeek': { weekday: 'short', month: 'long', day: 'numeric',
                    hour: 'numeric', minute: 'numeric' },
      'lastYear': { year: 'numeric', month: 'short', day: 'numeric',
                    weekday: 'short', hour: 'numeric', minute: 'numeric' },
      'beforeYear': { weekday: 'short', year: 'numeric', month: 'short',
                      day: 'numeric', hour: 'numeric', minute: 'numeric' }
    };
    const specialTimeOption = { hour: 'numeric', minute: 'numeric' };
    // 12 hour or 24 hour format.
    if (window.api.hour12) {
      [timeStampOption.thisWeek.hour12, timeStampOption.lastWeek.hour12,
       timeStampOption.lastYear.hour12, timeStampOption.beforeYear.hour12,
       specialTimeOption.hour12] = [true, true, true, true, true];
    } else {
      [timeStampOption.thisWeek.hour12, timeStampOption.lastWeek.hour12,
       timeStampOption.lastYear.hour12, timeStampOption.beforeYear.hour12,
       specialTimeOption.hour12] = [false, false, false, false, false];
    }

    const date = this.date.shared;
    // No day diff, show error time description.
    if (isNaN(this.dayDiff)) {
      return Utils.translateString('incorrectDate');
    }
    // Future time.
    if (this.dayDiff < 0) {
      return date.toLocaleString(this.dateLanguage, timeStampOption.lastYear);
    }
    // return time format by daydiff and yeardiff.
    if (this.dayDiff === 0) {
      const todayFormat = Utils.translateString('today') + ' ' + 
                          date.toLocaleString(this.dateLanguage, specialTimeOption);
      return todayFormat;
    } else if (this.dayDiff === 1) {
      const yesterdayFormat = Utils.translateString('yesterday') + ' ' + 
                              date.toLocaleString(this.dateLanguage, specialTimeOption);
      return yesterdayFormat;
    } else if (this.dayDiff < weekLength) {
      return date.toLocaleString(this.dateLanguage, timeStampOption.thisWeek);
    } else if (this.yearDiff < 1) {
      return date.toLocaleString(this.dateLanguage, timeStampOption.lastWeek);
    } else if (this.yearDiff === 1) {
      return date.toLocaleString(this.dateLanguage, timeStampOption.lastYear);
    } else {
      return date.toLocaleString(this.dateLanguage, timeStampOption.beforeYear);
    }
  },

  // Message detail time show rules.
  getInformationDate: function() {
    // Message detail time show map.
    // Rules example:
    // June 4, 1976, 2:30 PM.
    const informationOption = {
      year: 'numeric', month: 'long', day: 'numeric',
      hour: 'numeric', minute: 'numeric'
    };
    // 12 hour or 24 hour format.
    if (window.api.hour12) {
      informationOption.hour12 = true;
    } else {
      informationOption.hour12 = false;
    }

    const date = this.date.shared;
    // No day diff, show error time description.
    if (isNaN(this.dayDiff)) {
      return Utils.translateString('incorrectDate');
    }

    return date.toLocaleString(this.dateLanguage, informationOption);
  },

  // Only time format rules.
  getFormattedHour: function() {
    return this.date.format.localeFormat(
      this.date.shared,
      Utils.translateString(window.api.hour12 ? 'shortTimeFormat12' : 
                                                'shortTimeFormat24')
    );
  },

  // Get date object.
  getDayDate: function(time) {
    this.date.shared.setTime(+time);
    this.date.shared.setHours(0, 0, 0, 0);
    return this.date.shared.getTime();
  },

  // Get year diff for current time.
  getDayYearDiff: function(messageTime, currentTime) {
    let date = new Date();
    let yearDiff = 0;
    date.setTime(+messageTime);
    yearDiff = date.getFullYear() - yearDiff;
    date.setTime(+currentTime);
    yearDiff = date.getFullYear() - yearDiff;
    return yearDiff;
  }
};
