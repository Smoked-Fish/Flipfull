/* eslint-disable no-useless-escape */
/* eslint-disable optimize-regex/optimize-regex */
/* global Settings, OptionManager, DialogManager, Contacts, ThreadUI, 
          ContactsServiceManager, MessageManager, SMIL, Toaster, DraftUtils,
          SettingsObserver, DeviceCapabilityManager, WebActivity, ValueDefault */

(function(exports) {
  'use strict';
  const rdashes = /-(.)/g;
  const rescape = /[.?*+^$[\]\\(){}|-]/g;
  const rparams = /([^?=&]+)(?:=([^&]*))?/g;
  const rnondialablechars = /[^,#+\*\d]/g;
  const rmail = /[\w-]+@[\w\-]/;
  //TaskGF5GTMO-3580-porting from Defect10730943-tingting.chao on 24/08/22-begin
  const reBeginCard = /begin:vcard$/i;
  const reEndCard = /end:vcard$/i;
  const reVersion = /^VERSION:([\d\.]*)/i;
  const ReBasic = /^([^:]+):(.+)$/;
  const ReTuple = /([a-zA-Z]+)=(.+)/;
  const qpRegexp = /=([a-zA-Z0-9]{2})/g;
  const WHITE_SPACE = ' ';
  const NAME_PARTS = [
      'familyName',
      'givenName',
      'additionalName',
      'honorificPrefix',
      'honorificSuffix'
  ];
  //TaskGF5GTMO-3580-porting from Defect10730943-tingting.chao on 24/08/22-end

  const l10nInterface = window.api.l10n;

  let Utils = {
    // Event logger flag.
    eventSent: false,

    // Match no safe strings.
    escapeRegex: function(str) {
      if (typeof str !== 'string') {
        return '';
      }
      return str.replace(rescape, '\\$&');
    },

    // Match normal number.
    isNormalNumber: function(string) {
      const rnumber = /^-?\d+$/;
      return rnumber.test(string);
    },

    // Match the number detail from input value.
    getPhoneDetails: function(input, tels) {
      const length = tels.length;
      let hasUniqueCarriers = true;
      let hasUniqueTypes = true;
      let found, tel, type, carrier;

      for (let i = 0; i < length; i++) {
        tel = tels[i];

        if (tel.value && this.probablyMatches(tel.value, input)) {
          found = tel;
        }

        if (carrier && carrier === tel.carrier) {
          hasUniqueCarriers = false;
        }

        if (type && type === tel.type[0]) {
          hasUniqueTypes = false;
        }

        carrier = tel.carrier;
        type = (tel.type && tel.type[0]) || '';
      }

      if (!found) {
        return null;
      }

      return {
        type: (found.type && found.type[0]) || null,
        carrier: hasUniqueCarriers || hasUniqueTypes ? found.carrier : null,
        number: found.value
      };
    },

    probablyMatches: function(a, b) {
      let service = navigator.mozPhoneNumberService;

      // String comparison starts here.
      if (typeof a !== 'string' || typeof b !== 'string') {
        return false;
      }

      if (Settings.supportEmailRecipient &&
          this.isEmailAddress(a) &&
          this.isEmailAddress(b)) {
        return a === b;
      }

      if (service && service.normalize) {
        a = service.normalize(a);
        b = service.normalize(b);
      } else {
        a = this.removeNonDialables(a);
        b = this.removeNonDialables(b);
      }

      return a === b || a.slice(-7) === b.slice(-7);
    },

    // Remove not need string for phone number.
    removeNonDialables: function(input) {
      return input.replace(rnondialablechars, '');
    },

    // Img blob resize function map.
    getResizedImgBlob: function(blob, limit, callback) {
      const defaultLimit = 295 * 1024;
      if (typeof limit === 'function') {
        callback = limit;
        limit = defaultLimit;
      }
      limit = limit === 0 ? defaultLimit : Math.min(limit, defaultLimit);

      if (blob.size < limit) {
        setTimeout(() => {
          callback(blob);
        });
        return;
      }

      const ratio = Math.sqrt(blob.size / limit);
      this.resizeImageBlobWithRatio({
        blob: blob,
        limit: limit,
        ratio: ratio,
        callback: callback
      });
    },

    resizeImageBlobWithRatio: function(obj) {
      const blob = obj.blob,
            callback = obj.callback,
            limit = obj.limit;
      const qualities = [0.65, 0.5, 0.25];
      let ratio = Math.ceil(obj.ratio);
      let sampleSize = 1;
      let sampleSizeHash = '';

      // Not need resize if size is bellow limit.
      if (blob.size < limit || ratio <= 1) {
        setTimeout(() => {
          callback(blob);
        });
        return;
      }

      // Only image can be resized.
      if (blob.type === 'image/jpeg') {
        if (ratio >= 8) {
          sampleSize = 8;
        } else {
          sampleSize = ratio = this.getClosestSampleSize(ratio);
        }

        sampleSizeHash = '#-moz-samplesize=' + sampleSize;
      }

      let img = document.createElement('img');
      const url = window.URL.createObjectURL(blob);
      img.src = url + sampleSizeHash;

      img.onload = () => {
        window.URL.revokeObjectURL(url);
        const targetWidth = img.width * sampleSize / ratio;
        const targetHeight = img.height * sampleSize / ratio;

        let canvas = document.createElement('canvas');
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        let context = canvas.getContext('2d', { willReadFrequently: true });

        context.drawImage(img, 0, 0, targetWidth, targetHeight);
        img.src = '';
        let level = 0;

        function cleanup() {
          canvas.width = canvas.height = 0;
          canvas = null;
        }

        function ensureSizeLimit(resizedBlob) {
          if (resizedBlob.size < limit) {
            cleanup();
            setTimeout(callback.bind(null, resizedBlob));
          } else {
            resizedBlob = null;
            if (level < qualities.length) {
              canvas.toBlob(ensureSizeLimit, 'image/jpeg', qualities[level++]);
            } else {
              cleanup();
              setTimeout(
                Utils.resizeImageBlobWithRatio.bind(Utils, {
                  blob: blob,
                  limit: limit,
                  ratio: ratio * 2,
                  callback: callback
                })
              );
            }
          }
        }

        canvas.toBlob(ensureSizeLimit, blob.type);
      };
    },

    getClosestSampleSize: function(ratio) {
      if (ratio >= 8) {
        return 8;
      }
      if (ratio >= 4) {
        return 4;
      }
      if (ratio >= 2) {
        return 2;
      }
      return 1;
    },

    generateSmilSlides: function(slides, content) {
      const length = slides.length;
      if (typeof content === 'string') {
        if (!length || slides[length - 1].text) {
          slides.push({ text: content });
        } else {
          slides[length - 1].text = content;
        }
      } else {
        slides.push({ blob: content.blob, name: content.name });
      }
      return slides;
    },

    // Attachment limit size exceed select.
    getSizeForL10n: function(size) {
      // Blob size with unit (B or KB or MB).
      const sizeKB = size / 1024;
      const sizeMB = sizeKB / 1024;
      if (size < 1000) {
        return {
          l10nId: 'attachmentSizeB',
          l10nArgs: { n: size }
        };
      } else if (sizeKB < 1000) {
        return {
          l10nId: 'attachmentSizeKB',
          l10nArgs: { n: sizeKB.toFixed(1) }
        };
      }
      return {
        l10nId: 'attachmentSizeMB',
        l10nArgs: { n: sizeMB.toFixed(1) }
      };
    },

    // Get the mine type from attachment.
    typeFromMimeType: function(mime) {
      const MAX_MIME_TYPE_LENGTH = 256;
      if (typeof mime !== 'string' || mime.length > MAX_MIME_TYPE_LENGTH) {
        return null;
      }

      const index = mime.indexOf('/');
      if (index === -1) {
        return null;
      }
      const mainPart = mime.slice(0, index);
      const secondPart = mime.substr(index + 1).toLowerCase();

      switch (mainPart) {
        case 'image':
          return 'img';
        case 'text':
          if(secondPart.indexOf('vcard') !== -1) {
            return 'vcard';
          }
          if (secondPart !== 'plain') {
            return 'ref';
          }
          return mainPart;
        case 'video':
        case 'audio':
        case 'application':
          return mainPart;
        default:
          return null;
      }
    },

    // Common function map.
    camelCase: function(str) {
      return str.replace(rdashes, (str, p1) => {
        return p1.toUpperCase();
      });
    },

    params: function(input) {
      let parsed = {};
      input.replace(rparams, ($0, $1, $2) => {
        parsed[$1] = $2;
      });
      return parsed;
    },

    isEmailAddress: function(email) {
      const extraEmail = email.indexOf(' ') === -1;
      return rmail.test(email) && extraEmail;
    },

    debounce: function(func, waitTime) {
      let timeout, args, context;

      const executeLater = () => {
        func.apply(context, args);
        timeout = context = args = null;
      };

      return function() {
        context = this;
        args = arguments;

        if (timeout) {
          clearTimeout(timeout);
        }

        timeout = setTimeout(executeLater, waitTime);
      };
    },

    speedPressPrevent: function(callback) {
      if (OptionManager.isOptionMenuShown()) {
        OptionManager.hideOptionMenu();
      }
      window.addEventListener('transitionend', function optionDelete() {
        window.removeEventListener('transitionend', optionDelete);
        callback();
      });
    },

    getParents: function(node, tagName) {
      // It is impossible to transfer body elemet here, 
      // so need change the node to focus node.
      if (node.tagName === 'BODY') {
        node = document.querySelector('.focus');
      }
      const parent = node.parentNode;
      const tag = tagName.toUpperCase();
      if (parent.tagName === tag) {
        return parent;
      } else if (parent.tagName === 'BODY') {
        return document.body;
      } else {
        return this.getParents(parent, tag);
      }
    },

    getAChildFromMessage: function(node) {
      const secondFocusElement = 
        node.getElementsByClassName('message-content-body')[0];
      return (secondFocusElement.querySelectorAll('.link-focus').length !== 0);
    },

    getItemIndex: function(elements, id) {
      let index;
      const length = elements.length;
      for (let i = 0; i < length; i++) {
        if (elements[i].id === id) {
          index = i;
          break;
        }
      }
      return index;
    },

    handleActivity: function(detailName, detailData, onsuccess, onerror) {
      new WebActivity(detailName, detailData).start().then((result) => {
        console.log('activity added successfully, data is :: ' + JSON.stringify(result));
        onsuccess && onsuccess(result);
      }).catch((error) => {
        console.warn('Unhandled error spawning activity; ' + error.message);
        onerror && onerror(error);
      });
    },

    // Group SIM card judge (for DSDS) function map.
    judgeNumberSituation: function(serviceId, callback, cancelCallBack) {
      // Protection code to prevent error.
      if (!serviceId) {
        serviceId = 0;
      }

      const needShow = this.needShowInputNumber(serviceId);
      let simFlag;

      if (needShow) {
        simFlag = serviceId === 0 ? 'sim1' : 'sim2';
        DialogManager.inputDialogShow('group-message', '', 'input-alert-reInput',
                                      simFlag, (number) => {
          // Need wait for the settings value updated.
          const settingsName = serviceId === 0 ? 'ril.mms.phoneNumber.sim1' : 
                                                 'ril.mms.phoneNumber.sim2';
          this.observerSettingsValue(settingsName, (value) =>{
            if (value) {
              // After number inputted, send message immediately.
              callback();
            }
          });

          // Only consider two SIM at base now.
          if (serviceId === 0) {
            this.setSettingsValue([{
              name: 'ril.mms.phoneNumber.sim1',
              value: number
            }]);
            Settings.fakeSIMNumberArray[0] = number;
          } else {
            this.setSettingsValue([{
              name: 'ril.mms.phoneNumber.sim2',
              value: number
            }]);
            Settings.fakeSIMNumberArray[1] = number;
          }
        }, () => {
          cancelCallBack && cancelCallBack();
        }, () => {
          cancelCallBack && cancelCallBack();
        });
      } else {
        callback();
      }
    },

    needShowInputNumber: function(serviceId) {
      // Only when have SIM && SIM number not read && fake number is null,
      // show input box.
      return (Settings.originalSIMInfoArray[serviceId] &&
              !Settings.originalSIMNumberArray[serviceId] &&
              !Settings.fakeSIMNumberArray[serviceId]);
    },

    // Settings value common module.
    setSettingsValue: function(settingsGroup) {
      SettingsObserver.setValue(settingsGroup);
    },

    getSettingsValue: function(settingsValue) {
      return new Promise(function(resolver) {
        SettingsObserver.getValue(settingsValue).then((result) => {
          const settingsResult = result || null;
          resolver(settingsResult);
        });
      });
    },

    observerSettingsValue: function(settingsValue, callback) {
      SettingsObserver.observe(settingsValue, null, (value, name) => {
        if (name === settingsValue) {
          callback(value);
        }
      });
    },

    // Activity auto draft module.
    saveActivityDraft: function() {
      // Prevent activity draft extra save.
      if (!ValueDefault.activitymode || DraftUtils.activityDraft) {
        return;
      }

      DraftUtils.saveActivityDraft(() => {
        const saveTime = Date.now();
        Utils.setSettingsValue([{ 
          name: 'sms.draft.save.time', 
          value: saveTime
        }]);
      });
    },

    discardActivityDraft: function() {
      if (!ValueDefault.activitymode) {
        return;
      }

      DraftUtils.discardActivityDraft();
      Utils.setSettingsValue([{ 
        name: 'sms.draft.save.time', 
        value: null
      }]);
    },

    /* Send the event to the event_logger_module, the caught events are:
     * 1. When send a SMS, need save log.
     * 2. When open a SMS, need save log.
     */
    sendEventLogs: function(numbers, type = 'no_event') {
      const DATASTORE_NAME = 'eventlogger-event';
      let is_psms = 0;
      this.eventSent = false;

      // No event logger sent case.
      if (type === 'no_event') {
        this.eventSent = true;
        return;
      }

      this.findContactInArray(numbers).then((param) => {
        let options = {};
        if (type === 'sms_send') {
          options = {
            event_type: type,
            data: {
              is_contact: param[0],
              is_dial: param[1],
              is_psms: is_psms
            }
          };
        }

        if (type === 'sms_open') {
          options = {
            event_type: type,
            data: {
              is_contact: param[0]
            }
          };
        }

        return new Promise((resolve) => {
          this.handleActivity(DATASTORE_NAME, options, () => {
            this.eventSent = true;
            window.dispatchEvent(new CustomEvent('event-logger-sent'));
            resolve();
          }, (err) => {
            this.eventSent = true;
            window.dispatchEvent(new CustomEvent('event-logger-sent'));
            console.error(`Send event log with error: ${err}`);
          });
        });
      });
    },

    findContactInArray: function(numbers) {
      let is_contact = 0;
      let is_dial = 0;
      let count = 0;

      if (!Array.isArray(numbers)) {
        numbers = [numbers];
      }

      return new Promise((resolve) => {
        numbers.forEach((number) => {
          Contacts.findByAddress(number, (result) => {
            count++;
            // There is one situation we can not get,
            // if the user input a contact number, it is difficult to confirm
            // the number is manually input or not, so we only use a sample
            // logic here.
            // The contact number or email is not input manually.
            if (result && result.length > 0) {
              is_contact = 1;
            } else {
              if (ValueDefault.activitymode || ThreadUI.isManualInput) {
                is_dial = 1;
              }
            }

            if (count === numbers.length) {
              resolve([is_contact, is_dial]);
            }
          });
        });
      });
    },

    // Extra function map (now is not available)
    creationModeCheck: function(file, isForward) {
      const blob = file.blob;
      // Please refer to MMS protocol OMA-MMS-CONF-V1_2-20050301-A Chapter 7 table 1.
      // The useful format is as followed:
      // - format       - size  -    text   -  image   -  audio   -  video   -  Pim  -
      // -  text        - 30KB  -  US-ASCII    N/A        N/A        N/A        N/A
      //                           UTF-8,
      //                           UTF-16
      //
      // - image basic  - 30KB  -  same as  -  JPEG    -  AMR-NB  -  N/A     -  vCard
      //                           text        GIF87a     13K                   vCalendar
      //                                       GIF89a
      //                                       WBMP
      // - image rich   - 100KB -  same as  -  same as -  AMR-NB  -  N/A     -  same as
      //                           text        basic      13K                   basic
      //                                                  SP-MIDI
      // - video basic  - 100KB -  same as  -  same as -  same as -  3GPP    -  same as
      //                           text        basic      rich       3GPP2      basic
      // - video rich   - 300KB -  same as  -  same as -  same as -  same as -  same as
      //                           text        basic      rich       basic      basic
      const limitSizeMap = {
        text: 30 * 1024,
        imgBasic: 30 * 1024,
        imgRich: 100 * 1024,
        videoBasic: 100 * 1024,
        videoRich: 300 * 1024
      };
      const limitTypeMap = {
        text: ['text/vcard', 'text/x-vcard'],
        image: ['image/jpeg', 'image/gif', 'image/wbmp'],
        audio: ['audio/amr', 'audio/x-midi'],
        video: ['video/3gpp', 'video/3gpp2']
      };

      const blobTypeArray = blob.type.split('/');
      let needLimit = limitTypeMap[blobTypeArray[0]].indexOf(blob.type) === -1;
      if (blobTypeArray[0] === 'text' && blob.size > limitSizeMap.text) {
        needLimit = true;
      } else if ((blobTypeArray[0] === 'audio' || blobTypeArray[0] === 'video') &&
                 blob.size > limitSizeMap.videoRich) {
        needLimit = true;
      } else if (isForward && blobTypeArray[0] === 'image' &&
                 blob.size > limitSizeMap.imgRich) {
        needLimit = true;
      }

      return needLimit;
    },

    operatorCreationMode: function(needLimit, callback) {
      // Please refer the MMS protocol OMA-MMS-CONF-V1_2-20050301-A Chapter 12.
      //  - Creation mode RESTRICTED.
      //      In this mode, a terminal SHALL only create and submit MMs belonging
      //    to the Core MM Content Domain.
      //  - Creation mode WARNING.
      //      In this mode, a terminal SHALL guide the user to create and submit
      //    only MMs belonging to the Core MM Content Domain. This guidance may,
      //    for instance, be implemented as warnings to the user. If the user
      //    chooses to create and submit an MM that is conformant with the
      //    Core MM Content Domain, the MM shall be conformant with the
      //    Core MM Content Domain. The form of the guidance and choice is not specified.
      //  - Creation mode FREE.
      //      In this mode, a terminal MAY allow the user to add any content to the MM.
      const creationMode = Settings.creationMode;
      switch (creationMode) {
        case 'restricted':
          if (needLimit) {
            DialogManager.confirmAlert('creationMode_restricted_title',
                                       'creationMode_restricted_alert', 
                                       null, null, 'ok', null, null, null, null);
            callback(true);
          } else {
            callback(false);
          }
          break;
        case 'warning':
          if (needLimit) {
            DialogManager.confirmAlert('creationMode_warning_title',
                                       'creationMode_warning_alert',
                                       'cancel', () => {
              callback(true);
            }, null, null, 'confirm-dialog-ok', () => {
              callback(false);
            }, () => {
              callback(true);
            });
          } else {
            callback(false);
          }
          break;
        case 'free':
          callback(false);
          break;
        default:
          callback(false);
          break;
      }
    },

    canSendWhenParentControl: function(numbers) {
      return new Promise((resolveAll) => { 
        DeviceCapabilityManager.get('device.parental-control').then(
          (controlEnabled) => {
          if (controlEnabled) {
            let asyncTask = [];
            for (let i = 0; i < numbers.length; i++) {
              let newTask = () => new Promise((resolve) => {
                Contacts.findByPhoneNumber(numbers[i], (result) => {
                  if (result) {
                    ContactsServiceManager.findBlockNumbers(numbers[i]).then((blockList) => {
                      // If support parent control feature and contact number
                      // in block list, should prevent send action.
                      if (blockList && blockList.length !== 0) {
                        resolve(false);
                      } else {
                        resolve(true);
                      }
                    });
                  } else {
                    // If support parent control feature and number not contact,
                    // should prevent send action.
                    resolve(false);
                  }
                });
              });
              asyncTask.push(newTask());
            }

            Promise.all(asyncTask).then((values) => {
              let lastValue = true;
              for (let i = 0; i < values.length; i++) {
                lastValue = lastValue && values[i];
              }
              resolveAll(lastValue);
            });
          } else {
            // If not support parent control feature, we must send message.
            resolveAll(true);
          }
        });
      });
    },

    // Get body content from forward.
    findBodyContent: function(messageId, callback) {
      let needLimit = false;
      const request = MessageManager.getMessage(+messageId);
      request.onsuccess = () => {
        let message = request.result;
        if (message.type === 'sms') {
          callback(needLimit);
        } else {
          SMIL.parse(message, (elements) => {
            elements.forEach((element) => {
              if (element.blob) {
                let checkLimitResult = this.creationModeCheck(element, true);
                needLimit = needLimit || checkLimitResult;
              }
            });
            callback(needLimit);
          });
        }
      };
    },

    // L10n action map.
    translateString: function(id) {
      return l10nInterface.get(id);
    },

    translateFromAtr: function(element, string, args) {
      l10nInterface.setAttributes(element, string, args);
    },

    getTranslationFromAtr: function(element) {
      return l10nInterface.getAttributes(element);
    },

    translateFragment: function(doc) {
      l10nInterface.translateFragment(doc);
    },

    setIfreamsTranslateFragment: function(iframe) {
      const doc = iframe.contentDocument;
      doc.documentElement.lang = l10nInterface.language.code;
      doc.documentElement.dir = l10nInterface.language.direction;
      this.translateFragment(doc.body);
    },

    getL10nState: function() {
      return l10nInterface.readyState;
    },

    waitL10nState: function(callback) {
      l10nInterface.once(() => {
        callback();
      });
    },

    // Common toaster shown function.
    showToaster: function(args) {
      Toaster.showToast(args);
    },

    // Toaster shown for low spece.
    showLowSpaceAlert: function() {
      this.showToaster({ messageL10nId: 'space-low-not-save' });
    },

    // Toaster shown for MMS recipient limit exceed.
    showMMSLimitAlert: function() {
      this.showToaster({ messageL10nId: 'limit-MMS-recipients' });
    },

    // Last line judge.
    isLastLine: function(range) {
      const len = document.activeElement.childNodes.length;
      if (range.startContainer.nodeName === '#text' && len > 1 &&
          range.startOffset === document.activeElement.childNodes[len - 2].nodeValue.length) {
        return true;
      } else if (range.startContainer.nodeName === 'DIV' &&
                 range.startOffset === document.activeElement.childNodes.length - 1) {
        return true;
      }
      return false;
    },

    //TaskGF5GTMO-3580-porting from Defect10730943-tingting.chao on 24/08/22-begin
    parseDataUri: function (str) {
      var re = /^data:(.+);(charset=([^;]+))?;?base64,(.*)$/;
      var matches = re.exec(str);
      if (matches) {
        return {
          mime: matches[1],
          charset: matches[3],
          value: matches[4]
        };
      }
      return null;
    },

    ensureMimeType: function (type) {
      type = type.toLowerCase();
      if (!MimeMapper.isSupportedType(type)) {
        type = MimeMapper.guessTypeFromExtension(type) || type;
      }
      return type || '';
    },

    parseTuple: function (p) {
      var match = p.match(ReTuple);
      return match ? [match[1].toLowerCase(), match[2]] : ['type', p];
    },

    parseLine: function (line) {
      var parsed = ReBasic.exec(line);
      if (!parsed) {
        return null;
      }

      // `tuples` is an array containing all the extra properties
      let tuples = parsed[1].split(/[;,]/);
      let fieldName = tuples.shift().toLowerCase();
      // Value will be an empty array if there is only whitespace and semi-colons.
      let fieldValue = /[^\s;]/.test(parsed[2]) ? parsed[2].split(';') : [];
      let meta = {
        type: []
      };

      let len = tuples.length;
      for (let i = 0; i < len; i++) {
        let tuple = this.parseTuple(tuples[i]);
        if ('type' === tuple[0]) {
          meta.type.push(tuple[1]);
        } else {
          meta[tuple[0]] = tuple[1];
        }
      }

      // If this is a photo, we correct the value and type
      if ('photo' === fieldName) {
        if (meta.type.length) {
          meta.type = this.ensureMimeType(meta.type[0]);
        }

        fieldValue = parsed[2];
        // vCard 3.0 expects a mandatory encoding = 'b' parameter for base64
        // encoded images, and vCard 2.1 expects a 'BASE64' one.
        if (meta.encoding && ('b' === meta.encoding.toLowerCase() ||
            'base64' === meta.encoding.toLowerCase())) {
          meta.encoding = 'base64';
        } else {
          let parsedUri = this.parseDataUri(fieldValue);
          if (parsedUri) {
            meta.type = this.ensureMimeType(parsedUri.mime);
            meta.encoding = 'base64';
            fieldValue = parsedUri.value;
          }
        }
      }

      return {
        key: fieldName,
        data: {
          meta: meta,
          value: fieldValue
        }
      };
    },

    decodeQuoted: function (str) {
      return decodeURIComponent(
      str.replace(qpRegexp, '%$1'));
    },

    decodeQP: function (metaObj, value) {
      var isQP = metaObj && metaObj.encoding && (/quoted-printable/i).test(metaObj.encoding);
      if (isQP) {
        value = this.decodeQuoted(value);
      }
      return value;
    },

    vcardToContact: function (vcardObj, cb) {
      if (!vcardObj) {
        return null;
      }

      let contactObj = {};
      if (vcardObj.fn && vcardObj.fn.length) {
        let fnMeta = vcardObj.fn[0].meta;
        let fnValue = vcardObj.fn[0].value[0];
        // For the name field, we want the data as it is
        contactObj.name = [this.decodeQP(fnMeta, fnValue)];
      }

      if (vcardObj.n && vcardObj.n.length) {
        let values = vcardObj.n[0].value;
        let meta = vcardObj.n[0].meta;

        for (let i = 0; i < values.length; i++) {
          let namePart = values[i];
          if (namePart && NAME_PARTS[i]) {
             // For the rest of the fields, we want to keep the merged data
             // separated the same way, in different positions of the array.
            contactObj[NAME_PARTS[i]] = this.decodeQP(meta, namePart).split(',');
          }
        }

        // If we don't have a contact name at this point, make `name` be the
        // unification of all the name parts.
        if (!contactObj.name) {
          contactObj.name = [this.decodeQP(meta, values.join(' ').trim())];
        }
      }
      contactObj.name = contactObj.name || contactObj.givenName;
      return contactObj;
    },

    parseEntries: function(cardArray) {
      let parsedCards = [];
      for (let i = 0; i < cardArray.length; i++) {
        let lines = cardArray[i];
        // If there is no array of strings at cardArray[i] (representing a single
        // vcard), push a null value to account for a processed card.
        if (!lines) {
          continue;
        }

        let fields = {};
        let len = lines.length;

        for (let j = 0; j < len; j++) {
          let line = lines[j];
          let parsedLine = this.parseLine(line);
          if (!parsedLine) {
            continue;
          }

          if (!fields[parsedLine.key]) {
            fields[parsedLine.key] = [];
          }
          fields[parsedLine.key].push(parsedLine.data);
        }

        parsedCards.push(this.vcardToContact(fields));
        if(parsedCards.length === cardArray.length){
          return parsedCards;
        }
      }
    },

    parseVcardName: function(contents){
      if(!contents) {
        return null;
      }

      let match = contents.match(/end:vcard/gi);
      // If there are no matches, then this probably isn't a vcard and we should stop processing.
      if (!match) {
        return null;
      }
      let total = match.length;
      dump("total vcard in the contents: " + total);
      let currentLine = '';
      let currentVersion = 0;
      let inLabel = false;
      let multiline = false;

      let cardArray = [
          []
      ];

      /**
         * Number of cards processed. Quite faster than looking at `cardArray` length.
         * @type {number}
      */
      let cardsProcessed = 0;

      // We start at the last cursor position
      let i = 0;

      for (let l = contents.length; i < l; i++) {
        let ch = contents[i];
        if (currentVersion >= 4 && '"' === ch) {
          inLabel = !inLabel;
          currentLine += ch;
          continue;
        }

        // Ignore beginning whitespace that indicates multiline field.
        if (true === multiline) {
          if ((/[\r\t\s\n]/).test(ch)) {
            continue;
          } else {
            multiline = false;
          }
        }

        let next = contents[i + 1];
        if (inLabel || (ch !== '\n' && ch !== '\r')) {
           // If we have a quoted-printable sign for multiline (/=\n/) AND
           // we are not in a data URI field, ignore the character.
          if (!(/^PHOTO/i).test(currentLine) && !(/^URL/i).test(currentLine) &&
              '=' === ch && next && next.search(/(\r|\n)/) !== -1) {
            multiline = true;
            continue;
          }
          currentLine += ch;

          // Continue only if this is not the last char in the string
          if (i !== l - 1) {
              continue;
          }
        }

        // If the field is a photo, the field could be multiline, to know if the
        // following line is part of the photo, we must check if the first char
        // of the following line is a space.
        let firstCharNextLine = contents[i + 2];
        if ((firstCharNextLine === WHITE_SPACE) && (/[\r\t\s\n]/).test(next) && (/^PHOTO/i).test(currentLine)) {
          multiline = true;
          continue;
        }

        // At this point, we know that ch is a newline, and in the vcard format,
        // if we have a space after a newline, it indicates multiline field.
        if (next && (next === WHITE_SPACE || '\t' === next)) {
          multiline = true;
          continue;
        }

        if (reBeginCard.test(currentLine)) {
          currentLine = '';
          currentVersion = 0;
          continue;
        }

        // If the current line indicates the end of a card,
        if (reEndCard.test(currentLine)) {
          cardsProcessed += 1;

          if (cardsProcessed === total) {
            return this.parseEntries(cardArray);
          }

          currentLine = '';
          cardArray.push([]);
          continue;
        }

        if (currentLine) {
          let matches = reVersion.exec(currentLine);
          if (null === matches) {
            cardArray[cardArray.length - 1].push(currentLine);
          } else {
            currentVersion = parseFloat(matches[1] || '0');
          }
        }
        currentLine = '';
      }
    },
    //TaskGF5GTMO-3580-porting from Defect10730943-tingting.chao on 24/08/22-end

    // Promise related utilities.
    Promise: {
      defer: function() {
        let deferred = {};

        deferred.promise = new Promise(function(resolve, reject) {
          deferred.resolve = resolve;
          deferred.reject = reject;
        });

        return deferred;
      },

      async: function(generatorFunction) {
        return function asyncGenerator() {
          const generator = generatorFunction.apply(this, arguments);

          function handle(result) {
            if (result.done) {
              return Promise.resolve(result.value);
            }

            return Promise.resolve(result.value).then(
              (result) => handle(generator.next(result)),
              (error) => handle(generator.throw(error))
            );
          }

          try {
            return handle(generator.next());
          } catch (error) {
            return Promise.reject(error);
          }
        };
      }
    }
  };

  exports.Utils = Utils;
}(this));
