'use strict';

let ValueDefault = {
  init: function() {
    // Const init.
    this.CPUTIMEOUTVALUE = 30 * 1000;
    this.COMMONTIMEOUT = 300;
    this.NOTIFYAUDIO = '/sounds/New Message_MA.ogg';
    this.FIRST_PANEL_THREAD_COUNT = 9;
    this.FIRST_SHOW_THREAD_COUNT = 3;
    this.RECIPIENTS_MMS_BOX_LIMIT = 20;
    this.RECIPIENTS_INPUT_FIELD_MAX_ONE = 50;
    this.CHUNK_SIZE = 5;
    this.IMAGE_RESIZE_DURATION = 3000;
    this.BANNER_DURATION = 2000;
    this.ANOTHER_SMS_TOAST_DURATION = 3000;
    // Var init.
    this.activitymode = false;
    this.activitySending = false;
    this.firstEnter = false;
    this.isAttachmentPage = false;
    this.draftSaveId = null;
    this.manualLeave = false;
    this.isFromNotification = false;
    this.isInformation = false;
    this.isCall = false;
    this.isSizeRead = false;
    // Bubble color.
    this.COLORMAP = [
      'CE7E7EC',
      'CFBC6C2',
      'CC8CFF5',
      'CC9E6CA',
      'CCFD8DC',
      'CF8BED0',
      'CB3E4FB',
      'CDCECC8',
      'CFFE0C4',
      'CEDBDDB',
      'CB2EAF1',
      'CEEF2BD',
      'CFECCBC',
      'CE1BEE7',
      'CB2DFDB',
      'CF1EBB7',
      'C9C5239',
      'CD1C3E9',
      'CBBDBF3',
      'CF9E5B2'
    ];
    // Contact filter by option.
    this.FilterByOption = {
      NAME: 0,
      GIVEN_NAME: 1,
      FAMILY_NAME: 2,
      TEL: 3,
      EMAIL: 4,
      CATEGORY: 5
    };
    // Contact filter option.
    this.FilterOption = {
      EQUALS: 0,
      CONTAINS: 1,
      MATCH: 2,
      STARTS_WITH: 3,
      FUZZY_MATCH: 4
    };
  }
};

ValueDefault.init();
