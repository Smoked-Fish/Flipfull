/* global ThreadListUI */

'use strict';

// eslint-disable-next-line no-unused-vars
let WaitingScreen = {
  get loading() {
    delete this.loading;
    return (this.loading = document.getElementById('loading'));
  },

  get loadingHeader() {
    delete this.loadingHeader;
    return (this.loadingHeader = document.querySelector('.loading-header'));
  },

  show: function() {
    this.loading.classList.add('show-loading');
  },

  hide: function() {
    this.loading.classList.remove('show-loading');
    ThreadListUI.cacheAction();
  },

  // Beign by tingting.chao for GCSDIAL-4844 on 2025/05/19
  isShowing: function() {
    return this.loading.classList.contains('show-loading');
  }
  // End by tingting.chao for GCSDIAL-4844 on 2025/05/19
};
