const Audio = {
  recorder: {
    getState: jest.fn(),
    setWaved: jest.fn(),
    on: jest.fn()
  }
}
export default Audio;
