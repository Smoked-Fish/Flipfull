const RecordStore = {
  find: () => {
    return [{key: 1, id: 111, name: 'New Recording'}];
  },
  on: jest.fn(),
  getAll: () => {
    return [{key: 1, id: 111, name: 'New Recording_1'},
            {key: 2, id: 222, name: 'New Recording_2'} ];
  },
  get: jest.fn()
}
export default RecordStore;

