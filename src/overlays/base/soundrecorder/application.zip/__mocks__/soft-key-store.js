const SoftKeyStore = {
  register: jest.fn()
}
export default SoftKeyStore;
