self.addEventListener('install', (event) => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

let handler = null;
let resolveIdleTimeExtension = null;
self.onsystemmessage = (evt) => {
  if ('activity' === evt.name) {
    handler = evt.data.webActivityRequestHandler();
    let htmlPath = null;
    switch (handler.source.name) {
      case 'pick':
        htmlPath = '/index.html#pick';
        break;
      case 'open':
        htmlPath = '/open.html';
        break;
      default:
        break;
    }

    evt.waitUntil(
      clients.openWindow(htmlPath, { disposition: 'inline' }).then(
        (openWindow) => {
          openWindow.postMessage({
            source: handler.source
          });
        }, (err) => {
          console.error(`openWindow fail with error: ${err}`);
        }));

    // IdleTimeExtension to make service worker timeout longer
    const idleTimeExtension = new Promise((resolve) => {
      resolveIdleTimeExtension = resolve;
    });
    evt.waitUntil(idleTimeExtension);
  }
};

self.addEventListener('message', (event) => {
  // Message received from clients
  const { data } = event;
  if (data.isDummy) {
    return;
  }
  if (handler) {
    if (data.isError) {
      handler.postError(data.activityResult);
    } else {
      handler.postResult(data.activityResult);
    }
  }
  if (resolveIdleTimeExtension) {
    resolveIdleTimeExtension();
    resolveIdleTimeExtension = null;
  }
});
