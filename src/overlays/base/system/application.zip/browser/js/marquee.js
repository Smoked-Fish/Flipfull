const doms = new Map();
const marqueeStep = 6;
const marqueezInterval = 90;
const marqueeDelay = 1000;

function isLongText(node) {
  return node && node.scrollWidth > node.offsetWidth;
}

export function hideMarquee(target) {
  if (isLongText(target) && doms.get(target)) {
    const timers = doms.get(target);
    target.style.textOverflow = 'ellipsis';
    delete target.dataset.marqueeText;
    target.scrollLeft = 0;
    clearInterval(timers.scrollTimer);
    clearTimeout(timers.marqueeTimer);
    doms.delete(target);
  }
}

export function showMarquee(target) {
  if (!isLongText(target)) return;
  const timers = {};
  doms.set(target, timers);
  const isRtl = 'rtl' === document.dir;
  const oldscrollWidth = target.scrollWidth;
  timers.marqueeTimer = setTimeout(() => {
    target.style.textOverflow = 'unset';
    target.dataset.marqueeText = target.innerText;

    timers.scrollTimer = setInterval(() => {
      if (
        (!isRtl && oldscrollWidth + 50 - target.scrollLeft > marqueeStep) ||
        (isRtl && oldscrollWidth + 50 + target.scrollLeft > marqueeStep)
      ) {
        if (isRtl) {
          target.scrollLeft -= marqueeStep;
        } else {
          target.scrollLeft += marqueeStep;
        }
      } else {
        hideMarquee(target);
      }
    }, marqueezInterval);
  }, marqueeDelay);
}
