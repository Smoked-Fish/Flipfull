/* global FxaModuleStates, FxaModule, FxModuleServerRequest
  FxaModuleOverlay, FxaModuleManager */
/* exported FxaModuleEnterAccountEmail */

'use strict';

/**
 * This module checks the validity of an email address & password,
 * and if valid, determines which screen to go next.
 */

var FxaModuleEnterAccountEmail = (function () {
  var loading;

  function _checkEmail(email) {
    var reg = /(^|[\s(,;，"<>])([^(,;，"<>@\s]+@[a-z0-9.\-]{2,250}[.][a-z0-9\-]{2,32})/;
    return reg.test(email);
  }

  function _showLoading() {
    loading = true;
    FxaModuleOverlay.show('fxa-connecting');
    $('fxa-enter-account-email').dataset.subid = 'loading';
    ViewManager.setSkMenu();
  }

  function _hideLoading() {
    loading = false;
    FxaModuleOverlay.hide();
    $('fxa-enter-account-email').dataset.subid = '';
    ViewManager.setSkMenu();
  }

  function _cleanForm(passwordEl, passwordCheck) {
    passwordEl.value = '';
    passwordCheck.value = '';
  }

  function _checkPassword(passwordEl, passwordCheck) {
    var passwordValue = passwordEl.value;
    if (!passwordValue || passwordValue.length < 8) {
      return 'PASSWORD_LESS';
    }

    if (passwordValue.length > 20) {
      return 'PASSWORD_MORE';
    }

    if (passwordValue !== passwordCheck.value) {
      return 'PASSWORD_DONT_MATCH';
    }

    if (!_passwdPolicyCheck(passwordValue)) {
      return 'PASSWORD_ERROR';
    }

    return '';
  }

  function _onShowPwClick(checkEl, passwordEl, confirmPasswordEl) {
    if (checkEl.checked) {
      passwordEl.type = 'text';
      confirmPasswordEl.type = 'text';
    } else {
      passwordEl.type = 'password';
      confirmPasswordEl.type = 'password';
    }
  }

  var Module = Object.create(FxaModule);
  Module.init = function init(options) {
    // Cache static HTML elements
    this.importElements(
      'fxa-email-input',
      'fxa-pw-input',
      'fxa-confirm-pw-input',
      'fxa-show-pw'
    );

    if (this.initialized) {
      return;
    }

    var placeholder = window.api.l10n.get('fxa-email');
    this.fxaEmailInput.setAttribute('placeholder', placeholder);

    this.fxaShowPw.addEventListener('click', event => {
      _onShowPwClick(event.target, this.fxaPwInput,
        this.fxaConfirmPwInput);
    });

    _cleanForm(this.fxaPwInput, this.fxaConfirmPwInput);

    // Avoid to add listener twice
    this.initialized = true;
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    if (loading) return;

    var email = this.fxaEmailInput.value;
    if (!email) {
      this.showErrorResponse({ error: "EMAIL_EMPTY" });
      return;
    } else if (!_checkEmail(email)) {
      this.showErrorResponse({ error: "INVALID_EMAIL" });
      return;
    }

    var error = _checkPassword(this.fxaPwInput, this.fxaConfirmPwInput);
    if (error) {
      this.showErrorResponse({
        error: error
      });
      return;
    }

    _showLoading();
    FxModuleServerRequest.checkEmailExistence(email,
      response => {
        _hideLoading();
        if (response && response.registered) {
          this.showErrorResponse({ error: 'EMAIL_IS_TAKEN' });
        } else {
          FxaModuleManager.setParam('email', email);
          FxaModuleManager.setParam('password', this.fxaPwInput.value);
          gotoNextStepCallback(FxaModuleStates.ENTER_PERSONAL_INFO);
        }
      },
      response => {
        _hideLoading();
        this.showErrorResponse(response);
      });
  };

  Module.onBack = function onBack() {
    if (loading) {
      return _hideLoading();
    }
    _showConfirmation(null, () => {
      window.parent.FxAccountsUI.done(FxaModuleStates.DONE);
    });
  };

  Module.onDone = function onDone() {
    _hideLoading();
  };
  return Module;
}());
