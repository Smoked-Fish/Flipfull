'use strict';
/* global PowerSave, ScreenManager, SettingsObserver, Service, soundManager */

(function(exports) {

  function BatteryOverlay() {
    this.powerSave = new PowerSave();
    this.powerSave.start();
  }

  BatteryOverlay.prototype = {
    TOASTER_TIMEOUT: 5000,

    AUTO_SHUTDOWN_LEVEL: 0.00,
    EMPTY_BATTERY_LEVEL: 0.20,
    PLAY_ALERT_SOUND_LEVEL: 0.05,//Defcet-11226805 add shangpeng.su 2021.06.09

    TIMEOUT: 500,
    SOUNDFILE: 'resources/sounds/Connect_Power_MA.ogg',
    SOUNDFILE_LOWBATTERY: 'resources/sounds/Low battery.ogg',
    _battery: null,
    _powersupply: window.navigator.b2g.powerSupplyManager,
    _notification: null,
    _batteryFullNotification: null,

    checkBatteryDrainage: function bm_checkBatteryDrainage() {
      var battery = this._battery;
      if (!battery) {
        return;
      }
      if (battery.level <= this.AUTO_SHUTDOWN_LEVEL && !battery.charging) {
        // Fire a event to inform sleepMenu perform shutdown.
        //Defcet-11226805 modify-begin shangpeng.su 2021.06.09
        // added by yibin.yang for Task 10193024 begin [TMO]
        if (this.operator == 'TMO' &&
        battery.level <= this.PLAY_ALERT_SOUND_LEVEL &&
        !battery.charging) {
          var telephony = navigator.b2g.telephony;
          if ((telephony && telephony.calls.length) ||
                (telephony.conferenceGroup && telephony.conferenceGroup.calls.length)) {
            this.playAlertSound('notification','400Hz+1200Hz_200ms');
          }
        }
        // added by yibin.yang for Task 10193024 end [TMO]
        if (battery.level <= this.AUTO_SHUTDOWN_LEVEL && !battery.charging) {
          window.dispatchEvent(new CustomEvent('batteryshutdown'));
        }
        //Defcet-11226805 modify-end shangpeng.su 2021.06.09
      }
    },

    // Initialize the battery object. Note that synchronous access to _battery
    // from outside (eg. power_save.js) is now potentially racy.
    // This needs to be redesigned.
    start: function() {
      window.navigator.getBattery().then(battery => {
        this._battery = battery;
        this.init();
      });
    },

    init: function bm_init() {
      var battery = this._battery;
      var powersupply = this._powersupply;
      this._lastPowerSupplyStatus =
        powersupply.powerSupplyOnline || battery.charging;

      if (window.remoteHelper) {
        window.remoteHelper.getproperty('ro.operator.name', (response)=> {
          console.log('remoteHelper, getpropery, in');
          this.operator = JSON.parse(response).value;
        }, ()=> {
          console.log('remoteHelper error ,getpropery');
        });
      }
      if (battery) {
        // When the device is booted, check if the battery is drained. If so,
        // batteryshutdown would be triggered to inform sleepMenu shutdown.
        window.addEventListener('logohidden',
          this.checkBatteryDrainage.bind(this));

        battery.addEventListener('levelchange', this);
        battery.addEventListener('chargingchange', this);
      }

      if (powersupply) {
        powersupply.addEventListener('powersupplystatuschanged', this);
      }
      window.addEventListener('screenchange', this);
      SettingsObserver.observe('audio.volume.notification', 1, (value) => {
        this.silent = value === 0;
      });

      this._screenOn = true;
      this._wasEmptyBatteryNotificationDisplayed = false;

      this.displayIfNecessary();
    },

    powerSupplyStatusChanged: function() {
      const battery = this._battery;
      const powersupply = this._powersupply;
      const powerSupplyStatus =
        powersupply.powerSupplyOnline || battery.charging;
      if (this._lastPowerSupplyStatus !== powerSupplyStatus) {
        this._lastPowerSupplyStatus = powerSupplyStatus;
        if (!this._screenOn) {
          ScreenManager.turnScreenOn('powersupplystatuschanged');
        }
        this.removeBatteryFullNotification();
      }
    },

    handleEvent: function bm_handleEvent(evt) {
      var battery = this._battery;
      switch (evt.type) {
        case 'screenchange':
          this._screenOn = evt.detail.screenEnabled;
          this.displayIfNecessary();
          break;

        case 'levelchange':
          if (!battery) {
            return;
          }

          this.checkBatteryDrainage();
          this.displayIfNecessary();

          this.powerSave.onBatteryChange();

          if (this.shouldNotifyBatteryFull()) {
            this._batteryFullNotification = this.showBatteryFullNotification();
          }
          break;
        case 'chargingchange':
          this.powerSave.onBatteryChange();

          // We turn the screen on if needed in order to let
          // the user knows the device is charging
          if (battery && battery.charging) {
            this._wasEmptyBatteryNotificationDisplayed = false;
            this.playAudio(this.SOUNDFILE);
            if (soundManager.vibrationEnabled) {
              navigator.vibrate(50);
            }
          } else {
            this.checkBatteryDrainage();
            this.displayIfNecessary();
          }
          this.powerSupplyStatusChanged();
          break;
        case 'powersupplystatuschanged':
          this.powerSupplyStatusChanged();
          break;
        default:
          break;
      }
    },

    _shouldWeDisplay: function bm_shouldWeDisplay() {
      var battery = this._battery;
      if (!battery) {
        return false;
      }

      return (!this._wasEmptyBatteryNotificationDisplayed &&
        !battery.charging &&
        battery.level <= this.EMPTY_BATTERY_LEVEL &&
        this._screenOn);
    },

    // added by yibin.yang for Task 10189975 [TMO]
    playAlertSound: function bm_playAlertSound(audioChannelType,name) {
      if(StatusBar.playingActive){
        return;
      }
      var ringtonePlayer = new Audio();
      ringtonePlayer.src = 'resources/dtmf_tones/'+name+'.ogg'
      ringtonePlayer.mozAudioChannelType = audioChannelType;
      ringtonePlayer.play();
      window.setTimeout(function smsRingtoneEnder() {
        ringtonePlayer.pause();
        ringtonePlayer.removeAttribute('src');
        ringtonePlayer.load();
      }, 2000);
    },

    playAudio: function bm_playAudio(sound) {
      if (!this.audio) {
        this.audio = new Audio();
      } else if (!this.audio.paused) {
        this.audio.pause();
      }
      if (!this.silent) {
        this.audio.src = sound;
        this.audio.mozAudioChannelType = 'notification';
        this.audio.play();
        window.setTimeout(() => {
          this.audio.pause();
          this.audio.removeAttribute('src');
          this.audio.load();
        }, this.TIMEOUT);
      }
    },

    displayIfNecessary: function bm_display() {
      if (!this._shouldWeDisplay()) {
        return;
      }

      if (this.operator == 'TMO') {
	    this._wasEmptyBatteryNotificationDisplayed = true;
        this.playAlertSound('notification','400Hz+1200Hz_200ms');// added by yibin.yang for Task 10189975 [TMO]
      }
      else {
	    this._wasEmptyBatteryNotificationDisplayed = true;
        this.playAudio(this.SOUNDFILE_LOWBATTERY);
      }
      Service.request('SystemToaster:show', {
        text: window.api.l10n.get('battery-almost-empty-plug-in-your-charger')
      });
    },

    /**
     * Check if the battery is fully charged or not.
     */
    shouldNotifyBatteryFull: function() {
      var battery = this._battery;
      if (!battery) {
        return false;
      }

      var powersupply = this._powersupply;
      if (!powersupply) {
        return false;
      }

      return (battery.level === 1 &&
        (powersupply.powerSupplyOnline || battery.charging) &&
        this._batteryFullNotification === null);
    },

    /**
     * Display the fully charged notification.
     */
    showBatteryFullNotification: function() {
      var title = window.api.l10n.get('battery-full-title') || '';
      var body = window.api.l10n.get('battery-full-body') || '';
      var notification = new window.Notification(title, {
        body: body,
        tag: 'batteryFull',
        icon: window.AppOrigin.getOrigin('system') +
          '/style/notifications/images/battery_full.png'
      });

      notification.onclick = function() {
        notification.close();
      };

      return notification;
    },

    /**
     * Remove the battery full notification if it is exists.
     */
    removeBatteryFullNotification: function() {
      if (this._batteryFullNotification !== null) {
        this._batteryFullNotification.close();
        this._batteryFullNotification = null;
      }
    }
  };

  exports.BatteryOverlay = BatteryOverlay;

}(window));
