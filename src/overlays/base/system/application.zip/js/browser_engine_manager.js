/* eslint-disable no-unused-vars */
/* global Service, AlarmMessageHandler, SettingsObserver,
          BrowserUtils, SearchProvider */
'use strict';

(function(exports) {

  const BrowserEngineManager = function() {};
  BrowserEngineManager.prototype = {
    DEBUG: false,
    name: 'BrowserEngineManager',
    ENGINE_REFRESH_KEY: 'browser.engine.refresh',

    debug: function() {
      window.DUMP('[' + this.name + ']' +
        '[' + Service.currentTime() + '] ' +
        Array.prototype.slice.call(arguments).concat());
    },

    start: function() {
      Service.register('checkToUpdate', this);
      AlarmMessageHandler.addCallback(this.handleAlarm.bind(this));
      this.wifiManager = navigator.b2g.wifiManager;
      this.conns = navigator.b2g.mobileConnections || [];
      this.bindOnDatachange = this.onDatachange.bind(this);
      this.bindOnWifihasinternet = this.onWifihasinternet.bind(this);
      SettingsObserver.getValue(this.ENGINE_REFRESH_KEY).then(value => {
        !value && this.checkToUpdate();
      });
    },

    checkToUpdate: function() {
      if (!window.isOnline()) {
        for (let i = 0; i < this.conns.length; i++) {
          this.conns[i].addEventListener('datachange', this.bindOnDatachange);
        }
        if (this.wifiManager) {
          this.wifiManager.addEventListener('wifihasinternet',
            this.bindOnWifihasinternet);
        }
      } else {
        this.updateBrowserEngine();
      }
    },

    onDatachange: function(e) {
      if (e.target.data.connected) {
        this.updateBrowserEngine();
      }
    },

    onWifihasinternet: function(e) {
      if (e.hasInternet) {
        this.updateBrowserEngine();
      }
    },

    removeConnectionListener: function() {
      for (let i = 0; i < this.conns.length; i++) {
        this.conns[i].removeEventListener('datachange', this.bindOnDatachange);
      }
      if (this.wifiManager) {
        this.wifiManager.removeEventListener('wifihasinternet',
          this.bindOnWifihasinternet);
      }
    },

    updateBrowserEngine: function() {
      this.debug('updateBrowserEngine');
      window.BrowserUtils.requestProviders().then(json => {
        let data = null;
        try {
          data = JSON.parse(json);
        } catch(err) {
          console.error('get search providers fail. json: ' + json);
        }
        if (!data) {
          return;
        }

        this.removeConnectionListener();
        SettingsObserver.setValue([{
          name: this.ENGINE_REFRESH_KEY,
          value: true
        }]);
        const day = 24 * 60 * 60 * 1000;
        this.setAlarm(data.refreshTimeFrame * day);
        SearchProvider.ready().then(() => {
          SearchProvider.updateSearchProvider(data);
        });
      }, () => {
        console.error('get search providers fail.');
      });
    },

    handleAlarm: async function(message) {
      if (message.data && message.data.browserEngineRefresh) {
        this.debug('handleAlarm');
        await SettingsObserver.setValue([{
          name: this.ENGINE_REFRESH_KEY,
          value: false
        }]);
        this.checkToUpdate();
      }
    },

    setAlarm: function(time) {
      this.debug('setAlarm');
      const curTimestamp = new Date().getTime();
      const alarmStamp = curTimestamp + time;
      if (navigator.b2g && navigator.b2g.alarmManager) {
        navigator.b2g.alarmManager.getAll().then((result) => {
          const findAlarm = result.find((alarm) => {
            return !!alarm.data.browserEngineRefresh;
          });
          if (findAlarm) {
            navigator.b2g.alarmManager.remove(findAlarm.id);
          }
          this.debug('Add alarms ' + alarmStamp);
          navigator.b2g.alarmManager.add({
            date: new Date(alarmStamp),
            ignoreTimezone: true,
            data: { browserEngineRefresh: true }
          });
        });
      }
    },
  }
  exports.BrowserEngineManager = BrowserEngineManager;
}(window));