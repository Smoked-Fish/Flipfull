/* global asyncStorage */
'use strict';

(function () {
  const PRESITES_LOADED_KEY = 'browser-presites-loaded';
  const PINSITES_KEY = 'browser-pinsites';
  const MAX_PINSITES_NUM = 6;
  const systemOrigin = window.AppOrigin.getOrigin('system');
  const preloadPath = {
    preloadTopSites: systemOrigin + '/browser/js/inittopsites.json',
    preloadCustomizationTopSites: systemOrigin + '/browser/js/customizationtopsites.json',
  };
  let TMO_SIM_INCERTED = false;
  let TMO_SIM_TYPE = null;
  let FIRST_INSERT_TMO_SIMCARD = false;

  class BrowserPinSitesStore {
    constructor() {
      //GF5GTMO-4265-shuhong.zhou-add customized bookmarks begin
      this.switchSimCardHandler = this.switchSimCardHandler.bind(this);
      this.switchSimCardHandler2 = this.switchSimCardHandler2.bind(this);
      this.observerSimCardSwitch();
      this.loadPreloadSites();
      //GF5GTMO-4265-shuhong.zhou-add customized bookmarks end
    }

    async loadPreloadSites() {
      const hasLoaded = await this.checkPreSitesloaded();
      //GF5GTMO-4265-shuhong.zhou-modified customized bookmarks
      if (hasLoaded && !TMO_SIM_INCERTED) return;
      const preloadSites = await this.getJSON(preloadPath.preloadTopSites);
      const cusPreloadSites = await this.getJSON(preloadPath.preloadCustomizationTopSites);
      //GF5GTMO-4265-shuhong.zhou-add customized bookmarks begin
      //const combinedPreloadSites = cusPreloadSites ? preloadSites.concat(cusPreloadSites) : preloadSites;
      var customizedBookmarks;
      console.log(`BrowserPinSitesStore :: TMO_SIM_TYPE = ${TMO_SIM_TYPE}`);
      if(TMO_SIM_TYPE){
          customizedBookmarks = cusPreloadSites[0][TMO_SIM_TYPE];
      }
      const combinedPreloadSites = customizedBookmarks ? preloadSites.concat(customizedBookmarks) : preloadSites;
      //GF5GTMO-4265-shuhong.zhou-add customized bookmarks end
      await this.setPinSites(combinedPreloadSites);
      asyncStorage.setItem(PRESITES_LOADED_KEY, true);
    }

    //GF5GTMO-4265-shuhong.zhou-add customized bookmarks begin
    observerSimCardSwitch() {
      const iccManager = navigator.b2g.iccManager;
      if (iccManager) {
        const delayedHandler = () => {
          setTimeout(() => {
            this.switchSimCardHandler2();
          }, 2000);
        };
        console.log(`BrowserPinSitesStore :: Start sim switch listener!`);
        iccManager.addEventListener('iccdetected', delayedHandler);
      }
    }

    switchSimCardHandler() {
      navigator.b2g.engmodeManager.getPropertyValue('persist.gsm.sim.operator').then(simOperator =>{
        console.log(`BrowserPinSitesStore :: simOperator = ${simOperator}`);
        if (simOperator === 'TMO') {
          navigator.b2g.engmodeManager.getPropertyValue('persist.gsm.sim.tmo.type').then(tmoSimType =>{
            console.log(`BrowserPinSitesStore :: simOperator = ${simOperator} , tmoSimType = ${tmoSimType}`);
            if (tmoSimType === 'MPCS' || tmoSimType === 'TMO') {
              navigator.b2g.engmodeManager.getPropertyValue('persist.radio.device.rsu_state').then(rsu_state =>{
                console.log(`BrowserPinSitesStore :: rsu_state = ${rsu_state} , FIRST_INSERT_TMO_SIMCARD = ${FIRST_INSERT_TMO_SIMCARD}`);
                if (rsu_state && rsu_state === '0' && FIRST_INSERT_TMO_SIMCARD) {
                  console.log(`BrowserPinSitesStore :: Lock device and bookmarks already exist, return!`);
                  return;
                } else {
                  TMO_SIM_INCERTED = true;
                  TMO_SIM_TYPE = tmoSimType;
                  try {
                    FIRST_INSERT_TMO_SIMCARD = true
                    this.loadPreloadSites();
                  } catch (error) {
                    console.error(`BrowserPinSitesStore :: ${error}`);
                  }
                }
              });
            }
          });
        }
      });
    }

    switchSimCardHandler2() {
      const iccManager = navigator.b2g.iccManager;
      const jsonString5 = JSON.stringify(iccManager, null, 2);
      //We only consider updating the bookmarks when adding the card.
      if(!iccManager){
        return;
      }
      let iccId = iccManager.iccIds[0];
      const connection = navigator.b2g.mobileConnections;
      if(connection){
        iccId = connection[0].iccId;
      }
      let iccInfo = navigator.b2g.iccManager.getIccById(iccId).iccInfo;
      if (!iccInfo) {
        return;
      }
      let mcc = iccInfo.mcc;
      let mnc = iccInfo.mnc;
      let mccmnc = mcc.concat(mnc);
      let gid1 = iccInfo.gid1;
      console.log(`BrowserPinSitesStore :: MccMnc = ${mccmnc} , Gid1 = ${gid1}`);
      navigator.b2g.engmodeManager.getPropertyValue('persist.radio.device.rsu_state').then(rsu_state =>{
        console.log(`BrowserPinSitesStore :: rsu_state = ${rsu_state} , FIRST_INSERT_TMO_SIMCARD = ${FIRST_INSERT_TMO_SIMCARD}`);
        if (rsu_state && rsu_state === '0' && FIRST_INSERT_TMO_SIMCARD) {
          console.log(`BrowserPinSitesStore :: Lock device and bookmarks already exist, return!`);
          return;
        } else {
          if (gid1 === '6d38ffff' && mccmnc === '310260') {
            console.log(`BrowserPinSitesStore :: SIM is Metro`);
            TMO_SIM_TYPE = 'MPCS';
            TMO_SIM_INCERTED = true;
            FIRST_INSERT_TMO_SIMCARD = true
            this.loadPreloadSites();
            return true;
          } else if ((gid1 === null || gid1 === 'ffffffffffffffff') && mccmnc === '310260') {
            console.log(`BrowserPinSitesStore :: SIM is TMO`);
            TMO_SIM_TYPE = 'TMO';
            TMO_SIM_INCERTED = true;
            FIRST_INSERT_TMO_SIMCARD = true
            this.loadPreloadSites();
            return true;
          }
        }
        return false;
      });
    }
    //GF5GTMO-4265-shuhong.zhou-add customized bookmarks end

    checkPreSitesloaded() {
      return this.getItem(PRESITES_LOADED_KEY);
    }

    getJSON(input) {
      return fetch(input).then((response) => {
        if (response.ok) {
          return response.json();
        } else {
          console.warn(`getJSON: ${input} not loaded`);
          return null;
        }
      });
    }

    getPinSites() {
      return this.getItem(PINSITES_KEY);
    }

    replace(index, data) {
      return new Promise((resolve) => {
        this.getItem(PINSITES_KEY).then((sites) => {
          sites[index] = data;
          this.setPinSites(sites).then(() => resolve());
        });
      });
    }

    setPinSites(sites) {
      return this.setItem(PINSITES_KEY, this.formatPinSites(sites));
    }

    formatPinSites(sites) {
      if (sites.length === MAX_PINSITES_NUM) {
        return sites;
      }

      const results = new Array(MAX_PINSITES_NUM);

      for (let i = 0; i < results.length; i++) {
        results[i] = sites[i];
      }

      return results;
    }

    setItem(key, value) {
      return new Promise((resolve) => {
        asyncStorage.setItem(key, value, resolve);
      });
    }

    getItem(key) {
      return new Promise((resolve) => {
        asyncStorage.getItem(key, resolve);
      });
    }
  }

  window.BrowserPinSitesStore = BrowserPinSitesStore;
})(window);
