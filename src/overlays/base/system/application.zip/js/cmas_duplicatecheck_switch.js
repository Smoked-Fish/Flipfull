/**
 * Created by qiucheng.qin on 19-03-25 for PR7566274.
 */
/* TODO: <CDR-ECB-510>
* Message History after Power Cycle/Airplane Mode
* Summary: After a power cycle or disabling of airplane mode, CMAS capable UEs shall not
* use any history of previously received cell broadcast messages to determine if a newly
* received message is a duplicate. UEs shall treat a received cell broadcast message as new
* even if its Message Identifier and Serial Number match one received before the device's
* radio was power cycled.
*/
window.CmasMsgHistory = (function(){
  // Defect9520856-qiucheng.qin- UE didnt received CMAS AMBER A-begin
  const ATT_MCC_MNC = ['31030', '31070', '31090','310380', '310150', '310170',
      '310410', '310560', '310030',    '310280', '310680',
      '310950', '310980','311180', '312670', '313100','313110',
      '313120','313130','313140'];
  // Defect9520856-qiucheng.qin- UE didnt received CMAS AMBER A-end
  // Defect9575890-qiucheng.qin- UE does not display English CMAS message-begin
  const VZW_MCC_MNC = ['310590', '310012', '310890', '311280', '311281', '311282',
      '311283', '311284', '311285', '311286', '311287', '311288', '311289',
      '311480', '311481', '311482', '311483', '311484', '311485', '311486',
      '311487', '311488', '311489', '311270', '312770'];
  // Defect9575890-qiucheng.qin- UE does not display English CMAS message-end
  // Task10973431-daijun.xiao- add U.S. Cellular support-begin
  const USCC_MCC_MNC = ['311580', '311581', '311582', '311583', '311584', '311585',
      '311586', '311587', '311588', '311589', '311220', '311221', '311222',
      '311223', '311224', '311225', '311226', '311227', '311228', '311229'];
  var CmasMsgHistory = {
    setIgnoreDup: function() {
      SettingsObserver.setValue([{
        name: 'cmas.ignore.dup',
        value: true
      }]).then(() => {
        dump("CMAS:: Success to set cmas.ignore.dup to true");
      });
    },

    observeradiostatechange: function () {
      SettingsObserver.observe('airplaneMode.enabled', false, function settingChanged(value) {
        dump("CMAS::airplaneModeChanged value: " + value);
        if(!value){
          this.setIgnoreDup();
        }
      }.bind(this));
    },

    // Defect9576017-qiucheng-[50724_Verizon LTE CMAS][18] UE fails to display Spanish alert during step 23-begin
    getMccMnc: function () {
      var mccMnc = null;
      if (typeof SIMSlotManager !== 'undefined') {
        var primarySimSlot = SIMSlotManager.getSlots()[0];
        if (primarySimSlot && primarySimSlot.simCard && primarySimSlot.simCard.iccInfo) {
          mcc = primarySimSlot.simCard.iccInfo.mcc;
          mnc = primarySimSlot.simCard.iccInfo.mnc;
          mccMnc = mcc + mnc;
        }
      }
      dump('CMAS::CmasMsgHistory--init, MccMnc = ' + mccMnc);
      return mccMnc;
    },

    // Task10584955-qiucheng.qin- Init CmasMsgHistory when phone boot-begin
    getProp: function(key) {
      return new Promise((resolve, reject) => {
        if (window.remoteHelper) {
          window.remoteHelper.getproperty(key, (response)=>{
            let result = JSON.parse(response).value;
            dump('CMAS::CmasMsgHistory--getpropery ' + key + ' success, value is ' + result);
            resolve(result);
          }, ()=>{
            dump('CMAS::CmasMsgHistory--getpropery ' + key + ' failed');
            reject();
          });
        } else {
          dump('CMAS::CmasMsgHistory--getpropery error, no remoteHelper');
          reject();
        }
      });
    },

    setProp: function(key, value) {
      dump('CMAS::CmasMsgHistory--setpropery ' + key + " , value = " + value);
    },

    handleLabMccMnc: function () {
      this.getProp('ro.secure.build.operator').then((buildOperator) => {
        dump('CMAS::CmasMsgHistory--init, buildOperator = ' + buildOperator);
        // Defect9783036-qiucheng.qin-Treat 00101 as ATT card for TF version
        if (buildOperator === '1' || buildOperator === '4') {
          this.setIgnoreDup();
          this.observeradiostatechange();
          this.setProp('cmas.spanish.enabled', 0);
        } else if (buildOperator === '3') {
          this.setIgnoreDup();
        } else {
          this.setProp('cmas.spanish.enabled', 0);
        }
      });
    },
    // Task10584955-qiucheng.qin- Init CmasMsgHistory when phone boot-end

    init: function() {
      dump('CMAS::CmasMsgHistory--init');
      // Defect9575890-qiucheng.qin- UE does not display English CMAS message-begin
      // Defect9520856-qiucheng.qin- UE didnt received CMAS AMBER A-begin
      if (typeof OperatorUtils !== 'undefined') {
        if (OperatorUtils.isATTFamily()) {
          this.setIgnoreDup();
          this.observeradiostatechange();
          this.setProp('cmas.spanish.enabled', 0);
        } else if (OperatorUtils.isVZWFamily()) {
          this.setIgnoreDup();
        } else {
          var mccMnc = this.getMccMnc();
          if (mccMnc === '00101') {
            this.handleLabMccMnc();
          } else {
            this.setProp('cmas.spanish.enabled', 0);
          }
        }
      } else {
        var mccMnc = this.getMccMnc();
        if (mccMnc) {
          if (ATT_MCC_MNC.indexOf(mccMnc) !== -1) {
            dump('CMAS::CmasMsgHistory--isATTMccMnc');
            this.setIgnoreDup();
            this.observeradiostatechange();
            this.setProp('cmas.spanish.enabled', 0);
          } else if (VZW_MCC_MNC.indexOf(mccMnc) !== -1) {
            dump('CMAS::CmasMsgHistory--isVZWMccMnc');
            this.setIgnoreDup();
          // Task10973431-daijun.xiao- add U.S. Cellular support-begin
          } else if (USCC_MCC_MNC.indexOf(mccMnc) !== -1) {
            dump('CMAS::CmasMsgHistory--isUSCCMccMnc');
            this.setIgnoreDup();
          // Task10973431-daijun.xiao- add U.S. Cellular support-end
          } else if (mccMnc === '00101') {
            this.handleLabMccMnc();
          } else {
            this.setProp('cmas.spanish.enabled', 0);
          }
        }
      }
      // Defect9520856-qiucheng.qin- UE didnt received CMAS AMBER A-end
      // Defect9575890-qiucheng.qin- UE does not display English CMAS message-end
    }
  };
  // Defect9494518-qiucheng.qin- Can't receive CMAS-end
  // Defect9576017-qiucheng-[50724_Verizon LTE CMAS][18] UE fails to display Spanish alert during step 23-end
  return CmasMsgHistory;
})(window);
CmasMsgHistory.init();// Task10584955-qiucheng.qin- Init CmasMsgHistory when phone boot
