/* global BaseModule, Service, SettingsObserver */
'use strict';

(function() {
/*
 * This emergency callback mode manager is for:
 * - Initialize the manager if network type is cdma and regist an event handler
 *   for emergency callback mode change.
 * - Display a notification to showing the system is entered the callback
 *    mode with count down timer.
 * - Popup a dialog for user to notify the mode will block data network and
 *   let user decide callback mode should exit or not.
 *
 */

  var EmergencyCallbackManager = function(core) {
    if (core && core.mobileConnections) {
      this._conns = core.mobileConnections;
    }
  };
  // XXX: Migrate to ES6 BaseModule
  EmergencyCallbackManager.EVENTS = ['__keydown'];
  BaseModule.create(EmergencyCallbackManager, {
    name: 'EmergencyCallbackManager',
    timer: 0,
    timeoutController: null,
    TOASTER_TIMEOUT: 2000,
    EVENT_PREFIX: 'emergencycallback',

    notification: null,
    message: null,
    toaster: null,
    toasterMessage: null,
    // [GF7VZW-7489] added by zhichao.si, 2024-01-18
    showDialog: false,
    isForbiddenDisableWifi: false,
    needTurnOffWifi: false,

    initDOM: function() {
      if (this.notification) {
        return;
      }
      // Dom elements
      this.notification =
        document.getElementById('emergency-callback-notification');
      if (!this.notification) {
        return;
      }
      this.monitorEmergencyCallInit();
      Service.request('SoftKeyStore:register', {center: 'icon=ok'},
        this.notification);
      Service.register('skipTurnOffWifiAfterECBM', this);
      Service.registerState('isForbiddenDisableWifi', this);
      this.message = this.notification.querySelector('.title-container');
      this.notificationTimer = this.notification.querySelector('.timer');

      this.toaster = document.getElementById('emergency-callback-toaster');
      this.toasterMessage = this.toaster.querySelector('.message');
      this.toasterTimer = this.toaster.querySelector('.timer');

      this.notification.addEventListener('keydown', this);
    },

    monitorEmergencyCallInit() {
      navigator.b2g.telephony.addEventListener('callschanged', () => {
        this.debug('callschanged');
        const { calls } = navigator.b2g.telephony;
        if (calls.length !== 0) {
          let call = calls[calls.length - 1];
          this.debug('call.state ' + call.state);
          if (call.emergency &&
            (call.state === 'alerting' || call.state === 'connected')) {
            this.forceEnableWifi();
            return;
          }
        }
        if (this.isForbiddenDisableWifi && !this.isConnsInEmergencyCbMode() &&
          !this.restoreWifiTimer) {
          this.restoreWifiTimer = window.setTimeout(() => {
            this.restoreWifiOff();
          }, 5000);
        }
      });
    },

    skipTurnOffWifiAfterECBM() {
      this.needTurnOffWifi = false;
    },

    isConnsInEmergencyCbMode() {
      for(let i = 0; i < this._conns.length; i++) {
        if (this._conns[i].isInEmergencyCbMode) {
          return true;
        }
      }
      return false;
    },

    restoreWifiOff() {
      this.debug('restoreWifiOff');
      if (!this.isConnsInEmergencyCbMode()) {
        this.restoreWifiTimer = 0;
        this.isForbiddenDisableWifi = false;
        if (this.needTurnOffWifi) {
          this.needTurnOffWifi = false;
          SettingsObserver.setValue([{
            name: 'wifi.enabled',
            value: false
          }]);
        }
      }
    },

    forceEnableWifi() {
      this.debug('forceEnableWifi ' + this.isForbiddenDisableWifi);
      window.clearTimeout(this.restoreWifiTimer);
      this.restoreWifiTimer = 0;
      if (!this.isForbiddenDisableWifi) {
        this.isForbiddenDisableWifi = true;
        if (!window.Wifi.wifiEnabled) {
          if (!Service.query('AirplaneMode.isActive')) {
            this.needTurnOffWifi = true;
          }
          SettingsObserver.setValue([{
            name: 'wifi.enabled',
            value: true
          }]);
        }
      }
    },

    _handle_keydown(evt) {
      switch (evt.key) {
        case 'Enter':
          this.notificationClicked();
          break;
      }
    },

    _start: function() {
      this.initDOM();
      // Event handler
      for(let i = 0; i < this._conns.length; i++) {
        this._conns[i].addEventListener('emergencycbmodechange',
          this.onEmergencyCbModeChange.bind(this));
      }
    },

    exitEmergencyCbMode: function() {
      dump("exit Emergency Cb Mode");
      for(let i = 0; i < this._conns.length; i++) {
        this._conns[i].exitEmergencyCbMode();
      }
    },

    notificationClicked: function() {
      this.showEmergencyCbPrompt();
      Service.request('NotificationView:close');
    },

    // [GF7VZW-7489] begin modified by zhichao.si, 2024-01-18
    showEmergencyCbPrompt: function() {
      var _ = window.api.l10n.get;
      var contentnew = _('emergency-callback-message-new', {'time': this.timerString+""});
      this.showDialog = true;
      Service.request('DialogService:show', {
        id: 'emergency-callback-prompt-dialog',//Defect11278944-modify by syang
        header: _('emergency-callback-mode'),
        content: contentnew,
        translated: true,
        onOk: () => {
          this.exitEmergencyCbMode();
          this.showDialog = false;
        },
        onCancel: () => {
          this.showDialog = false;
        },
        onBack: () => {
          this.showDialog = false;
        },
        type: 'confirm'
      });
    },
    // [GF7VZW-7489] end modified by zhichao.si, 2024-01-18

    displayNotificationAndToaster: function() {
      this.displayNotificationIfHidden();
      this.toasterTimer.textContent = this.timerString;
      this.toaster.classList.add('displayed');
      this.toaster.hidden = false;
      setTimeout(function waitToHide() {
        this.toaster.classList.remove('displayed');
        this.toaster.hidden = true;
      }.bind(this), this.TOASTER_TIMEOUT);
    },

    hideNotificationIfDisplayed: function() {
      if (!this.notification.classList.contains('hidden')) {
        this.notification.classList.add('hidden');
        Service.request('hideEmcbNotification');
        this.publish('statechanged', {show: false});
      }
    },

    displayNotificationIfHidden: function() {
      if (this.notification.classList.contains('hidden')) {
        this.notification.classList.remove('hidden');
        Service.request('showEmcbNotification');
        this.publish('statechanged', {show: true});
      }
    },

    updateTimer: function() {
      this.timer -= 1000;
      if (this.timer < 0) {
        window.clearInterval(this.timeoutController);
        this.timeoutController = null;
        return;
      }
      if(this.showDialog) {
        this.showEmergencyCbPrompt();
      }

      this.notificationTimer.textContent = this.timerString;
    },

    onDataError: function() {
      // TODO: We shold be able to confirm the error is caused by
      //       emergency callback mode before showing prompt.
      this.showEmergencyCbPrompt();
    },

    onEmergencyCbModeChange: function(evt) {
      var active = evt.active;
      if (active) {
        if (this.timeoutController) {
          window.clearInterval(this.timeoutController);
        }
        this.timer = evt.timeoutMs;
        this.displayNotificationAndToaster();
        this.timeoutController =
          window.setInterval(this.updateTimer.bind(this), 1000);
        for(let i = 0; i < this._conns.length; i++) {
          this._conns[i].ondataerror = this.onDataError.bind(this);
        }
      } else {
        this.hideNotificationIfDisplayed();
        window.clearInterval(this.timeoutController);
        Service.request('DialogService:hide', 'emergency-callback-prompt-dialog');//Defect11278944-modify by syang
        this.timeoutController = null;
        for(let i = 0; i < this._conns.length; i++) {
          this._conns[i].ondataerror = null;
        }
        this.restoreWifiOff();
      }
    }
  }, {
    timerString: {
      configurable: false,
      get: function() {
        var totalSec = this.timer / 1000;
        var min = Math.floor(totalSec / 60);
        var secString = (totalSec % 60).toString();
        var sec = secString.length > 1 ? secString : '0' + secString;
        // [GF7VZW-7489] begin added by zhichao.si, 2024-01-18
        if (totalSec < 0) {
          min = 0;
          sec = 0;
        }
        // [GF7VZW-7489] end added by zhichao.si, 2024-01-18
        return (min + ':' + sec);
      }
    }
  });
}());
