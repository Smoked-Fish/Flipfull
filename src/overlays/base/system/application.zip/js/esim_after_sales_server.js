/* exported EsimAfterSalesServer */
'use strict';

// IIFE (Immediately Invoked Function Expression) to create a local scope
(function (exports) {
  const DEFAULT_PORT = 8612;
  const INITIAL_RECONNECT_INTERVAL = 1000; // Initial reconnect interval in milliseconds
  const MAX_RECONNECT_INTERVAL = 30000; // Max reconnect interval in milliseconds
  const MAX_RECONNECT_ATTEMPTS = 10; // Max reconnect attempts

  /**
   * Constructor function for the EsimAfterSalesServer.
   * @param {object} options - Optional configuration object.
   */
  function EsimAfterSalesServer(options) {
    options = options || {};

    // Implement a simple event mechanism
    this._eventListeners = new Map();

    for (var option in options) {
      this[option] = options[option];
    }

    this.running = false;
    this.port = this.port || DEFAULT_PORT;
    // Initialize reconnect attempts and interval
    this.reconnectAttempts = 0;
    this.reconnectInterval = INITIAL_RECONNECT_INTERVAL;
  }

  /**
   * Add an event listener.
   * @param {string} event - The name of the event.
   * @param {function} callback - The callback function to be executed when the event is triggered.
   */
  EsimAfterSalesServer.prototype.addEventListener = function(event, callback) {
    if (!this._eventListeners.has(event)) {
      this._eventListeners.set(event, []);
    }
    this._eventListeners.get(event).push(callback);
  };

  /**
   * Remove an event listener.
   * @param {string} event - The name of the event.
   * @param {function} callback - The callback function to be removed.
   */
  EsimAfterSalesServer.prototype.removeEventListener = function(event, callback) {
    if (!this._eventListeners.has(event)) return;
    const stack = this._eventListeners.get(event);
    const index = stack.indexOf(callback);
    if (index > -1) stack.splice(index, 1);
  };

  /**
   * Dispatch an event to all registered listeners.
   * @param {object} event - The event object to be dispatched.
   * @returns {boolean} - Returns true if the event's default action has not been prevented.
   */
  EsimAfterSalesServer.prototype.dispatchEvent = function(event) {
    if (!this._eventListeners.has(event.type)) return true;
    const stack = this._eventListeners.get(event.type).slice();
    for (const listener of stack) {
      listener.call(this, event);
    }
    return !event.defaultPrevented;
  };

  /**
   * Start the server.
   */
  EsimAfterSalesServer.prototype.start = function () {
    if (this.running) {
      return;
    }
    this.running = true;
    this.reconnectAttempts = 0; // Reset reconnect attempts
    this._attemptStart();
  };

  /**
   * Attempt to start the server.
   * This function handles creating the TCP socket and setting up event listeners.
   */
  EsimAfterSalesServer.prototype._attemptStart = function() {
    dump('esim_after_sales EsimAfterSalesServer.prototype._attemptStart');
    var socket = navigator.mozTCPSocket.listen(this.port, {
      binaryType: 'arraybuffer',
      localAddress: '127.0.0.1'
    });

    socket.onconnect = (connectEvent) => {
      var clientSocket = connectEvent.socket || connectEvent;

      clientSocket.ondata = (event) => {
        var data = event.data;
        var dataString = arrayBufferToString(data);
        dump('esim_after_sales event.data' + event.data);
        dump('esim_after_sales event.data length' + event.data.byteLength);
        dump('esim_after_sales dataString:' + dataString);
        const CRLF = '\r\n';
        const requestParts = dataString.split(CRLF + CRLF);
        const header = requestParts.shift();
        // const body = requestParts.join(CRLF + CRLF);
        const headerLines = header.split(CRLF);
        const requestLine = headerLines.shift().split(' ');
        const method = requestLine[0];
        const uri = requestLine[1];
        const version = requestLine[2];

        dump('esim_after_sales method:' + method + ' uri:' + uri + ' version:' + version);
        // Fire the request event and pass data and socket
        var customEvent = new CustomEvent('request', {
          detail: {
            request: requestLine,
            socket: clientSocket
          }
        });
        this.dispatchEvent(customEvent);
      };

    };

    socket.onerror = (error) => {
      console.error('esim_after_sales Socket error:', error);
      this.running = false;
      this._scheduleReconnect();
    };

    socket.onclose = () => {
      console.warn('esim_after_sales The socket has closed unexpectedly.');
      this.running = false;
      this._scheduleReconnect();
    };

    this.socket = socket;
    dump(`esim_after_sales Esim After Sales Server is running at http://localhost:` + this.port);
  };

  /**
   * Schedule a reconnection attempt with exponential backoff.
   */
  EsimAfterSalesServer.prototype._scheduleReconnect = function() {
    if (this.reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
      console.error('esim_after_sales Maximum reconnect attempts reached. Giving up.');
      return;
    }

    const reconnectDelay = Math.min(this.reconnectInterval * Math.pow(2, this.reconnectAttempts), MAX_RECONNECT_INTERVAL);
    console.log('esim_after_sales Reconnecting in ' + reconnectDelay + ' ms...');
    setTimeout(() => {
      this.reconnectAttempts += 1;
      this._attemptStart();
    }, reconnectDelay);
  };

  /**
   * Stop the server.
   */
  EsimAfterSalesServer.prototype.stop = function () {
    if (!this.running) {
      return;
    }
    this.socket.close();
    this.running = false;
    dump('esim_after_sales prototype.stop');
  };

  /**
   * Convert an ArrayBuffer to a hexadecimal string.
   * @param {ArrayBuffer} buffer - The buffer to convert.
   * @returns {string} - The hexadecimal string.
   */
  function arrayBufferToHexString(buffer) {
    const uint8Array = new Uint8Array(buffer);
    return uint8Array.reduce((str, byte) => str + byte.toString(16).padStart(2, '0'), '');
  }

  /**
   * Convert an ArrayBuffer to a string.
   * @param {ArrayBuffer} arrayBuffer - The buffer to convert.
   * @returns {string} - The string representation of the buffer.
   */
  function arrayBufferToString(arrayBuffer) {
    try {
      dump('esim_after_sales arrayBufferToHexString' + arrayBufferToHexString(arrayBuffer));
      const decoder = new TextDecoder('utf-8');
      return decoder.decode(arrayBuffer);
    } catch (error) {
      dump('esim_after_sales decode error');
      return 'decode error';
    }
  }

  // Export the EsimAfterSalesServer to the global window object
  exports.EsimAfterSalesServer = EsimAfterSalesServer;
}(window));
