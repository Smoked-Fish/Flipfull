'use strict';
/* global WebActivity, FtuLauncher, InitLogoHandler, Service, AppOrigin
   SettingsObserver */

(function(exports) {

  /**
   * ExternalStorageMonitor listens to external storage(should be
   * insterted/removed SD card slot) for the volume chagne event.
   * According to the status activity, we use regular expression to indentify
   * storage actions.
   * @class ExternalStorageMonitor
   */
  function ExternalStorageMonitor() {
    // We will monitor external storage. And the external storage should be
    // removable.
    const storages = navigator.b2g.getDeviceStorages('sdcard');

    // If there are two storages, the name of first storage name is 'sdcard'.
    // But it's an internal storage. The storage name is mapping to
    // a hard code name. Because name of some external storages are different.
    // Such as, Flame: 'external', Helix: 'extsdcard'.
    // XXX: Bug 1033952 - Implement "isRemovable" API for device storage
    // Once "isRemovable" attribute is ready, we can remove the dirty check here
    storages.some(function(storage) {
      if (storage.storageName !== 'sdcard' && storage.canBeMounted &&
        !this._storage) {
        this._storage = storage;
      }

      if (storage.storageName === 'sdcard') {
        this._internalStorage = storage;
      }
    }.bind(this));
    window.dump('start storages.length ' + storages.length);
    if (!this._storage) {
      const deviceStorageAreaListener =
        navigator.b2g.deviceStorageAreaListener;
      if (deviceStorageAreaListener) {
        deviceStorageAreaListener.onstorageareachanged = () => {
          window.dump('onstorageareachanged');
          if (!this._storage) {
            const storages = navigator.b2g.getDeviceStorages('sdcard');
            window.dump('storages.length ' + storages.length);
            storages.some((storage) => {
              if (storage.storageName !== 'sdcard' && storage.canBeMounted) {
                this._storage = storage;
                this._storage.addEventListener('storage-state-change', this);
              }
            });
          }
        };
      }
    }
  }

  const DEFAULT_MEDIA_VOLUME_KEY = 'device.storage.writable.name';
  const INTERNAL_MEDIA_VOLUME_NAME = 'sdcard';
  const EXTERNAL_MEDIA_VOLUME_NAME = 'sdcard1';
  const SDCARD_DETECT_KEY = 'external-storage-detected';
  const RESET_JUST_ENTER_IDLE_STATUS_MILLISECONDS = 1000;

  ExternalStorageMonitor.prototype = {
    /**
     * A flag to identify the storage status has been into Idle(Unmounted).
     * We will use the flag to distinguish removal SD card manually or not.
     *
     * @memberof ExternalStorageMonitor.prototype
     * @type {Boolean}
     */
    justEnterIdleLessThanOneSecond: null,

    /**
     * An integer with the ID value of the timer that is set.
     * We will clean the timer if create a new timer.
     *
     * @memberof ExternalStorageMonitor.prototype
     * @type {Integer}
     */
    resetJustEnterIdleFlagTimer: null,

    /**
     * An variable for maintain the storage status.
     *
     * @memberof ExternalStorageMonitor.prototype
     * @type {Object}
     */
    _storage: null,

    /**
     * Listene to storage 'change' event.
     * @memberof ExternalStorageMonitor.prototype
     * @private
     */
    init: function() {
      window.removeEventListener('ftudone', this._init);
      window.removeEventListener('ftuskip', this._init);
      let sdcardDetect = false;
      if (!this._storage) {
        // set default media location to internal storage if needed
        this.resetDefaultMediaLocation();
        this.showStorageInfoIfNecessary(sdcardDetect);
      } else {
        this._storage.available().then((result) => {
          if (result === 'unavailable') {
            this.resetDefaultMediaLocation();
          } else { // 'shared' & 'available' and other cases
            sdcardDetect = true;
            var statusReq = this._storage.storageStatus();
            statusReq.onsuccess = statusReq.onerror = (evt) => {
              var curStorageStatus =  evt.target.result;
              this.enableStorageUnrecognised(curStorageStatus === 'Mount-Fail');
              this._storage.addEventListener('storage-state-change', this);
              var msg = '[ExternalStorageMonitor] initEvent(): ' +
                'monitor external storage name = ' +
                this._storage.storageName + ', canBeMounted = ' +
                this._storage.canBeMounted;
              this.debug(msg);
            };
          }
          this.showStorageInfoIfNecessary(sdcardDetect);
        });
      }
    },

    start: function() {
      this._init = this.init.bind(this);
      if (FtuLauncher.isFinished()) {
        if (!InitLogoHandler.finished) {
          window.addEventListener('logohidden', this._init);
        } else {
          this.init();
        }
      } else {
        window.addEventListener('ftudone', this._init);
        window.addEventListener('ftuskip', this._init);
      }
    },

    resetStorage: function() {
      if (!this._storage) {
        const storages = navigator.b2g.getDeviceStorages('sdcard');
        storages.some((storage) => {
          if (storage.storageName !== 'sdcard' && storage.canBeMounted &&
            !this._storage) {
            this._storage = storage;
          }

          if (storage.storageName === 'sdcard' && !this._internalStorage) {
            this._internalStorage = storage;
          }
        });
        if (!this._storage) {
          this.resetDefaultMediaLocation();
        }
      }
    },

    resetDefaultMediaLocation: function() {
      if (!this._internalStorage) {
        return;
      }
      var msg = '[ExternalStorageMonitor] resetDefaultMediaLocation ';
      this.debug(msg);
      Service.request('SettingsCore:get', DEFAULT_MEDIA_VOLUME_KEY)
        .then((value) => {
        if (value !== 'sdcard') {
          SettingsObserver.setValue([{
            name: DEFAULT_MEDIA_VOLUME_KEY,
            value: INTERNAL_MEDIA_VOLUME_NAME
          }]);
        }
      });
    },

    showStorageInfoIfNecessary: function(sdcardDetect) {
      const msg =
        '[ExternalStorageMonitor] showStorageInfoIfNecessary ' + sdcardDetect;
      this.debug(msg);
      window.asyncStorage.getItem(SDCARD_DETECT_KEY, (value) => {
        let lastDetectedTime = value;
        if (!lastDetectedTime && sdcardDetect) {
          window.asyncStorage.setItem(SDCARD_DETECT_KEY, Date.now());
          SettingsObserver.setValue([{
            name: DEFAULT_MEDIA_VOLUME_KEY,
            value: EXTERNAL_MEDIA_VOLUME_NAME
          }]);

          if (navigator.b2g.engmodeManager) {
            let self = this;
            navigator.b2g.engmodeManager.getPropertyValue('ro.boot.mmitest').then(
              value => {
                if (!value || value === 'false') {
                  Service.request('DialogService:hide', 'set-external-storage');
                  self .showSdcardDetectDialog();
                }
              });
          } else {
            Service.request('DialogService:hide', 'set-external-storage');
            this.showSdcardDetectDialog();
          }
        } else if (lastDetectedTime !== '' && !sdcardDetect) {
          window.asyncStorage.setItem(SDCARD_DETECT_KEY, '');
        }
      });
    },

    showSdcardDetectDialog: function() {
      const _ = window.api.l10n.get;
      Service.request('DialogService:show', {
        id: 'set-external-storage',
        header: _('storage'),
        content: _('set-sdcard-as-default-media-location'),
        translated: true,
        type: 'confirm',
        ok: 'ok',
        cancel: 'no',
        noClose: true,
        onCancel: () => {
          SettingsObserver.setValue([{
            name: DEFAULT_MEDIA_VOLUME_KEY,
            value: INTERNAL_MEDIA_VOLUME_NAME
          }]);
          Service.request('DialogService:hide', 'set-external-storage');
        },
        onOk: () => {
          Service.request('DialogService:hide', 'set-external-storage');
        }
      });
    },

    /**
     * Trigger a timer to set flag 'justEnterIdleLessThanOneSecond' be true.
     * We will use the flag to speculate the action of storage removal manually
     * or not.
     * @memberof ExternalStorageMonitor.prototype
     * @param {} str The value we are pushing in stack.
     */
    enableEnterIdleStateTimer: function() {
      this.justEnterIdleLessThanOneSecond = true;

      if (this.resetJustEnterIdleFlagTimer) {
        clearTimeout(this.resetJustEnterIdleFlagTimer);
      }

      // reset the flag after 1000 milliseconds
      this.resetJustEnterIdleFlagTimer = setTimeout(function() {
        this.justEnterIdleLessThanOneSecond = false;
      }.bind(this), RESET_JUST_ENTER_IDLE_STATUS_MILLISECONDS);
    },

    /**
     * Set settings key 'volume.external.unrecognised' to be boolean.
     * @memberof ExternalStorageMonitor.prototype
     * @type {Boolean}
     */
    enableStorageUnrecognised: function(enabled) {
      SettingsObserver.setValue([{
        name: 'volume.external.unrecognised',
        value: enabled
      }]).then(() => {
        var msg = '[ExternalStorageMonitor] set settings key onsuccess';
        this.debug(msg);
      }, (error) => {
        var msg = '[ExternalStorageMonitor] set settings key error:' + error;
        this.debug(msg);
      });
    },



    /**
     * Notify user what the storage is activate.
     * @memberof ExternalStorageMonitor.prototype
     * @param {title} str The string we show on the title of notification
     * @param {body} str The string we show on the body of notification
     */
    fireNotification: function(title, body, openSettings) {
      var iconUrl = `${AppOrigin.getOrigin('system')}/style/storage_status/` +
        `notification_sd_card.png`;
      // We always use tag "sdcard-storage-status" to manage these notifications
      var notificationId = 'sdcard-storage-status';

      var options = {
        body: body,
        icon: iconUrl,
        tag: notificationId
      };

      var notification = new Notification(title, options);

      // set onclick handler for the notification
      notification.onclick =
        this.notificationHandler.bind(this, notification, openSettings);
    },

    /**
     * Handle notification while it be triggered 'onclick' event.
     * @memberof ExternalStorageMonitor.prototype
     * @private
     */
    notificationHandler: function(notification, openSettings) {
      // close the notification
      notification.close();

      // request configure activity for settings media storage
      if (!openSettings) {
        return;
      }

      const activity = new WebActivity('configure', {
        target: 'device',
        section: 'mediaStorage'
      });
      activity.start();
    },

    /**
     * General event handler interface.
     * @memberof ExternalStorageMonitor.prototype
     * @param  {DOMEvent} evt The event.
     */
    handleEvent: function(e) {
      switch (e.type) {
        case 'storage-state-change':
          var storageStatus = e.reason;
          var msg = '[ExternalStorageMonitor] received ' +
                    '"storage-state-change" event ' +
                    'storageStatus = ' + storageStatus;
          this.debug(msg);

          // checking 'Idle' state for set flag on
          if (storageStatus === 'Idle') {
            this.enableEnterIdleStateTimer();
          } else if (storageStatus === 'Unmounting') {
            Service.request('DialogService:hide', 'set-external-storage');
            this.resetDefaultMediaLocation();
            window.asyncStorage.setItem(SDCARD_DETECT_KEY, '');
          } else if (storageStatus === 'Mounted') {
            window.asyncStorage.setItem(SDCARD_DETECT_KEY, Date.now());
          }
          break;
      }
    },

    /**
     * Get total space via the sum of the used space and free space.
     * @memberof ExternalStorageMonitor.prototype
     * @param {callback} function The callback will be run while get total space
     */
    getTotalSpace: function(callback) {
      var usedSpace, freeSpace;
      var self = this;
      this._storage.usedSpace().onsuccess = function(e) {
        usedSpace = e.target.result;
        self._storage.freeSpace().onsuccess = function(e) {
          freeSpace = e.target.result;
          var totalSpace = self.formatSize(usedSpace + freeSpace);
          if (callback) {
            callback(totalSpace);
          }
        };
      };
    },

    /**
     * Helper function to format the value returned by the
     * nsIDOMDeviceStorage.freeSpace call in a more readable way.
     * @memberof ExternalStorageMonitor.prototype
     * @param {size} bytes The size of specific storage space
     */
    formatSize: function(size) {
      if (size === undefined || isNaN(size)) {
        return;
      }

      var units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
      var i = 0;
      while (size >= 1024 && i < (units.length) - 1) {
        size /= 1024;
        ++i;
      }

      var sizeDecimal = i < 2 ? Math.round(size) : Math.round(size * 10) / 10;
      var _ = window.api.l10n.get;

      return {
        size: sizeDecimal,
        unit: _('byteUnit-' + units[i])
      };
    },

    /**
     * Dump console log for debug message.
     * @memberof ExternalStorageMonitor.prototype
     * @param {string} str The error message for debugging.
     */
    debug: function(msg) {
      window.DUMP(msg);
    }
  };

  exports.ExternalStorageMonitor = ExternalStorageMonitor;

}(window));
