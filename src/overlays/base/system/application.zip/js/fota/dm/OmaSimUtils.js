
/* eslint-disable max-len */
/*global SIMSlotManager  dump*/
/** This js was create is to execute VZW TF process A.D.D Process for 2 minutes when SIM swap. */

const VZW_SIM = [
    "310012", "310590", "310591", "310592", "310593",
    "310594", "310595", "310596", "310597", "310598", "310599", "310890", "311270", "311280", "311281",
    "311282", "311283", "311284", "311285", "311286", "311287", "311288", "311289", "311480", "311481",
    "311482", "311483", "311484", "311485", "311486", "311487", "311488", "311489"];

const VZW_ICCID_START = "891480";

const VZW_SIM_EXTRA_GID = ["20404gid1BAE0000000000000", "999480gid1D100000000000000"];

class OmaSimUtils {

    constructor() {

    }
    log(info) {
        dump('OmaSimUtils ==> : ' + info);
    }
    isVZWSimCard() {
        var iccInfo = SIMSlotManager.getSlots()?.[0].simCard?.iccInfo;
        if (!iccInfo) {
            this.log('the sim card iccinfo info is null');
            return false;
        }

        var mcc = iccInfo.mcc;
        var mnc = iccInfo.mnc;

        var mccmnc = mcc + mnc
        this.log('the mccmnc : ' + mccmnc);
        if (typeof mccmnc != 'string') {
            this.log('the mccmnc is not string: ' + mccmnc);
            return false;
        }

        if (VZW_SIM.includes(mccmnc.toLowerCase())) {
            this.log("mccmnc match, is vzw card");
            return true;
        }

        var iccid = iccInfo.iccid;
        this.log('check iccid');
        if (typeof iccid === "string" && iccid.startsWith(VZW_ICCID_START)) {
            this.log("iccid match 891480, is vzw card");
            return true;
        }

        var gid1 = iccInfo.gid1;
        this.log('check gid1');
        var mccmncgid1 = mccmnc + "gid1" + gid1;
        if (VZW_SIM_EXTRA_GID.includes(mccmncgid1.toLowerCase())) {
            this.log("this is a special vzw card!");
            return true;
        }
        this.log("is not a vzw card!");
        return false;

    }
}

