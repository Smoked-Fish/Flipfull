/* eslint-disable max-len */
/*global SettingsObserver SIMSlotManager AlarmMessageHandler dump OmaSimUtils*/
/** This js was create is to execute VZW TF process A.D.D Process for 2 minutes when SIM swap. */
'use strict';

/**
 * The time interval of ADD process when power on
 */
const TIME_OF_ADD_INTERVAL = 2 * 60 * 1000;
const TIME_OF_ADD_RETRY = 60 * 1000;

const ADD_ALARM_TYPE = "VZW_ADD_ALARM_TYPE";
const AlarmTypes = [ADD_ALARM_TYPE];

function omadmdebug(info) {
    dump("oma_add ==>  " + info);
}
var ADDUpdate = {
    simUtils: new OmaSimUtils(),
    omaservice: null,
    addAlarm: async function (alarmType, timeInterval) {
        var self = this;
        omadmdebug('addAlarm Entry alarmType: ' + alarmType + ", timeInterval: " + timeInterval);
        if (!AlarmTypes.includes(alarmType)) {
            omadmdebug('has not used such type alarm alarmType: ' + alarmType);
            return;
        }
        if (isNaN(timeInterval) || timeInterval <= 0) {
            omadmdebug("addAlarm timeInterval is not speciy!");
            return;
        }
        var schedule = 0;
        await self.removeExistAlarm(alarmType);
        omadmdebug('addAlarm type: ' + alarmType + ', timeInterval: ' + timeInterval);
        schedule = Date.now() + Number(timeInterval);
        var at = new Date(schedule);
        omadmdebug('the alarm will be dispatched at: ' + at.toLocaleString());
        await navigator.b2g.alarmManager.add({
            date: at,
            data: { fotaAlarmType: alarmType },
            ignoreTimezone: false,
        });
    },

    removeExistAlarm: async function (type) {
        omadmdebug('removeExistAlarm Entry alarmType: ' + type);
        if (!AlarmTypes.includes(type)) {
            omadmdebug('has not used such type alarm : ' + type);
            return false;
        }
        if (!navigator.b2g || !navigator.b2g.alarmManager) {
            omadmdebug("removeExistAlarm alarmManager is null");
            return false;
        }
        var result = await navigator.b2g.alarmManager.getAll();
        for (let i = 0; i < result.length; i++) {
            if (result[i]?.data?.fotaAlarmType === type) {
                navigator.b2g.alarmManager.remove(result[i].id);
                omadmdebug('removeExistAlarm : ' + type + ' removed.');
                return true;
            }
        }
        return false;
    },

    handleAlarm: function (alarmType) {
        var self = this;
        omadmdebug("handleAlarm Entry.");
        if (alarmType) {
            omadmdebug('handleAlarm type is : ' + alarmType);
            switch (alarmType) {
                case ADD_ALARM_TYPE:
                    self.handleADDProgress_2Minute();
                    break;
                default:
                    omadmdebug('no such alarmType');
                    break;
            }
        }
        return;
    },

    checkSIMChange: async function () {
        var self = this;
        if (!self.simUtils.isVZWSimCard()) {
            omadmdebug("checkSIMChange, sim card is not vzw, ignore!");
            return;
        }
        let currentIccid = '';
        var primarySimSlot = SIMSlotManager.getSlots()[0];
        const simCard = primarySimSlot.simCard;
        if (simCard && simCard !== 'unknown') {
            if (simCard.iccInfo) {
                currentIccid = simCard.iccInfo.iccid;
            }
        } else {
            omadmdebug('checkSIMChange, sim card is not exist. ');
            return;
        }
        let oldICCID = await SettingsObserver.getValue('exist_iccid_inlocalstorage');
        if (currentIccid != '' && oldICCID != currentIccid) {
            omadmdebug('checkSIMChange , new sim card and do ADD progress.');
            self.addAlarm(ADD_ALARM_TYPE, TIME_OF_ADD_INTERVAL);
            SettingsObserver.setValue([{
                name: 'exist_iccid_inlocalstorage',
                value: currentIccid
            }]);
        } else {
            omadmdebug('checkSIMChange , sim card is not swapped, do nothing.');
        }
    },

    /**
     * Whether has NI received!
     */
    _isNIReceived: false,

    /**
     *ADD error times.
     */
    ADD_run_times: 0,

    handleADDProgress_2Minute: function () {
        var self = this;
        omadmdebug('handleADDProgress_2Minute Entry.');
        self.removeExistAlarm(ADD_ALARM_TYPE);
        if (self._isNIReceived) {
            omadmdebug('handleADDProgress_2Minute , NI has been received.');
            return;
        }
        if (self.ADD_run_times >= 3) {
            omadmdebug('handleADDProgress_2Minute, retry much times. ignore');
            return;
        }
        if (!self.simUtils.isVZWSimCard()) {
            omadmdebug('handleADDProgress_2Minute, is not vzw. ignore');
            return;
        }
        self.ADD_run_times++;
        self.checkIfFotaAvailable();
    },

    checkIfWifiAvailable: function () {
        omadmdebug('checkIfWifiAvailable Entry.');
        var isWifiAvailable = false;
        var wifiManager = window.navigator.b2g.wifiManager;
        if (wifiManager) {
            omadmdebug('checkIfWifiAvailable Entry wifiManager.connection.status =' + wifiManager.connection.status);
            if (wifiManager.connection && wifiManager.connection.status && wifiManager.connection.status === 'connected') {
                omadmdebug('wifiManager.connection.status === connected');
                isWifiAvailable = true;
            } else {
                omadmdebug('wifiManager.connection.status === disconnected');
                isWifiAvailable = false;
            }
        } else {
            omadmdebug('create wifiManager object failed.');
            isWifiAvailable = false;
        }
        omadmdebug('checkIfWifiAvailable: ' + isWifiAvailable);
        return isWifiAvailable;
    },

    checkIfDataAvailable: async function () {
        var isDataAvailable = false;
        omadmdebug('checkIfDataAvailable Entry.');
        var dataManager = window.navigator.mozMobileConnection || window.navigator.b2g.mobileConnections
            && window.navigator.b2g.mobileConnections[0];
        if (dataManager) {
            if (dataManager.data.state == 'registered') {
                var allowRomaing = await SettingsObserver.getValue('vzw_fota_current_allow_roaming');
                allowRomaing = allowRomaing == true;
                var isRoaming = !allowRomaing && dataManager.data.roaming;
                omadmdebug('data is connected, isRoaming:' + isRoaming);
                if (isRoaming) {
                    isDataAvailable = false;
                } else {
                    isDataAvailable = true;
                }
            } else {
                omadmdebug('data is disconnected');
                isDataAvailable = false;
            }
        } else {
            omadmdebug('create dataManager object failed.');
            isDataAvailable = false;
        }
        omadmdebug('checkIfDataAvailable: ' + isDataAvailable);
        return isDataAvailable;
    },

    checkNetworkAvailable: async function () {
        var self = this;
        omadmdebug('checkNetworkAvailable Entry.');
        if (self.checkIfWifiAvailable()) {
            omadmdebug('checkNetworkAvailable: wifi');
            return true;
        }
        if (await self.checkIfDataAvailable()) {
            omadmdebug('checkNetworkAvailable: data');
            return true;
        }
        omadmdebug('checkNetworkAvailable: false');
        return false;
    },

    _isADDProcesing: false,

    _isPendingCI: false,

    checkIfFotaAvailable: async function () {
        var self = this;
        omadmdebug('checkIfFotaAvailable Entry');
        let dmstate = self.omaservice.getEngineDMState;
        omadmdebug('checkIfFotaAvailable , current dm state = ' + dmstate);
        if (dmstate != 'NoAction') {
            omadmdebug('checkIfFotaAvailable , already started dm session,no need to ADD progress.');
            return;
        }
        let isNetworkOK = await self.checkNetworkAvailable();
        if (!isNetworkOK) {
            omadmdebug('checkIfFotaAvailable the network is not availabe.');
            self._isPendingCI = true;
            self.addNetworkChangeListener();
            return;
        }
        self._isPendingCI = false;
        let isWifi = self.checkIfWifiAvailable();
        omadmdebug('checkIfFotaAvailable start DM with wifi:' + isWifi);
        self._isADDProcesing = true;
        self.omaservice.checkForFOTA({ type: 'CI', vDate: '200' }, self.onCheckIfFotaAvailableCb.bind(self));
    },

    onCommonCb: function (cmd, isSuccess, errorType) {
        var self = this;
        isSuccess = isSuccess != false && isSuccess != "false";
        omadmdebug('onCommonCb Entry cmd: ' + cmd + ' isSuccess: ' + isSuccess + ' errorType: ' + errorType);
        switch (cmd) {
            case 'CheckIfFotaAvailable':
                if (!isSuccess && self._isADDProcesing) {
                    omadmdebug('The init the add omasession error, retry.');
                    self.addAlarm(ADD_ALARM_TYPE, TIME_OF_ADD_RETRY);
                }
                self._isADDProcesing = false;
                break;
            default:
                omadmdebug('no such action type.');
                break;
        }
    },

    onCheckIfFotaAvailableCb: function (sessiontype, ddfile) {
        omadmdebug('onCheckIfFotaAvailableCb Entry, dm status:' + self.omaservice.getEngineDMState
            + ', sessiontype:' + sessiontype + ', ddfile: ' + ddfile);
    },

    onFotaDownloadProgressCb: function fota_DownloadProgressCb(completionRate) {
        omadmdebug('onFotaDownloadProgressCb Entry Completion rate:  ' + completionRate);
    },

    onFotaExecConfirm: function () {
        var self = this;
        var result = result = { isAllow: false, isAllowExtStr: "DM_Client_NO_SUPPORT" };
        omadmdebug("onFotaExecConfirm result: " + result?.isAllow + ", isAllowExtStr: " + result?.isAllowExtStr);
        self.omaservice.execAllowConfirm(result);
    },

    onFotaDMStatusChange: function (status) {
        var self = this;
        omadmdebug("onFotaDMStatusChange Entry : status =" + status);
        switch (status) {
            case 'CheckIfFotaAvailable':
            case 'receiveNIA':
                self._isNIReceived = true;
                break;
            case 'ExecConfirm':
                self.onFotaExecConfirm();
                break;
            case 'NetworkErrFatal':
            case 'NetworkErr':
            case 'invalidDD':
            case 'UpdateConfirm':
            case 'NoAction':
            case 'AuthErr':
            case 'noUpdate':
            default:
                break;
        }
    },

    networkTimerId: null,
    startADDWhenNetworkAvailable: function () {
        omadmdebug("startADDWhenNetworkAvailable entry!");
        var self = this;
        if (self.networkTimerId) {
            window.clearTimeout(self.networkTimerId);
            self.networkTimerId = null;
        }
        if (self._isPendingCI && !self._isNIReceived) {
            omadmdebug("startADDWhenNetworkAvailable start one timer");
            self.networkTimerId = window.setTimeout(() => {
                omadmdebug("startADDWhenNetworkAvailable start ADD process");
                self.checkIfFotaAvailable();
            }, 5 * 1000);
        }
        self.removeNetworkChangeListener();
    },

    handleNetworkChange: async function () {
        var self = ADDUpdate;
        omadmdebug("handleNetworkChange Entry");
        let isNetworkAvailable = await self.checkNetworkAvailable();
        if (!isNetworkAvailable) {
            omadmdebug("handleNetworkChange network is not ready!");
            return;
        }
        self.startADDWhenNetworkAvailable();
    },

    addNetworkChangeListener_isAdd: false,
    addNetworkChangeListener: function () {
        var self = this;
        if (self.addNetworkChangeListener_isAdd) {
            omadmdebug("addNetworkChangeListener already add.");
            return;
        }
        omadmdebug('addNetworkChangeListener Entry.');
        window.addEventListener('wifi-statuschange', self.handleNetworkChange);
        var dataManager = window.navigator.mozMobileConnection ||
            (window.navigator.b2g.mobileConnections && window.navigator.b2g.mobileConnections[0]);
        if (dataManager) {
            dataManager.addEventListener('datachange', self.handleNetworkChange);
        }
        self.addNetworkChangeListener_isAdd = true;
    },
    removeNetworkChangeListener: function () {
        var self = this;
        omadmdebug('removeNetworkChangeListener Entry.');
        self.addNetworkChangeListener_isAdd = false;
        window.removeEventListener('wifi-statuschange', self.handleNetworkChange);
        var dataManager = window.navigator.mozMobileConnection ||
            (window.navigator.b2g.mobileConnections && window.navigator.b2g.mobileConnections[0]);
        if (dataManager) {
            dataManager.removeEventListener('datachange', self.handleNetworkChange);
        }
    },

    init: async function () {
        omadmdebug("init retry.");
        const self = this;
        self.omaservice = navigator?.b2g?.OmaService;
        if (!self.omaservice) {
            omadmdebug("The omaservice is null, so ignore!");
            return;
        }
        self.omaservice.initFota(
            self.onCommonCb.bind(self),
            self.onCheckIfFotaAvailableCb.bind(self),
            self.onFotaDownloadProgressCb.bind(self)
        );

        self.omaservice.onFotaDMStatusChange = (event) => {
            let status = event.status;
            omadmdebug("navigator.OmaService.onFotaDMStatusChange: status = " + status);
            self.onFotaDMStatusChange(status);
        };
        await self.removeExistAlarm(ADD_ALARM_TYPE);
        AlarmMessageHandler.addCallback((message) => {
            omadmdebug('AlarmMessageHandler call back. message:' + message?.data?.fotaAlarmType);
            if (message.data && AlarmTypes.includes(message.data.fotaAlarmType)) {
                self.handleAlarm(message.data.fotaAlarmType);
            }
        });
        setTimeout(self.checkSIMChange.bind(self), 30 * 1000);
    },
};

ADDUpdate.init();