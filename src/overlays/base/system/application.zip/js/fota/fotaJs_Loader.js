/* global LazyLoader */
'use strict';

const fotaJS_Loader_debugTag = 'JrdFotaSystem: JsLoader';

const fotaLoader = {
  operatorName: 'TF',
  init: function fs_init() {
    const self = this;
    navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name')
      .then((value) => {
        console.debug(fotaJS_Loader_debugTag + ', operatorName=' + value);
        self.operatorName = value;
        self.loadJs();
      });
  },
  loadJs: function fs_loadJs() {
    const self = this;
    if (self.operatorName === 'VZW') {
      self.loadOMADM();
    } else {
      self.loadJrdFota();
    }
  },
  loadOMADM: function () {
    LazyLoader.load([
      'js/vzwfumoUpdate.js'
    ], function () {
      console.debug(fotaJS_Loader_debugTag + ', vzwfumo related files loaded.');
    });
  },
  loadJrdFota: function () {
    //注意顺序，被引用的JS文件需要先加载...
    LazyLoader.load([
      'js/fota/jrd/jrd_logger.js',
      'js/fota/jrd/JrdConstant.js',
      'js/fota/jrd/JrdLock.js',
      'js/fota/jrd/JrdPhoneCall.js',
      'js/fota/jrd/JrdDatabase.js',
      'js/fota/jrd/JrdNetwork.js',
      'js/fota/jrd/JrdRequest.js',
      'js/fota/jrd/JrdBattery.js',
      'js/fota/jrd/JrdGecko.js',
      'js/fota/jrd/JrdUtils.js',
      'js/fota/dm/OmaSimUtils.js',
      'js/fota/dm/vzwADDUpdate.js',
      'js/fota/jrd/JrdAlarm.js',
      'js/fota/jrd/JrdDialog.js',
      'js/fota/jrd/JrdLauncher.js',
      'js/fota/jrd/JrdNotification.js',
      'js/fota/jrd/JrdReport.js',
      'js/fota/jrd/JrdFotaUpdateAB.js',
    ], function () {
      console.debug(fotaJS_Loader_debugTag + ', load jrd done.');
    });
  },
};

fotaLoader.init();
