'use strict';
/* exported JrdAlarm */
/* global AlarmMessageHandler */
/* global JrdUtils */
/* global JrdDatabase */
/* global JrdAlarmType,  */

const TIME_ONE_SECOND = 1000;
const TIME_ONE_MIN = 60 * TIME_ONE_SECOND;
const TIME_ONE_HOUR = 60 * TIME_ONE_MIN;
const TIME_ONE_DAY = 24 * TIME_ONE_HOUR;

const JrdAlarm = {
  log: window.JrdLogger.createLogger('#Alarm'),
  //--------------------- common begin ----------------------------------------
  getDIInterval: function () {
    const self = this;
    const testAlmDI = JrdDatabase.getTestAlmDI();
    let interval = TIME_ONE_DAY;
    if (testAlmDI && testAlmDI === true) {
      interval = 3 * TIME_ONE_MIN;
    }
    self.log.i('getDIInterval, testAlmDI=' + testAlmDI + ', interval=' + interval);
    return interval;
  },
  getRebootInterval: function () {
    const self = this;
    const testAlmRestart = JrdDatabase.getTestAlmRestart();
    let interval = 8 * TIME_ONE_HOUR;
    if (testAlmRestart && testAlmRestart === true) {
      interval = TIME_ONE_MIN;
    }
    self.log.i('getRebootInterval, testAlmRestart=' + testAlmRestart + ', interval=' + interval);
    return interval;
  },
  //-----------------------------------------------------------------------------
  getAlarmManager: function () {
    const self = this;
    let manager = null;
    if (navigator.b2g && navigator.b2g.alarmManager) {
      manager = navigator.b2g.alarmManager;
    }
    if (!manager) {
      self.log.i('addAlarm., manager is null.');
      return null;
    }
    return manager;
  },
  addAlarm: async function (type, interval) {
    const self = this;
    self.log.i('addAlarm, alarmType:' + type + ', interval:' + interval);
    const remove = await self.removeExistAlarm(type);
    self.log.i('addAlarm, remove:' + remove);
    const schedule = Date.now() + Number(interval);
    const at = new Date(schedule);
    self.log.i('addAlarm, ' + type + ' will be dispatched at: ' + at);
    const manager = self.getAlarmManager();
    if (!manager) {
      self.log.i('addAlarm, manager is null.');
      return;
    }
    await manager.add({
      date: at,
      data: {fotaAlarmType: type},
      ignoreTimezone: true,
    }).then(() => {
        self.log.i('addAlarm, ' + type + ' success.');
      },
      (err) => {
        self.log.i('addAlarm, ' + type + ' failed, dues to: ' + err);
      });
  },
  removeExistAlarm: async function (type) {
    const self = this;
    self.log.i('removeExistAlarm, type:' + type);
    const manager = self.getAlarmManager();
    if (!manager) {
      self.log.i('removeExistAlarm, manager is null.');
      return false;
    }
    const allAlarm = await manager.getAll();
    if (!allAlarm) {
      self.log.i('removeExistAlarm, allAlarm is null.');
      return false;
    }
    for (let i = 0; i < allAlarm.length; i++) {
      const msg = allAlarm[i];
      if (msg.data.fotaAlarmType === type) {
        manager.remove(msg.id);
        self.log.i('removeExistAlarm, msg: ' + JrdUtils.string(msg));
      }
    }
    return true;
  },
  getAlarmMsg: async function (type) {
    const self = this;
    self.log.i('getAlarmMsg, type:' + type);
    const manager = self.getAlarmManager();
    if (!manager) {
      self.log.i('getAlarmMsg, manager is null.');
      return '';
    }
    const allAlarm = await manager.getAll();
    if (!allAlarm) {
      self.log.i('getAlarmMsg, all alarm is null.');
      return '';
    }
    for (let i = 0; i < allAlarm.length; i++) {
      const msg = allAlarm[i];
      if (msg.data.fotaAlarmType === type) {
        return msg;
      }
    }
    return '';
  },
  //--------------------- common end ------------------------------------------
  init: function (handleAlarmCb) {
    const self = this;
    self.log.i('init.');
    AlarmMessageHandler.addCallback((msg) => {
      if (!msg || !msg.data) {
        self.log.i('alarm call, msg is null.');
      }
      self.log.i('alarm call, msg: ' + JrdUtils.string(msg));
      let type = msg.data.fotaAlarmType;
      const myAlarm = type === JrdAlarmType.DI ||
        type === JrdAlarmType.POSTPONE_REBOOT ||
        type === JrdAlarmType.AUTO_REBOOT;
      if (myAlarm) {
        handleAlarmCb(type);
      }
    });
    window.addEventListener('timechange', function () {
      setTimeout(() => {
        //  avoid to be called with handleAlarm in a very close time.
        self.initAutoCheckAlarm('time change').then();
      }, 2000);
    });
  },
  initAutoCheckAlarm: async function (reason = 'init') {
    const self = this;
    const msg = await self.getAlarmMsg(JrdAlarmType.DI);
    self.log.i(`initAutoCheckAlarm, reason=${reason} msg=${JrdUtils.string(msg)}`);
    if (msg === '') {
      self.addAlarmDI24Hour();
    } else {
      const alarmTime = (new Date(msg.date)).getTime();
      const nowTime = (new Date()).getTime();
      const gap = alarmTime - nowTime;
      const interval = this.getDIInterval();
      self.log.i('initAutoCheckAlarm, ' + gap + '/' + interval);
      if (gap < 0 || gap > interval) {
        self.addAlarmDI24Hour();
      }
    }
  },
  addAlarmDI24Hour: function () {
    const self = this;
    const interval = this.getDIInterval();
    self.log.i('addAlarmDI24Hour, interval=' + interval);
    self.addAlarm(JrdAlarmType.DI, interval).then();
  },
  addAlarmPostponeReboot: function () {
    const self = this;
    const interval = this.getRebootInterval();
    self.log.i('addAlarmPostponeReboot, interval=' + interval);
    self.addAlarm(JrdAlarmType.POSTPONE_REBOOT, interval).then();
  },
  removeAlarmPostponeReboot: function () {
    const self = this;
    self.log.i('removeAlarmPostponeReboot.');
    self.removeExistAlarm(JrdAlarmType.POSTPONE_REBOOT).then();
  },
  addAlarmAutoReboot: function (interval) {
    const self = this;
    self.log.i('addAlarmAutoReboot, interval:' + interval);
    self.addAlarm(JrdAlarmType.AUTO_REBOOT, interval).then();
  },
  removeAlarmAutoReboot: function () {
    const self = this;
    self.log.i('removeAlarmAutoReboot.');
    self.removeExistAlarm(JrdAlarmType.AUTO_REBOOT).then();
  },
};
