'use strict';
/* exported JrdBattery */

const JrdBattery = {
  log: window.JrdLogger.createLogger('#Battery'),
  battery: null,
  batteryCallbacks: [],
  initBattery(callback) {
    const self = this;
    self.log.i('initBattery, enter.');
    self.addBatteryChangedCallback(callback);
    self.bindBatteryChanged = self.handlerBatteryChanged.bind(self);
    window.navigator.getBattery().then(battery => {
      self.battery = battery;
      self.battery.addEventListener('levelchange', self.bindBatteryChanged);
    });
  },
  addBatteryChangedCallback(callback) {
    const self = this;
    if (callback && typeof callback == 'function') {
      self.batteryCallbacks.push(callback);
    }
  },
  handlerBatteryChanged: function () {
    const self = this;
    const level = self.getBatteryLevel();
    for (let i = 0; i < self.batteryCallbacks.length; i++) {
      const callback = self.batteryCallbacks[i];
      if (callback && typeof callback == 'function') {
        callback(level);
      }
    }
  },
  getBatteryLevel() {
    const self = this;
    self.log.i('getBatteryLevel, battery=' + self.battery);
    const fLevel = (self.battery && self.battery.level) ? self.battery.level : 0;
    const level = fLevel * 100;
    self.log.i('getBatteryLevel, level=' + level);
    return level;
  },
};
