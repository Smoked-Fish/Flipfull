'use strict';
/* exported JrdOperator */
/* exported JrdState */
/* exported JrdLimit */
/* exported JrdEGStatusCode */
/* exported JrdEGErrorCode */
/* exported JrdSlotStatus */
/* exported JrdProperties */
/* exported JrdDb */
/* exported JrdUiCb */
/* exported JrdNetworkState */
/* exported JRD_BATTERY_LEVEL_LIMIT */
/* exported JrdUi */
/* exported JrdDi */
/* exported JrdUiRes */
/* exported JrdAlarmType */
/* exported JrdHttp */
/* exported JrdDlError */
/* exported JrdDlNetwork */

const JrdNetworkState = {
  DATA_CONNECTED: 'data_connected',
  DATA_DISCONNECTED: 'data_disconnected',
  WIFI_CONNECTED: 'wifi_connected',
  WIFI_DISCONNECTED: 'wifi_disconnected',
  ROAMING: 'roaming',
};

const JrdOperator = {
  TMO: 'TMO',
  TMO_MetroPCS: 'MetroPCS',
  TMO_ASW: 'ASW',
  TF: 'TF',
  EE: 'EE',
  VZW: 'VZW',
  DISH: 'DISH',
  USCC: 'USCC',
};

const JrdState = {
  IDLE: 'IDLE',
  CHECKED: 'CHECKED',
  DOWNLOADING: 'DOWNLOADING',
  DOWNLOADED: 'DOWNLOADED',
  INSTALLING: 'INSTALLING',
  INSTALLED: 'INSTALLED',
};

const JrdLimit = {
  PASS: 'PASS',
  LOW_BATTERY: 'LOW_BATTERY',
  LOW_STORAGE: 'LOW_STORAGE',
  CELLULAR_SIZE: 'CELLULAR_SIZE',
};

//1、download [TF]；2、install；3、reboot
const JRD_BATTERY_LEVEL_LIMIT = 30;

const JrdEGStatusCode = {
  IDLE: 0,
  CHECKING_FOR_UPDATE: 1,
  UPDATE_AVAILABLE: 2,
  DOWNLOADING: 3,
  VERIFYING: 4,
  FINALIZING: 5,
  UPDATED_NEED_REBOOT: 6,
  REPORTING_ERROR_EVENT: 7,
  ATTEMPTING_ROLLBACK: 8,
  DISABLED: 9,
  INSTALL_PAUSE: 10,
  CLEAR_PREVIOUS: 11,
};

const JrdEGErrorCode = {
  DEFAULT: -1, // fota app define
  SUCCESS: 0,
  ERROR: 1,
  FILESYSTEM_COPIER_ERROR: 4,
  POST_INSTALL_RUNNER_ERROR: 5,
  PAYLOAD_MISMATCHED_TYPE_ERROR: 6,
  INSTALL_DEVICE_OPEN_ERROR: 7,
  KERNEL_DEVICE_OPEN_ERROR: 8,
  DOWNLOAD_TRANSFER_ERROR: 9,
  PAYLOAD_HASH_MISMATCH_ERROR: 10,
  PAYLOAD_SIZE_MISMATCH_ERROR: 11,
  DOWNLOAD_PAYLOAD_VERIFICATION_ERROR: 12,
  USER_CANCELED: 48,
  PAYLOAD_TIMESTAMP_ERROR: 51,
  UPDATED_BUT_NOT_ACTIVE: 52,
  NOT_ENOUGH_SPACE: 60,
  DEVICE_CORRUPTED: 61,
  UNKNOWN: 999,
};

const JrdSlotStatus = {
  CUR_SLOT_IS_EMPTY: 1,
  CUR_SLOT_NOT_CHANGE: 2,
  CUR_SLOT_CHANGED: 3,
};

const JrdProperties = {
  OPERATOR: 'ro.operator.name',
  CU: 'ro.tct.curef',
  TCT_VERSION: 'ro.tct.ver.system',
  VEN_VERSION: 'ro.vendor.tct.ver.vendor',
  SLOT: 'ro.boot.slot_suffix',
};

const JrdDb = {
  UPDATE_INFO: 'JRD_UPDATE_INFO',
  STATUS: 'JRD_CONST_STATUS',
  DOWNLOAD_LOW_BATTERY: 'JRD_CONST_DOWNLOAD_LOW_BATTERY',
  POSTPONE_SHOW_TIMES: 'JRD_CONST_POSTPONE_SHOW_TIMES',
  CONFIG_AUTO_DOWNLOAD: 'JRD_CONST_CONFIG_AUTO_DOWNLOAD',
  EG_WAIT_REBOOT: 'JRD_CONST_EG_WAIT_REBOOT',
  BOOT_SLOT: 'JRD_CONST_BOOT_SLOT',
  BOOT_VERSION: 'JRD_CONST_BOOT_VERSION',
  AUTO_REBOOT: 'JRD_CONST_AUTO_REBOOT',
  REBOOT_TIME: 'JRD_CONST_REBOOT_TIME',
  TEST_LOW_BATTERY: 'JRD_CONST_TEST_LOW_BATTERY',
  TEST_LOW_STORAGE: 'JRD_CONST_TEST_LOW_STORAGE',
  TEST_ROAMING: 'JRD_CONST_TEST_ROAMING',
  TEST_ALM_DI: 'JRD_CONST_TEST_ALM_DI',
  TEST_ALM_RESTART: 'JRD_CONST_TEST_ALM_RESTART',
  INSTALL_PROGRESS: 'JRD_CONST_INSTALL_PROGRESS',
  TEST_KEEP_STATE_ON_INSTALL_FAIL: 'JRD_CONST_TEST_KEEP_STATE_ON_INSTALL_FAIL',
  NEW_VERSION_JSON: 'JRD_CONST_NEW_VERSION_JSON',
  DOWNLOAD_INFO_JSON: 'JRD_CONST_DOWNLOAD_INFO_JSON',
  HAS_BOOT_UP: 'JRD_HAS_BOOT_UP',
};

const JrdUiCb = {
  NETWORK_CHANGE: 'JRD_UI_CB_NETWORK_CHANGE',
  CHECK: 'JRD_UI_CB_CHECK',
  DOWNLOAD: 'JRD_UI_CB_DOWNLOAD',
  INSTALL: 'JRD_UI_CB_INSTALL',
};

const JrdUi = {
  CHECK: 'JRD_UI_CHECK',
  DOWNLOAD: 'JRD_UI_DOWNLOAD',
  DOWNLOAD2: 'JRD_UI_DOWNLOAD2',
  INSTALL: 'JRD_UI_INSTALL',
  REBOOT: 'JRD_UI_REBOOT',
  LATER: 'JRD_UI_LATER',
  RESET: 'JRD_UI_RESET',
  TEST_FUN: 'JRD_UI_TEST_FUN',
};

const JrdDi = {
  CHECK: 'JRD_DI_CHECK',
  DOWNLOAD: 'JRD_DI_DOWNLOAD',
  INSTALL: 'JRD_DI_INSTALL',
  REBOOT: 'JRD_DI_REBOOT',
};

const JrdUiRes = {
  SUCCESS: 'success',
  FAILED: 'failed',
  NETWORK_ERROR: 'network_error',
  AUTO_DOWNLOAD: 'auto_download',
  INSTALLING: 'installing',
};

const JrdAlarmType = {
  DI: 'JRD_ALARM_DI',
  POSTPONE_REBOOT: 'JRD_ALARM_POSTPONE_REBOOT',
  AUTO_REBOOT: 'JRD_ALARM_AUTO_REBOOT',
};

const JrdHttp = {
  SUCCESS: 200,
  NO_CONTENT: 204,
  NO_TO_VERSION: 205,
  NO_CU_OR_FROM_VERSION: 207,
  BAD_REQUEST: 400,
  NOT_FOUND: 404,
  SERVER_ERROR_START: 500,
  SERVER_ERROR_END: 599,
};

const JrdDlError = {
  NETWORK: 'NetworkError',
  TIMEOUT: 'TimeOutError',
  CHECKSUM: 'ChecksumError',
  NO_PACKAGE_RESOURCE: 'PackageNotFoundFromServer',
};

const JrdDlNetwork = {
  WIFI_AUTO: 0,
  WIFI_AND_CELLULAR: 1,
  WIFI_ONLY: 2,
};

const JrdPkgSize = {
  LIMIT_1GB: 1024 * 1024 * 1024,
  LIMIT_3GB: 3 * 1024 * 1024 * 1024,
};

