'use strict';
/* exported JrdDatabase */
/* global SettingsObserver */
/* global JrdUtils */
/* global JrdLock */
/* global JrdDb */
/* global JrdProperties */
/* global BrowserUtils */

/* global JrdUiCb */

const JrdDatabase = {
  log: window.JrdLogger.createLogger('#Database'),
  observedSettings: {},
  settingValues: {},
  systemProperties: {},
  //-------------------- common ----------------------------------
  setValue: function (name, value) {
    const self = this;
    self.settingValues[name] = value;

    async function write() {
      await SettingsObserver.setValue([{name: name, value: value}]);
    }

    write().then();
  },
  getValue: function (name) {
    return SettingsObserver.getValue(name);
  },
  observe: function (name, defaultValue, callback, observerOnly) {
    const self = this;
    self.log.i(`observer, name=${name}, defaultValue=${JrdUtils.string(defaultValue)}`);
    SettingsObserver.observe(name, defaultValue, callback, observerOnly);
  },
  //-------------------- common ----------------------------------
  //--------------------  base  ----------------------------------
  init: async function () {
    const self = this;
    self.log.i(`init database, begin.`);
    self.lock = new JrdLock();
    const settingKeys = [...Object.values(JrdDb)];
    const settingPromises = settingKeys.map(key => self.getValue(key));
    try {
      const settingValues = await Promise.all(settingPromises);
      settingValues.forEach((value, index) => {
        self.addSettings(settingKeys[index], value);
      });
    } catch (e) {
      self.log.i(`Error during settings collection: ${e}`);
    }
    await self.addSystemProperties();
    self.log.i(`init database, done.`);
  },
  addSettings: function (name, initValue) {
    const self = this;
    if (self.observedSettings[name]) {
      self.log.i(`${name} already observed.`);
      return;
    }
    self.log.i(`addSettings, name=${name}, initValue=${JrdUtils.string(initValue)}`);
    self.observedSettings[name] = true;
    //赋初值，并添加监听
    self.settingValues[name] = initValue;
    SettingsObserver.observe(name, initValue, (value) => {
      self.settingValues[name] = value;
    }, true);
  },
  addSystemProperties: async function () {
    const self = this;
    for (const key of Object.values(JrdProperties)) {
      const value = await navigator.b2g.engmodeManager.getPropertyValue(key);
      self.log.i(`properties, key=${key}, value=${JrdUtils.string(value)}`);
      self.systemProperties[key] = value;
    }
  },
  flush: async function () {
    const self = this;
    let formattedArray = [];
    try {
      formattedArray = Object.entries(self.settingValues)
        .filter(([name, value]) => value != null) // 过滤掉 value 为 null 的条目
        .map(([name, value]) => ({
          name,
          value
        }));
    } catch (e) {
      self.log.i(`flush, error=${e}.`);
    }
    self.log.i(`flush, ${JrdUtils.string(formattedArray)}.`);
    await SettingsObserver.setValue(formattedArray);
    self.log.i(`flush, done.`);
  },
  //--------------------  base  ----------------------------------
  //--------------------  system properties  ---------------------
  getOperator: function () {
    const value = this.systemProperties[JrdProperties.OPERATOR];
    return JrdUtils.optString(value);
  },
  getCu: function () {
    const value = this.systemProperties[JrdProperties.CU];
    return JrdUtils.optString(value);
  },
  getImei: function () {
    const self = this;
    let imei = '';
    try {
      const conn = navigator.b2g.mobileConnections[0];
      if (conn) {
        const deviceId = conn.getDeviceIdentities();
        if (deviceId.imei) {
          imei = deviceId.imei;
        }
      }
    } catch (e) {
      self.log.e(`getImei, e=${e}`);
    }
    return imei;
  },
  getTctVersion: function () {
    const value = this.systemProperties[JrdProperties.TCT_VERSION];
    return JrdUtils.optString(value);
  },
  getVendorVersion: function () {
    const value = this.systemProperties[JrdProperties.VEN_VERSION];
    return JrdUtils.optString(value);
  },
  getCurrentSlot: function () {
    const value = this.systemProperties[JrdProperties.SLOT];
    return JrdUtils.optString(value);
  },
  //--------------------  system properties  ---------------------
  getFV: function () {
    const self = this;
    const systemV = self.getTctVersion();
    const vendorV = self.getVendorVersion();
    let fv = '';
    const noPerso = systemV.substring(1, 4) === vendorV.substring(1, 4) && vendorV.substring(7, 8) !== '0';
    self.log.i(`sv=${systemV}, vv=${vendorV}, no=${noPerso}`);
    // 没有 perso 的情况
    if (noPerso) {
      fv += vendorV.substring(1, 5);
      fv += vendorV.substring(4, 8);
    } else {
      fv += systemV.substring(1, 4);
      fv += systemV.substring(6, 7);
      fv += systemV.substring(4, 8);
    }
    self.log.i(`getFV=${fv}`);
    return fv;
  },
  //--------------------  system data  -      --------------------
  //-------------------- business --------------------------------
  setUpdateInfo(value) {
    const self = this;
    self.log.i(`setUpdateInfo=${JrdUtils.string(value)}`);
    this.setValue(JrdDb.UPDATE_INFO, value);
  },
  getUpdateInfo() {
    return this.settingValues[JrdDb.UPDATE_INFO];
  },
  setFotaStatus(value) {
    // checked、downloading、downloaded、installing、installed、null。
    const self = this;
    self.log.i(`setFotaStatus=${value}`);
    this.setValue(JrdDb.STATUS, value);
  },
  getFotaStatus() {
    return this.settingValues[JrdDb.STATUS];
  },
  setDownloadLowBattery(value) {
    const self = this;
    self.log.i(`setDownloadLowBattery=${value}`);
    this.setValue(JrdDb.DOWNLOAD_LOW_BATTERY, value);
  },
  getDownloadLowBattery() {
    return this.settingValues[JrdDb.DOWNLOAD_LOW_BATTERY];
  },
  setPostponeShowTimes(value) {
    const self = this;
    self.log.i(`setPostponeShowTimes=${value}`);
    this.setValue(JrdDb.POSTPONE_SHOW_TIMES, value);
  },
  getPostponeShowTimes() {
    return this.settingValues[JrdDb.POSTPONE_SHOW_TIMES];
  },
  setAutoReboot(value) {
    const self = this;
    self.log.i(`setAutoReboot=${value}`);
    this.setValue(JrdDb.AUTO_REBOOT, value);
  },
  getAutoReboot() {
    return this.settingValues[JrdDb.AUTO_REBOOT];
  },
  setNightlyRebootTime(value) {
    const self = this;
    self.log.i(`setNightlyRebootTime=${value}`);
    this.setValue(JrdDb.REBOOT_TIME, value);
  },
  getNightlyRebootTime() {
    return this.settingValues[JrdDb.REBOOT_TIME];
  },
  /**
   * 0：wifi | cellular
   * 1：wifi & cellular
   * 2：wifi
   */
  setAutoDownload(value) {
    const self = this;
    self.log.i(`setAutoDownload=${value}`);
    this.setValue(JrdDb.CONFIG_AUTO_DOWNLOAD, value);
  },
  /**
   * 0：wifi | cellular
   * 1：wifi & cellular
   * 2：wifi
   */
  getAutoDownload() {
    const self = this;
    const value = self.settingValues[JrdDb.CONFIG_AUTO_DOWNLOAD];
    if (!value) {
      return JrdDlNetwork.WIFI_AUTO;
    } else {
      return value;
    }
  },
  //-------------------- ui callback --------------------------------
  setUiNetworkChange(value) {
    const self = this;
    self.log.i(`setUiNetworkChange=${value}`);
    this.setValue(JrdUiCb.NETWORK_CHANGE, value);
  },
  setUiCheckCallback(value) {
    const self = this;
    self.log.i(`setUiCheckCallback=${JrdUtils.string(value)}`);
    this.setValue(JrdUiCb.CHECK, value);
  },
  setUiDownloadProgress(value) {
    const self = this;
    self.log.i(`setUiDownloadProgress=${value}`);
    this.setValue(JrdUiCb.DOWNLOAD, value);
  },
  setUiInstallCallback(value) {
    const self = this;
    self.log.i(`setUiInstallCallback=${JrdUtils.string(value)}`);
    this.setValue(JrdUiCb.INSTALL, value);
  },
  setInstallWaitReboot(value) {
    const self = this;
    self.log.i(`setInstallWaitReboot=${value}`);
    this.setValue(JrdDb.EG_WAIT_REBOOT, value);
  },
  getInstallWaitReboot() {
    return this.settingValues[JrdDb.EG_WAIT_REBOOT];
  },
  setBootSlot(value) {
    const self = this;
    self.log.i(`setBootSlot=${value}`);
    this.setValue(JrdDb.BOOT_SLOT, value);
  },
  getBootSlot() {
    return this.settingValues[JrdDb.BOOT_SLOT];
  },
  setBootVersion(value) {
    const self = this;
    self.log.i(`setBootVersion=${value}`);
    this.setValue(JrdDb.BOOT_VERSION, value);
  },
  getBootVersion() {
    return this.settingValues[JrdDb.BOOT_VERSION];
  },
  setTestLowBattery(value) {
    const self = this;
    self.log.i(`setTestLowBattery=${value}`);
    this.setValue(JrdDb.TEST_LOW_BATTERY, value);
  },
  getTestLowBattery() {
    return this.settingValues[JrdDb.TEST_LOW_BATTERY];
  },
  setTestLowStorage(value) {
    const self = this;
    self.log.i(`setTestLowStorage=${value}`);
    this.setValue(JrdDb.TEST_LOW_STORAGE, value);
  },
  getTestLowStorage() {
    return this.settingValues[JrdDb.TEST_LOW_STORAGE];
  },
  setTestAlmDI(value) {
    this.setValue(JrdDb.TEST_ALM_DI, value);
  },
  getTestAlmDI() {
    return this.settingValues[JrdDb.TEST_ALM_DI];
  },
  setTestAlmRestart(value) {
    const self = this;
    self.log.i(`setTestAlmRestart=${value}`);
    this.setValue(JrdDb.TEST_ALM_RESTART, value);
  },
  getTestAlmRestart() {
    return this.settingValues[JrdDb.TEST_ALM_RESTART];
  },
  setTestRoaming(value) {
    const self = this;
    self.log.i(`setTestRoaming=${value}`);
    this.setValue(JrdDb.TEST_ROAMING, value);
  },
  getTestRoaming() {
    return this.settingValues[JrdDb.TEST_ROAMING];
  },
  setInstallProcess(value) {
    const self = this;
    self.log.i(`setInstallProcess=${value}`);
    this.setValue(JrdDb.INSTALL_PROGRESS, value);
  },
  getInstallProcess() {
    return this.settingValues[JrdDb.INSTALL_PROGRESS];
  },
  getKeepStateOnInstallFailed() {
    return this.settingValues[JrdDb.TEST_KEEP_STATE_ON_INSTALL_FAIL];
  },
  setNewVersionJson(value) {
    const self = this;
    self.log.i(`setNewVersionJson=${JrdUtils.string(value)}`);
    this.setValue(JrdDb.NEW_VERSION_JSON, value);
  },
  getNewVersionJson() {
    return this.settingValues[JrdDb.NEW_VERSION_JSON];
  },
  setDownloadInfoJson(value) {
    const self = this;
    self.log.i(`setDownloadInfoJson=${JrdUtils.string(value)}`);
    this.setValue(JrdDb.DOWNLOAD_INFO_JSON, value);
  },
  getDownloadInfoJson() {
    return this.settingValues[JrdDb.DOWNLOAD_INFO_JSON];
  },
  // 是否已经开机过了
  setHasBootUp(value) {
    const self = this;
    self.log.i(`setHasBootUp=${value}`);
    this.setValue(JrdDb.HAS_BOOT_UP, value);
  },
  getHasBootUp() {
    const self = this;
    const value = this.settingValues[JrdDb.HAS_BOOT_UP];
    self.log.i(`getHasBootUp=${value}`);
    return value;
  },
};
