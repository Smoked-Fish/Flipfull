'use strict';
/* exported JrdDialog */
/* global JrdLauncher */
/* global Service */
/* global JrdUtils */
/* global JrdNotification */

const JrdDialog = {
  log: window.JrdLogger.createLogger('#Dialog'),
  l10nGet: window.api.l10n.get,
  init() {
    this.handleShowUiDialog = this.handleShowUiDialog.bind(this);
  },
  showNormalDialogByContent(dialogConfig) {
    const self = this;
    if (dialogConfig.desc) {
      Service.request('DialogService:show', {
        header: self.l10nGet(dialogConfig.title.id),
        content: self.l10nGet(dialogConfig.body.id) + dialogConfig.desc,
        type: 'confirm',
        noClose: false,
        ok: self.l10nGet(dialogConfig.confirm.l10nId),
        onOk: dialogConfig.confirm.callback,
        cancel: self.l10nGet(dialogConfig.cancel.l10nId),
        onCancel: dialogConfig.cancel.callback,
        translated: true
      });
    } else {
      Service.request('DialogService:show', {
        header: self.l10nGet(dialogConfig.title.id),
        content: self.l10nGet(dialogConfig.body.id),
        type: 'confirm',
        noClose: false,
        ok: self.l10nGet(dialogConfig.confirm.l10nId),
        onOk: dialogConfig.confirm.callback,
        cancel: self.l10nGet(dialogConfig.cancel.l10nId),
        onCancel: dialogConfig.cancel.callback,
        translated: true
      });
    }
  },
  showNormalDialogByID(dialogConfig) {
    Service.request('DialogService:show', {
      id: dialogConfig.title.id,
      header: dialogConfig.title.id,
      content: dialogConfig.body.id,
      type: 'confirm',
      noClose: false,
      ok: dialogConfig.confirm.l10nId,
      onOk: dialogConfig.confirm.callback,
      cancel: dialogConfig.cancel.l10nId,
      onCancel: dialogConfig.cancel.callback
    });
  },
  showAttentionDialogByContent(dialogConfig) {
    Service.request('DialogService:show', {
      header: dialogConfig.title,
      content: dialogConfig.body,
      translated: true,
      type: 'alert',
      noClose: false,
      ok: dialogConfig.confirm.title,
      onOk: dialogConfig.confirm.callback
    });
  },
  showAttentionDialog(dialogConfig) {
    Service.request('DialogService:show', {
      id: 'tct_fota_dialog',
      header: dialogConfig.title.id,
      content: dialogConfig.body.id,
      type: 'alert',
      noClose: false,
      ok: dialogConfig.confirm.l10nId,
      onOk: dialogConfig.confirm.callback
    });
  },
  hide() {
    Service.request('DialogService:hide', 'tct_fota_dialog');
  },
  //------------------------------------------------------------
  batteryNotEnoughDialog() {
    const self = this;
    const header = self.l10nGet('software-update');
    const content = self.l10nGet('jrdfota_battery_low');
    self.log.i(`batteryNotEnoughDialog, content=${content}`);
    const dialogConfig = {
      title: header,
      body: content,
      confirm: {
        title: self.l10nGet('jrdfota_btn_ok'),
        callback: null
      }
    };
    self.showAttentionDialogByContent(dialogConfig);
  },
  showLowBatteryDialog() {
    const self = this;
    const header = self.l10nGet('software-update');
    const content = self.l10nGet('jrdfota_battery_low');
    self.log.i(`showLowBatteryDialog, content=${content}`);
    const dialogConfig = {
      title: header,
      body: content,
      confirm: {
        title: self.l10nGet('jrdfota_btn_ok'),
        callback: null
      }
    };
    JrdNotification.showLowBattery(false);
    self.showAttentionDialogByContent(dialogConfig);
  },
  showNotEnoughStorageSpaceDialog: function () {
    const self = this;
    const header = self.l10nGet('software-update');
    const needSize = JrdUtils.needSize();
    const size = JrdUtils.formatSize(needSize);
    const content = self.l10nGet('jrdfota_storage_not_enough', {number: size});
    self.log.i(`showNotEnoughStorageSpaceDialog, content=${content}`);
    const dialogConfig = {
      title: header,
      body: content,
      confirm: {
        title: self.l10nGet('jrdfota_btn_ok'),
        callback: function () {
          JrdLauncher.launchSettingsClearStorage();
        }
      }
    };
    JrdNotification.showLowStorage(false);
    self.showAttentionDialogByContent(dialogConfig);
  },
  showNoNetworkDialog() {
    const self = this;
    const header = self.l10nGet('software-update');
    const content = self.l10nGet('jrdfota_no_network');
    self.log.i(`showNoNetworkDialog, content=${content}`);
    const dialogConfig = {
      title: header,
      body: content,
      confirm: {
        title: self.l10nGet('jrdfota_btn_ok'),
        callback: null
      }
    };
    self.showAttentionDialogByContent(dialogConfig);
  },
  showDataRoamingDialog() {
    const self = this;
    const header = self.l10nGet('software-update');
    const content = self.l10nGet('jrdfota_data_roaming');
    self.log.i(`showDataRoamingDialog, content=${content}`);
    const dialogConfig = {
      title: header,
      body: content,
      confirm: {
        title: self.l10nGet('jrdfota_btn_ok'),
        callback: null
      }
    };
    self.showAttentionDialogByContent(dialogConfig);
  },
  showCellularDownloadLimitDialog() {
    const self = this;
    const header = self.l10nGet('software-update');
    const content = self.l10nGet('jrdfota_download_limit');
    self.log.i(`showCellularDownloadLimitDialog, content=${content}`);
    const dialogConfig = {
      title: header,
      body: content,
      confirm: {
        title: self.l10nGet('jrdfota_btn_ok'),
        callback: null
      }
    };
    self.showAttentionDialogByContent(dialogConfig);
  },
  handleShowUiDialog(content) {
    const self = this;
    self.log.i(`handleShowUiDialog, content=${content}`);
    if (content === 'no_network') {
      self.showNoNetworkDialog();
    }
  },
  showUpgradeSuccess() {
    const self = this;
    self.log.i('showUpgradeSuccess.');
    window.setTimeout(function () {
      self.showAttentionDialog({
        title: {id: 'software-update'},
        body: {id: 'jrdfota_upgrade_success'},
        confirm: {l10nId: 'jrdfota_btn_ok'}
      });
    }, 3000);
  },
  showUpgradeFail() {
    const self = this;
    self.log.i('showUpgradeFail.');
    window.setTimeout(function () {
      self.showAttentionDialog({
        title: {id: 'software-update'},
        body: {id: 'jrdfota_upgrade_failure'},
        confirm: {l10nId: 'jrdfota_btn_ok'}
      });
    }, 3000);
  },
};
