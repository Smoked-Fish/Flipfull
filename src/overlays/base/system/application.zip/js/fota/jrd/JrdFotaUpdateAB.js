'use strict';
/* global JrdUtils, JrdDatabase, JrdState */
/* global JrdOp, JrdStatus, JrdOperator, JrdAlarm */
/* global JrdState, JrdLimit, JrdEGStatusCode */
/* global JrdEGErrorCode, JrdSlotStatus */
/* global JrdNetwork, JrdGecko, JrdLauncher, JrdDialog */
/* global JrdNotification, JrdNetwork, */
/* global JrdBattery, JrdDb, JrdUi, JrdDi, JrdUiRes, JrdReport */
/* global JrdAlarmType, JRD_BATTERY_LEVEL_LIMIT */
/* global JrdPhoneCall */
/* global JrdNetworkState */
/* global JrdRequest */
/* global JrdHttp */
/* global JrdDlError */
/* global JrdDlNetwork */
/* global JrdPkgSize */

const JRD_UI = 'JRD_UI';

const systemUpdate = {
  log: window.JrdLogger.createLogger('#Main'),
  initialize: false,
  screenOpened: false,
  jrdInstallStatusCode: -1,
  jrdInstallProcess: -1,
  jrdIsIdleLaunched: false,
  jrdOnIdleLaunched: null,
  jrdOperatorName: null,
  jrdUpdateInfo: {
    version: '',
    size: 0,
    percentage: 0,
    description: '',
    svn: '',
  },
  jrdUIType: 'init',
  jrdEGStatusList: [],
  debounce(func, delay) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => {
        func.apply(this, args);
      }, delay);
    };
  },
  throttle: function (func, limit) {
    let lastTimer;
    let lastRan;
    return function (...args) {
      const context = this;
      if (!lastRan) {
        func.apply(context, args);
        lastRan = Date.now();
      } else {
        clearTimeout(lastTimer);
        lastTimer = setTimeout(() => {
          if ((Date.now() - lastRan) >= limit) {
            func.apply(context, args);
            lastRan = Date.now();
          }
        }, limit - (Date.now() - lastRan));
      }
    };
  },
  //---------------------------- init begin ----------------------------
  init: async function () {
    const self = this;
    self.log.i('init.initialize=' + self.initialize);
    if (self.initialize === true) {
      return;
    }
    //数据库初始化会要很久，屏幕首次监听放在前面才能收到。
    self.bindOnScreenOpened = self.handleOnScreenOpened.bind(self);
    window.addEventListener('homescreenopened', self.bindOnScreenOpened);
    self.bindDeviceShutdown = self.handleDeviceShutdown.bind(self);
    window.addEventListener('will-shutdown', self.bindDeviceShutdown);

    await JrdDatabase.init(); //初始化持久化数据，必须同步执行
    self.jrdOperatorName = JrdDatabase.getOperator();

    self.setupUIMethod = self.setupUI.bind(self);
    self.dataNetworkListenter = self.handleDataStatusChange.bind(self);
    self.wifiNetworkListenter = self.handleWifiStatusChange.bind(self);
    self.batteryListenter = self.onBatteryChange.bind(self);
    self.bindCheckIfDownload = self.debounce(self.checkIfDownload.bind(self), 1000);
    self.bindUpdateInstallProgress = self.throttle(self.updateInstallProgress.bind(self), 1000);
    self.commonCallback = self.onCommonCb.bind(self);
    self.checkNewCallback = self.onCheckNewCb.bind(self);
    self.downloadRequestCallback = self.onDownloadRequestCb.bind(self);
    self.verifyPackageCallback = self.onVerifyPackageCb.bind(self);
    self.engineStatusUpdateCallback = self.onEngineStatusUpdate.bind(self);
    self.engineCompleteCallback = self.onEngineComplete.bind(self);

    JrdDialog.init();
    JrdLauncher.init();
    JrdPhoneCall.init();
    JrdNotification.init(self.setupUIMethod);
    JrdGecko.init(self.commonCallback);
    JrdAlarm.init(self.handleAlarm.bind(self));
    JrdAlarm.initAutoCheckAlarm().then();

    self.jrdUIType = 'init';
    self.initUpdateInfo();
    self.initUIObserver();
    self.initAutoReboot();

    self.initialize = true;
    self.log.i(`init.complete. screenOpened=${self.screenOpened}`);

    //------二次检查首次亮屏回调是否已经执行过了------
    if (self.screenOpened && self.screenOpened === true) {
      self.bindOnScreenOpened();
    }
  },
  initUpdateInfo: function () {
    const self = this;
    const result = JrdDatabase.getUpdateInfo();
    if (result && result.version) {
      self.log.i('initUpdateInfo, updateInfo=' + JrdUtils.string(result));
      self.jrdUpdateInfo = result;
    } else {
      self.log.i('initUpdateInfo, updateInfo is not exist, so add empty');
      self.updateJrdPkgInfo({
        version: '',
        size: 0,
        percentage: 0,
        description: '',
        svn: '',
      });
    }
  },
  initUIObserver: function () {
    const self = this;
    self.UICheckUpdate = self.handleUICheckUpdate.bind(self);
    JrdDatabase.observe(JrdUi.CHECK, false, self.UICheckUpdate, true);
    self.UIDownload = self.handleUIDownload.bind(self);
    JrdDatabase.observe(JrdUi.DOWNLOAD, false, self.UIDownload, true);
    self.UIDownload2 = self.handleUIDownload2.bind(self);
    JrdDatabase.observe(JrdUi.DOWNLOAD2, false, self.UIDownload2, true);
    self.UIInstall = self.handleUIInstall.bind(self);
    JrdDatabase.observe(JrdUi.INSTALL, false, self.UIInstall, true);
    self.UIReboot = self.handleUIReboot.bind(self);
    JrdDatabase.observe(JrdUi.REBOOT, false, self.UIReboot, true);
    self.UILater = self.handleUIClickLater.bind(self);
    JrdDatabase.observe(JrdUi.LATER, false, self.UILater, true);
    self.UIReset = self.handleUIReset.bind(self);
    JrdDatabase.observe(JrdUi.RESET, false, self.UIReset, true);
    self.UITestFun = self.handleUITestFun.bind(self);
    JrdDatabase.observe(JrdUi.TEST_FUN, false, self.UITestFun, true);
    self.AutoRebootChange = self.handleAutoRebootChange.bind(self);
    JrdDatabase.observe(JrdDb.AUTO_REBOOT, 'on', self.AutoRebootChange, true);
    JrdDatabase.observe(JrdDb.REBOOT_TIME, '2:00 AM', self.AutoRebootChange, true);
    self.UITestAlmDI = self.handleUITestAlmDI.bind(self);
    JrdDatabase.observe(JrdDb.TEST_ALM_DI, false, self.UITestAlmDI, true);
    self.UITestAlmRestart = self.handleUITestAlmRestart.bind(self);
    JrdDatabase.observe(JrdDb.TEST_ALM_RESTART, false, self.UITestAlmRestart, true);
  },
  initAutoReboot: function () {
    const self = this;
    const autoReboot = JrdDatabase.getAutoReboot();
    const rebootTime = JrdDatabase.getNightlyRebootTime();
    self.log.i('initAutoReboot, autoReboot:' + autoReboot + ', rebootTime:' + rebootTime);
    if (!autoReboot) {
      JrdDatabase.setAutoReboot('on');
    }
    if (!rebootTime) {
      JrdDatabase.setNightlyRebootTime('2:00 AM');
    }
    self.handleAutoRebootChange();
  },
  //---------------------------- getter && setter ----------------------

  //---------------------------- update info ---------------------------
  updateJrdPkgInfo: function (pkgInfo) {
    const self = this;
    const version = JrdUtils.optString(pkgInfo.version);
    const size = JrdUtils.optInt(pkgInfo.size);
    const percentage = JrdUtils.optInt(pkgInfo.percentage);
    const description = JrdUtils.optString(pkgInfo.description);
    const svn = JrdUtils.optString(pkgInfo.svn);

    self.jrdUpdateInfo = {
      version: version,
      size: size,
      percentage: percentage,
      description: description,
      svn: svn
    };
    JrdDatabase.setUpdateInfo(self.jrdUpdateInfo);
  },
  updateFotaStatus: function (status) {
    // checked、downloading、downloaded、installing、installed、null。
    const self = this;
    self.log.i('updateFotaStatus, status:' + status);
    JrdDatabase.setFotaStatus(status);
    if (status === JrdState.CHECKED) {
      JrdNotification.showNewUpdateAvailable(false);
    } else if (status === JrdState.DOWNLOADING) {
      JrdNotification.showDownloading(false);
    } else if (status === JrdState.DOWNLOADED) {
      JrdNotification.showDownloadedTips(false);
    } else if (status === JrdState.INSTALLING) {
      JrdNotification.showInstallingTips(false);
    } else if (status === JrdState.INSTALLED) {
      JrdNotification.showRebootTips(false);
    }
  },
  //---------------------------- gecko callback ------------------------
  onDownloadProgressCb: function (downloadType, completionRate) {
    const self = this;
    self.log.i(`onDownloadProgressCb, downloadType=${downloadType}, completionRate=${completionRate}`);
    JrdDatabase.setUiDownloadProgress(completionRate);
    if (completionRate === 100) {
      self.log.i('onDownloadProgressCb, download complete.');
      self.saveCompletionRate(100);
      self.updateFotaStatus(JrdState.DOWNLOADED);
      JrdNotification.showDownloadedTips(false);
      self.tryInstall(true).then();
    } else {
      self.saveCompletionRate(completionRate);
    }
  },
  onCheckUpdateFail: function (resCode, msg) {
    // JrdUi.CHECK, JrdDi.CHECK
    const self = this;
    self.log.i(`onCheckUpdateFail, resCode=${resCode}, msg=${msg}`);
    self.notifyUiCheckResult(JrdUiRes.FAILED, null);
    self.reset('onCheckUpdateFail');
  },
  onCheckUpdateSuccess: function (jrdUIType, version, size, percentage, description, svn) {
    // JrdUi.CHECK, JrdDi.CHECK
    const self = this;
    self.log.i('onCheckUpdateSuccess, uiType:' + jrdUIType + ', version:' + version + ', size:' + size);
    if (JrdUtils.isEmpty(version) || size === 0) {
      self.reset('version-unavailable.');
      if (self.needNotifyUi()) {
        self.notifyUiCheckResult(JrdUiRes.FAILED, null);
      }
      return;
    }
    // jrdUIType是从检查更新透传来的为(JrdUi.CHECK/JrdDi.CHECK)。
    // TMO流量下允许自动下载的场景下，需要矫正jrdUIType为下载类型。
    let newJrdUIType = JrdDi.DOWNLOAD;
    if (self.needNotifyUi()) {
      newJrdUIType = JrdUi.DOWNLOAD;
    }
    const oldVersion = JrdUtils.optString(self.jrdUpdateInfo.version);
    const diffVersion = oldVersion !== version;
    self.log.i(`onCheckUpdateSuccess, diffVersion=${diffVersion}`);
    if (diffVersion) {
      self.updateJrdPkgInfo({
        version: version,
        size: size,
        percentage: percentage,
        description: description,
        svn: svn,
      });
      self.updateFotaStatus(JrdState.CHECKED);
      if (self.needNotifyUi()) {
        self.notifyUiCheckResult(JrdUiRes.SUCCESS, self.jrdUpdateInfo);
      }
      self.setupDownload(newJrdUIType); // Modify to JrdUi.DOWNLOAD or JrdDi.DOWNLOAD.
    } else {
      const oldPercent = JrdUtils.optInt(self.jrdUpdateInfo.percentage);
      self.log.i(`onCheckUpdateSuccess, size and version are the same. percent=${oldPercent}`);
      if (oldPercent === 100) {
        self.log.i('onCheckUpdateSuccess, package has downloaded');
        self.updateFotaStatus(JrdState.DOWNLOADED);
        JrdLauncher.launchDownloaded();
      } else {
        self.updateFotaStatus(JrdState.CHECKED);
        if (self.needNotifyUi()) {
          self.notifyUiCheckResult(JrdUiRes.SUCCESS, self.jrdUpdateInfo);
        }
        self.setupDownload(newJrdUIType); // Modify to JrdUi.DOWNLOAD or JrdDi.DOWNLOAD.
      }
    }
  },
  onVerifyPackageCb: function (available) {
    const self = this;
    self.log.i(`onVerifyPackageCb, available=${available}`);
    if (available === 1) {
      self.saveCompletionRate(100);
      self.updateFotaStatus(JrdState.DOWNLOADED);
      JrdNotification.showDownloadedTips(false);
      self.tryInstall(true).then();
    } else {
      JrdDatabase.setUiDownloadProgress(3021);
      self.reset('verify-package-failure');
    }
  },
  onCommonCb: function (actionType, isSuccess, errorType) {
    const self = this;
    self.log.i(`onCommonCb, actionType=${actionType}, isSuccess=${isSuccess}, errorType=${errorType}.`);
    switch (actionType) {
      // Gecko层，旧版本上表示‘检查更新‘失败，需要通知‘已经是最新版本’；新版本走回调，没使用这个。
      case 'CheckNew':
        self.notifyUiCheckResult(JrdUiRes.FAILED, null);
        self.reset('check-new-failure');
        break;
      // Gecko层，下载文件失败且下载进度小于100会走这个回调，只要收到这个状态表示下载失败。
      case 'Download':
        self.onDownloadInterrupted(errorType);
        JrdReport.report();
        break;
      // Gecko层，暂停下载执行成功
      case 'Pause':
        self.onPauseDownload();
        break;
      // Gecko层，安装操作执行成功
      case 'Install':
        break;
      // Gecko层，删除操作执行成功
      case 'Delete':
        break;
      default:
        self.log.i('no such action type.');
        break;
    }
  },
  onDownloadInterrupted: function (errorType) {
    const self = this;
    JrdReport.record(JrdOp.DOWNLOAD_FAIL, JrdStatus.DOWNLOAD_FAIL, errorType);
    if (errorType === JrdDlError.NETWORK || errorType === JrdDlError.TIMEOUT) {
      self.updateFotaStatus(JrdState.CHECKED);
      self.notifyUiCheckResult(JrdUiRes.NETWORK_ERROR, null);
      // 网络连接失败或超时导致的下载中断，5秒后尝试恢复下载
      window.setTimeout(() => {
        if (JrdNetwork.isOnline()) {
          self.bindCheckIfDownload();
        }
      }, 3000);
    } else if (errorType === JrdDlError.CHECKSUM) {
      // 下载文件校验失败
      self.reset('downloaded-checksum-error');
      JrdReport.record(JrdOp.VERIFY_FAIL, JrdStatus.VERIFY_FAIL);
      JrdReport.record(JrdOp.VERIFY_FAIL, JrdStatus.VERIFY_CHECKSUM_ERROR);
    } else if (errorType === JrdDlError.NO_PACKAGE_RESOURCE) {
      self.reset('downloaded-no-package-resource-error');
      JrdReport.record(JrdOp.VERIFY_FAIL, JrdStatus.VERIFY_FAIL, JrdDlError.NO_PACKAGE_RESOURCE);
    }
  },
  onPauseDownload: function () {
    const self = this;
    //防止在非 DOWNLOADING 状态下回调，导致状态错误。
    const status = JrdDatabase.getFotaStatus();
    if (status !== JrdState.DOWNLOADING) {
      self.log.i('onPauseDownload, wrong status.');
      return;
    }
    const updateInfo = JrdDatabase.getUpdateInfo();
    self.log.i('onPauseDownload, updateInfo: ' + JrdUtils.string(updateInfo));
    if (updateInfo && updateInfo.version && updateInfo.size > 0) {
      self.updateFotaStatus(JrdState.CHECKED);
      if (self.needNotifyUi()) {
        self.notifyUiCheckResult(JrdUiRes.SUCCESS, self.jrdUpdateInfo);
      }
    }
  },
  //-------------server callback end ------------------
  handleUITestAlmDI: function (value) {
    const self = this;
    if (value && value === true) {
      self.log.i('handleUITestAlmDI, reset alarms.');
      JrdAlarm.addAlarmDI24Hour();
    }
  },
  handleUITestAlmRestart: function (value) {
    const self = this;
    if (value && value === true) {
      self.log.i('handleUITestAlmRestart, reset alarms.');
      JrdAlarm.addAlarmPostponeReboot();
    }
  },
  handleAutoRebootChange: function () {
    const self = this;
    const autoUpdate = JrdDatabase.getAutoReboot();
    self.log.i('handleAutoRebootChange, autoUpdate=' + autoUpdate);
    //add the auto reboot alarm
    if (autoUpdate === 'on') {
      const rebootTime = JrdDatabase.getNightlyRebootTime();
      self.log.i('handleAutoRebootChange, rebootTime=' + rebootTime);
      if (rebootTime && rebootTime !== '') {
        let timeArray = rebootTime.split(':');
        let hour = timeArray[0];
        let min = timeArray[1].substr(0, 2);
        let ap = timeArray[1].substr(3, 2);
        // eslint-disable-next-line max-len
        self.log.i('parse auto update time, hour=' + hour + ',min=' + min + ',ap=' + ap);
        // eslint-disable-next-line max-len
        const interval = JrdUtils.getTimeInterval(hour, min, ap);
        JrdAlarm.addAlarmAutoReboot(interval);
      }
    } else if (autoUpdate === 'off') {
      JrdAlarm.removeAlarmAutoReboot();
    }
  },
  handleUIInstall: function (value) {
    const self = this;
    self.log.i('handleUIInstall, value=' + value);
    if (value && value === true) {
      self.tryInstall(false).then();
    }
  },
  handleUIReboot: function (value) {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i(`handleUIReboot value=${value}, status=${status}`);
    JrdReport.record(JrdOp.UPGRADE, JrdStatus.CLICK_REBOOT);
    if (value && value === true) {
      JrdGecko.reboot();
    }
  },
  handleUIClickLater: function (value) {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i(`handleUIClickLater value=${value}, status=${status}`);
    JrdReport.record(JrdOp.UPGRADE, JrdStatus.CLICK_LATER);
  },
  startForceRebootCountdown() {
    const self = this;
    let time = 6;
    const timer = window.setInterval(() => {
      let nextCountdown = time - 1;
      if (nextCountdown < 0) {
        self.log.i('startForceRebootCountdown, done, to reboot.');
        window.clearInterval(timer);
        self.tryReboot(false);
      } else {
        time = nextCountdown;
        self.log.i('startForceRebootCountdown, counting:' + time);
      }
    }, 1000);
  },
  notifyUiCheckResult: function (result, updateInfo) {
    const self = this;
    self.log.i('notifyUiCheckResult, result:' + result);
    JrdDatabase.setUiCheckCallback({
      result: result,
      updateInfo: updateInfo,
    });
  },
  needNotifyUi: function () {
    // JrdUi.CHECK,
    // JrdDi.CHECK,
    // JrdUi.DOWNLOAD,
    // JrdUi.DOWNLOAD2,
    // JrdDi.DOWNLOAD
    const self = this;
    const jrdUIType = self.jrdUIType;
    let result = false;
    if (JrdUtils.isEmpty(jrdUIType)) {
      result = false;
    } else if (jrdUIType.startsWith(JRD_UI)) {
      result = true;
    }
    self.log.i(`needNotifyUi, uiType=${jrdUIType}, result=${result}`);
    return result;
  },
  setupRealDownload: function () {
    const self = this;
    self.log.i('setupRealDownload, jrdUIType=' + self.jrdUIType);
    if (self.needNotifyUi()) {
      self.notifyUiCheckResult(JrdUiRes.AUTO_DOWNLOAD, self.jrdUpdateInfo);
    }
    const progress = JrdUtils.optInt(self.jrdUpdateInfo.percentage);
    if (progress === 0) {
      JrdReport.record(JrdOp.DOWNLOAD_START, JrdStatus.DOWNLOAD_START);
    } else {
      JrdReport.record(JrdOp.DOWNLOAD_RESUME, JrdStatus.DOWNLOAD_RESUME);
    }
    self.updateFotaStatus(JrdState.DOWNLOADING);
    JrdGecko.downloadRequest(self.downloadRequestCallback, !self.needNotifyUi()).then();
  },
  upcomingDownload: async function () {
    const self = this;
    const result = await self.checkDownload();
    self.log.i('upcomingDownload, result:' + result);
    if (result === JrdLimit.PASS) {
      self.setupRealDownload();
    } else if (result === JrdLimit.LOW_BATTERY) {
      JrdDatabase.setDownloadLowBattery(true);
      if (self.needNotifyUi()) {
        JrdDialog.showLowBatteryDialog();
      } else {
        JrdNotification.showLowBattery(false);
      }
    } else if (result === JrdLimit.LOW_STORAGE) {
      if (self.needNotifyUi()) {
        JrdDialog.showNotEnoughStorageSpaceDialog();
      } else {
        JrdNotification.showLowStorage(false);
      }
    } else if (result === JrdLimit.CELLULAR_SIZE) {
      if (self.needNotifyUi()) {
        JrdDialog.showCellularDownloadLimitDialog();
      }
    }
  },
  setupDownload: function (jrdUIType) {
    // JrdUi.CHECK, JrdDi.CHECK, JrdUi.DOWNLOAD, JrdUi.DOWNLOAD2, JrdDi.DOWNLOAD
    const self = this;
    self.setCheckType(jrdUIType);
    const isNotOnline = JrdNetwork.isNotOnline();
    self.log.i('setupDownload, uiType:' + jrdUIType + ', isNotOnline:' + isNotOnline);
    if (isNotOnline) {
      if (self.needNotifyUi()) {
        JrdDialog.showNoNetworkDialog();
      }
      JrdReport.record(JrdOp.DOWNLOAD, JrdStatus.NO_NETWORK);
      return;
    }
    if (self.needNotifyUi()) {
      self.downloadWithUI();
    } else {
      self.downloadWithDI();
    }
  },
  downloadWithUI: function () {
    const self = this;
    const jrdUIType = self.jrdUIType;
    self.log.i(`downloadWithUI, uiType=${jrdUIType}.`);
    const network = JrdNetwork.getNetwork();
    if (network.wifi) {
      self.log.i('downloadWithUI, wifi start download.');
      self.upcomingDownload().then();
      return 0;
    }
    if (network.data) { // 下面是蜂窝网络的情况
      if (network.roaming) {
        self.log.i('downloadWithUI, downloads are prohibited while roaming.');
        JrdDialog.showDataRoamingDialog();
        return 0;
      }
      const autoDownload = JrdDatabase.getAutoDownload();
      self.log.i('downloadWithUI, autoDownload:' + autoDownload);
      if (autoDownload === JrdDlNetwork.WIFI_AUTO) {
        if (jrdUIType === JrdUi.DOWNLOAD) {
          const tmoNetwork = JrdNetwork.isTMONetwork();
          self.log.i('downloadWithUI, tmoNetwork=' + tmoNetwork);
          if (tmoNetwork) {
            self.upcomingDownload().then();
          } else {
            const success = JrdLauncher.launchDataWarning();
            if (success === false) {
              self.reset('launch-data-warning-error');
            }
          }
        } else if (jrdUIType === JrdUi.DOWNLOAD2) {
          self.upcomingDownload().then();
        }
      } else if (autoDownload === JrdDlNetwork.WIFI_AND_CELLULAR) {
        self.upcomingDownload().then();
      } else {
        JrdDialog.showCellularDownloadLimitDialog();
      }
      return 0;
    }
    return 0;
  },
  downloadWithDI: function () {
    const self = this;
    self.log.i(`downloadWithDI, uiType=${self.jrdUIType}.`);
    const network = JrdNetwork.getNetwork();
    if (network.wifi) {
      self.log.i('downloadWithDI, start download with wifi.');
      self.upcomingDownload().then();
      return 0;
    }
    if (network.data) { // 下面是蜂窝网络的情况
      if (network.roaming) {
        self.log.i('downloadWithDI, downloads are prohibited while roaming.');
        return 0;
      }
      const autoDownload = JrdDatabase.getAutoDownload();
      self.log.i('downloadWithDI, autoDownload:' + autoDownload);
      if (autoDownload === JrdDlNetwork.WIFI_AND_CELLULAR) {
        self.upcomingDownload().then();
      } else {
        // 1、是TMO网络。
        const tmoNetwork = JrdNetwork.isTMONetwork();
        // 2、DownloadNetwork是WIFI-AUTO。
        const canDownload = autoDownload === JrdDlNetwork.WIFI_AUTO && tmoNetwork;
        // 3、TMO需求，TMO网络下允许自动下载。
        if (canDownload) {
          self.upcomingDownload().then();
        } else {
          JrdNotification.showNewUpdateAvailable(false);
          self.log.i('downloadWithDI, JrdDi.CHECK, 24 hour ');
          const success = JrdLauncher.launchChecked('no');
          if (success === false) {
            self.reset('launch-checked-error');
          }
        }
      }
    }
    return 0;
  },
  handleUICheckUpdate: function (value) {
    const self = this;
    self.log.i('handleUICheckUpdate, value: ' + value);
    if (!value) {
      self.log.i('handleUICheckUpdate, maybe error.');
      return;
    }
    self.setupUI(false);
  },
  setupUI: function (setupFromNotify) {
    const self = this;
    self.setCheckType(JrdUi.CHECK);
    //checked、downloading、downloaded、null。
    const status = JrdDatabase.getFotaStatus();
    const fromNotify = setupFromNotify && setupFromNotify === true;
    const fromApp = fromNotify ? 'no' : 'yes';
    self.log.i('setupUI, fromApp=' + fromApp + ', status=' + status);
    if (status === JrdState.CHECKED) {
      const success = JrdLauncher.launchChecked(fromApp);
      if (success === false) {
        self.reset('launch-checked-error-1');
        return;
      }
      if (fromNotify) {
        JrdNotification.showNewUpdateAvailable(false);
      }
      return;
    } else if (status === JrdState.DOWNLOADING) {
      JrdLauncher.launchDownloading(fromApp);
      if (fromNotify) {
        JrdNotification.showDownloading(false);
      }
      return;
    } else if (status === JrdState.DOWNLOADED) {
      JrdLauncher.launchDownloaded(fromApp);
      if (fromNotify) {
        JrdNotification.showDownloadedTips(false);
      }
      return;
    } else if (status === JrdState.INSTALLING) {
      JrdLauncher.launchInstalling(fromApp);
      if (fromNotify) {
        JrdNotification.showInstallingTips(false);
      }
      return;
    } else if (status === JrdState.INSTALLED) {
      JrdLauncher.launchReboot(fromApp);
      if (fromNotify) {
        JrdNotification.showRebootTips(false);
      }
      return;
    }
    if (fromNotify) {
      JrdLauncher.launchHome(fromApp);
      return;
    }
    const network = JrdNetwork.getNetwork();
    const shouldCheck = network.wifi || (network.data && !network.roaming);
    self.log.i(`setupUI, shouldCheck=${shouldCheck}.`);
    if (shouldCheck) {
      JrdLauncher.launchChecking(fromApp);
      JrdGecko.checkNew(self.checkNewCallback, false).then();
    } else if (network.data) {
      JrdDialog.showDataRoamingDialog();
    } else {
      JrdDialog.showNoNetworkDialog();
      JrdReport.record(JrdOp.CHECK, JrdStatus.CHECK_FAIL_NO_NETWORK);
    }
  },
  onCheckNewCb: function (resCode, content1, content2, msg) {
    const self = this;
    const uiType = self.needNotifyUi() ? JrdUi.CHECK : JrdDi.CHECK;
    self.log.i(`onCheckNewCb, uiType=${uiType}, resCode=${resCode},\n content1=${content1},\n msg=${msg}`);
    if (resCode === JrdHttp.SUCCESS) {
      // 解析新版本信息
      const vInfo = JrdRequest.parseNewVersionXml(content1);
      // 将新版本信息写入数据库
      JrdDatabase.setNewVersionJson(vInfo);
      // 解析服务端配置到本地
      JrdRequest.updateConfig(vInfo.config);
      self.onCheckUpdateSuccess(uiType, vInfo.tv, vInfo.fileSize, 0, '', vInfo.svn);
      // 因为可能存在背靠背安装，导致更新成功提醒弹窗和提醒用户重启页面重叠；当检查到新版本之后移除弹窗。
      JrdDialog.hide();
      JrdReport.record(JrdOp.CHECK, JrdStatus.CHECK_SUCCESS);
    } else {
      self.notifyUiCheckResult(JrdUiRes.FAILED, null);
      self.reset('onCheckNewCb');

      const extras = `${resCode}-${msg}`;
      if (resCode === JrdHttp.NO_CONTENT || resCode === JrdHttp.NO_TO_VERSION || resCode === JrdHttp.NOT_FOUND) {
        // 204：CU存在，起始版本存在，目标版本原来有现在删除了；
        // 205：没有目标版本；
        // 404：不明确，历史安卓实现上有过返回；
        JrdReport.record(JrdOp.CHECK, JrdStatus.CHECK_SUCCESS_NO_NEW_VERSION, extras);
      } else if (resCode === JrdHttp.BAD_REQUEST) {
        JrdReport.record(JrdOp.CHECK, JrdStatus.CHECK_FAIL_BAD_REQUEST, extras);
      } else if (resCode === JrdHttp.NO_CU_OR_FROM_VERSION) {
        //  207：没有起始版本或没有CU。
        JrdReport.record(JrdOp.CHECK, JrdStatus.CHECK_SUCCESS_CU_OR_FV_NOT_FOUND, extras);
      } else if (resCode >= JrdHttp.SERVER_ERROR_START && resCode <= JrdHttp.SERVER_ERROR_END) {
        JrdReport.record(JrdOp.CHECK, JrdStatus.CHECK_FAIL_SERVER_ERROR, extras);
      } else {
        JrdReport.record(JrdOp.CHECK, JrdStatus.CHECK_FAIL, extras);
      }
    }
    // 检查更新结束上报埋点，TMO24小时请求一次服务器需求。
    JrdReport.report();
  },
  onDownloadRequestCb: function (resCode, content, msg) {
    const self = this;
    const uiType = self.needNotifyUi() ? JrdUi.CHECK : JrdDi.CHECK;
    self.log.i(`onDownloadRequestCb, uiType=${uiType}, resCode=${resCode},\n content=${content},\n msg=${msg}`);
    // 当前在服务器上无论包是否删除都会返回200。
    if (resCode === JrdHttp.SUCCESS) {
      self.downloadProgressCallback = self.onDownloadProgressCb.bind(self, uiType);
      // 解析下载包信息
      const dInfo = JrdRequest.parseDownloadInfoXml(content);
      // 将下载包信息写入数据库
      JrdDatabase.setDownloadInfoJson(dInfo);
      // 发起文件下载
      JrdGecko.downloadPackage(self.downloadProgressCallback).then(res => {
        if (res < 0) {
          self.reset('download-request-error');
        }
      });
    } else if (resCode === JrdHttp.NOT_FOUND) {
      // 对应资源已经不可查询，可能版本已经取消
      self.onDownloadInterrupted(JrdDlError.NO_PACKAGE_RESOURCE);
    } else {
      self.onDownloadInterrupted(JrdDlError.NETWORK);
    }
    if (resCode !== JrdHttp.SUCCESS) {
      JrdReport.record(JrdOp.DOWNLOAD_FAIL, JrdStatus.DOWNLOAD_FAIL, `${resCode}-${msg}`);
    }
    if (resCode >= JrdHttp.BAD_REQUEST && resCode <= JrdHttp.SERVER_ERROR_END) {
      self.reset('download-request-error1');
      JrdReport.record(JrdOp.DOWNLOAD, resCode, `${resCode}-${msg}`);
    }
  },
  handleUIDownload: function (value) {
    const self = this;
    self.log.i('handleUIDownload=' + value);
    if (value && value === true) {
      JrdReport.record(JrdOp.DOWNLOAD_REQUEST_MANUAL, JrdStatus.DOWNLOAD_REQUEST_MANUAL);
      self.setupDownload(JrdUi.DOWNLOAD);
    }
  },
  handleUIDownload2: function (value) {
    const self = this;
    self.log.i('handleUIDownload2=' + value);
    if (value && value === true) {
      JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_AND_CELLULAR);
      JrdReport.record(JrdOp.DOWNLOAD_REQUEST_MANUAL, JrdStatus.DOWNLOAD_REQUEST_MANUAL);
      self.setupDownload(JrdUi.DOWNLOAD2);
    }
  },
  handleDeviceShutdown: async function () {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i(`device will shutdown. status=${status}`);
    JrdNotification.clear(true);
    await JrdDatabase.flush();
    JrdGecko.pauseDownload(status);
  },
  handleOnScreenOpened: function () {
    const self = this;
    self.screenOpened = true;
    JrdNotification.clear(true);
    window.removeEventListener('homescreenopened', self.bindOnScreenOpened);
    if (!self.initialize) {
      self.log.i('home screen opened, has not initialize complete.');
      return;
    }
    self.log.i('home screen opened.');
    self.screenOpened = null;
    self.jrdIsIdleLaunched = true;
    if (self.jrdOnIdleLaunched && typeof self.jrdOnIdleLaunched == 'function') {
      self.log.i('start to execute handle alarm.');
      self.jrdOnIdleLaunched();
    }
    self.jrdOnIdleLaunched = null;

    //屏幕亮起来再处理UI相关，否则不会响应
    self.initJrdStatus();
    // 延迟注册，这个回调来的很早
    window.setTimeout(() => {
      JrdNetwork.init(self.dataNetworkListenter, self.wifiNetworkListenter);
      JrdBattery.initBattery(self.batteryListenter);
    }, 5000);
    // FR: GF5GTMO-8012，激活后即开始检查更新，列为通用功能，不做运营商区分;
    const hasBootUp = JrdDatabase.getHasBootUp();
    if (hasBootUp !== true) {
      window.setTimeout(() => {
        // 防止开机不到1分钟就关机，实际没有发起检查更新的情况；
        JrdDatabase.setHasBootUp(true);
        self.runAutoCheck("FirstBootUp");
      }, 60000);
    }
  },
  initJrdStatus: function () {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i(`initJrdStatus, status=${status}`);
    if (status === JrdState.CHECKED) {
      JrdNotification.showNewUpdateAvailable(false);
    } else if (status === JrdState.DOWNLOADING) {
      self.updateFotaStatus(JrdState.CHECKED);
    } else if (status === JrdState.DOWNLOADED) {
      JrdNotification.showDownloadedTips(false);
    } else if (status === JrdState.INSTALLING) {
      self.setupInstallReal();
    } else if (status === JrdState.INSTALLED) {
      const waitReboot = JrdDatabase.getInstallWaitReboot();
      self.log.i('initJrdStatus, waitReboot=' + waitReboot);
      if (waitReboot && waitReboot === true) {
        JrdNotification.clear(true);
        window.setTimeout(() => {
          self.resumeOnInstalled();
        }, 5000);
      } else {
        JrdNotification.showRebootTips(false);
      }
    }
  },
  setCheckType: function (jrdUIType) {
    const self = this;
    self.log.i('setCheckType, uiType:' + jrdUIType);
    self.jrdUIType = jrdUIType;
  },
  resetCheckType: function () {
    const self = this;
    self.log.i('resetCheckType, enter.');
    self.jrdUIType = 'init';
  },
  //-------------------------- alarm begin -------------------------------------
  handleAlarm: function (alarmType) {
    const self = this;
    if (!self.jrdIsIdleLaunched) {
      self.log.i('handleAlarm enter, homescreen is not launched, wait it launch.');
      self.jrdOnIdleLaunched = self.handleAlarm.bind(self, alarmType);
      return;
    }
    if (alarmType) {
      self.log.i('handleAlarm type is ' + alarmType);
      switch (alarmType) {
        case JrdAlarmType.DI:
          self.handleAutoCheckAlarm();
          break;
        case JrdAlarmType.POSTPONE_REBOOT:
          self.handleAlarmPostponeReboot();
          break;
        case JrdAlarmType.AUTO_REBOOT:
          self.handleAlarmAutoReboot();
          break;
        default:
          self.log.i('no such alarmType');
          break;
      }
    }
  },
  handleAutoCheckAlarm: function () {
    const self = this;
    JrdAlarm.addAlarmDI24Hour();
    JrdReport.record(JrdOp.CHECK, JrdStatus.AUTO_CHECK_START);
    self.runAutoCheck("DI");
  },
  runAutoCheck: function (source) {
    const self = this;
    self.log.i(`runAutoCheck, source=${source}.`);
    if (JrdNetwork.isNotOnline()) {
      self.log.i('runAutoCheck, network is not connected.');
      JrdReport.record(JrdOp.CHECK, JrdStatus.CHECK_FAIL_NO_NETWORK);
      return 0;
    }
    const status = JrdDatabase.getFotaStatus();
    self.log.i('runAutoCheck , state=' + status);
    const allowCheckState = status === null ||
      status === undefined ||
      status === JrdState.IDLE ||
      status === JrdState.CHECKED;
    if (allowCheckState) {
      const network = JrdNetwork.getNetwork();
      const shouldCheck = network.wifi || (network.data && !network.roaming);
      self.log.i(`runAutoCheck, shouldCheck=${shouldCheck}.`);
      if (shouldCheck) {
        JrdGecko.checkNew(self.checkNewCallback, true).then();
      }
      return 0;
    }
    JrdReport.record(JrdOp.CHECK, JrdStatus.STATE_ERROR);
    if (status === JrdState.DOWNLOADED) {
      self.tryInstall(true).then();
    }
    return 0;
  },
  setPostponeRebootAlarm: function (times) {
    const self = this;
    self.log.i('setPostponeRebootAlarm, times:' + times);
    JrdAlarm.addAlarmPostponeReboot();
    JrdDatabase.setPostponeShowTimes(times);
  },
  handleAlarmPostponeReboot: function () {
    const self = this;
    const showTimes = JrdDatabase.getPostponeShowTimes();
    const times = JrdUtils.optInt(showTimes);
    self.log.i('handleAlarmPostponeReboot, times:' + times);
    if (times < 3) {
      JrdLauncher.launchReboot();
      self.setPostponeRebootAlarm(times + 1);
    } else {
      JrdLauncher.launchRebootForce();
      self.startForceRebootCountdown();
    }
  },
  handleAlarmAutoReboot: function () {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i('handleAlarmAutoReboot, status=' + status);
    if (status === JrdState.INSTALLED) {
      JrdLauncher.launchRebootForce();
      self.startForceRebootCountdown();
      self.handleAutoRebootChange();
    }
  },
  //-------------------------- alarm end ---------------------------------------
  //-------------------------- network change begin ----------------------------
  checkIfDownload: function () {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i('checkIfDownload, status:' + status);
    if (status === JrdState.DOWNLOADING || status === JrdState.CHECKED) {
      self.setupDownload(JrdDi.DOWNLOAD);
    } else {
      self.log.i('checkIfDownload, status info is null');
    }
  },
  handleWifiStatusChange: function (value) { // value:int
    const self = this;
    self.log.i(`handleWifiStatusChange=${value}`);
    if (value === JrdNetworkState.WIFI_CONNECTED) {
      self.handleWifiConnected();
    } else {
      self.handleWifiDisconnected();
    }
  },
  handleDataStatusChange: function (value) {// value:int
    const self = this;
    self.log.i(`handleDataStatusChange=${value}`);
    if (value === JrdNetworkState.ROAMING) {
      self.handleDataRoaming();
    } else if (value === JrdNetworkState.DATA_CONNECTED) {
      self.handleDataConnected();
    } else {
      self.handleDataDisconnected();
    }
  },
  handleWifiConnected: function () {
    const self = this;
    JrdDatabase.setUiNetworkChange(10);
    const status = JrdDatabase.getFotaStatus();
    self.log.i('handleWifiConnected, status:' + status);
    if (status === JrdState.CHECKED) {
      self.bindCheckIfDownload();
    }
  },
  handleWifiDisconnected: function () {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i(`handleWifiDisconnected, status=${status}.`);
    JrdDatabase.setUiNetworkChange(-10);
    if (JrdGecko.getGeckoAction() === 'Download') {
      JrdReport.record(JrdOp.DISCONNECT, JrdStatus.DISCONNECT);
    }
  },
  handleDataConnected: function () {
    const self = this;
    JrdDatabase.setUiNetworkChange(20);
    const status = JrdDatabase.getFotaStatus();
    self.log.i('handleDataConnected, status=' + status);
    if (status === JrdState.CHECKED) {
      self.bindCheckIfDownload();
    }
  },
  handleDataDisconnected: function () {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i(`handleDataDisconnected, status=${status}.`);
    JrdDatabase.setUiNetworkChange(-20);
    if (JrdGecko.getGeckoAction() === 'Download') {
      JrdReport.record(JrdOp.DISCONNECT, JrdStatus.DISCONNECT);
    }
  },
  handleDataRoaming: function () {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    const network = JrdNetwork.getNetwork();
    self.log.i(`handleDataRoaming, status=${status}.`);
    if (network.data) {
      JrdGecko.pauseDownload(status);
      //whether show data is roaming interface,tbd
      self.log.i('handleDataConnected roaming true , wifi false, status download');
    }
  },
  saveCompletionRate: function (completionRate) {
    const self = this;
    const version = self.jrdUpdateInfo.version;
    const size = self.jrdUpdateInfo.size;
    self.log.i('saveCompletionRate, completionRate:' + completionRate + ', version:' + version + ', size:' + size);
    self.updateJrdPkgInfo({
      version: version,
      size: size,
      percentage: completionRate,
      description: self.jrdUpdateInfo.description,
      svn: self.jrdUpdateInfo.svn,
    });
    if (completionRate === 100) {
      JrdReport.record(JrdOp.DOWNLOAD, JrdStatus.DOWNLOAD_SUCCESS);
      JrdReport.record(JrdOp.VERIFY_SUCCESS, JrdStatus.VERIFY_SUCCESS);
    }
  },
  checkCellularSizeLimit: function () {
    const self = this;
    const network = JrdNetwork.getNetwork();
    if (network.wifi) {
      self.log.i('checkCellularSizeLimit, download with wifi.');
      return JrdLimit.PASS;
    }
    const pkgSize = JrdUtils.optInt(self.jrdUpdateInfo.size);
    // FR: GF5GTMO-8013, 蜂窝网络下允许下载1GB以下的更新包。
    if (JrdUtils.canUSCC() === true && pkgSize >= JrdPkgSize.LIMIT_1GB) {
      self.log.i('checkCellularSizeLimit, operator[uscc] 1gb limit.');
      return JrdLimit.CELLULAR_SIZE;
    }
    // FR: , 蜂窝网络下允许下载3GB以下的更新包。
    if (self.jrdOperatorName === JrdOperator.EE && pkgSize >= JrdPkgSize.LIMIT_3GB) {
      self.log.i('checkCellularSizeLimit, operator[ee] 3gb limit.');
      return JrdLimit.CELLULAR_SIZE;
    }
    return JrdLimit.PASS;
  },
  checkDownload: async function () {
    const self = this;
    const batteryEnough = JrdUtils.isBatteryEnough();
    self.log.i(`checkDownload, batteryEnough=${batteryEnough}`);
    if (batteryEnough) {
      JrdNotification.showNewUpdateAvailable(false);
    } else {
      JrdReport.record(JrdOp.DOWNLOAD, JrdStatus.DL_LOW_BATTERY);
      return JrdLimit.LOW_BATTERY;
    }
    const storageEnough = await JrdUtils.isStorageEnough();
    self.log.i('checkDownload, storageEnough:' + storageEnough);
    if (storageEnough) {
      JrdNotification.showNewUpdateAvailable(false);
    } else {
      JrdReport.record(JrdOp.INSUFFICIENT_MEMORY, JrdStatus.DL_LOW_STORAGE);
      return JrdLimit.LOW_STORAGE;
    }
    const cellularSizeLimit = self.checkCellularSizeLimit();
    if (cellularSizeLimit) {
      JrdNotification.showNewUpdateAvailable(false);
      return cellularSizeLimit;
    }
    return JrdLimit.PASS;
  },
  onBatteryChange: function (level) {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i(`onBatteryChange, status=${status}`);
    if (status === JrdState.CHECKED) {
      const lowBattery = JrdDatabase.getDownloadLowBattery();
      if (!lowBattery) {
        self.log.i('onBatteryChange, check failure.');
      }
      if (level < JRD_BATTERY_LEVEL_LIMIT) {
        self.log.i('onBatteryChange, battery not enough.');
        return;
      }
      JrdNotification.showNewUpdateAvailable(false);
      self.bindCheckIfDownload();
    } else if (status === JrdState.DOWNLOADED) {
      self.tryInstall(true).then();
    }
  },
  tryInstall: async function (auto) {
    const self = this;
    const batteryEnough = JrdUtils.isBatteryEnough();
    self.log.i(`tryInstall, auto=${auto}, batteryEnough=${batteryEnough}`);
    if (!batteryEnough) {
      self.updateFotaStatus(JrdState.DOWNLOADED);
      if (auto && auto === true) {
        JrdLauncher.launchDownloaded();
      }
      if (self.needNotifyUi()) {
        JrdNotification.showLowBattery(false);
        JrdDialog.batteryNotEnoughDialog();
      }
      JrdReport.record(JrdOp.UPGRADE, JrdStatus.INSTALL_LOW_BATTERY);
      return;
    }
    const storageEnough = await JrdUtils.isStorageEnough();
    self.log.i(`tryInstall, storageEnough=${storageEnough}`);
    if (!storageEnough) {
      self.updateFotaStatus(JrdState.DOWNLOADED);
      if (auto && auto === true) {
        JrdLauncher.launchDownloaded();
      }
      if (self.needNotifyUi()) {
        JrdNotification.showLowStorage(false);
        JrdDialog.showNotEnoughStorageSpaceDialog();
      }
      JrdReport.record(JrdOp.UPGRADE, JrdStatus.INSTALL_LOW_STORAGE);
      return;
    }
    self.setupInstallReal();
  },
  setupInstallReal: function () {
    const self = this;
    self.updateFotaStatus(JrdState.INSTALLING);
    self.notifyUiCheckResult(JrdUiRes.INSTALLING, self.jrdUpdateInfo);
    self.log.i('setupInstallReal, bind update_engine.');
    self.jrdEGStatusList = [];
    self.jrdInstallStatusCode = -1;
    self.jrdInstallProcess = -1;
    JrdReport.record(JrdOp.UPGRADE, JrdStatus.INSTALL_START);
    JrdGecko.abInstallBind(self.engineStatusUpdateCallback, self.engineCompleteCallback);
  },
  ongoingInstalling: function () {
    const self = this;
    const installing = self.jrdEGStatusList.includes(JrdEGStatusCode.CHECKING_FOR_UPDATE) ||
      self.jrdEGStatusList.includes(JrdEGStatusCode.UPDATE_AVAILABLE) ||
      self.jrdEGStatusList.includes(JrdEGStatusCode.DOWNLOADING) ||
      self.jrdEGStatusList.includes(JrdEGStatusCode.VERIFYING) ||
      self.jrdEGStatusList.includes(JrdEGStatusCode.FINALIZING) ||
      self.jrdEGStatusList.includes(JrdEGStatusCode.UPDATED_NEED_REBOOT);
    self.log.i(`ongoingInstalling, installing=${installing}`);
    return installing;
  },
  onEngineStatusUpdate: function (statusCode, progress) {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i(`onEngineStatusUpdate, status=${status}, statusCode=${statusCode}, progress=${progress}`);
    if (status !== JrdState.INSTALLING) {
      self.log.i(`onEngineStatusUpdate, status is ${status}, return.`);
      JrdGecko.abInstallUnbind();
      return;
    }
    if (self.jrdInstallStatusCode === statusCode && self.jrdInstallProcess === progress) {
      self.log.i(`onEngineStatusUpdate, same status, return.`);
      return;
    }
    self.jrdInstallStatusCode = statusCode;
    self.jrdInstallProcess = progress;
    const applyPayload = statusCode === JrdEGStatusCode.IDLE && !self.ongoingInstalling();
    self.log.i(`onEngineStatusUpdate, applyPayload=${applyPayload}.`);
    if (applyPayload) {
      JrdUtils.requestCpuWakeLock();
      JrdGecko.abInstallApplyPayload();
    }
    self.jrdEGStatusList.push(statusCode);
    let curProgress = 0;
    switch (statusCode) {
      case JrdEGStatusCode.IDLE:
      case JrdEGStatusCode.CLEAR_PREVIOUS: {
        curProgress = 0;
        break;
      }
      case JrdEGStatusCode.CHECKING_FOR_UPDATE: {
        curProgress = 10;
        break;
      }
      case JrdEGStatusCode.UPDATE_AVAILABLE: {
        curProgress = 20;
        break;
      }
      case JrdEGStatusCode.DOWNLOADING: {
        curProgress = 20 + Math.floor(progress * 40);
        break;
      }
      case JrdEGStatusCode.VERIFYING: {
        curProgress = 60 + Math.floor(progress * 40);
        break;
      }
      case JrdEGStatusCode.FINALIZING:
      case JrdEGStatusCode.UPDATED_NEED_REBOOT: {
        curProgress = 100;
        break;
      }
    }
    self.bindUpdateInstallProgress(JrdUiRes.SUCCESS, statusCode, curProgress);
  },
  onEngineComplete: function (errorCode) {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i(`onEngineComplete, status=${status}, errorCode=` + errorCode);
    if (status !== JrdState.INSTALLING) {
      self.log.i(`onEngineComplete, status is ${status}, return.`);
      return;
    }
    switch (errorCode) {
      case JrdEGErrorCode.USER_CANCELED: {
        self.log.i('onEngineComplete, this update has been canceled, so ignore it.');
        self.reset('engine-code-error');
        break;
      }
      case JrdEGErrorCode.SUCCESS: {
        self.onEngineSuccess(errorCode);
        break;
      }
      default: {
        self.onEngineError(errorCode);
        break;
      }
    }

    JrdGecko.abInstallUnbind();
    JrdUtils.releaseCpuWakeLock();
  },
  onEngineSuccess: function (errorCode) {
    const self = this;
    self.updateFotaStatus(JrdState.INSTALLED);
    JrdReport.record(JrdOp.UPGRADE, JrdStatus.INSTALL_SUCCESS);
    const slot = JrdDatabase.getCurrentSlot();
    const fv = JrdDatabase.getFV();
    self.log.i(`onEngineSuccess, slot=${slot}, fv=${fv}`);
    JrdDatabase.setBootSlot(slot);
    JrdDatabase.setBootVersion(fv);
    JrdDatabase.setInstallWaitReboot(true);
    self.handleAutoRebootChange();
    self.setPostponeRebootAlarm(1);
    JrdNotification.showRebootTips(false);
    JrdLauncher.launchReboot();
  },
  onEngineError: function (errorCode) {
    const self = this;
    const keepState = JrdDatabase.getKeepStateOnInstallFailed();
    self.log.i(`onEngineError, errorCode=${errorCode}, keepState=${keepState}`);
    if (keepState == null || !keepState) {
      self.reset('engine-result-error');
    }
    self.bindUpdateInstallProgress(JrdUiRes.FAILED, JrdEGErrorCode.UNKNOWN, 0);
    JrdReport.record(JrdOp.UPGRADE, JrdStatus.INSTALL_FAILED, `${errorCode}`);
    JrdReport.record(JrdOp.INSTALL_FAIL, errorCode);
  },
  updateInstallProgress: function (result, statusCode, newProgress) {
    const self = this;
    self.log.i(`updateInstallProgress, result=${result}, statusCode=${statusCode}, newProgress=${newProgress}`);
    const dbProcess = JrdDatabase.getInstallProcess();
    const oldProcess = JrdUtils.optInt(dbProcess);
    let postProcess = oldProcess;
    if (newProgress > oldProcess) {
      postProcess = newProgress; //避免进度回退
      JrdDatabase.setInstallProcess(newProgress);
    }
    const data = {result: result, progress: postProcess};
    self.log.i(`updateInstallProgress, post data=${JrdUtils.string(data)}`);
    JrdDatabase.setUiInstallCallback(data);
  },
  getSlotState: function () {
    const self = this;
    const slot = JrdDatabase.getBootSlot();
    const rebootSlot = JrdDatabase.getCurrentSlot();
    self.log.i(`getSlotState, slot=${slot}, rebootSlot=${rebootSlot}`);
    if (!slot || slot && slot === '') {
      return JrdSlotStatus.CUR_SLOT_IS_EMPTY;
    } else if (slot && slot === rebootSlot) {
      return JrdSlotStatus.CUR_SLOT_NOT_CHANGE;
    } else {
      return JrdSlotStatus.CUR_SLOT_CHANGED;
    }
  },
  resumeOnInstalled: function () {
    const self = this;
    const slotState = self.getSlotState();
    const bootV = JrdDatabase.getBootVersion();
    const curV = JrdDatabase.getFV();
    self.log.i(`resumeOnInstalled, slotState=${slotState}, bootV=${bootV}, curV=${curV}.`);
    if (slotState === JrdSlotStatus.CUR_SLOT_CHANGED) {
      JrdDialog.showUpgradeSuccess();
    } else if (slotState === JrdSlotStatus.CUR_SLOT_NOT_CHANGE) {
      JrdDialog.showUpgradeFail();
    }
    self.reset('upgrade-done');
  },
  tryReboot: function (afterCall) {
    // 打电话的时候不能重启
    const self = this;
    if (self.jrdIsIdleLaunched === false) {
      self.log.i('tryReboot, the idle is not launched, wait for open.');
      return;
    }
    const isCalling = JrdPhoneCall.isDeviceCalling();
    self.log.i(`tryReboot, afterCall=${afterCall}, isCalling=${isCalling}`);
    if (!afterCall && isCalling) {
      self.log.i('tryReboot, the device is in calling, wait for over.');
      JrdPhoneCall.addCallEndListener(self.tryReboot.bind(self, true));
      return;
    }
    JrdAlarm.removeAlarmPostponeReboot();
    JrdGecko.reboot();
  },
  handleUIReset: function (value) {
    const self = this;
    self.log.i('handleUIReset, value:' + value);
    if (value) {
      JrdDatabase.setTestAlmDI(false);
      JrdAlarm.addAlarmDI24Hour();
      self.reset();
    }
  },
  handleUITestFun: function (value) {
    const self = this;
    self.log.i('handleUITestFun, value:' + value);
  },
  reset: function (reason = '') {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i(`reset, status=${status}, reason=${reason}`);
    self.resetCheckType();
    self.updateFotaStatus(JrdState.IDLE);//需要先重置状态，否则后续操作可能有回调无法拦截
    self.updateJrdPkgInfo({
      version: '',
      size: 0,
      percentage: 0,
      description: '',
      svn: '',
    });
    JrdGecko.pauseDownload(status);
    JrdGecko.delete();
    JrdGecko.abInstallCancel();
    JrdGecko.abInstallResetStatus();
    JrdDatabase.setBootSlot('');
    JrdDatabase.setBootVersion('');
    JrdDatabase.setDownloadLowBattery(false);
    JrdDatabase.setInstallWaitReboot(false);
    JrdDatabase.setTestLowBattery(false);
    JrdDatabase.setTestLowStorage(false);
    JrdDatabase.setTestRoaming(false);
    JrdDatabase.setTestAlmDI(false);
    JrdDatabase.setTestAlmRestart(false);
    JrdDatabase.setInstallProcess(0);
    JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_AUTO);
    JrdDatabase.setPostponeShowTimes(0);
    JrdAlarm.removeAlarmPostponeReboot();
    JrdAlarm.removeAlarmAutoReboot();
    JrdNotification.clear(true);
    self.jrdEGStatusList = [];
    self.jrdInstallStatusCode = -1;
    self.jrdInstallProcess = -1;
  },
};

systemUpdate.init().then();
