'use strict';
/* exported JrdGecko */
/* global JrdDatabase */
/* global JrdUtils */
/* global JrdRequest */
/* global JrdState */
/* global JrdDlNetwork */

const JrdGecko = {
  log: window.JrdLogger.createLogger('#Gecko'),
  mozJrdFota: navigator.b2g.mozJrdFota,
  init: function (callback) {
    const self = this;
    self.log.i('init');
    this.configCallback = this.configCallback.bind(this);
    self.mozJrdFota.init(callback, true);
  },
  getGeckoAction: function () {
    //CheckNew
    //Download
    //Pause
    //Delete
    //Cancel
    const self = this;
    let action = self.mozJrdFota.JrdFotaActionStatus;
    self.log.i('getGeckoAction, action:' + action);
    return action;
  },
  checkUpdate: function (checkCallback) {
    const self = this;
    self.log.i('checkUpdate');
    self.mozJrdFota.checkIfFotaAvailable(checkCallback, this.configCallback);
  },
  download: function (callback) {
    const self = this;
    self.log.i('download');
    JrdDatabase.setDownloadLowBattery(false);
    self.mozJrdFota.download(callback);
  },
  pauseDownload: function (status) {
    const self = this;
    self.log.i(`pauseDownload, status=${status}`);
    if (status === JrdState.DOWNLOADING) {
      self.mozJrdFota.pause();
    }
  },
  install: function () {
    const self = this;
    self.log.i('install');
    self.mozJrdFota.install();
  },
  //---------------------------------------------
  checkNew: async function (callback, auto) {
    const self = this;
    const params = await JrdRequest.generateCheckParams(auto);
    await self.mozJrdFota.checkNew(params, callback);
  },
  downloadRequest: async function (callback, auto) {
    const self = this;
    JrdDatabase.setDownloadLowBattery(false);
    const params = await JrdRequest.generateDownloadRequestParams(auto);
    await self.mozJrdFota.downloadRequest(params, callback);
  },
  downloadPackage: async function (callback) {
    const self = this;
    const url = await JrdRequest.generateDownloadUrl();
    if (url === '') {
      return -1;
    }
    const vInfo = JrdDatabase.getNewVersionJson();
    if (vInfo.checksum == null || vInfo.checksum === '') {
      return -2;
    }
    if (vInfo.fileSize == null || vInfo.fileSize <= 0) {
      return -3;
    }
    self.mozJrdFota.downloadPackage(url, vInfo.checksum, vInfo.fileSize, callback);
    return 0;
  },
  abInstallBind: function (callback1, callback2) {
    const self = this;
    self.log.i('abInstallBind');
    self.mozJrdFota.abInstallBind(callback1, callback2);
  },
  abInstallUnbind: function () {
    const self = this;
    self.log.i('abInstallUnbind');
    self.mozJrdFota.abInstallUnbind();
  },
  abInstallApplyPayload: function () {
    const self = this;
    self.log.i('abInstallApplyPayload');
    self.mozJrdFota.abInstallApplyPayload();
  },
  abInstallSuspend: function () {
    const self = this;
    self.log.i('abInstallSuspend');
    self.mozJrdFota.abInstallSuspend();
  },
  abInstallResume: function () {
    const self = this;
    self.log.i('abInstallResume');
    self.mozJrdFota.abInstallResume();
  },
  abInstallCancel: function () {
    const self = this;
    self.log.i('abInstallCancel');
    self.mozJrdFota.abInstallCancel();
  },
  abInstallResetStatus: function () {
    const self = this;
    self.log.i('abInstallResetStatus');
    self.mozJrdFota.abInstallResetStatus();
  },
  abInstallVerifyPayload: function (callback) {
    const self = this;
    self.log.i('abInstallVerifyPayload');
    self.mozJrdFota.abInstallVerifyPayload(callback);
  },
  abInstallAllocateSpace: function (callback) {
    const self = this;
    self.log.i('abInstallAllocateSpace');
    self.mozJrdFota.abInstallAllocateSpace(callback);
  },
  delete: function () {
    const self = this;
    self.log.i('delete');
    self.mozJrdFota.delete();
  },
  reboot: function () {
    const self = this;
    self.log.i('delete');
    self.mozJrdFota.reboot();
  },
  record: function (operation, status, extras = '') {
    const self = this;
    self.log.i(`record, operation=${operation}, status=${status} extras=${extras}`);

    async function asyncWrapper() {
      const cu = JrdDatabase.getCu();
      const imei = JrdDatabase.getImei();
      const fv = JrdDatabase.getFV();
      const updateInfo = JrdDatabase.getUpdateInfo();
      const tv = JrdUtils.optString(updateInfo.version);
      self.mozJrdFota.recordBi(imei, cu, fv, tv, operation, status, extras);
    }

    asyncWrapper().then();
  },
  report: function () {
    const self = this;
    self.mozJrdFota.reportBi();
  },
  testFun: function (code) {
    const self = this;
    self.log.i('testFun, code=' + code);
    self.mozJrdFota.testFun(code);
    self.report(50, 1, '');
  },
  //----------------------------------
  configCallback: function (type, resp) {
    const self = this;
    self.log.i('configCallback, type:' + type + ', resp:' + resp);
    let operatorResp;
    if (resp !== '' && resp != null) {
      operatorResp = JSON.parse(resp);
    }
    if (type === 6 || type === '6') {
      //type=6,resp={"format version":1,"data":{"check":false,"download":true}}
      const download6 = operatorResp.data.download;
      self.log.i('configCallback, download6:' + download6);
      if (download6 && download6 === true) {
        JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_AND_CELLULAR);
      } else {
        JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_AUTO);
      }
    }
    if (type === 7 || type === '7') {
      // type:7, resp:{"format version":1,"data":{"type":"mandatory","type_data":{"download":"auto","install":"manual"}}}
      const type7 = operatorResp.data.type;
      const download7 = operatorResp.data.type_data.download;
      const install7 = operatorResp.data.type_data.install;
      self.log.i('configCallback, type7:' + type7 + ', download7:' + download7 + ', install7:' + install7);
      if (type7 === 'mandatory') {
        if (download7 === 'auto') {
          JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_AND_CELLULAR);
        } else if (download7 === 'wifi_auto') {
          JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_AUTO);
        } else if (download7 === 'wifi_only') {
          JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_ONLY);
        }
        /*if (install7 === 'auto') { //TF not support.
          JrdDatabase.setPostponeRebootTimes(0);
        } else {
          JrdDatabase.setPostponeRebootTimes(10);
        }*/
      }
    } else if (type === 17 || type === '17') {
      //type=17,resp={"format version":1,"data":{"upgrade":true}}
      const upgrade17 = operatorResp.data.upgrade;
      self.log.i('configCallback, upgrade17:' + upgrade17);
      if (upgrade17 && upgrade17 === true) {
        JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_AND_CELLULAR);
        //JrdDatabase.setPostponeRebootTimes(10);  //TF not support.
      }
    }
  },
};
