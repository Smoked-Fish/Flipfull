'use strict';
/* exported JrdLauncher */
/* global WebActivity */
/* global JrdLock */
/* global JrdDatabase */
/* global JrdUtils */
/* global JrdPhoneCall */

const JrdLauncher = {
  log: window.JrdLogger.createLogger('#Launcher'),
  init() {
    this.lock = new JrdLock();
    this.onCallEnd = this.launch.bind(this);
  },
  launch(data) {
    const self = this;
    if (JrdPhoneCall.isDeviceCalling()) {
      self.log.i('launchChecked, device is calling now.');
      //JrdPhoneCall.addCallEndListener(this.onCallEnd(data));
      return;
    }
    try {
      new WebActivity('launch-fota', data).start();
      self.log.i(`launch, ${JrdUtils.string(data)} success.`);
    } catch (e) {
      self.log.i('launch, failure. error=' + JrdUtils.string(e));
    }
  },
  //-----------------------------------------------------------
  launchHome: function (fromApp = 'yes') {
    const self = this;
    self.launch({type: 'jrd_main', fromApp: fromApp});
  },
  launchChecked: function (fromApp = 'yes') {
    const self = this;
    const updateInfo = JrdDatabase.getUpdateInfo();
    self.log.i('launchChecked, updateInfo: ' + JrdUtils.string(updateInfo));
    if (updateInfo.size > 0) {
      const info = JrdUtils.getDisplayInfo(updateInfo);
      self.launch({
        type: 'jrd_checked',
        fromApp: fromApp,
        version: info.version,
        size: info.size,
      });
      return true;
    } else {
      self.log.i('launchChecked, updateInfo incorrect.');
      return false;
    }
  },
  launchDownloading: function (fromApp = 'yes') {
    const self = this;
    self.launch({type: 'jrd_downloading', fromApp: fromApp});
  },
  launchSettingsClearStorage: function () {
    const self = this;
    self.log.i('launchSettingsClearStorage, enter.');
    new WebActivity('configure', {
      target: 'device',
      section: 'application_storage'
    }).start();
  },
  launchChecking: function (fromApp = 'yes') {
    const self = this;
    self.launch({type: 'jrd_checking', fromApp: fromApp});
  },
  launchDataWarning: function () {
    const self = this;
    const updateInfo = JrdDatabase.getUpdateInfo();
    self.log.i('launchDataWarning, updateInfo:' + JrdUtils.string(updateInfo));
    if (updateInfo.size > 0) {
      const info = JrdUtils.getDisplayInfo(updateInfo);
      self.launch({
        type: 'jrd_download_data_warning',
        fromApp: 'yes',
        size: info.size,
      });
      return true;
    } else {
      self.log.i('launchDataWarning, updateInfo incorrect.');
      return false;
    }
  },
  launchDownloaded: function (fromApp = 'yes') {
    const self = this;
    const updateInfo = JrdDatabase.getUpdateInfo();
    self.log.i('launchDownloaded, updateInfo: ' + JrdUtils.string(updateInfo));
    if (updateInfo.size > 0) {
      const info = JrdUtils.getDisplayInfo(updateInfo);
      self.launch({
        type: 'jrd_downloaded',
        fromApp: fromApp,
        version: info.version,
        size: info.size,
      });
      return true;
    } else {
      self.log.i('launchDownloaded, updateInfo incorrect.');
      return false;
    }
  },
  launchInstalling(fromApp = 'yes') {
    const self = this;
    self.launch({type: 'jrd_installing', fromApp: fromApp});
  },
  launchReboot(fromApp = 'yes') {
    const self = this;
    self.launch({type: 'jrd_reboot', fromApp: fromApp});
  },
  launchRebootForce(fromApp = 'yes') {
    const self = this;
    self.launch({type: 'jrd_reboot_force', fromApp: fromApp});
  }
};
