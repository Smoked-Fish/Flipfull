'use strict';

/* exported JrdLock */

class JrdLock {

  constructor() {
    this.isLocked = false;
    this.queue = [];
    this.log = window.JrdLogger.createLogger('#Lock');
  }

  acquire() {
    const self = this;
    return new Promise((resolve) => {
      const acquireLock = () => {
        if (!self.isLocked) {
          self.isLocked = true;
          self.log.i('acquireLock isLocked is false, now lock.');
          resolve();
        } else {
          self.log.i('acquireLock isLocked is true, push.');
          self.queue.push(resolve);
        }
      };
      acquireLock();
    });
  }

  release() {
    const self = this;
    if (self.queue.length > 0) {
      const next = self.queue.shift();
      next();
      self.log.i('release next.');
    } else {
      self.log.i('release lock.');
      self.isLocked = false;
    }
  }
}
