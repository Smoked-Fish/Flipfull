'use strict';
/* exported JrdNetwork */
/* global OperatorUtils */
/* global JrdOperator */
/* global JrdDatabase */
/* global JrdNetworkState */
/* global SimSettingsHelper */
/* global JrdUtils */

const JrdNetwork = {
  log: window.JrdLogger.createLogger('#Network'),
  isDataConnected: false,
  isWifiConnected: false,
  isDataRoaming: false,
  dataChangeListener: null,//0:disconnected, 1: connected, 2:roaming
  wifiChangeListener: null,//0:disconnected, 1: connected,
  init: function (dataListener, wifiListener) {
    const self = this;
    self.bindWifiStatusChange = self.onWifiStatusChange.bind(self);
    self.bindDataStatusChange = self.onDataStatusChange.bind(self);
    if (dataListener && typeof dataListener == 'function') {
      self.dataChangeListener = dataListener;
    }
    if (wifiListener && typeof wifiListener == 'function') {
      self.wifiChangeListener = wifiListener;
    }
    self.addWifiChangeListener();
    self.addDataNetworkChangeListener();
  },
  isOnline: function () {
    const self = this;
    const network = self.getNetwork();
    const online = network.wifi || network.data;
    self.log.i(`online=${online}, ${JrdUtils.string(network)}`);
    return online;
  },
  isNotOnline: function () {
    const self = this;
    const notOnline = !self.isOnline();
    self.log.i(`notOnline=${notOnline}`);
    return notOnline;
  },
  getNetwork: function () {
    const self = this;
    const wifiManager = navigator.b2g.wifiManager;
    const wifiConnected = wifiManager && wifiManager.connection && wifiManager.connection.status === 'connected';
    const slotId = SimSettingsHelper['ril.data.defaultServiceId'];
    const conn = navigator.b2g.mobileConnections[slotId];
    const dataConnected = conn && conn.data && conn.data.connected
      && conn.data.state === "registered"
      && JrdUtils.isNotBlank(conn.iccId) === true;
    let roaming = conn && conn.data && conn.data.roaming;
    // FR: GF5GDISH-1061, GF5GTMO-8002
    const operator = JrdDatabase.getOperator();
    if (operator === JrdOperator.DISH || JrdUtils.canUSCC() === true) {
      const usDomesticMcc = self.getIsUsDomesticMcc();
      // 如果是漫游状态，且网络注册在美国国内，则改为false。
      if (roaming && usDomesticMcc) {
        roaming = false;
      }
    }
    const testRoaming = JrdDatabase.getTestRoaming();
    if (testRoaming && testRoaming === true) {
      roaming = testRoaming;
    }
    const result = {
      wifi: wifiConnected,
      data: dataConnected,
      roaming: roaming
    };
    self.log.i(`getNetwork=${JrdUtils.string(result)}, testRoaming=${testRoaming}.`);
    return result;
  },
  addWifiChangeListener: function () {
    const self = this;
    self.log.i(`addWifiChangeListener`);
    // 监听注册后不会马上触发回调，所以主动调用一次。
    self.bindWifiStatusChange();
    window.addEventListener('wifi-statuschange', self.bindWifiStatusChange);
  },
  addDataNetworkChangeListener: function () {
    const self = this;
    self.log.i(`addDataNetworkChangeListener`);
    // 监听注册后不会马上触发回调，所以主动调用一次。
    self.bindDataStatusChange();
    const connections = navigator.b2g.mobileConnections || [];
    for (let i = 0; i < connections.length; i++) {
      connections[i].addEventListener('datachange', self.bindDataStatusChange);
    }
  },
  notifyWifiStatusChange: function (value) {
    const self = this;
    if (!self.wifiChangeListener || typeof self.wifiChangeListener != 'function') {
      self.log.i('notifyWifiStatusChange, listener is null.');
      return;
    }
    self.wifiChangeListener(value);
  },
  dispatchWifiStatusChange: function () {
    const self = this;
    const network = self.getNetwork();
    self.log.i(`wifiStatusChange => connected=[${self.isWifiConnected}/${network.wifi}]`);
    // 如果状态相等，则不重复回调
    if (self.isWifiConnected === network.wifi) {
      return;
    }
    self.isWifiConnected = network.wifi;
    if (self.isWifiConnected) {
      self.log.i(`notifyWifiStatusChange => WIFI_CONNECTED.`);
      self.notifyWifiStatusChange(JrdNetworkState.WIFI_CONNECTED);
    } else {
      self.log.i(`notifyWifiStatusChange => WIFI_DISCONNECTED.`);
      self.notifyWifiStatusChange(JrdNetworkState.WIFI_DISCONNECTED);
    }
  },
  onWifiStatusChange: function () {
    const self = this;
    self.dispatchWifiStatusChange();
  },
  notifyDataStatusChange: function (value) {
    const self = this;
    if (!self.dataChangeListener || typeof self.dataChangeListener != 'function') {
      self.log.i('notifyDataStatusChange, listener is null.');
      return;
    }
    self.dataChangeListener(value);
  },
  dispatchDataStatusChange: function () {
    const self = this;
    const network = self.getNetwork();
    // 正常来说，不管是哪张卡变成了默认卡，只需要关注当前蜂窝网络的状态结果即可。
    const wifiConnected = network.wifi;
    const dataConnected = network.data;
    const dataRoaming = network.roaming;
    self.log.i(`dataStatusChange => connected/roaming=[${self.isDataConnected}/${self.isDataRoaming}, ${dataConnected}/${dataRoaming}]`);
    if (self.isWifiConnected === wifiConnected && wifiConnected === true) {
      // 当前是 WIFI，不分发蜂窝网络变化，但是需要更新最新蜂窝网络状态到本地
      self.isDataConnected = dataConnected;
      self.isDataRoaming = dataRoaming;
      return;
    }
    // 1、蜂窝网络状态/漫游是否变化，即使蜂窝网络状态相等，也需要检查漫游状态(国内漫游)
    if (self.isDataConnected === dataConnected && self.isDataRoaming === dataRoaming) {
      // 蜂窝网络状态未变
      return;
    }
    // 2、将最新的网络状态更新到本地
    self.isDataConnected = dataConnected;
    self.isDataRoaming = dataRoaming;
    // 3、开始分发网络状态
    if (self.isDataConnected === true) {
      if (self.isDataRoaming === true) {
        self.log.i(`notifyDataStatusChange => ROAMING.`);
        self.notifyDataStatusChange(JrdNetworkState.ROAMING);
      } else {
        self.log.i(`notifyDataStatusChange => DATA_CONNECTED.`);
        self.notifyDataStatusChange(JrdNetworkState.DATA_CONNECTED);
      }
    } else {
      self.log.i(`notifyDataStatusChange => DATA_DISCONNECTED.`);
      self.notifyDataStatusChange(JrdNetworkState.DATA_DISCONNECTED);
    }
  },
  onDataStatusChange: function () {
    const self = this;
    self.dispatchDataStatusChange();
  },
  isTMONetwork: function () {
    const self = this;
    const dataServiceId = SimSettingsHelper['ril.data.defaultServiceId'];
    const simOperator = OperatorUtils.getSimOperatorNameByIndex(dataServiceId);
    self.log.i(`isTMONetwork, simOperator=${simOperator}`);
    return simOperator === JrdOperator.TMO || simOperator === JrdOperator.TMO_MetroPCS || simOperator === JrdOperator.TMO_ASW;
  },
  isUSCCNetwork: function () {
    const self = this;
    const dataServiceId = SimSettingsHelper['ril.data.defaultServiceId'];
    const simOperator = OperatorUtils.getSimOperatorNameByIndex(dataServiceId);
    const result = simOperator === JrdOperator.USCC;
    self.log.i(`isUSCCNetwork=${result}, simOperator=${simOperator}`);
    return result;
  },
  // 判断当前卡是否注册在美国国内运营商
  getIsUsDomesticMcc: function () {
    const self = this;
    let usDomesticMcc = false;
    try {
      // 获取当前默认数据卡
      const dataServiceId = SimSettingsHelper['ril.data.defaultServiceId'];
      // 获取驻网的MCC
      const mccStr = navigator.b2g?.mobileConnections?.[dataServiceId]?.data?.network?.mcc;
      // 将MCC字符串转为数字
      const mcc = JrdUtils.optInt(mccStr);
      // 同步Android, MCC >= 310 && MCC <= 316。
      if (mcc >= 310 && mcc <= 316) {
        usDomesticMcc = true;
      }
    } catch (e) {
      // ignore
    }
    return usDomesticMcc;
  }
};
