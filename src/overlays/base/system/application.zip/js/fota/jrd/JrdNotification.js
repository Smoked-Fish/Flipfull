'use strict';
/* exported JrdNotification */
/* global JrdDatabase, JrdUtils, JrdDialog, JrdLauncher */
/* global Service */

const JRD_NOTIFICATION_TAG = 'tct_firmware_ota_tag';

const JrdNotifyType = {
  UPDATE_AVAILABLE: 'tct_firmware_ota_checked',
  DOWNLOADING: 'tct_firmware_ota_downloading',
  LOW_MEMORY: 'tct_firmware_ota_low_storage',
  LOW_BATTERY: 'tct_firmware_ota_low_battery',
  DOWNLOADED: 'tct_firmware_ota_downloaded',
  INSTALLING: 'tct_firmware_ota_installing',
  REBOOT: 'tct_firmware_ota_reboot',
};

const JrdNotification = {
  log: window.JrdLogger.createLogger('#Notification'),
  l10nGet: window.api.l10n.get,
  currentType: '',
  nextInfo: {
    type: '',
    content: '',
    reload: false,
  },
  throttle: function (func, limit) {
    let lastTimer;
    let lastRan;
    return function (...args) {
      const context = this;
      if (!lastRan) {
        func.apply(context, args);
        lastRan = Date.now();
      } else {
        clearTimeout(lastTimer);
        lastTimer = setTimeout(() => {
          if ((Date.now() - lastRan) >= limit) {
            func.apply(context, args);
            lastRan = Date.now();
          }
        }, limit - (Date.now() - lastRan));
      }
    };
  },
  init(setupUI) {
    const self = this;
    this.setupUI = setupUI;
    self.bindShowNotification = self.throttle(self.showJrdNotification.bind(self), 1000);
    self.icon = window.AppOrigin.getOrigin('system') + '/style/notifications/images/system_update.png';
    Service.request('handleSystemMessageNotification', JRD_NOTIFICATION_TAG, self);

    window.addEventListener('localized', () => {
      self.log.i(`language change.`);
      window.setTimeout(function () {
        self.reload();
      }, 1000); //系统会在3s之后刷新一次应用标题，防止和系统冲突，不要设置3s左右的延迟。
    });
  },
  showNotify(type, content, reload) {
    const self = this;
    if (type === self.currentType && reload === false) {
      self.log.i(`${type} already showing.`);
      return;
    }
    self.currentType = type;
    self.nextInfo = {
      type: type,
      content: content,
      reload: reload,
    };
    self.clear(false);
    self.bindShowNotification();
  },
  showJrdNotification() {
    const self = this;
    if (self.nextInfo == null || self.nextInfo.type === '') {
      self.log.i('showJrdNotification, nextInfo is null.');
      return;
    }
    const type = self.nextInfo.type;
    const lang = navigator.language;
    const content = self.nextInfo.content;
    const options = {
      tag: JRD_NOTIFICATION_TAG,
      body: content,
      icon: self.icon,
      mozbehavior: {noclear: true},
      data: {
        systemMessageTarget: JRD_NOTIFICATION_TAG,
        type: type,
      },
    };
    const title = self.l10nGet('jrdfota_software_update');
    window.NotificationService.send(title, options);
    self.log.i(`showJrdNotification, type=${type}, lang=${lang}, content=${content}`);
  },
  clear(clear) {
    const self = this;
    if (clear) {
      self.currentType = '';
      self.nextInfo = null;
    }
    self.log.i(`clear=${clear}`);
    Service.request('removeSystemNoticeByTag', JRD_NOTIFICATION_TAG, true);
  },
  //--------------------------------------
  handleSystemMessageNotification(msg) {
    let self = this;
    const type = JrdUtils.optString(msg.data.type);
    self.log.i(`on notification click -> type=${type}, msg=${JrdUtils.string(msg)}`);
    switch (type) {
      case JrdNotifyType.DOWNLOADING:
        self.handleCheck2DownloadClick();
        break;
      case JrdNotifyType.UPDATE_AVAILABLE:
        self.handleCheck2DownloadClick();
        break;
      case JrdNotifyType.LOW_MEMORY:
        self.handleNotEnoughSpaceClick().then();
        break;
      case JrdNotifyType.LOW_BATTERY:
        self.handleLowBatteryClick();
        break;
      case JrdNotifyType.DOWNLOADED:
        self.handleDownloadedClick();
        break;
      case JrdNotifyType.INSTALLING:
        self.handleInstallingClick();
        break;
      case JrdNotifyType.REBOOT:
        self.handleRebootClick();
        break;
    }
  },
  handleLowBatteryClick() {
    let self = this;
    const batteryEnough = JrdUtils.isBatteryEnough();
    self.log.i('handleLowBatteryClick, batteryEnough:' + batteryEnough);
    if (batteryEnough) {
      self.clear(true);
      self.setupUI(true);
    } else {
      JrdDialog.showLowBatteryDialog();
    }
  },
  handleNotEnoughSpaceClick: async function () {
    let self = this;
    const status = JrdDatabase.getFotaStatus();
    const storageEnough = await JrdUtils.isStorageEnough();
    self.log.i('handleNotEnoughSpaceClick, status:' + status + ', storageEnough: ' + storageEnough);
    if (storageEnough) {
      if (!status) {
        self.clear(true);
      }
      self.setupUI(true);
    } else {
      JrdDialog.showNotEnoughStorageSpaceDialog();
    }
  },
  handleCheck2DownloadClick: function () {
    const self = this;
    const status = JrdDatabase.getFotaStatus();
    self.log.i(`handleCheck2DownloadClick, status=${status}`);
    if (!status) {
      self.clear(true);
    }
    self.setupUI(true);
  },
  handleDownloadedClick: function () {
    const self = this;
    self.log.i('handleDownloadedClick');
    JrdLauncher.launchDownloaded('no');
  },
  handleInstallingClick: function () {
    const self = this;
    self.log.i('handleInstallingClick');
    JrdLauncher.launchInstalling('no');
  },
  handleRebootClick: function () {
    const self = this;
    self.log.i('handleRebootClick');
    JrdLauncher.launchReboot('no');
  },
  //--------------------------------------
  showLowStorage: function (reloadNotify) {
    const self = this;
    const needSize = JrdUtils.needSize();
    const size = JrdUtils.formatSize(needSize);
    const content = self.l10nGet('jrdfota_storage_not_enough', {number: size});
    self.showNotify(
      JrdNotifyType.LOW_MEMORY,
      content,
      reloadNotify
    );
  },
  showLowBattery: function (reloadNotify) {
    const self = this;
    self.showNotify(
      JrdNotifyType.LOW_BATTERY,
      self.l10nGet('jrdfota_battery_low'),
      reloadNotify
    );
  },
  showNewUpdateAvailable: function (reloadNotify) {
    const self = this;
    self.showNotify(
      JrdNotifyType.UPDATE_AVAILABLE,
      self.l10nGet('jrdfota_notification_checked'),
      reloadNotify
    );
  },
  showDownloading(reloadNotify) {
    const self = this;
    self.showNotify(
      JrdNotifyType.DOWNLOADING,
      self.l10nGet('jrdfota_notification_download'),
      reloadNotify
    );
  },
  showDownloadedTips(reloadNotify) {
    const self = this;
    self.showNotify(
      JrdNotifyType.DOWNLOADED,
      self.l10nGet('jrdfota_notification_downloaded'),
      reloadNotify
    );
  },
  showInstallingTips(reloadNotify) {
    const self = this;
    self.showNotify(
      JrdNotifyType.INSTALLING,
      self.l10nGet('jrdfota_notification_installing'),
      reloadNotify
    );
  },
  showRebootTips(reloadNotify) {
    const self = this;
    self.showNotify(
      JrdNotifyType.REBOOT,
      self.l10nGet('jrdfota_notification_reboot'),
      reloadNotify
    );
  },
  reload() {
    const self = this;
    self.log.i(`reload -> current=${self.currentType}`);
    if (self.currentType === JrdNotifyType.UPDATE_AVAILABLE) {
      self.showNewUpdateAvailable(true);
    } else if (self.currentType === JrdNotifyType.DOWNLOADING) {
      self.showDownloading(true);
    } else if (self.currentType === JrdNotifyType.LOW_MEMORY) {
      self.showLowStorage(true);
    } else if (self.currentType === JrdNotifyType.LOW_BATTERY) {
      self.showLowBattery(true);
    } else if (self.currentType === JrdNotifyType.DOWNLOADED) {
      self.showDownloadedTips(true);
    } else if (self.currentType === JrdNotifyType.INSTALLING) {
      self.showInstallingTips(true);
    } else if (self.currentType === JrdNotifyType.REBOOT) {
      self.showRebootTips(true);
    }
  },
};
