'use strict';
/* exported JrdPhoneCall */
/* global JrdLock */

const JrdPhoneCall = {
  log: window.JrdLogger.createLogger('#PhoneCall'),
  init() {
    this.lock = new JrdLock();
    this.callEndListeners = [];
    this.initCallEndListener();
  },
  initCallEndListener() {
    const self = this;
    const telephony = window.navigator.b2g.telephony;
    telephony.oncallschanged = function () {
      if (telephony.calls.length === 0) {
        if (telephony.conferenceGroup.calls.length !== 0) {
          self.log.i('initCallEndListener, device is still calling.');
          return;
        }
        self.notifyCallEnd();
      }
    };
    telephony.conferenceGroup.oncallschanged = function () {
      if (telephony.conferenceGroup.calls.length === 0 && telephony.conferenceGroup.state !== 'connected') {
        if (telephony.calls.length !== 0) {
          self.log.i('initCallEndListener, on calls changed, device is still calling.');
          return;
        }
        self.notifyCallEnd();
      }
    };
  },
  addCallEndListener(listener) {
    const self = this;
    if (listener && typeof listener == 'function') {
      self.callEndListeners.push(listener);
    }
  },
  notifyCallEnd() {
    const self = this;
    this.lock.acquire().then();
    self.callEndListeners.forEach((listener, index) => {
      if (listener && typeof listener == 'function') {
        listener();
      }
      self.callEndListeners.splice(index, 1);
    });
    this.lock.release();
  },
  isDeviceCalling() {
    const self = this;
    const telephony = window.navigator.b2g.telephony;
    let isCalling = telephony.calls.length > 0;
    self.log.i(`isDeviceCalling=${isCalling}`);
    return isCalling;
  },
};
