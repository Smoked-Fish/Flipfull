'use strict';
/* exported JrdReport */
/* exported JrdOp */
/* exported JrdStatus */
/* global JrdGecko */
/* global JrdNetwork */


const JrdOp = {
  CHECK: 50,
  DOWNLOAD_START: 1,
  INSUFFICIENT_MEMORY: 4,
  DISCONNECT: 5,
  DOWNLOAD_FAIL: 6,
  DOWNLOAD_RESUME: 7,
  DOWNLOAD_REQUEST_MANUAL: 12,
  DOWNLOAD_STOP_MANUAL: 55,
  DOWNLOAD_REQUEST: 100,
  DOWNLOAD: 1000,
  VERIFY_FAIL: 8,
  VERIFY_SUCCESS: 9,
  INSTALL_FAIL: 16,
  UPGRADE: 2000,
};

const JrdStatus = {
  // check
  AUTO_CHECK_START: 0,
  STATE_ERROR: 3,
  CHECK_SUCCESS: 10,
  CHECK_SUCCESS_NO_NEW_VERSION: 11,
  CHECK_SUCCESS_CU_OR_FV_NOT_FOUND: 12,
  CHECK_FAIL: 20,
  CHECK_FAIL_NO_NETWORK: 21,
  CHECK_FAIL_BAD_REQUEST: 22,
  CHECK_FAIL_SERVER_ERROR: 24,
  // download
  DOWNLOAD_START: 981,
  DISCONNECT: 985,
  DOWNLOAD_FAIL: 986,
  DOWNLOAD_RESUME: 988,
  DOWNLOAD_REQUEST_MANUAL: 978,
  NO_NETWORK: 62,
  DL_LOW_BATTERY: 63,
  DL_LOW_STORAGE: 984,
  DOWNLOAD_SUCCESS: 999,
  // verify
  VERIFY_FAIL: 990,
  VERIFY_SUCCESS: 991,
  VERIFY_CHECKSUM_ERROR: 603,
  INSTALL_LOW_BATTERY: 900,
  INSTALL_LOW_STORAGE: 901,
  INSTALL_FAILED: 955,
  INSTALL_SUCCESS: 957,
  INSTALL_START: 958,
  CLICK_REBOOT: 801,
  CLICK_LATER: 802,
  UPDATE_FAIL: 999,
  UPDATE_SUCCESS: 999,
};

const JrdReport = {
  log: window.JrdLogger.createLogger('#Report'),
  record: function (operation, status, extras = '') {
    JrdGecko.record(operation, status, extras);
  },
  report: function () {
    if (JrdNetwork.isOnline()) {
      JrdGecko.report();
    }
  }
};
