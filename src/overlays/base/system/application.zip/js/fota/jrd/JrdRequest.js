'use strict';
/* exported JrdRequest */
/* global JrdUtils */
/* global JrdNetwork */
/* global JrdDatabase */
/* global JrdOperator */
/* global JrdDlNetwork */

const NAME_VALUE_SEPARATOR = '=';
const PARAMETER_SEPARATOR = '&';
const SECURITY_KEY = '010010000110111101110111001000000110000101110010011001010010000001111001011011110111010100100000011001110110010101110100001000000111010001101000011010010111001100100000011010110110010101111001001000000111011101101111011100100110010000111111';
const NUMBER_CHAR = '0123456789';
const DOMAIN_PATTERN = /^(?!:\/\/)([a-zA-Z0-9-_]+\.)+[a-zA-Z]{2,6}$/;

const JrdRequest = {
  log: window.JrdLogger.createLogger('#Request'),
  /**
   * 生成一个带有时间戳的随机盐字符串
   * @returns {string}
   */
  salt: function () {
    let result = '';
    for (let i = 0; i < 6; i++) {
      const randomIndex = Math.floor(Math.random() * NUMBER_CHAR.length);
      result += NUMBER_CHAR[randomIndex];
    }
    const timestamp = Date.now();
    return timestamp.toString() + result;
  },
  /**
   * 将 Uint8Array 转换为十六进制字符串
   * @param {ArrayBuffer} buffer
   * @returns {string}
   */
  bufferToHex: function (buffer) {
    return Array.from(new Uint8Array(buffer))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  },
  /**
   * 通过 SHA-1 生成哈希值
   * @param {string} message
   * @returns {Promise<string>}
   */
  sha1: async function (message) {
    const msgBuffer = new TextEncoder().encode(message);
    const hashBuffer = await window.crypto.subtle.digest('SHA-1', msgBuffer);
    return this.bufferToHex(hashBuffer);
  },
  createVK: async function (params) {
    let vkStr = '';
    for (let i = 0; i < params.length; ++i) {
      const [fst, snd] = params[i];
      vkStr += `${fst}${NAME_VALUE_SEPARATOR}${snd}`;
      if (i === params.length - 1) {
        vkStr += SECURITY_KEY;
      } else {
        vkStr += PARAMETER_SEPARATOR;
      }
    }
    return await this.sha1(vkStr);
  },
  /**
   * 根据参数生成POST数据字符串
   * @param {Array.<[string, string]>} params
   * @returns {string}
   */
  createPostData: function (params) {
    let postData = params.map(pair => {
      const [key, value] = pair;
      return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
    });
    return postData.join('&');
  },
  //----------------------------------------------------------------------------------
  generateCheckParams: async function (auto) {
    const cu = JrdDatabase.getCu();
    const imei = JrdDatabase.getImei();
    const fv = JrdDatabase.getFV();
    const params = [
      ['id', imei],
      ['salt', this.salt()],
      ['curef', cu],
      ['fv', fv],
      ['type', 'Firmware'],
      ['mode', '2'],
      ['cltp', '10'],
    ];
    const vk = await this.createVK(params);
    const network = JrdNetwork.getNetwork();
    params.push(['vk', vk]);
    params.push(['cktp', auto === true ? '1' : '2']);
    params.push(['rtd', '1']);
    params.push(['chnl', network.wifi ? '1' : '2']);
    params.push(['osvs', '14']);
    params.push(['ckot', '2']);
    params.push(['ckab', '1']);
    params.push(['plmnname', '']);
    params.push(['plmncode', '']);
    return this.createPostData(params);
  },
  generateDownloadRequestParams: async function (auto) {
    const cu = JrdDatabase.getCu();
    const imei = JrdDatabase.getImei();
    const vInfo = JrdDatabase.getNewVersionJson();
    const params = [
      ['id', imei],
      ['salt', this.salt()],
      ['curef', cu],
      ['fv', vInfo.fv],
      ['tv', vInfo.tv],
      ['type', 'Firmware'],
      ['fw_id', vInfo.fwId],
      ['mode', '2'],
      ['cltp', '10'],
    ];
    const vk = await this.createVK(params);
    const network = JrdNetwork.getNetwork();
    params.push(['vk', vk]);
    params.push(['cktp', auto === true ? '1' : '2']);
    params.push(['rtd', '1']);
    params.push(['chnl', network.wifi ? '1' : '2']);
    return this.createPostData(params);
  },
  generateDownloadUrl: async function () {
    const dInfo = JrdDatabase.getDownloadInfoJson();
    if (dInfo.downloadUrl == null || dInfo.downloadUrl.length === 0) {
      return '';
    }
    if (dInfo.domains == null || dInfo.domains.length === 0) {
      return '';
    }
    const index = Math.floor(Math.random() * dInfo.domains.length);
    const domain = dInfo.domains[index];
    let url;
    if (DOMAIN_PATTERN.test(domain)) {
      url = `https://${domain}${dInfo.downloadUrl}`;
    } else {
      url = `http://${domain}${dInfo.downloadUrl}`;
    }
    return url;
  },
  parsePackageInfoFromJson: function (json) {
    const self = this;
    const vInfo = {};
    const gotu = json.GOTU;
    if (gotu == null) {
      return vInfo;
    }
    let cu = '';
    try {
      cu = gotu.CUREF;
    } catch (e) {
      self.log.e(`parsePackageInfoFromJson, e2=${e}.`);
    }
    vInfo.cu = cu ? cu : '';
    //--------------------------------
    let fv = '';
    try {
      fv = gotu.VERSION.FV;
    } catch (e) {
      self.log.e(`parsePackageInfoFromJson, e3=${e}.`);
    }
    vInfo.fv = fv ? fv : '';
    //--------------------------------
    let tv = '';
    try {
      tv = gotu.VERSION.TV;
    } catch (e) {
      self.log.e(`parsePackageInfoFromJson, e4=${e}.`);
    }
    vInfo.tv = tv ? tv : '';
    //--------------------------------
    let svn = '';
    try {
      svn = gotu.VERSION.SVN;
    } catch (e) {
      self.log.e(`parsePackageInfoFromJson, e5=${e}.`);
    }
    vInfo.svn = svn ? svn : '';
    //--------------------------------
    let fwId = '';
    try {
      fwId = gotu.FIRMWARE.FW_ID;
    } catch (e) {
      self.log.e(`parsePackageInfoFromJson, e6=${e}.`);
    }
    vInfo.fwId = fwId ? fwId : '';
    //--------------------------------
    let fileId = '';
    try {
      fileId = gotu.FIRMWARE.FILESET.FILE.FILE_ID;
    } catch (e) {
      self.log.e(`parsePackageInfoFromJson, e7=${e}.`);
    }
    vInfo.fileId = fileId ? fileId : '';
    //--------------------------------
    let fileSize = '';
    try {
      fileSize = gotu.FIRMWARE.FILESET.FILE.SIZE;
    } catch (e) {
      self.log.e(`parsePackageInfoFromJson, e8=${e}.`);
    }
    vInfo.fileSize = fileSize ? fileSize : '';
    //--------------------------------
    let checksum = '';
    try {
      checksum = gotu.FIRMWARE.FILESET.FILE.CHECKSUM;
    } catch (e) {
      self.log.e(`parsePackageInfoFromJson, e9=${e}.`);
    }
    vInfo.checksum = checksum ? checksum : '';
    //--------------------------------
    return vInfo;
  },
  parseNewVersionXml: function (xmlString) {
    const self = this;
    let vInfo = {};
    try {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(xmlString, 'application/xml');
      const xmlJson = self.newVersionXmlToJson(xmlDoc);
      vInfo = self.parsePackageInfoFromJson(xmlJson);
      self.log.i(`check=${JrdUtils.string(vInfo)}.`);
      try {
        const configNode = xmlDoc.getElementsByTagName('SPOP_LIST')[0];
        const config = self.configToJson(configNode);
        self.log.i(`config=${JrdUtils.string(config)}.`);
        vInfo.config = config;
      } catch (e) {
        self.log.e(`parse config error=${e}.`);
      }
    } catch (e) {
      self.log.e(`parseNewVersionXml, e=${e}.`);
    }
    return vInfo;
  },
  newVersionXmlToJson: function (xml) {
    const self = this;
    let obj = {};
    if (xml.nodeType === 3) {
      obj = xml.nodeValue.trim();
      return obj;
    }
    if (xml.nodeType === 1) { // 元素类型节点
      if (xml.attributes.length > 0) {
        obj['@attributes'] = {};
        for (let j = 0; j < xml.attributes.length; j++) {
          const attribute = xml.attributes.item(j);
          obj['@attributes'][attribute.nodeName] = attribute.nodeValue;
        }
      }
    } else if (xml.nodeType === 3) { // 文本类型节点
      obj = xml.nodeValue.trim(); // 去除空白
    }
    if (xml.hasChildNodes()) {
      for (let i = 0; i < xml.childNodes.length; i++) {
        const item = xml.childNodes.item(i);
        const nodeType = item.nodeType;
        const nodeName = item.nodeName;
        const nodeValue = item.nodeValue ? item.nodeValue.trim() : '';
        if (nodeName === 'SPOP_LIST') {
          continue;//配置单独解析
        }
        if (nodeType === 3 && nodeValue === '') {
          continue; // 跳过空白文本节点
        } else if (nodeType === 3) {
          return nodeValue; // 返回修剪过的文本节点值
        }
        if (typeof (obj[nodeName]) === 'undefined') {
          const result = self.newVersionXmlToJson(item);
          if (result || result === 0) {
            obj[nodeName] = result;
          }
        } else {
          if (!Array.isArray(obj[nodeName])) {
            const old = obj[nodeName];
            obj[nodeName] = [old];
          }
          const result = self.newVersionXmlToJson(item);
          if (result || result === 0) {
            obj[nodeName].push(result);
          }
        }
      }
    }
    return obj;
  },
  configToJson: function (xml) {
    const spopNodes = xml.getElementsByTagName('SPOP');
    const result = {};
    Array.from(spopNodes).forEach(node => {
      const type = node.getElementsByTagName('SPOP_TYPE')[0].textContent;
      result[`type_${type}`] = node.getElementsByTagName('SPOP_DATA')[0].textContent.trim();
    });
    return result;
  },
  parseDownloadInfoXml: function (xmlString) {
    const self = this;
    let dInfo = {};
    try {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(xmlString, 'application/xml');
      try {
        const fileId = xmlDoc.getElementsByTagName('FILE_ID')[0].textContent.trim();
        dInfo.fileId = fileId ? fileId : '';
      } catch (e) {
        self.log.e(`parse fileId error=${e}.`);
      }
      try {
        const downloadUrl = xmlDoc.getElementsByTagName('DOWNLOAD_URL')[0].textContent.trim();
        dInfo.downloadUrl = downloadUrl ? downloadUrl : '';
      } catch (e) {
        self.log.e(`parse downloadUrl error=${e}.`);
      }
      try {
        const domainsNode = xmlDoc.getElementsByTagName('SLAVE_LIST')[0];
        const domains = [];
        if (domainsNode) {
          const slaveNodes = domainsNode.getElementsByTagName('SLAVE');
          for (let i = 0; i < slaveNodes.length; i++) {
            domains.push(slaveNodes[i].textContent.trim());
          }
        }
        dInfo.domains = domains;
      } catch (e) {
        self.log.e(`parse domains error=${e}.`);
      }
    } catch (e) {
      self.log.e(`parseDownloadInfoXml, e=${e}.`);
    }
    return dInfo;
  },
  configType6: function (config) {
    const self = this;
    const dataType6 = JrdUtils.toJson(config.type_6);
    if (!dataType6) {
      return;
    }
    //type=6,resp={"format version":1,"data":{"check":false,"download":true}}
    const download6 = dataType6.data.download;
    self.log.i('download6:' + download6);
    if (download6 && download6 === true) {
      JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_AND_CELLULAR);
    } else {
      JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_AUTO);
    }
  },
  configType7: function (config) {
    const self = this;
    const dataType7 = JrdUtils.toJson(config.type_7);
    if (!dataType7) {
      return;
    }
    // {"type_7":"{\"format version\":1,\"data\":{\"type\":\"mandatory\",\"type_data\":{\"download\":\"wifi_auto\",\"install\":\"auto\"}}}"}.
    const type7 = dataType7.data.type;
    const download7 = dataType7.data.type_data.download;
    const install7 = dataType7.data.type_data.install;
    self.log.i('type7:' + type7 + ', download7:' + download7 + ', install7:' + install7);
    if (type7 === 'mandatory') {
      if (download7 === 'auto') {
        JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_AND_CELLULAR);
      } else if (download7 === 'wifi_auto') {
        JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_AUTO);
      } else if (download7 === 'wifi_only') {
        JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_ONLY);
      }
      if (JrdDatabase.getOperator() !== JrdOperator.TF) {
        if (install7 === 'auto') {
          JrdDatabase.setPostponeShowTimes(0);
        } else {
          JrdDatabase.setPostponeShowTimes(10);
        }
      }
    }
  },
  configType17: function (config) {
    const self = this;
    const dataType17 = JrdUtils.toJson(config.type_17);
    if (!dataType17) {
      return;
    }
    //type=17,resp={"format version":1,"data":{"upgrade":true}}
    const upgrade17 = dataType17.data.upgrade;
    self.log.i('upgrade17:' + upgrade17);
    if (upgrade17 && upgrade17 === true) {
      JrdDatabase.setAutoDownload(JrdDlNetwork.WIFI_AND_CELLULAR);
      if (JrdDatabase.getOperator() !== JrdOperator.TF) {
        JrdDatabase.setPostponeShowTimes(10);
      }
    }
  },
  updateConfig: function (config) {
    const self = this;
    if (!config) {
      self.log.i('updateConfig, no new config.');
      return;
    }
    self.configType6(config);
    self.configType7(config);
    self.configType17(config);
  },
};
