/* exported JrdThread */
'use strict';

const JrdThread = {
  WORKER_URL: 'js/fota/JrdWorker.js',
  compress: function (payload) {
    return new Promise((resolve, reject) => {
      const worker = new Worker(this.WORKER_URL);
      // Protect against the worker failing for whatever reason.
      const workerTimeout = setTimeout(function () {
        worker.terminate();
        reject('Failed to process.');
      }, 10000);
      worker.onmessage = function (msg) {
        clearTimeout(workerTimeout);
        worker.terminate();
        const data = msg.data;
        if (data.returnResult) {
          resolve(data.params);
        } else {
          reject('Failed to process: ' + data.error);
        }
      };
      worker.postMessage({
        cmd: 'check',
        payload: payload
      });
    });
  }
};

window.JrdThread = JrdThread;
