'use strict';
/* exported JrdUtils */
/* global JrdDatabase */
/* global JrdBattery */
/* global JRD_BATTERY_LEVEL_LIMIT */
/* global CpuManager */
/* global JrdOperator */
/* global JrdNetwork */

const JrdUtils = {
  log: window.JrdLogger.createLogger('#Utils'),
  getReadableFileSize: function (size, digits) { // in: size in Bytes
    if (!size) {
      return {
        size: '0',
        unit: 'B'
      };
    }
    const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    let i = 0;
    while (size >= 1024) {
      size /= 1024;
      ++i;
    }
    const sizeString = size.toFixed(digits || 0);
    const sizeDecimal = parseFloat(sizeString);
    return {
      size: sizeDecimal.toString(),
      unit: units[i]
    };
  },
  formatSize: function (size) {
    const self = this;
    if (size == null) {
      return 0;
    }
    const fixedDigits = (size < 1024 * 1024) ? 0 : 1;
    const sizeInfo = self.getReadableFileSize(size, fixedDigits);
    return sizeInfo.size + sizeInfo.unit;
  },
  string: function (object) {
    let str = '';
    try {
      if (object) {
        str = JSON.stringify(object);
      }
    } catch (e) {
      //do nth;
    }
    return str;
  },
  cropTailOfString: function (input, retentionLength) {
    const self = this;
    const str = self.optString(input);
    if (str.length > retentionLength) {
      return str.substring(0, retentionLength);
    }
    return str;
  },
  optString: function (value) {
    if (typeof value !== 'string') {
      if (value === null || value === undefined) {
        return '';
      }
      try {
        let convertedValue = value.toString();
        if (typeof convertedValue === 'string') {
          return convertedValue;
        }
      } catch (error) {
      }
      return '';
    }
    return value;
  },
  optInt: function (value) {
    if (typeof value === 'number') {
      return value;
    }
    if (value === null || value === undefined) {
      return 0;
    }
    let convertedValue = Number(value);
    return isNaN(convertedValue) ? 0 : convertedValue;
  },
  isEmpty: function (value) {
    return !value || value === '';
  },
  isNotBlank(str) {
    return typeof str === 'string' && str.trim().length > 0;
  },
  getTimeInterval: function (hour, min, ap) {
    const ONE_SECOND = 1000;
    const ONE_MIN = 60 * ONE_SECOND;
    const ONE_HOUR = 60 * ONE_MIN;
    const ONE_DAY = 24 * ONE_HOUR;

    [hour, min] = [parseInt(hour), parseInt(min)];
    if (12 === hour) {
      hour = (ap === 'AM') ? 0 : 12;
    } else {
      hour = (ap === 'AM') ? hour : (hour + 12);
    }
    let setMillSeconds = Number(hour) * ONE_HOUR + Number(min) * ONE_MIN;
    let now = new Date();
    let nowMillSeconds = Number(now.getHours()) * ONE_HOUR + Number(now.getMinutes()) * ONE_MIN;
    let timeInterval;
    if (nowMillSeconds < setMillSeconds) {
      //The set time is greater than the current time, schedule on today
      timeInterval = setMillSeconds - nowMillSeconds;
    } else {
      //The set time is less than the current time, schedule on next day.
      timeInterval = ONE_DAY - nowMillSeconds + setMillSeconds;
    }
    //Guaranteed on the minute
    return timeInterval - now.getSeconds() * ONE_SECOND;
  },
  getFreeSpace: async function () {
    try {
      return await navigator.b2g.getDeviceStorage('sdcard').freeSpace();
    } catch (error) {
      return 0;
    }
  },
  needSize: function () {
    const self = this;
    const updateInfo = JrdDatabase.getUpdateInfo();
    const pkgSize = JrdUtils.optInt(updateInfo.size);
    let needSize = 0;
    if (pkgSize > 0) {
      needSize = pkgSize * 1.3;
    }
    self.log.i('pkgSize=' + pkgSize + ', needSize=' + needSize);
    return needSize;
  },
  isStorageEnough: async function () {
    const self = this;
    const testLowStorage = JrdDatabase.getTestLowStorage();
    if (testLowStorage && testLowStorage === true) {
      return false;
    }
    const needSize = self.needSize();
    const freeSpace = self.optInt(await self.getFreeSpace());
    self.log.i('isStorageEnough, freeSpace:' + freeSpace + ', needSize:' + needSize);
    return freeSpace >= needSize;
  },
  isBatteryEnough: function () {
    const self = this;
    const testLowBattery = JrdDatabase.getTestLowBattery();
    if (testLowBattery && testLowBattery === true) {
      return false;
    }
    const level = JrdBattery.getBatteryLevel();
    const value = level >= JRD_BATTERY_LEVEL_LIMIT;
    self.log.i('isBatteryEnough, level:' + level + ', value=' + value);
    return value;
  },
  getDisplayInfo: function (updateInfo) {
    const self = this;
    const operator = JrdDatabase.getOperator();
    const displayShort = operator !== JrdOperator.TMO
      && operator !== JrdOperator.DISH;       // FR: GF5GDISH-2100
    let version = (updateInfo && updateInfo.version) ? updateInfo.version : '';
    if (displayShort && version.length > 4) {
      version = version.substring(0, 4);
    }
    let dummy = '';
    if (version && version !== '') {
      let svn = (updateInfo && updateInfo.svn) ? updateInfo.svn : '';
      // 判断字符串中是否包含 '.'，可能为 '.DMY' 或 '.FAKE'
      const dotIndex = svn.indexOf('.');
      if (dotIndex !== -1) { // 取出 '.' 及后面的字符串
        dummy = svn.substring(dotIndex);
      }
    }
    let dSize = ''; //string
    let size = (updateInfo && updateInfo.size) ? updateInfo.size : 0;
    if (size > 0) {
      dSize = (size / (1024 * 1024)).toFixed(2);
    }
    const result = {
      version: (version + dummy),
      size: dSize
    };
    self.log.i(`getDisplayInfo, result=${JrdUtils.string(result)}`);
    return result;
  },
  toJson: function (jsonString) {
    if (jsonString === null || jsonString === undefined) {
      return null;
    }
    try {
      return JSON.parse(jsonString);
    } catch (e) {
      return null;
    }
  },
  requestCpuWakeLock: function () {
    const self = this;
    try {
      if (self._cpuManager) {
        self._cpuManager.start();
      } else {
        self._cpuManager = new CpuManager();
        self._cpuManager.start();
      }
      self.log.i(`requestCpuWakeLock, lock.`);
    } catch (e) {
      self.log.i(`requestCpuWakeLock, e=${e}.`);
    }
  },
  releaseCpuWakeLock: function () {
    const self = this;
    try {
      if (self._cpuManager) {
        self._cpuManager.stop();
        self._cpuManager = null;
      } else {
        self._cpuManager = new CpuManager();
        self._cpuManager.stop();
        self._cpuManager = null;
      }
      self.log.i(`releaseCpuWakeLock, unlock.`);
    } catch (e) {
      self.log.i(`releaseCpuWakeLock, e=${e}.`);
    }
  },
  canUSCC: function () {
    const self = this;
    const operator = JrdDatabase.getOperator();
    const result = (operator === JrdOperator.TMO && JrdNetwork.isUSCCNetwork() === true);
    self.log.i(`canUSCC=${result}, operator=${operator}.`);
    return result;
  },
};
