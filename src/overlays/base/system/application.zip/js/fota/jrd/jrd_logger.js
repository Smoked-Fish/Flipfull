'use strict';

(function (exports) {

  const LOG_LEVEL_DEBUG = 1;
  const LOG_LEVEL_INFO = 2;
  const LOG_LEVEL_WARN = 3;
  const LOG_LEVEL_ERROR = 4;

  // 工厂函数，用于创建带有特定标签的新 JrdLogger 对象
  const createLogger = function (tag) {
    return {
      printLog: function (level, info) {
        const chunkSize = 1000;//Max1024,剩24给TAG
        for (let i = 0; i < info.length; i += chunkSize) {
          window.navigator.b2g.mozJrdFota.printLog(level, `${tag}`, `${info.slice(i, i + chunkSize)}`);
        }
      },
      d: function (info) {
        this.printLog(LOG_LEVEL_DEBUG, info);
      },
      i: function (info) {
        this.printLog(LOG_LEVEL_INFO, info);
      },
      w: function (info) {
        this.printLog(LOG_LEVEL_WARN, info);
      },
      e: function (info) {
        this.printLog(LOG_LEVEL_ERROR, info);
      },
    };
  };
  exports.JrdLogger = {createLogger};
}(window));
