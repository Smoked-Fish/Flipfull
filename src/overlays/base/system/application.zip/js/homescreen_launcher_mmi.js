'use strict';
/* global Service, HomescreenWindow, WebActivity, appWindowManager */
(function(exports) {
  /**
   * HomescreenLauncher is responsible for launching the homescreen window
   * instance and make sure it's a singleton.
   *
   * Every extermal modules should use
   * <code>window.homescreenLauncher.getHomescreen()</code>
   * to access the homescreen window instance. Since window.homescreenLauncher
   * should be instantiated and started in bootstrap.js
   *
   * @example
   * var home = HomescreenLauncher.getHomescreen();
   * home.open(); // Do the open animation.
   *
   * @class HomescreenLauncher
   * @requires module:SettingsObserver
   * @requires HomescreenWindow
   */
  var HomescreenLauncher = function() {
  };

  /**
   * Fired when homescreen launcher detect 'homescreen.manifestUrl' changed
   * @event HomescreenLauncher#homescreen-changed
   */
  /**
   * Fired when homescreen launcher is done retriving 'homescreen.manifestUrl'
   * @event HomescreenLauncher#homescreen-ready
   */

  HomescreenLauncher.prototype = {
    _currentManifestUrl: '',

    _notificationStoreReady: false,
    _homescreenLoaded: false,
    _logohidden: false,

    _started: false,

    _ready: false,

    /**
     * Homescreen launcher is ready or not. Homescreen launcher is ready
     * only when it is done retrieving 'homescreen.manifestUrl'
     * from settings DB.
     *
     * @access public
     * @memberOf HomescreenLauncher.prototype
     * @type {boolean}
     */
    get ready() {
      return this._ready;
    },

    /**
     * manifest URL of homescreen.
     *
     * @access public
     * @memberOf HomescreenLauncher.prototype
     * @type {string}
     */
    get manifestUrl() {
      return this._currentManifestUrl;
    },

    _fetchSettings: function hl_fetchSettings() {
     //modified by cheng.luo mmitest
      const homescreenManifestUrl = window.AppOrigin.getManifestURL('mmitest');
      this._currentManifestUrl = homescreenManifestUrl;
      this.getInstance();
      this._ready = true;
      window.dispatchEvent(new CustomEvent('homescreen-ready'));
    },

    /**
     * Start process
     * ![Homescreen launch process](http://i.imgur.com/JZ1ibkc.png)
     *
     * @memberOf HomescreenLauncher.prototype
     */
    start: function hl_start() {
      if (this._started) {
        return;
      }
      this._started = true;
      //add a workaround solution to get sdcard for mmitest by cheng.luo
      window.setTimeout(() => {
        this._fetchSettings();
      },1000);
      window.addEventListener('appopening', this);
      window.addEventListener('notification-update-launcher', this);
      window.addEventListener('notification-store-ready', this);
      window.addEventListener('statusbar-update-launcher', this);
      window.addEventListener('homescreenloaded', this, { once: true });
      window.addEventListener('logohidden', this, { once: true });
    },

    /**
     * Stop process
     *
     * @memberOf HomescreenLauncher.prototype
     */
    stop: function hl_stop() {
      this.getInstance().kill();

      this._currentManifestUrl = '';
      window.removeEventListener('appopening', this);
      window.removeEventListener('notification-update-launcher', this);
      window.removeEventListener('notification-store-ready', this);
      window.removeEventListener('statusbar-update-launcher', this);
      this._started = false;
    },

    getAllNotices: function hl_getAllNotices(detail) {
      if (!this._notificationStoreReady || !this._homescreenLoaded ||
        !this._logohidden) {
        return;
      }
      let allNotices = Service.query('NotificationStore.getAll');
      let notices = {};
      allNotices.forEach((notice) => {
        const manifestUrl = this.getManifestUrl(notice);
        if (notices[manifestUrl]) {
          notices[manifestUrl]++;
        } else {
          notices[manifestUrl] = 1;
        }
      });

      const activity = new WebActivity('notices-updated', {
        notices: notices,
        screenLocked: Service.query('locked'),
        listUnread: Service.query('listUnread'),
        newNotice: this.getManifestUrl(detail)
      });
      activity.start();
    },

    getManifestUrl: function hl_getManifestUrl(detail) {
      if (!detail) {
        return '';
      }
      let manifestUrl = detail.manifestURL;
      if (detail.manifestURL === window.AppOrigin.getManifestURL('system') &&
        detail.icon &&
        detail.icon.includes('voicemail.png')) {
        manifestUrl = 'voicemail';
      } else if (detail.data &&
        detail.data.systemMessageTarget === 'system-download') {
        manifestUrl = 'download';
      } else if (detail.icon &&
        detail.icon.includes('icon_bluetooth.png')) {
        manifestUrl = 'bluetooth';
      } else if (detail.id && detail.id.indexOf('batteryFull') !== -1) {
        manifestUrl = 'battery';
      }
      return manifestUrl;
    },

    /**
     * General event handler interface.
     *
     * @param  {DOMEvent} evt The event.
     * @type {boolean}
     */
    handleEvent: function hl_handleEvent(evt) {
      switch (evt.type) {
        case 'appopening':
          // Fade out homescreen if the opening app is landscape.
          if (evt.detail.rotatingDegree === 90 ||
              evt.detail.rotatingDegree === 270) {
            this.getHomescreen().fadeOut();
          }
          break;
        case 'notification-update-launcher':
          this.getAllNotices(evt.detail);
          break;
        case 'notification-store-ready':
          this._notificationStoreReady = true;
          this.getAllNotices();
          break;
        case 'homescreenloaded':
          this._homescreenLoaded = true;
          this.getAllNotices();
          break;
        case 'statusbar-update-launcher':
          this.getAllNotices();
          break;
        case 'logohidden':
          this._logohidden = true;
          this.getAllNotices();
          break;
        default:
          break;
      }
    },

    /**
     * Get instance of homescreen window singleton
     *
     * @memberOf HomescreenLauncher.prototype
     * @params {Boolean} ensure Ensure the homescreen app is alive.
     * @returns {HomescreenWindow} Instance of homescreen window singleton, or
     *                             null if HomescreenLauncher is not ready
     */
    getHomescreen: function hl_getHomescreen(ensure) {
      if (this._currentManifestUrl === '') {
        console.warn('HomescreenLauncher: not ready right now.');
        return null;
      }
      const homescreenInstance = this.getInstance();

      if (ensure) {
        homescreenInstance.ensure();
      }
      return homescreenInstance;
    },

    getInstance: function hl_getInstance() {
      if (!this._currentManifestUrl) {
        throw new Error('No manifest URL for homescreen');
      }

      const homescreenInstance =
        appWindowManager.getApp(this._currentManifestUrl);

      if (homescreenInstance) {
        return homescreenInstance;
      }

      if (appWindowManager.havePreallocatedApp()) {
        return appWindowManager.reusePreallocatedApp({
          manifestUrl: this._currentManifestUrl,
          isHomescreen: true,
        });
      }

      return new HomescreenWindow(this._currentManifestUrl);
    }
  };

  exports.HomescreenLauncher = HomescreenLauncher;
}(window));
