/* global EsimAfterSalesServer */
'use strict';

// Create an instance of the EsimAfterSalesServer
const server = new EsimAfterSalesServer();

/**
 * Function to create an HTTP response.
 * @param {number} statusCode - The HTTP status code.
 * @param {string} body - The body of the response.
 * @returns {string} - The complete HTTP response.
 */
function createHttpResponse(statusCode, body) {
  const CRLF = '\r\n';
  const bodyLength = body.length;
  const headers = [
    `HTTP/1.1 ${statusCode}${CRLF}`,
    `Content-Type: application/json${CRLF}`,
    `Content-Length: ${bodyLength}${CRLF}${CRLF}`
  ].join('');
  return headers + body;
}

/**
 * Function to create a JSON formatted response.
 * @param {string} status - The status of the response (success/failure).
 * @param {object} extra - Additional data to be included in the response.
 * @returns {string} - The JSON formatted response.
 */
function createJsonResponse(status, extra) {
  return JSON.stringify({ status, extra });
}

/**
 * Function to execute the BF20 command.
 * @returns {Promise<string>} - A promise that resolves with a success message.
 */
async function executeEuiccInfo2Command() {
  // Implementation for executing BF20/BF22 command
  try {
    var eUiccInfo2 = await navigator.b2g.eUiccManager.GetEuiccInfo2();
    return createJsonResponse('success', { data: eUiccInfo2 });
  } catch (error) {
    return createJsonResponse('failure', { reason: `get eUiccInfo2 failed: ${error}` });
  }
}

/**
 * Function to clear all profiles.
 * @returns {Promise<string>} - A promise that resolves with a JSON response indicating success or failure.
 */
async function clearProfiles() {
  try {
    await navigator.b2g.eUiccManager.resetMemory(2); // Using 2 as mode which is OPTIONAL_PROFILES
    return createJsonResponse('success', { data: 'all profiles cleared' });
  } catch (error) {
    return createJsonResponse('failure', { reason: `Clear profiles failed: ${error}` });
  }
}

/**
 * Function to check if any profile is active.
 * @returns {Promise<string>} - A promise that resolves with a JSON response indicating whether an active profile was found.
 */
async function checkProfileActive() {
  try {
    const profiles = await navigator.b2g.eUiccManager.queryProfiles();
    const activeProfile = profiles.find(profile => profile.state === 'active');
    if (activeProfile) {
      return createJsonResponse('success', { data: 'profile active' });
    } else {
      return createJsonResponse('success', { data: 'no active profile' });
    }
  } catch (error) {
    return createJsonResponse('failure', { reason: `Check profile active failed: ${error}` });
  }
}

/**
 * Function to disable an active test profile.
 * @returns {Promise<string>} - A promise that resolves with a JSON response indicating success or failure.
 */
async function disableTestProfile() {
  try {
    const profiles = await navigator.b2g.eUiccManager.queryProfiles();
    const testProfile = profiles.find(profile => profile.profileClass.includes('test') && profile.state === 'active'); // Assuming test profiles contain 'test' in profileClass
    if (testProfile) {
      await navigator.b2g.eUiccManager.disableProfile(testProfile.iccid);
      return createJsonResponse('success', { data: 'test profile disabled' });
    } else {
      return createJsonResponse('success', { data: 'no active test profile to disable' });
    }
  } catch (error) {
    return createJsonResponse('failure', { reason: `Disable test profile failed: ${error}` });
  }
}

// Add an event listener to handle incoming requests
server.addEventListener('request', async (event) => {
  const { request, socket } = event.detail;
  let response;

  // Determine which command to execute based on the request
  if (request[1].includes('command=start-service')) {
    dump('esim_after_sales start-service');
    response = createHttpResponse(200, createJsonResponse('success', { data: 'service started' }));
  } else if (request[1].includes('command=clear-profile')) {
    dump('esim_after_sales clear profile');
    response = createHttpResponse(200, await clearProfiles());
  } else if (request[1].includes('command=esim-status-check')) {
    dump('esim_after_sales esim status check');
    response = createHttpResponse(200, await executeEuiccInfo2Command());
  } else if (request[1].includes('command=profile-active-check')) {
    dump('esim_after_sales profile active check');
    response = createHttpResponse(200, await checkProfileActive());
  } else if (request[1].includes('command=disable-test-profile')) {
    dump('esim_after_sales disable test profile');
    response = createHttpResponse(200, await disableTestProfile());
  } else {
    dump('esim_after_sales unknown command');
    response = createHttpResponse(400, createJsonResponse('failure', { reason: 'invalid command' }));
  }

  // Send the response
  socket.send(response);
  socket.close();
});

// Initialize the eSIM after sales server
dump('esim_after_sales init_esim_after_sales_server');
server.start();
