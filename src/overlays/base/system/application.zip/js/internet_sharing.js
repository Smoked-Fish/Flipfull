'use strict';
/* global SettingsObserver, SIMSlotManager, Service, DUMP, SimSettingsHelper*/

(function(exports) {

  /**
   * Internet Sharing module responsible for checking the availability of
   * internet sharing based on the status of airplane mode.
   * @requires ModalDialog
   * @class InternetSharing
   */
  function InternetSharing() {}

  const WIFI_SSID_KEY = 'tethering.wifi.ssid';
  const WIFI_SECURITY_KEY = 'tethering.wifi.security.type';
  const WIFI_PASSWORD_KEY = 'tethering.wifi.security.password';
  const WIFI_BROADCAST_SSID_KEY = 'tethering.wifi.broadcast.ssid';
  const WIFI_MAX_NUM_STA = 'tethering.wifi.maxnumsta';
  const WIFI_AP_BAND = 'tethering.wifi.band';

  InternetSharing.prototype = {
    autoTurnoffHandle: null,
    autoTurnoffInterval: 0,
    startTimestamp: 0,
    lastConnectedClients: 0,
    tetheringWifiEnabled: false,
    tetheringUsbEnabled: false,  //add by tailiangchen for jira GF5GTMO-4842 20241031
    wifiSavedEnabled: false,  //add by tailiangchenf for jira GF5GTMO-4842 20241031
    taskScheduler: null,
    tetheringWifiSsid: '',
    tetheringMhsCheckIgnore: false,//add by tailiangchen for jira GF5GTMO-4842 20241031
    isTetheringChanged: false,    //add by tailiangchen for GF5GTMO-4842 20241031
    tetheringWifiSecurityType: '',
    tetheringWifiSecurityPassword: '',
    operator: null,

    _taskScheduler: function() {
      return {
        _isLocked: false,
        _tasks: [],
        _lock: function() {
          this._isLocked = true;
        },
        _unlock: function() {
          this._isLocked = false;
          this._executeNextTask();
        },
        _executeNextTask: function() {
          if (this._isLocked) {
            console.log('[InternetSharing] waiting for the last task to end');
            return;
          }
          var nextTask = this._tasks.shift();
          if (nextTask) {
            this._lock();
            navigator.b2g.tetheringManager.setTetheringEnabled(nextTask.value,
              nextTask.type, nextTask.info).then(() => {
              this._unlock();
            }, () => {
              this._unlock();
            });
          }
        },
        enqueue: function(value, type, info) {
          this._tasks.push({
            value,
            type,
            info
          });
          this._executeNextTask();
        }
      };
    },
    /**
     * Called whenever there is a setting change in wifi tethering.
     * Validates that we can turn internet sharing on, and saves state to
     * @memberof InternetSharing.prototype
     */
    wifiInternetSharingSettingsChangeHandler: function(value) {
      DUMP('WifiTethering set to ' + value);
      if (this.tetheringWifiEnabled  && !value) {
        this.resetWifiWhenTetheringTurnedOff();
      }

      this.tetheringWifiEnabled = value;
      this.resetAutoTimeoutHandle();
      if (!value) {
        this.taskScheduler.enqueue(false, 'wifi');
      } else if (Service.query('AirplaneMode.isActive') && value) {
        var title = 'apmActivated';
        var buttonText = 'ok';
        var message ='noHotspotWhenAPMisOnWifiHotspot';
        if (!Service.query('isWifiCertified')) {
          message = 'noHotspotWhenAPMisOnWlanHotspot';
        }
        Service.request('DialogService:show', {
          id: 'apm-activated-alert',
          header: title,
          content: message,
          ok: buttonText,
          type: 'alert',
          noClose: true,
          onOk: () => {
            Service.request('DialogService:hide', 'apm-activated-alert');
          }
        });
        SettingsObserver.setValue([{
          name: 'tethering.wifi.enabled',
          value: false
        }]);
      } else {
        //add begin by tailiangchen for jira GF5GTMO-4763 20241024
        const list = [
          WIFI_SSID_KEY,
          WIFI_SECURITY_KEY,
          WIFI_PASSWORD_KEY,
          WIFI_BROADCAST_SSID_KEY,
          WIFI_MAX_NUM_STA,
          WIFI_AP_BAND
        ];
        SettingsObserver.getBatch(list).then(resultlist => {
          console.log(`get settings:${JSON.stringify(resultlist)}`);
          const dbCache = {};
          for (let i= 0; i < resultlist.length; i++) {
            dbCache[resultlist[i].name] = resultlist[i].value;
          }
          this.taskScheduler.enqueue(true, 'wifi', {
            ssid: dbCache[WIFI_SSID_KEY],
            security: dbCache[WIFI_SECURITY_KEY],
            key: dbCache[WIFI_PASSWORD_KEY],
            hidden: !dbCache[WIFI_BROADCAST_SSID_KEY],
            maxNumSta: dbCache[WIFI_MAX_NUM_STA],
            band: dbCache[WIFI_AP_BAND]
          });
        });
        //add end by tailiangchen for jira GF5GTMO-4763 20241024
      }
    },

    usbInternetSharingSettingsChangeHandler: function(value) {
      DUMP('UsbTethering set to ' + value);
      this.taskScheduler.enqueue(!!value, 'usb');
      //Task-10232568/10475261 modify-begin shangpeng.su@tcl.com 2020.12.17
      if (this.tetheringUsbEnabled && !value) {
        this.resetWifiWhenTetheringTurnedOff();
      }
      this.tetheringUsbEnabled = value;
      //Task-10232568/10475261 modify-end shangpeng.su@tcl.com 2020.12.17
    },

    //add begin by tailiangchen for jira GF5GTMO-4842 20241031
    wifiSavedEnabledSettingsChangeHanlder: function(value) {
      this.wifiSavedEnabled = value;
    },

    tetheringWifiUsbChangehandler: function (value) {
      this.isTetheringChanged = value;
    },

    tetheringMhsCheckIgnoreChangeHandler: function(value) {
      this.tetheringMhsCheckIgnore = value;
    },
    //add end by tailiangchen for jira GF5GTMO-4842 20241031

    clearAutoTimeoutHandle: function() {
      if (this.autoTurnoffHandle) {
        window.clearTimeout(this.autoTurnoffHandle);
        this.autoTurnoffHandle = null;
      }
    },

    wifiTetheringTimeoutChanged: function(value) {
      this.autoTurnoffInterval = value;
      this.resetAutoTimeoutHandle();
    },

    resetAutoTimeoutHandle: function() {
      this.clearAutoTimeoutHandle();
      if (!this.lastConnectedClients && this.tetheringWifiEnabled &&
        this.autoTurnoffInterval) {
        this.autoTurnoffHandle = window.setTimeout(() => {
          SettingsObserver.setValue([{
            name: 'tethering.wifi.enabled',
            value: false
          }]);
        }, this.autoTurnoffInterval * 1000);
      }
    },

    wifiStationchange: function() {
      let connectedClients = Service.query('Wifi.connectedClients');
      if (this.lastConnectedClients !== connectedClients) {
        this.lastConnectedClients = connectedClients;
        this.resetAutoTimeoutHandle();
      }
    },

    turnOffInternetSharing: function(value) {
      //add by tailiangchen for jira GF5GTMO-5751
      if ('TMO' === this.operator) {
        this.tetheringMhsCheckIgnore = true;
      }
      if (!value || (SIMSlotManager.noSIMCardOnDevice() && !this.tetheringMhsCheckIgnore)) {
        SettingsObserver.setValue([{
          name: 'tethering.wifi.enabled',
          value: false
        }, {
          name: 'tethering.wifi.usb.change',  //fix begin by tailiangchen for defect-10950562
          value: false
        }, {
          name: 'tethering.usb.enabled',
          value: false
        }]);
      }
    },

    turnOffInternetSharingByWifi: function(value) {
      //add by tailiangchen for jira GF5GTMO-5751
      if ('TMO' === this.operator) {
        this.tetheringMhsCheckIgnore = true;
      }
      if (value || (SIMSlotManager.noSIMCardOnDevice() && !this.tetheringMhsCheckIgnore)) {
        SettingsObserver.setValue([{
          name: 'tethering.wifi.enabled',
          value: false
        }, {
          name: 'tethering.wifi.usb.change',  //fix begin by tailiangchen for defect-10950562
          value: false
        }, {
          name: 'tethering.usb.enabled',
          value: false
        }]);
      }
    },

    turnOffUsbTethering: function() {
      SettingsObserver.setValue([{
        name: 'tethering.usb.enabled',
        value: false
      }, {
        name: 'tethering.wifi.usb.change',  //fix begin by tailiangchen for defect-10950562
        value: false
      }]);
    },

    //Task-10232568 add-begin shangpeng.su@tcl.com 2020.11.20
    resetWifiWhenTetheringTurnedOff: function () {
      let operatorEnableWifiList = ['VZW', 'TMO', 'USCC', 'TF', 'USOM'];
      if (this.operator && (operatorEnableWifiList.indexOf(this.operator) !== -1)) {
        if (this.wifiSavedEnabled) {
          if (this.isTetheringChanged) {
            SettingsObserver.setValue(
              [
                { name: 'tethering.wifi.usb.change', value: false}
              ]
            );
          } else {
            DUMP ('enable wifi when tethering turned off');
            SettingsObserver.setValue(
              [
                { name: 'wifi.saved.enabled', value: false },
                { name: 'tethering.wifi.usb.change', value: false}
              ]
            );
            if(!(Service.query('AirplaneMode.isActive'))) {
              SettingsObserver.setValue(
                [
                  { name: 'wifi.enabled', value: true }
                ]
              );
            }
          }
        }
      }
    },
    //Task-10232568 add-end shangpeng.su@tcl.com 2020.11.20

    generateHotspotPassword: function() {
      const words = [
        'amsterdam',
        'ankara',
        'auckland',
        'belfast',
        'berlin',
        'boston',
        'calgary',
        'caracas',
        'chicago',
        'dakar',
        'delhi',
        'dubai',
        'dublin',
        'houston',
        'jakarta',
        'lagos',
        'lima',
        'madrid',
        'newyork',
        'osaka',
        'oslo',
        'porto',
        'santiago',
        'saopaulo',
        'seattle',
        'stockholm',
        'sydney',
        'taipei',
        'tokyo',
        'toronto'
      ];
      let password = words[Math.floor(Math.random() * words.length)];
      for (let i = 0; i < 4; i++) {
        password += Math.floor(Math.random() * 10);
      }
      return password;
    },

    initWifiTethering: function() {
      SettingsObserver.observe('tethering.wifi.security.type', 'wpa-psk',
        (value) => {
        this.tetheringWifiSecurityType = value;
      });

      SettingsObserver.observe('tethering.wifi.ssid', '',
        (value) => {
        this.tetheringWifiSsid = value;
      });

      SettingsObserver.observe('tethering.wifi.band.type', '2.4G',
        (value) => {
        this.tetheringWifiBandType = value;
      });

      SettingsObserver.observe('tethering.wifi.security.password', '',
        (value) => {
        if (!value) {
          value = this.generateHotspotPassword();
          SettingsObserver.setValue([{
            name: 'tethering.wifi.security.password',
            value
          }]);
        }
        this.tetheringWifiSecurityPassword = value;
      });
    },

    /**
     * Starts the InternetSharing class.
     * @memberof InternetSharing.prototype
     */
    start: function() {
      this.taskScheduler = this._taskScheduler();
      // listen changes after value is restored.
      SettingsObserver.observe('tethering.wifi.enabled', false,
        this.wifiInternetSharingSettingsChangeHandler.bind(this), true);
      SettingsObserver.observe('tethering.usb.enabled', false,
        this.usbInternetSharingSettingsChangeHandler.bind(this));
      SettingsObserver.observe('ril.data.enabled', false,
        this.turnOffInternetSharing.bind(this));
      SettingsObserver.observe('tethering.wifi.timeout', 0,
        this.wifiTetheringTimeoutChanged.bind(this));
      SettingsObserver.observe('wifi.enabled', true,
        this.turnOffInternetSharingByWifi.bind(this));
      //Defect-10651366 add-begin shangpeng.su 2021.01.21
      SettingsObserver.observe('wifi.saved.enabled', false,
        this.wifiSavedEnabledSettingsChangeHanlder.bind(this));
      SettingsObserver.observe('tethering.wifi.usb.change', false,
        this.tetheringWifiUsbChangehandler.bind(this));
      SettingsObserver.observe('tethering.mhs.check.ignore', false,
        this.tetheringMhsCheckIgnoreChangeHandler.bind(this));
      window.addEventListener('wifi-stationchange',
        this.wifiStationchange.bind(this));
      if (!window.navigator.b2g.powerSupplyManager.powerSupplyOnline ||
        window.navigator.b2g.powerSupplyManager.powerSupplyType !== 'USB') {
        this.turnOffUsbTethering();
      }
      if (navigator.b2g.usbManager) {
        navigator.b2g.usbManager.onusbstatuschange = (evt) => {
          if (!evt.deviceAttached) {
            this.turnOffUsbTethering();
          }
        };
      }
      SettingsObserver.setValue([{
        name: 'tethering.wifi.enabled',
        value: false
      }]);
      //this.initWifiTethering();
      //add begin by tailiangchen for jira GF5GTMO-4846 20241028
      if (navigator.b2g.engmodeManager) {
        navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name')
          .then(value => {
            this.operator = value;
            let defaultAutotimeout = 0;
            if (this.operator === 'VZW') {
              defaultAutotimeout = 1200;
            } else if (this.operator === 'TMO') {
              defaultAutotimeout = 1200;
            }
            if (defaultAutotimeout > 0) {
              SettingsObserver.getValue('tethering.wifi.timeout')
                .then(time=>{
                  if (typeof(time) === 'undefined') {
                    SettingsObserver.setValue([{
                      name: 'tethering.wifi.timeout',
                      value: defaultAutotimeout
                    }]);
                  }
                })
            }
          });
      }
      //add end by tajiliangchen for jira GF5GTMO-4846 20241028
      Service.registerState('tetheringWifiEnabled', this);
      window.addEventListener('simslot-removed', () => {
        const dataServiceId = SimSettingsHelper['ril.data.defaultServiceId'];
        if (!navigator.b2g.mobileConnections[dataServiceId]?.iccId) {
          this.turnOffInternetSharing(false);
        }
      });
    }
  };

  exports.InternetSharing = InternetSharing;

}(window));
