/* exported advanced_timer */
/* global SettingsObserver, Service, applications, AppOrigin,
   appWindowManager, FtuLauncher */

'use strict';
(function (exports) {
  var KidsModeStore = function() {};
  KidsModeStore.prototype = {
    name: 'KidsModeStore',
    enabled: false,
    userAgentKey: 'KAIKID',
    allowList: [],
    defaultList: [
      'accounts.google.com/o/oauth2',
      'www.googleapis.com/oauth2',
      'login.microsoftonline.com/common/oauth2'
    ],
    debug: function(str) {
      window.DUMP(`[KidsModeStore] ${str}`);
    },
    start: function() {
      SettingsObserver.observe('kids.mode.enabled', false, (value) => {
        this.enabled = value;
        this.debug(`kids.mode.enabled: ${value}`);
        for (let appName in appWindowManager._apps) {
          const app = appWindowManager._apps[appName];
          if (!app.isActive() && !app.isHomescreen &&
            app.manifestUrl !== FtuLauncher.getFtuManifestUrl()) {
            app.kill();
          }
        }
      });
      SettingsObserver.getValue('kids.mode.allow.urls.list').then((value) => {
        let allowList = value || [];
        this.allowList = allowList.concat(this.defaultList);
        this.allowList.push('services.kaiostech.com/antitheft');
        this.allowList.push('www.kaiostech.com');
        const protocolRegex = /^https?:\/\//i;
        this.allowList.forEach((item, index, array) => {
          if (typeof item === 'string') {
            array[index] = item.replace(protocolRegex, '').toLowerCase();
          }
        });
      });

      Service.registerState('enabled', this);
      Service.registerState('isForbiddenApp', this);
      Service.registerState('isForbiddenUrl', this);
      Service.registerState('isForbiddenRedirection', this);
      Service.register('updateUserAgent', this);
    },

    updateUserAgent: function(userAgentExtensions, manifestUrl) {
      let userAgent = navigator.userAgent;
      let newUserAgent = userAgent;
      if (this.enabled) {
        if (!userAgent.includes(this.userAgentKey)) {
          newUserAgent = userAgent.replace(`)`, `; ${this.userAgentKey})`);
        }
      } else {
        newUserAgent = userAgent.replace(`; ${this.userAgentKey})`, `)`);
      }
      if (userAgentExtensions && !userAgent.endsWith(userAgentExtensions)) {
        newUserAgent = newUserAgent.concat(` ${userAgentExtensions}`);
      }
      this.debug(`updateUserAgent ${manifestUrl}: ${newUserAgent}`);
      return newUserAgent;
    },

    toast: function(l10nId) {
      if (!Service.query('KidsModeStore.enabled')) {
        return;
      }
      Service.request('SystemToaster:show', {
        text: window.api.l10n.get(l10nId)
      });
    },

    isForbiddenRedirection: function(originUrl, newUrl) {
      if (!Service.query('KidsModeStore.enabled')) {
        return false;
      }
      let newOriginUrl = originUrl.replace(/^https?:\/\//i, '').toLowerCase();
      const urlObjOrigin = new URL(originUrl);
      const hostnameOrigin = urlObjOrigin.hostname;
      let forbidden = !this.defaultList.find(allowUrl => {
        const urlObj = new URL(`https://${allowUrl}`);
        const hostname = urlObj.hostname;
        return newOriginUrl.startsWith(allowUrl) && hostnameOrigin === hostname;
      });
      if (forbidden) {
        forbidden = Service.query('KidsModeStore.isForbiddenUrl', newUrl);
      }
      this.debug(`isForbiddenRedirection ${originUrl} ${newUrl} ${forbidden}`);
      return forbidden;
    },

    isForbiddenUrl: function(url) {
      if (!Service.query('KidsModeStore.enabled')) {
        return false;
      }
      let newUrl = url.replace(/^https?:\/\//i, '').toLowerCase();
      const newUrlObjN = new URL(url);
      const newHostname = newUrlObjN.hostname;
      const forbidden = !this.allowList.find(allowUrl => {
        const urlObj = new URL(`https://${allowUrl}`);
        const hostname = urlObj.hostname;
        return newUrl.startsWith(allowUrl) && hostname === newHostname;
      });
      this.debug(`isForbiddenUrl ${url} ${forbidden}`);
      if (forbidden) {
        this.toast('kids-modes-open-webpage-failed');
      }
      return forbidden;
    },

    isForbiddenActivity: function(name) {
      const silentForbiddenList = [
        'kaistore-get-silent-apps',
        'kaistore-push-register',
        'kaistore-show-greeting'
      ];
      const forbiddenList = [
        'voice-assistant',
        'voice-input'
      ];
      let retVal = false;
      if (!Service.query('KidsModeStore.enabled')) {
        return retVal;
      }
      if (forbiddenList.includes(name)) {
        this.toast('kids-modes-open-app-failed');
        retVal = true;
      } else {
        retVal = silentForbiddenList.includes(name);
      }
      this.debug(`isForbiddenActivity ${name}: ${retVal}`);
      return retVal;
    },

    isForbiddenApp: function(manifestURL, hasToast = true) {
      const app = applications.getByManifestURL(manifestURL);
      const manifest = app?.manifest;
      if (!Service.query('KidsModeStore.enabled')) {
        return false;
      }
      if (manifestURL === AppOrigin.getManifestURL('search')) {
        return false;
      }
      if (manifestURL.startsWith(window.AppOrigin.getOrigin('cached')) ||
        manifestURL === AppOrigin.getManifestURL('kaios-store') ||
        manifestURL === AppOrigin.getManifestURL('kaios-voiceassistant') ||
        app && (!app.preloaded ||
        ((manifest?.role === 'search' || manifest?.display === 'browser') &&
        !manifest.chrome?.bar))) {
        if (hasToast) {
          this.toast('kids-modes-open-app-failed');
        }
        this.debug(`Forbidden open ${manifestURL}`);
        return true;
      } else {
        return false;
      }
    }
  };
  exports.KidsModeStore = KidsModeStore;
}(window));
