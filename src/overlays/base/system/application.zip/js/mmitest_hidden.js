//add for: hidden statusbar and lockscreen in mmitest mode
/*global SettingsObserver ,applications, Service, appWindowManager, AppWindow */
var mmitestHidden = (function () {
  dump("system---mmitest_hidden.js ---1---called");



/*  let pass = lock.get('lockscreen.passcode-lock.code');
  pass.onsuccess= function(){
    dump(" mmitest_hidden get mozSettings early");
    navigator.engmodeExtension.setPrefValue("lockscreen.code",pass.result["lockscreen.passcode-lock.code"]);
  };*/

  SettingsObserver.getValue('homescreen.manifestURL').then((value)=>
    {
    var app = value;
    dump('---mmitest_hidden.js----2---app：'+app);
    dump('---mmitest_hidden.js-----3----app.origin.search(mmitest)：'+app.search('mmitest'));
    // If in mmitest mode: homescreen.manifestURL = "http://mmitest.gaiamobile.org:8080"
    if (app.search('mmitest') > 0 ) {
      dump('---mmitest_hidden.js---4----进入if:'+app.search('mmitest'));
      // hide statusbar
      document.getElementById("statusbar").style.display = "none";
    }
  });
})();
