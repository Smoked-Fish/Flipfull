/* global BaseModule, SimSettingsHelper, Service */
'use strict';

(function() {
  // Responsible to load and init the sub system for mobile connections.
  var MobileConnectionCore = function(core) {
    this.core = core;
    this.mobileConnections = [];
    navigator.b2g.mobileConnections.forEach(conn => {
      this.mobileConnections.push(conn);
    });
    this.notificationsMap = new Map();
  };
  MobileConnectionCore.SUB_MODULES = [
    'Radio',
    'CallForwarding',
    'EmergencyCallbackManager',
    'EuRoamingManager',
    'TelephonySettings',
    'OperatorVariantManager',
    'InternetSharing',
    'CellBroadcastSystem'
  ];

  MobileConnectionCore.SERVICES = [
    'showWifiCallNotification',
    'clearWifiCallNotification'
  ];

  // Modified-Begin for Wi-Fi Calling status
  var ErrorCodes = [
    {indexx:'2', code: 'ER02', errorMsgL10n: 'MsgDNSError'},   // errorMsg: 'ER02 – DNS Error'
    {indexx:'3', code: 'ER03', errorMsgL10n: 'MsgDNSError'},
    //{code: 'ER04', errorMsgL10n: 'MsgDNSError'}, // PR 7684833
    {indexx:'41', code: 'ER041', errorMsgL10n: 'MsgDNSError'},
    {indexx:'5', code: 'ER05', errorMsgL10n: 'MsgInvalidSIMCard'},
    //{indexx:'7', code: 'ER07', errorMsgL10n: 'MsgUnableToConnect'},//GF7TF-5024
    {indexx:'8', code: 'ER08', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'81', code: 'ER081', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'82', code: 'ER082', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'10', code: 'ER010', errorMsgL10n: 'MsgInvalidCertificate'},
    {indexx:'101', code: 'ER101', errorMsgL10n: 'MsgInvalidCertificate'},
    {indexx:'11', code: 'ER011', errorMsgL10n: 'MsgInvalidCertificate'},
    {indexx:'111', code: 'ER111', errorMsgL10n: 'MsgInvalidCertificate'},

    {indexx:'1701', code: 'REG09', errorMsgL10n: 'MsgMissing911'},
    {indexx:'500', code: 'REG91', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'403', code: 'REG90', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'90', code: 'REG90', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'901', code: 'REG901', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'902', code: 'REG902', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'903', code: 'REG903', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'904', code: 'REG904', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'905', code: 'REG905', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'91', code: 'REG91', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'99', code: 'REG99', errorMsgL10n: 'MsgUnableToConnect'},
    {indexx:'995', code: 'REG09', errorMsgL10n: 'MsgMissing911'}//GF5GTMO-6157 guanzhong.zhu.cd 2025/1/10
  ];
  var _ = window.api.l10n.get;
  function getErrorCode(reason) {
    if (!reason || reason === '0' || reason === 'GenericFailure') {
      return null;
    }

    const errorCode = ErrorCodes.find(errorCode => reason === errorCode.indexx);

    if (errorCode) {
      debugInfo('getErrorCode reason:' + reason + ' errorCode:' + errorCode.code);
      return errorCode.code;
    }

    debugInfo('getErrorCode code = null');
    return null;
  };
  function getErrorMsg(code) {
    if (!code) {
      return null;
    }

    const upperCaseReason = code.toUpperCase();
    const errorCode = ErrorCodes.find(errorCode => upperCaseReason === errorCode.code);

    if (errorCode) {
      const msg = errorCode.code + ' - ' + _(errorCode.errorMsgL10n);
      debugInfo(`getErrorMsg reason: ${code} errorCode: ${errorCode.code}`);
      return msg;
    }

    return null;
  };

  function debugInfo(msg){
    console.log('mobile_connection_core'+msg);
  };
  var _wfcFirstTimeRegShown = false;//GF5GTMO-8482 guanzhong.zhu.cd 2025/10/23
  BaseModule.create(MobileConnectionCore, {
    name: 'MobileConnectionCore',

    _start: function() {
      BaseModule.lazyLoad(['SimSettingsHelper']).then(function() {
        this.debug('lazily load SimSettingsHelper');
        this.simSettingsHelper = SimSettingsHelper;
        this.simSettingsHelper.start();
      }.bind(this));
    },

    // XXX: move to standalone module
    showWifiCallNotification: function(index) {
      var imsRegHandler = navigator.b2g.mobileConnections[index].imsHandler;
      if (imsRegHandler && !imsRegHandler.unregisteredReason && !imsRegHandler.wfcError){
        if(imsRegHandler.capability === 'voice-over-wifi' ||
           imsRegHandler.capability === 'video-over-wifi'){
          // register success
          debugInfo('WFC register success, mode='+imsRegHandler.capability+', notifications disabled');
          this.clearWifiCallNotification(index);

          SettingsObserver.getValue('WifiCall.firstTime.reg').then(value => {
            var notFirst = !!value;
            if(!notFirst && !_wfcFirstTimeRegShown){//GF5GTMO-8482 guanzhong.zhu.cd 2025/10/23
              _wfcFirstTimeRegShown = true;
              debugInfo('WFC is registered successfully for the first time and will show the dialog to remind user.');
              this.showWFCRegisterSuccessDialog();
              SettingsObserver.setValue([{
                name: 'WifiCall.firstTime.reg',
                value: true
              }]);
            }
          });
        }
        return;
      }

      var code = getErrorCode(imsRegHandler.unregisteredReason);
      var errorMsg = getErrorMsg(code);

      if (!errorMsg && imsRegHandler.wfcError === "ER082 - Unable to connect"){
        code = getErrorCode('82');
        errorMsg = getErrorMsg(code);
      }
      if(!errorMsg){
        return;
      }
      //TCTTEL-2633-begin GID-MTRREQ-4982 guanzhong.zhu.cd 2024/12/4
      if(code !== 'REG09' && code !== 'ER082' && code !== 'ER05'){
        return;
      }

      var icon = window.location.protocol + '//' + window.location.hostname +
          '/style/icons/captivePortal.png';
      var operatorName = OperatorUtils.getSimOperatorNameByIndex(index);
      var buildOperatorName = OperatorUtils.getBuildOperatorName();
      debugInfo('operatorName:'+operatorName+' buildOperatorName:'+buildOperatorName);
      if(buildOperatorName !== 'TMO'){//GF5GTMO-6531  TMO project no need to show notification guanzhong.zhu.cd 2025/2/21
        var notification = new Notification('', {
          body: errorMsg,
          icon: icon,
          tag: 'wificall'+index,
          mozbehavior: {
            showOnlyOnce: true,
            soundFile: null,
            noclear: true,
            vibrationPattern: [1]
          }
        });
        this.notificationsMap.set(notification.tag,notification);
        if(code === 'ER05'){
          return;
        }
        //TCTTEL-2633-end GID-MTRREQ-4982 guanzhong.zhu.cd 2024/12/4
        var e911Url = 'https://t-mo.co/2UT2voK';
        if(operatorName === 'TMO'){
          e911Url = 'https://t-mo.co/2UT2voK';
        }else if(operatorName === 'MetroPCS'){
          e911Url = 'https://t-mo.co/2VVEDVL';
        }
        if(buildOperatorName === 'TF'){
          e911Url = 'https://e911-reg.tracfone.com/';
        }
        notification.onclick = function(){
          const activity = new WebActivity('view', { type: 'url', url: e911Url });
          activity.start();
        };
      }
      if(operatorName === 'TMO' && buildOperatorName === 'TF') {
        this.showWFCErrorDialog(index);

      }
    },
    showWFCErrorDialog:function () {
      debugInfo('showWFCErrorDialog');
      Service.request('DialogService:show', {
        header: _('Wi-Fi Calling Error'),
        content: _('missingE911MsgTracfone'),
        ok: _('ok'),
        cancel: _('cancel'),
        type: 'confirm',
        onOk: function(){
          const activity = new WebActivity('view', { type: 'url', url: 'https://e911-reg.tracfone.com/' });
          activity.start();
        },
        translated: true
      });
    },

    clearWifiCallNotification: function(cardIndex) {
      this.debug('clearWifiCallNotification:'+cardIndex);
      let key = 'wificall'+cardIndex;
      if(this.notificationsMap.has(key)){
        let notification = this.notificationsMap.get(key);
        notification.close();
        this.notificationsMap.delete(key);
      }
    },

    showWFCRegisterSuccessDialog(){
      Service.request('DialogService:show', {
        header: _('Wifi-remind-firstcall-title'),
        content: _('Wifi-remind-firstreg-body'),
        type: 'alert',
        translated: true
      });
    },
  });
}());
