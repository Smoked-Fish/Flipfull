/* globals ApnHelper, LazyLoader, OperatorVariantHelper, SettingsObserver,
   DeviceCapabilityManager */

(function(exports) {
  'use strict';
  // Prefix for the persist key.
  var PERSIST_KEY_PREFIX = 'operatorvariant';
  // Sufix for the persist key.
  var PERSIST_KEY_SUFIX = 'customization';
  // When support cdma module, we should set the config to true,
  // and gaia will provide all the apn items to gecko,
  // otherwise, gaia just need to provide the preferred apn.

  // This json file should always be accessed from the root instead of the
  // current working base URL so that it can work in unit-tests as well
  // as during normal run time.
  var OPERATOR_VARIANT_FILE =
    window.AppOrigin.getOrigin('shared') + '/resources/apn.json';

  var APN_TYPES = ['default', 'mms', 'supl', 'dun', 'ims', 'ia', 'hipri',
    'xcap', 'cbs', 'fota', 'Emergency'];
  var AUTH_TYPES = ['none', 'pap', 'chap', 'papOrChap'];
  var APN_KEYS = ['authtype', 'user', 'password', 'proxy', 'port', 'mmsc',
    'mmsproxy', 'mmsport', 'protocol', 'roaming_protocol', 'bearer'];
  var DEFAULT_MMS_SIZE_LIMITATION = 300 * 1024;

  /**
   * Helper object that handles some carrier-specific settings on the ICC card
   * from the mozMobileConnection.
   */
  function OperatorVariantHandler(iccId, iccCardIndex, manager) {
    const mobileConnections = navigator.b2g.mobileConnections;
    const simIndex =
      mobileConnections?.length > 1 ? `.sim${iccCardIndex + 1}` : '';
    this._mvnoSettingsKey = `operatorvariant.mvno${simIndex}`;

    this.manager = manager;
    /** Holds the OS version */
    this._deviceInfoOs = manager.deviceInfoOs || 'unknown';
    /** Index of the ICC card on the mozMobileConnections array */
    this._iccCardIndex = iccCardIndex;
    /** ICC id in the ICC card */
    this._iccId = iccId;
    /** Operator variant helper object */
    this._operatorVariantHelper = null;
    /** MCC and MNC values */
    this._iccSettings = { mcc: '000', mnc: '00' };

    //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,02/10/2025,GF5GTMO-6463,
    //Add some log for operator_variant
    this.log = function(msg) {
      dump("-->OVH-" + this._iccCardIndex + ": " + msg);
    };
    this.log("init: simIndex=" + simIndex + " manager=" + manager);
    //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-6463,
  }

  OperatorVariantHandler.prototype = {
    /**
     * Run customizations.
     */
    start: function ovh_start() {
      this.log("start:");//[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,02/10/2025,GF5GTMO-6463,
      // Set some carrier settings on startup and when the SIM card is changed.
      this._operatorVariantHelper =
        new OperatorVariantHelper(
          this._iccId,
          this._iccCardIndex,
          this.applySettings.bind(this),
          // Pass the persist key.
          PERSIST_KEY_PREFIX + '.' +
          this._deviceInfoOs + '.' +
          'ICC' + this._iccCardIndex + '.' +
          PERSIST_KEY_SUFIX,
          true);

      // Listen for changes in MCC/MNC values.
      this._operatorVariantHelper.listen();
    },

    /**
     * Utility function to pad a number with leading zeros and transform it
     * into a string.
     *
     * @param {Number} num The number to pad with leading zeros.
     * @param {Number} length The final length the number should have,
     *                        in characters.
     */
    padLeft: function ovh_padLeft(num, length) {
      var r = String(num);
      while (r.length < length) {
        r = '0' + r;
      }
      return r;
    },

    clone: function ovh_clone(obj) {
      return JSON.parse(JSON.stringify(obj));
    },

    /**
     * Utility function to merge default apn settings (from apn.json) to
     * existing apn settings.
     *
     * @param {Array} apns
     *                Existing apns.
     * @param {Array} defaultApns
     *                Default apns. Note that in the array there should be no
     *                apn with the carrier name "_custom_".
     */
    mergeAndKeepCustomApnSettings:
      function ovh_mergeApnSettings(apns, defaultApns) {
        var defaultApnsCopy = this.clone(defaultApns);

        // apns might be undefined, do filtering only if it's an Array
        var existingCustomApns = !Array.isArray(apns) ? [] :
          apns.filter(function(apn) {
            return (apn.carrier === '_custom_');
          });

        // Find the apn types of the custom apns.
        var typesOfCustomApn = new Set();
        existingCustomApns.forEach(function(apn) {
          apn.types.forEach(function(type) {
            typesOfCustomApn.add(type);
          });
        });

        // We only need to set the apns of the types that are not covered by
        // the custom apns.
        var apnsToBeSet = defaultApnsCopy.filter(function(apn) {
          // Remove the type that is already covered by the custom apns.
          apn.types = apn.types.filter(function(type) {
            return !typesOfCustomApn.has(type);
          });
          return !!apn.types.length;
        });
        apnsToBeSet = apnsToBeSet.concat(existingCustomApns);

        return apnsToBeSet;
    },

    /**
     * Apply the carrier settings relaying on the MCC and MNC values. This
     * function must be called only once when the device boots with a new ICC
     * card or when the device boots with the same ICC card and the
     * customization has not been applied yet.
     *
     * @param {String}  mcc Mobile Country Code in the ICC card.
     * @param {String}  mnc Mobile Network Code in the ICC card.
     */
    applySettings: function ovh_applySettings(mcc, mnc) {
      // Save MCC and MNC codes.
      this._iccSettings.mcc = mcc;
      this._iccSettings.mnc = mnc;

      this.retrieveOperatorVariantSettings(function(result) {
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,02/10/2025,GF5GTMO-6463,
        //Add some log for operator_variant
        let resultCount = Array.isArray(result) ? result.length : -1;
        this.log("applySettings: mccmnc=" + mcc + mnc + " resultCount=" + resultCount);
        //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-6463,

        this.applyOperatorVariantSettings(result);
        this.retrieveWAPUserAgentProfileSettings(
          this.applyWAPUAProfileUrl.bind(this)
        );
      }.bind(this));

      this._operatorVariantHelper.applied();
    },

    /**
     * Retrieve the settings and call the callback function.
     *
     * @param {function} callback Callback function to be called once the
     *                            settings have been retrieved.
     */
    retrieveOperatorVariantSettings:
      function ovh_retrieveOperatorVariantSettings(callback) {

      var self = this;
      LazyLoader.getJSON(OPERATOR_VARIANT_FILE).then(function(apn) {
        // The apn.json generator strips out leading zeros for mcc values. No
        // need for padding in this instance.
        var mcc = self._iccSettings.mcc;

        // We must pad the mnc value and turn it into a string otherwise
        // we could *fail* to load the appropriate settings for single digit
        // *mnc* values!
        var mnc = self.padLeft(self._iccSettings.mnc, 2);

        // Get a list of matching APNs
        callback(ApnHelper.getCompatible(apn, mcc, mnc));
      });
    },

    /**
     * Given the list of APNs for the current operator numeric value (MCC and
     * MNC codes in the ICC card) filter those ones matching the MVNO rules.
     * The MVNO rules allow us to pre-select the APN relying on several things
     * such as the IMSI code, the carrier name in the ICC card, etc. This rules
     * could be used as well for non-MVNO carriers that provides different APN
     * for their subscribers relying on the IMSI code in the ICC card.
     *
     */
    filterApnsByMvnoRules: function ovh_filterApnsByMvnoRules(apnIndex,
                                                              allApnList,
                                                              filteredApnList,
                                                              mvnoType,
                                                              mvnoMatchData,
                                                              mvnoMatchedInfo,
                                                              onFinish) {
      if (apnIndex === allApnList.length) {
        SettingsObserver.setValue([{
          name: this._mvnoSettingsKey,
          value: [mvnoMatchedInfo]
        }]);
        if (onFinish && (typeof onFinish === 'function')) {
          onFinish(filteredApnList);
        }
        return;
      }

      var apn = allApnList[apnIndex];
      var listMvnoType = apn.mvno_type || '';
      listMvnoType = listMvnoType && listMvnoType.toLowerCase();
      var listMvnoMatchData = apn.mvno_match_data || '';
      if (listMvnoType === 'gid' || listMvnoType === 'imsi') {
        listMvnoMatchData =
          listMvnoMatchData && listMvnoMatchData.toLowerCase();
      }

      if (!listMvnoType ||
          (mvnoType && mvnoType === listMvnoType &&
           mvnoMatchData === listMvnoMatchData)) {
          if (!listMvnoType) {
            let existMvnoApn = filteredApnList.find((apn) => {
              return !!apn.mvno_type;
            });
            if (existMvnoApn === undefined) {
              filteredApnList.push(apn);
            }
          } else {
            filteredApnList.push(apn);
          }
          return this.filterApnsByMvnoRules(apnIndex + 1,
                                            allApnList,
                                            filteredApnList,
                                            mvnoType,
                                            mvnoMatchData,
                                            mvnoMatchedInfo,
                                            onFinish);
      }

      let matchedInfo = mvnoMatchedInfo.find((matchItem) => {
        return matchItem.mvnoType === listMvnoType &&
          matchItem.mvnoMatchData === listMvnoMatchData;
      });
      if (matchedInfo) {
        if (matchedInfo.match) {
          mvnoType = listMvnoType;
          mvnoMatchData = listMvnoMatchData;
          filteredApnList = [];
          filteredApnList.push(apn);
        }
        this.filterApnsByMvnoRules(apnIndex + 1,
                                   allApnList,
                                   filteredApnList,
                                   mvnoType,
                                   mvnoMatchData,
                                   mvnoMatchedInfo,
                                   onFinish);
      } else {
        const iccCard = navigator.b2g.iccManager &&
          navigator.b2g.iccManager.getIccById(this._iccId);
        var request = window.matchMvno(iccCard, listMvnoType, listMvnoMatchData);
        request.onsuccess = (function onSuccessHandler() {
          var match = request.result;
          var matchedInfo = {
            'mvnoType': listMvnoType,
            'mvnoMatchData': listMvnoMatchData,
            'match': match
          };
          mvnoMatchedInfo.push(matchedInfo);

          if (match) {
            filteredApnList = [];
            filteredApnList.push(apn);
            return this.filterApnsByMvnoRules(apnIndex + 1,
                                              allApnList,
                                              filteredApnList,
                                              listMvnoType,
                                              listMvnoMatchData,
                                              mvnoMatchedInfo,
                                              onFinish);
          }

          this.filterApnsByMvnoRules(apnIndex + 1,
                                     allApnList,
                                     filteredApnList,
                                     mvnoType,
                                     mvnoMatchData,
                                     mvnoMatchedInfo,
                                     onFinish);
        }).bind(this);
        request.onerror = (function onErrorHandler() {
          window.DUMP('[APN]operator APN: matchMvno error ' + listMvnoType + ', '
            + listMvnoMatchData);
          var matchedInfo = {
            'mvnoType': listMvnoType,
            'mvnoMatchData': listMvnoMatchData,
            'match': false
          };
          mvnoMatchedInfo.push(matchedInfo);
          this.filterApnsByMvnoRules(apnIndex + 1,
                                     allApnList,
                                     filteredApnList,
                                     mvnoType,
                                     mvnoMatchData,
                                     mvnoMatchedInfo,
                                     onFinish);
        }).bind(this);
      }
    },

    /**
     * Store the carrier settings.
     *
     * @param {Array} result Settings to be stored.
     */
    applyOperatorVariantSettings:
      function ovh_applyOperatorVariantSettings(result) {
      var apnPrefNames = {
        'operatorvariant': {
          'ril.iccInfo.mbdn': 'voicemail',
          'ril.sms.strict7BitEncoding.enabled':
            'enableStrict7BitEncodingForSms',
          'ril.cellbroadcast.searchlist': 'cellBroadcastSearchList',
          'dom.mms.operatorSizeLimitation': 'operatorSizeLimitation'
        }
      };

      var booleanPrefNames = [
        'ril.sms.strict7BitEncoding.enabled'
      ];
      const promises = [];
      // store relevant APN settings
      for (var type in apnPrefNames) {
        var apn = {};
        for (var i = 0; i < result.length; i++) {
          if (typeof result[i].type === 'undefined') {
            result[i].type = 'default';
          }
          if (result[i].type.indexOf(type) != -1) {
            apn = result[i];
            break;
          }
        }
        var prefNames = apnPrefNames[type];
        for (var key in prefNames) {
          var name = apnPrefNames[type][key];
          var item = {};
          switch (name) {
            case 'voicemail':
              promises.push(this.applyVoicemailSettings(result));
              break;

            case 'cellBroadcastSearchList':
              promises.push(this.applyCellBroadcastSearchList(result));
              break;

            case 'operatorSizeLimitation':
              item[key] = +apn[name] || DEFAULT_MMS_SIZE_LIMITATION;
              break;

            // all other keys default to empty strings
            default:
              if (booleanPrefNames.indexOf(key) !== -1) {
                item[key] = apn[name] || false;
              } else {
                item[key] = apn[name] || '';
              }
              break;
          }

          if (Object.keys(item).length) {
            promises.push(SettingsObserver.setValue([{
              name: key,
              value: item[key] || ''
            }]));
          }
        }
      }
      Promise.all(promises).then(() => {
        window.DUMP(`[APN]filterApnsByMvnoRules`);
        this.filterApnsByMvnoRules(0, result, [], '', '', [],
          (function onFinishCb(filteredApnList) {
            this.buildCompleteDefaultApnSettings(filteredApnList);
            this.buildApnSettings(filteredApnList);
        }).bind(this));
      });
    },

    /**
     * Get the value of a specific operator vatiant setting.
     *
     * @param {Array} allSettings Carrier settings.
     * @param {String} prop The name of the property to be queried.
     */
    getValueFromOperatorVariantSettings:
      function ovh_getVMNumberFromOperatorVariantSettings(allSettings, prop) {
        var operatorVariantSettings = {};
        for (var i = 0; i < allSettings.length; i++) {
          if (allSettings[i] &&
              allSettings[i].type.indexOf('operatorvariant') != -1) {
            operatorVariantSettings = allSettings[i];
            break;
          }
        }
        // Load the value stored in the apn.json database.
        return operatorVariantSettings[prop] || '';
    },

    /**
     * Store update the operator variant settings to database.
     *
     * @param {String} key The key of the settings field.
     * @param {Object} value The value.
     */
    updateOperatorVariantSettings:
      function ovh_updateOperatorVariantSettings(key, value) {
        return new Promise((resolve) => {
          SettingsObserver.getValue(key).then((getValue) => {
            var originalSetting = getValue || ['', ''];
            // If the key is 'ril.iccInfo.mbdn':
            // We should only call to this function when new icc cards detected
            // (not system update) in order to preserve user manual settings.

            // If the key is 'ril.cellbroadcast.searchlist':
            // Note that cellbroad cast search list is never touched by users,
            // we should always apply the new value no matter the function is
            // triggered by changing icc cards or system update.
            originalSetting[this._iccCardIndex] = value;
            SettingsObserver.setValue([{
              name: key,
              value: originalSetting
            }]).then(() => {
              resolve();
            }, () => {
              resolve();
            });
        });
      });
    },

    /**
     * Store the voicemail settings into the settings database.
     *
     * @param {Array} allSettings Carrier settings.
     */
    applyVoicemailSettings:
      function ovh_applyVoicemailSettings(allSettings) {
        var number = this.getValueFromOperatorVariantSettings(allSettings,
          'voicemail');
        return this.updateOperatorVariantSettings('ril.iccInfo.mbdn', number);
    },

    /**
     * Store the cell broadcast settings into the settings database.
     *
     * @param {Array} allSettings Carrier settings.
     */
    applyCellBroadcastSearchList:
      function ovh_applyCellBroadcastSearchList(allSettings) {
        var searchList = this.getValueFromOperatorVariantSettings(allSettings,
          'cellBroadcastSearchList');
        return this.updateOperatorVariantSettings('ril.cellbroadcast.searchlist',
          searchList);
    },

    /**
     * Helper function.
     */
    canHandleType: function ovh_canHandleType(apn, type) {
      return (apn.type && (apn.type.indexOf(type) != -1));
    },

    /**
     * Helper function to
     * - Change property mane 'type' by 'types'.
     * - Change values for 'authtype' property as the ones that gecko expects.
     */
    convertApnSettings: function ovh_convertApns(apnSettings) {
      var that = this;
      return apnSettings.map(function(apn) {
        var apnClone = that.clone(apn);
        if (apnClone.type && Array.isArray(apnClone.type)) {
          apnClone.types = apnClone.type.map(function(type) {
            return type;
          });
        }
        delete apnClone.type;
        APN_KEYS.forEach(function(key) {
          var empty;
          switch (key) {
            case 'authtype':
              empty = AUTH_TYPES[apnClone.authtype] || 'notDefined';
              // Convert process force update the value.
              apnClone[key] = empty;
              break;
            case 'protocol':
            case 'roaming_protocol':
              empty = 'notDefined';
              break;
            case 'bearer':
              empty = 0;
              break;
            default:
              empty = '';
              break;
          }
          if (!apnClone[key]) {
            apnClone[key] = empty;
          }
        });
        return apnClone;
      });
    },

    /**
     * Build all possible apn settings for the current mcc and mnc codes.
     *
     * @param {Array} allApnList The array of settings used for bulding the data
     *                           call ones.
     */
    buildCompleteDefaultApnSettings:
      function ovh_buildCompleteDefaultApnSettings(allApnList) {
        dump('operator_variant_handler buildCompleteDefaultApnSettings begin!');
        var validApnSettings = allApnList.filter(function(apn) {
          return apn.type && apn.type.indexOf('operatorvariant') == -1;
        });
        validApnSettings = this.convertApnSettings(validApnSettings);

        SettingsObserver.getValue('ril.data.default.apns').then((value) => {
          var result = value || {};
          result[this._iccCardIndex] = validApnSettings;
          SettingsObserver.setValue([{
            name: 'ril.data.default.apns',
            value: result
          }]);
        });
        //[FEATURE] Add BEGIN for MMS APN refer to 10647518,10647521
        var apnList = this.clone(validApnSettings);
        var allMmsApns = [];
        apnList.forEach(function(apn) {
          for (var i = 0; i < apn.types.length; i++) {
            if (apn.types[i] === 'mms') {
              apn.types = ['mms'];
              allMmsApns.push(apn);
              break;
            }
          }
        });
        dump('operator_variant_handler: buildCompleteDefaultApnSettings, allMsmApns = ' + JSON.stringify(allMmsApns));
        SettingsObserver.getValue('ril.data.mms.apns').then((value) => {
          var result = value || [[], []];
          result[this._iccCardIndex] = allMmsApns;
          SettingsObserver.setValue([{
            name: 'ril.data.mms.apns',
            value: result
          }]);
        });
        //[FEATURE] Add END for MMS APN refer to 10647518,10647521
      },

    /**
     * Build the data call settings for the new APN setting architecture.
     *
     * @param {Array} allApnList The array of settings used for bulding the data
     *                           call ones.
     * @return {Array} The data call settings.
     */
    buildApnSettings: function ovh_buildApnSettings(allApnList) {
      var tmpApnSettings = [];
      var apnSettings = [];
      var validApnFound = false;

      //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,02/10/2025,GF5GTMO-6463,
      //Add some log for operator_variant
      let allApnCount = Array.isArray(allApnList) ? allApnList.length : -1;
      this.log("buildApnSettings: allApnCount=" + allApnCount);
      for (let i = 0; i < allApnCount; i++) {
        this.log("buildApnSettings: index=" + i + " apn=" + JSON.stringify(allApnList[i]));
      }
      //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-6463,

      for (var i = 0; i < APN_TYPES.length; i++) {
        var type = APN_TYPES[i];

        // Let's find out an APN in the list being capable of handling the type.
        // A valid APN might be already included, let's search it.
        validApnFound = false;
        for (var j = 0; j < tmpApnSettings.length; j++) {
          if (this.canHandleType(tmpApnSettings[j], type)) {
            validApnFound = true;
            break;
          }
        }
        if (validApnFound) {
          // Already have a valid APN, let's go for the next APN type.
          continue;
        }
        // There is no valid APN for the type, use the first APN in the list.
        for (var k = 0; k < allApnList.length; k++) {
          if (this.canHandleType(allApnList[k], type)) {
            if (allApnList[k].type.length > 1) {
              var tmpApn = this.clone(allApnList[k]);
              delete tmpApn.type;
              tmpApn.type = [];
              tmpApn.type.push(type);
              tmpApnSettings.push(tmpApn);
              break;
            }
            tmpApnSettings.push(allApnList[k]);
            break;
          }
        }
      }

      apnSettings = this.convertApnSettings(tmpApnSettings);

      // Check if enabled cdma feature or not.
      DeviceCapabilityManager.get('device.cdma-apn').then((isEnabled) => {
        this.log("buildApnSettings: device.cdma-apn=" + isEnabled);//[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,02/10/2025,GF5GTMO-6463,
        if (isEnabled) {
          this.buildAllApnSettings().then((allApnSettings) => {
            this.saveDefaultApnSettings(apnSettings, allApnSettings);
          });
        } else {
          this.buildPreferredApnSettings(apnSettings);
        }
      });
    },

    resetDefaultApnSettings: function ovh_resetDefaultApnSettings(apnSettings) {
      SettingsObserver.getValue('ril.data.default.apnSettings').then(value => {
        let result = value;
        if (!result || !Array.isArray(result)) {
          result = [[], []];
        }
        result[this._iccCardIndex] = apnSettings;
        SettingsObserver.setValue([{
          name: 'ril.data.default.apnSettings',
          value: result
        }]);
      });
    },

    /**
     * Build the preferred data call settings which using for
     * building data calls.
     *
     * @param {Array} apnSettings The array of settings used for default
     *                            data call setting.
     */
    buildPreferredApnSettings:
      function ovh_buildPreferredApnSettings(apnSettings) {
        this.resetCpApns();
        const simApnSettingsKey = [
          'ril.data.dm.apnSettings.sim1',
          'ril.data.dm.apnSettings.sim2'
        ];
        const key = simApnSettingsKey[this._iccCardIndex];
        SettingsObserver.setValue([{
          name: key,
          value: apnSettings
        }, {
          name: 'apn.selections',
          value: null
        }]);
        //[BUGFIX]-Add-BEGIN by GCSSZ.kaiyun.yan,02/10/2025,GF5GTMO-6463,
        //Add some log for operator_variant
        let apnSettingsCount = Array.isArray(apnSettings) ? apnSettings.length : -1;
        this.log("buildPreferredApnSettings: key=" + key + " apnSettingsCount=" + apnSettingsCount);
        for (let i = 0; i < apnSettingsCount; i++) {
          this.log("buildPreferredApnSettings: index=" + i + " apn=" + JSON.stringify(apnSettings[i]));
        }
        //[BUGFIX]-Add-END by GCSSZ.kaiyun.yan,GF5GTMO-6463,
        this.resetDefaultApnSettings(apnSettings);
      },

    resetCpApns: function ovh_resetCpApns() {
      SettingsObserver.getValue('ril.data.cp.apns').then((value) => {
        var result = value;
        if (!result || !Array.isArray(result)) {
          result = [{}, {}];
        }
        result[this._iccCardIndex] = {};
        SettingsObserver.setValue([{
          name: 'ril.data.cp.apns',
          value: result
        }]);
      });
    },

    /**
     * Build all the data call settings for the default APN setting architecture
     *
     * @return {Array} The all matched data call settings.
     */
    buildAllApnSettings: function ovh_buildAllApnSettings() {
      return new Promise((resolve) => {
        LazyLoader.getJSON(OPERATOR_VARIANT_FILE).then((apn) => {
          var mcc = this._iccSettings.mcc;
          var mnc = this._iccSettings.mnc;
          var allApnList = ApnHelper.getAll(apn, mcc, mnc);
          var tmpApnSettings = [];
          var allApnSettings = [];

          allApnList.forEach((apn) => {
            var tmpApn = this.clone(apn);

            tmpApn.type.forEach((type) => {
              var newTmpApn = this.clone(tmpApn);

              delete newTmpApn.type;
              newTmpApn.type = [];
              newTmpApn.type.push(type);
              tmpApnSettings.push(newTmpApn);
            });
          });

          allApnSettings = this.convertApnSettings(tmpApnSettings);

          resolve(allApnSettings);
        });
      });
    },

    /**
     * Save the filtered and all data call settings to Settings.
     */
    saveDefaultApnSettings:
      function ovh_saveDefaultApnSettings(apnSettings, allApnSettings) {
        this.resetCpApns();
        const simApnSettingsKey = [
          'ril.data.dm.apnSettings.sim1',
          'ril.data.dm.apnSettings.sim2'
        ];
        const key = simApnSettingsKey[this._iccCardIndex];
        SettingsObserver.getValue(key).then((value) => {
          var result = value;
          if (!result || !Array.isArray(result)) {
            result = [];
          }

          // We should respect to the existing custom settings if any. Instead
          // of overwriting it with "apnSettings" compeletely, we should only
          // overwrite the apn settings that are not configured by custom
          // settings by using the result of "mergeAndKeepCustomApnSettings".
          var mergedApnSettings = this.mergeAndKeepCustomApnSettings(
            result, apnSettings);

          SettingsObserver.setValue([{
            name: key,
            value: allApnSettings
          }, {
            name: 'apn.selections',
            value: null
          }]);
          this.resetDefaultApnSettings(mergedApnSettings);
        });
    },

    /**
     * Retrieve the user agent profile setting from /resources/wapuaprof.json
     *  and find out the user agent URL for current mcc and mnc codes.
     *
     * @param {function} callback Callback function to be called once the
     *                             settings have been retrieved.
     */
    retrieveWAPUserAgentProfileSettings:
      function ovh_retrieveWAPUserAgentProfileSettings(callback) {

      var self = this;
      var WAP_UA_PROFILE_FILE = './resources/wapuaprof.json';
      var DEFAULT_KEY = '000000';

      LazyLoader.getJSON(WAP_UA_PROFILE_FILE).then(function(uaprof) {
        // normalize mcc, mnc as zero padding string.
        var mcc = self.padLeft(self._iccSettings.mcc, 3);
        var mnc = self.padLeft(self._iccSettings.mnc, 3);

        // Get the ua profile url with mcc/mnc. Fallback to default if no
        // record found. If still not found, we use undefined as the default
        // value
        var uaProfile = uaprof[mcc + mnc] || uaprof[DEFAULT_KEY];
        callback(uaProfile);
      });
    },

    /**
     * Store the user agent profile setting into the setting database.
     */
    applyWAPUAProfileUrl: function ovh_applyWAPUAProfileUrl(uaProfile) {
      SettingsObserver.setValue([{
        name: 'wap.UAProf.url',
        value: uaProfile ? uaProfile.url : ''
      }]);
    }
  };
  exports.OperatorVariantHandler = OperatorVariantHandler;
})(window);
