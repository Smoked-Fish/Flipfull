/* global LazyLoader, Resources */

'use strict';

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {value: value, enumerable: true, configurable: true, writable: true});
  } else {
    obj[key] = value;
  }
  return obj;
}

class KaiContact {
  constructor(data) {
    _defineProperty(this, "category", ['KAICONTACT',"DEVICE", "PRELOAD"]);

    Object.entries(data).forEach(([field, value]) => {
      if (value) {
        this[field] = value;
      }
    });
  }
}

var PreloadContacts = {
  PRELOAD_CONTACTS_FILE_VZW_POST : './resources/contact/vzw_post_default_contacts.json',
  PRELOAD_CONTACTS_FILE_VZW_PRE : './resources/contact/vzw_pre_default_contacts.json',
  PRELOAD_CONTACTS_FILE_USCC : './resources/contact/vzw_uscc_default_contacts.json',
  PRELOAD_CONTACTS_FILE_TMO_BOOST : './resources/contact/tmo_boost_default_contacts.json',
  PRELOAD_CONTACTS_FILE_TF : './resources/contact/tf_default_contacts.json',
  PRELOAD_CONTACTS_FILE_SPECTRUM : './resources/contact/spectrum_default_contacts.json',
  PRELOAD_CONTACTS_FILE_EE : './resources/contact/ee_default_contacts.json',
  PRELOAD_CONTACTS_FILE_DISH : './resources/contact/dish_default_contacts.json', //Add by xiaolei.yin for GF5GDISH-2199 on 20250117

  preloadContactsNum : 0,
  preloadingContactsNum : 0,
  needSetSpeedDials : false,
  existedSpeedDials : null,
  ro_product_name : null,
  removedContactsNum : 0,
  //Begin add by xiaolei.yin for GF5GDISH-2199 on 20250117
  isPreloading: false,
  isRemoving: false,
  //End add by xiaolei.yin for GF5GDISH-2199 on 20250117

  EE_CARD:['23430','23433'],
  //Begin add by xiaolei.yin for GF5GDISH-2199 on 20250117
  DISH_CARD:[
  {mccmnc: '310410', gid:["3430/3431","3442/3443","3432/3433","3444/3445","3436/3437","3448/3449","3438/3439","3440/3441","3450/3451","3452/3453"]},
  {mccmnc: '311180', gid:["3430/3431","3442/3443","3432/3433","3444/3445","3436/3437","3448/3449","3438/3439","3440/3441","3450/3451","3452/3453"]},
  {mccmnc: '310240', gid:["6230/6231","6430/6431","6432/6433","6438/6439","6440/6441","6442/6443"]},
  {mccmnc: '313340', gid:["6332/6333","6732/6733","6530/6531","6538/6539","6738/6739","6630/6631","6830/6831","7330/7331","7530/7531","6636/6637","6836/6837","6638/6639","6838/6839","8030/8031","8032/8033","8034/8035","8036/8037","8038/8039","9030/9031","9032/9033","9034/9035","9036/9037","9038/9039"]},
  {mccmnc: '20809', gid:["6332/6333","6732/6733","6530/6531","6538/6539","6738/6739","6630/6631","6830/6831","7330/7331","7530/7531","6636/6637","6836/6837","6638/6639","6838/6839","8030/8031","8032/8033","8034/8035","8036/8037","8038/8039","9030/9031","9032/9033","9034/9035","9036/9037","9038/9039"]},
  {mccmnc: '302220', gid:["6332/6333","6732/6733","6530/6531","6538/6539","6738/6739","6630/6631","6830/6831","7330/7331","7530/7531","6636/6637","6836/6837","6638/6639","6838/6839","8030/8031","8032/8033","8034/8035","8036/8037","8038/8039","9030/9031","9032/9033","9034/9035","9036/9037","9038/9039"]}],
  //End add by xiaolei.yin for GF5GDISH-2199 on 20250117

  MODEL_NAME : {
    VZW_POSTPAID : '',
    VZW_PREPAY : '',
    VZW_VOICEONLY : '',
    SPECTRUM: '',
  },

  OPERATOR_NAME : {
    VZW : 'VZW',
    USCC: 'USCC',
    TF: 'TF',
    TMO: 'TMO',
    OM: 'USOM',
    EE: 'EE',
    BOOST: 'BOOST',
    DISH: 'DISH'
  },

  load: function() {
    // active when contact restart
    SettingsObserver.observe('operater.contacts.refresh', undefined, (value) => {
      if (value === true) {
        dump("system_preload_contacts, refresh");
        navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name').then((operator) => {
          PreloadContacts.preloadOperaterContacts(operator);
        });
      }
    });

    navigator.b2g.engmodeManager.getPropertyValue('ro.operator.name').then((operator) => {
      //Begin modify by zhihai.yu for GF5GDISH-2199, GF5GDISH-2241. Final for GF5GTMO-8409
      if(operator === PreloadContacts.OPERATOR_NAME.TMO){
        if (PreloadContacts.containsUSCCCard()){
          PreloadContacts.preLoadContactsOrSpeedDial(PreloadContacts.PRELOAD_CONTACTS_FILE_USCC);
        }
//        else {
//          PreloadContacts.resourcesLoad(PreloadContacts.PRELOAD_CONTACTS_FILE_USCC, PreloadContacts.removePreloadContacts);
//        }
//        window.addEventListener('simslot-removed',(event) => {
//          dump('system_preload_contacts simslot-removed ');
//          if(!PreloadContacts.containsUSCCCard()){
//            PreloadContacts.resourcesLoad(PreloadContacts.PRELOAD_CONTACTS_FILE_USCC, PreloadContacts.removePreloadContacts);
//          }
//        });
        window.addEventListener('simslot-iccinfochange',(event) => {
           dump('system_preload_contacts simslot-iccinfochange isPreloading ' + PreloadContacts.isPreloading);
           if(PreloadContacts.containsUSCCCard() && !PreloadContacts.isPreloading){
             if(PreloadContacts.isRemoving){
               setTimeout(function advTimer() {
                 PreloadContacts.preLoadContactsOrSpeedDial(PreloadContacts.PRELOAD_CONTACTS_FILE_USCC);
               }, 1000);
             } else {
               PreloadContacts.preLoadContactsOrSpeedDial(PreloadContacts.PRELOAD_CONTACTS_FILE_USCC);
             }
           }
        });
      } else {
        PreloadContacts.preloadOperaterContacts(operator);
      }
      //End modify by zhihai.yu for GF5GDISH-2199, GF5GDISH-2241. Final for GF5GTMO-8409
    });
  },

  preloadOperaterContacts: function(operator) {
    dump("system_preload_contacts, operator: " + operator);
    navigator.b2g.engmodeManager.getPropertyValue('ro.product.model').then((model) => {
      PreloadContacts.ro_product_name = operator;
      var presetFile = null;
      dump("system_preload_contacts, model: " + model);
      switch(operator) {
        case PreloadContacts.OPERATOR_NAME.VZW:
          if(model === PreloadContacts.MODEL_NAME.VZW_PREPAY){
            presetFile = PreloadContacts.PRELOAD_CONTACTS_FILE_VZW_PRE;
          } else {
            presetFile = PreloadContacts.PRELOAD_CONTACTS_FILE_VZW_POST;
          }
          PreloadContacts.needSetSpeedDials = true;
          break;
        case PreloadContacts.OPERATOR_NAME.USCC:
          presetFile = PreloadContacts.PRELOAD_CONTACTS_FILE_USCC;
          break;
        case PreloadContacts.OPERATOR_NAME.BOOST:
          presetFile = PreloadContacts.PRELOAD_CONTACTS_FILE_TMO_BOOST;
          break;
        case PreloadContacts.OPERATOR_NAME.TF:
          presetFile = PreloadContacts.PRELOAD_CONTACTS_FILE_TF;
          break;
        case PreloadContacts.OPERATOR_NAME.OM:
          if(model === PreloadContacts.MODEL_NAME.SPECTRUM){
            presetFile = PreloadContacts.PRELOAD_CONTACTS_FILE_SPECTRUM;
          }
          break;
        case PreloadContacts.OPERATOR_NAME.EE:
          let mccmnc = OperatorUtils.getMccMnc();
          dump("system_preload_contacts, mccmnc " + mccmnc);
          if(mccmnc !== null && PreloadContacts.EE_CARD.includes(mccmnc)){
            PreloadContacts.resourcesLoad(PreloadContacts.PRELOAD_CONTACTS_FILE_EE, PreloadContacts.saveContacts);
          }else {
            PreloadContacts.resourcesLoad(PreloadContacts.PRELOAD_CONTACTS_FILE_EE, PreloadContacts.removePreloadContacts);
          }
          break;
        //Begin add by xiaolei.yin for GF5GDISH-2241 on 20250207
        case PreloadContacts.OPERATOR_NAME.DISH:
          presetFile = PreloadContacts.PRELOAD_CONTACTS_FILE_DISH;
          break;
        //End add by xiaolei.yin for GF5GDISH-2241 on 20250207
        default:
          break;
      }

      if (presetFile) {
        PreloadContacts.preLoadContactsOrSpeedDial(presetFile)
      }
    });
  },

  preLoadContactsOrSpeedDial: function (presetFile) {
    SettingsObserver.getValue('operater.contacts.loaded').then(value => {
      dump("system_preload_contacts, loaded: " + value);
      if (value !== true) {
        dump("system_preload_contacts, start preload");
        PreloadContacts.isPreloading = true; //Add by xiaolei.yin for GF5GDISH-2199 on 20250117
        PreloadContacts.resourcesLoad(presetFile, PreloadContacts.saveContacts);
      } else {
        if (!PreloadContacts.needSetSpeedDials) {
          dump("system_preload_contacts, No speed dial requirements");
        } else {
          dump("system_preload_contacts, speed dial");
          PreloadContacts.speedDialLoad(presetFile);
        }
      }
    });
  },

  saveContacts: function(contacts) {
    dump("system_preload_contacts, Contacts numbers = " + contacts.length);
    PreloadContacts.preloadContactsNum = contacts.length;
    PreloadContacts.saveContactsInternal(contacts);
  },

  saveContactsInternal(contacts) {
    for (let i = 0; i < contacts.length; ++i) {
      (function (i) {
        let filter = {
          filterBy: [ContactsManager.FilterByOption.NAME],
          filterValue: contacts[i].name,
          filterOption: ContactsManager.FilterOption.EQUALS
        };

        ContactsManager.find(filter).then(cursor => {

          cursor.next().then(result => {
            if (!result.length) {
              dump("system_preload_contacts find fail, need save");
              cursor.release();
              PreloadContacts.saveContact(contacts, i);
            } else {
              cursor.release();
              dump("system_preload_contacts, exist same contact,do nothing");
              PreloadContacts.preloadingContactsNum++;
              if (PreloadContacts.preloadContactsNum === PreloadContacts.preloadingContactsNum) {
                PreloadContacts.preloadDone(contacts);
                dump('system_preload_contacts, save contact done 1');
              }
            }
          }, () => {
            dump("system_preload_contacts, find fail need save");
            cursor.release();
            PreloadContacts.saveContact(contacts, i);
          }).catch(error => {
              dump("system_preload_contacts, findContact cursor next error: " + error);
          });
        }).catch(e => {
          dump("system_preload_contacts, ContactsManager find error: " + e);
        });
      })(i);
    }
  },

  saveContact: function (contacts, index) {
    let contact = contacts[index];
    //dump("system_preload_contacts, saveContact: "+JSON.stringify(contact));
    const toRemoteContact = new KaiContact(contact);
    //ModifyBegin by ze.wang.cd for GF7TF-3624 at 2023/10/19
    if (PreloadContacts.OPERATOR_NAME.TF === PreloadContacts.ro_product_name) {
      toRemoteContact.category = ["DEVICE", "KAICONTACT", "PRELOAD"];
      toRemoteContact.name = window.api.l10n.get('customer-support');
      toRemoteContact.givenName = window.api.l10n.get('customer-support');
      toRemoteContact.tel[0].atype = window.api.l10n.get('call-us');
      toRemoteContact.tel[1].atype = window.api.l10n.get('text-us');
    }
    //ModifyEnd by ze.wang.cd for GF7TF-3624 at 2023/10/19
    ContactsManager.save(!contact.id, [toRemoteContact]).then(() => {
      dump('system_preload_contacts, save contact:' + contact.name + " ,success");
      PreloadContacts.preloadingContactsNum ++;
      if (PreloadContacts.preloadContactsNum === PreloadContacts.preloadingContactsNum) {
        dump('system_preload_contacts, save contact done 2');
        PreloadContacts.preloadDone(contacts);
      }
    }).catch((e) => {
      dump('system_preload_contacts, error when saving contact:' + JSON.stringify(e));
    });

  },

  preloadDone: function (contacts) {
    dump("system_preload_contacts, preloadDone");
    SettingsObserver.setValue([{
      name: 'operater.contacts.loaded',
      value: true
    }]).then(function (result) {
      //Begin add by xiaolei.yin for GF5GDISH-2199 on 20250117
      PreloadContacts.isPreloading = false;
      PreloadContacts.preloadingContactsNum = 0;
      //End add by xiaolei.yin for GF5GDISH-2199 on 20250117
      PreloadContacts.checkSpeedDial(contacts);
    }, function (err) {
      dump('system_preload_contacts, set preloadDone tag error = ' + JSON.stringify(err));
    });
  },

  resourcesLoad: function(path, onSuccess) {
    dump("system_preload_contacts, resourceLoad start");
    var xhr = new XMLHttpRequest();
    xhr.open('GET', path, true);
    xhr.responseType = 'json';
    var mimetype = 'application/json';
    if (mimetype) {
      xhr.overrideMimeType(mimetype);
    }
    xhr.onload = function() {
      if (xhr.status === 200) {
        onSuccess && onSuccess(xhr.response);
        dump("system_preload_contacts, resourceLoad end");
      } else {
        dump("system_preload_contacts,  onload Failed = " + xhr.statusText);
      }
    };
    try {
      xhr.send();
    } catch (e) {
      dump("system_preload_contacts, send load Failed = " + xhr.statusText);
    }
  },

  speedDialLoad: function (presetFile) {
    SettingsObserver.getValue('operater.contacts.speeddial.loaded').then(value => {
      dump("system_preload_contacts, speeddial loaded: " + value);
      if (value !== true) {
        dump("system_preload_contacts, start preset speed dial");
        PreloadContacts.resourcesLoad(presetFile, PreloadContacts.checkSpeedDial);
      } else {
        dump("system_preload_contacts, has been preset return");
      }
    });
  },

  checkSpeedDial: function (contacts) {
    if (!PreloadContacts.needSetSpeedDials) {
      dump("system_preload_contacts, No speed dial requirements");
      return;
    }
    dump("system_preload_contacts, speed dial count: " + contacts.length);
    ContactsManager.getSpeedDials().then((speedDials) => {
      if (contacts.length === speedDials.length) {
        dump("system_preload_contacts, already saved all speed contacts");
        PreloadContacts.speedDialDone();
      } else {
        let speedDialIds = [];
        speedDials.forEach((dialContact) => {
          dump("system_preload_contacts, query saved speed dial contacts " + JSON.stringify(dialContact));
          speedDialIds.push(dialContact.contactId);
        });
        PreloadContacts.saveToSpeedDial(contacts, speedDialIds);
      }
    }).catch(error => {
      dump("system_preload_contacts, get speed dial error: " + JSON.stringify(error));
    });
  },

  saveToSpeedDial: function (contacts, speedDialIds) {
    let loadSpeedDialNum = 0;
    let keyboard = 1;
    for (let i = 0; i < contacts.length; i++) {
      if (contacts[i].name === "Voice Mail") {
        loadSpeedDialNum++;
        if (loadSpeedDialNum === contacts.length) {
          PreloadContacts.speedDialDone();
        }
        continue;
      }

      let filter = {
        filterBy: [ContactsManager.FilterByOption.NAME],
        filterValue: contacts[i].name,
        filterOption: ContactsManager.FilterOption.EQUALS
      };

      ContactsManager.find(filter).then(cursor => {
        cursor.next().then(result => {
          cursor.release();
          keyboard++;
          let contactid = result[0].id;

          dump("system_preload_contacts, speeddial saved previous" + (speedDialIds.indexOf(contactid) > -1)
            + " , keyboard :" + keyboard);

          if (speedDialIds.indexOf(contactid) > -1) {
            loadSpeedDialNum++;
            if (loadSpeedDialNum == contacts.length) {
              PreloadContacts.speedDialDone();
            }
          } else {
            ContactsManager.setSpeedDial(true, {
              dialKey: keyboard,
              tel: contacts[i].tel[0].value,
              contactId: contactid,
            }).then(() => {
              loadSpeedDialNum++;
              if (loadSpeedDialNum == contacts.length) {
                PreloadContacts.speedDialDone();
              }
            }, (err) => {
              console.warn('system_preload_contacts, failed to set speed dial', JSON.stringify(err));
            });
          }

        }).catch(error => {
          dump("system_preload_contacts, speeddial cursor next error: " + JSON.stringify(error));
        });
      }).catch(e => {
        dump("system_preload_contacts, speeddial find error: " + JSON.stringify(e));
      });
    }
  },

  speedDialDone: function () {
    dump("system_preload_contacts, speed contacts done");
    SettingsObserver.setValue([{
      name: 'operater.contacts.speeddial.loaded',
      value: true
    }]).then(function (result) {
      dump("system_preload_contacts, set speed contacts tag success");
    }, function (err) {
      dump('system_preload_contacts, set speed contacts tag error = ' + JSON.stringify(err));
    });
  },

  //FR GF7EE-877 xiaolei.yin 20240318 add-begin
  removePreloadContacts: function (contacts) {
    PreloadContacts.isRemoving = true; //Add by xiaolei.yin for GF5GDISH-2199 on 20250117
    for (let i = 0; i < contacts.length; ++i) {
      (function (i) {
        let filter = {
          filterBy: [ContactsManager.FilterByOption.NAME],
          filterValue: contacts[i].name,
          filterOption: ContactsManager.FilterOption.EQUALS
        };

        ContactsManager.find(filter).then(cursor => {
          cursor.next().then(result => {
            if (!result.length) {
              dump("system_preload_contacts, remove find no result, do nothing");
              cursor.release();
              PreloadContacts.removedContactsNum ++;
              if (PreloadContacts.removedContactsNum === contacts.length) {
                PreloadContacts.removePreloadDone();
              }
            } else {
              cursor.release();
              dump("system_preload_contacts, exist same contact,remove contact");
              PreloadContacts.deleteContact(result);
            }
          }, () => {
            dump("system_preload_contacts, remove find fail, do nothing");
            cursor.release();
            PreloadContacts.removedContactsNum ++;
            if (PreloadContacts.removedContactsNum === contacts.length) {
              PreloadContacts.removePreloadDone();
            }
          }).catch(error => {
            dump("system_preload_contacts, remove cursor next error: " + JSON.stringify(error));
          });
        }).catch(e => {
          dump("system_preload_contacts, remove find error: " + JSON.stringify(e));
        });
      })(i);
    }
  },

  deleteContact: function (contacts){
    for(let i = 0; i < contacts.length; i++){
        if(!contacts[i].category.includes("PRELOAD")){
            continue;
        }
        ContactsManager.remove([contacts[i].id])
            .then(() => {
                dump('system_preload_contacts, remove a contact deleted:');
                PreloadContacts.removedContactsNum ++;
                if (PreloadContacts.removedContactsNum === contacts.length) {
                    PreloadContacts.removePreloadDone();
                }
            })
            .catch(e => {
                console.error('system_preload_contacts, remove Error when deleting a contact:', JSON.stringify(e));
            })
    }
  },
  removePreloadDone: function (contacts) {
    SettingsObserver.setValue([{
      name: 'operater.contacts.loaded',
      value: false
    }]).then(function (result) {
      dump("system_preload_contacts, set remove tag success");
      //Begin add by xiaolei.yin for GF5GDISH-2199 on 20250117
      PreloadContacts.isRemoving = false;
      PreloadContacts.removedContactsNum = 0;
      //End add by xiaolei.yin for GF5GDISH-2199 on 20250117
      PreloadContacts.checkSpeedDial(contacts);
    }, function (err) {
      dump('system_preload_contacts, set remove tag error = ' + JSON.stringify(err));
    });
  },
  //FR GF7EE-877 xiaolei.yin 20240318 add-end

  //Modify by zhihai.yu for GF5GTMO-8409 on 2025-10-17
  containsUSCCCard: function () {
    let iccManager = navigator.b2g.iccManager;
    if (!iccManager || !iccManager.iccIds || iccManager.iccIds.length < 1) {
      dump("system_preload_contacts, no SIM card detected");
      return false;
    }

    for(let m = 0; m < iccManager.iccIds.length; m++) {
      let iccId = iccManager.iccIds[m];
      let iccInfo = iccManager.getIccById(iccId).iccInfo;
      if (!iccInfo || !iccInfo.mcc || !iccInfo.mnc) {
        continue; // Skip invalid cards
      }
      let simMccMnc = String(iccInfo.mcc) + String(iccInfo.mnc);

      dump("system_preload_contacts mccmnc " + simMccMnc);
      if (simMccMnc.startsWith("31158") || simMccMnc.startsWith("31122") || simMccMnc === "20404") {
        dump("system_preload_contacts has USCC SIM");
        return true;
      }
    };
    dump("system_preload_contacts, contains dish card return false");
    return false;
  },
  //End by zhihai.yu for GF5GTMO-8409 on 2025-10-17
};

PreloadContacts.load();
