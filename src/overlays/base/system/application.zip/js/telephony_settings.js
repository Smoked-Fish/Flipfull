'use strict';
/* global SettingsHelper, BaseModule, SIMSlotManager, Service,
   SettingsObserver */

(function() {
  /**
   * TelephonySettings sets voice privacy and roaming modes based on
   * the users saved settings.
   * @requires SettingsHelper
   * @class TelephonySettings
   */
  function TelephonySettings(core) {
    this.started = false;
    this.connections = core && core.mobileConnections || [];
    if (!this.connections.length && navigator.b2g.mobileConnections) {
      navigator.b2g.mobileConnections.forEach(conn => {
        this.connections.push(conn);
      });
    }
  }

  TelephonySettings.SERVICES = [
    'setPreferredNetworkType'
  ];
  TelephonySettings.SETTINGS = [
    'tty.mode.enabled',
    'accessibility.hac_mode',
    'ril.ims.enabled',
    'volte_item.ui.status',
    'ril.radio.preferredNetworkType',
    'ril.defaultServiceId.preferredNetworkType',
    'ril.data.defaultServiceId',
    'ril.data.defaultServiceId.iccId',
    // 'ril.ims.preferredProfile',
    'ril.dsds.ims.enabled',
    // 'ril.dsds.ims.preferredProfile',
    'ril.rtt.enabled',
    'vowifiUIEnable_0',
    'vowifiUIEnable_1',
    'vowifiPreferred_0',
    'vowifiPreferred_1',
    'vowifiPreferredWhenRoaming_0',
    'vowifiPreferredWhenRoaming_1'
  ];

  TelephonySettings.STATES = [
    'hacMode'
  ];

  BaseModule.create(TelephonySettings, {
    name: 'TelephonySettings',
    EVENT_PREFIX: '',
    hacMode: false,
    rttEnabled: undefined,
    preferredProfile: null,
    prefNetworkType: {},
    defaultPrefNetworkType: null,
    defaultServiceId: 0,
    prefSimIccId: null,
    taskScheduler: null,
    /**
     * Initialzes all settings.
     * @memberof TelephonySettings.prototype
     */
    _start: function() {
      this.taskScheduler = this._taskScheduler();
      this.initVoicePrivacy();
      this.initRoaming();
      if (!SIMSlotManager.isMultiSIM() ||
        !Service.query('supportSwitchPrimarysim')) {
        window.addEventListener('simslot-updated', () => {
          this.initPreferredNetworkType();
          this.resetRTTValue();
          this.resetPreferredProfile();
        });
        this.initPreferredNetworkType();
      }
    },

    _taskScheduler: function() {
      return {
        _isLocked: false,
        _tasks: [],
        _lock: function() {
          this._isLocked = true;
        },
        _unlock: function() {
          this._isLocked = false;
          this._executeNextTask();
        },
        _executeNextTask: function() {
          if (this._isLocked) {
            return;
          }
          var nextTask = this._tasks.shift();
          if (nextTask) {
            this._lock();
            nextTask.func(nextTask.cardIndex, nextTask.value).then(() => {
              dump('_taskScheduler success');
              this._unlock();
            }, () => {
              dump('_taskScheduler failed');
              this._unlock();
            });
          }
        },
        enqueue: function(cardIndex, value, func) {
          this._tasks.push({
            cardIndex: cardIndex,
            value: value,
            func: func
          });
          this._executeNextTask();
        }
      };
    },

    '_observe_tty.mode.enabled': function(value) {
      if (navigator.b2g.telephony) {
        navigator.b2g.telephony.ttyMode = value;
      }
    },

    '_observe_accessibility.hac_mode': function(value) {
      this.hacMode = value;
      this.publish('hacchange');
      if (navigator.b2g.telephony) {
        navigator.b2g.telephony.hacMode = value;
      }
    },

    '_observe_ril.radio.preferredNetworkType': function(value) {
      if (!value) {
        this._getDefaultPreferredNetworkTypes().then(defaultValues => {
          this.prefNetworkType = defaultValues;
          this.savePreferredNetworkType();
        });
      } else {
        this.prefNetworkType = value;
        this.savePreferredNetworkType();
      }
    },

    '_observe_ril.defaultServiceId.preferredNetworkType': function(value) {
      this.defaultPrefNetworkType = value;
    },

    '_observe_ril.data.defaultServiceId': function(value) {
      this.defaultServiceId = value;
    },

    '_observe_ril.data.defaultServiceId.iccId': function(value) {
      this.prefSimIccId = value;
      this.savePreferredNetworkType();
    },

    debugInfo:function (msg) {
      console.log('TelephonySettings, '+msg);
    },
    //Defect-begin GF5GTMO-6513 guanzhong.zhu.cd 2025/2/19
    withRetry:function (operation, maxRetries = 3, delayMs = 1000) {
      return new Promise((resolve, reject) => {
          let attempts = 0;

          const execute = () => {
              operation()
                  .then(resolve)
                  .catch(error => {
                      attempts++;
                      if (attempts <= maxRetries) {
                          const nextDelay = delayMs * Math.pow(2, attempts - 1);
                          this.debugInfo(`Retrying (${attempts}/${maxRetries}) current error ${error.message}, next attempt in ${nextDelay}ms...`);
                          setTimeout(execute, nextDelay);
                      } else {
                          reject(new Error(`All retry attempts failed: ${error.message}`));
                      }
                  });
          }

          execute();
      });
    },
    //Defect-end GF5GTMO-6513 guanzhong.zhu.cd 2025/2/19

    '_observe_vowifiUIEnable_0': function(value) {
      this.debugInfo('_observe_vowifiUIEnable_0 value:'+value);
      this.vowifiUIEnable(0,value);
    },

    '_observe_vowifiUIEnable_1': function(value) {
      this.debugInfo('_observe_vowifiUIEnable_1 value:'+value);
      this.vowifiUIEnable(1,value);
    },

    vowifiUIEnable: function (cardIndex,value) {
      if (this.connections[cardIndex] && this.connections[cardIndex].imsHandler){
        var imsHandler = this.connections[cardIndex].imsHandler;
        var data = this.connections[cardIndex].data;
        if (value === '1'){
          var isRoam = (data && data.state === 'registered' && data.roaming);
          SettingsObserver.getValue(isRoam ? 'vowifiPreferredWhenRoaming_'+cardIndex : 'vowifiPreferred_'+cardIndex)
            .then(result =>{
              if(result === 'cellular-preferred'){
                this.withRetry(() => imsHandler.setPreferredProfile('cellular-preferred'));
              }else if(result === 'wifi-preferred'){
                this.withRetry(() => imsHandler.setPreferredProfile('wifi-preferred'));
              }
            });
        }else if(value === '0'){
          this.withRetry(() => imsHandler.setPreferredProfile('cellular-only'));
        }
      }
    },

    '_observe_vowifiPreferred_0': function(value) {
      this.debugInfo('_observe_vowifiPreferred_0 value:'+value);
      this.vowifiPreferred(0,value);
    },

    '_observe_vowifiPreferred_1': function(value) {
      this.debugInfo('_observe_vowifiPreferred_1 value:'+value);
      this.vowifiPreferred(1,value);
    },

    vowifiPreferred: function (cardIndex,value) {
      if(!value){
        this.debugInfo('vowifiPreferred. invalid value:'+cardIndex);
        return;
      }
      SettingsObserver.getValue('vowifiUIEnable_'+cardIndex).then(status =>{
        if(status === '1'){
          if(this.connections[cardIndex] && this.connections[cardIndex].imsHandler){
            var imsHandler = this.connections[cardIndex].imsHandler;
            var data = this.connections[cardIndex].data;
            var isRoam = (data && data.state === 'registered' && data.roaming);
            if(!isRoam){
              return this.withRetry(() => imsHandler.setPreferredProfile(value));
            }
          }
        }
      });
    },

    '_observe_vowifiPreferredWhenRoaming_0': function(value) {
      this.debugInfo('_observe_vowifiPreferredWhenRoaming_0 value:'+value);
      this.vowifiPreferredWhenRoaming(0,value);
    },

    '_observe_vowifiPreferredWhenRoaming_1': function(value) {
      this.debugInfo('_observe_vowifiPreferredWhenRoaming_1 value:'+value);
      this.vowifiPreferredWhenRoaming(1,value);
    },

    vowifiPreferredWhenRoaming: function (cardIndex,value) {
      if(!value){
        this.debugInfo('vowifiPreferredWhenRoaming.cardIndex:'+ cardIndex +' invalid value:'+value);
        return;
      }
      SettingsObserver.getValue('vowifiUIEnable_'+cardIndex).then(status =>{
        if(status === '1'){
          if(this.connections[cardIndex] && this.connections[cardIndex].imsHandler){
            var imsHandler = this.connections[cardIndex].imsHandler;
            var data = this.connections[cardIndex].data;
            var isRoam = (data && data.state === 'registered' && data.roaming);
            if(isRoam){
              return this.withRetry(() => imsHandler.setPreferredProfile(value));
            }
          }
        }
      });
    },

    '_observe_ril.ims.enabled': function(value) {
      if (Service.query('supportDualLte')) {
        return;
      }
      var simSlots = SIMSlotManager.getSlots();
      for (var index = 0; index < simSlots.length; index++) {
        if (this.connections[index] && this.connections[index].imsHandler) {
          this.taskScheduler.enqueue(index, value, (cardIndex, value) => {
            var imsHandler = this.connections[cardIndex].imsHandler;
            dump('setEnabled ' + cardIndex + ': ' + value);
            return imsHandler.setEnabled(value);
          });
        }
      }
    },

    '_observe_ril.ims.preferredProfile': function(value) {
      if (Service.query('supportDualLte')) {
        return;
      }
      var simSlots = SIMSlotManager.getSlots();
      this.preferredProfile = value;
      for (var index = 0; index < simSlots.length; index++) {
        if (this.connections[index] && this.connections[index].imsHandler) {
          this.taskScheduler.enqueue(index, value, (cardIndex, value) => {
            var imsHandler = this.connections[cardIndex].imsHandler;
            dump('setPreferredProfile ' + cardIndex + ': ' + value);
            return imsHandler.setPreferredProfile(value);
          });
        }
      }
    },

    '_observe_ril.dsds.ims.enabled': function(values) {
      if (!Service.query('supportDualLte')) {
        return;
      }
      let simSlots = SIMSlotManager.getSlots();
      for (let index = 0; index < simSlots.length; index++) {
        if (this.connections[index].imsHandler) {
          let value = values[index];
          this.taskScheduler.enqueue(index, value, (cardIndex, value) => {
            let imsHandler = this.connections[cardIndex].imsHandler;
            dump('setEnabled ' + cardIndex + ': ' + value);
            return imsHandler.setEnabled(value);
          });
        }
      }
    },

    '_observe_ril.dsds.ims.preferredProfile': function(values) {
      if (!Service.query('supportDualLte')) {
        return;
      }
      let simSlots = SIMSlotManager.getSlots();
      for (let index = 0; index < simSlots.length; index++) {
        if (this.connections[index].imsHandler) {
          let value = values[index];
          this.taskScheduler.enqueue(index, value, (cardIndex, value) => {
            let imsHandler = this.connections[cardIndex].imsHandler;
            dump('setPreferredProfile ' + cardIndex + ': ' + value);
            return imsHandler.setPreferredProfile(value);
          });
        }
      }
    },

    '_observe_ril.rtt.enabled': function(value) {
      if (!Service.query('hasRtt')) {
        return;
      }
      this.rttEnabled = value;
      var simSlots = SIMSlotManager.getSlots();
      for (var index = 0; index < simSlots.length; index++) {
        if (this.connections[index] && this.connections[index].imsHandler) {
          this.taskScheduler.enqueue(index, value, (cardIndex, value) => {
            var imsHandler = this.connections[cardIndex].imsHandler;
            dump('setRttEnabled ' + cardIndex + ': ' + !!value);
            return imsHandler.setRttEnabled(!!value);
          });
        }
      }
    },

    //defect10683385 begin-xiaohui.song@tcl.com
    '_observe_volte_item.ui.status': function (value) {
      if (Service.query('supportDualLte')) {
        return;
      }
      //lchen2 , pr 10683385 --begin
      if (value == null) {
        console.log("_observe_volte_item.ui.status , since value is null, so return here ");
        return;
      }
      //lchen2 , pr 10683385 --end
      var simSlots = SIMSlotManager.getSlots();
      for (var index = 0; index < simSlots.length; index++) {
        if (this.connections[index] && this.connections[index].imsHandler) {
          this.taskScheduler.enqueue(index, value, (cardIndex, value) => {
            var imsHandler = this.connections[cardIndex].imsHandler;
            console.log('user changed volte option, set volte enabled to ' + value);
            return imsHandler.setVolteEnabled(value);
          });
        }
      }
    },
    //defect10683385 end-xiaohui.song@tcl.com

  resetRTTValue: function () {
      if (!Service.query('hasRtt')) {
        return;
      }
      const simSlots = SIMSlotManager.getSlots();
      for (let index = 0; index < simSlots.length; index++) {
        if (this.connections[index] && this.connections[index].imsHandler &&
          this.rttEnabled !== undefined &&
          this.connections[index].imsHandler.rttEnabled !== this.rttEnabled) {
          this.taskScheduler.enqueue(index, this.rttEnabled,
            (cardIndex, value) => {
              const imsHandler = this.connections[cardIndex].imsHandler;
              dump('resetRTTValue ' + cardIndex + ': ' + !!value);
              return imsHandler.setRttEnabled(!!value);
            });
        }
      }
    },

    resetPreferredProfile: function () {
      const simSlots = SIMSlotManager.getSlots();
      for (let index = 0; index < simSlots.length; index++) {
        if (this.connections[index] && this.connections[index].imsHandler &&
          this.preferredProfile &&
          this.connections[index].imsHandler.preferredProfile !==
          this.preferredProfile) {
          this.taskScheduler.enqueue(index, this.preferredProfile,
            (cardIndex, value) => {
              const imsHandler = this.connections[cardIndex].imsHandler;
              dump('resetPreferredProfile ' + cardIndex + ': ' + value);
              return imsHandler.setPreferredProfile(value);
            });
        }
      }
    },


    savePreferredNetworkType: function() {
      var cardIndex = this.defaultServiceId;
      const conns = navigator.b2g.mobileConnections || [];
      if (this.prefSimIccId && conns[cardIndex] &&
        this.prefSimIccId === conns[cardIndex].iccId) {
        var preferredNetworkType =
          SettingsHelper('ril.defaultServiceId.preferredNetworkType');
        preferredNetworkType.set(this.prefNetworkType[cardIndex]);
      }
    },
    /**
     * Initializes voice privacy based on user setting.
     */
    initVoicePrivacy: function() {
      SettingsObserver.getValue('ril.voicePrivacy.enabled').then((values) => {
        if (!values) {
          console.log('ril.voicePrivacy.enabled is undefined, ' +
            'device does not support CDMA');
          return;
        }
        this.connections.forEach(function vp_iterator(conn, index) {
          var setReq = conn.setVoicePrivacyMode(values[index]);
          setReq.onerror = function set_vpm_error() {
            if (setReq.error.name === 'RequestNotSupported' ||
                setReq.error.name === 'GenericFailure') {
              console.log('Request not supported.');
            } else {
              console.error('Error setting voice privacy.');
            }
          };
        });
      });
    },

    /**
     * Initializes roaming based on user setting.
     */
    initRoaming: function() {
      var defaultRoamingPreferences =
        this.connections.map(function() { return 'any'; });
      var roamingPreferenceHelper =
        SettingsHelper('ril.roaming.preference', defaultRoamingPreferences);
      roamingPreferenceHelper.get(function got_rp(values) {
        this.connections.forEach(function rp_iterator(conn, index) {
          var setReq = conn.setRoamingPreference(values[index]);
          setReq.onerror = function set_vpm_error() {
            if (setReq.error.name === 'RequestNotSupported' ||
                setReq.error.name === 'GenericFailure') {
              console.log('Request not supported.');
            } else {
              console.error('Error roaming preference.');
            }
          };
        });
      }.bind(this));
    },
    // cardsState.state:
    // 1. 'newPrefCard' --> set data to other card
    // 2. 'oldCard' --> reboot device and card not change
    // 3. 'recordPrefCard' -->  insert new card and the card is the last card
    //                          that user set mobile data
    // 4. 'noSimCard' --> no sim card in device
    // 5. 'noMobileData' --> the card not set mobile data.
    // 6. 1 & 4 set with allType
    // 7. 2 set with 'ril.radio.preferredNetworkType'
    // 8. 3 set with 'ril.defaultServiceId.preferredNetworkType'
    // 9. 5 set allType;
    setPreferredNetworkType: function(cardsState) {
      this.connections.forEach((conn, index) => {
        this._getDefaultPreferredNetworkType(index).then((allType) => {
          console.log('[TelephonySettings]getPreferredNetworkType ' +
            allType + ' ' + cardsState[index].state);
          var state = cardsState[index].state;
          if (state === 'newPrefCard' || state === 'noSimCard') {
            this.prefNetworkType[index] = allType;
          } else if (state === 'recordPrefCard') {
            this.prefNetworkType[index] =
              this.defaultPrefNetworkType || allType;
          } else if (state === 'noMobileData') {
            this.prefNetworkType[index] = allType;
          }
          this._setDefaultPreferredNetworkType(conn,
            this.prefNetworkType[index]);
          var preferredNetworkTypeHelper =
            SettingsHelper('ril.radio.preferredNetworkType');
          preferredNetworkTypeHelper.set(this.prefNetworkType);
        });
      });
    },

    filterpreferredNetworkType: function(values, defaultValues) {
      const defaultArray = defaultValues.split('/') || [];
      const valueArray = values.split('/') || [];
      let types = valueArray.filter((value) => {
        return (defaultArray.includes(value));
      }).join('/');
      return types;
    },

    /**
     * Initialize preferred network type. If the default value is null, we
     * should use the option that makes the device able to connect all supported
     * netwrok types.
     */
    initPreferredNetworkType: function() {
      var preferredNetworkTypeHelper =
        SettingsHelper('ril.radio.preferredNetworkType');
      preferredNetworkTypeHelper.get((values) => {
        this._getDefaultPreferredNetworkTypes().then(defaultValues => {
          if (!values || !values.length) {
            values = defaultValues;
            preferredNetworkTypeHelper.set(values);
          } else if (typeof values == 'string') {
            values =
              [this.filterpreferredNetworkType(values, defaultValues[0])];
            preferredNetworkTypeHelper.set(values);
          }
          this.connections.forEach((conn, index) => {
            this._setDefaultPreferredNetworkType(
              conn,
              this.filterpreferredNetworkType(values[index],
              defaultValues[index]));
          });
        });
      });
    },

    _isSubSidyLock: function(index) {
      const SUBSIDY_LOCK_SIM_NETWORK = 1;
      if (navigator.subsidyLockManager) {
        return new Promise((resolve) => {
          navigator.subsidyLockManager[index].getSubsidyLockStatus()
            .then((value) => {
            if (value && value.includes(SUBSIDY_LOCK_SIM_NETWORK)) {
              resolve(true);
            } else {
              resolve(false);
            }
          });
        });
      } else {
        return Promise.resolve(false);
      }
    },

    _setDefaultPreferredNetworkType: function(conn, preferredNetworkType) {
      var doSet = function() {
        console.log('[TelephonySettings]setPreferredNetworkType ' +
          preferredNetworkType);
        if (preferredNetworkType !== '') {
          var setReq = conn.setPreferredNetworkType(preferredNetworkType);
          setReq.onerror = function set_vpm_error() {
            console.error('Error setting preferred network type: ' +
              preferredNetworkType);
          }
        };
      };
      if (conn.radioState === 'enabled') {
        doSet();
      } else {
        conn.addEventListener('radiostatechange', function onchange() {
          if (conn.radioState === 'enabled') {
            conn.removeEventListener('radiostatechange', onchange);
            doSet();
          }
        });
      }
    },

    /**
     * Returns an array specifying the default preferred network types of all
     * mobile connections.
     */
    _getDefaultPreferredNetworkTypes: function() {
      return new Promise((resolve) => {
        let promises = [];
        this.connections.forEach((conn, index) => {
          promises.push(this._getDefaultPreferredNetworkType(index));
        });
        Promise.all(promises).then(values => {
          resolve(values);
        });
      });
    },

    /**
     * Returns the default preferred network types based on the hardware
     * supported network types.
     */
    _getDefaultPreferredNetworkType: function(index) {
      const conn = navigator.b2g.mobileConnections &&
        navigator.b2g.mobileConnections[index];
      return new Promise((resolve) => {
        Promise.all([conn.getSupportedNetworkTypes(),
          this._isSubSidyLock(index)])
          .then((values) => {
          let allTypes =
            ['nr', 'lte', 'wcdma', 'tdscdma', 'gsm', 'cdma', 'evdo'];
          if (values[1]) {
            if (values[0].indexOf('lte') > -1) {
              allTypes = ['wcdma', 'tdscdma', 'gsm', 'cdma', 'evdo'];
            } else {
              allTypes = ['gsm', 'cdma', 'evdo'];
            }
          }
          let types = allTypes.filter((type) => {
            return (values[0] && values[0].indexOf(type) !== -1);
          }).join('/');
          resolve(types);
        });
      });
    }
  });

}());
