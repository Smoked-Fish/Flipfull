'use strict';
/* global SettingsObserver, SIMSlotManager,  */

let vowifiConfig = {
    // Initialize the configuration
    _init: function() {
        dump('vowifiConfig init');
        window.addEventListener(
            'simslot-iccinfochange',
            (event) => {
                dump('vowifiConfig iccinfochange');
                this._simChanged(event.detail);
            }
        );
        window.addEventListener(
            'simslot-cardstatechange',
            (event) => {
                dump('vowifiConfig cardstatechange');
                this._simChanged(event.detail);
            }
        );

        this._checkIcc();
    },
    //Defect-GF5GTMO-5766-begin The WFC default status is off guanzhong.zhu.cd 2024/12/20
    // Load the default configurations
    _loadDefaultConfigs: function(operator) {
        const defaultConfigsTable = {
            'TMO': {
                vowifiUIStatus: '1',
                preferredProfile: 'cellular-preferred',
                preferredProfileWhenRoaming: 'cellular-preferred'
            },
            'MetroPCS': {
                vowifiUIStatus: '1',
                preferredProfile: 'cellular-preferred',
                preferredProfileWhenRoaming: 'cellular-preferred'
            },
            'ASW': {
                vowifiUIStatus: '1',
                preferredProfile: 'cellular-preferred',
                preferredProfileWhenRoaming: 'cellular-preferred'
            },
            'VZW': {
                vowifiUIStatus: '0',
                preferredProfile: 'cellular-preferred',
                preferredProfileWhenRoaming: 'cellular-preferred'
            },
            // Add more operators and their default values as needed
        };
        //[Feature] modified vowifiUIStatus default as 0 for GF5GTMO-8548 on 2025/10/27
        return defaultConfigsTable[operator] || {
            vowifiUIStatus: '0',
            preferredProfile: 'cellular-preferred',
            preferredProfileWhenRoaming: 'cellular-preferred'
        };
    },
    //Defect-GF5GTMO-5766-end The WFC default status is off guanzhong.zhu.cd 2024/12/20

    // Reset the slot settings to the default configuration
    _resetSlotToDefault: function(index, defaultConfigs) {
        this._dumpDefaultConfigs(defaultConfigs);

        let settingsToSet = [];

        // Only set values that are not undefined
        if (defaultConfigs.vowifiUIStatus !== undefined) {
            settingsToSet.push({ name: 'vowifiUIEnable_' + index, value: defaultConfigs.vowifiUIStatus });
        }
        if (defaultConfigs.preferredProfile !== undefined) {
            settingsToSet.push({ name: 'vowifiPreferred_' + index, value: defaultConfigs.preferredProfile });
        }
        if (defaultConfigs.preferredProfileWhenRoaming !== undefined) {
            settingsToSet.push({ name: 'vowifiPreferredWhenRoaming_' + index, value: defaultConfigs.preferredProfileWhenRoaming });
        }

        SettingsObserver.setValue(settingsToSet);
    },

    _checkIcc: function (){
      dump('vowifiConfig _checkIcc');
        var simSlots = SIMSlotManager.getSlots();
        for (var index = 0; index < simSlots.length; index++) {
          this._simChanged(simSlots[index]);
        }
    },
    // Event handler when sim information changes
    _simChanged: function(slot) {
        var index = slot.index;
        var simCard = slot.simCard;
        var cardState = simCard && simCard.cardState;
        var iccid = simCard && simCard.iccInfo && simCard.iccInfo.iccid;
        dump('vowifiConfig _simChanged:' + index+' cardState:'+cardState);

        // Proceed only if the SIM card is ready and iccid is available
        if (cardState === 'ready' && iccid) {
            SettingsObserver.getValue('vowifiConfigCache').then(cache => {
                // Reset to default settings if the ICCID has changed
                let  operatorName = OperatorUtils.getSimOperatorNameByIndex(index);
                dump('vowifiConfig operatorName'+operatorName);
                if (!cache || cache[index] !== iccid) {
                    const defaultConfigs = this._loadDefaultConfigs(operatorName);
                    this._resetSlotToDefault(slot.index, defaultConfigs);
                    if(!cache){
                      cache = {};
                    }
                    cache[index] = iccid;
                    SettingsObserver.setValue([{ name: 'vowifiConfigCache', value: cache }]);
                }
            });
        }
    },

    // Debug method to output default configurations
    _dumpDefaultConfigs: function(defaultConfigs) {
        dump('vowifiConfig vowifiUIStatus:' + defaultConfigs.vowifiUIStatus +
            ' preferredProfile ' + defaultConfigs.preferredProfile +
            ' preferredProfileWhenRoaming ' + defaultConfigs.preferredProfileWhenRoaming);
    },
};

// Initialize the configuration
vowifiConfig._init();
