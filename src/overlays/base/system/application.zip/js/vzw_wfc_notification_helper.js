/* global SettingsObserver, SIMSlotManager */
'use strict';
var VZWWFCNotificationHelper = {
  ftuDone:false,
  notificationsMap:new Map(),
  debug: function (msg) {
    console.log('VZWWFCNotificationHelper, ' + msg);
  },
  _init: function vzw_wfc_init(){
    this.debug('init ===========================');
    window.addEventListener(
      'simslot-iccinfochange',
      (function (event) {
        this._iccInfoChanged(event.detail);
      }).bind(this)
    );
    window.addEventListener('ftudone', this._ftuDone.bind(this));
    window.addEventListener('ftuskip', this._ftuDone.bind(this));
    let simSlots = SIMSlotManager.getSlots();
    for (let index = 0; index < simSlots.length; index++) {
      (function(index) {
        SettingsObserver.observe('vowifiUIEnable_' + index, '0', (value) => {
          this.debug('SettingsObserver=========vowifiUIEnable_' + index + '===========value====' + value);
          if (value === '1') {
            this.clearVZWWifiCallNotification(index);
            // Defect 11030474-rongjun.zheng@tcl.com-The status of WFC switch display incorrectly when flash MS with VZW SIM inserted-begin
          } else {
            window.setTimeout(this.checkAndShowVZWFCNotification.bind(this, index), 5000);
          }
          // Defect 11030474-rongjun.zheng@tcl.com-The status of WFC switch display incorrectly when flash MS with VZW SIM inserted-end
        });
      }.call(this, index));
    }
    // defect-GF7VZW-7379-begin guanzhong.zhu.cd@tcl.com 2023/12/15
    SettingsObserver.observe('persist.dbg.clear_vzw_wfc_auth_info',null, (value)=>{
      this.debug('SettingsObserver=========persist.dbg.clear_vzw_wfc_auth_info===========value===='+value);
      let simSlots = SIMSlotManager.getSlots();
      for (let index = 0; index < simSlots.length; index++) {
        SettingsObserver.setValue([{
          name :'E911ADDR_SAVED' + (this._getPhoneIccid(index)),
          value:0
        }]);
      }
    },true);
    // defect-GF7VZW-7379-end guanzhong.zhu.cd@tcl.com 2023/12/15
  },
  _getPhoneIccid: function(cardIndex) {
    let iccId = null;
    let connection = navigator.b2g.mobileConnections;
    if (connection[cardIndex]) {
      iccId = connection[cardIndex].iccId;
    }
    return iccId;
  },

  _iccInfoChanged: function (slot){
    this.debug('iccInfoChanged');
    window.setTimeout(this.checkAndShowVZWFCNotification.bind(this,slot.index),3000);
  },
  checkAndShowVZWFCNotification: function (cardIndex){
    this.debug('checkAndShowVZWFCNotification cardIndex:'+cardIndex);
    const conns = navigator.b2g.mobileConnections;
    var _imsHandler = conns && conns[cardIndex] && conns[cardIndex].imsHandler;
    if(_imsHandler){
      _imsHandler.addEventListener('vowifiOMAEnabledStateChange',
        function onevent(){
          this.debug('vowifiOMAEnabledStateChange vowifiOMAEnabled:'+_imsHandler.vowifiOMAEnabled);
          if(!_imsHandler.vowifiOMAEnabled){
            this.clearVZWWifiCallNotification(cardIndex);
          }
        }
      );
      if(!_imsHandler.vowifiOMAEnabled){
        this.debug('_imsHandler.vowifiOMAEnabled'+_imsHandler.vowifiOMAEnabled);
        return;
      }
      if(!this.ftuDone){
        this.debug('ftu not done ,return-----' );
        return;
      }
      let  operatorName = OperatorUtils.getSimOperatorNameByIndex(cardIndex);
      this.debug('operatorName = ' + operatorName);
      if (operatorName!='VZW'){
        return ;
      }
      var iccManager = navigator.b2g.iccManager;
      var iccid = iccManager && iccManager.iccIds[cardIndex];
      if(!iccid){
        return;
      }
      this.checkVZWMDN(iccid);
      try {
        Promise.all([
          SettingsObserver.getValue('ril.ims.enabled'),
          SettingsObserver.getValue('vowifiUIEnable_'+cardIndex),
          SettingsObserver.getValue('E911ADDR_SAVED'+iccid),
          SettingsObserver.getValue('vzw_notification_cancel_by_user'+iccid)
        ]).then(results => {
          let imsOn = results[0];
          let vowifiUIEnabled = results[1];
          let e911_addr = results[2];
          let cancelByUser = results[3];
          this.debug('e911_addr = ' + e911_addr);
          this.debug('imsOn = ' + imsOn);
          this.debug('vowifiUIEnabled = ' + vowifiUIEnabled);
          this.debug('vzw_notification_cancel_by_user = ' + cancelByUser);
          if((vowifiUIEnabled === '1')&&imsOn){
            dump('wfc ON ============== ' );
            this.clearVZWWifiCallNotification(cardIndex);
            return;
          }
          if(e911_addr&&e911_addr!=""){
            this.clearVZWWifiCallNotification(cardIndex);
            return;
          }
          if(cancelByUser == 1){
            this.clearVZWWifiCallNotification(cardIndex);
            return;
          }

          SettingsObserver.observe('vzw_notification_cancel_by_user'+iccid,null, (value)=>{
            this.debug('vzw_notification_cancel_by_user'+iccid+' :'+value);
            if(value == 1){
              this.clearVZWWifiCallNotification(cardIndex);
            }
          },true);

          var icon = window.location.protocol + '//' + window.location.hostname +
            '/style/icons/captivePortal.png';
          let message = window.api.l10n.get('wfc_emergency_notification_text') ;
          var notification = new Notification('', {
            body: message,
            icon: icon,
            tag: 'wificall_vzw'+cardIndex,
            mozbehavior: {
              showOnlyOnce: true,
              soundFile: null,
              noclear: true,
              vibrationPattern: [1]
            }
          });
          notification.onclick = function() {
            //enter wfc settings
            this.debug('notification.onclick=========== ' );
            var activity = new WebActivity(
              'launch-wfc',{type:'vzwwfcswitch',cardIndex:cardIndex}
            );
            activity.start();
          }.bind(this);
          this.notificationsMap.set(notification.tag,notification);
        }, () => {
          this.debug(' launch fail');
        });
      } catch (e) {
        this.debug('launch e = ' + e);
      }
    }
  },
  clearVZWWifiCallNotification:function (cardIndex) {
    this.debug('clearVZWWifiCallNotification:'+cardIndex);
    let key = 'wificall_vzw'+cardIndex;
    if(this.notificationsMap.has(key)){
      let notification = this.notificationsMap.get(key);
      notification.close();
      this.notificationsMap.delete(key);
    }
  },
  _ftuDone: function () {
    this.debug('ftudone or ftuskip event');
    this.ftuDone = true;
    let simSlots = SIMSlotManager.getSlots();
    for (let index = 0; index < simSlots.length; index++) {
      (function(index) {
        window.setTimeout(this.checkAndShowVZWFCNotification.bind(this,index),3000);
      }.call(this, index));
    }
    window.removeEventListener('ftudone', this._ftuDone.bind(this));
    window.removeEventListener('ftuskip', this._ftuDone.bind(this));
  },

  resetWfc: function (cardIndex) {
    SettingsObserver.setValue([{
      name: 'vowifiUIEnable_' + cardIndex,
      value: '0'
    }]).then(()=>{
      this.debug('resetWfc==========done');
      this.checkAndShowVZWFCNotification(cardIndex);
    });
  },

  checkVZWMDN:function (iccid,cardIndex) {
    SettingsObserver.getValue('wfc_last_iccid_'+cardIndex).then((value)=> {
      if(iccid!==value){
        this.resetWfc(cardIndex);
        if(window.remoteHelper){
          window.remoteHelper.runXHRequest('name=query&api=set_sys_property&key=vzw_mdn&data=0', () => {
            this.debug('checkVZWMDN setmdn success=====');
          }, ()=> {
            this.debug('checkVZWMDN setmdn error=====');
          });
        }
        SettingsObserver.setValue([{
          name: 'wfc_last_iccid_'+cardIndex,
          value: iccid
        }]);
        SettingsObserver.setValue([{
          name: 'vzw_notification_cancel_by_user'+iccid,
          value: 0
        }]);
        SettingsObserver.setValue([{
          name: 'E911ADDR_SAVED'+iccid,
          value: 0
        }]);
      }
    });
  }
};
VZWWFCNotificationHelper._init();
