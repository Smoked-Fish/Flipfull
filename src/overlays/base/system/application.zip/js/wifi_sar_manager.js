/**
 * [WifiSarManager description]
 * @type {Object}
 * [GF5GTMO-4298] create by shangpeng.su 2024.10.08
 */
/* global SettingsObserver, SIMSlotManager */
'use strict';
var WifiSarManager = {
  _DEBUG: false,
  _wifiManager: navigator.b2g.wifiManager,
  _networkUpload: false,
  _dataActivityOut: false,
  _isCalling: false,
  _isMobileDataOn: false,
  _isHotspotOn: false,
  _isWiredHeadsetPlugin: false,
  _isBtScoConnected: false,
  _isReceiverActive: false,
  _isSpeakerActive: false,
  _isWifiConnected: false,
  _hotspotBand: "2.4G",
  _wifiSarState: -1,
  _wifiSarBand: -1,
  _wifiSarPwrOffSet: {
    '1': '60-60',
    '2': '60-60',
    '3': '60-60'
  },
  _wifiSar24GPwrOffSet: {
    '1': '60',
    '2': '60',
    '3': '60'
  },
  _wifiSar5GPwrOffSet: {
    '1': '60',
    '2': '60',
    '3': '60'
  },


  debug: function (msg) {
    if (this._DEBUG) {
      console.log('[WifiSarManager] ' + msg);
    }
  },

  debugv: function (msg) {
    dump('[WifiSarManager] ' + msg);
  },

  _init: function wifisarmanager_init() {
    var self = this;

    self.debugv('init');
    window.addEventListener('homescreenloaded', () => {
      if (navigator.b2g.engmodeManager) {
        navigator.b2g.engmodeManager.getPropertyValue('ro.boot.mmitest').then(value => {
          if (value || value === 'true') {
            self.debugv('mmitest version, ignore');
            return;
          }
          navigator.b2g.engmodeManager.getPropertyValue('persist.sys.sar.wifi.enabled').then(
            value => {
              if (
                typeof(value) === 'undefined' || !value ||
                value === 'false' || value === '0'
              ) {
                self.debugv('wifi sar is not enabled');
                return;
              }
              self._initData();
            }
          );
        });
      }
    }, { once: true });
  },

  _initData: function() {
    let self = this;
    window.addEventListener('wifi-enabled', function (event) {
      self._updateWifiSarState();
    });
    window.addEventListener('wifi-disabled', function (event) {
      self._updateWifiSarState();
    });
    window.addEventListener('wifi-statuschange', function (event) {
      self._isWifiConnected = self._wifiManager.connection.status === 'connected';
      self._updateWifiSarState();
    });
    window.addEventListener('networkupload', function (event) {
      self._handleEvent(event);
    });
    const telephony = navigator.b2g.telephony;
    if (telephony) {
      telephony.addEventListener('callschanged', function (event) {
        self._handleEvent(event);
      });
    }

    SettingsObserver.observe(
      'ril.data.enabled',
       false,
       self._mobileDataChange.bind(self)
    );
    SettingsObserver.observe(
      'wifi.debugging.enabled',
       false,
       (enabled) => {
         self._DEBUG = enabled;
       }
    );
    SettingsObserver.observe(
      'telephony.audio.output.speaker',
      false,
      (speakerEnabled) => {
        self._isSpeakerActive = speakerEnabled;
        self._updateReceiverStatus();
      }
    );
    SettingsObserver.observe(
      'tethering.wifi.enabled',
      false,
      (enabled) => {
        //[GF5GTMO-6603] modify-begin shangpeng.su 2025.02.24
        navigator.b2g.engmodeManager.setPropertyLE("wifi_sar_hotspotstatus", enabled ? "running" : "stopped")
          .then(result => {
            self.debugv('setprop wifi_sar_hotspotstatus ' + result);
            self._isHotspotOn = enabled;
            self._updateWifiSarState();
          });
        //[GF5GTMO-6603] modify-end shangpeng.su 2025.02.24
      }
    );
    SettingsObserver.observe(
      'tethering.wifi.band',
      false,
      (band) => {
        self._hotspotBand = band;
        self._updateWifiSarState();
      }
    );
    SettingsObserver.getValue('wifi.enabled').then(enabled => {
      self.debug('wifi-enabled=' + enabled);
      if (self._wifiManager && self._wifiManager.connection) {
        self._isWifiConnected = self._wifiManager.connection.status === 'connected';
      }
      self._updateWifiSarState();
    });
    SettingsObserver.getValue('wifi.debugging.enabled').then(enabled => {
      self._DEBUG = enabled;
    });
    SettingsObserver.getValue('ril.data.enabled').then(enabled => {
      self._mobileDataChange.bind(self);
    });

    let audioCM = navigator.b2g.audioChannelManager;
    if (audioCM) {
      audioCM.addEventListener('headphoneschange', () => {
        self._isWiredHeadsetPlugin = audioCM.headphones;
        self._updateReceiverStatus();
      });
    }
    let btHelper = new BluetoothHelper();
    if (btHelper) {
        btHelper.onscostatuschanged = (evt) => {
            self._isBtScoConnected = evt.status;
            self._updateReceiverStatus();
        };
    }

    SettingsObserver.getValue('wifi.sar.pwroffset').then(value => {
      self.debug('wifi.sar.pwroffset value =>' + value);
      if (value) {
        let str = value;
        str = str.replace(/'/g, '"');
        var pwroffset = JSON.parse(str);
        if (pwroffset) {
          for (let key in pwroffset) {
            if (self._wifiSarPwrOffSet[key]) {
              self._wifiSarPwrOffSet[key] = pwroffset[key];
              let bandoffset = pwroffset[key].split('-');
              if (bandoffset.length > 1) {
                self._wifiSar24GPwrOffSet[key] = bandoffset[0];
                self._wifiSar5GPwrOffSet[key] = bandoffset[1];
              }
            }
          }
        }
      }
    });

    //set default sar
    self._updateWifiSarState();  
  },

  _handleEvent: function (evt) {
    this.debug('evt.type=' + evt.type);
    let self = this;
    switch (evt.type) {
      case 'networkupload':
        self._networkUpload = true;
        self._updateDataActivityOut();
        clearTimeout(self._networkLoadTimer);
        self._networkLoadTimer = setTimeout(function resetNework() {
          self.debug('set _networkUpload to false');
          self._networkUpload = false;
          self._updateDataActivityOut();
        }.bind(self), 2000);
        break;
      case 'callschanged':
        self._handleCallsChanged();
        break;
      default:
        break;
    }
  },

  _mobileDataChange: function(enabled) {
    this.debugv("mobile data change to " + enabled);
    if ((enabled && !this._isMobileDataOn) || (!enabled && this._isMobileDataOn)) {
      this._isMobileDataOn = enabled;
      this._updateDataActivityOut();
    };
  },

  _updateDataActivityOut: function () {
    if (SIMSlotManager.noSIMCardOnDevice()) {
      this.debugv('no sim card');
      this._dataActivityOut = false;
      return;
    }

    SIMSlotManager.getSlots().forEach(SIMSlot => {
      let self = this;
      let curDataOut = false;
      if (!SIMSlot.isAbsent() && self._isMobileDataOn) {
        let isWifiConnected = self._wifiManager &&
            self._wifiManager.connection &&
            'connected' === self._wifiManager.connection.status;
        if (!isWifiConnected && self._networkUpload) {
          curDataOut = true;
        }
      }
      if (
        (curDataOut && !self._dataActivityOut) ||
        (!curDataOut && self._dataActivityOut)
      ) {
        self.debug(' change _dataActivityOut to ' + curDataOut);
        self._dataActivityOut = curDataOut;
        self._updateWifiSarState();
      }
    });
  },

  _handleCallsChanged: function() {
    let self = this;
    let calling = false;
    const { calls } = navigator.b2g.telephony;
    for (let i = 0; i < calls.length; i++) {
      const call = calls[i];
      call.addEventListener('statechange', function callStateChange() {
        self.debug('CALL State Change: ' + call.state);
        switch (call.state) {
          case 'connected':
          case 'alerting':
          case 'incoming':
            self.debug('calling= true');
            calling = true;
            break;
          case 'disconnected':
            calling = false;
            call.removeEventListener('statechange', callStateChange);
            break;
          default:
            break;
        }
        self.debug('calling= ' + calling + "," + self._isCalling);
        if (
          (self._isCalling && !calling) ||
          (!self._isCalling && calling)
        ) {
          self.debugv(' change call state is ' + calling);
          self._isCalling = calling;
          self._updateReceiverStatus();
        }
      });
    }
  },

  _updateReceiverStatus: function() {
    if (this._isCalling) {
      if (this._isWiredHeadSetPlugin || this._isBtScoConnected || this._isSpeakerActive) {
        this._isReceiverActive = false;
      } else {
        this._isReceiverActive = true;
      }
    } else {
      this._isReceiverActive = false;
    }
    this._updateWifiSarState();
  },

  _updateWifiSarState: function () {
    let curSarState = 0;
    let band = 0;//default 2.4G
    let freq = 0;
    this.debug("status is " +
      this._isReceiverActive + ":" + this._isCalling + ":" + this._dataActivityOut + ":" +
      this._wifiManager.enabled + ":" + this._isHotspotOn + ":" + this._isWifiConnected);
    if (
      this._isReceiverActive &&
      (this._isCalling || this._dataActivityOut) &&
      (this._wifiManager.enabled || this._isHotspotOn)
    ) {//SAR4
      curSarState = 1;
      if (this._wifiManager.enabled && this._isWifiConnected) {
        freq = this._wifiManager.connection.network.frequency;
        if (freq / 1000 >= 5) {
          band = 1;
        }
      } else if (this._isHotspotOn) {
        if (this._hotspotBand.indexOf("5G") > -1) {
          band = 1;
        }
      } else {
        curSarState = 0;
      }
    } else if (//SAR5
      !this._isReceiverActive &&
      (this._isCalling || this._dataActivityOut) &&
      this._isHotspotOn
    ) {
      curSarState = 2;
      if (this._hotspotBand.indexOf("5G") > -1) {
        band = 1;
      }
    } else if (//SAR6
      !this._isReceiverActive &&
      (this._isCalling || this._dataActivityOut) &&
      this._wifiManager.enabled
    ) {
      curSarState = 3;
      if (this._isWifiConnected) {
        freq = this._wifiManager.connection.network.frequency;
        if (freq / 1000 >= 5) {
          band = 1;
        }
      } else {
        curSarState = 0;
      }
    }

    if (curSarState !== this._wifiSarState || band !== this._wifiSarBand) {
      this.debugv('set wifisarstate to ' + curSarState);
      this._wifiSarState = curSarState;
      this._wifiSarBand = band;
      let pwroffset = "60";
      if (typeof (this._wifiSar24GPwrOffSet[curSarState]) !== 'undefined') {
        pwroffset = this._wifiSar24GPwrOffSet[String(curSarState)];
        if (band === 1) {
          pwroffset = this._wifiSar5GPwrOffSet[String(curSarState)];
        }
      }

      this.debug('set pwroffset to ' + pwroffset + " for " + band +" band");

      let self = this;
      //sys.sar.wifi.txmaxpower
      navigator.b2g.engmodeManager.setPropertyLE("wifi_sar_txmaxpower", pwroffset)
        .then(result => {
          navigator.b2g.engmodeManager.setPropertyLE("wifi_sar_enabled", "reduce")
            .then(result => {
              let success = ('process-finished' === result);
              self.debugv('set wifi txmaxpower prop ' + (success ? "success" : "fail"));
            });
        });
    }
  }
};
WifiSarManager._init();
