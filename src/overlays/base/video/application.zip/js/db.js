'use strict';

/*
 * This file is part of the Gaia Video app.  It uses the MediaDB libarary
 * and the code in metadata.js to ensure that the videos[] array is up to date.
 */

/* globals MediaDB, playerShowing, firstScanEnded, thumbnailList, metadataQueue
  showOverlay, updateDialog, playerShowing, resetCurrentVideo, currentVideo
  hidePlayer, selectedFileNames, Toaster, hideInfoView, addToMetadataQueue,
  hideSelectView, currentLayoutMode, option, LAYOUT_MODE, NavigationMap*/
const videoMediaDB = {
  videodb: null,
  lastIndexDb: 0,
  lastIndex: null,
  enumerateDone: false,
  limitByLoad: 0,
  pendingEnumerate: null,
  enumerateFiles: [],
  fileOrder: 1,
  currentBatch: 1,
  batchSize: 10,
  ENUMERATE_INTERVAL: 1000,
  initDB() {
    // Use excludeFilter to ignore dummy files from camera.
    videoMediaDB.videodb = new MediaDB('videos', null);
    document.addEventListener('visibilitychange', () => {
      if (!playerShowing) {
        if (!document.hidden) {
          videoMediaDB.videodb.scan(this);
          if (firstScanEnded &&
            thumbnailList.count === 0 &&
            metadataQueue.length === 0) {
            if (VideoUtils.fromActivity || !VideoUtils.supportKaiAds) {
              showOverlay('empty');
            } else {
              showOnlineSuggestionView(true);
            }
          }
        } else {
          videoMediaDB.videodb.stopScan();
        }
      }
      /* eslint-enable */
    });

    videoMediaDB.videodb.onopenMediaDBFail = () => {
      window.close();
    };

    videoMediaDB.videodb.onupgrading = () => {
      // Show dialog in upgradestart, when it finished, it will turned to ready.
      // eslint-disable-next-line
      storageState = MediaDB.UPGRADING;
      updateDialog();
    };

    videoMediaDB.videodb.onunavailable = (event) => {
      // eslint-disable-next-line
      storageState = event.detail;

      /*
       * If player is playing, we need to hide the player which pauses the player
       * and unloads the video file.
       */
      if (playerShowing) {
        hidePlayer(true);
      }
      updateDialog();
    };

    /*
     * On devices that have internal and external storage, we get this event
     * when the user pulls the sdcard out. If we're playing a video when that
     * happens, we need to stop or risk a crash.
     */
    videoMediaDB.videodb.oncardremoved = () => {
      if (playerShowing) {
        hidePlayer(true);
      }
    };

    videoMediaDB.videodb.onenumerable = () => {
      // eslint-disable-next-line
      storageState = false;
      videoMediaDB.startTheFirstEnumerate();
    };

    videoMediaDB.videodb.onempty = () => {
      // eslint-disable-next-line
      isSearching = false;
      updateDialog();
    };

    videoMediaDB.videodb.onscanend = () => {
      if (!videoMediaDB.videodb.details.firstscan) {
        // eslint-disable-next-line
        isSearching = false;
      }

      /*
       * If this was the first scan after startup, then tell
       * performance monitors that the app is finally fully loaded and stable.
       */
      if (!firstScanEnded) {
        /* eslint-disable */
        firstScanEnded = true;
        /* eslint-enable */
        window.performance.mark('fullyLoaded');
        // Didn't updateDialog when currentLayout isn't list or optionmenu visible
        if (currentLayoutMode === 'layout-list' && !option.menuVisible) {
          updateDialog();
        }
      }
    };

    videoMediaDB.videodb.oncreated = (event) => {
      if (event.detail.length === 1 && !document.hasFocus()) {
        /* eslint-disable-next-line */
        if (event.detail[0].name.search(/^.+(\/\.tmp\.3gp)$/) !== -1) {
          return;
        }
      }
      event.detail.forEach(videoMediaDB.videoCreated);
    };

    videoMediaDB.videodb.ondeleted = (event) => {
      if (event.detail.length === 1 && !document.hasFocus()) {
        /* eslint-disable-next-line */
        if (event.detail[0].search(/^.+(\/\.tmp\.3gp)$/) !== -1) {
          return;
        }
      }
      if (event.detail.length === 1) {
        if (window.performance.getEntriesByName(
          'delete-a-video-start', 'mark').length > 0) {
          window.performance.mark('delete-a-video-end');
          window.performance.measure('performance-delete-a-video',
            'delete-a-video-start', 'delete-a-video-end');
          window.performance.clearMeasures('performance-delete-a-video');
          window.performance.clearMarks('delete-a-video-start');
          window.performance.clearMarks('delete-a-video-end');
        }
      } else if (window.performance.getEntriesByName(
        'delete-all-video-start', 'mark').length > 0) {
        window.performance.mark('delete-all-video-end');
        window.performance.measure('performance-delete-all-video',
          'delete-all-video-start', 'delete-all-video-end');
        window.performance.clearMeasures('performance-delete-all-video');
        window.performance.clearMarks('delete-all-video-start');
        window.performance.clearMarks('delete-all-video-end');
      }
      /* eslint-disable */
      if (isDisplayToast) {
        isDisplayToast = false;
        Toaster.showToast({
          messageL10nId: 'n-video-deleted',
          messageL10nArgs: { n: totalDeletedCount }
        });
      }
      if (window.option.menuVisible) {
        window.option.menuVisible = false;
        window.option.hideMenu();
      }
      const bodyClass = document.body.className.split(' ');
      if (bodyClass.indexOf('info-view') !== -1) {
        hideInfoView();
      } else if (currentLayoutMode !== 'layout-selection') {
        if (!playerShowing) {
          updateDialog();
        }
      }

      // For loop is a little bit faster than forEach ~ 23ms
      const videoListLength = event.detail.length;
      for (let i = 0; i < videoListLength; i++) {
        const index = selectedFileNames.indexOf(event.detail[i]);
        if (index !== -1) {
          selectedFileNames.splice(index, 1);
        }
        if (currentVideo.name === event.detail[i] &&
          VideoUtils.fromActivity) {
            switchLayout('layout-list');
        }
        videoMediaDB.videoDeleted(event.detail[i]);
      }
    };
  },

  startTheFirstEnumerate() {
    videoMediaDB.pendingEnumerate = videoMediaDB.videodb.enumerate(
      'date',
      null,
      'prev',
      videoMediaDB.enumerateHandle
    );
  },

  enumerateHandle(videoinfo) {
    if (videoinfo === null) {
      // eslint-disable-next-line
      videoMediaDB.enumerateDone = videoMediaDB.pendingEnumerate.state === 'complete';
      videoMediaDB.batchEnumerateHandle();
      return;
    }
    const { isVideo } = videoinfo.metadata;

    // If we know this is not a video, ignore it
    if (isVideo === false) {
      return;
    }

    if (typeof isVideo === 'undefined') {
      addToMetadataQueue(videoinfo);
      return;
    }

    // If we've parsed the metadata and know this is a video, display it.
    if (isVideo === true) {
      videoMediaDB.enumerateFiles.push(videoinfo);
    }

    if (1 !== videoMediaDB.currentBatch) {
      videoMediaDB.fileOrder++;
    }

    if (videoMediaDB.enumerateFiles.length === videoMediaDB.batchSize) {
      videoMediaDB.cancelEnumerate();
      videoMediaDB.batchEnumerateHandle();
    }
  },

  cancelEnumerate() {
    videoMediaDB.videodb.cancelEnumeration(videoMediaDB.pendingEnumerate);
  },

  batchEnumerateHandle() {
    videoMediaDB.enumerateFiles.forEach(videoMediaDB.addVideo);
    setCache();
    if (1 === videoMediaDB.currentBatch) {
      videoMediaDB.visualLoaded = true;
      window.dispatchEvent(new CustomEvent('visual-loaded',
          { detail: { index: videoMediaDB.lastIndex } }));
        if (!existCache) {
          window.performance.mark('visuallyLoaded');
          window.performance.mark('contentInteractive');
        }
    }
    videoMediaDB.enumerateFiles = [];
    if (videoMediaDB.enumerateDone) {
      videoMediaDB.stopEnumerate();
      return;
    }
    videoMediaDB.continueEnumerate();
  },

  continueEnumerate() {
    setTimeout(() => {
      if (videoMediaDB.videodb.state === MediaDB.READY) {
        videoMediaDB.startOthersEnumerate();
      } else {
        videoMediaDB.videodb.addEventListener(
          'ready',
          videoMediaDB.startOthersEnumerate()
        );
      }
    }, videoMediaDB.ENUMERATE_INTERVAL);
  },

  startOthersEnumerate() {
    videoMediaDB.currentBatch++;
    videoMediaDB.batchSize = videoMediaDB.batchSize * 10;
    videoMediaDB.pendingEnumerate = videoMediaDB.videodb.advancedEnumerate(
      'date',
      null,
      'prev',
      videoMediaDB.fileOrder,
      videoMediaDB.enumerateHandle
    );
  },

  stopEnumerate() {
    videoMediaDB.currentBatch = null;
    videoMediaDB.fileOrder = null;
    videoMediaDB.pendingEnumerate = null;
    videoMediaDB.enumerateFiles = null;
    videoMediaDB.batchSize = null;
  },

  addVideo(videodata) {
    if (!videodata || !videodata.metadata.isVideo) {
      return;
    }

    // Create the thumbnail view for this video and insert it at the right spot
    thumbnailList.addItem(videodata);
    // ThumbnailClickHandler is defined in video.js

    /*
     * If we just added the first video we need to hide the "no video" overlay
     * When firstScanEnded is true
     */
    if (thumbnailList.count === 1 && firstScanEnded) {
      updateDialog();
    }

    if (currentLayoutMode === LAYOUT_MODE.selection) {
      NavigationMap.setSoftKeyBar(LAYOUT_MODE.selection);
    }
  },

  videoCreated(videoinfo) {

    /*
     * When MediaDB tells us about a new video, we add it to the queue for
     * metadata parsing when we are able to do that.
     */
    addToMetadataQueue(videoinfo);
  },

  videoDeleted(filename) {

    /*
     * In tablet landscape mode, we use currentVideo to be the current playing
     * video and last played video. When deleting file and the file is playing or
     * last played video, we need to change the it to the next, previous or null.
     */
    if (currentVideo && filename === currentVideo.name) {
      resetCurrentVideo();
    }

    // And remove its thumbnail from the document
    thumbnailList.removeItem(filename);

    /*
     * If we just deleted the last video we need to display the "no video" overlay
     * and go back to thumbnail list view in case we were in thumbnail select view
     */
    if (thumbnailList.count === 0) {
      hidePlayer(true);
      updateDialog();
      hideSelectView();
    }
    setCache();
  }
}

window.videoMediaDB = videoMediaDB;
