/* global clients */
'use strict';
self.addEventListener('install', (event) => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

let handler = null;
let resolveIdleTimeExtension = null;
self.onsystemmessage = (evt) => {
  console.log('service_worker: system message', evt.name);
  if (evt.name === 'activity') {
    handler = evt.data.webActivityRequestHandler();
    const activityName = handler.source.name;
    console.log('service_worker: activity name', activityName);
    let htmlPath = null;
    const obj = {};
    if ('browse' === activityName) {
      htmlPath = '/index.html';
      obj.disposition = 'window';
    } else if ('pick' === activityName) {
      htmlPath = '/index.html#pick';
      obj.disposition = 'inline';
    } else if ('open' === activityName) {
      htmlPath = '/view.html';
      obj.disposition = 'inline';
    } else if ('view' === activityName) {
      htmlPath = '/view.html';
      obj.disposition = 'inline';
    }
    evt.waitUntil(
      clients.openWindow(htmlPath, obj).then(
        (openWindow) => {
          openWindow.postMessage({
            source: handler.source
          });
        },
        (err) => {
          clients.openWindow(htmlPath, obj).then(
            (openWindow) => {
              openWindow.postMessage({
                source: handler.source
              });
            },
            (error) => {
              console.log(`service_worker: openWindow fail again with error: ${error}`);
            });
          console.log(`service_worker: openWindow fail with error: ${err}`);
        }));
    const idleTimeExtension = new Promise((resolve) => {
      resolveIdleTimeExtension = resolve;
    });
    evt.waitUntil(idleTimeExtension);
  }
};

self.addEventListener('message', (event) => {
  // Message received from clients
  console.log('service_worker: receive message ', event.data);
  const { data } = event;
  if (data.isDummy) {
    return;
  }
  if (handler) {
    if (data.isError) {
      handler.postError(data.activityResult);
    } else {
      handler.postResult(data.activityResult);
    }
    handler = null;
  }
  if (resolveIdleTimeExtension) {
    resolveIdleTimeExtension();
    resolveIdleTimeExtension = null;
  }
});
