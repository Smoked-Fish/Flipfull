!function(exports) {
  'use strict';

  // Handles the "set-wallpaper" activity. Validation, cropping and saving
  // (still images, animated GIFs and MP4 videos) all live in the shared
  // WallpaperProcessor so the Settings app follows exactly the same rules.
  const Share = {
    DM_WALLPAPER_SETTINGS_KEY: 'dm.wallpaper.image',
    imageBlob: null,
    previewURL: null,

    serviceWorkerMessageHandler(evt) {
      window.keepSWStateInterval && clearInterval(window.keepSWStateInterval);
      window.keepSWStateInterval = setInterval(() => {
        navigator.serviceWorker.controller &&
          navigator.serviceWorker.controller.postMessage({ isDummy: true });
      }, 300000);

      const { source } = evt.data;
      if ('set-wallpaper' !== source.name) {
        return;
      }
      [this.imageBlob] = source.data.blobs;
      window.api.l10n.once(() => {
        WallpaperProcessor.getMediaType(this.imageBlob).then(type => {
          // Also validates the file: for MP4 this decodes the first frame.
          WallpaperProcessor.getWallpaperBlobByBlob(this.imageBlob, blob => {
            this.initSoftKey();
            if ('mp4' === type) {
              this.previewVideo(this.imageBlob);
            } else {
              // Stills are shown cropped; GIFs come back untouched and animate.
              this.previewImage(blob);
            }
          }, err => this.displayError(err));
        });
      });
    },

    initSoftKey() {
      SoftkeyHelper.init({
        header: { l10nId: 'message' },
        items: [
          { name: 'Cancel', l10nId: 'cancel', priority: 1,
            method: this.returnResult.bind(this, false) },
          { name: 'Set', l10nId: 'set-wallpaper', priority: 3,
            method: this.setWallpaper.bind(this) }
        ]
      }, this.returnResult.bind(this, false));
    },

    previewImage(blob) {
      // Kept alive until the window closes so animated GIFs keep playing.
      this.previewURL = URL.createObjectURL(blob);
      document.querySelector('#frame').style.backgroundImage =
        `url(${this.previewURL})`;
    },

    previewVideo(blob) {
      this.previewURL = URL.createObjectURL(blob);
      const video = document.createElement('video');
      video.muted = true;
      video.loop = true;
      video.autoplay = true;
      video.src = this.previewURL;
      document.querySelector('#frame').appendChild(video);
    },

    showToaster(l10nId) {
      Toaster.showToast({ messageL10nId: l10nId });
    },

    displayError(l10nId) {
      this.showToaster(l10nId);
      this.returnResult(true);
    },

    setWallpaper() {
      SettingsObserver.getValue(this.DM_WALLPAPER_SETTINGS_KEY).then(disabled => {
        if (disabled) {
          this.showDialog();
          return;
        }
        WallpaperProcessor.setWallpaperByBlob(this.imageBlob, () => {
          this.showToaster('kai-wallpaper-set');
          this.returnResult(false);
        }, err => this.displayError(err));
      });
    },

    showDialog() {
      const dialog = new ConfirmDialogHelper({
        title: { id: 'dialog-title-action-disabled', args: {} },
        body: { id: 'dialog-body-action-disabled', args: {} },
        accept: {
          l10nId: 'dialog-button-ok',
          priority: 2,
          callback: this.returnResult.bind(this, false)
        }
      });
      dialog.show(document.getElementById('app-dialog'));
    },

    returnResult(isError, result) {
      clearInterval(window.keepSWStateInterval);
      this.previewURL && URL.revokeObjectURL(this.previewURL);
      navigator.serviceWorker.controller.postMessage({
        isError,
        activityResult: result
      });
      window.close();
    }
  };

  window.onload = () => {
    window.libSession.initService(['settingsService', 'devicecapabilityService']);
    navigator.serviceWorker.addEventListener('message',
      Share.serviceWorkerMessageHandler.bind(Share));
  };

  exports.Share = Share;
}(window);
