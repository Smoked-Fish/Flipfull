self.addEventListener('install', event => {
  event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});

let handler = null;
let resolveIdleTimeExtension = null;
self.onsystemmessage = evt => {
  console.log('service_worker: wallpaper receive system message', evt.name);
  if ('activity' === evt.name) {
    handler = evt.data.webActivityRequestHandler();
    const activityName = handler.source.name;
    let htmlPath = null;
    if ('pick' === activityName) {
      htmlPath = '/pick.html';
    } else if ('set-wallpaper' === activityName) {
      htmlPath = '/share.html';
    }
    evt.waitUntil(
      // eslint-disable-next-line no-undef
      clients.openWindow(htmlPath, { disposition: 'inline' }).then(
        openWindow => {
          openWindow.postMessage({
            source: handler.source
          });
        },
        err => {
          console.error(
            `service_worker: wallpaper openWindow fail with error: ${err}`
          );
        }
      )
    );
    // IdleTimeExtension to make service worker timeout longer
    const idleTimeExtension = new Promise(resolve => {
      resolveIdleTimeExtension = resolve;
    });
    evt.waitUntil(idleTimeExtension);
  }
};

self.addEventListener('message', event => {
  console.log('service_worker: wallpaper receive message ', event.data);
  const { data } = event;
  if (data.isDummy) {
    return;
  }
  if (handler) {
    if (data.isError) {
      handler.postError(data.activityResult);
    } else {
      handler.postResult(data.activityResult);
    }
    handler = null;
  }
  if (resolveIdleTimeExtension) {
    resolveIdleTimeExtension();
    resolveIdleTimeExtension = null;
  }
});
